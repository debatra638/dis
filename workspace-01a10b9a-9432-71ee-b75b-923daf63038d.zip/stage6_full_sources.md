# LIFELINE Stage 6 — Complete Source Listing

This document contains the full contents of each Stage 6 new or modified source, migration, data, and test file in this delivery. Paths are relative to the workspace root.

## `lifeline/bot.py`

```py
"""LIFELINE Discord bot entry point."""
from __future__ import annotations

import asyncio
import logging
import secrets

import discord
from discord import app_commands
from discord.ext import commands

from core.config import Config
from core.db import DatabaseManager
from core.errors import GameError
from core.family import FamilyService
from core.locks import UserLockRegistry
from core.rng import RNG

logging.basicConfig(
    level=getattr(logging, Config.from_env().log_level, logging.INFO),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("lifeline")


class LifelineBot(commands.Bot):
    """Main bot class, owning shared database, RNG, and action-lock services."""

    def __init__(self, config: Config | None = None):
        self.config = config or Config.from_env()
        intents = discord.Intents.default()
        # The entertainment cog includes a small message listener; it needs the
        # privileged Message Content intent enabled in the Discord developer portal.
        intents.message_content = True
        super().__init__(
            command_prefix=commands.when_mentioned_or("!"),
            intents=intents,
            help_command=None,
            allowed_mentions=discord.AllowedMentions(
                everyone=False,
                users=True,
                roles=False,
                replied_user=False,
            ),
        )
        self.db: DatabaseManager | None = None
        self.family_service: FamilyService | None = None
        self.rng: RNG = RNG(self.config.rng_seed)
        self.locks = UserLockRegistry()
        self.tree.on_error = self.on_app_command_error

    async def setup_hook(self) -> None:
        """Initialize shared services, extensions, and application commands."""
        self.db = DatabaseManager(self.config.db_path)
        await self.db.initialize()
        self.family_service = FamilyService(self.db, self.rng, self.locks)
        await self._load_cogs()

        if self.config.dev_guild_id is not None:
            guild = discord.Object(id=self.config.dev_guild_id)
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
            logger.info("Synced application commands to development guild %s", guild.id)
        else:
            await self.tree.sync()
            logger.info("Synced application commands globally")

    async def _load_cogs(self) -> None:
        """Load the life simulation and entertainment command extensions."""
        for extension in ("cogs.life", "cogs.education", "cogs.career", "cogs.relationships", "cogs.discobot"):
            await self.load_extension(extension)
            logger.info("Loaded extension %s", extension)

    async def on_ready(self) -> None:
        if self.user is not None:
            logger.info("Logged in as %s (ID: %s)", self.user, self.user.id)
        logger.info("Connected to %s guilds", len(self.guilds))
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="lives unfold | /life",
            ),
            status=discord.Status.online,
        )

    async def on_app_command_error(
        self,
        interaction: discord.Interaction,
        error: app_commands.AppCommandError,
    ) -> None:
        """Send safe user-facing errors and retain unexpected errors in logs."""
        if isinstance(error, app_commands.CommandOnCooldown):
            message = f"⏳ Try again in {error.retry_after:.1f} seconds."
        elif isinstance(error, (app_commands.CheckFailure, commands.CheckFailure)):
            message = "❌ You do not have permission to use this command."
        else:
            original = getattr(error, "original", error)
            if isinstance(original, GameError):
                message = original.message
            else:
                error_id = __import__("secrets").token_hex(4)
                logger.error(
                    "Unexpected application-command error (ID %s)",
                    error_id,
                    exc_info=(type(original), original, original.__traceback__),
                )
                message = f"An unexpected error occurred (ID: {error_id}). Please try again later."
        await self._send_error(interaction, message)

    @staticmethod
    async def _send_error(interaction: discord.Interaction, message: str) -> None:
        try:
            if interaction.response.is_done():
                await interaction.followup.send(message, ephemeral=True)
            else:
                await interaction.response.send_message(message, ephemeral=True)
        except discord.HTTPException:
            logger.exception("Could not send an application-command error response")

    async def close(self) -> None:
        logger.info("Shutting down LIFELINE")
        if self.db is not None:
            await self.db.close()
        await super().close()


async def main() -> None:
    config = Config.from_env()
    token = config.require_token()
    bot = LifelineBot(config)
    async with bot:
        await bot.start(token)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
```

## `lifeline/cogs/life.py`

```py
"""Slash commands for starting and advancing a LIFELINE character."""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from core.events import EventPrompt
from core.life_engine import LifeEngine, YearOutcome
from core.models import Character
from core.views import EventChoiceView, event_embed


STAT_ORDER = (
    ("health", "❤️ Health"),
    ("happiness", "😊 Happiness"),
    ("smarts", "🧠 Smarts"),
    ("looks", "✨ Looks"),
    ("fitness", "💪 Fitness"),
    ("karma", "🍀 Karma"),
)


def _stat_bar(value: int) -> str:
    filled = max(0, min(10, round(value / 10)))
    return f"{'🟩' * filled}{'⬛' * (10 - filled)} **{value}/100**"


def _character_embed(character: Character) -> discord.Embed:
    status = "Alive" if character.is_alive else f"Deceased at age {character.death_age}"
    embed = discord.Embed(
        title=f"{character.name} · Age {character.age}",
        description=(
            f"**Life stage:** {character.life_stage.value.replace('_', ' ').title()}\n"
            f"**Status:** {status}\n"
            f"**Background:** {character.wealth_class.title()} household · {character.country.upper()}"
        ),
        color=discord.Color.green() if character.is_alive else discord.Color.dark_grey(),
    )
    embed.add_field(
        name="Core stats",
        value="\n".join(f"{label}  {_stat_bar(getattr(character.stats, key))}" for key, label in STAT_ORDER),
        inline=False,
    )
    education = character.education_level.value.replace("_", " ").title()
    if character.current_school:
        education += f" · {character.current_school} ({character.school_years_left} year(s) left)"
    embed.add_field(name="Education", value=education, inline=False)
    embed.set_footer(text=f"Generation {character.generation} · Life #{character.char_id}")
    return embed


def _outcome_description(outcome: YearOutcome) -> str:
    parts = list(outcome.log_messages)
    if outcome.stat_changes:
        changes = []
        label_map = dict(STAT_ORDER)
        for key, delta in outcome.stat_changes.items():
            label = label_map.get(key, key.replace("_", " ").title())
            changes.append(f"{label} {'+' if delta > 0 else ''}{delta}")
        parts.append("**Stat changes:** " + " · ".join(changes))
    if outcome.died:
        parts.append("Start a new life with `/life start` when you're ready.")
    return "\n".join(parts)


class LifeCog(commands.Cog):
    """Birth, status, and age-advance commands."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.engine = LifeEngine(
            bot.db,
            bot.rng,
            getattr(bot, "locks", None),
            family_service=getattr(bot, "family_service", None),
        )

    life = app_commands.Group(name="life", description="Create and guide your life simulation")

    @life.command(name="start", description="Begin a new life at birth")
    @app_commands.describe(
        name="Your character's name",
        gender="Character gender",
        country="Country or region code, such as usa or in",
    )
    @app_commands.choices(gender=[
        app_commands.Choice(name="Male", value="male"),
        app_commands.Choice(name="Female", value="female"),
        app_commands.Choice(name="Non-binary", value="non_binary"),
    ])
    async def start_life(
        self,
        interaction: discord.Interaction,
        name: str,
        gender: str = "male",
        country: str = "usa",
    ) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        character = await self.engine.create_character(
            interaction.user.id,
            name,
            gender=gender,
            country=country,
        )
        embed = _character_embed(character)
        embed.description = (
            "A new story begins. Your choices will shape the life ahead.\n\n"
            + (embed.description or "")
        )
        await interaction.followup.send(embed=embed, ephemeral=True)

    @life.command(name="status", description="View your current life and stats")
    async def life_status(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        character = await self.engine.get_active_character(interaction.user.id)
        await interaction.followup.send(embed=_character_embed(character), ephemeral=True)

    @life.command(name="age", description="Advance your life by one year")
    async def age_up(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        outcome = await self.engine.age_up(interaction.user.id)
        if outcome.pending_event is not None:
            prompt: EventPrompt = outcome.pending_event
            view = EventChoiceView(interaction.user.id, prompt, self.engine.events)
            message = await interaction.followup.send(
                embed=event_embed(prompt, lead=_outcome_description(outcome)),
                view=view,
                ephemeral=True,
                wait=True,
            )
            view.bind_message(message)
            return

        embed = _character_embed(outcome.character)
        embed.description = _outcome_description(outcome)
        if outcome.died:
            embed.color = discord.Color.dark_grey()
        elif outcome.new_stage != outcome.previous_stage:
            embed.color = discord.Color.gold()
        await interaction.followup.send(embed=embed, ephemeral=True)

    @life.command(name="choice", description="Reopen your unresolved life-event choice")
    async def resume_choice(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        prompt = await self.engine.events.get_pending_event(interaction.user.id)
        view = EventChoiceView(interaction.user.id, prompt, self.engine.events)
        message = await interaction.followup.send(
            embed=event_embed(prompt, lead="Your unresolved life event is saved."),
            view=view,
            ephemeral=True,
            wait=True,
        )
        view.bind_message(message)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(LifeCog(bot))
```

## `lifeline/cogs/relationships.py`

```py
"""Discord slash commands and nonce-protected menus for Stage 6 relationships."""
from __future__ import annotations

from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from core.errors import GameError, ValidationError
from core.family import (
    RING_CATALOG,
    WEDDING_TIERS,
    DateOutcome,
    DateSearch,
    FamilyService,
    InfidelityPrompt,
    InteractionOutcome,
    ProposalOutcome,
)
from core.money import format_cents
from core.views import OwnedView


ACTION_CHOICES = [
    app_commands.Choice(name="Spend time", value="spend_time"),
    app_commands.Choice(name="Give a gift", value="gift"),
    app_commands.Choice(name="Compliment", value="compliment"),
    app_commands.Choice(name="Argue", value="argue"),
    app_commands.Choice(name="Ask for money (parents only)", value="ask_for_money"),
    app_commands.Choice(name="Insult", value="insult"),
]
WEDDING_CHOICES = [
    app_commands.Choice(name="Courthouse · $100", value="courthouse"),
    app_commands.Choice(name="Intimate · $2,500", value="intimate"),
    app_commands.Choice(name="Traditional · $25,000", value="traditional"),
    app_commands.Choice(name="Lavish · $80,000 × price index", value="lavish"),
]
RING_CHOICES = [
    app_commands.Choice(name=f"{item['name']} · {format_cents(int(item['price']))}", value=item_id)
    for item_id, item in RING_CATALOG.items()
]


def _safe(value: object) -> str:
    """Escape user-facing names and suppress every Discord mention."""
    text = discord.utils.escape_markdown(str(value))
    return discord.utils.escape_mentions(text)


def _person_label(person: dict[str, object]) -> str:
    """Build a compact, escaped person label for family embeds."""
    name = _safe(person.get("name", "Unknown"))
    relation = _safe(person.get("relationship_type", "relative")).title()
    score = int(person.get("relationship_score", 0))
    alive = "Alive" if bool(person.get("is_alive", True)) else f"Died at age {person.get('death_age', '?')}"
    age = int(person.get("age", 0))
    return f"**{name}** · {relation} · age {age} · relationship {score}/100 · {alive}"


def _roster_embed(title: str, character: object, people: list[dict[str, object]]) -> discord.Embed:
    """Render a character's connected NPCs without exposing raw markdown or mentions."""
    name = _safe(getattr(character, "name", "Life"))
    age = int(getattr(character, "age", 0))
    embed = discord.Embed(
        title=f"{title} · {name}",
        description=f"Age {age} · {len(people)} connected person(s)",
        color=discord.Color.blurple(),
    )
    if not people:
        embed.add_field(name="Family and relationships", value="No people are recorded yet.", inline=False)
    for person in people[:20]:
        relation = str(person.get("relationship_type", "relative")).replace("_", " ").title()
        score = int(person.get("relationship_score", 0))
        value = _person_label(person)
        if person.get("custody"):
            value += f"\nCustody: {_safe(person['custody'])}"
        if int(person.get("child_support", 0) or 0) > 0:
            value += f" · Annual support: {format_cents(int(person['child_support']))}"
        embed.add_field(name=f"{relation} · {score}/100", value=value[:1024], inline=False)
    if len(people) > 20:
        embed.set_footer(text=f"Showing 20 of {len(people)} people")
    return embed


def _date_embed(search: DateSearch) -> discord.Embed:
    """Show all three date candidates as selectable profile cards."""
    embed = discord.Embed(
        title="Meet someone new",
        description="Choose one candidate below. Dating age rules are checked again when you select.",
        color=discord.Color.magenta(),
    )
    for index, person in enumerate(search.candidates, start=1):
        embed.add_field(
            name=f"Candidate {index} · {_safe(person['name'])}",
            value=(
                f"Age {person['age']} · {_safe(person['occupation'])}\n"
                f"Looks {person['looks']}/100 · Smarts {person['smarts']}/100 · "
                f"Health {person['health']}/100\n"
                f"Wealth: {format_cents(int(person['wealth']))}"
            ),
            inline=False,
        )
    embed.set_footer(text="This private selection expires in 15 minutes")
    return embed


def _date_outcome_embed(outcome: DateOutcome) -> discord.Embed:
    """Render a date result while retaining the calculated chance for feedback."""
    person = outcome.npc
    if outcome.accepted:
        title = f"A new relationship with {_safe(person['name'])}!"
        description = f"They agreed to date you. Your relationship score is 60/100."
        color = discord.Color.green()
    else:
        title = "The date didn't work out"
        description = f"{_safe(person['name'])} declined this time. You can meet new people with `/date find`."
        color = discord.Color.orange()
    embed = discord.Embed(title=title, description=description, color=color)
    embed.set_footer(text=f"Success chance: {outcome.success_chance:.1f}%")
    return embed


def _interaction_embed(outcome: InteractionOutcome) -> discord.Embed:
    """Render the score and money effect of one person-to-person action."""
    embed = discord.Embed(
        title=f"Relationship · {_safe(outcome.person_name)}",
        description=_safe(outcome.message),
        color=discord.Color.green() if outcome.score_after >= outcome.score_before else discord.Color.orange(),
    )
    embed.add_field(
        name="Relationship score",
        value=f"{outcome.score_before}/100 → {outcome.score_after}/100",
        inline=True,
    )
    if outcome.money_delta:
        embed.add_field(name="Money change", value=format_cents(outcome.money_delta), inline=True)
    embed.set_footer(text="Three interactions per person per in-game year")
    return embed


def _proposal_embed(outcome: ProposalOutcome) -> discord.Embed:
    """Render a proposal result."""
    result = "accepted" if outcome.accepted else "declined"
    return discord.Embed(
        title="💍 Proposal " + result,
        description=(
            f"{_safe(outcome.person_name)} {result} your proposal.\n"
            f"Acceptance chance: {outcome.chance}% · Ring bonus: +{outcome.ring_bonus}%"
        ),
        color=discord.Color.green() if outcome.accepted else discord.Color.orange(),
    )


class DateCandidateSelect(discord.ui.Select["DateSearchView"]):
    """A select menu whose custom ID and server-side nonce protect date options."""

    def __init__(self, search: DateSearch):
        options = [
            discord.SelectOption(
                label=f"{_safe(person['name'])} · age {person['age']}"[:100],
                description=f"{_safe(person['occupation'])} · looks {person['looks']} · smarts {person['smarts']}"[:100],
                value=str(person["npc_id"]),
            )
            for person in search.candidates
        ]
        super().__init__(
            placeholder="Choose a date",
            min_values=1,
            max_values=1,
            options=options,
            custom_id=f"lifeline:date:{search.nonce}",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        """Resolve one candidate and disable the menu after the one-use session."""
        view = self.view
        if not isinstance(view, DateSearchView):
            return
        try:
            await interaction.response.defer()
            outcome = await view.service.choose_date(interaction.user.id, int(self.values[0]), view.nonce)
            if interaction.message is not None:
                await interaction.message.edit(embed=_date_outcome_embed(outcome), view=None)
            view.stop()
        except GameError as exc:
            await interaction.followup.send(exc.message, ephemeral=True)
        except (ValueError, TypeError):
            await interaction.followup.send("That date selection is invalid.", ephemeral=True)


class DateSearchView(OwnedView):
    """Owner-checked select menu backed by a database nonce and expiry."""

    def __init__(self, owner_id: int, search: DateSearch, service: FamilyService):
        super().__init__(owner_id, search.nonce, timeout=180.0)
        self.service = service
        self.add_item(DateCandidateSelect(search))


class InfidelityChoiceView(OwnedView):
    """Owner-checked cheat-or-not choice with a persistent one-use nonce."""

    def __init__(self, owner_id: int, prompt: InfidelityPrompt, service: FamilyService):
        super().__init__(owner_id, prompt.nonce, timeout=180.0)
        self.service = service
        self.spouse_name = prompt.spouse_name
        self.add_item(InfidelityChoiceButton("Cheat", True, prompt.nonce))
        self.add_item(InfidelityChoiceButton("Stay faithful", False, prompt.nonce))

    async def resolve_choice(self, interaction: discord.Interaction, cheat: bool) -> None:
        """Resolve the selected temptation and remove controls after use."""
        try:
            await interaction.response.defer()
            message = await self.service.resolve_infidelity_choice(interaction.user.id, self.nonce, cheat)
            embed = discord.Embed(
                title="Relationship choice",
                description=_safe(message),
                color=discord.Color.orange() if cheat else discord.Color.green(),
            )
            if interaction.message is not None:
                await interaction.message.edit(embed=embed, view=None)
            self.stop()
        except GameError as exc:
            await interaction.followup.send(exc.message, ephemeral=True)


class InfidelityChoiceButton(discord.ui.Button[InfidelityChoiceView]):
    """One nonce-tagged infidelity option."""

    def __init__(self, label: str, cheat: bool, nonce: str):
        super().__init__(
            label=label,
            style=discord.ButtonStyle.danger if cheat else discord.ButtonStyle.success,
            custom_id=f"lifeline:temptation:{nonce}:{'cheat' if cheat else 'faithful'}",
        )
        self.cheat = cheat

    async def callback(self, interaction: discord.Interaction) -> None:
        """Delegate after the base view confirms component ownership."""
        if isinstance(self.view, InfidelityChoiceView):
            await self.view.resolve_choice(interaction, self.cheat)


class RelationshipsCog(commands.Cog):
    """Family, relationship, dating, friendship, and ring-shop slash commands."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.service = getattr(bot, "family_service", None) or FamilyService(
            bot.db, bot.rng, getattr(bot, "locks", None)
        )

    relationship = app_commands.Group(name="relationship", description="Manage friends, romance, and family")
    date = app_commands.Group(name="date", description="Meet age-appropriate dating candidates")
    friends = app_commands.Group(name="friends", description="Meet and manage friends")
    shop = app_commands.Group(name="shop", description="Buy relationship items")

    @app_commands.command(name="family", description="View your parents, siblings, partner, and children")
    @app_commands.checks.cooldown(1, 3.0)
    async def family_command(self, interaction: discord.Interaction) -> None:
        """Show the full current family and relationship roster."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        character, people = await self.service.family(interaction.user.id)
        await interaction.followup.send(
            embed=_roster_embed("Family", character, people),
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @relationship.command(name="list", description="List people and relationship scores")
    @app_commands.checks.cooldown(1, 3.0)
    async def relationship_list(self, interaction: discord.Interaction) -> None:
        """List all relatives, friends, partners, former partners, and children."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        character, people = await self.service.relationship_list(interaction.user.id)
        await interaction.followup.send(
            embed=_roster_embed("Relationships", character, people),
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @relationship.command(name="interact", description="Interact with one person up to three times per year")
    @app_commands.describe(
        person="A relative, friend, partner, or other listed NPC",
        action="Choose how to interact",
        gift_dollars="Gift amount in whole dollars (required for the gift action)",
    )
    @app_commands.choices(action=ACTION_CHOICES)
    @app_commands.checks.cooldown(1, 3.0)
    async def interact(
        self,
        interaction: discord.Interaction,
        person: str,
        action: str,
        gift_dollars: Optional[int] = None,
    ) -> None:
        """Apply a selected action to an autocomplete-selected person."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        npc_id = self._person_id(person)
        outcome = await self.service.interact(interaction.user.id, npc_id, action, gift_dollars)
        await interaction.followup.send(
            embed=_interaction_embed(outcome),
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @interact.autocomplete("person")
    async def interaction_person_autocomplete(
        self,
        interaction: discord.Interaction,
        current: str,
    ) -> list[app_commands.Choice[str]]:
        """Offer living connected NPCs with their relationship types."""
        return await self._autocomplete(interaction, current)

    @relationship.command(name="propose", description="Propose after a year together with a strong partner score")
    @app_commands.describe(person="Your current partner; optional owned rings boost acceptance")
    @app_commands.checks.cooldown(1, 3.0)
    async def propose(self, interaction: discord.Interaction, person: str) -> None:
        """Propose to an eligible partner."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        outcome = await self.service.propose(interaction.user.id, self._person_id(person))
        await interaction.followup.send(
            embed=_proposal_embed(outcome),
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @propose.autocomplete("person")
    async def propose_person_autocomplete(
        self,
        interaction: discord.Interaction,
        current: str,
    ) -> list[app_commands.Choice[str]]:
        """Autocomplete connected living NPCs for a proposal."""
        return await self._autocomplete(interaction, current, types={"partner"})

    @relationship.command(name="marry", description="Hold a wedding with your fiance")
    @app_commands.describe(wedding="Wedding size", prenup="Protect premarital cash, bank, and property in divorce")
    @app_commands.choices(wedding=WEDDING_CHOICES)
    @app_commands.checks.cooldown(1, 3.0)
    async def marry(self, interaction: discord.Interaction, wedding: str = "courthouse", prenup: bool = False) -> None:
        """Complete a wedding at the chosen indexed cost and optionally record a prenup."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await self.service.marry(interaction.user.id, wedding, prenup)
        embed = discord.Embed(
            title="💒 Wedding complete",
            description=(
                f"You married **{_safe(result.person_name)}**.\n"
                f"Wedding cost: {format_cents(result.wedding_cost)}\n"
                f"Prenup: {'signed' if result.prenup else 'not signed'}\n"
                f"Spouse annual income: {format_cents(result.annual_income)}"
            ),
            color=discord.Color.gold(),
        )
        await interaction.followup.send(embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @relationship.command(name="divorce", description="End a marriage and settle assets, custody, and support")
    @app_commands.checks.cooldown(1, 3.0)
    async def divorce(self, interaction: discord.Interaction) -> None:
        """Run a transactional divorce with asset division, legal fees, and custody."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        outcome = await self.service.divorce(interaction.user.id)
        embed = discord.Embed(
            title="Divorce finalized",
            description=(
                f"{_safe(outcome.spouse_name)} is now your ex-spouse.\n"
                f"Eligible marital assets: {format_cents(outcome.marital_assets)}\n"
                f"Spouse share: {format_cents(outcome.spouse_share)}\n"
                f"Lawyer fees: {format_cents(outcome.lawyer_fee)}\n"
                f"Children affected: {outcome.children}"
            ),
            color=discord.Color.orange(),
        )
        if outcome.alimony_annual:
            embed.add_field(
                name="Alimony",
                value=(
                    f"{format_cents(outcome.alimony_annual)} per year for "
                    f"{outcome.alimony_years:g} year(s)"
                ),
                inline=False,
            )
        await interaction.followup.send(embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @relationship.command(name="breakup", description="End a dating or engagement relationship")
    @app_commands.describe(person="Your current partner or fiance")
    @app_commands.checks.cooldown(1, 3.0)
    async def breakup(self, interaction: discord.Interaction, person: str) -> None:
        """Break up with an autocomplete-selected partner or fiance."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        message = await self.service.breakup(interaction.user.id, self._person_id(person))
        await interaction.followup.send(_safe(message), ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @breakup.autocomplete("person")
    async def breakup_person_autocomplete(
        self,
        interaction: discord.Interaction,
        current: str,
    ) -> list[app_commands.Choice[str]]:
        """Autocomplete living partners and fiances for breakup."""
        return await self._autocomplete(interaction, current, types={"partner", "fiance"})

    @relationship.command(name="try_for_baby", description="Try for a baby with your partner or spouse")
    @app_commands.checks.cooldown(1, 3.0)
    async def try_for_baby(self, interaction: discord.Interaction) -> None:
        """Use the age-based fertility curve to start a one-year pregnancy."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        success, chance = await self.service.try_for_baby(interaction.user.id)
        message = (
            f"Pregnancy started. The baby is due after your next `/life age`. Chance was {chance * 100:.1f}%."
            if success
            else f"No pregnancy this year. Estimated chance was {chance * 100:.1f}%; you may try again next year."
        )
        await interaction.followup.send(_safe(message), ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @relationship.command(name="adopt", description="Begin a paid adoption with a one-year wait")
    @app_commands.checks.cooldown(1, 3.0)
    async def adopt(self, interaction: discord.Interaction) -> None:
        """Pay the indexed adoption fee and schedule the child's arrival next year."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        cost = await self.service.adopt(interaction.user.id)
        await interaction.followup.send(
            f"Adoption started. The child will join after your next `/life age`. Cost: {format_cents(cost)}.",
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @relationship.command(name="temptation", description="Choose whether to cheat or stay faithful")
    @app_commands.checks.cooldown(1, 3.0)
    async def temptation(self, interaction: discord.Interaction) -> None:
        """Create a one-use infidelity choice event for a married character."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        prompt = await self.service.start_infidelity_choice(interaction.user.id)
        embed = discord.Embed(
            title="A moment of temptation",
            description=f"Your spouse **{_safe(prompt.spouse_name)}** is not here. What do you do?\n\n"
                        "If you cheat, there is a 35% discovery chance each year.",
            color=discord.Color.orange(),
        )
        view = InfidelityChoiceView(interaction.user.id, prompt, self.service)
        message = await interaction.followup.send(
            embed=embed,
            view=view,
            ephemeral=True,
            wait=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        view.bind_message(message)

    @date.command(name="find", description="Find three age-appropriate dating candidates")
    @app_commands.checks.cooldown(1, 3.0)
    async def date_find(self, interaction: discord.Interaction) -> None:
        """Generate three NPC candidates and present an owner-only select menu."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        search = await self.service.find_dates(interaction.user.id)
        view = DateSearchView(interaction.user.id, search, self.service)
        message = await interaction.followup.send(
            embed=_date_embed(search),
            view=view,
            ephemeral=True,
            wait=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        view.bind_message(message)

    @friends.command(name="find", description="Meet an age-appropriate friend")
    @app_commands.checks.cooldown(1, 3.0)
    async def friend_find(self, interaction: discord.Interaction) -> None:
        """Generate one age-appropriate friend NPC."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        person = await self.service.find_friend(interaction.user.id)
        embed = discord.Embed(
            title=f"You met {_safe(person['name'])}!",
            description=(
                f"Age {person['age']} · {_safe(person['occupation'])}\n"
                f"Relationship score: {person['relationship_score']}/100"
            ),
            color=discord.Color.green(),
        )
        await interaction.followup.send(embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @shop.command(name="ring", description="Buy an engagement ring for your next proposal")
    @app_commands.describe(ring="Ring item to purchase")
    @app_commands.choices(ring=RING_CHOICES)
    @app_commands.checks.cooldown(1, 3.0)
    async def shop_ring(self, interaction: discord.Interaction, ring: str) -> None:
        """Buy one ring and store its integer-cent value and proposal bonus."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        cost, bonus = await self.service.buy_ring(interaction.user.id, ring)
        item = RING_CATALOG[ring]
        await interaction.followup.send(
            f"Purchased **{_safe(item['name'])}** for {format_cents(cost)}. It gives +{bonus}% proposal acceptance.",
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @staticmethod
    def _person_id(value: str) -> int:
        """Parse the opaque NPC ID supplied by autocomplete without accepting names."""
        try:
            npc_id = int(value)
        except (TypeError, ValueError) as exc:
            raise ValidationError("Select a person from the autocomplete list.") from exc
        if npc_id <= 0:
            raise ValidationError("Select a person from the autocomplete list.")
        return npc_id

    async def _autocomplete(
        self,
        interaction: discord.Interaction,
        current: str,
        *,
        types: Optional[set[str]] = None,
    ) -> list[app_commands.Choice[str]]:
        """Create escaped Discord choices from the current life's people."""
        people = await self.service.autocomplete_people(interaction.user.id, current)
        if types is not None:
            people = [person for person in people if str(person["relationship_type"]) in types]
        return [
            app_commands.Choice(
                name=f"{_safe(person['name'])} · {_safe(person['relationship_type'])} · age {person['age']}"[:100],
                value=str(person["npc_id"]),
            )
            for person in people[:25]
        ]


async def setup(bot: commands.Bot) -> None:
    """Load the Stage 6 command cog."""
    await bot.add_cog(RelationshipsCog(bot))
```

## `lifeline/core/errors.py`

```py
"""User-safe domain exceptions for LIFELINE game operations."""
from __future__ import annotations


class GameError(Exception):
    """Expected game-rule error whose message is safe to show to a player."""

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message


class ValidationError(GameError):
    """An input value does not satisfy game rules."""


class CharacterNotFound(GameError):
    def __init__(self, message: str = "You do not have a life yet. Start one with `/life start`."):
        super().__init__(message)


class CharacterAlreadyExists(GameError):
    def __init__(self, message: str = "You already have an active life. Use `/life status` to view it."):
        super().__init__(message)


class CharacterDead(GameError):
    def __init__(self, message: str = "This life has ended. Start a new one to continue playing."):
        super().__init__(message)


class CharacterBusy(GameError):
    def __init__(self, message: str = "Your character is already processing an action. Try again in a moment."):
        super().__init__(message)


class ConcurrentUpdate(GameError):
    def __init__(self, message: str = "Your life changed while this action was processing. Please try again."):
        super().__init__(message)


class PendingEventExists(GameError):
    def __init__(self, message: str = "Resolve your pending life event with `/life choice` before aging again."):
        super().__init__(message)


class PendingEventNotFound(GameError):
    def __init__(self, message: str = "You have no pending life event. Use `/life age` to continue your story."):
        super().__init__(message)


class StaleEvent(GameError):
    def __init__(self, message: str = "This choice has already been resolved or is no longer available. Use `/life choice` to check for another event."):
        super().__init__(message)


class NotEnrolled(GameError):
    def __init__(self, message: str = "You are not currently enrolled. Check `/education status` for options."):
        super().__init__(message)


class StudyAlreadyUsed(GameError):
    def __init__(self, message: str = "You have already studied this year. You can study again after `/life age`."):
        super().__init__(message)


class EducationRequirementError(GameError):
    def __init__(self, message: str):
        super().__init__(message)


class JobAlreadyExists(GameError):
    def __init__(self, message: str = "You already have a job. Use `/career status` or `/career quit` first."):
        super().__init__(message)


class NoActiveJob(GameError):
    def __init__(self, message: str = "You do not have a job right now. Use `/career list` to explore careers."):
        super().__init__(message)


class WorkAlreadyUsed(GameError):
    def __init__(self, message: str = "You have already worked this in-game year. Work again after `/life age`."):
        super().__init__(message)


class RetiredCharacter(GameError):
    def __init__(self, message: str = "You are retired and cannot take a new job."):
        super().__init__(message)


class FamilyRequirementError(GameError):
    """A family or relationship action is not permitted by current life state."""


class RelationshipNotFound(GameError):
    def __init__(self, message: str = "That person is not in your relationship list."):
        super().__init__(message)


class InteractionLimitReached(GameError):
    def __init__(self, message: str = "You have used all three interactions with this person this year."):
        super().__init__(message)


class InsufficientFunds(GameError):
    def __init__(self, message: str = "You do not have enough available funds for that action."):
        super().__init__(message)


class DateSessionExpired(GameError):
    def __init__(self, message: str = "These date options expired. Use `/date find` to meet new people."):
        super().__init__(message)


class NoActiveMarriage(GameError):
    def __init__(self, message: str = "You are not currently married."):
        super().__init__(message)
```

## `lifeline/core/family.py`

```py
"""Stage 6 family generation, relationships, dating, marriage, and yearly care."""
from __future__ import annotations

import json
import logging
import secrets
import time
from dataclasses import dataclass, replace
from decimal import Decimal, ROUND_HALF_UP
from typing import Any, Callable, Optional

import aiosqlite

from .data_loader import DataLoader
from .errors import (
    CharacterDead,
    CharacterNotFound,
    ConcurrentUpdate,
    DateSessionExpired,
    EducationRequirementError,
    FamilyRequirementError,
    InsufficientFunds,
    InteractionLimitReached,
    NoActiveMarriage,
    PendingEventExists,
    RelationshipNotFound,
    ValidationError,
)
from .locks import UserLockRegistry
from .models import Character, EducationLevel, Gender, Stats
from .money import dollars_to_cents, scale_cents
from .repositories.family import FamilyRepository
from .rng import RNG

logger = logging.getLogger("lifeline.family")


@dataclass(frozen=True, slots=True)
class DateSearch:
    """Three generated NPC candidates and the owner/nonce-bound menu token."""

    nonce: str
    candidates: tuple[dict[str, Any], ...]
    expires_at: int


@dataclass(frozen=True, slots=True)
class DateOutcome:
    """Outcome of selecting one candidate from a date search."""

    npc: dict[str, Any]
    success_chance: float
    accepted: bool
    relationship_score: Optional[int]


@dataclass(frozen=True, slots=True)
class InteractionOutcome:
    """Result of one relationship interaction."""

    person_name: str
    action: str
    score_before: int
    score_after: int
    message: str
    money_delta: int = 0


@dataclass(frozen=True, slots=True)
class ProposalOutcome:
    """Outcome of proposing to an eligible partner."""

    person_name: str
    chance: int
    accepted: bool
    ring_bonus: int


@dataclass(frozen=True, slots=True)
class MarriageOutcome:
    """Wedding details after cost, prenup, and spouse income are recorded."""

    person_name: str
    wedding_cost: int
    prenup: bool
    annual_income: int


@dataclass(frozen=True, slots=True)
class DivorceSplit:
    """Pure integer-cent divorce asset allocation result."""

    eligible_assets: int
    spouse_share: int
    protected_assets: int


@dataclass(frozen=True, slots=True)
class DivorceOutcome:
    """Completed divorce settlement and its cash-flow consequences."""

    character: Character
    spouse_name: str
    marital_assets: int
    spouse_share: int
    lawyer_fee: int
    children: int
    alimony_annual: int
    alimony_years: float
    message: str


@dataclass(frozen=True, slots=True)
class FamilyYearResult:
    """Character state and journal messages produced by Stage 6's annual tick."""

    character: Character
    messages: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class InfidelityPrompt:
    """Nonce-protected choice between cheating and remaining faithful."""

    nonce: str
    spouse_name: str
    expires_at: int


RING_CATALOG: dict[str, dict[str, int | str]] = {
    "simple_ring": {"name": "Simple band", "price": 10_000, "bonus": 1},
    "silver_ring": {"name": "Silver ring", "price": 100_000, "bonus": 4},
    "gold_ring": {"name": "Gold ring", "price": 500_000, "bonus": 8},
    "diamond_ring": {"name": "Diamond ring", "price": 2_000_000, "bonus": 14},
    "heirloom_ring": {"name": "Heirloom ring", "price": 10_000_000, "bonus": 20},
}

WEDDING_TIERS: dict[str, tuple[str, int]] = {
    "courthouse": ("Courthouse", 10_000),
    "intimate": ("Intimate", 250_000),
    "traditional": ("Traditional", 2_500_000),
    "lavish": ("Lavish", 8_000_000),
}

_NAME_GENDERS = (Gender.MALE, Gender.FEMALE, Gender.NON_BINARY)
_WEALTH_RANGES = {
    "poor": (100_000, 1_500_000),
    "working": (1_500_000, 8_000_000),
    "middle": (8_000_000, 60_000_000),
    "upper": (60_000_000, 500_000_000),
    "rich": (500_000_000, 5_000_000_000),
}
_WEALTH_WEIGHTS = ("poor", "working", "middle", "upper", "rich")
_WEALTH_PROBABILITIES = (0.10, 0.25, 0.40, 0.18, 0.07)
_OCCUPATION_INCOMES = (
    ("Teacher", 5_200_000),
    ("Nurse", 6_000_000),
    ("Engineer", 8_400_000),
    ("Small business owner", 6_500_000),
    ("Artist", 3_800_000),
    ("Accountant", 6_200_000),
    ("Chef", 4_000_000),
    ("Researcher", 7_200_000),
    ("Mechanic", 4_600_000),
    ("Public servant", 5_000_000),
)
_COST_OF_LIVING = {"poor": 0.80, "working": 0.90, "middle": 1.00, "upper": 1.20, "rich": 1.50}


def can_date_ages(player_age: int, npc_age: int) -> bool:
    """Enforce the age boundary for dating independently of generated/UI options."""
    if player_age < 16 or npc_age < 0:
        return False
    if player_age < 18:
        return npc_age < 18 and abs(player_age - npc_age) <= 2
    return npc_age >= 18 and abs(player_age - npc_age) <= 5


def proposal_acceptance_chance(score: int, ring_bonus: int = 0) -> int:
    """Return a clamped proposal chance from relationship score and ring bonus."""
    return max(0, min(100, int(score) - 20 + max(0, min(20, int(ring_bonus)))))


def dating_success_chance(
    *,
    player_looks: int,
    npc_looks: int,
    player_smarts: int,
    npc_smarts: int,
    npc_prefers_smarts: bool,
    fame: int,
    npc_wealth: int,
) -> float:
    """Calculate the requested dating formula and clamp it to 5–90 percent."""
    smarts_bonus = (player_smarts - npc_smarts) * 0.4 if npc_prefers_smarts else 0.0
    wealthy_bonus = 10.0 if npc_wealth >= dollars_to_cents(1_000_000) else 0.0
    value = 40.0 + (player_looks - npc_looks) * 0.8 + smarts_bonus + fame * 0.2 + wealthy_bonus
    return max(5.0, min(90.0, value))


def calculate_fertility_factor(age: int) -> float:
    """Return the specified piecewise female fertility curve."""
    if age < 0:
        raise ValueError("age cannot be negative")
    if age < 30:
        return 1.0
    if age < 35:
        return 1.0 - (age - 30) * 0.06
    if age < 40:
        return 0.7 - (age - 35) * 0.08
    if age < 45:
        return 0.3 - (age - 40) * 0.05
    if age < 50:
        return max(0.0, 0.05 - (age - 45) * 0.01)
    return 0.0


def calculate_male_fertility_factor(age: int) -> float:
    """Return a gentle age-related male fertility multiplier."""
    if age < 0:
        raise ValueError("age cannot be negative")
    return max(0.2, 1.0 - max(0, age - 30) * 0.02)


def calculate_divorce_split(
    *,
    cash: int,
    bank: int,
    marital_item_values: list[int] | tuple[int, ...],
    prenup: bool,
    premarital_cash: int = 0,
    premarital_bank: int = 0,
) -> DivorceSplit:
    """Calculate a 50/50 split in integer cents without making balances negative."""
    values = (cash, bank, premarital_cash, premarital_bank, *marital_item_values)
    if any(isinstance(value, bool) or not isinstance(value, int) or value < 0 for value in values):
        raise ValueError("divorce assets must be non-negative integer cents")
    protected_cash = min(cash, premarital_cash) if prenup else 0
    protected_bank = min(bank, premarital_bank) if prenup else 0
    eligible = cash - protected_cash + bank - protected_bank + sum(marital_item_values)
    return DivorceSplit(
        eligible_assets=eligible,
        spouse_share=eligible // 2,
        protected_assets=protected_cash + protected_bank,
    )


def calculate_alimony(player_income: int, spouse_income: int, marriage_years: int) -> tuple[bool, int, float]:
    """Return (player_pays, annual amount, duration) from 20% of income difference."""
    if player_income < 0 or spouse_income < 0 or marriage_years < 0:
        raise ValueError("incomes and marriage duration must be non-negative")
    difference = abs(int(player_income) - int(spouse_income))
    annual = int((Decimal(difference) * Decimal("0.20")).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    duration = float(marriage_years) / 2.0
    return player_income > spouse_income, annual, duration


def calculate_joint_tax(combined_income: int) -> int:
    """Apply progressive US-style sample tax bands with every joint band doubled.

    This stage has no pre-existing tax service; these explicit game bands keep
    spouse income and the character's gross annual salary in one household basis.
    All thresholds and results are integer cents.
    """
    if combined_income <= 0:
        return 0
    single_bands = (
        (1_000_000, 0.10),
        (4_000_000, 0.12),
        (9_000_000, 0.22),
        (18_000_000, 0.24),
        (30_000_000, 0.32),
        (None, 0.35),
    )
    remaining = int(combined_income)
    lower = 0
    tax = 0
    for upper_single, rate in single_bands:
        upper = None if upper_single is None else upper_single * 2
        bracket_width = remaining if upper is None else max(0, min(remaining, upper - lower))
        tax += int((Decimal(bracket_width) * Decimal(str(rate))).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        remaining -= bracket_width
        if remaining <= 0:
            break
        if upper is not None:
            lower = upper
    return max(0, min(int(combined_income), tax))


class FamilyService:
    """Transactional family/NPC domain service integrated into LIFELINE's age tick."""

    def __init__(
        self,
        db: Any,
        rng: RNG,
        locks: Optional[UserLockRegistry] = None,
        *,
        repository: Optional[FamilyRepository] = None,
        data_loader: Optional[DataLoader] = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.db = db
        self.rng = rng.fork("lifeline-stage6-family")
        self.locks = locks or UserLockRegistry()
        self.repository = repository or FamilyRepository(db)
        self.clock = clock
        self.names = (data_loader or DataLoader()).load_json("names.json")
        self._validate_names(self.names)

    @staticmethod
    def _validate_names(document: Any) -> None:
        if not isinstance(document, dict) or document.get("schema_version") != 1:
            raise ValueError("names.json must be a schema-version-1 object")
        defaults = document.get("defaults")
        countries = document.get("countries")
        if not isinstance(defaults, dict) or not isinstance(countries, dict):
            raise ValueError("names.json requires defaults and countries objects")
        for group in (defaults, *countries.values()):
            if not isinstance(group, dict):
                raise ValueError("each names group must be an object")
            for gender in ("male", "female", "non_binary"):
                names = group.get(gender)
                if not isinstance(names, list) or not names or any(not isinstance(name, str) or not name.strip() for name in names):
                    raise ValueError(f"names.json requires non-empty {gender} name lists")

    def _name(self, country: str, gender: Gender) -> str:
        """Select a gender-aware name from the character's country or fallback list."""
        group = self.names["countries"].get(country.lower(), self.names["defaults"])
        return self.rng.choice(group[gender.value])

    def _wealth(self, wealth_class: str) -> int:
        """Roll integer-cent NPC net worth within a class-specific band."""
        low, high = _WEALTH_RANGES.get(wealth_class, _WEALTH_RANGES["middle"])
        return self.rng.randint(low, high)

    def _occupation(self, wealth_class: str, *, child: bool = False) -> tuple[str, int]:
        """Choose an NPC occupation and annual income in integer cents."""
        if child:
            return "Student", 0
        occupation, base_income = self.rng.choice(_OCCUPATION_INCOMES)
        multiplier = {"poor": 0.70, "working": 0.85, "middle": 1.0, "upper": 1.3, "rich": 1.8}.get(wealth_class, 1.0)
        return occupation, scale_cents(base_income, multiplier)

    def _stats(self, *, means: Optional[tuple[float, float, float]] = None) -> tuple[int, int, int]:
        """Generate bounded NPC looks, smarts, and health from Gaussian rolls."""
        look_mean, smarts_mean, health_mean = means or (50.0, 50.0, 75.0)
        values = (
            int(round(self.rng.gauss(look_mean, 15.0))),
            int(round(self.rng.gauss(smarts_mean, 15.0))),
            int(round(self.rng.gauss(health_mean, 12.0))),
        )
        return tuple(max(0, min(100, value)) for value in values)  # type: ignore[return-value]

    def _npc_fields(
        self,
        character: Character,
        *,
        gender: Gender,
        age: int,
        wealth_class: Optional[str] = None,
        occupation: Optional[str] = None,
        annual_income: Optional[int] = None,
        means: Optional[tuple[float, float, float]] = None,
        prefers_smarts: Optional[bool] = None,
    ) -> dict[str, Any]:
        """Create generation data while keeping gameplay randomness in the RNG wrapper."""
        selected_wealth = wealth_class or self.rng.weighted_choice(_WEALTH_WEIGHTS, _WEALTH_PROBABILITIES)
        selected_occupation, selected_income = self._occupation(selected_wealth, child=occupation == "Student")
        if occupation is not None:
            selected_occupation = occupation
        if annual_income is not None:
            selected_income = annual_income
        looks, smarts, health = self._stats(means=means)
        return {
            "owner_char_id": character.char_id,
            "name": self._name(character.country, gender),
            "gender": gender.value,
            "age": max(0, min(120, int(age))),
            "looks": looks,
            "smarts": smarts,
            "health": health,
            "wealth": 0 if occupation == "Student" else self._wealth(selected_wealth),
            "occupation": selected_occupation,
            "country": character.country,
            "annual_income": selected_income,
            "prefers_smarts": bool(self.rng.random() < 0.35) if prefers_smarts is None else prefers_smarts,
        }

    async def _insert_npc(self, tx: aiosqlite.Connection, fields: dict[str, Any]) -> int:
        """Persist one NPC using the Stage 6 repository."""
        return await self.repository.create_npc(tx, **fields)

    async def initialize_family(self, tx: aiosqlite.Connection, character: Character) -> tuple[str, ...]:
        """Generate two parents and zero to three siblings at the character's birth."""
        messages: list[str] = []
        parent_ages: list[int] = []
        for gender in (Gender.FEMALE, Gender.MALE):
            age = self.rng.randint(22, 40)
            parent_ages.append(age)
            npc_id = await self._insert_npc(
                tx,
                self._npc_fields(character, gender=gender, age=age, wealth_class=character.wealth_class),
            )
            score = self.rng.randint(60, 90)
            await self.repository.create_relationship(
                tx,
                char_id=character.char_id,
                npc_id=npc_id,
                relation_type="parent",
                score=score,
                since_age=0,
            )
        sibling_count = self.rng.randint(0, 3)
        for _ in range(sibling_count):
            gender = self.rng.choice(_NAME_GENDERS)
            age = self.rng.randint(0, 8)
            fields = self._npc_fields(
                character,
                gender=gender,
                age=age,
                wealth_class=character.wealth_class,
                occupation="Student",
                annual_income=0,
            )
            fields["wealth"] = self._wealth(character.wealth_class)
            npc_id = await self._insert_npc(tx, fields)
            await self.repository.create_relationship(
                tx,
                char_id=character.char_id,
                npc_id=npc_id,
                relation_type="sibling",
                score=self.rng.randint(60, 90),
                since_age=0,
            )
        message = f"Family generated: two parents and {sibling_count} sibling(s)."
        await self.repository.insert_life_log(
            tx,
            char_id=character.char_id,
            age=0,
            category="family",
            text=message,
            importance=2,
            created_at=int(self.clock()),
        )
        messages.append(message)
        return tuple(messages)

    async def _active_character(self, tx: aiosqlite.Connection, user_id: int) -> tuple[Character, int]:
        """Load a versioned active life or raise a user-safe life error."""
        row = await self.repository.load_active(tx, user_id)
        if row is None:
            if await self.repository.has_any_life(tx, user_id):
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.char_id = int(row["char_id"])
        character.user_id = int(row["user_id"])
        character.version = int(row["version"])
        if not character.is_alive:
            raise CharacterDead()
        return character, int(row["version"])

    async def _active_character_read(self, user_id: int) -> Character:
        """Load an active character outside a write transaction."""
        row = await self.repository.load_active_read(user_id)
        if row is None:
            if await self.repository.has_any_life_read(user_id):
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.char_id = int(row["char_id"])
        character.user_id = int(row["user_id"])
        character.version = int(row["version"])
        if not character.is_alive:
            raise CharacterDead()
        return character

    def _check_age(self, character: Character, minimum: int, action: str, *, maximum: Optional[int] = None) -> None:
        """Enforce age gates in the domain engine rather than relying on Discord UI."""
        if character.age < minimum:
            raise EducationRequirementError(f"You must be at least {minimum} to {action}.")
        if maximum is not None and character.age > maximum:
            raise EducationRequirementError(f"You must be age {maximum} or younger to {action}.")

    @staticmethod
    def _check_not_imprisoned(character: Character) -> None:
        """Prevent family actions while the character is serving a prison sentence."""
        if character.in_prison:
            raise FamilyRequirementError("You cannot do this while your character is in prison.")

    async def _check_pending_event(self, tx: aiosqlite.Connection, character: Character) -> None:
        """Keep unresolved Stage 3 choices ahead of new family decisions."""
        if await self.repository.has_pending_event(tx, character.char_id):
            raise PendingEventExists()

    async def family(self, user_id: int) -> tuple[Character, list[dict[str, Any]]]:
        """Return the active life and its complete relationship roster."""
        async with self.locks.hold(user_id):
            character = await self._active_character_read(user_id)
            people = await self.repository.list_people(character.char_id)
            return character, people

    async def relationship_list(self, user_id: int) -> tuple[Character, list[dict[str, Any]]]:
        """Return the same relationship roster for the explicit relationship command."""
        return await self.family(user_id)

    async def autocomplete_people(self, user_id: int, query: str) -> list[dict[str, Any]]:
        """Return owned, living NPC relationships matching a short autocomplete query."""
        character = await self._active_character_read(user_id)
        return await self.repository.autocomplete_people(character.char_id, query[:80])

    async def find_dates(self, user_id: int) -> DateSearch:
        """Create exactly three age-eligible, persistent dating candidates."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 16, "start dating")
                romance = await self.repository.active_romance(tx, character.char_id)
                if romance is not None:
                    raise FamilyRequirementError("End your current relationship before searching for dates.")
                candidates: list[dict[str, Any]] = []
                npc_ids: list[int] = []
                for _ in range(3):
                    gender = self.rng.choice(_NAME_GENDERS)
                    if character.age < 18:
                        low, high = max(0, character.age - 2), min(17, character.age + 2)
                    else:
                        low, high = max(18, character.age - 5), min(120, character.age + 5)
                    age = self.rng.randint(low, high)
                    fields = self._npc_fields(character, gender=gender, age=age)
                    npc_id = await self._insert_npc(tx, fields)
                    fields["npc_id"] = npc_id
                    candidates.append(fields)
                    npc_ids.append(npc_id)
                now = int(self.clock())
                nonce = secrets.token_urlsafe(16)
                expires = now + 900
                await self.repository.save_dating_session(tx, character.char_id, nonce, now, expires, npc_ids)
                return DateSearch(nonce, tuple(candidates), expires)

    async def choose_date(self, user_id: int, npc_id: int, nonce: str) -> DateOutcome:
        """Resolve a date select-menu choice, enforcing age and ownership in-engine."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 16, "date")
                candidate = await self.repository.get_dating_candidate(
                    tx, character.char_id, int(npc_id), nonce, int(self.clock())
                )
                if candidate is None:
                    raise DateSessionExpired()
                if not can_date_ages(character.age, int(candidate["age"])):
                    raise FamilyRequirementError("Dating age rules do not allow that match.")
                if await self.repository.active_romance(tx, character.char_id) is not None:
                    raise FamilyRequirementError("You already have an active relationship.")
                stats = character.stats
                chance = dating_success_chance(
                    player_looks=stats.looks,
                    npc_looks=int(candidate["looks"]),
                    player_smarts=stats.smarts,
                    npc_smarts=int(candidate["smarts"]),
                    npc_prefers_smarts=bool(candidate["prefers_smarts"]),
                    fame=stats.fame,
                    npc_wealth=int(candidate["wealth"]),
                )
                accepted = self.rng.random() * 100.0 < chance
                if accepted:
                    await self.repository.create_relationship(
                        tx,
                        char_id=character.char_id,
                        npc_id=int(candidate["npc_id"]),
                        relation_type="partner",
                        score=60,
                        since_age=character.age,
                    )
                await self.repository.consume_dating_session(tx, character.char_id, nonce)
                name = str(candidate["name"])
                await self.repository.insert_life_log(
                    tx,
                    char_id=character.char_id,
                    age=character.age,
                    category="relationship",
                    text=(f"Started dating {name}." if accepted else f"A date with {name} did not turn into a relationship."),
                    importance=2,
                    created_at=int(self.clock()),
                )
                return DateOutcome(dict(candidate), chance, accepted, 60 if accepted else None)

    async def find_friend(self, user_id: int) -> dict[str, Any]:
        """Meet one age-appropriate NPC friend and persist the relationship."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 6, "make new friends")
                if character.age < 18:
                    low, high = max(0, character.age - 2), min(17, character.age + 2)
                else:
                    low, high = max(18, character.age - 5), min(120, character.age + 5)
                age = self.rng.randint(low, high)
                gender = self.rng.choice(_NAME_GENDERS)
                npc_id = await self._insert_npc(
                    tx,
                    self._npc_fields(character, gender=gender, age=age),
                )
                score = self.rng.randint(50, 65)
                await self.repository.create_relationship(
                    tx,
                    char_id=character.char_id,
                    npc_id=npc_id,
                    relation_type="friend",
                    score=score,
                    since_age=character.age,
                )
                person = await self.repository.get_person(tx, character.char_id, npc_id)
                return dict(person or {"npc_id": npc_id, "name": "Friend", "age": age, "relationship_score": score})

    async def interact(self, user_id: int, npc_id: int, action: str, gift_dollars: Optional[int] = None) -> InteractionOutcome:
        """Interact with one connected NPC, enforcing three actions per person/year."""
        selected = str(action).lower()
        allowed = {"spend_time", "gift", "compliment", "argue", "ask_for_money", "insult"}
        if selected not in allowed:
            raise ValidationError("Choose spend_time, gift, compliment, argue, ask_for_money, or insult.")
        if selected == "gift" and (gift_dollars is None or gift_dollars <= 0):
            raise ValidationError("A gift requires a positive amount in whole dollars.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 6, "interact with people")
                person = await self.repository.get_person(tx, character.char_id, int(npc_id))
                if person is None:
                    raise RelationshipNotFound()
                if not bool(person["is_alive"]):
                    raise FamilyRequirementError("You cannot interact with someone who has died.")
                if not await self.repository.claim_interaction(tx, character.char_id, int(npc_id), character.age):
                    raise InteractionLimitReached()

                before = int(person["relationship_score"])
                money_delta = 0
                if selected == "spend_time":
                    delta = self.rng.randint(5, 10)
                    message = f"You spent quality time with {person['name']} (+{delta} relationship)."
                elif selected == "compliment":
                    delta = self.rng.randint(2, 8)
                    message = f"You gave {person['name']} a sincere compliment (+{delta})."
                elif selected == "argue":
                    delta = -self.rng.randint(5, 15)
                    message = f"You argued with {person['name']} ({delta} relationship)."
                elif selected == "insult":
                    delta = -self.rng.randint(10, 25)
                    message = f"You insulted {person['name']} ({delta} relationship)."
                elif selected == "gift":
                    gift_value = dollars_to_cents(gift_dollars or 0)
                    available = character.cash + character.bank
                    if gift_value > available:
                        raise InsufficientFunds("You do not have enough cash or bank balance for that gift.")
                    income = await self.repository.get_annual_job_income(tx, character.char_id)
                    reference = max(income, dollars_to_cents(1_000))
                    ratio = min(1.0, gift_value / reference)
                    delta = max(3, min(15, int(round(3 + 12 * ratio))))
                    character, _ = self._deduct_cash_bank(character, gift_value)
                    character = replace(character, version=expected_version + 1)
                    await self.repository.save_character(tx, character, expected_version)
                    await self.repository.add_npc_wealth(tx, int(npc_id), gift_value)
                    money_delta = -gift_value
                    message = f"You gave {person['name']} a gift worth {gift_dollars:,} dollars (+{delta} relationship)."
                else:
                    if person["relationship_type"] != "parent":
                        raise FamilyRequirementError("Only a parent can be asked for money.")
                    wealth = int(person["wealth"])
                    income_factor = min(25, (wealth // dollars_to_cents(100_000)) * 3)
                    chance = max(5, min(90, int(before * 0.60 + income_factor)))
                    if self.rng.random() * 100 < chance and wealth > 0:
                        amount = min(wealth, dollars_to_cents(self.rng.randint(100, 5_000)))
                        await self.repository.add_npc_wealth(tx, int(npc_id), -amount)
                        character = replace(character, cash=character.cash + amount, version=expected_version + 1)
                        await self.repository.save_character(tx, character, expected_version)
                        money_delta = amount
                        delta = self.rng.randint(1, 4)
                        message = f"{person['name']} agreed to help with {amount // 100:,} dollars."
                    else:
                        delta = -self.rng.randint(1, 3)
                        message = f"{person['name']} could not help with money this time."
                after = max(0, min(100, before + delta))
                await self.repository.set_relationship_score(tx, character.char_id, int(npc_id), after)
                await self.repository.log_relationship_interaction(
                    tx, character.char_id, character.age, message, int(self.clock())
                )
                return InteractionOutcome(str(person["name"]), selected, before, after, message, money_delta)

    async def propose(self, user_id: int, npc_id: int) -> ProposalOutcome:
        """Propose after a year of dating with a score of at least 70."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "propose")
                person = await self.repository.get_person(tx, character.char_id, int(npc_id))
                if person is None or not bool(person["is_alive"]):
                    raise RelationshipNotFound()
                if person["relationship_type"] != "partner" or int(person["relationship_score"]) < 70:
                    raise FamilyRequirementError("You need a living partner with relationship score 70 or higher.")
                if character.age - int(person["relationship_since_age"]) < 1:
                    raise FamilyRequirementError("You must have been dating for at least one in-game year.")
                if int(person["age"]) < 18:
                    raise FamilyRequirementError("Adults may only propose to adults.")
                active = await self.repository.active_romance(tx, character.char_id)
                if active is not None and int(active["npc_id"]) != int(npc_id):
                    raise FamilyRequirementError("End your other active relationship before proposing.")
                rings = await self.repository.list_ring_assets(tx, character.char_id)
                ring = rings[0] if rings else None
                ring_bonus = int(RING_CATALOG.get(str(ring["item_id"]), {}).get("bonus", 0)) if ring else 0
                chance = proposal_acceptance_chance(int(person["relationship_score"]), ring_bonus)
                if ring is not None:
                    await self.repository.consume_ring(tx, int(ring["asset_id"]))
                accepted = self.rng.random() * 100.0 < chance
                if accepted:
                    await self.repository.set_relationship_type(tx, character.char_id, int(npc_id), "fiance")
                    message = f"{person['name']} accepted your proposal!"
                else:
                    message = f"{person['name']} declined the proposal."
                await self.repository.insert_life_log(
                    tx, char_id=character.char_id, age=character.age,
                    category="relationship", text=message, importance=3, created_at=int(self.clock()),
                )
                return ProposalOutcome(str(person["name"]), chance, accepted, ring_bonus)

    async def buy_ring(self, user_id: int, item_id: str) -> tuple[int, int]:
        """Purchase one catalog ring for a future proposal."""
        ring = RING_CATALOG.get(str(item_id))
        if ring is None:
            raise ValidationError("That ring is not sold by the relationship shop.")
        price = int(ring["price"])
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "buy a wedding ring")
                if character.cash + character.bank < price:
                    raise InsufficientFunds("You do not have enough available funds for this ring.")
                updated, _ = self._deduct_cash_bank(character, price)
                updated = replace(updated, version=expected_version + 1)
                await self.repository.save_character(tx, updated, expected_version)
                await self.repository.add_asset(
                    tx, char_id=character.char_id, kind="item", item_id=str(item_id), quantity=1,
                    purchase_price=price, current_value=price, acquired_age=character.age,
                    acquired_at=int(self.clock()),
                )
                return price, int(ring["bonus"])

    async def marry(self, user_id: int, wedding: str = "courthouse", prenup: bool = False) -> MarriageOutcome:
        """Hold a wedding, charge its price-indexed cost, and save optional prenup terms."""
        selected = str(wedding).lower()
        if selected not in WEDDING_TIERS:
            raise ValidationError("Choose courthouse, intimate, traditional, or lavish.")
        if not isinstance(prenup, bool):
            raise ValidationError("Prenup must be true or false.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "get married")
                if await self.repository.get_marriage(tx, character.char_id) is not None:
                    raise FamilyRequirementError("You are already married.")
                person = await self.repository.active_romance(tx, character.char_id)
                if person is None or person["relationship_type"] != "fiance" or not bool(person["is_alive"]):
                    raise FamilyRequirementError("You need a living fiance before you can marry.")
                if int(person["age"]) < 18:
                    raise FamilyRequirementError("Both partners must be adults to marry.")
                label, base_cost = WEDDING_TIERS[selected]
                cost = scale_cents(base_cost, Decimal(str(character.price_index)))
                if character.cash + character.bank < cost:
                    raise InsufficientFunds(f"You need {cost // 100:,} dollars for this wedding.")
                updated, _ = self._deduct_cash_bank(character, cost)
                updated = replace(updated, version=expected_version + 1)
                await self.repository.save_character(tx, updated, expected_version)
                await self.repository.set_relationship_type(tx, character.char_id, int(person["npc_id"]), "spouse")
                await self.repository.create_marriage(
                    tx,
                    char_id=character.char_id,
                    spouse_npc_id=int(person["npc_id"]),
                    start_age=character.age,
                    spouse_income=int(person["annual_income"]),
                    prenup=prenup,
                    premarital_cash=updated.cash,
                    premarital_bank=updated.bank,
                    wedding_cost=cost,
                    created_at=int(self.clock()),
                )
                await self.repository.insert_life_log(
                    tx,
                    char_id=character.char_id,
                    age=character.age,
                    category="relationship",
                    text=f"{character.name} married {person['name']} in a {label.lower()} wedding.",
                    importance=4,
                    created_at=int(self.clock()),
                )
                return MarriageOutcome(str(person["name"]), cost, prenup, int(person["annual_income"]))

    async def divorce(self, user_id: int) -> DivorceOutcome:
        """Atomically divorce, divide eligible assets, roll custody, and record support."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "divorce")
                result, updated = await self._divorce_in_tx(
                    tx, character, expected_version, reason="player", now=int(self.clock()), save_character=True
                )
                return replace(result, character=updated)

    async def _divorce_in_tx(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
        *,
        reason: str,
        now: int,
        save_character: bool,
    ) -> tuple[DivorceOutcome, Character]:
        """Perform every divorce write in the caller's existing transaction."""
        marriage = await self.repository.get_marriage(tx, character.char_id)
        if marriage is None:
            raise NoActiveMarriage()
        spouse = await self.repository.get_person(tx, character.char_id, int(marriage["spouse_npc_id"]))
        if spouse is None:
            raise FamilyRequirementError("Your spouse record is unavailable.")
        marriage_years = max(0, character.age - int(marriage["start_age"]))
        player_income = await self.repository.get_annual_job_income(tx, character.char_id)
        spouse_income = int(spouse["annual_income"])
        player_pays_alimony, alimony_annual, alimony_years = calculate_alimony(
            player_income, spouse_income, marriage_years
        )
        updated = character

        # Liquidate marital stocks into bank cash before calculating the split.
        stock_total = await self.repository.liquidate_stock_assets(
            tx, character.char_id, int(marriage["created_at"])
        )
        updated = replace(updated, bank=updated.bank + stock_total)
        item_assets = await self.repository.get_marital_assets(
            tx, character.char_id, int(marriage["created_at"])
        )
        item_values = [int(asset["current_value"]) for asset in item_assets if asset["kind"] == "item"]
        split = calculate_divorce_split(
            cash=updated.cash,
            bank=updated.bank,
            marital_item_values=item_values,
            prenup=bool(marriage["prenup"]),
            premarital_cash=int(marriage["premarital_cash"]),
            premarital_bank=int(marriage["premarital_bank"]),
        )
        protected_cash = int(marriage["premarital_cash"]) if bool(marriage["prenup"]) else 0
        protected_bank = int(marriage["premarital_bank"]) if bool(marriage["prenup"]) else 0
        updated, _ = await self._pay_divorce_assets(
            tx,
            updated,
            split.spouse_share,
            marriage_timestamp=int(marriage["created_at"]),
            protect_cash=protected_cash,
            protect_bank=protected_bank,
            marital_only=True,
        )
        await self.repository.add_npc_wealth(tx, int(spouse["npc_id"]), split.spouse_share)

        lawyer_fee = self.rng.randint(dollars_to_cents(5_000), dollars_to_cents(50_000))
        updated, _ = await self._pay_divorce_assets(
            tx,
            updated,
            lawyer_fee,
            marriage_timestamp=int(marriage["created_at"]),
            marital_only=False,
        )

        children = await self.repository.get_children(tx, character.char_id)
        support_amount = int((Decimal(player_income) * Decimal("0.15")).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        for child in children:
            if not bool(child["is_alive"]) or int(child["age"]) >= 18:
                await self.repository.update_child_support(tx, int(child["npc_id"]), 0)
                continue
            custody = self._roll_custody(character, player_income)
            child_support = support_amount if custody != "full" else 0
            await self.repository.update_custody_and_support(
                tx, int(child["npc_id"]), custody, child_support
            )
        if alimony_annual > 0 and alimony_years > 0:
            await self.repository.create_alimony(
                tx,
                character.char_id,
                int(spouse["npc_id"]),
                alimony_annual,
                alimony_years,
                player_pays_alimony,
            )
        await self.repository.set_relationship_type(tx, character.char_id, int(spouse["npc_id"]), "ex")
        await self.repository.set_relationship_score(
            tx, character.char_id, int(spouse["npc_id"]), max(0, int(spouse.get("relationship_score", 50)) - 30)
        )
        await self.repository.delete_marriage(tx, character.char_id)
        await self.repository.delete_affair(tx, character.char_id)
        stats = replace(character.stats)
        stats.happiness = max(0, stats.happiness - 25)
        updated = replace(updated, stats=stats, version=expected_version + 1)
        if save_character:
            await self.repository.save_character(tx, updated, expected_version)
        await self.repository.increment_divorces(tx, character.char_id)
        await self.repository.insert_divorce_record(
            tx,
            char_id=character.char_id,
            spouse_npc_id=int(spouse["npc_id"]),
            age=character.age,
            prenup=bool(marriage["prenup"]),
            marital_assets=split.eligible_assets,
            spouse_share=split.spouse_share,
            lawyer_fee=lawyer_fee,
            reason=reason,
            created_at=now,
        )
        message = (
            f"Divorced {spouse['name']}. The spouse's share was {split.spouse_share // 100:,} dollars; "
            f"lawyer fees were {lawyer_fee // 100:,} dollars."
        )
        await self.repository.insert_life_log(
            tx,
            char_id=character.char_id,
            age=character.age,
            category="relationship",
            text=message,
            importance=4,
            created_at=now,
        )
        return (
            DivorceOutcome(
                updated,
                str(spouse["name"]),
                split.eligible_assets,
                split.spouse_share,
                lawyer_fee,
                sum(1 for child in children if bool(child["is_alive"]) and int(child["age"]) < 18),
                alimony_annual,
                alimony_years,
                message,
            ),
            updated,
        )

    async def breakup(self, user_id: int, npc_id: int) -> str:
        """End a dating or engagement relationship without legal divorce."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 16, "end a relationship")
                person = await self.repository.get_person(tx, character.char_id, int(npc_id))
                if (
                    person is None
                    or not bool(person["is_alive"])
                    or person["relationship_type"] not in {"partner", "fiance"}
                ):
                    raise FamilyRequirementError("You can only break up with a living partner or fiance.")
                await self.repository.set_relationship_type(tx, character.char_id, int(npc_id), "ex")
                await self.repository.add_relationship_score(tx, character.char_id, int(npc_id), -20)
                await self.repository.insert_life_log(
                    tx, char_id=character.char_id, age=character.age, category="relationship",
                    text=f"Ended the relationship with {person['name']}.", importance=3, created_at=int(self.clock()),
                )
                return f"You and {person['name']} have broken up."

    async def try_for_baby(self, user_id: int) -> tuple[bool, float]:
        """Try to conceive with a current partner or spouse using age-based fertility."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "try for a baby")
                partner = await self.repository.active_romance(tx, character.char_id)
                if (
                    partner is None
                    or partner["relationship_type"] not in {"partner", "spouse"}
                    or not bool(partner["is_alive"])
                ):
                    raise FamilyRequirementError("You need a living partner or spouse to try for a baby.")
                if int(partner["age"]) < 18:
                    raise FamilyRequirementError("Both partners must be adults to try for a baby.")
                if await self.repository.get_pregnancy(tx, character.char_id) is not None:
                    raise FamilyRequirementError("A pregnancy is already in progress.")
                if await self.repository.get_adoption(tx, character.char_id) is not None:
                    raise FamilyRequirementError("An adoption is already in progress.")
                if not await self.repository.claim_yearly_action(
                    tx, character.char_id, int(partner["npc_id"]), character.age, "try_for_baby"
                ):
                    raise FamilyRequirementError("You can try for a baby with this partner once per year.")
                probability = self._couple_fertility(character, partner)
                success = self.rng.random() < probability
                if success:
                    await self.repository.add_pregnancy(
                        tx,
                        char_id=character.char_id,
                        other_parent_npc_id=int(partner["npc_id"]),
                        conception_age=character.age,
                        due_age=character.age + 1,
                        accidental=False,
                    )
                    message = f"A pregnancy is underway with {partner['name']}; the baby is due after one year."
                else:
                    message = "There was no pregnancy this year. You can try again next year."
                await self.repository.insert_life_log(
                    tx, char_id=character.char_id, age=character.age, category="family",
                    text=message, importance=3, created_at=int(self.clock()),
                )
                return success, probability

    @staticmethod
    def _couple_fertility(character: Character, partner: dict[str, Any]) -> float:
        """Combine the gestational partner curve and the other partner's factor."""
        try:
            partner_gender = Gender(str(partner["gender"]))
        except ValueError:
            partner_gender = Gender.NON_BINARY
        if character.gender is Gender.FEMALE:
            female_age = character.age
            male_age = int(partner["age"]) if partner_gender is Gender.MALE else 30
        elif partner_gender is Gender.FEMALE:
            female_age = int(partner["age"])
            male_age = character.age
        else:
            return 0.0
        return 0.35 * calculate_fertility_factor(female_age) * calculate_male_fertility_factor(male_age)

    async def adopt(self, user_id: int) -> int:
        """Pay the indexed adoption cost and schedule an infant after one age tick."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 21, "adopt a child")
                if await self.repository.get_adoption(tx, character.char_id) is not None:
                    raise FamilyRequirementError("An adoption is already in progress.")
                if await self.repository.get_pregnancy(tx, character.char_id) is not None:
                    raise FamilyRequirementError("Resolve the current pregnancy before starting an adoption.")
                cost = scale_cents(dollars_to_cents(30_000), Decimal(str(character.price_index)))
                if character.cash + character.bank < cost:
                    raise InsufficientFunds("You need enough cash or bank balance to cover the adoption cost.")
                updated, _ = self._deduct_cash_bank(character, cost)
                updated = replace(updated, version=expected_version + 1)
                await self.repository.save_character(tx, updated, expected_version)
                await self.repository.add_adoption(tx, character.char_id, character.age, character.age + 1, cost)
                await self.repository.insert_life_log(
                    tx, char_id=character.char_id, age=character.age, category="family",
                    text=f"Started an adoption; the child will join the family after one year. Cost: {cost // 100:,} dollars.",
                    importance=3, created_at=int(self.clock()),
                )
                return cost

    async def buy_ring_options(self) -> tuple[dict[str, Any], ...]:
        """Return immutable view data for the ring shop."""
        return tuple({"id": item_id, **values} for item_id, values in RING_CATALOG.items())

    async def start_infidelity_choice(self, user_id: int) -> InfidelityPrompt:
        """Create a one-use choice prompt for a married character's temptation event."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "consider an affair")
                marriage = await self.repository.get_marriage(tx, character.char_id)
                if marriage is None:
                    raise NoActiveMarriage()
                if await self.repository.has_infidelity_choice(tx, character.char_id, character.age):
                    raise FamilyRequirementError("The relationship choice for this in-game year has already been resolved.")
                spouse = await self.repository.get_npc_owned(tx, character.char_id, int(marriage["spouse_npc_id"]))
                if spouse is None or not bool(spouse["is_alive"]):
                    raise FamilyRequirementError("There is no living spouse to betray.")
                nonce = secrets.token_urlsafe(16)
                now = int(self.clock())
                await self.repository.create_infidelity_prompt(
                    tx, character.char_id, int(spouse["npc_id"]), nonce, now, now + 300
                )
                return InfidelityPrompt(nonce, str(spouse["name"]), now + 300)

    async def resolve_infidelity_choice(self, user_id: int, nonce: str, cheat: bool) -> str:
        """Resolve a nonce-protected temptation choice and record an affair if chosen."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "resolve a relationship choice")
                prompt = await self.repository.get_infidelity_prompt(
                    tx, character.char_id, nonce, int(self.clock())
                )
                if prompt is None:
                    raise DateSessionExpired("This relationship choice expired. Start a new one with `/relationship temptation`.")
                marriage = await self.repository.get_marriage(tx, character.char_id)
                if marriage is None or int(marriage["spouse_npc_id"]) != int(prompt["spouse_npc_id"]):
                    raise FamilyRequirementError("The marriage ended before this choice was resolved.")
                now = int(self.clock())
                await self.repository.record_infidelity_choice(
                    tx,
                    character.char_id,
                    int(prompt["spouse_npc_id"]),
                    character.age,
                    "cheat" if cheat else "faithful",
                    now,
                )
                if cheat:
                    await self.repository.save_affair(
                        tx, character.char_id, int(prompt["spouse_npc_id"]), character.age, nonce
                    )
                    message = "You chose to cheat. There is a 35% chance of discovery each year."
                else:
                    message = "You stayed faithful and ended the temptation."
                await self.repository.delete_infidelity_prompt(tx, character.char_id, nonce)
                await self.repository.insert_life_log(
                    tx, char_id=character.char_id, age=character.age, category="relationship",
                    text=message, importance=3, created_at=now,
                )
                return message

    async def _create_child(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        other_parent_npc_id: Optional[int],
        *,
        adopted: bool,
    ) -> tuple[int, str]:
        """Create a child NPC with parent-average traits and a full-custody record."""
        other_parent = None
        if other_parent_npc_id is not None:
            other_parent = await self.repository.get_npc_owned(tx, character.char_id, other_parent_npc_id)
        if adopted or other_parent is None:
            means = (50.0, 50.0, 75.0)
        else:
            means = (
                (character.stats.looks + int(other_parent["looks"])) / 2,
                (character.stats.smarts + int(other_parent["smarts"])) / 2,
                (character.stats.health + int(other_parent["health"])) / 2,
            )
        gender = self.rng.choice(_NAME_GENDERS)
        fields = self._npc_fields(
            character,
            gender=gender,
            age=0,
            wealth_class="poor",
            occupation="Student",
            annual_income=0,
            means=means,
        )
        fields["wealth"] = 0
        npc_id = await self._insert_npc(tx, fields)
        score = self.rng.randint(80, 95)
        await self.repository.create_relationship(
            tx, char_id=character.char_id, npc_id=npc_id, relation_type="child", score=score, since_age=character.age
        )
        await self.repository.add_child(
            tx,
            npc_id=npc_id,
            char_id=character.char_id,
            other_parent_npc_id=other_parent_npc_id,
            custody="full",
            child_support=0,
        )
        return npc_id, str(fields["name"])

    async def advance_year(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        previous_age: int,
        personal_income: int,
        now: int,
    ) -> FamilyYearResult:
        """Settle family expenses/support and execute Stage 6 yearly step 11.

        This runs in the same BEGIN IMMEDIATE transaction as ``/life age``. It
        pays spouse wages/tax, child costs/support and alimony, completes adoptions
        and pregnancies, checks infidelity/divorce, then decays relationships and
        ages all NPCs. Stage 1-5 RNG is not consumed; this service owns a forked RNG.
        """
        updated = character
        messages: list[str] = []
        newborn_npc_ids: set[int] = set()
        marriage = await self.repository.get_marriage(tx, character.char_id)
        if marriage is not None:
            spouse = await self.repository.get_npc_owned(tx, character.char_id, int(marriage["spouse_npc_id"]))
            if spouse is not None and bool(spouse["is_alive"]):
                spouse_income = int(spouse["annual_income"])
                joint_tax = calculate_joint_tax(max(0, personal_income) + spouse_income)
                updated = replace(updated, cash=updated.cash + spouse_income)
                updated, tax_unpaid = self._deduct_cash_bank(updated, joint_tax)
                if tax_unpaid:
                    updated = replace(updated, debt_total=updated.debt_total + tax_unpaid)
                messages.append(
                    f"Household income included {spouse_income // 100:,} dollars from {spouse['name']}; joint tax was {joint_tax // 100:,} dollars."
                )
            else:
                await self.repository.set_relationship_type(
                    tx, character.char_id, int(marriage["spouse_npc_id"]), "ex"
                )
                await self.repository.delete_marriage(tx, character.char_id)
                messages.append("The marriage ended after your spouse's death.")

        children = await self.repository.get_children(tx, character.char_id)
        for child in children:
            child_age = int(child["age"]) + (1 if bool(child["is_alive"]) else 0)
            custody = str(child["custody"])
            minor_alive = bool(child["is_alive"]) and child_age < 18
            if minor_alive and custody in {"full", "shared"}:
                cost = scale_cents(
                    dollars_to_cents(12_000),
                    Decimal(str(character.price_index))
                    * Decimal(str(_COST_OF_LIVING.get(character.wealth_class, 1.0)))
                    * (Decimal("0.5") if custody == "shared" else Decimal("1")),
                )
                updated, unpaid = self._deduct_cash_bank(updated, cost)
                if unpaid:
                    updated = replace(updated, debt_total=updated.debt_total + unpaid)
                messages.append(f"Child care cost for {child['name']}: {cost // 100:,} dollars.")
            if minor_alive and custody != "full":
                support = int((Decimal(max(0, personal_income)) * Decimal("0.15")).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
                await self.repository.update_child_support(tx, int(child["npc_id"]), support)
                updated, unpaid = self._deduct_cash_bank(updated, support)
                if unpaid:
                    updated = replace(updated, debt_total=updated.debt_total + unpaid)
                if support and child["other_parent_npc_id"] is not None:
                    await self.repository.add_npc_wealth(tx, int(child["other_parent_npc_id"]), support)
                if support:
                    messages.append(f"Child support paid for {child['name']}: {support // 100:,} dollars.")
            elif (child_age >= 18 or not bool(child["is_alive"])) and int(child["child_support"]) > 0:
                await self.repository.update_child_support(tx, int(child["npc_id"]), 0)
                if bool(child["is_alive"]):
                    messages.append(f"Child support ended for {child['name']} at age 18.")
                else:
                    messages.append(f"Child support ended for {child['name']} after their death.")

        alimony = await self.repository.get_alimony(tx, character.char_id)
        if alimony is not None:
            fraction = min(1.0, float(alimony["remaining_years"]))
            amount = int((Decimal(int(alimony["annual_amount"])) * Decimal(str(fraction))).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
            if bool(alimony["payer_is_player"]):
                updated, unpaid = self._deduct_cash_bank(updated, amount)
                if unpaid:
                    updated = replace(updated, debt_total=updated.debt_total + unpaid)
                if amount:
                    await self.repository.add_npc_wealth(tx, int(alimony["ex_npc_id"]), amount)
                    messages.append(f"Alimony paid: {amount // 100:,} dollars.")
            else:
                updated = replace(updated, cash=updated.cash + amount)
                await self.repository.add_npc_wealth(tx, int(alimony["ex_npc_id"]), -amount)
                if amount:
                    messages.append(f"Alimony received: {amount // 100:,} dollars.")
            await self.repository.update_alimony(
                tx, character.char_id, max(0.0, float(alimony["remaining_years"]) - 1.0)
            )

        pregnancy = await self.repository.get_pregnancy(tx, character.char_id)
        if pregnancy is not None and int(pregnancy["due_age"]) <= character.age:
            newborn_id, child_name = await self._create_child(
                tx, character, pregnancy["other_parent_npc_id"], adopted=False
            )
            newborn_npc_ids.add(newborn_id)
            await self.repository.delete_pregnancy(tx, character.char_id)
            messages.append(f"{child_name} joined the family.")

        adoption = await self.repository.get_adoption(tx, character.char_id)
        if adoption is not None and int(adoption["due_age"]) <= character.age:
            newborn_id, child_name = await self._create_child(tx, character, None, adopted=True)
            newborn_npc_ids.add(newborn_id)
            await self.repository.delete_adoption(tx, character.char_id)
            messages.append(f"The adoption was finalized: {child_name} joined the family.")

        if marriage is not None:
            affair = await self.repository.get_affair(tx, character.char_id)
            if affair is not None and int(affair["started_age"]) < character.age:
                if self.rng.random() < 0.35:
                    await self.repository.add_relationship_score(
                        tx, character.char_id, int(affair["spouse_npc_id"]), -40
                    )
                    await self.repository.delete_affair(tx, character.char_id)
                    messages.append("Your infidelity was discovered; your spouse's relationship score fell by 40.")
                    if self.rng.random() < 0.60:
                        expected = character.version
                        divorce, updated = await self._divorce_in_tx(
                            tx, updated, expected, reason="discovery", now=now, save_character=False
                        )
                        messages.append(divorce.message)

            # Below-20 spouse relationship scores can trigger an NPC-initiated divorce.
            current_marriage = await self.repository.get_marriage(tx, character.char_id)
            if current_marriage is not None:
                spouse_relation = await self.repository.get_person(
                    tx, character.char_id, int(current_marriage["spouse_npc_id"])
                )
                if spouse_relation is not None:
                    low_years = int(current_marriage.get("low_score_years", 0))
                    if int(spouse_relation["relationship_score"]) < 20:
                        low_years += 1
                    else:
                        low_years = 0
                    await self.repository.update_marriage_low_score_years(tx, character.char_id, low_years)
                    if low_years >= 2 and self.rng.random() < 0.50:
                        divorce, updated = await self._divorce_in_tx(
                            tx, updated, character.version, reason="npc_initiated", now=now, save_character=False
                        )
                        messages.append(divorce.message)

        # Accidentally conceived pregnancies are permitted while an adult is partnered.
        active = await self.repository.active_romance(tx, character.char_id)
        if (
            character.is_alive
            and character.age >= 18
            and active is not None
            and bool(active["is_alive"])
            and await self.repository.get_pregnancy(tx, character.char_id) is None
            and await self.repository.get_adoption(tx, character.char_id) is None
        ):
            fertility = self._couple_fertility(character, active)
            if fertility > 0 and self.rng.random() < 0.02 * fertility:
                await self.repository.add_pregnancy(
                    tx,
                    char_id=character.char_id,
                    other_parent_npc_id=int(active["npc_id"]),
                    conception_age=character.age,
                    due_age=character.age + 1,
                    accidental=True,
                )
                messages.append("An unexpected pregnancy began; the baby is due after one year.")

        # Step 11: decay scores for unattended connections, then age and roll NPC mortality.
        await self.repository.decay_relationships(tx, character.char_id, previous_age)
        npc_rows = await self.repository.list_live_npcs(tx, character.char_id)
        for npc in npc_rows:
            if int(npc["npc_id"]) in newborn_npc_ids:
                continue
            next_age = min(120, int(npc["age"]) + 1)
            risk = self._npc_death_chance(next_age, int(npc["health"]))
            alive = next_age < 120 and self.rng.random() >= risk
            await self.repository.update_npc_year(tx, int(npc["npc_id"]), next_age, alive=alive)
            if not alive:
                updated = await self._on_npc_death(tx, updated, npc, next_age, now, messages)

        romance = await self.repository.active_romance(tx, character.char_id)
        if (
            romance is not None
            and romance["relationship_type"] in {"partner", "fiance"}
            and not can_date_ages(character.age, int(romance["age"]))
        ):
            await self.repository.set_relationship_type(
                tx, character.char_id, int(romance["npc_id"]), "ex"
            )
            messages.append(f"The relationship with {romance['name']} ended as your ages no longer met dating rules.")
        updated = await self._family_events(tx, updated, messages)
        return FamilyYearResult(updated, tuple(messages))

    @staticmethod
    def _npc_death_chance(age: int, health: int) -> float:
        """Return an age- and health-sensitive annual NPC death probability."""
        if age >= 120:
            return 1.0
        age_risk = 0.0005 + max(0, age - 60) * 0.0015
        health_risk = max(0, 50 - health) * 0.0015
        if age < 18:
            age_risk *= 0.15
        return min(0.65, age_risk + health_risk)

    async def _on_npc_death(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        npc: dict[str, Any],
        death_age: int,
        now: int,
        messages: list[str],
    ) -> Character:
        """Apply grief, inheritance, or relationship changes after NPC death."""
        person = await self.repository.get_person(tx, character.char_id, int(npc["npc_id"]))
        if person is None:
            messages.append(f"{npc['name']} died at age {death_age}.")
            return character
        relation = str(person["relationship_type"])
        if relation == "parent":
            grief = self.rng.randint(15, 30)
            stats = replace(character.stats)
            stats.happiness = max(0, stats.happiness - grief)
            sibling_count = await self.repository.count_siblings(tx, character.char_id) + 1
            gross = int(npc["wealth"]) // sibling_count
            threshold = scale_cents(dollars_to_cents(1_000_000), Decimal(str(character.price_index)))
            tax = int(
                (Decimal(max(0, gross - threshold)) * Decimal("0.10"))
                .quantize(Decimal("1"), rounding=ROUND_HALF_UP)
            )
            inheritance = max(0, gross - tax)
            await self.repository.set_npc_wealth(tx, int(npc["npc_id"]), 0)
            messages.append(
                f"{npc['name']} died. Grief reduced happiness by {grief}; inheritance after tax was {inheritance // 100:,} dollars."
            )
            return replace(character, stats=stats, bank=character.bank + inheritance)
        if relation == "spouse":
            marriage = await self.repository.get_marriage(tx, character.char_id)
            if marriage is not None and int(marriage["spouse_npc_id"]) == int(npc["npc_id"]):
                await self.repository.delete_marriage(tx, character.char_id)
                await self.repository.delete_affair(tx, character.char_id)
                await self.repository.set_relationship_type(tx, character.char_id, int(npc["npc_id"]), "ex")
                messages.append(f"Your spouse {npc['name']} died; the marriage ended.")
                return character
        if relation in {"partner", "fiance"}:
            await self.repository.set_relationship_type(tx, character.char_id, int(npc["npc_id"]), "ex")
        messages.append(f"{npc['name']} ({relation}) died at age {death_age}.")
        return character

    async def _family_events(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        messages: list[str],
    ) -> Character:
        """Roll family reunion, sibling-rivalry, adult-child, and elder-care events."""
        updated = character
        siblings = [
            row for row in await self.repository.people_by_type(tx, character.char_id, ("sibling",))
            if bool(row["is_alive"])
        ]
        family = [
            row for row in await self.repository.people_by_type(tx, character.char_id, ("parent", "sibling"))
            if bool(row["is_alive"])
        ]
        if siblings and self.rng.random() < 0.04:
            sibling = self.rng.choice(siblings)
            delta = self.rng.randint(3, 10)
            await self.repository.add_relationship_score(tx, character.char_id, int(sibling["npc_id"]), -delta)
            messages.append(f"A bout of sibling rivalry strained things with {sibling['name']} (-{delta}).")
        elif family and self.rng.random() < 0.03:
            relative = self.rng.choice(family)
            delta = self.rng.randint(3, 8)
            await self.repository.add_relationship_score(tx, character.char_id, int(relative["npc_id"]), delta)
            stats = replace(updated.stats)
            stats.happiness = min(100, stats.happiness + 2)
            updated = replace(updated, stats=stats)
            messages.append(f"A family reunion brought {relative['name']} closer (+{delta}); happiness +2.")
        children = await self.repository.get_children(tx, character.char_id)
        adult_children = [child for child in children if int(child["age"]) >= 18 and bool(child["is_alive"])]
        if adult_children and character.age >= 60 and self.rng.random() < 0.05:
            child = self.rng.choice(adult_children)
            gift = dollars_to_cents(self.rng.randint(100, 2_000))
            updated = replace(updated, cash=updated.cash + gift)
            messages.append(f"Your adult child {child['name']} helped with {gift // 100:,} dollars.")
        elif adult_children and self.rng.random() < 0.03:
            child = self.rng.choice(adult_children)
            amount = dollars_to_cents(self.rng.randint(100, 1_000))
            updated, unpaid = self._deduct_cash_bank(updated, amount)
            if unpaid:
                updated = replace(updated, debt_total=updated.debt_total + unpaid)
            messages.append(f"Your adult child {child['name']} asked for {amount // 100:,} dollars.")
        parents = await self.repository.parent_relations(tx, character.char_id)
        elderly = [parent for parent in parents if bool(parent["is_alive"]) and int(parent["age"]) >= 75]
        if elderly and self.rng.random() < 0.03:
            parent = self.rng.choice(elderly)
            care_cost = dollars_to_cents(self.rng.randint(250, 2_500))
            updated, unpaid = self._deduct_cash_bank(updated, care_cost)
            if unpaid:
                updated = replace(updated, debt_total=updated.debt_total + unpaid)
            messages.append(f"Your elderly parent {parent['name']} needed care costing {care_cost // 100:,} dollars.")
        return updated

    def _roll_custody(self, character: Character, annual_income: int) -> str:
        """Choose full/shared/none custody using karma, income, and criminal history."""
        income_factor = min(20, max(0, int(annual_income // dollars_to_cents(10_000))))
        criminal_penalty = min(35, max(0, int(character.criminal_record)) * 5)
        full = max(5, 60 + (character.stats.karma - 50) // 2 + income_factor - criminal_penalty)
        shared = max(5, 30 + criminal_penalty // 2)
        none = max(5, 10 + criminal_penalty - income_factor)
        return self.rng.weighted_choice(("full", "shared", "none"), (full, shared, none))

    @staticmethod
    def _deduct_cash_bank(character: Character, amount: int) -> tuple[Character, int]:
        """Deduct integer cents from cash then bank without allowing negatives."""
        amount = max(0, int(amount))
        cash_paid = min(max(0, character.cash), amount)
        remaining = amount - cash_paid
        bank_paid = min(max(0, character.bank), remaining)
        unpaid = remaining - bank_paid
        return replace(
            character,
            cash=max(0, character.cash - cash_paid),
            bank=max(0, character.bank - bank_paid),
        ), unpaid

    async def _pay_divorce_assets(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        amount: int,
        *,
        marriage_timestamp: int,
        protect_cash: int = 0,
        protect_bank: int = 0,
        marital_only: bool,
    ) -> tuple[Character, int]:
        """Pay a divorce settlement by liquid cash, then assets, then recorded debt."""
        if marital_only:
            updated, remaining = self._pay_from_liquid_assets(
                character, amount, protected_cash=protect_cash, protected_bank=protect_bank
            )
            assets = await self.repository.get_marital_assets(
                tx, character.char_id, marriage_timestamp
            )
        else:
            updated, remaining = self._deduct_cash_bank(character, amount)
            assets = await self.repository.get_all_assets(tx, character.char_id)
        for asset in assets:
            if remaining <= 0:
                break
            used = await self.repository.reduce_asset(tx, int(asset["asset_id"]), remaining)
            remaining -= used
        if remaining > 0:
            updated = replace(updated, debt_total=updated.debt_total + remaining)
        return updated, remaining

    @staticmethod
    def _pay_from_liquid_assets(
        character: Character,
        amount: int,
        *,
        protected_cash: int = 0,
        protected_bank: int = 0,
    ) -> tuple[Character, int]:
        """Pay only from available cash/bank above prenup-protected baselines."""
        amount = max(0, int(amount))
        available_cash = max(0, character.cash - protected_cash)
        cash_paid = min(available_cash, amount)
        remaining = amount - cash_paid
        available_bank = max(0, character.bank - protected_bank)
        bank_paid = min(available_bank, remaining)
        remaining -= bank_paid
        return replace(
            character,
            cash=max(0, character.cash - cash_paid),
            bank=max(0, character.bank - bank_paid),
        ), remaining

    async def _settle_player_payment(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        amount: int,
        *,
        allow_assets: bool = False,
    ) -> tuple[Character, int]:
        """Pay a household expense, optionally liquidating all player assets."""
        updated, unpaid = self._deduct_cash_bank(character, amount)
        if allow_assets and unpaid:
            for asset in await self.repository.get_all_assets(tx, character.char_id):
                if unpaid <= 0:
                    break
                used = await self.repository.reduce_asset(tx, int(asset["asset_id"]), unpaid)
                unpaid -= used
        if unpaid:
            updated = replace(updated, debt_total=updated.debt_total + unpaid)
        return updated, unpaid
```

## `lifeline/core/life_engine.py`

```py
"""Birth creation, stat rolls, and one-year life simulation."""
from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass, replace
from typing import Any, Callable, Optional

import aiosqlite

from .careers import CareerService
from .config import GameBalance
from .education import advance_school_year
from .family import FamilyService
from .errors import (
    CharacterAlreadyExists,
    CharacterDead,
    CharacterNotFound,
    ConcurrentUpdate,
    PendingEventExists,
    ValidationError,
)
from .events import EventEngine, EventPrompt
from .locks import UserLockRegistry
from .models import Character, Gender, HiddenTraits, LifeStage, Stats
from .rng import RNG

logger = logging.getLogger("lifeline.life")
_NAME_RE = re.compile(r"[^\x00-\x1f\x7f]+")


@dataclass(frozen=True, slots=True)
class YearOutcome:
    """Result of applying one simulated year to a character."""

    character: Character
    previous_age: int
    new_age: int
    died: bool
    death_cause: Optional[str]
    stat_changes: dict[str, int]
    previous_stage: LifeStage
    new_stage: LifeStage
    log_messages: tuple[str, ...]
    pending_event: Optional[EventPrompt] = None


def _clamp_stat(value: int | float) -> int:
    return max(GameBalance.STAT_MIN, min(GameBalance.STAT_MAX, int(round(value))))


def _random_stat(rng: RNG, mean: float, stddev: float) -> int:
    return _clamp_stat(rng.gauss(mean, stddev))


def roll_birth_attributes(rng: RNG) -> tuple[Stats, HiddenTraits, str]:
    """Roll reproducible starting stats, hidden traits, and household wealth class."""
    hidden = HiddenTraits(
        genetic_health_mod=rng.randint(-10, 10),
        lifespan_mod=rng.randint(*GameBalance.LIFESPAN_MOD_RANGE),
        luck=rng.randint(-5, 5),
        temperament=rng.weighted_choice(
            ("calm", "neutral", "volatile"),
            (0.25, 0.55, 0.20),
        ),
    )
    wealth_class = rng.weighted_choice(
        tuple(GameBalance.WEALTH_CLASSES),
        tuple(GameBalance.WEALTH_CLASSES.values()),
    )
    stats = Stats(
        health=_clamp_stat(
            _random_stat(rng, GameBalance.HEALTH_INIT_MEAN, GameBalance.HEALTH_INIT_STDDEV)
            + hidden.genetic_health_mod
        ),
        happiness=_random_stat(rng, GameBalance.HAPPINESS_INIT_MEAN, GameBalance.HAPPINESS_INIT_STDDEV),
        smarts=_random_stat(rng, GameBalance.SMARTS_INIT_MEAN, GameBalance.SMARTS_INIT_STDDEV),
        looks=_random_stat(rng, GameBalance.LOOKS_INIT_MEAN, GameBalance.LOOKS_INIT_STDDEV),
        fitness=_random_stat(rng, GameBalance.FITNESS_INIT_MEAN, GameBalance.FITNESS_INIT_STDDEV),
        karma=_clamp_stat(50 + rng.randint(-10, 10)),
        stress=GameBalance.BASE_STRESS,
        addiction=0,
        fame=0,
        credit_score=None,
    ).clamp_all()
    return stats, hidden, wealth_class


def simulate_year(character: Character, rng: RNG, *, now: Optional[int] = None) -> YearOutcome:
    """Purely calculate one year's aging effects without writing to a database.

    Each call advances exactly one year. Stats remain within 0–100 and a character
    is guaranteed to die no later than ``GameBalance.MAX_AGE``.
    """
    if not character.is_alive:
        raise CharacterDead()
    if character.age < 0:
        raise ValidationError("Character age cannot be negative.")
    if character.age >= GameBalance.MAX_AGE:
        raise CharacterDead("This life has reached the maximum age and has ended.")

    old_age = character.age
    new_age = old_age + 1
    old_stage = character.life_stage
    stats = replace(character.stats)
    before = stats.to_dict()

    # Health varies slightly year to year; age and inherited resilience shape the drift.
    health_delta = rng.randint(-1, 1)
    if new_age >= 50:
        health_delta -= 1
    if new_age >= 70:
        health_delta -= 1
    if character.hidden.genetic_health_mod >= 7 and new_age < 70:
        health_delta += 1
    elif character.hidden.genetic_health_mod <= -7:
        health_delta -= 1
    stats.health = _clamp_stat(stats.health + health_delta)

    # Happiness trends gently toward the game's neutral point; stress recovers naturally.
    target = GameBalance.HAPPINESS_DRIFT_TARGET
    if stats.happiness < target:
        stats.happiness += GameBalance.HAPPINESS_DRIFT_RATE
    elif stats.happiness > target:
        stats.happiness -= GameBalance.HAPPINESS_DRIFT_RATE
    stats.stress = max(0, stats.stress - GameBalance.STRESS_DECAY_PER_YEAR)

    # Childhood and young adulthood build learning and fitness; aging slowly reduces fitness.
    if 6 <= new_age <= 29 and rng.random() < 0.55:
        stats.smarts += 1
    if new_age <= 25 and rng.random() < 0.35:
        stats.fitness += 1
    elif new_age >= 40:
        stats.fitness -= 1
    if new_age >= 70:
        stats.fitness -= 1
    if new_age >= 35 and new_age % 5 == 0:
        stats.looks -= 1

    stats = stats.clamp_all()
    death_cause: Optional[str] = None

    # A low-health character is at higher risk. The hazard rises after expected lifespan.
    expected_lifespan = (
        GameBalance.BASE_LIFESPAN_MEAN
        + character.hidden.lifespan_mod
        + round(character.hidden.genetic_health_mod * 0.25)
    )
    age_hazard = 0.001 + max(0, new_age - 55) * 0.00035
    lifespan_hazard = max(0, new_age - expected_lifespan) * 0.018
    health_multiplier = max(0.55, min(1.8, 1.0 + (50 - stats.health) * 0.012))
    mortality_chance = min(0.95, (age_hazard + lifespan_hazard) * health_multiplier)
    if stats.health <= 0:
        death_cause = "illness"
    elif new_age >= GameBalance.MAX_AGE or rng.random() < mortality_chance:
        death_cause = "natural causes"

    timestamp = int(time.time()) if now is None else int(now)
    updated = replace(
        character,
        age=new_age,
        stats=stats,
        is_alive=death_cause is None,
        died_at=timestamp if death_cause else None,
        death_cause=death_cause,
        death_age=new_age if death_cause else None,
        last_age_at=timestamp,
    )
    new_stage = updated.life_stage
    changes = {
        key: int(stats.to_dict()[key] - before[key])
        for key in stats.to_dict()
        if stats.to_dict()[key] != before[key]
    }

    messages = [f"{updated.name or 'Your character'} turned {new_age}."]
    if new_stage != old_stage:
        messages.append(f"Entered the {new_stage.value.replace('_', ' ')} stage of life.")
    if death_cause:
        messages.append(f"Life ended at age {new_age} from {death_cause}.")

    return YearOutcome(
        character=updated,
        previous_age=old_age,
        new_age=new_age,
        died=death_cause is not None,
        death_cause=death_cause,
        stat_changes=changes,
        previous_stage=old_stage,
        new_stage=new_stage,
        log_messages=tuple(messages),
    )


class LifeEngine:
    """Persistence-backed API for creating, viewing, and aging a user's life."""

    def __init__(
        self,
        db: Any,
        rng: RNG,
        locks: Optional[UserLockRegistry] = None,
        clock: Callable[[], float] = time.time,
        event_engine: Optional[EventEngine] = None,
        event_chance: Optional[float] = None,
        career_service: Optional[CareerService] = None,
        family_service: Optional[FamilyService] = None,
    ) -> None:
        self.db = db
        self.rng = rng
        self.locks = locks or UserLockRegistry()
        self.clock = clock
        self.events = event_engine or EventEngine(
            db,
            rng,
            self.locks,
            event_chance=event_chance,
        )
        self.careers = career_service or CareerService(db, rng, self.locks, clock=clock)
        self.family = family_service or FamilyService(db, rng, self.locks, clock=clock)

    async def create_character(
        self,
        user_id: int,
        name: str,
        *,
        gender: Gender | str = Gender.MALE,
        country: str = "usa",
        parent_char_id: Optional[int] = None,
    ) -> Character:
        """Create one active life for a Discord user, starting at age zero."""
        if not isinstance(user_id, int) or user_id <= 0:
            raise ValidationError("A valid Discord user ID is required.")
        clean_name = self._validate_name(name)
        clean_country = self._validate_country(country)
        try:
            clean_gender = gender if isinstance(gender, Gender) else Gender(str(gender).lower())
        except ValueError as exc:
            raise ValidationError("Choose male, female, or non-binary.") from exc

        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                cursor = await tx.execute(
                    "SELECT char_id FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
                    (user_id,),
                )
                if await cursor.fetchone():
                    raise CharacterAlreadyExists()

                generation = 1
                if parent_char_id is not None:
                    cursor = await tx.execute(
                        "SELECT data_json FROM characters WHERE char_id = ?",
                        (parent_char_id,),
                    )
                    parent_row = await cursor.fetchone()
                    if parent_row is None:
                        raise ValidationError("The selected parent life could not be found.")
                    parent = Character.from_dict(json.loads(parent_row["data_json"]))
                    generation = parent.generation + 1

                stats, hidden, wealth_class = roll_birth_attributes(self.rng)
                now = int(self.clock())
                character = Character(
                    user_id=user_id,
                    name=clean_name,
                    gender=clean_gender,
                    country=clean_country,
                    wealth_class=wealth_class,
                    age=0,
                    stats=stats,
                    hidden=hidden,
                    cash=0,
                    bank=0,
                    debt_total=0,
                    parent_char_id=parent_char_id,
                    generation=generation,
                    last_age_at=now,
                    born_at=now,
                )
                cursor = await tx.execute(
                    """INSERT INTO characters (
                           user_id, is_alive, name, gender, country, wealth_class, age,
                           stats_json, hidden_json, version, last_age_at, born_at,
                           died_at, death_cause, death_age, data_json
                       ) VALUES (?, 1, ?, ?, ?, ?, 0, ?, ?, 0, ?, ?, NULL, NULL, NULL, ?)""",
                    self._row_values(character),
                )
                char_id = int(cursor.lastrowid)
                character = replace(character, char_id=char_id)
                await self._refresh_data_json(tx, character)
                await self.family.initialize_family(tx, character)
                await self._insert_log(
                    tx,
                    character,
                    age=0,
                    category="birth",
                    text=f"{clean_name} was born into a {wealth_class} household.",
                    importance=3,
                    created_at=now,
                )
                return character

    async def get_active_character(self, user_id: int) -> Character:
        """Return a user's active character or raise ``CharacterNotFound``."""
        row = await self.db.fetchone(
            "SELECT data_json FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        if row is None:
            latest = await self.db.fetchone(
                "SELECT data_json FROM characters WHERE user_id = ? ORDER BY char_id DESC LIMIT 1",
                (user_id,),
            )
            if latest is not None:
                raise CharacterDead()
            raise CharacterNotFound()
        return Character.from_dict(json.loads(row["data_json"]))

    async def age_up(self, user_id: int) -> YearOutcome:
        """Advance the active life by one year as one serialized DB transaction."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                cursor = await tx.execute(
                    "SELECT data_json, version FROM characters "
                    "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
                    (user_id,),
                )
                row = await cursor.fetchone()
                if row is None:
                    # Distinguish a completed life from a user who never started.
                    cursor = await tx.execute(
                        "SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,)
                    )
                    if await cursor.fetchone():
                        raise CharacterDead()
                    raise CharacterNotFound()

                character = Character.from_dict(json.loads(row["data_json"]))
                # A pending choice must be resolved before the next simulated year.
                cursor = await tx.execute(
                    "SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1",
                    (character.char_id,),
                )
                if await cursor.fetchone():
                    raise PendingEventExists()

                # Keep the database version authoritative if a caller's JSON was stale.
                character.version = int(row["version"])
                timestamp = int(self.clock())
                outcome = simulate_year(character, self.rng, now=timestamp)
                school_progress = advance_school_year(outcome.character)
                career_progress = await self.careers.advance_year(
                    tx,
                    school_progress.character,
                    previous_age=outcome.previous_age,
                    now=timestamp,
                )
                personal_income = max(0, career_progress.character.cash - school_progress.character.cash)
                family_progress = await self.family.advance_year(
                    tx,
                    career_progress.character,
                    previous_age=outcome.previous_age,
                    personal_income=personal_income,
                    now=timestamp,
                )
                updated = replace(family_progress.character, version=character.version + 1)
                outcome = replace(
                    outcome,
                    character=updated,
                    log_messages=(
                        outcome.log_messages
                        + school_progress.messages
                        + career_progress.messages
                        + family_progress.messages
                    ),
                )
                await self._save_character(tx, updated, expected_version=character.version)

                for message in outcome.log_messages:
                    if message.startswith("Life ended at age"):
                        category, importance = "death", 5
                    elif message in school_progress.messages:
                        category, importance = "education", 3
                    elif message in career_progress.messages:
                        category, importance = "career", 2
                    elif message in family_progress.messages:
                        category, importance = "family", 2
                    else:
                        category = "aging"
                        importance = 3 if "stage of life" in message else 1
                    await self._insert_log(
                        tx,
                        updated,
                        age=updated.age,
                        category=category,
                        text=message,
                        importance=importance,
                        created_at=timestamp,
                    )

                pending_event = None
                if updated.is_alive:
                    pending_event = await self.events.maybe_create_pending(
                        tx,
                        updated,
                        now=timestamp,
                    )
                    if pending_event is not None:
                        await self._insert_log(
                            tx,
                            updated,
                            age=updated.age,
                            category="event",
                            text=f"A choice event began: {pending_event.event.title}.",
                            importance=2,
                            created_at=timestamp,
                        )

                return replace(outcome, character=updated, pending_event=pending_event)

    @staticmethod
    def _validate_name(name: str) -> str:
        if not isinstance(name, str):
            raise ValidationError("Enter a character name.")
        clean = " ".join(name.split()).strip()
        if not clean or len(clean) > 32 or not _NAME_RE.fullmatch(clean):
            raise ValidationError("Name must be 1–32 characters and contain no control characters.")
        return clean

    @staticmethod
    def _validate_country(country: str) -> str:
        if not isinstance(country, str):
            raise ValidationError("Enter a country or region code.")
        clean = " ".join(country.split()).strip().lower()
        if not clean or len(clean) > 40 or not _NAME_RE.fullmatch(clean):
            raise ValidationError("Country or region must be 1–40 characters.")
        return clean

    @staticmethod
    def _row_values(character: Character) -> tuple[Any, ...]:
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        hidden_json = json.dumps({
            "genetic_health_mod": character.hidden.genetic_health_mod,
            "lifespan_mod": character.hidden.lifespan_mod,
            "luck": character.hidden.luck,
            "temperament": character.hidden.temperament,
        }, separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        return (
            character.user_id,
            character.name,
            character.gender.value,
            character.country,
            character.wealth_class,
            stats_json,
            hidden_json,
            character.last_age_at,
            character.born_at,
            data_json,
        )

    async def _refresh_data_json(self, tx: aiosqlite.Connection, character: Character) -> None:
        """Persist a newly assigned ID to the JSON snapshot."""
        await tx.execute(
            "UPDATE characters SET data_json = ? WHERE char_id = ?",
            (json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False), character.char_id),
        )

    async def _save_character(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        expected_version: int,
    ) -> None:
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        hidden_json = json.dumps({
            "genetic_health_mod": character.hidden.genetic_health_mod,
            "lifespan_mod": character.hidden.lifespan_mod,
            "luck": character.hidden.luck,
            "temperament": character.hidden.temperament,
        }, separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET
                   is_alive = ?, name = ?, gender = ?, country = ?, wealth_class = ?, age = ?,
                   stats_json = ?, hidden_json = ?, version = ?, last_age_at = ?,
                   died_at = ?, death_cause = ?, death_age = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (
                int(character.is_alive), character.name, character.gender.value,
                character.country, character.wealth_class, character.age,
                stats_json, hidden_json, character.version, character.last_age_at,
                character.died_at, character.death_cause, character.death_age,
                data_json, character.char_id, expected_version,
            ),
        )
        if cursor.rowcount != 1:
            raise ConcurrentUpdate()

    @staticmethod
    async def _insert_log(
        tx: aiosqlite.Connection,
        character: Character,
        *,
        age: int,
        category: str,
        text: str,
        importance: int,
        created_at: int,
    ) -> None:
        await tx.execute(
            """INSERT INTO life_logs (char_id, age, category, text, importance, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (character.char_id, age, category, text, importance, created_at),
        )
```

## `lifeline/core/migrations/005_relationships_family.sql`

```sql
-- Stage 6: family NPCs, relationships, dating, marriage, children, and support.
CREATE TABLE IF NOT EXISTS npcs (
    npc_id             INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_char_id      INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    name               TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 80),
    gender             TEXT NOT NULL CHECK (gender IN ('male', 'female', 'non_binary')),
    age                INTEGER NOT NULL DEFAULT 0 CHECK (age BETWEEN 0 AND 120),
    looks              INTEGER NOT NULL CHECK (looks BETWEEN 0 AND 100),
    smarts             INTEGER NOT NULL CHECK (smarts BETWEEN 0 AND 100),
    health             INTEGER NOT NULL CHECK (health BETWEEN 0 AND 100),
    wealth             INTEGER NOT NULL DEFAULT 0 CHECK (wealth >= 0),
    occupation         TEXT NOT NULL DEFAULT 'Unemployed',
    is_alive           INTEGER NOT NULL DEFAULT 1 CHECK (is_alive IN (0, 1)),
    death_age          INTEGER,
    country            TEXT NOT NULL DEFAULT 'usa',
    annual_income      INTEGER NOT NULL DEFAULT 0 CHECK (annual_income >= 0),
    prefers_smarts     INTEGER NOT NULL DEFAULT 0 CHECK (prefers_smarts IN (0, 1)),
    CHECK ((is_alive = 1 AND death_age IS NULL) OR (is_alive = 0 AND death_age IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS idx_npcs_owner_alive ON npcs(owner_char_id, is_alive, age);

CREATE TABLE IF NOT EXISTS relationships (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id     INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    npc_id      INTEGER NOT NULL REFERENCES npcs(npc_id) ON DELETE CASCADE,
    type        TEXT NOT NULL CHECK (type IN ('parent', 'sibling', 'child', 'friend', 'partner', 'fiance', 'spouse', 'ex', 'enemy', 'coworker')),
    score       INTEGER NOT NULL DEFAULT 50 CHECK (score BETWEEN 0 AND 100),
    since_age   INTEGER NOT NULL DEFAULT 0 CHECK (since_age >= 0),
    UNIQUE(char_id, npc_id)
);
CREATE INDEX IF NOT EXISTS idx_relationships_character_type ON relationships(char_id, type, score DESC);

CREATE TABLE IF NOT EXISTS children (
    npc_id               INTEGER PRIMARY KEY REFERENCES npcs(npc_id) ON DELETE CASCADE,
    char_id              INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    other_parent_npc_id  INTEGER REFERENCES npcs(npc_id) ON DELETE SET NULL,
    custody              TEXT NOT NULL DEFAULT 'full' CHECK (custody IN ('full', 'shared', 'none')),
    child_support        INTEGER NOT NULL DEFAULT 0 CHECK (child_support >= 0)
);
CREATE INDEX IF NOT EXISTS idx_children_character ON children(char_id, custody);

-- Count interactions per person and in-game age; a primary key prevents duplicate races.
CREATE TABLE IF NOT EXISTS yearly_counters (
    char_id  INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    npc_id   INTEGER NOT NULL REFERENCES npcs(npc_id) ON DELETE CASCADE,
    age      INTEGER NOT NULL CHECK (age >= 0),
    action   TEXT NOT NULL,
    count    INTEGER NOT NULL DEFAULT 0 CHECK (count >= 0),
    PRIMARY KEY(char_id, npc_id, age, action)
);

CREATE TABLE IF NOT EXISTS dating_sessions (
    char_id     INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    nonce       TEXT NOT NULL UNIQUE,
    created_at  INTEGER NOT NULL,
    expires_at  INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS dating_candidates (
    char_id  INTEGER NOT NULL REFERENCES dating_sessions(char_id) ON DELETE CASCADE,
    npc_id   INTEGER NOT NULL REFERENCES npcs(npc_id) ON DELETE CASCADE,
    PRIMARY KEY(char_id, npc_id)
);

CREATE TABLE IF NOT EXISTS marriages (
    char_id          INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    spouse_npc_id    INTEGER NOT NULL REFERENCES npcs(npc_id) ON DELETE CASCADE,
    start_age        INTEGER NOT NULL CHECK (start_age >= 0),
    spouse_income    INTEGER NOT NULL DEFAULT 0 CHECK (spouse_income >= 0),
    prenup           INTEGER NOT NULL DEFAULT 0 CHECK (prenup IN (0, 1)),
    premarital_cash  INTEGER NOT NULL DEFAULT 0 CHECK (premarital_cash >= 0),
    premarital_bank  INTEGER NOT NULL DEFAULT 0 CHECK (premarital_bank >= 0),
    wedding_cost     INTEGER NOT NULL DEFAULT 0 CHECK (wedding_cost >= 0),
    low_score_years  INTEGER NOT NULL DEFAULT 0 CHECK (low_score_years >= 0),
    created_at       INTEGER NOT NULL,
    UNIQUE(spouse_npc_id)
);

CREATE TABLE IF NOT EXISTS pregnancies (
    char_id              INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    other_parent_npc_id  INTEGER REFERENCES npcs(npc_id) ON DELETE SET NULL,
    conception_age       INTEGER NOT NULL CHECK (conception_age >= 0),
    due_age              INTEGER NOT NULL CHECK (due_age >= conception_age),
    accidental           INTEGER NOT NULL DEFAULT 0 CHECK (accidental IN (0, 1))
);
CREATE TABLE IF NOT EXISTS adoptions (
    char_id      INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    started_age  INTEGER NOT NULL CHECK (started_age >= 0),
    due_age      INTEGER NOT NULL CHECK (due_age > started_age),
    paid_cost    INTEGER NOT NULL CHECK (paid_cost >= 0)
);

-- Minimal persistent inventory/portfolio values for rings and divorce valuation.
CREATE TABLE IF NOT EXISTS family_assets (
    asset_id        INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id         INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    kind            TEXT NOT NULL CHECK (kind IN ('item', 'stock')),
    item_id         TEXT NOT NULL,
    quantity        INTEGER NOT NULL DEFAULT 1 CHECK (quantity >= 0),
    purchase_price  INTEGER NOT NULL CHECK (purchase_price >= 0),
    current_value   INTEGER NOT NULL CHECK (current_value >= 0),
    acquired_age    INTEGER NOT NULL CHECK (acquired_age >= 0),
    acquired_at     INTEGER NOT NULL DEFAULT 0,
    is_liquidated   INTEGER NOT NULL DEFAULT 0 CHECK (is_liquidated IN (0, 1))
);
CREATE INDEX IF NOT EXISTS idx_family_assets_character_age ON family_assets(char_id, acquired_age, kind);

CREATE TABLE IF NOT EXISTS alimony (
    char_id          INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    ex_npc_id        INTEGER NOT NULL REFERENCES npcs(npc_id) ON DELETE CASCADE,
    annual_amount    INTEGER NOT NULL CHECK (annual_amount >= 0),
    remaining_years  REAL NOT NULL CHECK (remaining_years >= 0),
    payer_is_player  INTEGER NOT NULL CHECK (payer_is_player IN (0, 1))
);
CREATE TABLE IF NOT EXISTS affairs (
    char_id        INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    spouse_npc_id  INTEGER NOT NULL REFERENCES npcs(npc_id) ON DELETE CASCADE,
    started_age    INTEGER NOT NULL CHECK (started_age >= 0),
    nonce          TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS infidelity_prompts (
    char_id        INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    spouse_npc_id  INTEGER NOT NULL REFERENCES npcs(npc_id) ON DELETE CASCADE,
    nonce          TEXT NOT NULL UNIQUE,
    created_at     INTEGER NOT NULL,
    expires_at     INTEGER NOT NULL CHECK (expires_at >= created_at)
);
CREATE TABLE IF NOT EXISTS infidelity_choices (
    char_id      INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    spouse_npc_id INTEGER NOT NULL REFERENCES npcs(npc_id) ON DELETE CASCADE,
    age          INTEGER NOT NULL CHECK (age >= 0),
    choice       TEXT NOT NULL CHECK (choice IN ('cheat', 'faithful')),
    created_at   INTEGER NOT NULL,
    PRIMARY KEY(char_id, age)
);

CREATE TABLE IF NOT EXISTS divorce_records (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id         INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    spouse_npc_id   INTEGER NOT NULL REFERENCES npcs(npc_id),
    age             INTEGER NOT NULL CHECK (age >= 0),
    prenup          INTEGER NOT NULL CHECK (prenup IN (0, 1)),
    marital_assets  INTEGER NOT NULL CHECK (marital_assets >= 0),
    spouse_share    INTEGER NOT NULL CHECK (spouse_share >= 0),
    lawyer_fee      INTEGER NOT NULL CHECK (lawyer_fee >= 0),
    reason          TEXT NOT NULL CHECK (reason IN ('player', 'discovery', 'npc_initiated')),
    created_at      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_divorce_history_character ON divorce_records(char_id, age DESC);

CREATE TABLE IF NOT EXISTS stats_tracking (
    char_id    INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    divorces   INTEGER NOT NULL DEFAULT 0 CHECK (divorces >= 0)
);
```

## `lifeline/core/repositories/__init__.py`

```py
"""Persistence repositories for LIFELINE's transactional game systems."""
```

## `lifeline/core/repositories/family.py`

```py
"""Parameterized SQLite repository for Stage 6 family and relationship data."""
from __future__ import annotations

import json
from typing import Any, Optional

import aiosqlite

from ..models import Character


class FamilyRepository:
    """Own every SQL statement used by the Stage 6 family domain service."""

    def __init__(self, db: Any) -> None:
        self.db = db

    @staticmethod
    async def _tx_one(tx: aiosqlite.Connection, query: str, params: tuple[Any, ...] = ()) -> Any:
        cursor = await tx.execute(query, params)
        return await cursor.fetchone()

    @staticmethod
    async def _tx_all(tx: aiosqlite.Connection, query: str, params: tuple[Any, ...] = ()) -> list[Any]:
        cursor = await tx.execute(query, params)
        return await cursor.fetchall()

    async def load_active(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Return the active character row and version for a transactional action."""
        row = await self._tx_one(
            tx,
            "SELECT char_id, user_id, data_json, version FROM characters "
            "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def has_any_life(self, tx: aiosqlite.Connection, user_id: int) -> bool:
        """Check whether a user has a completed or active life."""
        row = await self._tx_one(tx, "SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,))
        return row is not None

    async def load_active_read(self, user_id: int) -> Optional[dict[str, Any]]:
        """Return an active character row for a read-only command."""
        row = await self.db.fetchone(
            "SELECT char_id, user_id, data_json, version FROM characters "
            "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def has_any_life_read(self, user_id: int) -> bool:
        """Check read-only character history for a user."""
        row = await self.db.fetchone("SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,))
        return row is not None

    async def has_pending_event(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check for an unresolved life choice before a new family action."""
        row = await self._tx_one(tx, "SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1", (char_id,))
        return row is not None

    async def save_character(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
    ) -> None:
        """Save character JSON and stats with optimistic-version protection."""
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET stats_json = ?, version = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (stats_json, character.version, data_json, character.char_id, expected_version),
        )
        if cursor.rowcount != 1:
            from ..errors import ConcurrentUpdate
            raise ConcurrentUpdate()

    async def create_npc(
        self,
        tx: aiosqlite.Connection,
        *,
        owner_char_id: int,
        name: str,
        gender: str,
        age: int,
        looks: int,
        smarts: int,
        health: int,
        wealth: int,
        occupation: str,
        country: str,
        annual_income: int = 0,
        prefers_smarts: bool = False,
    ) -> int:
        """Persist one generated NPC and return its key."""
        cursor = await tx.execute(
            """INSERT INTO npcs
                   (owner_char_id, name, gender, age, looks, smarts, health, wealth,
                    occupation, is_alive, death_age, country, annual_income, prefers_smarts)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NULL, ?, ?, ?)""",
            (
                owner_char_id, name, gender, age, looks, smarts, health, wealth,
                occupation, country, annual_income, int(prefers_smarts),
            ),
        )
        return int(cursor.lastrowid)

    async def create_relationship(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        npc_id: int,
        relation_type: str,
        score: int,
        since_age: int,
    ) -> None:
        """Insert or update the unique relationship between a life and an NPC."""
        await tx.execute(
            """INSERT INTO relationships(char_id, npc_id, type, score, since_age)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(char_id, npc_id) DO UPDATE SET
                   type = excluded.type, score = excluded.score, since_age = excluded.since_age""",
            (char_id, npc_id, relation_type, max(0, min(100, int(score))), since_age),
        )

    async def get_person(self, tx: aiosqlite.Connection, char_id: int, npc_id: int) -> Optional[dict[str, Any]]:
        """Return an NPC only when it belongs to the selected life."""
        row = await self._tx_one(
            tx,
            """SELECT n.*, r.type AS relationship_type, r.score AS relationship_score,
                      r.since_age AS relationship_since_age, c.custody, c.child_support
               FROM relationships AS r
               JOIN npcs AS n ON n.npc_id = r.npc_id
               LEFT JOIN children AS c ON c.npc_id = n.npc_id AND c.char_id = r.char_id
               WHERE r.char_id = ? AND n.owner_char_id = ? AND n.npc_id = ? LIMIT 1""",
            (char_id, char_id, npc_id),
        )
        return dict(row) if row is not None else None

    async def get_person_read(self, char_id: int, npc_id: int) -> Optional[dict[str, Any]]:
        """Return an owned NPC and relationship for autocomplete or UI rendering."""
        row = await self.db.fetchone(
            """SELECT n.*, r.type AS relationship_type, r.score AS relationship_score,
                      r.since_age AS relationship_since_age, c.custody, c.child_support
               FROM relationships AS r
               JOIN npcs AS n ON n.npc_id = r.npc_id
               LEFT JOIN children AS c ON c.npc_id = n.npc_id AND c.char_id = r.char_id
               WHERE r.char_id = ? AND n.owner_char_id = ? AND n.npc_id = ? LIMIT 1""",
            (char_id, char_id, npc_id),
        )
        return dict(row) if row is not None else None

    async def list_people(self, char_id: int, *, include_dead: bool = True) -> list[dict[str, Any]]:
        """List NPC relationships for one life in family-friendly display order."""
        condition = "" if include_dead else "AND n.is_alive = 1"
        rows = await self.db.fetchall(
            f"""SELECT n.*, r.type AS relationship_type, r.score AS relationship_score,
                       r.since_age AS relationship_since_age, c.custody, c.child_support
                FROM relationships AS r
                JOIN npcs AS n ON n.npc_id = r.npc_id
                LEFT JOIN children AS c ON c.npc_id = n.npc_id AND c.char_id = r.char_id
                WHERE r.char_id = ? {condition}
                ORDER BY CASE r.type WHEN 'spouse' THEN 0 WHEN 'fiance' THEN 1
                     WHEN 'partner' THEN 2 WHEN 'parent' THEN 3 WHEN 'child' THEN 4
                     WHEN 'sibling' THEN 5 WHEN 'friend' THEN 6 ELSE 7 END,
                     r.score DESC, n.name COLLATE NOCASE""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def autocomplete_people(self, char_id: int, query: str) -> list[dict[str, Any]]:
        """Find living connected NPCs for people-option autocomplete."""
        rows = await self.db.fetchall(
            """SELECT n.npc_id, n.name, n.age, r.type AS relationship_type
               FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
               WHERE r.char_id = ? AND n.is_alive = 1 AND lower(n.name) LIKE ?
               ORDER BY n.name COLLATE NOCASE LIMIT 25""",
            (char_id, f"%{query.lower()}%"),
        )
        return [dict(row) for row in rows]

    async def list_relationships_tx(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """List full relationship and NPC records inside an existing transaction."""
        rows = await self._tx_all(
            tx,
            """SELECT n.*, r.type AS relationship_type, r.score AS relationship_score,
                      r.since_age AS relationship_since_age, c.custody, c.child_support
               FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
               LEFT JOIN children AS c ON c.npc_id = n.npc_id AND c.char_id = r.char_id
               WHERE r.char_id = ? ORDER BY n.npc_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def set_relationship_score(self, tx: aiosqlite.Connection, char_id: int, npc_id: int, score: int) -> None:
        """Store a clamped relationship score."""
        await tx.execute(
            "UPDATE relationships SET score = ? WHERE char_id = ? AND npc_id = ?",
            (max(0, min(100, int(score))), char_id, npc_id),
        )

    async def add_relationship_score(self, tx: aiosqlite.Connection, char_id: int, npc_id: int, delta: int) -> None:
        """Apply and clamp a score delta in SQLite."""
        await tx.execute(
            """UPDATE relationships SET score = MIN(100, MAX(0, score + ?))
               WHERE char_id = ? AND npc_id = ?""",
            (int(delta), char_id, npc_id),
        )

    async def set_relationship_type(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        npc_id: int,
        relation_type: str,
    ) -> None:
        """Change one existing relationship's role."""
        await tx.execute(
            "UPDATE relationships SET type = ? WHERE char_id = ? AND npc_id = ?",
            (relation_type, char_id, npc_id),
        )

    async def active_romance(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Find the highest-scoring active partner, fiance, or spouse."""
        row = await self._tx_one(
            tx,
            """SELECT n.*, r.type AS relationship_type, r.score AS relationship_score,
                      r.since_age AS relationship_since_age
               FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
               WHERE r.char_id = ? AND r.type IN ('partner', 'fiance', 'spouse') AND n.is_alive = 1
               ORDER BY CASE r.type WHEN 'spouse' THEN 0 WHEN 'fiance' THEN 1 ELSE 2 END,
                        r.id DESC LIMIT 1""",
            (char_id,),
        )
        return dict(row) if row is not None else None

    async def claim_interaction(self, tx: aiosqlite.Connection, char_id: int, npc_id: int, age: int) -> bool:
        """Atomically reserve one of the three per-year interactions with an NPC."""
        row = await self._tx_one(
            tx,
            """SELECT count FROM yearly_counters
               WHERE char_id = ? AND npc_id = ? AND age = ? AND action = 'relationship_interact'""",
            (char_id, npc_id, age),
        )
        count = int(row["count"]) if row is not None else 0
        if count >= 3:
            return False
        await tx.execute(
            """INSERT INTO yearly_counters(char_id, npc_id, age, action, count)
               VALUES (?, ?, ?, 'relationship_interact', 1)
               ON CONFLICT(char_id, npc_id, age, action) DO UPDATE SET count = count + 1""",
            (char_id, npc_id, age),
        )
        return True

    async def claim_yearly_action(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        npc_id: int,
        age: int,
        action: str,
        *,
        limit: int = 1,
    ) -> bool:
        """Atomically reserve an action with a per-NPC, per-age limit."""
        row = await self._tx_one(
            tx,
            "SELECT count FROM yearly_counters WHERE char_id = ? AND npc_id = ? AND age = ? AND action = ?",
            (char_id, npc_id, age, action),
        )
        count = int(row["count"]) if row is not None else 0
        if count >= limit:
            return False
        await tx.execute(
            """INSERT INTO yearly_counters(char_id, npc_id, age, action, count)
               VALUES (?, ?, ?, ?, 1)
               ON CONFLICT(char_id, npc_id, age, action) DO UPDATE SET count = count + 1""",
            (char_id, npc_id, age, action),
        )
        return True

    async def list_live_npcs(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """List live NPCs owned by a life for the yearly NPC-ageing tick."""
        rows = await self._tx_all(
            tx,
            "SELECT * FROM npcs WHERE owner_char_id = ? AND is_alive = 1 ORDER BY npc_id",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def update_npc_year(self, tx: aiosqlite.Connection, npc_id: int, age: int, *, alive: bool) -> None:
        """Persist a single NPC's age and terminal death state."""
        await tx.execute(
            """UPDATE npcs SET age = ?, is_alive = ?, death_age = ? WHERE npc_id = ? AND is_alive = 1""",
            (age, int(alive), None if alive else age, npc_id),
        )

    async def decay_relationships(self, tx: aiosqlite.Connection, char_id: int, previous_age: int) -> None:
        """Apply annual score decay only to people with no prior-year interaction."""
        await tx.execute(
            """UPDATE relationships
               SET score = MAX(0, score - CASE
                   WHEN type IN ('parent', 'sibling', 'child') THEN 1
                   WHEN type IN ('partner', 'fiance', 'spouse') THEN 3
                   WHEN type = 'friend' THEN 2
                   ELSE 0 END)
               WHERE char_id = ? AND type IN ('parent', 'sibling', 'child', 'friend', 'partner', 'fiance', 'spouse')
                 AND NOT EXISTS (
                     SELECT 1 FROM yearly_counters AS yc
                     WHERE yc.char_id = relationships.char_id
                       AND yc.npc_id = relationships.npc_id
                       AND yc.age = ? AND yc.action = 'relationship_interact' AND yc.count > 0
                 )""",
            (char_id, previous_age),
        )

    async def count_siblings(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Count recorded sibling NPCs for inheritance division."""
        row = await self._tx_one(
            tx,
            """SELECT COUNT(*) AS count FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
               WHERE r.char_id = ? AND r.type = 'sibling' AND n.is_alive = 1""",
            (char_id,),
        )
        return int(row["count"] if row is not None else 0)

    async def parent_relations(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return parent NPC and relationship rows for grief/inheritance logic."""
        rows = await self._tx_all(
            tx,
            """SELECT n.*, r.type AS relationship_type, r.score AS relationship_score
               FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
               WHERE r.char_id = ? AND r.type = 'parent' ORDER BY n.npc_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def insert_life_log(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        age: int,
        category: str,
        text: str,
        importance: int,
        created_at: int,
    ) -> None:
        """Insert a family system log into the shared life journal."""
        await tx.execute(
            """INSERT INTO life_logs(char_id, age, category, text, importance, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (char_id, age, category, text, importance, created_at),
        )

    async def save_dating_session(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        nonce: str,
        created_at: int,
        expires_at: int,
        npc_ids: list[int],
    ) -> None:
        """Replace the previous date search and attach its three generated candidates."""
        await tx.execute(
            """DELETE FROM npcs WHERE npc_id IN (
                   SELECT d.npc_id FROM dating_candidates AS d WHERE d.char_id = ?
               ) AND NOT EXISTS (
                   SELECT 1 FROM relationships AS r WHERE r.npc_id = npcs.npc_id
               )""",
            (char_id,),
        )
        await tx.execute("DELETE FROM dating_sessions WHERE char_id = ?", (char_id,))
        await tx.execute(
            "INSERT INTO dating_sessions(char_id, nonce, created_at, expires_at) VALUES (?, ?, ?, ?)",
            (char_id, nonce, created_at, expires_at),
        )
        for npc_id in npc_ids:
            await tx.execute(
                "INSERT INTO dating_candidates(char_id, npc_id) VALUES (?, ?)",
                (char_id, npc_id),
            )

    async def get_dating_candidate(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        npc_id: int,
        nonce: str,
        now: int,
    ) -> Optional[dict[str, Any]]:
        """Return a candidate only for its live, nonce-matched owner session."""
        row = await self._tx_one(
            tx,
            """SELECT n.*, s.nonce, s.expires_at
               FROM dating_sessions AS s
               JOIN dating_candidates AS d ON d.char_id = s.char_id
               JOIN npcs AS n ON n.npc_id = d.npc_id
               WHERE s.char_id = ? AND s.nonce = ? AND s.expires_at >= ? AND n.npc_id = ?
                 AND n.owner_char_id = ? AND n.is_alive = 1 LIMIT 1""",
            (char_id, nonce, now, npc_id, char_id),
        )
        return dict(row) if row is not None else None

    async def consume_dating_session(self, tx: aiosqlite.Connection, char_id: int, nonce: str) -> None:
        """Remove all unused date candidates after one selection."""
        await tx.execute(
            """DELETE FROM npcs WHERE npc_id IN (
                   SELECT d.npc_id FROM dating_candidates AS d WHERE d.char_id = ?
               ) AND NOT EXISTS (
                   SELECT 1 FROM relationships AS r WHERE r.npc_id = npcs.npc_id
               )""",
            (char_id,),
        )
        await tx.execute("DELETE FROM dating_sessions WHERE char_id = ? AND nonce = ?", (char_id, nonce))

    async def get_marriage(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return the active marriage record."""
        row = await self._tx_one(tx, "SELECT * FROM marriages WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def create_marriage(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        spouse_npc_id: int,
        start_age: int,
        spouse_income: int,
        prenup: bool,
        premarital_cash: int,
        premarital_bank: int,
        wedding_cost: int,
        created_at: int,
    ) -> None:
        """Store marriage terms and premarital liquid-asset baselines."""
        await tx.execute(
            """INSERT INTO marriages
                   (char_id, spouse_npc_id, start_age, spouse_income, prenup,
                    premarital_cash, premarital_bank, wedding_cost, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                char_id, spouse_npc_id, start_age, spouse_income, int(prenup),
                premarital_cash, premarital_bank, wedding_cost, created_at,
            ),
        )

    async def delete_marriage(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Remove the current marriage record after divorce or spouse death."""
        await tx.execute("DELETE FROM marriages WHERE char_id = ?", (char_id,))

    async def get_children(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return each child NPC and custody/support state."""
        rows = await self._tx_all(
            tx,
            """SELECT n.*, c.custody, c.child_support, c.other_parent_npc_id
               FROM children AS c JOIN npcs AS n ON n.npc_id = c.npc_id
               WHERE c.char_id = ? ORDER BY n.age, n.npc_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def add_child(
        self,
        tx: aiosqlite.Connection,
        *,
        npc_id: int,
        char_id: int,
        other_parent_npc_id: Optional[int],
        custody: str = "full",
        child_support: int = 0,
    ) -> None:
        """Attach an NPC child to its player parent and support/custody record."""
        await tx.execute(
            """INSERT INTO children(npc_id, char_id, other_parent_npc_id, custody, child_support)
               VALUES (?, ?, ?, ?, ?)""",
            (npc_id, char_id, other_parent_npc_id, custody, max(0, child_support)),
        )

    async def update_child_support(self, tx: aiosqlite.Connection, npc_id: int, child_support: int) -> None:
        """Refresh the stored annual support amount in integer cents."""
        await tx.execute(
            "UPDATE children SET child_support = ? WHERE npc_id = ?",
            (max(0, int(child_support)), npc_id),
        )

    async def update_custody(self, tx: aiosqlite.Connection, npc_id: int, custody: str) -> None:
        """Persist a custody roll."""
        await tx.execute("UPDATE children SET custody = ? WHERE npc_id = ?", (custody, npc_id))

    async def add_pregnancy(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        other_parent_npc_id: Optional[int],
        conception_age: int,
        due_age: int,
        accidental: bool,
    ) -> None:
        """Persist a pregnancy until its one-year due date."""
        await tx.execute(
            """INSERT INTO pregnancies(char_id, other_parent_npc_id, conception_age, due_age, accidental)
               VALUES (?, ?, ?, ?, ?)""",
            (char_id, other_parent_npc_id, conception_age, due_age, int(accidental)),
        )

    async def get_pregnancy(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return a pending pregnancy if present."""
        row = await self._tx_one(tx, "SELECT * FROM pregnancies WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def delete_pregnancy(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Delete a pregnancy after birth or cancellation."""
        await tx.execute("DELETE FROM pregnancies WHERE char_id = ?", (char_id,))

    async def add_adoption(self, tx: aiosqlite.Connection, char_id: int, started_age: int, due_age: int, paid_cost: int) -> None:
        """Store an adoption completion date."""
        await tx.execute(
            "INSERT INTO adoptions(char_id, started_age, due_age, paid_cost) VALUES (?, ?, ?, ?)",
            (char_id, started_age, due_age, paid_cost),
        )

    async def get_adoption(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return a pending adoption."""
        row = await self._tx_one(tx, "SELECT * FROM adoptions WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def delete_adoption(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Delete a completed adoption."""
        await tx.execute("DELETE FROM adoptions WHERE char_id = ?", (char_id,))

    async def add_asset(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        kind: str,
        item_id: str,
        quantity: int,
        purchase_price: int,
        current_value: int,
        acquired_age: int,
        acquired_at: int,
    ) -> int:
        """Add an item or portfolio asset with integer-cent values."""
        cursor = await tx.execute(
            """INSERT INTO family_assets
                   (char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at),
        )
        return int(cursor.lastrowid)

    async def list_ring_assets(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return unused ring items available to a marriage proposal."""
        rows = await self._tx_all(
            tx,
            """SELECT * FROM family_assets
               WHERE char_id = ? AND kind = 'item' AND item_id LIKE '%_ring'
                 AND quantity > 0 AND is_liquidated = 0
               ORDER BY current_value DESC, asset_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def consume_ring(self, tx: aiosqlite.Connection, asset_id: int) -> None:
        """Consume the selected ring at proposal time."""
        await tx.execute(
            "UPDATE family_assets SET quantity = 0, current_value = 0, is_liquidated = 1 WHERE asset_id = ?",
            (asset_id,),
        )

    async def get_marital_assets(self, tx: aiosqlite.Connection, char_id: int, marriage_started_at: int) -> list[dict[str, Any]]:
        """Return non-liquidated assets acquired at or after the wedding timestamp."""
        rows = await self._tx_all(
            tx,
            """SELECT * FROM family_assets
               WHERE char_id = ? AND acquired_at >= ? AND current_value > 0 AND is_liquidated = 0
               ORDER BY CASE kind WHEN 'stock' THEN 0 ELSE 1 END, asset_id""",
            (char_id, marriage_started_at),
        )
        return [dict(row) for row in rows]

    async def reduce_asset(self, tx: aiosqlite.Connection, asset_id: int, reduction: int) -> int:
        """Reduce an asset's value by up to an integer-cent payment amount."""
        row = await self._tx_one(tx, "SELECT current_value FROM family_assets WHERE asset_id = ?", (asset_id,))
        if row is None:
            return 0
        current = int(row["current_value"])
        used = min(current, max(0, int(reduction)))
        remaining = current - used
        await tx.execute(
            "UPDATE family_assets SET current_value = ?, is_liquidated = ? WHERE asset_id = ?",
            (remaining, int(remaining == 0), asset_id),
        )
        return used

    async def liquidate_stock_assets(self, tx: aiosqlite.Connection, char_id: int, marriage_started_at: int) -> int:
        """Liquidate eligible marital stocks and return their total integer-cent value."""
        row = await self._tx_one(
            tx,
            """SELECT COALESCE(SUM(current_value), 0) AS total FROM family_assets
               WHERE char_id = ? AND kind = 'stock' AND acquired_at >= ?
                 AND current_value > 0 AND is_liquidated = 0""",
            (char_id, marriage_started_at),
        )
        total = int(row["total"] if row is not None else 0)
        await tx.execute(
            """UPDATE family_assets SET current_value = 0, quantity = 0, is_liquidated = 1
               WHERE char_id = ? AND kind = 'stock' AND acquired_at >= ?
                 AND current_value > 0 AND is_liquidated = 0""",
            (char_id, marriage_started_at),
        )
        return total

    async def get_annual_job_income(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Return the current annual salary as integer cents, or zero when unemployed."""
        row = await self._tx_one(tx, "SELECT salary FROM jobs WHERE char_id = ? LIMIT 1", (char_id,))
        return int(row["salary"]) if row is not None else 0

    async def create_alimony(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        ex_npc_id: int,
        annual_amount: int,
        remaining_years: float,
        payer_is_player: bool,
    ) -> None:
        """Persist an alimony agreement."""
        await tx.execute(
            """INSERT INTO alimony(char_id, ex_npc_id, annual_amount, remaining_years, payer_is_player)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(char_id) DO UPDATE SET
                   ex_npc_id = excluded.ex_npc_id,
                   annual_amount = excluded.annual_amount,
                   remaining_years = excluded.remaining_years,
                   payer_is_player = excluded.payer_is_player""",
            (char_id, ex_npc_id, max(0, annual_amount), max(0.0, remaining_years), int(payer_is_player)),
        )

    async def get_alimony(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return an active alimony order."""
        row = await self._tx_one(tx, "SELECT * FROM alimony WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def update_alimony(self, tx: aiosqlite.Connection, char_id: int, remaining_years: float) -> None:
        """Update or remove an expired alimony order."""
        if remaining_years <= 0:
            await tx.execute("DELETE FROM alimony WHERE char_id = ?", (char_id,))
        else:
            await tx.execute(
                "UPDATE alimony SET remaining_years = ? WHERE char_id = ?",
                (remaining_years, char_id),
            )

    async def get_affair(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return an active infidelity record."""
        row = await self._tx_one(tx, "SELECT * FROM affairs WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def save_affair(self, tx: aiosqlite.Connection, char_id: int, spouse_npc_id: int, age: int, nonce: str) -> None:
        """Persist a hidden affair after the player's infidelity choice."""
        await tx.execute(
            """INSERT INTO affairs(char_id, spouse_npc_id, started_age, nonce)
               VALUES (?, ?, ?, ?)
               ON CONFLICT(char_id) DO UPDATE SET
                   spouse_npc_id = excluded.spouse_npc_id,
                   started_age = excluded.started_age,
                   nonce = excluded.nonce""",
            (char_id, spouse_npc_id, age, nonce),
        )

    async def delete_affair(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Delete a discovered or ended affair."""
        await tx.execute("DELETE FROM affairs WHERE char_id = ?", (char_id,))

    async def increment_divorces(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Increment the persistent divorce statistic."""
        await tx.execute(
            """INSERT INTO stats_tracking(char_id, divorces) VALUES (?, 1)
               ON CONFLICT(char_id) DO UPDATE SET divorces = divorces + 1""",
            (char_id,),
        )

    async def insert_divorce_record(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        spouse_npc_id: int,
        age: int,
        prenup: bool,
        marital_assets: int,
        spouse_share: int,
        lawyer_fee: int,
        reason: str,
        created_at: int,
    ) -> None:
        """Persist an audit summary of one completed divorce."""
        await tx.execute(
            """INSERT INTO divorce_records
                   (char_id, spouse_npc_id, age, prenup, marital_assets, spouse_share,
                    lawyer_fee, reason, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, spouse_npc_id, age, int(prenup), marital_assets, spouse_share, lawyer_fee, reason, created_at),
        )

    async def update_custody_and_support(
        self,
        tx: aiosqlite.Connection,
        npc_id: int,
        custody: str,
        support: int,
    ) -> None:
        """Store divorce custody and its annual support amount."""
        await tx.execute(
            "UPDATE children SET custody = ?, child_support = ? WHERE npc_id = ?",
            (custody, max(0, support), npc_id),
        )

    async def list_children_public(self, char_id: int) -> list[dict[str, Any]]:
        """Read child NPCs for the family command."""
        rows = await self.db.fetchall(
            """SELECT n.*, c.custody, c.child_support, c.other_parent_npc_id
               FROM children AS c JOIN npcs AS n ON n.npc_id = c.npc_id
               WHERE c.char_id = ? ORDER BY n.age, n.npc_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def people_by_type(self, tx: aiosqlite.Connection, char_id: int, types: tuple[str, ...]) -> list[dict[str, Any]]:
        """Return NPC relationships filtered by a fixed type list."""
        placeholders = ",".join("?" for _ in types)
        rows = await self._tx_all(
            tx,
            f"""SELECT n.*, r.type AS relationship_type, r.score AS relationship_score,
                       r.since_age AS relationship_since_age
                FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
                WHERE r.char_id = ? AND r.type IN ({placeholders}) ORDER BY n.npc_id""",
            (char_id, *types),
        )
        return [dict(row) for row in rows]

    async def log_relationship_interaction(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        age: int,
        text: str,
        now: int,
    ) -> None:
        """Log one relationship action to the life journal."""
        await self.insert_life_log(
            tx,
            char_id=char_id,
            age=age,
            category="relationship",
            text=text,
            importance=2,
            created_at=now,
        )

    async def get_npc_owned(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        npc_id: int,
    ) -> Optional[dict[str, Any]]:
        """Return any NPC owned by a life, whether or not it has a relationship row."""
        row = await self._tx_one(
            tx,
            "SELECT * FROM npcs WHERE owner_char_id = ? AND npc_id = ? LIMIT 1",
            (char_id, npc_id),
        )
        return dict(row) if row is not None else None

    async def add_npc_wealth(self, tx: aiosqlite.Connection, npc_id: int, delta: int) -> None:
        """Apply a non-negative integer-cent wealth change to one NPC."""
        await tx.execute(
            "UPDATE npcs SET wealth = MAX(0, wealth + ?) WHERE npc_id = ?",
            (int(delta), npc_id),
        )

    async def set_npc_wealth(self, tx: aiosqlite.Connection, npc_id: int, wealth: int) -> None:
        """Set an NPC's wealth to a non-negative integer-cent value."""
        await tx.execute("UPDATE npcs SET wealth = ? WHERE npc_id = ?", (max(0, int(wealth)), npc_id))

    async def get_all_assets(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return every non-liquidated item/stock asset for a settlement cascade."""
        rows = await self._tx_all(
            tx,
            """SELECT * FROM family_assets WHERE char_id = ? AND current_value > 0
               AND is_liquidated = 0 ORDER BY CASE kind WHEN 'stock' THEN 0 ELSE 1 END, asset_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def has_infidelity_choice(self, tx: aiosqlite.Connection, char_id: int, age: int) -> bool:
        """Check whether this life already resolved a temptation at this age."""
        row = await self._tx_one(
            tx,
            "SELECT 1 FROM infidelity_choices WHERE char_id = ? AND age = ? LIMIT 1",
            (char_id, age),
        )
        return row is not None

    async def record_infidelity_choice(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        spouse_npc_id: int,
        age: int,
        choice: str,
        created_at: int,
    ) -> None:
        """Persist one choice per in-game age; the unique key protects races."""
        await tx.execute(
            """INSERT INTO infidelity_choices(char_id, spouse_npc_id, age, choice, created_at)
               VALUES (?, ?, ?, ?, ?)""",
            (char_id, spouse_npc_id, age, choice, created_at),
        )

    async def create_infidelity_prompt(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        spouse_npc_id: int,
        nonce: str,
        created_at: int,
        expires_at: int,
    ) -> None:
        """Persist a one-use temptation prompt."""
        await tx.execute("DELETE FROM infidelity_prompts WHERE char_id = ?", (char_id,))
        await tx.execute(
            """INSERT INTO infidelity_prompts(char_id, spouse_npc_id, nonce, created_at, expires_at)
               VALUES (?, ?, ?, ?, ?)""",
            (char_id, spouse_npc_id, nonce, created_at, expires_at),
        )

    async def get_infidelity_prompt(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        nonce: str,
        now: int,
    ) -> Optional[dict[str, Any]]:
        """Return an unexpired prompt only when its owner and nonce match."""
        row = await self._tx_one(
            tx,
            """SELECT * FROM infidelity_prompts
               WHERE char_id = ? AND nonce = ? AND expires_at >= ? LIMIT 1""",
            (char_id, nonce, now),
        )
        return dict(row) if row is not None else None

    async def delete_infidelity_prompt(self, tx: aiosqlite.Connection, char_id: int, nonce: str) -> None:
        """Consume one temptation prompt."""
        await tx.execute("DELETE FROM infidelity_prompts WHERE char_id = ? AND nonce = ?", (char_id, nonce))

    async def update_marriage_low_score_years(self, tx: aiosqlite.Connection, char_id: int, years: int) -> None:
        """Store the consecutive low-score years needed for NPC divorce checks."""
        await tx.execute(
            "UPDATE marriages SET low_score_years = ? WHERE char_id = ?",
            (max(0, int(years)), char_id),
        )
```

## `lifeline/core/rng.py`

```py
"""Seedable random-number helpers used by game systems and deterministic tests."""
from __future__ import annotations

import hashlib
import random
from typing import Sequence, TypeVar

T = TypeVar("T")


class RNG:
    """Small wrapper around ``random.Random`` with a stable, injectable seed."""

    def __init__(self, seed: int | str | bytes | bytearray | None = None):
        self._random = random.Random(seed)

    def seed(self, seed: int | str | bytes | bytearray | None = None) -> None:
        self._random.seed(seed)

    def fork(self, namespace: str) -> "RNG":
        """Create a deterministic independent stream without consuming this stream."""
        if not isinstance(namespace, str) or not namespace:
            raise ValueError("RNG fork namespace must be a non-empty string")
        state = repr(self._random.getstate()).encode("utf-8")
        seed = hashlib.sha256(state + b"|" + namespace.encode("utf-8")).digest()
        return RNG(seed)

    def random(self) -> float:
        return self._random.random()

    def randint(self, a: int, b: int) -> int:
        return self._random.randint(a, b)

    def randrange(self, *args: int) -> int:
        return self._random.randrange(*args)

    def uniform(self, a: float, b: float) -> float:
        return self._random.uniform(a, b)

    def gauss(self, mu: float, sigma: float) -> float:
        return self._random.gauss(mu, sigma)

    def choice(self, values: Sequence[T]) -> T:
        if not values:
            raise IndexError("Cannot choose from an empty sequence")
        return self._random.choice(values)

    def sample(self, population: Sequence[T], k: int) -> list[T]:
        return self._random.sample(population, k)

    def shuffle(self, values: list[T]) -> None:
        self._random.shuffle(values)

    def weighted_choice(self, values: Sequence[T], weights: Sequence[float]) -> T:
        """Choose one value proportionally to positive weights."""
        if len(values) != len(weights) or not values:
            raise ValueError("values and weights must have the same non-zero length")
        clean_weights = [float(weight) for weight in weights]
        if any(weight < 0 for weight in clean_weights):
            raise ValueError("weights cannot be negative")
        total = sum(clean_weights)
        if total <= 0:
            raise ValueError("at least one weight must be positive")
        threshold = self.random() * total
        cumulative = 0.0
        for value, weight in zip(values, clean_weights):
            cumulative += weight
            if threshold < cumulative:
                return value
        # Protect against floating-point rounding at the upper endpoint.
        return values[-1]
```

## `lifeline/data/names.json`

```json
{
  "schema_version": 1,
  "defaults": {
    "male": ["Alex", "Casey", "Jordan", "Morgan", "Taylor", "Riley", "Sam", "Jamie", "Avery", "Cameron"],
    "female": ["Ari", "Casey", "Jordan", "Morgan", "Taylor", "Riley", "Sam", "Jamie", "Avery", "Cameron"],
    "non_binary": ["Alex", "Casey", "Jordan", "Morgan", "Taylor", "Riley", "Sam", "Jamie", "Avery", "Cameron"]
  },
  "countries": {
    "usa": {
      "male": ["James", "Liam", "Noah", "Elijah", "Lucas", "Mason", "Ethan", "Logan", "Aiden", "Caleb"],
      "female": ["Olivia", "Emma", "Amelia", "Sophia", "Mia", "Harper", "Evelyn", "Luna", "Ella", "Grace"],
      "non_binary": ["Avery", "Riley", "Quinn", "Sage", "Rowan", "Skyler", "Parker", "River", "Emery", "Blake"]
    },
    "in": {
      "male": ["Aarav", "Arjun", "Vivaan", "Aditya", "Ishaan", "Reyansh", "Rohan", "Kabir", "Dev", "Neel"],
      "female": ["Aadhya", "Diya", "Anaya", "Isha", "Kavya", "Mira", "Priya", "Saanvi", "Tara", "Zoya"],
      "non_binary": ["Ari", "Kiran", "Noor", "Ravi", "Samar", "Shakti", "Tashi", "Tej", "Veda", "Yuvan"]
    },
    "india": {
      "male": ["Aarav", "Arjun", "Vivaan", "Aditya", "Ishaan", "Reyansh", "Rohan", "Kabir", "Dev", "Neel"],
      "female": ["Aadhya", "Diya", "Anaya", "Isha", "Kavya", "Mira", "Priya", "Saanvi", "Tara", "Zoya"],
      "non_binary": ["Ari", "Kiran", "Noor", "Ravi", "Samar", "Shakti", "Tashi", "Tej", "Veda", "Yuvan"]
    },
    "uk": {
      "male": ["Oliver", "George", "Arthur", "Harry", "Jack", "Charlie", "Oscar", "Theodore", "Henry", "Alfie"],
      "female": ["Isla", "Amelia", "Ava", "Lily", "Freya", "Florence", "Ivy", "Elsie", "Poppy", "Daisy"],
      "non_binary": ["Avery", "Rory", "Robin", "Alex", "Kit", "Jules", "Ash", "Ellis", "Sasha", "Remy"]
    },
    "ca": {
      "male": ["Liam", "Noah", "Jack", "Benjamin", "William", "Lucas", "Leo", "Theodore", "Oliver", "Thomas"],
      "female": ["Olivia", "Emma", "Charlotte", "Amelia", "Sophia", "Mila", "Chloe", "Ava", "Lily", "Ella"],
      "non_binary": ["Avery", "Rowan", "Quinn", "Sage", "River", "Rory", "Finley", "Emerson", "Parker", "Reese"]
    },
    "au": {
      "male": ["Oliver", "Noah", "Leo", "Henry", "Charlie", "Jack", "Hudson", "Luca", "Thomas", "William"],
      "female": ["Charlotte", "Amelia", "Isla", "Olivia", "Mia", "Ava", "Grace", "Willow", "Harper", "Matilda"],
      "non_binary": ["Billie", "Frankie", "Riley", "Alex", "Charlie", "Sasha", "Jules", "Ash", "Kai", "Sam"]
    },
    "jp": {
      "male": ["Haruto", "Ren", "Yuto", "Sota", "Minato", "Riku", "Aoi", "Itsuki", "Haru", "Kaito"],
      "female": ["Himari", "Yui", "Rin", "Sakura", "Aoi", "Hana", "Mei", "Akari", "Yuna", "Mio"],
      "non_binary": ["Aoi", "Haru", "Ren", "Rin", "Sora", "Yuki", "Noa", "Kaoru", "Michi", "Rei"]
    },
    "fr": {
      "male": ["Gabriel", "Raphaël", "Léo", "Louis", "Arthur", "Jules", "Adam", "Maël", "Lucas", "Hugo"],
      "female": ["Jade", "Louise", "Ambre", "Alba", "Emma", "Rose", "Alice", "Mia", "Lina", "Chloé"],
      "non_binary": ["Camille", "Sacha", "Noa", "Charlie", "Alix", "Lou", "Ariel", "Eden", "Morgan", "Alex"]
    },
    "es": {
      "male": ["Hugo", "Mateo", "Martín", "Leo", "Lucas", "Daniel", "Alejandro", "Pablo", "Adrián", "Manuel"],
      "female": ["Lucía", "Sofía", "Martina", "María", "Julia", "Paula", "Valeria", "Emma", "Alma", "Vega"],
      "non_binary": ["Alex", "Cruz", "Dani", "Noa", "Ángel", "Ariel", "Gael", "Luz", "Mar", "Sol"]
    }
  }
}
```

## `lifeline/tests/test_family.py`

```py
"""Runnable Stage 6 tests for family, dating, support, and divorce rules."""
from __future__ import annotations

import json
from dataclasses import replace
from typing import Any

import pytest

from core.errors import FamilyRequirementError, InteractionLimitReached
from core.family import (
    FamilyService,
    calculate_alimony,
    calculate_divorce_split,
    calculate_fertility_factor,
    can_date_ages,
    proposal_acceptance_chance,
)
from core.repositories.family import FamilyRepository
from core.rng import RNG


async def _set_character(database: Any, character: Any, **changes: Any) -> Any:
    """Persist test-only character state through the database transaction API."""
    updated = replace(character, **changes)
    async with database.transaction() as tx:
        await tx.execute(
            """UPDATE characters SET age = ?, stats_json = ?, data_json = ? WHERE char_id = ?""",
            (
                updated.age,
                json.dumps(updated.stats.to_dict(), separators=(",", ":")),
                json.dumps(updated.to_dict(), separators=(",", ":")),
                updated.char_id,
            ),
        )
    return updated


async def _add_npc(
    repository: FamilyRepository,
    tx: Any,
    *,
    char_id: int,
    name: str = "Jordan",
    age: int = 30,
    gender: str = "female",
    wealth: int = 10_000_000,
    annual_income: int = 5_000_000,
    relation: str = "friend",
    score: int = 80,
    since_age: int = 18,
) -> int:
    """Create one deterministic NPC and connect it to the test life."""
    npc_id = await repository.create_npc(
        tx,
        owner_char_id=char_id,
        name=name,
        gender=gender,
        age=age,
        looks=55,
        smarts=60,
        health=85,
        wealth=wealth,
        occupation="Engineer",
        country="usa",
        annual_income=annual_income,
        prefers_smarts=True,
    )
    await repository.create_relationship(
        tx,
        char_id=char_id,
        npc_id=npc_id,
        relation_type=relation,
        score=score,
        since_age=since_age,
    )
    return npc_id


async def _add_marriage(
    database: Any,
    character: Any,
    *,
    spouse_income: int = 5_000_000,
    prenup: bool = False,
    premarital_cash: int = 0,
    premarital_bank: int = 0,
    start_age: int | None = None,
) -> int:
    """Create an adult spouse and a persisted wedding record for settlement tests."""
    repository = FamilyRepository(database)
    async with database.transaction() as tx:
        spouse_id = await _add_npc(
            repository,
            tx,
            char_id=character.char_id,
            name="Morgan Spouse",
            age=max(18, character.age),
            gender="female",
            annual_income=spouse_income,
            relation="spouse",
            since_age=max(0, character.age - 1),
        )
        start = max(18, character.age - 2) if start_age is None else start_age
        await repository.create_marriage(
            tx,
            char_id=character.char_id,
            spouse_npc_id=spouse_id,
            start_age=start,
            spouse_income=spouse_income,
            prenup=prenup,
            premarital_cash=premarital_cash,
            premarital_bank=premarital_bank,
            wedding_cost=10_000,
            created_at=int(character.last_age_at or 1_800_000_000),
        )
    return spouse_id


@pytest.mark.asyncio
async def test_family_birth_generates_two_parents_and_zero_to_three_siblings(life_engine):
    """Birth setup creates the requested relatives with class-aligned parent wealth."""
    character = await life_engine.create_character(2101, "Family Test", country="in")
    people = await life_engine.db.fetchall(
        """SELECT r.type, r.score, n.age, n.gender, n.wealth, n.country, n.occupation
           FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
           WHERE r.char_id = ?""",
        (character.char_id,),
    )
    parents = [row for row in people if row["type"] == "parent"]
    siblings = [row for row in people if row["type"] == "sibling"]
    assert len(parents) == 2
    assert 0 <= len(siblings) <= 3
    assert {row["gender"] for row in parents} == {"male", "female"}
    assert all(60 <= row["score"] <= 90 for row in parents + siblings)
    assert all(22 <= row["age"] <= 40 and row["country"] == "in" for row in parents)
    wealth_ranges = {
        "poor": (100_000, 1_500_000),
        "working": (1_500_000, 8_000_000),
        "middle": (8_000_000, 60_000_000),
        "upper": (60_000_000, 500_000_000),
        "rich": (500_000_000, 5_000_000_000),
    }
    minimum, maximum = wealth_ranges[character.wealth_class]
    assert all(minimum <= row["wealth"] <= maximum for row in parents + siblings)
    assert all(row["occupation"] == "Student" for row in siblings)


def test_minors_cannot_date_adults_and_minor_age_gap_is_two_years():
    """The engine's reusable dating rule rejects adult/minor pairings explicitly."""
    assert can_date_ages(16, 14) is True
    assert can_date_ages(17, 15) is True
    assert can_date_ages(16, 13) is False
    assert can_date_ages(17, 18) is False
    assert can_date_ages(18, 17) is False
    assert can_date_ages(18, 23) is True
    assert can_date_ages(18, 24) is False


@pytest.mark.asyncio
async def test_date_search_generates_three_minor_candidates_and_engine_rejects_adult(database, life_engine):
    """Date options obey the minor rule and forged adult candidates fail server-side."""
    character = await life_engine.create_character(2102, "Minor Date")
    character = await _set_character(database, character, age=17)
    search = await life_engine.family.find_dates(2102)
    assert len(search.candidates) == 3
    assert all(person["age"] < 18 and abs(person["age"] - 17) <= 2 for person in search.candidates)
    candidate_id = int(search.candidates[0]["npc_id"])
    await database.execute("UPDATE npcs SET age = 18 WHERE npc_id = ?", (candidate_id,))
    with pytest.raises(FamilyRequirementError, match="Dating age rules"):
        await life_engine.family.choose_date(2102, candidate_id, search.nonce)


def test_dating_success_formula_is_clamped_to_five_and_ninety_percent():
    """The date formula weights smarts at 0.4 and clamps chance to 5–90%."""
    from core.family import dating_success_chance

    assert dating_success_chance(
        player_looks=50, npc_looks=45, player_smarts=70, npc_smarts=50,
        npc_prefers_smarts=True, fame=50, npc_wealth=100_000_000,
    ) == 72.0
    assert dating_success_chance(
        player_looks=100, npc_looks=0, player_smarts=100, npc_smarts=0,
        npc_prefers_smarts=True, fame=100, npc_wealth=100_000_000,
    ) == 90.0
    assert dating_success_chance(
        player_looks=0, npc_looks=100, player_smarts=0, npc_smarts=100,
        npc_prefers_smarts=True, fame=0, npc_wealth=0,
    ) == 5.0


@pytest.mark.asyncio
async def test_three_interactions_per_person_per_year(database, life_engine):
    """Each person has an independent persistent three-action annual cap."""
    character = await life_engine.create_character(2103, "Interaction Test")
    await _set_character(database, character, age=18)
    person = await life_engine.family.find_friend(2103)
    npc_id = int(person["npc_id"])
    for _ in range(3):
        await life_engine.family.interact(2103, npc_id, "spend_time")
    with pytest.raises(InteractionLimitReached):
        await life_engine.family.interact(2103, npc_id, "compliment")


@pytest.mark.parametrize(
    ("age", "expected"),
    [(20, 1.0), (29, 1.0), (30, 1.0), (32, 0.88), (35, 0.7), (37, 0.54), (40, 0.3), (43, 0.15), (45, 0.05), (50, 0.0)],
)
def test_fertility_curve_values(age: int, expected: float):
    """The fertility curve has the specified anchors and linear interpolation."""
    assert calculate_fertility_factor(age) == pytest.approx(expected)


def test_proposal_acceptance_bounds():
    """Proposal score and ring bonuses are clamped to valid probability bounds."""
    assert proposal_acceptance_chance(0, 0) == 0
    assert proposal_acceptance_chance(80, 14) == 74
    assert proposal_acceptance_chance(100, 99) == 100


def test_divorce_split_math_with_and_without_prenup():
    """Prenups protect liquid premarital balances while marital property splits evenly."""
    unprotected = calculate_divorce_split(
        cash=1_000_000,
        bank=3_000_000,
        marital_item_values=[400_000, 1_500_000],
        prenup=False,
    )
    protected = calculate_divorce_split(
        cash=1_000_000,
        bank=3_000_000,
        marital_item_values=[400_000, 1_500_000],
        prenup=True,
        premarital_cash=500_000,
        premarital_bank=1_000_000,
    )
    assert unprotected.eligible_assets == 5_900_000
    assert unprotected.spouse_share == 2_950_000
    assert unprotected.protected_assets == 0
    assert protected.eligible_assets == 4_400_000
    assert protected.spouse_share == 2_200_000
    assert protected.protected_assets == 1_500_000


def test_alimony_calculation_uses_twenty_percent_and_half_marriage_duration():
    """Alimony uses the income gap, paying direction, and half the marriage years."""
    player_pays, annual, years = calculate_alimony(10_000_000, 5_000_000, 4)
    assert player_pays is True
    assert annual == 1_000_000
    assert years == 2.0
    player_pays, annual, years = calculate_alimony(3_000_000, 8_000_000, 3)
    assert player_pays is False
    assert annual == 1_000_000
    assert years == 1.5


@pytest.mark.asyncio
async def test_npcs_age_die_and_parent_inheritance_is_shared_and_taxed(database, life_engine):
    """The age tick advances an NPC to death, applies grief, and credits net inheritance."""
    character = await life_engine.create_character(2104, "Inheritance Test")
    parents = await database.fetchall(
        """SELECT n.npc_id, n.wealth FROM npcs AS n JOIN relationships AS r ON r.npc_id=n.npc_id
           WHERE r.char_id=? AND r.type='parent' ORDER BY n.npc_id""",
        (character.char_id,),
    )
    parent_id = int(parents[0]["npc_id"])
    parent_wealth = 150_000_000
    await database.execute(
        "UPDATE npcs SET age = 119, health = 100, wealth = ? WHERE npc_id = ?",
        (parent_wealth, parent_id),
    )
    sibling_count = int((await database.fetchone(
        "SELECT COUNT(*) AS count FROM relationships WHERE char_id=? AND type='sibling'",
        (character.char_id,),
    ))["count"])
    gross = parent_wealth // (sibling_count + 1)
    threshold = 100_000_000
    tax = max(0, gross - threshold) // 10
    expected_inheritance = gross - tax

    outcome = await life_engine.age_up(2104)
    parent = await database.fetchone("SELECT age, is_alive, death_age, wealth FROM npcs WHERE npc_id=?", (parent_id,))
    assert parent["age"] == 120
    assert parent["is_alive"] == 0
    assert parent["death_age"] == 120
    assert parent["wealth"] == 0
    assert outcome.character.bank == expected_inheritance
    assert any("inheritance after tax" in message for message in outcome.log_messages)
    assert outcome.character.stats.happiness < character.stats.happiness


@pytest.mark.asyncio
async def test_child_support_deducts_income_and_stops_at_age_eighteen(database, life_engine):
    """Shared-custody support is 15% of gross income and ends on the 18th birthday."""
    character = await life_engine.create_character(2105, "Support Test")
    character = await _set_character(
        database, character, age=30, cash=10_000_000, wealth_class="middle"
    )
    repository = FamilyRepository(database)
    async with database.transaction() as tx:
        other_parent = int((await repository.parent_relations(tx, character.char_id))[0]["npc_id"])
        child_id = await repository.create_npc(
            tx,
            owner_char_id=character.char_id,
            name="Child Support NPC",
            gender="male",
            age=16,
            looks=50,
            smarts=50,
            health=85,
            wealth=0,
            occupation="Student",
            country="usa",
        )
        await repository.create_relationship(
            tx,
            char_id=character.char_id,
            npc_id=child_id,
            relation_type="child",
            score=85,
            since_age=20,
        )
        await repository.add_child(
            tx,
            npc_id=child_id,
            char_id=character.char_id,
            other_parent_npc_id=other_parent,
            custody="shared",
            child_support=150_000,
        )

    first = replace(character, age=31)
    async with database.transaction() as tx:
        result_one = await life_engine.family.advance_year(
            tx, first, previous_age=30, personal_income=1_000_000, now=101
        )
    assert result_one.character.cash == 9_250_000  # $6,000 shared-care cost + $1,500 support.
    assert int((await database.fetchone("SELECT child_support FROM children WHERE npc_id=?", (child_id,)))["child_support"]) == 150_000

    second = replace(result_one.character, age=32)
    async with database.transaction() as tx:
        result_two = await life_engine.family.advance_year(
            tx, second, previous_age=31, personal_income=1_000_000, now=102
        )
    assert result_two.character.cash == second.cash
    assert int((await database.fetchone("SELECT child_support FROM children WHERE npc_id=?", (child_id,)))["child_support"]) == 0
    assert any("ended for Child Support NPC at age 18" in message for message in result_two.messages)


@pytest.mark.asyncio
async def test_deceased_minor_child_stops_costs_and_support(database, life_engine):
    """A deceased minor remains in records but generates no annual expense or support."""
    character = await life_engine.create_character(2111, "Deceased Child Test")
    character = await _set_character(database, character, age=30, cash=5_000_000)
    repository = FamilyRepository(database)
    async with database.transaction() as tx:
        parent_id = int((await repository.parent_relations(tx, character.char_id))[0]["npc_id"])
        child_id = await repository.create_npc(
            tx,
            owner_char_id=character.char_id,
            name="Deceased Minor",
            gender="female",
            age=12,
            looks=50,
            smarts=50,
            health=0,
            wealth=0,
            occupation="Student",
            country="usa",
        )
        await tx.execute("UPDATE npcs SET is_alive=0, death_age=12 WHERE npc_id=?", (child_id,))
        await repository.create_relationship(
            tx,
            char_id=character.char_id,
            npc_id=child_id,
            relation_type="child",
            score=85,
            since_age=25,
        )
        await repository.add_child(
            tx,
            npc_id=child_id,
            char_id=character.char_id,
            other_parent_npc_id=parent_id,
            custody="shared",
            child_support=200_000,
        )
    async with database.transaction() as tx:
        result = await life_engine.family.advance_year(
            tx, replace(character, age=31), previous_age=30, personal_income=1_000_000, now=104
        )
    assert result.character.cash == character.cash
    support_row = await database.fetchone("SELECT child_support FROM children WHERE npc_id=?", (child_id,))
    assert support_row["child_support"] == 0
    assert any("after their death" in message for message in result.messages)


@pytest.mark.asyncio
async def test_divorce_does_not_create_support_for_a_deceased_minor(database, life_engine):
    """A late divorce clears support for a deceased child instead of opening a new order."""
    character = await life_engine.create_character(2115, "Deceased Custody Test")
    character = await _set_character(database, character, age=30, cash=5_000_000, bank=5_000_000)
    await _add_marriage(database, character, spouse_income=0)
    repository = FamilyRepository(database)
    async with database.transaction() as tx:
        child_id = await repository.create_npc(
            tx,
            owner_char_id=character.char_id,
            name="Child Who Passed",
            gender="male",
            age=12,
            looks=45,
            smarts=55,
            health=0,
            wealth=0,
            occupation="Student",
            country="usa",
        )
        await tx.execute("UPDATE npcs SET is_alive=0, death_age=12 WHERE npc_id=?", (child_id,))
        await repository.create_relationship(
            tx,
            char_id=character.char_id,
            npc_id=child_id,
            relation_type="child",
            score=70,
            since_age=25,
        )
        await repository.add_child(
            tx,
            npc_id=child_id,
            char_id=character.char_id,
            other_parent_npc_id=None,
            custody="shared",
            child_support=100_000,
        )
    outcome = await life_engine.family.divorce(2115)
    assert outcome.children == 0
    support = await database.fetchone("SELECT child_support FROM children WHERE npc_id=?", (child_id,))
    assert support["child_support"] == 0


@pytest.mark.asyncio
async def test_try_for_baby_is_limited_to_once_per_partner_per_year(database, life_engine, monkeypatch):
    """A failed conception cannot be spammed repeatedly in the same simulated year."""
    character = await life_engine.create_character(2112, "Baby Limit Test")
    character = await _set_character(database, character, age=30)
    spouse_id = await _add_marriage(database, character)
    monkeypatch.setattr(life_engine.family.rng, "random", lambda: 1.0)
    success, _ = await life_engine.family.try_for_baby(2112)
    assert not success
    with pytest.raises(FamilyRequirementError, match="once per year"):
        await life_engine.family.try_for_baby(2112)
    assert await database.fetchone("SELECT 1 FROM pregnancies WHERE char_id=?", (character.char_id,)) is None
    assert spouse_id > 0


@pytest.mark.asyncio
async def test_infidelity_choice_can_only_be_resolved_once_per_game_year(database, life_engine):
    """The spouse cannot receive repeated temptation prompts after choosing."""
    character = await life_engine.create_character(2113, "Temptation Limit Test")
    await _set_character(database, character, age=30)
    await _add_marriage(database, character)
    prompt = await life_engine.family.start_infidelity_choice(2113)
    await life_engine.family.resolve_infidelity_choice(2113, prompt.nonce, False)
    with pytest.raises(FamilyRequirementError, match="already been resolved"):
        await life_engine.family.start_infidelity_choice(2113)


@pytest.mark.asyncio
async def test_joint_spouse_income_is_taxed_with_doubled_brackets(database, life_engine):
    """The yearly marriage settlement adds spouse income and taxes the combined gross."""
    character = await life_engine.create_character(2106, "Joint Tax")
    character = await _set_character(database, character, age=30, cash=10_000_000)
    await _add_marriage(database, character, spouse_income=5_000_000)
    from core.family import calculate_joint_tax

    expected_tax = calculate_joint_tax(15_000_000)
    async with database.transaction() as tx:
        result = await life_engine.family.advance_year(
            tx, replace(character, age=31), previous_age=30, personal_income=10_000_000, now=103
        )
    assert result.character.cash == 15_000_000 - expected_tax
    assert any("joint tax" in message for message in result.messages)


class _FailingDivorceRepository(FamilyRepository):
    """Inject an exception after the divorce record write to verify rollback."""

    async def insert_divorce_record(self, tx: Any, **values: Any) -> None:
        await super().insert_divorce_record(tx, **values)
        raise RuntimeError("injected failure after divorce updates")


@pytest.mark.asyncio
async def test_divorce_exception_rolls_back_every_database_change(database, life_engine):
    """A mid-divorce exception leaves balances, marriage, and statistics unchanged."""
    character = await life_engine.create_character(2107, "Rollback Test")
    character = await _set_character(database, character, age=30, cash=8_000_000, bank=3_000_000)
    spouse_id = await _add_marriage(
        database,
        character,
        spouse_income=6_000_000,
        prenup=True,
        premarital_cash=2_000_000,
        premarital_bank=1_000_000,
    )
    service = FamilyService(
        database,
        RNG(991),
        life_engine.locks,
        repository=_FailingDivorceRepository(database),
        clock=lambda: 1_800_000_000,
    )
    before_character = await database.fetchone("SELECT data_json, version FROM characters WHERE char_id=?", (character.char_id,))
    before_marriage = await database.fetchone("SELECT * FROM marriages WHERE char_id=?", (character.char_id,))
    before_relationship = await database.fetchone("SELECT type, score FROM relationships WHERE char_id=? AND npc_id=?", (character.char_id, spouse_id))

    with pytest.raises(RuntimeError, match="injected failure"):
        await service.divorce(2107)

    after_character = await database.fetchone("SELECT data_json, version FROM characters WHERE char_id=?", (character.char_id,))
    after_marriage = await database.fetchone("SELECT * FROM marriages WHERE char_id=?", (character.char_id,))
    after_relationship = await database.fetchone("SELECT type, score FROM relationships WHERE char_id=? AND npc_id=?", (character.char_id, spouse_id))
    assert dict(after_character) == dict(before_character)
    assert dict(after_marriage) == dict(before_marriage)
    assert dict(after_relationship) == dict(before_relationship)
    assert await database.fetchone("SELECT 1 FROM stats_tracking WHERE char_id=?", (character.char_id,)) is None
    assert await database.fetchone("SELECT 1 FROM divorce_records WHERE char_id=?", (character.char_id,)) is None


@pytest.mark.asyncio
async def test_divorce_payment_cascade_never_makes_balances_negative(database, life_engine):
    """Very small balances become debt after the cascade, never negative cash/bank."""
    character = await life_engine.create_character(2108, "Low Funds")
    character = await _set_character(database, character, age=30, cash=50, bank=0, debt_total=0)
    await _add_marriage(database, character, spouse_income=0, prenup=False)
    outcome = await life_engine.family.divorce(2108)
    saved = await life_engine.get_active_character(2108)
    assert saved.cash >= 0
    assert saved.bank >= 0
    assert saved.debt_total >= 0
    assert saved.cash == 0
    assert saved.bank == 0
    assert saved.debt_total > 0
    assert outcome.spouse_share >= 0
    record = await database.fetchone("SELECT lawyer_fee FROM divorce_records WHERE char_id=?", (character.char_id,))
    assert 500_000 <= record["lawyer_fee"] <= 5_000_000


@pytest.mark.asyncio
async def test_adoption_completes_after_one_year_and_newborn_stays_age_zero(database, life_engine):
    """The indexed adoption fee is paid immediately and NPC child arrives one tick later."""
    character = await life_engine.create_character(2109, "Adoption Test")
    await _set_character(database, character, age=21, cash=4_000_000)
    cost = await life_engine.family.adopt(2109)
    assert cost == 3_000_000
    assert await database.fetchone("SELECT 1 FROM children WHERE char_id=?", (character.char_id,)) is None
    await life_engine.age_up(2109)
    child = await database.fetchone(
        """SELECT n.age, n.occupation, c.custody FROM children AS c
           JOIN npcs AS n ON n.npc_id=c.npc_id WHERE c.char_id=?""",
        (character.char_id,),
    )
    assert child["age"] == 0
    assert child["occupation"] == "Student"
    assert child["custody"] == "full"


@pytest.mark.asyncio
async def test_infidelity_choice_is_nonce_backed_and_stored(database, life_engine):
    """Cheating is a one-use owner-side choice persisted for yearly discovery checks."""
    character = await life_engine.create_character(2110, "Temptation Test")
    character = await _set_character(database, character, age=30)
    await _add_marriage(database, character)
    prompt = await life_engine.family.start_infidelity_choice(2110)
    message = await life_engine.family.resolve_infidelity_choice(2110, prompt.nonce, True)
    assert "35%" in message
    affair = await database.fetchone("SELECT spouse_npc_id, started_age, nonce FROM affairs WHERE char_id=?", (character.char_id,))
    assert affair is not None
    assert affair["started_age"] == 30
    assert affair["nonce"] == prompt.nonce
    assert await database.fetchone("SELECT 1 FROM infidelity_prompts WHERE char_id=?", (character.char_id,)) is None
```

## `lifeline/tests/test_migrations.py`

```py
"""Migration repeatability and Stage 2 schema checks."""
from __future__ import annotations

import pytest


@pytest.mark.asyncio
async def test_initialize_is_idempotent(database):
    await database.initialize()
    await database.close()
    await database.initialize()
    versions = await database.fetchall("SELECT version FROM schema_version ORDER BY version")
    assert [row["version"] for row in versions] == [1, 2, 3, 4, 5]
    tables = {row["name"] for row in await database.fetchall(
        "SELECT name FROM sqlite_master WHERE type = 'table'"
    )}
    assert {
        "characters", "life_logs", "schema_version", "education_actions", "jobs",
        "career_history", "career_actions", "npcs", "relationships", "children",
        "yearly_counters", "dating_sessions", "dating_candidates", "marriages",
        "pregnancies", "adoptions", "family_assets", "alimony", "affairs",
        "divorce_records", "stats_tracking", "infidelity_prompts", "infidelity_choices",
    }.issubset(tables)
```
