# LIFELINE Stage 7 — Complete Changed-File Listing

This document contains the full contents of every new or modified source, data, migration, and test file for Stage 7.
The complete project archive is `STAGE7_SOURCE_ARCHIVE.zip`.

Changed/new files: 21

## `lifeline/bot.py`

```python
"""LIFELINE Discord bot entry point."""
from __future__ import annotations

import asyncio
import logging
import secrets

import discord
from discord import app_commands
from discord.ext import commands

from core.config import Config
from core.crime import CrimeService
from core.db import DatabaseManager
from core.errors import GameError
from core.family import FamilyService
from core.locks import UserLockRegistry
from core.rng import RNG

logging.basicConfig(
    level=getattr(logging, Config.from_env().log_level, logging.INFO),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("lifeline")


class LifelineBot(commands.Bot):
    """Main bot class, owning shared database, RNG, and action-lock services."""

    def __init__(self, config: Config | None = None):
        self.config = config or Config.from_env()
        intents = discord.Intents.default()
        # The entertainment cog includes a small message listener; it needs the
        # privileged Message Content intent enabled in the Discord developer portal.
        intents.message_content = True
        super().__init__(
            command_prefix=commands.when_mentioned_or("!"),
            intents=intents,
            help_command=None,
            allowed_mentions=discord.AllowedMentions(
                everyone=False,
                users=True,
                roles=False,
                replied_user=False,
            ),
        )
        self.db: DatabaseManager | None = None
        self.family_service: FamilyService | None = None
        self.crime_service: CrimeService | None = None
        self.rng: RNG = RNG(self.config.rng_seed)
        self.locks = UserLockRegistry()
        self.tree.on_error = self.on_app_command_error

    async def setup_hook(self) -> None:
        """Initialize shared services, extensions, and application commands."""
        self.db = DatabaseManager(self.config.db_path)
        await self.db.initialize()
        self.family_service = FamilyService(self.db, self.rng, self.locks)
        self.crime_service = CrimeService(
            self.db,
            self.rng,
            self.locks,
            family_service=self.family_service,
        )
        await self._load_cogs()

        if self.config.dev_guild_id is not None:
            guild = discord.Object(id=self.config.dev_guild_id)
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
            logger.info("Synced application commands to development guild %s", guild.id)
        else:
            await self.tree.sync()
            logger.info("Synced application commands globally")

    async def _load_cogs(self) -> None:
        """Load the life simulation and entertainment command extensions."""
        for extension in (
            "cogs.life",
            "cogs.education",
            "cogs.career",
            "cogs.relationships",
            "cogs.crime",
            "cogs.prison",
            "cogs.discobot",
        ):
            await self.load_extension(extension)
            logger.info("Loaded extension %s", extension)

    async def on_ready(self) -> None:
        if self.user is not None:
            logger.info("Logged in as %s (ID: %s)", self.user, self.user.id)
        logger.info("Connected to %s guilds", len(self.guilds))
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="lives unfold | /life",
            ),
            status=discord.Status.online,
        )

    async def on_app_command_error(
        self,
        interaction: discord.Interaction,
        error: app_commands.AppCommandError,
    ) -> None:
        """Send safe user-facing errors and retain unexpected errors in logs."""
        if isinstance(error, app_commands.CommandOnCooldown):
            message = f"⏳ Try again in {error.retry_after:.1f} seconds."
        elif isinstance(error, (app_commands.CheckFailure, commands.CheckFailure)):
            message = "❌ You do not have permission to use this command."
        else:
            original = getattr(error, "original", error)
            if isinstance(original, GameError):
                message = original.message
            else:
                error_id = __import__("secrets").token_hex(4)
                logger.error(
                    "Unexpected application-command error (ID %s)",
                    error_id,
                    exc_info=(type(original), original, original.__traceback__),
                )
                message = f"An unexpected error occurred (ID: {error_id}). Please try again later."
        await self._send_error(interaction, message)

    @staticmethod
    async def _send_error(interaction: discord.Interaction, message: str) -> None:
        try:
            if interaction.response.is_done():
                await interaction.followup.send(message, ephemeral=True)
            else:
                await interaction.response.send_message(message, ephemeral=True)
        except discord.HTTPException:
            logger.exception("Could not send an application-command error response")

    async def close(self) -> None:
        logger.info("Shutting down LIFELINE")
        if self.db is not None:
            await self.db.close()
        await super().close()


async def main() -> None:
    config = Config.from_env()
    token = config.require_token()
    bot = LifelineBot(config)
    async with bot:
        await bot.start(token)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
```

## `lifeline/cogs/career.py`

```python
"""Slash commands for employment, work effort, and retirement."""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from core.careers import CareerService, CareerStatus, WorkResult
from core.models import JobAction
from core.money import format_cents


CAREER_CHOICES = [
    app_commands.Choice(name="Retail", value="retail"),
    app_commands.Choice(name="Food Service", value="food_service"),
    app_commands.Choice(name="Office Administration", value="office_admin"),
    app_commands.Choice(name="Creative Arts", value="creative_arts"),
    app_commands.Choice(name="Education", value="teaching"),
    app_commands.Choice(name="Software Engineering", value="software_engineering"),
    app_commands.Choice(name="Healthcare", value="healthcare"),
    app_commands.Choice(name="Research", value="research"),
]


def _status_embed(status: CareerStatus) -> discord.Embed:
    job = status.job
    career = status.career
    embed = discord.Embed(
        title=f"💼 {status.level_title}",
        description=(
            f"**Career:** {career.name}\n"
            f"**Annual salary:** {format_cents(job.salary)}"
            f"{' · Part-time' if job.is_part_time else ''}\n"
            f"**Performance:** {_performance_bar(job.performance)}\n"
            f"**Time in role:** {job.years_in_role} year(s)\n"
            f"**Time in career:** {job.years_in_career} year(s)"
        ),
        color=discord.Color.blue(),
    )
    if status.next_promotion_years is not None:
        embed.add_field(
            name="Promotion path",
            value=(
                f"Next level: **{career.levels[job.level].title}**\n"
                f"Needs performance ≥ 70 and {status.next_promotion_years} year(s) in this role"
            ),
            inline=False,
        )
    else:
        embed.add_field(name="Promotion path", value="You are at the top of this career ladder.", inline=False)
    if job.warnings:
        embed.add_field(name="Performance warnings", value=str(job.warnings), inline=True)
    embed.set_footer(text="Use /career work once per in-game year to affect performance")
    return embed


def _performance_bar(value: int) -> str:
    filled = max(0, min(10, value // 10))
    return f"{'🟩' * filled}{'⬛' * (10 - filled)} **{value}/100**"


def _work_embed(result: WorkResult) -> discord.Embed:
    sign = "+" if result.performance_after >= result.performance_before else ""
    embed = _status_embed(result.career_status)
    embed.title = f"🛠️ Work year · {result.career_status.level_title}"
    embed.description = (
        f"Effort: **{result.action.value.title()}**\n"
        f"Performance: {result.performance_before} → {result.performance_after} ({sign}"
        f"{result.performance_after - result.performance_before})\n"
        f"Annual salary: **{format_cents(result.career_status.job.salary)}**"
    )
    if result.stat_changes:
        effects = " · ".join(
            f"{key.title()} {'+' if delta > 0 else ''}{delta}"
            for key, delta in result.stat_changes.items()
        )
        embed.add_field(name="Stat effects", value=effects, inline=False)
    return embed


class CareerCog(commands.Cog):
    """Career browsing, applications, work actions, and retirement."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.service = CareerService(bot.db, bot.rng, getattr(bot, "locks", None))

    career = app_commands.Group(name="career", description="Find work and manage your career")

    @career.command(name="list", description="Browse available career paths and salaries")
    async def list_careers(self, interaction: discord.Interaction) -> None:
        embed = discord.Embed(
            title="Career paths",
            description="Salary figures are annual gross pay in the game's currency. Requirements apply when you apply.",
            color=discord.Color.blurple(),
        )
        for item in self.service.careers:
            first, last = item.levels[0], item.levels[-1]
            salary = f"{format_cents(first.annual_salary)}–{format_cents(last.annual_salary)} / year"
            requirement = (
                f"Age {item.minimum_age}+ · {item.minimum_education.value.replace('_', ' ').title()} "
                f"· Smarts {item.minimum_smarts}+"
            )
            if item.part_time_allowed:
                requirement += " · part-time available"
            embed.add_field(
                name=f"{item.name} (`{item.id}`)",
                value=f"{salary}\n{requirement}",
                inline=False,
            )
        embed.set_footer(text="Apply with /career apply; salaries are paid when you use /life age")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @career.command(name="apply", description="Apply for a career path")
    @app_commands.describe(career_id="Career path", part_time="Take a reduced-hours role if available")
    @app_commands.choices(career_id=CAREER_CHOICES)
    @app_commands.checks.cooldown(1, 8.0, key=lambda interaction: interaction.user.id)
    async def apply(
        self,
        interaction: discord.Interaction,
        career_id: str,
        part_time: bool = False,
    ) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        status = await self.service.apply(interaction.user.id, career_id, part_time=part_time)
        embed = _status_embed(status)
        embed.description = f"You got the position! Your first paycheck arrives after your next year.\n\n{embed.description}"
        await interaction.followup.send(embed=embed, ephemeral=True)

    @career.command(name="status", description="View your current job and performance")
    async def career_status(self, interaction: discord.Interaction) -> None:
        status = await self.service.status(interaction.user.id)
        await interaction.response.send_message(embed=_status_embed(status), ephemeral=True)

    @career.command(name="history", description="View past and current career records")
    async def career_history(self, interaction: discord.Interaction) -> None:
        records = await self.service.history(interaction.user.id)
        embed = discord.Embed(
            title="Career history",
            description="No career records yet." if not records else "Your employment history for this life.",
            color=discord.Color.blurple(),
        )
        for record in records[:10]:
            years = f"Age {record.start_age}–{record.end_age}" if record.end_age is not None else f"Age {record.start_age}–present"
            end = f" · {record.end_reason.title()}" if record.end_reason else " · Current"
            embed.add_field(
                name=f"{record.career_name} · {record.top_title}",
                value=f"Reached level {record.max_level} · {years}{end}",
                inline=False,
            )
        embed.set_footer(text="Showing the latest 10 records")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @career.command(name="work", description="Choose your work effort for this in-game year")
    @app_commands.describe(effort="Hard, normal, or slack effort")
    @app_commands.choices(effort=[
        app_commands.Choice(name="Work hard — boost performance, gain stress", value="hard"),
        app_commands.Choice(name="Work normally — steady performance", value="normal"),
        app_commands.Choice(name="Slack off — relax, but risk performance", value="slack"),
    ])
    async def work(self, interaction: discord.Interaction, effort: str = "normal") -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await self.service.work(interaction.user.id, effort)
        await interaction.followup.send(embed=_work_embed(result), ephemeral=True)

    @career.command(name="quit", description="Leave your current job")
    async def quit(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        message = await self.service.quit(interaction.user.id)
        await interaction.followup.send(message, ephemeral=True)

    @career.command(name="retire", description="Retire permanently from the workforce (age 60+)")
    async def retire(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        character = await self.service.retire(interaction.user.id)
        await interaction.followup.send(
            f"🌅 **{character.name}** has retired at age {character.age}.",
            ephemeral=True,
        )


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(CareerCog(bot))
```

## `lifeline/cogs/crime.py`

```python
"""Discord slash commands for crime, risk previews, trials, tax choices, and laundering."""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from core.crime import CrimeDefinition, CrimeRecord, CrimeService
from core.money import format_cents
from cogs.crime_views import (
    CrimeConfirmationView,
    TaxChoiceView,
    TrialView,
    crime_preview_embed,
    tax_prompt_embed,
    trial_embed,
)


CRIME_CHOICES = [
    app_commands.Choice(name="Shoplift", value="shoplift"),
    app_commands.Choice(name="Pickpocket", value="pickpocket"),
    app_commands.Choice(name="Vandalism", value="vandalism"),
    app_commands.Choice(name="Car Break-in", value="car_break_in"),
    app_commands.Choice(name="Burglary", value="burglary"),
    app_commands.Choice(name="Grand Theft Auto", value="grand_theft_auto"),
    app_commands.Choice(name="Drug Dealing", value="drug_dealing"),
    app_commands.Choice(name="Fraud / Scam", value="fraud_scam"),
    app_commands.Choice(name="Embezzlement", value="embezzlement"),
    app_commands.Choice(name="Assault", value="assault"),
    app_commands.Choice(name="Armed Robbery", value="armed_robbery"),
    app_commands.Choice(name="Bank Heist", value="bank_heist"),
    app_commands.Choice(name="Murder", value="murder"),
    app_commands.Choice(name="Tax Evasion (event only)", value="tax_evasion"),
]


def _safe(value: str) -> str:
    """Escape Discord markdown and mention syntax in character or catalog text."""
    return discord.utils.escape_mentions(discord.utils.escape_markdown(str(value)))


def _crime_list_embed(crimes: tuple[CrimeDefinition, ...]) -> discord.Embed:
    """List validated crime definitions and age gates without real-world advice."""
    embed = discord.Embed(
        title="Fictional crime catalog",
        description="All outcomes are abstract game rolls. Crime flavor intentionally includes no real-world instructions.",
        color=discord.Color.dark_red(),
    )
    for crime in crimes:
        if crime.commit_enabled:
            risk = f"Base success {crime.base_success:.0f}% · base arrest {crime.base_catch:.0f}%"
            if crime.requires_job:
                risk += " · active job required"
            if crime.violence:
                risk += " · violent offense"
        else:
            risk = "Event-only; cannot be committed with this command."
        embed.add_field(
            name=f"{_safe(crime.name)} · age {crime.min_age}+",
            value=f"{_safe(crime.description)}\n{risk}",
            inline=False,
        )
    embed.set_footer(text="/crime commit previews current risk before an attempt · two attempts per in-game year")
    return embed


def _record_embed(record: CrimeRecord) -> discord.Embed:
    """Render the player-owned criminal record and recent case history."""
    character = record.character
    embed = discord.Embed(
        title=f"Crime record · {_safe(character.name)}",
        description=(
            f"**Criminal record:** {character.criminal_record}\n"
            f"**Notoriety:** {character.notoriety}/100\n"
            f"**Criminal career:** {_safe(record.career_rank or 'Not established')}"
            f" · {record.career_years} paid year(s)\n"
            f"**Unlaundered proceeds:** {format_cents(record.dirty_cash)}\n"
            f"**Tax exposed to audit:** {format_cents(record.evaded_tax)}"
        ),
        color=discord.Color.dark_red(),
    )
    if record.attempts:
        for attempt in record.attempts[:8]:
            status = str(attempt["case_status"]).replace("_", " ").title()
            crime_name = str(attempt["crime_id"]).replace("_", " ").title()
            result = "caught" if bool(attempt["caught"]) else ("success" if bool(attempt["success"]) else "failed")
            value = f"Age {int(attempt['age'])} · {result} · {status} · {format_cents(int(attempt['loot']))} proceeds"
            if int(attempt["sentence_years"]):
                value += f" · sentence {int(attempt['sentence_years'])} year(s)"
            embed.add_field(name=_safe(crime_name), value=value, inline=False)
    else:
        embed.add_field(name="History", value="No recorded attempts yet.", inline=False)
    if record.trial is not None:
        embed.add_field(name="Pending decision", value="A court case is waiting for a lawyer choice below.", inline=False)
    elif record.tax_prompt is not None:
        embed.add_field(name="Pending decision", value="A tax choice is waiting below.", inline=False)
    elif record.preview is not None:
        embed.add_field(name="Pending decision", value="A crime risk preview is ready to confirm or cancel below.", inline=False)
    embed.set_footer(text="A criminal record lowers future job-offer odds; the post-release penalty fades over time.")
    return embed


class CrimeCog(commands.Cog):
    """Owner-safe player commands for Stage 7 crime and court rules."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        service = getattr(bot, "crime_service", None)
        if service is None:
            service = CrimeService(bot.db, bot.rng, getattr(bot, "locks", None))
        self.service: CrimeService = service

    crime = app_commands.Group(name="crime", description="View abstract crime risks and court outcomes")

    @crime.command(name="list", description="Browse fictional crime options and age gates")
    @app_commands.checks.cooldown(1, 8.0, key=lambda interaction: interaction.user.id)
    async def list_crimes(self, interaction: discord.Interaction) -> None:
        crimes = await self.service.list_crimes(interaction.user.id)
        await interaction.response.send_message(embed=_crime_list_embed(crimes), ephemeral=True)

    @crime.command(name="commit", description="Preview risk and choose whether to attempt a fictional crime")
    @app_commands.describe(crime_id="The fictional offense to preview")
    @app_commands.choices(crime_id=CRIME_CHOICES)
    @app_commands.checks.cooldown(1, 10.0, key=lambda interaction: interaction.user.id)
    async def commit(self, interaction: discord.Interaction, crime_id: str) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        preview = await self.service.preview_crime(interaction.user.id, crime_id)
        view = CrimeConfirmationView(interaction.user.id, preview, self.service)
        message = await interaction.followup.send(
            embed=crime_preview_embed(preview), view=view, ephemeral=True, wait=True
        )
        view.bind_message(message)

    @crime.command(name="launder", description="Move available dirty cash to your bank after a 25% fee")
    @app_commands.describe(amount="Whole-dollar amount of dirty cash to launder")
    @app_commands.checks.cooldown(1, 10.0, key=lambda interaction: interaction.user.id)
    async def launder(self, interaction: discord.Interaction, amount: app_commands.Range[int, 1, 1_000_000_000]) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await self.service.launder(interaction.user.id, amount)
        cap_message = (
            "Front-business access removes the ordinary annual cap."
            if result.annual_limit == 0
            else f"Annual cap without a front business: {format_cents(result.annual_limit)} gross."
        )
        embed = discord.Embed(
            title="Laundering complete",
            description=(
                f"Gross removed from dirty cash: **{format_cents(result.gross_amount)}**\n"
                f"Fee (25%): **{format_cents(result.fee_amount)}**\n"
                f"Added to bank: **{format_cents(result.net_amount)}**\n\n{cap_message}"
            ),
            color=discord.Color.gold(),
        )
        await interaction.followup.send(embed=embed, ephemeral=True)

    @crime.command(name="record", description="View your criminal record and resume a pending decision")
    @app_commands.checks.cooldown(1, 8.0, key=lambda interaction: interaction.user.id)
    async def record(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        record = await self.service.crime_record(interaction.user.id)
        view: discord.ui.View | None = None
        embed = _record_embed(record)
        if record.trial is not None:
            view = TrialView(interaction.user.id, record.trial, self.service)
            embed = trial_embed(record.trial)
            embed.add_field(
                name="Record summary",
                value=(
                    f"Criminal record: {record.character.criminal_record} · "
                    f"Notoriety: {record.character.notoriety}/100 · Dirty cash: {format_cents(record.dirty_cash)}"
                ),
                inline=False,
            )
        elif record.tax_prompt is not None:
            view = TaxChoiceView(interaction.user.id, record.tax_prompt, self.service)
            embed = tax_prompt_embed(record.tax_prompt)
        elif record.preview is not None:
            view = CrimeConfirmationView(interaction.user.id, record.preview, self.service)
            embed = crime_preview_embed(record.preview)
        message = await interaction.followup.send(embed=embed, view=view, ephemeral=True, wait=True)
        if view is not None and hasattr(view, "bind_message"):
            view.bind_message(message)


async def setup(bot: commands.Bot) -> None:
    """Register the crime slash-command cog."""
    await bot.add_cog(CrimeCog(bot))
```

## `lifeline/cogs/crime_views.py`

```python
"""Owner-checked, nonce-protected interactive crime, court, and tax views."""
from __future__ import annotations

import time

import discord

from core.crime import (
    CrimeAttemptOutcome,
    CrimePreview,
    CrimeService,
    LAWYER_CONVICTION_CHANCES,
    TaxEvasionPrompt,
    TrialPrompt,
    TrialResolution,
)
from core.errors import GameError
from core.money import format_cents
from core.views import OwnedView


class CrimeConfirmationView(OwnedView):
    """Risk disclosure with one-use confirm and cancel controls."""

    def __init__(self, owner_id: int, preview: CrimePreview, service: CrimeService) -> None:
        super().__init__(owner_id, preview.nonce, timeout=max(30, preview.expires_at - time.time()))
        self.preview = preview
        self.service = service
        self.add_item(_CrimeConfirmButton(preview.nonce))
        self.add_item(_CrimeCancelButton(preview.nonce))

    async def confirm(self, interaction: discord.Interaction) -> None:
        try:
            result = await self.service.confirm_crime(interaction.user.id, self.nonce)
        except GameError as exc:
            self._disable_all()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
            self.stop()
            return
        self._disable_all()
        embed = attempt_embed(result)
        if result.trial is not None:
            trial_view = TrialView(interaction.user.id, result.trial, self.service)
            trial_view.bind_message(interaction.message)
            await interaction.response.edit_message(embed=embed, view=trial_view)
        else:
            await interaction.response.edit_message(embed=embed, view=self)
        self.stop()

    async def cancel(self, interaction: discord.Interaction) -> None:
        try:
            await self.service.cancel_preview(interaction.user.id, self.nonce)
        except GameError as exc:
            self._disable_all()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
            self.stop()
            return
        self._disable_all()
        await interaction.response.edit_message(
            content="Crime confirmation cancelled. No attempt was made.", embed=None, view=self
        )
        self.stop()

    def _disable_all(self) -> None:
        for child in self.children:
            if hasattr(child, "disabled"):
                child.disabled = True


class _CrimeConfirmButton(discord.ui.Button[CrimeConfirmationView]):
    def __init__(self, nonce: str) -> None:
        super().__init__(
            label="Confirm attempt",
            style=discord.ButtonStyle.danger,
            custom_id=f"crime:confirm:{nonce}",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        if isinstance(self.view, CrimeConfirmationView):
            await self.view.confirm(interaction)


class _CrimeCancelButton(discord.ui.Button[CrimeConfirmationView]):
    def __init__(self, nonce: str) -> None:
        super().__init__(
            label="Cancel",
            style=discord.ButtonStyle.secondary,
            custom_id=f"crime:cancel:{nonce}",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        if isinstance(self.view, CrimeConfirmationView):
            await self.view.cancel(interaction)


class TrialView(OwnedView):
    """Three lawyer choices bound to a single owner and persistent court nonce."""

    def __init__(self, owner_id: int, prompt: TrialPrompt, service: CrimeService) -> None:
        super().__init__(owner_id, prompt.nonce, timeout=300)
        self.prompt = prompt
        self.service = service
        for tier, label, style in (
            ("public", "Public defender · free", discord.ButtonStyle.secondary),
            ("standard", "Standard · $10,000", discord.ButtonStyle.primary),
            ("elite", "Elite · $100,000 × index", discord.ButtonStyle.success),
        ):
            self.add_item(_LawyerButton(tier, label, style, prompt.nonce))

    async def resolve(self, interaction: discord.Interaction, tier: str) -> None:
        try:
            result = await self.service.resolve_trial(interaction.user.id, self.nonce, tier)
        except GameError as exc:
            self._disable_all()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
            self.stop()
            return
        self._disable_all()
        await interaction.response.edit_message(embed=trial_resolution_embed(result), view=self)
        self.stop()

    def _disable_all(self) -> None:
        for child in self.children:
            if hasattr(child, "disabled"):
                child.disabled = True


class _LawyerButton(discord.ui.Button[TrialView]):
    def __init__(self, tier: str, label: str, style: discord.ButtonStyle, nonce: str) -> None:
        super().__init__(label=label, style=style, custom_id=f"crime:lawyer:{tier}:{nonce}")
        self.tier = tier

    async def callback(self, interaction: discord.Interaction) -> None:
        if isinstance(self.view, TrialView):
            await self.view.resolve(interaction, self.tier)


class TaxChoiceView(OwnedView):
    """One-use owner-only annual income-tax decision."""

    def __init__(self, owner_id: int, prompt: TaxEvasionPrompt, service: CrimeService) -> None:
        super().__init__(owner_id, prompt.nonce, timeout=300)
        self.prompt = prompt
        self.service = service
        for choice, label, style in (
            ("pay", "Pay tax", discord.ButtonStyle.success),
            ("evade_50", "Skip 50%", discord.ButtonStyle.secondary),
            ("evade_75", "Skip 75%", discord.ButtonStyle.primary),
            ("evade_100", "Skip 100%", discord.ButtonStyle.danger),
        ):
            self.add_item(_TaxButton(choice, label, style, prompt.nonce))

    async def resolve(self, interaction: discord.Interaction, choice: str) -> None:
        try:
            result = await self.service.resolve_tax_choice(interaction.user.id, self.nonce, choice)
        except GameError as exc:
            self._disable_all()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
            self.stop()
            return
        self._disable_all()
        embed = discord.Embed(
            title="Tax decision recorded",
            description=result.message,
            color=discord.Color.orange() if result.evaded_amount else discord.Color.green(),
        )
        embed.add_field(name="Tax assessed", value=format_cents(result.tax_due), inline=True)
        embed.add_field(name="Deferred to audit risk", value=format_cents(result.evaded_amount), inline=True)
        await interaction.response.edit_message(embed=embed, view=self)
        self.stop()

    def _disable_all(self) -> None:
        for child in self.children:
            if hasattr(child, "disabled"):
                child.disabled = True


class _TaxButton(discord.ui.Button[TaxChoiceView]):
    def __init__(self, choice: str, label: str, style: discord.ButtonStyle, nonce: str) -> None:
        super().__init__(label=label, style=style, custom_id=f"crime:tax:{choice}:{nonce}")
        self.choice = choice

    async def callback(self, interaction: discord.Interaction) -> None:
        if isinstance(self.view, TaxChoiceView):
            await self.view.resolve(interaction, self.choice)


def crime_preview_embed(preview: CrimePreview) -> discord.Embed:
    """Display both success and arrest risks before a player confirms."""
    embed = discord.Embed(
        title=f"Crime risk · {preview.crime_name}",
        description=(
            f"{preview.description}\n\n"
            f"**Success chance:** {preview.success_chance:.1f}%\n"
            f"**Arrest chance if successful:** {preview.catch_chance:.1f}%\n"
            f"**Arrest chance if it fails:** {preview.failed_catch_chance:.1f}%\n"
            f"**Possible proceeds:** {format_cents(preview.loot_min)}–{format_cents(preview.loot_max)} (dirty cash)"
        ),
        color=discord.Color.orange(),
    )
    embed.set_footer(text=f"Age {preview.age} · Confirmation expires in about 5 minutes · Maximum two attempts per year")
    return embed


def attempt_embed(result: CrimeAttemptOutcome) -> discord.Embed:
    """Render a neutral fictional outcome without procedural crime details."""
    if result.caught:
        color = discord.Color.red()
    elif result.success:
        color = discord.Color.gold()
    else:
        color = discord.Color.blurple()
    embed = discord.Embed(title=f"Crime outcome · {result.crime_name}", description=result.message, color=color)
    embed.add_field(name="Success roll", value=f"{result.success_chance:.1f}%", inline=True)
    embed.add_field(name="Arrest roll", value=f"{result.catch_chance:.1f}%", inline=True)
    if result.loot:
        embed.add_field(name="Dirty cash", value=format_cents(result.loot), inline=False)
    if result.trial is not None:
        embed.add_field(name="Public defender", value="85% conviction chance · free", inline=False)
        embed.add_field(name="Standard lawyer", value="65% conviction chance · $10,000", inline=False)
        embed.add_field(name="Elite lawyer", value="40% conviction chance · $100,000 × price index", inline=False)
        embed.set_footer(text="Choose counsel below to resolve the pending trial.")
    return embed


def trial_embed(prompt: TrialPrompt) -> discord.Embed:
    """Show available lawyer tiers and the case awaiting a verdict roll."""
    embed = discord.Embed(
        title=f"Trial · {prompt.crime_name}",
        description=(
            "Choose counsel. The displayed percentage is the chance of conviction; "
            "a lower tier costs more but does not guarantee an outcome."
        ),
        color=discord.Color.dark_red(),
    )
    for tier, chance, cost in (
        ("Public defender", LAWYER_CONVICTION_CHANCES["public"], "Free"),
        ("Standard lawyer", LAWYER_CONVICTION_CHANCES["standard"], "$10,000"),
        ("Elite lawyer", LAWYER_CONVICTION_CHANCES["elite"], "$100,000 × price index"),
    ):
        embed.add_field(name=tier, value=f"Conviction chance: {chance:.0f}% · Cost: {cost}", inline=False)
    embed.set_footer(text=f"Case source: {prompt.source.replace('_', ' ')} · Buttons are owner-only and one-use")
    return embed


def trial_resolution_embed(result: TrialResolution) -> discord.Embed:
    """Render a resolved verdict from a ``TrialResolution`` result."""
    return discord.Embed(
        title=f"Trial resolved · {result.crime_name}",
        description=result.message,
        color=discord.Color.red() if result.convicted else discord.Color.green(),
    )


def tax_prompt_embed(prompt: TaxEvasionPrompt) -> discord.Embed:
    """Describe the high-earner tax choice without real-world evasion advice."""
    embed = discord.Embed(
        title="Annual tax choice",
        description=(
            f"Tax assessed: **{format_cents(prompt.tax_due)}**. Choose to pay or defer 50%, 75%, or 100%. "
            "Any skipped amount can trigger a future in-game audit, back taxes, and a sentence."
        ),
        color=discord.Color.orange(),
    )
    embed.set_footer(text="Fictional game decision · Resolve before advancing another year")
    return embed
```

## `lifeline/cogs/life.py`

```python
"""Slash commands for starting and advancing a LIFELINE character."""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from core.events import EventPrompt
from core.life_engine import LifeEngine, YearOutcome
from core.models import Character
from core.views import EventChoiceView, event_embed
from cogs.crime_views import TaxChoiceView, TrialView, tax_prompt_embed, trial_embed


STAT_ORDER = (
    ("health", "❤️ Health"),
    ("happiness", "😊 Happiness"),
    ("smarts", "🧠 Smarts"),
    ("looks", "✨ Looks"),
    ("fitness", "💪 Fitness"),
    ("karma", "🍀 Karma"),
)


def _stat_bar(value: int) -> str:
    filled = max(0, min(10, round(value / 10)))
    return f"{'🟩' * filled}{'⬛' * (10 - filled)} **{value}/100**"


def _character_embed(character: Character) -> discord.Embed:
    status = "Alive" if character.is_alive else f"Deceased at age {character.death_age}"
    embed = discord.Embed(
        title=f"{character.name} · Age {character.age}",
        description=(
            f"**Life stage:** {character.life_stage.value.replace('_', ' ').title()}\n"
            f"**Status:** {status}\n"
            f"**Background:** {character.wealth_class.title()} household · {character.country.upper()}"
        ),
        color=discord.Color.green() if character.is_alive else discord.Color.dark_grey(),
    )
    embed.add_field(
        name="Core stats",
        value="\n".join(f"{label}  {_stat_bar(getattr(character.stats, key))}" for key, label in STAT_ORDER),
        inline=False,
    )
    education = character.education_level.value.replace("_", " ").title()
    if character.current_school:
        education += f" · {character.current_school} ({character.school_years_left} year(s) left)"
    embed.add_field(name="Education", value=education, inline=False)
    embed.set_footer(text=f"Generation {character.generation} · Life #{character.char_id}")
    return embed


def _outcome_description(outcome: YearOutcome) -> str:
    parts = list(outcome.log_messages)
    if outcome.stat_changes:
        changes = []
        label_map = dict(STAT_ORDER)
        for key, delta in outcome.stat_changes.items():
            label = label_map.get(key, key.replace("_", " ").title())
            changes.append(f"{label} {'+' if delta > 0 else ''}{delta}")
        parts.append("**Stat changes:** " + " · ".join(changes))
    if outcome.died:
        parts.append("Start a new life with `/life start` when you're ready.")
    return "\n".join(parts)


class LifeCog(commands.Cog):
    """Birth, status, and age-advance commands."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.engine = LifeEngine(
            bot.db,
            bot.rng,
            getattr(bot, "locks", None),
            family_service=getattr(bot, "family_service", None),
            crime_service=getattr(bot, "crime_service", None),
        )

    life = app_commands.Group(name="life", description="Create and guide your life simulation")

    @life.command(name="start", description="Begin a new life at birth")
    @app_commands.describe(
        name="Your character's name",
        gender="Character gender",
        country="Country or region code, such as usa or in",
    )
    @app_commands.choices(gender=[
        app_commands.Choice(name="Male", value="male"),
        app_commands.Choice(name="Female", value="female"),
        app_commands.Choice(name="Non-binary", value="non_binary"),
    ])
    async def start_life(
        self,
        interaction: discord.Interaction,
        name: str,
        gender: str = "male",
        country: str = "usa",
    ) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        character = await self.engine.create_character(
            interaction.user.id,
            name,
            gender=gender,
            country=country,
        )
        embed = _character_embed(character)
        embed.description = (
            "A new story begins. Your choices will shape the life ahead.\n\n"
            + (embed.description or "")
        )
        await interaction.followup.send(embed=embed, ephemeral=True)

    @life.command(name="status", description="View your current life and stats")
    async def life_status(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        character = await self.engine.get_active_character(interaction.user.id)
        await interaction.followup.send(embed=_character_embed(character), ephemeral=True)

    @life.command(name="age", description="Advance your life by one year")
    @app_commands.checks.cooldown(1, 8.0, key=lambda interaction: interaction.user.id)
    async def age_up(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        outcome = await self.engine.age_up(interaction.user.id)
        if outcome.pending_event is not None:
            prompt: EventPrompt = outcome.pending_event
            view = EventChoiceView(interaction.user.id, prompt, self.engine.events)
            message = await interaction.followup.send(
                embed=event_embed(prompt, lead=_outcome_description(outcome)),
                view=view,
                ephemeral=True,
                wait=True,
            )
            view.bind_message(message)
            return

        if outcome.pending_trial is not None:
            view = TrialView(interaction.user.id, outcome.pending_trial, self.engine.crimes)
            embed = trial_embed(outcome.pending_trial)
            embed.description = f"{_outcome_description(outcome)}\n\n{embed.description or ''}"
            message = await interaction.followup.send(embed=embed, view=view, ephemeral=True, wait=True)
            view.bind_message(message)
            return

        if outcome.pending_tax is not None:
            view = TaxChoiceView(interaction.user.id, outcome.pending_tax, self.engine.crimes)
            embed = tax_prompt_embed(outcome.pending_tax)
            embed.description = f"{_outcome_description(outcome)}\n\n{embed.description or ''}"
            message = await interaction.followup.send(embed=embed, view=view, ephemeral=True, wait=True)
            view.bind_message(message)
            return

        embed = _character_embed(outcome.character)
        embed.description = _outcome_description(outcome)
        if outcome.died:
            embed.color = discord.Color.dark_grey()
        elif outcome.new_stage != outcome.previous_stage:
            embed.color = discord.Color.gold()
        await interaction.followup.send(embed=embed, ephemeral=True)

    @life.command(name="choice", description="Reopen your unresolved life-event choice")
    async def resume_choice(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        prompt = await self.engine.events.get_pending_event(interaction.user.id)
        view = EventChoiceView(interaction.user.id, prompt, self.engine.events)
        message = await interaction.followup.send(
            embed=event_embed(prompt, lead="Your unresolved life event is saved."),
            view=view,
            ephemeral=True,
            wait=True,
        )
        view.bind_message(message)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(LifeCog(bot))
```

## `lifeline/cogs/prison.py`

```python
"""Discord slash commands for prison status and once-yearly prison choices."""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from core.crime import CrimeService
from core.money import format_cents


PRISON_ACTIONS = [
    app_commands.Choice(name="Behave", value="behave"),
    app_commands.Choice(name="Workout", value="workout"),
    app_commands.Choice(name="Study", value="study"),
    app_commands.Choice(name="Riot", value="riot"),
    app_commands.Choice(name="Escape", value="escape"),
    app_commands.Choice(name="Gang protection", value="gang"),
]


def _safe(value: str) -> str:
    """Escape character-controlled text and mentions before adding it to an embed."""
    return discord.utils.escape_mentions(discord.utils.escape_markdown(str(value)))


class PrisonCog(commands.Cog):
    """Prison status and abstract once-per-year custody actions."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        service = getattr(bot, "crime_service", None)
        if service is None:
            service = CrimeService(bot.db, bot.rng, getattr(bot, "locks", None))
        self.service: CrimeService = service

    prison = app_commands.Group(name="prison", description="View custody status and choose a prison action")

    @prison.command(name="status", description="View your current prison sentence and conditions")
    @app_commands.checks.cooldown(1, 8.0, key=lambda interaction: interaction.user.id)
    async def status(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await self.service.prison_status(interaction.user.id)
        character = result.character
        if not result.in_prison:
            description = (
                f"**Status:** Not incarcerated\n"
                f"**Criminal career:** {_safe(result.career_rank or 'Not established')}\n"
                f"**Notoriety:** {character.notoriety}/100\n"
                f"**Criminal record:** {character.criminal_record}"
            )
            if result.escaped:
                description += "\n**Escape status:** At large; annual re-arrest roll is 30%."
            embed = discord.Embed(title=f"Prison status · {_safe(character.name)}", description=description, color=discord.Color.green())
            embed.set_footer(text="Use /crime record to review your history or resume a saved decision.")
            await interaction.followup.send(embed=embed, ephemeral=True)
            return

        sentence = f"{result.years_left} year(s) remaining"
        if result.juvenile_release_age is not None:
            sentence += f" · juvenile release at age {result.juvenile_release_age}"
        embed = discord.Embed(
            title=f"Prison status · {_safe(character.name)}",
            description=(
                f"**Sentence:** {sentence}\n"
                f"**Career rank:** {_safe(result.career_rank or 'Not established')} · {result.career_years} paid year(s)\n"
                f"**Dirty proceeds:** {format_cents(result.dirty_cash)}\n"
                f"**Gang protection:** {'Active' if result.gang_protected else 'None'}\n"
                f"**GED credential:** {'Yes' if character.has_ged else 'No'}\n\n"
                "No wages or ordinary bills are processed while incarcerated; only affordable loan payments are attempted. "
                "Use `/prison action` once this in-game year."
            ),
            color=discord.Color.dark_grey(),
        )
        embed.set_footer(text="Actions are abstract, once-per-year game choices; no real-world instructions are provided.")
        await interaction.followup.send(embed=embed, ephemeral=True)

    @prison.command(name="action", description="Take one prison action for this in-game year")
    @app_commands.describe(action="Choose one prison action; each character gets one per year")
    @app_commands.choices(action=PRISON_ACTIONS)
    @app_commands.checks.cooldown(1, 10.0, key=lambda interaction: interaction.user.id)
    async def action(self, interaction: discord.Interaction, action: str) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await self.service.prison_action(interaction.user.id, action)
        embed = discord.Embed(
            title=f"Prison action · {result.action.replace('_', ' ').title()}",
            description=result.message,
            color=discord.Color.blurple(),
        )
        embed.add_field(name="Age", value=str(result.character.age), inline=True)
        embed.add_field(
            name="Status",
            value=(
                f"Released · record {result.character.criminal_record}"
                if not result.character.in_prison
                else f"{result.character.prison_years_left} year(s) remaining"
            ),
            inline=True,
        )
        await interaction.followup.send(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    """Register the prison slash-command cog."""
    await bot.add_cog(PrisonCog(bot))
```

## `lifeline/core/careers.py`

```python
"""Career catalog, job actions, promotions, and annual salary settlement."""
from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, replace
from typing import Any, Callable, Optional

import aiosqlite

from .data_loader import DataLoader
from .education import EDUCATION_RANK
from .errors import (
    CareerApplicationRejected,
    CharacterDead,
    CharacterInPrison,
    CharacterNotFound,
    ConcurrentUpdate,
    EducationRequirementError,
    JobAlreadyExists,
    NoActiveJob,
    PendingEventExists,
    RetiredCharacter,
    ValidationError,
    WorkAlreadyUsed,
)
from .locks import UserLockRegistry
from .models import Character, EducationLevel, Job, JobAction, Stats
from .money import format_cents, scale_cents
from .rng import RNG
from .repositories.crime import CrimeRepository
from .crime import calculate_job_application_chance
from .validators import validate_career_catalog

logger = logging.getLogger("lifeline.careers")


@dataclass(frozen=True, slots=True)
class CareerLevel:
    title: str
    annual_salary: int
    promotion_years: int


@dataclass(frozen=True, slots=True)
class CareerDefinition:
    id: str
    name: str
    minimum_age: int
    retirement_age: int
    minimum_education: EducationLevel
    minimum_smarts: int
    part_time_allowed: bool
    part_time_multiplier: float
    levels: tuple[CareerLevel, ...]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CareerDefinition":
        return cls(
            id=data["id"],
            name=data["name"],
            minimum_age=int(data["minimum_age"]),
            retirement_age=int(data["retirement_age"]),
            minimum_education=EducationLevel(data["minimum_education"]),
            minimum_smarts=int(data["minimum_smarts"]),
            part_time_allowed=bool(data.get("part_time_allowed", False)),
            part_time_multiplier=float(data.get("part_time_multiplier", 0.5)),
            levels=tuple(
                CareerLevel(
                    title=level["title"],
                    annual_salary=int(level["annual_salary"]),
                    promotion_years=int(level["promotion_years"]),
                )
                for level in data["levels"]
            ),
        )

    def salary_for(self, level: int, *, part_time: bool) -> int:
        if not 1 <= level <= len(self.levels):
            raise ValueError("career level is outside this career's ladder")
        salary = self.levels[level - 1].annual_salary
        return scale_cents(salary, self.part_time_multiplier if part_time else 1.0)


@dataclass(frozen=True, slots=True)
class CareerStatus:
    job: Job
    career: CareerDefinition
    level_title: str
    next_promotion_years: Optional[int]


@dataclass(frozen=True, slots=True)
class CareerHistoryEntry:
    career_name: str
    top_title: str
    max_level: int
    start_age: int
    end_age: Optional[int]
    end_reason: Optional[str]


@dataclass(frozen=True, slots=True)
class WorkResult:
    character: Character
    career_status: CareerStatus
    action: JobAction
    performance_before: int
    performance_after: int
    stat_changes: dict[str, int]


@dataclass(frozen=True, slots=True)
class CareerYearResult:
    character: Character
    messages: tuple[str, ...] = ()


class CareerService:
    """Career actions persisted transactionally alongside the character record."""

    def __init__(
        self,
        db: Any,
        rng: RNG,
        locks: Optional[UserLockRegistry] = None,
        *,
        data_loader: Optional[DataLoader] = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.db = db
        self.rng = rng
        self.hiring_rng = rng.fork("lifeline-stage7-hiring")
        self.locks = locks or UserLockRegistry()
        self.clock = clock
        self.crime_repository = CrimeRepository(db)
        catalog = (data_loader or DataLoader()).load_careers()
        validate_career_catalog(catalog)
        self.careers = tuple(CareerDefinition.from_dict(item) for item in catalog["careers"])
        self._by_id = {career.id: career for career in self.careers}

    def get_career(self, career_id: str) -> CareerDefinition:
        try:
            return self._by_id[career_id]
        except KeyError as exc:
            raise ValidationError("That career is not available. Use `/career list` to browse careers.") from exc

    def eligible_careers(self, character: Character) -> list[CareerDefinition]:
        """Careers for which the character currently meets listed requirements."""
        if character.is_retired or not character.is_alive or character.in_prison:
            return []
        education_rank = max(
            EDUCATION_RANK[character.education_level],
            EDUCATION_RANK[EducationLevel.HIGH_SCHOOL] if character.has_ged else 0,
        )
        return [
            career for career in self.careers
            if career.minimum_age <= character.age <= career.retirement_age
            and education_rank >= EDUCATION_RANK[career.minimum_education]
            and character.stats.smarts >= career.minimum_smarts
        ]

    async def apply(self, user_id: int, career_id: str, *, part_time: bool = False) -> CareerStatus:
        """Start a job after validating age, education, ability, and part-time rules."""
        if not isinstance(user_id, int) or user_id <= 0:
            raise ValidationError("A valid Discord user ID is required.")
        if not isinstance(part_time, bool):
            raise ValidationError("Part-time must be true or false.")
        career = self.get_career(career_id)

        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._load_active(tx, user_id)
                await self._ensure_no_pending_event(tx, character.char_id)
                if character.in_prison:
                    raise CharacterInPrison()
                if await self.crime_repository.other_pending_prompt(tx, character.char_id):
                    raise PendingEventExists("Resolve the pending court or tax buttons before applying for a job.")
                if character.is_retired:
                    raise RetiredCharacter()
                if character.age < career.minimum_age:
                    raise EducationRequirementError(
                        f"You must be at least {career.minimum_age} to apply for {career.name}."
                    )
                if character.age > career.retirement_age:
                    raise EducationRequirementError(f"This career's retirement age is {career.retirement_age}.")
                education_rank = max(
                    EDUCATION_RANK[character.education_level],
                    EDUCATION_RANK[EducationLevel.HIGH_SCHOOL] if character.has_ged else 0,
                )
                if education_rank < EDUCATION_RANK[career.minimum_education]:
                    needed = career.minimum_education.value.replace("_", " ").title()
                    raise EducationRequirementError(f"{career.name} requires {needed} education.")
                if character.stats.smarts < career.minimum_smarts:
                    raise EducationRequirementError(
                        f"{career.name} requires at least {career.minimum_smarts} smarts."
                    )
                if part_time and not career.part_time_allowed:
                    raise EducationRequirementError(f"{career.name} does not offer part-time positions.")

                cursor = await tx.execute("SELECT 1 FROM jobs WHERE char_id = ?", (character.char_id,))
                if await cursor.fetchone():
                    raise JobAlreadyExists()

                await self.crime_repository.initialize_profile(tx, character.char_id)
                hiring_context = await self.crime_repository.get_hiring_context(tx, character.char_id) or {}
                hiring_chance = calculate_job_application_chance(
                    character.criminal_record,
                    age=character.age,
                    last_release_age=(
                        int(hiring_context["last_release_age"])
                        if hiring_context.get("last_release_age") is not None else None
                    ),
                )
                if self.hiring_rng.random() * 100.0 >= hiring_chance:
                    raise CareerApplicationRejected(
                        f"Your application was declined after a background check. Current hiring chance: {hiring_chance:.0f}%."
                    )

                level = 1
                first_level = career.levels[0]
                performance = max(20, min(80, 50 + character.hidden.luck * 2))
                salary = career.salary_for(level, part_time=part_time)
                cursor = await tx.execute(
                    """INSERT INTO jobs
                           (char_id, career_id, level, performance, years_in_role,
                            years_in_career, salary, is_part_time, warnings)
                       VALUES (?, ?, ?, ?, 0, 0, ?, ?, 0)""",
                    (character.char_id, career.id, level, performance, salary, int(part_time)),
                )
                await tx.execute(
                    """INSERT INTO career_history (char_id, career_id, max_level, start_age)
                       VALUES (?, ?, ?, ?)""",
                    (character.char_id, career.id, level, character.age),
                )
                await self._insert_log(
                    tx,
                    character,
                    f"Started work as {first_level.title} in {career.name}, earning {format_cents(salary)} per year.",
                    int(self.clock()),
                )
                job = Job(
                    char_id=character.char_id,
                    career_id=career.id,
                    level=level,
                    performance=performance,
                    salary=salary,
                    is_part_time=part_time,
                )
                return self._status(job, career)

    async def status(self, user_id: int) -> CareerStatus:
        row = await self.db.fetchone(
            """SELECT j.* FROM jobs AS j
               JOIN characters AS c ON c.char_id = j.char_id
               WHERE c.user_id = ? AND c.is_alive = 1 LIMIT 1""",
            (user_id,),
        )
        if row is None:
            raise NoActiveJob()
        job = self._job_from_row(row)
        career = self.get_career(job.career_id)
        return self._status(job, career)

    async def history(self, user_id: int) -> list[CareerHistoryEntry]:
        """Return career records from the user's most recent life."""
        row = await self.db.fetchone(
            "SELECT char_id FROM characters WHERE user_id = ? ORDER BY char_id DESC LIMIT 1",
            (user_id,),
        )
        if row is None:
            raise CharacterNotFound()
        records = await self.db.fetchall(
            """SELECT career_id, max_level, start_age, end_age, end_reason
               FROM career_history WHERE char_id = ? ORDER BY start_age DESC, id DESC""",
            (row["char_id"],),
        )
        history: list[CareerHistoryEntry] = []
        for record in records:
            career = self._by_id.get(record["career_id"])
            max_level = int(record["max_level"])
            top_title = career.levels[max_level - 1].title if career and max_level <= len(career.levels) else record["career_id"]
            history.append(CareerHistoryEntry(
                career_name=career.name if career else str(record["career_id"]),
                top_title=top_title,
                max_level=max_level,
                start_age=int(record["start_age"]),
                end_age=int(record["end_age"]) if record["end_age"] is not None else None,
                end_reason=record["end_reason"],
            ))
        return history

    async def work(self, user_id: int, action: JobAction | str = JobAction.WORK_NORMAL) -> WorkResult:
        """Work once in the current in-game year to influence performance and stats."""
        try:
            selected_action = action if isinstance(action, JobAction) else JobAction(str(action).lower())
        except ValueError as exc:
            raise ValidationError("Choose hard, normal, or slack effort.") from exc

        performance_delta = {
            JobAction.WORK_HARD: 12,
            JobAction.WORK_NORMAL: 7,
            JobAction.WORK_SLACK: -8,
        }[selected_action]
        stress_delta = {
            JobAction.WORK_HARD: 3,
            JobAction.WORK_NORMAL: 1,
            JobAction.WORK_SLACK: -1,
        }[selected_action]
        happiness_delta = -1 if selected_action is JobAction.WORK_HARD else (1 if selected_action is JobAction.WORK_SLACK else 0)

        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._load_active(tx, user_id)
                await self._ensure_no_pending_event(tx, character.char_id)
                if character.in_prison:
                    raise CharacterInPrison()
                if character.is_retired:
                    raise RetiredCharacter()
                cursor = await tx.execute("SELECT * FROM jobs WHERE char_id = ?", (character.char_id,))
                row = await cursor.fetchone()
                if row is None:
                    raise NoActiveJob()
                job = self._job_from_row(row)
                career = self.get_career(job.career_id)
                cursor = await tx.execute(
                    "SELECT 1 FROM career_actions WHERE char_id = ? AND age = ? LIMIT 1",
                    (character.char_id, character.age),
                )
                if await cursor.fetchone():
                    raise WorkAlreadyUsed()

                performance_before = job.performance
                performance_after = max(0, min(100, performance_before + performance_delta))
                updated_job = replace(job, performance=performance_after)
                await tx.execute(
                    "UPDATE jobs SET performance = ? WHERE char_id = ?",
                    (performance_after, character.char_id),
                )

                before = character.stats.to_dict()
                stats = Stats.from_dict(before)
                stats.stress += stress_delta
                stats.happiness += happiness_delta
                stats = stats.clamp_all()
                stat_changes = {
                    key: int(getattr(stats, key) - before[key])
                    for key in ("stress", "happiness")
                    if getattr(stats, key) != before[key]
                }
                updated_character = replace(
                    character,
                    stats=stats,
                    version=expected_version + 1,
                )
                await self._save_character(tx, updated_character, expected_version)
                created_at = int(self.clock())
                await tx.execute(
                    """INSERT INTO career_actions
                           (char_id, age, action, performance_before, performance_after, created_at)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (
                        character.char_id,
                        character.age,
                        selected_action.value,
                        performance_before,
                        performance_after,
                        created_at,
                    ),
                )
                await self._insert_log(
                    tx,
                    updated_character,
                    f"Worked {selected_action.value} as {career.levels[job.level - 1].title}; performance is {performance_after}.",
                    created_at,
                )
                return WorkResult(
                    updated_character,
                    self._status(updated_job, career),
                    selected_action,
                    performance_before,
                    performance_after,
                    stat_changes,
                )

    async def quit(self, user_id: int) -> str:
        """Quit the active job and close its career-history entry."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._load_active(tx, user_id)
                await self._ensure_no_pending_event(tx, character.char_id)
                if character.in_prison:
                    raise CharacterInPrison()
                cursor = await tx.execute("SELECT career_id, level FROM jobs WHERE char_id = ?", (character.char_id,))
                row = await cursor.fetchone()
                if row is None:
                    raise NoActiveJob()
                career = self.get_career(row["career_id"])
                level_title = career.levels[int(row["level"]) - 1].title
                await self._close_job(tx, character.char_id, character.age, "quit")
                await self._insert_log(
                    tx,
                    character,
                    f"Quit the position of {level_title} in {career.name}.",
                    int(self.clock()),
                )
                return f"You quit your job as {level_title}. Your career history has been saved."

    async def retire(self, user_id: int) -> Character:
        """Retire from employment permanently, with an optional current job to close."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._load_active(tx, user_id)
                await self._ensure_no_pending_event(tx, character.char_id)
                if character.in_prison:
                    raise CharacterInPrison()
                if character.is_retired:
                    raise RetiredCharacter("You are already retired.")
                if character.age < 60:
                    raise EducationRequirementError("You must be at least 60 to retire.")
                cursor = await tx.execute("SELECT career_id FROM jobs WHERE char_id = ?", (character.char_id,))
                row = await cursor.fetchone()
                if row is not None:
                    await self._close_job(tx, character.char_id, character.age, "retired")
                updated = replace(character, is_retired=True, version=expected_version + 1)
                await self._save_character(tx, updated, expected_version)
                await self._insert_log(tx, updated, "Retired from the workforce.", int(self.clock()))
                return updated

    async def advance_year(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        previous_age: int,
        now: int,
    ) -> CareerYearResult:
        """Settle one worked year and update promotions/retirement inside age transaction."""
        if character.in_prison:
            return CareerYearResult(character, ("Employment income and work progression were paused during imprisonment.",))

        cursor = await tx.execute("SELECT * FROM jobs WHERE char_id = ?", (character.char_id,))
        row = await cursor.fetchone()
        if row is None:
            return CareerYearResult(character)

        job = self._job_from_row(row)
        career = self.get_career(job.career_id)
        paid_salary = job.salary
        updated_character = replace(character, cash=character.cash + paid_salary)
        messages = [f"Earned {format_cents(paid_salary)} from {career.name} this year."]

        cursor = await tx.execute(
            "SELECT action FROM career_actions WHERE char_id = ? AND age = ? LIMIT 1",
            (character.char_id, previous_age),
        )
        action_row = await cursor.fetchone()
        performance = job.performance if action_row else max(0, job.performance - 2)
        years_in_role = job.years_in_role + 1
        years_in_career = job.years_in_career + 1
        warnings = job.warnings + 1 if performance < 20 else 0

        if not character.is_alive:
            await self._close_job(tx, character.char_id, character.age, "died")
            messages.append(f"Employment at {career.name} ended with the character's death.")
            return CareerYearResult(updated_character, tuple(messages))

        if character.age >= career.retirement_age:
            await self._close_job(tx, character.char_id, character.age, "retired")
            updated_character = replace(updated_character, is_retired=True)
            messages.append(f"Retired from {career.name} at age {character.age}.")
            return CareerYearResult(updated_character, tuple(messages))

        if warnings >= 2:
            await self._close_job(tx, character.char_id, character.age, "fired")
            messages.append(f"Was dismissed from {career.name} after repeated low-performance years.")
            return CareerYearResult(updated_character, tuple(messages))

        level = job.level
        salary = job.salary
        if level < len(career.levels):
            current_level = career.levels[level - 1]
            if years_in_role >= current_level.promotion_years and performance >= 70:
                level += 1
                years_in_role = 0
                salary = career.salary_for(level, part_time=job.is_part_time)
                performance = max(50, performance - 5)
                messages.append(f"Promoted to {career.levels[level - 1].title} in {career.name}!")
                await tx.execute(
                    """UPDATE career_history SET max_level = MAX(max_level, ?)
                       WHERE char_id = ? AND end_age IS NULL""",
                    (level, character.char_id),
                )

        await tx.execute(
            """UPDATE jobs SET level = ?, performance = ?, years_in_role = ?,
                   years_in_career = ?, salary = ?, warnings = ?
               WHERE char_id = ?""",
            (level, performance, years_in_role, years_in_career, salary, warnings, character.char_id),
        )
        return CareerYearResult(updated_character, tuple(messages))

    async def _load_active(self, tx: aiosqlite.Connection, user_id: int) -> tuple[Character, int]:
        cursor = await tx.execute(
            "SELECT char_id, data_json, version FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        row = await cursor.fetchone()
        if row is None:
            cursor = await tx.execute("SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,))
            if await cursor.fetchone():
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.char_id = int(row["char_id"])
        character.version = int(row["version"])
        return character, int(row["version"])

    @staticmethod
    async def _ensure_no_pending_event(tx: aiosqlite.Connection, char_id: int) -> None:
        cursor = await tx.execute("SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1", (char_id,))
        if await cursor.fetchone():
            raise PendingEventExists()

    @staticmethod
    async def _save_character(
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
    ) -> None:
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET stats_json = ?, version = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (stats_json, character.version, data_json, character.char_id, expected_version),
        )
        if cursor.rowcount != 1:
            raise ConcurrentUpdate()

    async def _close_job(self, tx: aiosqlite.Connection, char_id: int, age: int, reason: str) -> None:
        await tx.execute(
            """UPDATE career_history SET end_age = ?, end_reason = ?
               WHERE char_id = ? AND end_age IS NULL""",
            (age, reason, char_id),
        )
        await tx.execute("DELETE FROM jobs WHERE char_id = ?", (char_id,))

    @staticmethod
    async def _insert_log(
        tx: aiosqlite.Connection,
        character: Character,
        text: str,
        created_at: int,
    ) -> None:
        await tx.execute(
            """INSERT INTO life_logs (char_id, age, category, text, importance, created_at)
               VALUES (?, ?, 'career', ?, 2, ?)""",
            (character.char_id, character.age, text, created_at),
        )

    @staticmethod
    def _job_from_row(row: Any) -> Job:
        return Job(
            char_id=int(row["char_id"]),
            career_id=str(row["career_id"]),
            level=int(row["level"]),
            performance=int(row["performance"]),
            years_in_role=int(row["years_in_role"]),
            years_in_career=int(row["years_in_career"]),
            salary=int(row["salary"]),
            is_part_time=bool(row["is_part_time"]),
            warnings=int(row["warnings"]),
        )

    @staticmethod
    def _status(job: Job, career: CareerDefinition) -> CareerStatus:
        level = career.levels[job.level - 1]
        next_years = (
            max(0, level.promotion_years - job.years_in_role)
            if job.level < len(career.levels)
            else None
        )
        return CareerStatus(job, career, level.title, next_years)
```

## `lifeline/core/crime.py`

```python
"""Stage 7 fictional crime, sentencing, laundering, audits, and prison rules.

Crime outcomes are abstract game rolls only. This module contains no real-world
procedural guidance; all persistence is delegated to ``CrimeRepository``.
"""
from __future__ import annotations

import json
import logging
import math
import secrets
import time
from dataclasses import dataclass, replace
from decimal import Decimal, ROUND_HALF_UP
from typing import Any, Callable, Optional

import aiosqlite

from .errors import (
    CharacterDead,
    CharacterInPrison,
    CharacterNotFound,
    CharacterNotInPrison,
    CrimeActionAlreadyUsed,
    CrimeLimitReached,
    CrimeSessionExpired,
    EducationRequirementError,
    InsufficientFunds,
    PendingEventExists,
    TaxDecisionNotFound,
    TrialNotFound,
    ValidationError,
)
from .family import FamilyService
from .locks import UserLockRegistry
from .models import Character, HousingType, Stats
from .money import dollars_to_cents, format_cents, scale_cents
from .repositories.crime import CrimeRepository
from .rng import RNG
from .data_loader import DataLoader

logger = logging.getLogger("lifeline.crime")

LAWYER_CONVICTION_CHANCES: dict[str, float] = {
    "public": 85.0,
    "standard": 65.0,
    "elite": 40.0,
}
LAWYER_FEES: dict[str, int] = {
    "public": 0,
    "standard": dollars_to_cents(10_000),
    "elite": dollars_to_cents(100_000),
}
CAREER_RANKS: tuple[tuple[str, int, int], ...] = (
    ("Street Dealer", 0, dollars_to_cents(10_000)),
    ("Hustler", 20, dollars_to_cents(25_000)),
    ("Crew Leader", 40, dollars_to_cents(50_000)),
    ("Enforcer", 60, dollars_to_cents(100_000)),
    ("Crime Boss", 80, dollars_to_cents(250_000)),
    ("Kingpin", 95, dollars_to_cents(500_000)),
)
TAX_EVENT_INCOME_THRESHOLD = dollars_to_cents(100_000)
LAUNDERING_ANNUAL_CAP = dollars_to_cents(50_000)
MAX_GAME_AGE = 120


@dataclass(frozen=True, slots=True)
class CrimeDefinition:
    """Validated, immutable crime data used by the engine and command UI."""

    id: str
    name: str
    description: str
    min_age: int
    base_success: Optional[float]
    loot_min_dollars: int
    loot_max_dollars: int
    base_catch: Optional[float]
    sentence_min: int
    sentence_max: Optional[int]
    life_sentence: bool
    violence: bool
    success_stat: str
    requires_job: bool
    commit_enabled: bool
    salary_loot_min_fraction: float = 0.0
    salary_loot_max_fraction: float = 0.0
    salary_loot_multiplier: int = 1

    @classmethod
    def from_dict(cls, values: dict[str, Any]) -> "CrimeDefinition":
        """Create a typed definition from a validated JSON object."""
        raw_max = values["sentence_max"]
        return cls(
            id=str(values["id"]),
            name=str(values["name"]),
            description=str(values["description"]),
            min_age=int(values["min_age"]),
            base_success=None if values["base_success"] is None else float(values["base_success"]),
            loot_min_dollars=int(values["loot_min_dollars"]),
            loot_max_dollars=int(values["loot_max_dollars"]),
            base_catch=None if values["base_catch"] is None else float(values["base_catch"]),
            sentence_min=int(values["sentence_min"]),
            sentence_max=None if raw_max == "life" else int(raw_max),
            life_sentence=raw_max == "life",
            violence=bool(values["violence"]),
            success_stat=str(values["success_stat"]),
            requires_job=bool(values["requires_job"]),
            commit_enabled=bool(values["commit_enabled"]),
            salary_loot_min_fraction=float(values.get("salary_loot_min_fraction", 0.0)),
            salary_loot_max_fraction=float(values.get("salary_loot_max_fraction", 0.0)),
            salary_loot_multiplier=int(values.get("salary_loot_multiplier", 1)),
        )


@dataclass(frozen=True, slots=True)
class CrimePreview:
    """Risk summary persisted before a crime can be confirmed."""

    crime_id: str
    crime_name: str
    description: str
    age: int
    nonce: str
    success_chance: float
    catch_chance: float
    failed_catch_chance: float
    loot_min: int
    loot_max: int
    expires_at: int


@dataclass(frozen=True, slots=True)
class CrimeAttemptOutcome:
    """Result of one confirmed fictional crime attempt."""

    crime_id: str
    crime_name: str
    success: bool
    caught: bool
    loot: int
    success_chance: float
    catch_chance: float
    message: str
    trial: Optional["TrialPrompt"] = None


@dataclass(frozen=True, slots=True)
class TrialPrompt:
    """Owner/nonce-bound lawyer selection for one pending case."""

    nonce: str
    attempt_id: int
    crime_id: str
    crime_name: str
    age: int
    source: str


@dataclass(frozen=True, slots=True)
class TrialResolution:
    """Verdict, sentence, fine, and updated life after lawyer selection."""

    character: Character
    crime_name: str
    lawyer_tier: str
    conviction_chance: float
    convicted: bool
    sentence_years: int
    life_sentence: bool
    record_sealed: bool
    fine_paid: int
    message: str


@dataclass(frozen=True, slots=True)
class TaxEvasionPrompt:
    """Persistent annual high-earner tax decision."""

    nonce: str
    age: int
    tax_due: int
    paid_amount: int
    prepaid: bool


@dataclass(frozen=True, slots=True)
class CrimeYearResult:
    """Character, journal messages, and any decision produced by yearly step 12."""

    character: Character
    messages: tuple[str, ...] = ()
    pending_trial: Optional[TrialPrompt] = None
    pending_tax: Optional[TaxEvasionPrompt] = None


@dataclass(frozen=True, slots=True)
class TaxChoiceResult:
    """Tax decision settlement returned to the interactive choice view."""

    character: Character
    choice: str
    tax_due: int
    evaded_amount: int
    message: str


@dataclass(frozen=True, slots=True)
class LaunderResult:
    """Gross cash, fee, and bank deposit from one laundering action."""

    gross_amount: int
    fee_amount: int
    net_amount: int
    annual_limit: int


@dataclass(frozen=True, slots=True)
class PrisonActionResult:
    """Outcome of one prison-only action."""

    character: Character
    action: str
    message: str


@dataclass(frozen=True, slots=True)
class PrisonStatus:
    """Concise prison status and criminal-career details for command output."""

    character: Character
    in_prison: bool
    years_left: int
    juvenile_release_age: Optional[int]
    career_rank: Optional[str]
    career_years: int
    dirty_cash: int
    gang_protected: bool
    escaped: bool


@dataclass(frozen=True, slots=True)
class CrimeRecord:
    """Recent offenses, criminal-career state, and recoverable pending prompts."""

    character: Character
    career_rank: Optional[str]
    career_years: int
    dirty_cash: int
    evaded_tax: int
    attempts: tuple[dict[str, Any], ...]
    trial: Optional[TrialPrompt]
    tax_prompt: Optional[TaxEvasionPrompt]
    preview: Optional[CrimePreview]


def clamp_chance(value: float) -> float:
    """Clamp probability in percentage points to the required 3–97 interval."""
    return max(3.0, min(97.0, float(value)))


def calculate_crime_success_chance(
    base_success: float,
    *,
    smarts: int,
    fitness: int,
    luck: int,
    success_stat: str,
) -> float:
    """Apply the specified skill/physical/luck modifiers to a crime success roll."""
    value = float(base_success)
    if success_stat == "skill":
        value += (int(smarts) - 50) * 0.3
    elif success_stat == "physical":
        value += (int(fitness) - 50) * 0.2
    elif success_stat != "none":
        raise ValueError("success_stat must be none, skill, or physical")
    value += int(luck) * 1.0
    return clamp_chance(value)


def calculate_crime_catch_chance(
    base_catch: float,
    *,
    notoriety: int,
    criminal_record: int,
    failed_attempt: bool = False,
) -> float:
    """Apply notoriety, record, and the 1.5 failed-attempt multiplier."""
    value = float(base_catch) + int(notoriety) * 0.4 + int(criminal_record) * 3.0
    if failed_attempt:
        value *= 1.5
    return clamp_chance(value)


def calculate_job_application_chance(
    criminal_record: int,
    *,
    age: int,
    last_release_age: Optional[int],
) -> float:
    """Apply a permanent per-record penalty and a release penalty that fades over 10 years."""
    count = max(0, int(criminal_record))
    if count == 0:
        return 100.0
    years_since_release = max(0, int(age) - int(last_release_age)) if last_release_age is not None else 0
    release_penalty = max(0.0, 20.0 - 2.0 * years_since_release) if last_release_age is not None else 0.0
    record_penalty = min(95.0, 20.0 * count)
    return max(5.0, 100.0 - record_penalty - release_penalty)


def calculate_single_income_tax(income: int) -> int:
    """Calculate annual single-filer tax using the game's integer-cent tax bands."""
    if income <= 0:
        return 0
    bands = (
        (1_000_000, Decimal("0.10")),
        (4_000_000, Decimal("0.12")),
        (9_000_000, Decimal("0.22")),
        (18_000_000, Decimal("0.24")),
        (30_000_000, Decimal("0.32")),
        (None, Decimal("0.35")),
    )
    remaining = int(income)
    lower = 0
    tax = 0
    for upper, rate in bands:
        width = remaining if upper is None else max(0, min(remaining, upper - lower))
        tax += int((Decimal(width) * rate).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        remaining -= width
        if remaining <= 0:
            break
        if upper is not None:
            lower = upper
    return max(0, min(int(income), tax))


def calculate_laundering(amount: int) -> tuple[int, int]:
    """Return a 25% integer-cent laundering fee and the remaining bank deposit."""
    if isinstance(amount, bool) or not isinstance(amount, int) or amount <= 0:
        raise ValueError("laundering amount must be positive integer cents")
    fee = int((Decimal(amount) * Decimal("0.25")).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    return fee, amount - fee


class CrimeService:
    """Transactional engine for abstract crime, court, tax, and prison gameplay."""

    def __init__(
        self,
        db: Any,
        rng: RNG,
        locks: Optional[UserLockRegistry] = None,
        *,
        repository: Optional[CrimeRepository] = None,
        family_service: Optional[FamilyService] = None,
        data_loader: Optional[DataLoader] = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.db = db
        self.rng = rng.fork("lifeline-stage7-crime")
        self.locks = locks or UserLockRegistry()
        self.repository = repository or CrimeRepository(db)
        self.family_service = family_service or FamilyService(db, rng, self.locks, clock=clock)
        self.clock = clock
        catalog = (data_loader or DataLoader()).load_crimes()
        self.country_severity = {str(key).lower(): float(value) for key, value in catalog["crime_severity_mod"].items()}
        self.crimes = tuple(CrimeDefinition.from_dict(item) for item in catalog["crimes"])
        self._by_id = {crime.id: crime for crime in self.crimes}

    async def initialize_character(self, tx: aiosqlite.Connection, character: Character) -> None:
        """Initialize Stage 7 profile data during birth without changing RNG streams."""
        await self.repository.initialize_profile(tx, character.char_id)

    async def list_crimes(self, user_id: int) -> tuple[CrimeDefinition, ...]:
        """Return the validated crime catalog only to a living player with an active life."""
        async with self.locks.hold(user_id):
            await self._active_character_read(user_id)
            return self.crimes

    async def preview_crime(self, user_id: int, crime_id: str) -> CrimePreview:
        """Persist risk estimates before the player sees a one-use confirm button."""
        crime = self._by_id.get(str(crime_id))
        if crime is None or not crime.commit_enabled:
            raise ValidationError("Choose a committable crime from `/crime list`.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character.char_id)
                await self._check_no_trial_or_tax(tx, character.char_id)
                self._check_not_imprisoned(character)
                if character.age < crime.min_age:
                    raise EducationRequirementError(f"You must be at least {crime.min_age} to attempt {crime.name}.")
                job = await self.repository.get_job(tx, character.char_id)
                if crime.requires_job and job is None:
                    raise EducationRequirementError(f"{crime.name} requires an active job.")
                salary = int(job["salary"]) if job is not None else 0
                success = calculate_crime_success_chance(
                    float(crime.base_success or 0.0),
                    smarts=character.stats.smarts,
                    fitness=character.stats.fitness,
                    luck=character.hidden.luck,
                    success_stat=crime.success_stat,
                )
                catch = calculate_crime_catch_chance(
                    float(crime.base_catch or 0.0),
                    notoriety=character.notoriety,
                    criminal_record=character.criminal_record,
                )
                loot_min, loot_max = self._loot_bounds(crime, character, salary)
                nonce = secrets.token_urlsafe(16)
                now = int(self.clock())
                await self.repository.save_preview(
                    tx,
                    char_id=character.char_id,
                    crime_id=crime.id,
                    age=character.age,
                    nonce=nonce,
                    success_chance=success,
                    catch_chance=catch,
                    loot_min=loot_min,
                    loot_max=loot_max,
                    salary_snapshot=salary,
                    created_at=now,
                    expires_at=now + 300,
                )
                return CrimePreview(
                    crime.id, crime.name, crime.description, character.age, nonce,
                    success, catch, clamp_chance(catch * 1.5), loot_min, loot_max, now + 300,
                )

    async def cancel_preview(self, user_id: int, nonce: str) -> None:
        """Consume a matching risk preview when its owner cancels."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                if not await self.repository.cancel_preview(tx, character.char_id, nonce):
                    raise CrimeSessionExpired()

    async def confirm_crime(self, user_id: int, nonce: str) -> CrimeAttemptOutcome:
        """Resolve a saved risk preview, record the attempt, and open trial if caught."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                self._check_not_imprisoned(character)
                await self._check_pending_event(tx, character.char_id)
                await self._check_no_trial_or_tax(tx, character.char_id)
                now = int(self.clock())
                preview = await self.repository.get_preview(tx, character.char_id, nonce, now)
                if preview is None or int(preview["age"]) != character.age:
                    raise CrimeSessionExpired()
                crime = self._by_id.get(str(preview["crime_id"]))
                if crime is None or not crime.commit_enabled:
                    raise CrimeSessionExpired()
                if crime.requires_job and await self.repository.get_job(tx, character.char_id) is None:
                    raise EducationRequirementError(f"{crime.name} requires an active job.")
                if not await self.repository.claim_crime_attempt(tx, character.char_id, character.age):
                    raise CrimeLimitReached()

                success_chance = float(preview["success_chance"])
                success = self.rng.random() * 100.0 < success_chance
                catch_chance = float(preview["catch_chance"])
                if not success:
                    catch_chance = clamp_chance(catch_chance * 1.5)
                caught = self.rng.random() * 100.0 < catch_chance
                loot = self.rng.randint(int(preview["loot_min"]), int(preview["loot_max"])) if success else 0
                notoriety_gain = self.rng.randint(5, 25)
                karma_loss = self.rng.randint(5, 50)
                stats = replace(character.stats)
                stats.karma = max(0, stats.karma - karma_loss)
                if crime.id == "vandalism" and character.hidden.temperament == "volatile" and success:
                    stats.happiness = min(100, stats.happiness + 5)
                updated = replace(
                    character,
                    cash=character.cash + loot,
                    stats=stats,
                    notoriety=max(0, min(100, character.notoriety + notoriety_gain)),
                    version=expected_version + 1,
                )
                profile = await self.repository.get_profile(tx, character.char_id)
                dirty_cash = int(profile["dirty_cash"]) + loot
                career_level = int(profile["career_level"])
                if career_level < 0:
                    career_level = 0
                else:
                    career_level = max(career_level, self._career_level(updated.notoriety))
                career_rank = CAREER_RANKS[career_level][0]
                attempt_id = await self.repository.insert_attempt(
                    tx,
                    char_id=character.char_id,
                    crime_id=crime.id,
                    age=character.age,
                    source="attempt",
                    success=success,
                    caught=caught,
                    loot=loot,
                    success_chance=success_chance,
                    catch_chance=catch_chance,
                    case_status="pending" if caught else "clear",
                    created_at=now,
                )
                await self.repository.delete_preview(tx, character.char_id, nonce)
                await self.repository.update_profile(
                    tx,
                    character.char_id,
                    dirty_cash=dirty_cash,
                    career_rank=career_rank,
                    career_level=career_level,
                    last_crime_id=crime.id,
                )
                if loot:
                    await self.repository.add_cashflow(tx, character.char_id, character.age, "crime_income", loot, now)
                if career_level >= 4:
                    await self.repository.grant_front_business(tx, character.char_id, character.age, now)
                trial = None
                if caught:
                    trial_nonce = secrets.token_urlsafe(16)
                    await self.repository.create_trial(tx, character.char_id, attempt_id, trial_nonce, now)
                    trial = TrialPrompt(trial_nonce, attempt_id, crime.id, crime.name, character.age, "attempt")
                    message = f"You were caught after the {crime.name} attempt. Choose a lawyer for your trial."
                elif success:
                    message = f"The fictional {crime.name} attempt succeeded; {format_cents(loot)} was added as dirty cash."
                else:
                    message = f"The fictional {crime.name} attempt failed, but you avoided arrest."
                await self.repository.save_character(tx, updated, expected_version)
                await self.repository.insert_life_log(
                    tx, character.char_id, character.age, "crime", message, 4, now
                )
                return CrimeAttemptOutcome(
                    crime.id, crime.name, success, caught, loot,
                    success_chance, catch_chance, message, trial,
                )

    async def resolve_trial(self, user_id: int, nonce: str, lawyer_tier: str) -> TrialResolution:
        """Roll a conviction using the selected lawyer and settle every consequence atomically."""
        tier = str(lawyer_tier).lower()
        if tier not in LAWYER_CONVICTION_CHANCES:
            raise ValidationError("Choose public defender, standard, or elite counsel.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                trial = await self.repository.pending_trial(tx, character.char_id)
                if trial is None or str(trial["nonce"]) != nonce:
                    raise TrialNotFound()
                crime = self._by_id.get(str(trial["crime_id"]))
                if crime is None:
                    raise TrialNotFound("The charge data could not be loaded for this trial.")
                fee = 0 if tier == "public" else LAWYER_FEES[tier]
                if tier == "elite":
                    fee = scale_cents(fee, Decimal(str(character.price_index)))
                if character.cash + character.bank < fee:
                    raise InsufficientFunds(f"You need {format_cents(fee)} for that lawyer. The public defender is free.")
                updated, _ = self._deduct_funds(character, fee)
                convicted = self.rng.random() * 100.0 < LAWYER_CONVICTION_CHANCES[tier]
                fine_paid = 0
                sentence_years = 0
                life_sentence = False
                record_sealed = False
                profile = await self.repository.get_profile(tx, character.char_id)
                if convicted:
                    updated, profile, sentence_years, life_sentence, record_sealed, fine_paid = await self._apply_conviction(
                        tx,
                        updated,
                        expected_version,
                        crime,
                        profile,
                        source=str(trial["source"]),
                        loot=int(trial["loot"]),
                        now=int(self.clock()),
                        sentence_override=None,
                        life_override=False,
                        assess_fine=True,
                    )
                    case_status = "convicted"
                    verdict = "convicted"
                else:
                    updated = replace(updated, version=expected_version + 1)
                    case_status = "acquitted"
                    verdict = "acquitted"
                now = int(self.clock())
                await self.repository.complete_trial(
                    tx,
                    char_id=character.char_id,
                    attempt_id=int(trial["attempt_id"]),
                    case_status=case_status,
                    lawyer_tier=tier,
                    sentence_years=sentence_years,
                    life_sentence=life_sentence,
                    record_sealed=record_sealed,
                    fine_paid=fine_paid,
                    resolved_at=now,
                )
                await self.repository.save_character(tx, updated, expected_version)
                message = (
                    f"The court {verdict} you. Lawyer: {tier.replace('_', ' ')}; "
                    f"conviction chance: {LAWYER_CONVICTION_CHANCES[tier]:.0f}%."
                )
                if convicted:
                    if sentence_years:
                        message += f" Sentence: {sentence_years} year(s){' (life sentence)' if life_sentence else ''}."
                    if record_sealed:
                        message += " Your juvenile record was sealed."
                    if fine_paid:
                        message += f" {format_cents(fine_paid)} was seized from available crime proceeds."
                    if updated.in_prison:
                        message += " You are now in prison."
                await self.repository.insert_life_log(tx, character.char_id, character.age, "crime", message, 5, now)
                return TrialResolution(
                    updated, crime.name, tier, LAWYER_CONVICTION_CHANCES[tier], convicted,
                    sentence_years, life_sentence, record_sealed, fine_paid, message,
                )

    async def launder(self, user_id: int, amount_dollars: int) -> LaunderResult:
        """Convert dirty cash to bank balance after the fixed 25% laundering fee."""
        if isinstance(amount_dollars, bool) or not isinstance(amount_dollars, int) or amount_dollars <= 0:
            raise ValidationError("Enter a positive whole-dollar amount to launder.")
        gross = dollars_to_cents(amount_dollars)
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character.char_id)
                await self._check_no_trial_or_tax(tx, character.char_id)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "launder money")
                profile = await self.repository.get_profile(tx, character.char_id)
                available_dirty = min(int(profile["dirty_cash"]), character.cash)
                if gross > available_dirty:
                    raise InsufficientFunds("You do not have that much available dirty cash to launder.")
                has_front = await self.repository.has_front_business(tx, character.char_id)
                used = await self.repository.laundering_total(tx, character.char_id, character.age)
                limit = 0 if has_front else LAUNDERING_ANNUAL_CAP
                if not has_front and used + gross > LAUNDERING_ANNUAL_CAP:
                    remaining = max(0, LAUNDERING_ANNUAL_CAP - used)
                    raise ValidationError(
                        f"Without a front-business item, the annual laundering cap is {format_cents(LAUNDERING_ANNUAL_CAP)}; "
                        f"you have {format_cents(remaining)} left this year."
                    )
                fee, net = calculate_laundering(gross)
                updated = replace(
                    character,
                    cash=max(0, character.cash - gross),
                    bank=character.bank + net,
                    version=expected_version + 1,
                )
                await self.repository.update_profile(
                    tx, character.char_id, dirty_cash=max(0, int(profile["dirty_cash"]) - gross)
                )
                now = int(self.clock())
                await self.repository.add_laundering(tx, character.char_id, character.age, gross, fee, net, now)
                await self.repository.add_cashflow(tx, character.char_id, character.age, "launder", gross, now)
                await self.repository.add_cashflow(tx, character.char_id, character.age, "fine", fee, now)
                await self.repository.save_character(tx, updated, expected_version)
                await self.repository.insert_life_log(
                    tx, character.char_id, character.age, "crime",
                    f"Laundered {format_cents(gross)}; the fee was {format_cents(fee)}.", 3, now,
                )
                return LaunderResult(gross, fee, net, limit)

    async def resolve_tax_choice(self, user_id: int, nonce: str, choice: str) -> TaxChoiceResult:
        """Resolve one high-earner pay-or-evade event and persist its audit exposure."""
        selected = str(choice).lower()
        evasion_rates = {"pay": 0.0, "evade_50": 0.50, "evade_75": 0.75, "evade_100": 1.0}
        if selected not in evasion_rates:
            raise ValidationError("Choose to pay tax or evade 50%, 75%, or 100%.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                prompt = await self.repository.pending_tax_prompt(tx, character.char_id)
                if prompt is None or str(prompt["nonce"]) != nonce:
                    raise TaxDecisionNotFound()
                tax_due = int(prompt["tax_due"])
                rate = Decimal(str(evasion_rates[selected]))
                evaded = int((Decimal(tax_due) * rate).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
                payable = max(0, tax_due - evaded)
                updated = character
                if bool(prompt["prepaid"]):
                    paid_before = min(int(prompt["paid_amount"]), tax_due)
                    unpaid_before = max(0, tax_due - paid_before)
                    debt_reduction = min(unpaid_before, evaded)
                    refund = min(paid_before, max(0, evaded - debt_reduction))
                    updated = replace(
                        updated,
                        cash=updated.cash + refund,
                        debt_total=max(0, updated.debt_total - debt_reduction),
                    )
                else:
                    updated, unpaid = self._deduct_funds(updated, payable)
                    if unpaid:
                        updated = replace(updated, debt_total=updated.debt_total + unpaid)
                profile = await self.repository.get_profile(tx, character.char_id)
                if evaded:
                    await self.repository.update_profile(
                        tx, character.char_id, evaded_tax=int(profile["evaded_tax"]) + evaded
                    )
                now = int(self.clock())
                await self.repository.record_tax_choice(
                    tx, character.char_id, int(prompt["age"]), selected, tax_due, evaded, now
                )
                if not await self.repository.consume_tax_prompt(tx, character.char_id, nonce):
                    raise TaxDecisionNotFound()
                updated = replace(updated, version=expected_version + 1)
                await self.repository.save_character(tx, updated, expected_version)
                await self.repository.insert_life_log(
                    tx, character.char_id, character.age, "crime",
                    f"Tax decision: {selected.replace('_', ' ')}; {format_cents(evaded)} was deferred.", 3, now,
                )
                message = (
                    f"Tax decision recorded. {format_cents(payable)} was paid or remained withheld; "
                    f"{format_cents(evaded)} is exposed to a future audit."
                )
                return TaxChoiceResult(updated, selected, tax_due, evaded, message)

    async def laundered_amount(self, user_id: int) -> int:
        """Return a read-only estimate of the current year's laundering cap usage."""
        async with self.locks.hold(user_id):
            character = await self._active_character_read(user_id)
            return await self.repository.laundering_total_read(character.char_id, character.age)

    async def get_trial_prompt(self, user_id: int) -> TrialPrompt:
        """Reopen a pending trial after a component timed out or its message was lost."""
        async with self.locks.hold(user_id):
            await self._active_character_read(user_id)
            row = await self.repository.pending_trial_read(user_id)
            if row is None:
                raise TrialNotFound()
            crime = self._by_id.get(str(row["crime_id"]))
            if crime is None:
                raise TrialNotFound("The charge data could not be loaded for this trial.")
            return TrialPrompt(
                str(row["nonce"]), int(row["attempt_id"]), crime.id, crime.name,
                int(row["age"]), str(row["source"]),
            )

    async def get_tax_prompt(self, user_id: int) -> TaxEvasionPrompt:
        """Reopen an unresolved tax choice through the /crime record command."""
        async with self.locks.hold(user_id):
            await self._active_character_read(user_id)
            row = await self.repository.pending_tax_prompt_read(user_id)
            if row is None:
                raise TaxDecisionNotFound()
            return self._tax_prompt_from_row(row)

    async def prison_action(self, user_id: int, action: str) -> PrisonActionResult:
        """Resolve one annual prison action using its own in-game-year counter."""
        selected = str(action).lower()
        if selected not in {"behave", "workout", "study", "riot", "escape", "gang"}:
            raise ValidationError("Choose behave, workout, study, riot, escape, or gang.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                if not character.in_prison:
                    raise CharacterNotInPrison()
                self._check_age(character, 10, "take a prison action")
                await self._check_pending_event(tx, character.char_id)
                if await self.repository.other_pending_prompt(tx, character.char_id):
                    raise PendingEventExists("Resolve your pending crime or tax decision before taking another action.")
                if not await self.repository.claim_action(tx, character.char_id, character.age, "prison_action"):
                    raise CrimeActionAlreadyUsed()
                profile = await self.repository.get_profile(tx, character.char_id)
                updated = character
                message = ""
                if selected == "behave":
                    if self.rng.random() < 0.20:
                        years_left = max(0, character.prison_years_left - 1)
                        updated = replace(updated, prison_years_left=years_left)
                        message = "Good behavior earned one year off your sentence."
                        if years_left == 0:
                            updated, profile = await self._release(tx, updated, profile, juvenile=False)
                            message += " Your sentence is complete; you are released."
                    else:
                        message = "You kept your conduct steady, but no sentence reduction was awarded this year."
                elif selected == "workout":
                    gain = self.rng.randint(3, 6)
                    stats = replace(updated.stats, fitness=min(100, updated.stats.fitness + gain))
                    updated = replace(updated, stats=stats)
                    message = f"A routine workout improved fitness by {gain}."
                elif selected == "study":
                    if not updated.has_ged:
                        updated = replace(updated, has_ged=True)
                        message = "Your study effort earned GED eligibility for future job applications."
                    else:
                        message = "You continued studying and kept your GED credential current."
                elif selected in {"escape", "riot"}:
                    if selected == "riot" and self.rng.random() >= 0.10:
                        message = "The riot did not turn into an escape attempt."
                    else:
                        if selected == "riot":
                            message = "The disturbance created an escape opportunity. "
                        escaped = self.rng.random() < 0.08
                        if escaped:
                            updated = replace(
                                updated,
                                in_prison=False,
                                prison_years_left=0,
                                notoriety=min(100, updated.notoriety + 40),
                            )
                            await self.repository.update_profile(
                                tx, character.char_id, escaped=1, juvenile_release_age=None, gang_protected=0
                            )
                            message += "You escaped. Notoriety rose by 40; re-arrest risk is 30% each year."
                        else:
                            extension = self.rng.randint(3, 5)
                            updated = replace(updated, prison_years_left=updated.prison_years_left + extension)
                            message += f"The escape failed and added {extension} year(s) to your sentence."
                else:
                    notoriety_gain = self.rng.randint(5, 10)
                    updated = replace(updated, notoriety=min(100, updated.notoriety + notoriety_gain))
                    await self.repository.update_profile(tx, character.char_id, gang_protected=1)
                    profile["gang_protected"] = 1
                    message = f"You gained protection from random prison violence; notoriety rose by {notoriety_gain}."
                updated = replace(updated, version=expected_version + 1)
                await self.repository.save_character(tx, updated, expected_version)
                now = int(self.clock())
                await self.repository.insert_life_log(
                    tx, character.char_id, character.age, "prison", message, 3, now
                )
                return PrisonActionResult(updated, selected, message)

    async def prison_status(self, user_id: int) -> PrisonStatus:
        """Return current custody, sentence, gang, and criminal-career status."""
        async with self.locks.hold(user_id):
            character = await self._active_character_read(user_id)
            profile = await self.repository.read_profile(character.char_id) or {}
            return PrisonStatus(
                character=character,
                in_prison=character.in_prison,
                years_left=character.prison_years_left,
                juvenile_release_age=(int(profile["juvenile_release_age"]) if profile.get("juvenile_release_age") is not None else None),
                career_rank=str(profile["career_rank"]) if profile.get("career_rank") else None,
                career_years=int(profile.get("career_years", 0)),
                dirty_cash=int(profile.get("dirty_cash", 0)),
                gang_protected=bool(profile.get("gang_protected", 0)),
                escaped=bool(profile.get("escaped", 0)),
            )

    async def crime_record(self, user_id: int) -> CrimeRecord:
        """Show lifetime criminal outcomes and recover any pending owner-only decision."""
        async with self.locks.hold(user_id):
            character = await self._active_character_read(user_id)
            async with self.db.transaction() as tx:
                await self.repository.initialize_profile(tx, character.char_id)
                profile = await self.repository.get_profile(tx, character.char_id)
                preview_row = await self.repository.preview_for_character(tx, character.char_id)
                if preview_row is not None and int(preview_row["expires_at"]) < int(self.clock()):
                    await self.repository.cancel_preview(tx, character.char_id, str(preview_row["nonce"]))
                    preview_row = None
                trial_row = await self.repository.pending_trial(tx, character.char_id)
                tax_row = await self.repository.pending_tax_prompt(tx, character.char_id)
                history = await self.repository.crime_history_in_transaction(tx, character.char_id, 10)
                preview = self._preview_from_row(preview_row) if preview_row else None
                trial = self._trial_from_row(trial_row) if trial_row else None
                tax = self._tax_prompt_from_row(tax_row) if tax_row else None
                return CrimeRecord(
                    character,
                    str(profile["career_rank"]) if profile["career_rank"] else None,
                    int(profile["career_years"]),
                    int(profile["dirty_cash"]),
                    int(profile["evaded_tax"]),
                    tuple(history),
                    trial,
                    tax,
                    preview,
                )

    async def advance_year(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        previous_age: int,
        personal_income: int,
        household_income: int,
        tax_assessed: int,
        tax_paid: int,
        now: int,
    ) -> CrimeYearResult:
        """Execute Stage 7 annual step 12 inside the existing /life age transaction."""
        if not character.is_alive:
            return CrimeYearResult(character)
        profile = await self.repository.get_profile(tx, character.char_id)
        messages: list[str] = []
        updated = character
        pending_trial: Optional[TrialPrompt] = None
        pending_tax: Optional[TaxEvasionPrompt] = None
        was_in_prison = bool(character.in_prison)

        if was_in_prison:
            updated, profile, prison_messages = await self._advance_prison_year(tx, updated, profile, now)
            messages.extend(prison_messages)
        else:
            updated, profile, audit_messages = await self._run_annual_audit(
                tx, updated, profile, previous_age, household_income, now
            )
            messages.extend(audit_messages)
            if updated.is_alive and not updated.in_prison:
                if bool(profile["escaped"]):
                    if self.rng.random() < 0.30:
                        pending_trial = await self._create_career_arrest_trial(
                            tx, updated, profile, source="escape_rearrest", now=now
                        )
                        messages.append("Authorities located you after your escape; a new trial is pending.")
                if pending_trial is None and int(profile["career_level"]) >= 0:
                    arrest_chance = min(0.97, 0.08 + updated.notoriety * 0.003)
                    if self.rng.random() < arrest_chance:
                        pending_trial = await self._create_career_arrest_trial(
                            tx, updated, profile, source="career_arrest", now=now
                        )
                        messages.append("A yearly criminal-career arrest roll resulted in a pending trial.")
                if pending_trial is None and int(profile["career_level"]) >= 0:
                    updated, profile, income_message = await self._pay_criminal_career_income(
                        tx, updated, profile, now
                    )
                    if income_message:
                        messages.append(income_message)

            if updated.is_alive and not updated.in_prison:
                has_marriage = await self.repository.has_marriage(tx, updated.char_id)
                if has_marriage:
                    annual_tax = max(0, int(tax_assessed))
                    prepaid = True
                    paid_amount = max(0, min(annual_tax, int(tax_paid)))
                else:
                    high_earner = (
                        updated.age >= 18
                        and household_income >= TAX_EVENT_INCOME_THRESHOLD
                    )
                    annual_tax = (
                        calculate_single_income_tax(max(0, int(personal_income)))
                        if high_earner else 0
                    )
                    prepaid = False
                    paid_amount = 0
                if annual_tax > 0 and household_income >= TAX_EVENT_INCOME_THRESHOLD:
                    nonce = secrets.token_urlsafe(16)
                    await self.repository.save_tax_prompt(
                        tx, updated.char_id, nonce, updated.age, annual_tax, prepaid, now,
                        paid_amount=paid_amount,
                    )
                    pending_tax = TaxEvasionPrompt(nonce, updated.age, annual_tax, paid_amount, prepaid)
                    messages.append("A high-earner tax decision is waiting for you.")
                elif annual_tax > 0 and prepaid:
                    await self.repository.add_cashflow(
                        tx, updated.char_id, updated.age, "tax", paid_amount, now
                    )
            elif updated.in_prison:
                messages.append("No wages or ordinary bills were charged during imprisonment.")

        # Notoriety cools by five points each completed year, after arrest/audit rolls.
        notoriety = max(0, updated.notoriety - 5)
        updated = replace(updated, notoriety=notoriety)
        await self.repository.update_profile(tx, updated.char_id, dirty_cash=max(0, int(profile["dirty_cash"])))
        return CrimeYearResult(updated, tuple(messages), pending_trial, pending_tax)

    async def ensure_no_pending_decision(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Block /life age until pending Stage 7 confirmation, trial, or tax buttons resolve."""
        if await self.repository.has_pending_decision(tx, char_id, int(self.clock())):
            raise PendingEventExists("Resolve the crime confirmation, trial, or tax choice before using `/life age`.")

    async def _run_annual_audit(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        profile: dict[str, Any],
        previous_age: int,
        annual_income: int,
        now: int,
    ) -> tuple[Character, dict[str, Any], list[str]]:
        """Roll annual tax and unlaundered-cash audits and settle a detected evasion."""
        messages: list[str] = []
        totals = await self.repository.cashflow_totals(tx, character.char_id, previous_age)
        income = int(totals.get("crime_income", 0)) + int(totals.get("career_income", 0))
        laundered = int(totals.get("launder", 0))
        threshold = scale_cents(dollars_to_cents(10_000), Decimal(str(character.price_index)))
        cash_flag = max(0, income - laundered) > threshold
        evaded = int(profile["evaded_tax"])
        auditable = evaded > 0 or int(annual_income) >= TAX_EVENT_INCOME_THRESHOLD or cash_flag
        tax_chance = min(0.97, 0.05 + character.notoriety * 0.002) if auditable else 0.0
        cash_chance = 0.20 if cash_flag else 0.0
        chance = 1.0 - (1.0 - tax_chance) * (1.0 - cash_chance)
        triggered = chance > 0 and self.rng.random() < chance
        sentence_years = 0
        back_taxes = 0
        updated = character
        if triggered and evaded > 0:
            back_taxes = evaded * 2
            updated, unpaid = self._deduct_funds(updated, back_taxes)
            if unpaid:
                updated = replace(updated, debt_total=updated.debt_total + unpaid)
            await self.repository.update_profile(tx, character.char_id, evaded_tax=0)
            await self.repository.add_cashflow(tx, character.char_id, character.age, "audit", back_taxes, now)
            messages.append(f"A tax audit found evaded taxes; {format_cents(back_taxes)} in back taxes was assessed.")
            if self.rng.random() < 0.30:
                tax_crime = self._by_id["tax_evasion"]
                source_record = await self.repository.insert_attempt(
                    tx,
                    char_id=character.char_id,
                    crime_id=tax_crime.id,
                    age=character.age,
                    source="tax_audit",
                    success=False,
                    caught=True,
                    loot=0,
                    success_chance=0.0,
                    catch_chance=chance * 100.0,
                    case_status="convicted",
                    created_at=now,
                )
                base_sentence = self.rng.randint(tax_crime.sentence_min, int(tax_crime.sentence_max or 5))
                updated, profile, sentence_years, _, _, _ = await self._apply_conviction(
                    tx,
                    updated,
                    character.version,
                    tax_crime,
                    profile,
                    source="tax_audit",
                    loot=0,
                    now=now,
                    sentence_override=base_sentence,
                    life_override=False,
                    assess_fine=False,
                )
                await self.repository.resolve_audit_attempt(
                    tx, source_record, sentence_years=sentence_years, resolved_at=now
                )
                messages.append(f"The tax audit also resulted in a {sentence_years}-year sentence.")
        elif triggered:
            messages.append("A financial audit reviewed the year's activity and found no tax evasion.")
        elif auditable:
            messages.append("The year's tax and cash activity passed its random audit roll.")
        await self.repository.record_audit(
            tx,
            character.char_id,
            character.age,
            chance * 100.0,
            triggered,
            bool(triggered and evaded > 0),
            back_taxes,
            sentence_years,
            "caught" if triggered and evaded > 0 else ("reviewed" if triggered else "not_triggered"),
            now,
        )
        return updated, profile, messages

    async def _create_career_arrest_trial(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        profile: dict[str, Any],
        *,
        source: str,
        now: int,
    ) -> TrialPrompt:
        """Open a lawyer-choice trial after a yearly career or escape arrest roll."""
        crime_id = str(profile["last_crime_id"] or "shoplift")
        crime = self._by_id.get(crime_id, self._by_id["shoplift"])
        attempt_id = await self.repository.insert_attempt(
            tx,
            char_id=character.char_id,
            crime_id=crime.id,
            age=character.age,
            source=source,
            success=False,
            caught=True,
            loot=0,
            success_chance=0.0,
            catch_chance=min(97.0, (0.30 if source == "escape_rearrest" else 0.08 + character.notoriety * 0.003) * 100.0),
            case_status="pending",
            created_at=now,
        )
        nonce = secrets.token_urlsafe(16)
        await self.repository.create_trial(tx, character.char_id, attempt_id, nonce, now)
        return TrialPrompt(nonce, attempt_id, crime.id, crime.name, character.age, source)

    async def _pay_criminal_career_income(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        profile: dict[str, Any],
        now: int,
    ) -> tuple[Character, dict[str, Any], str]:
        """Pay yearly illegal income into cash as dirty proceeds and advance career rank."""
        current_level = max(0, int(profile["career_level"]))
        desired_level = max(current_level, self._career_level(character.notoriety))
        rank_name, _, income = CAREER_RANKS[desired_level]
        updated = character
        messages: list[str] = []
        if desired_level > current_level:
            messages.append(f"Your criminal career advanced to {rank_name}.")
        updated = replace(updated, cash=updated.cash + income)
        profile["dirty_cash"] = int(profile["dirty_cash"]) + income
        profile["career_level"] = desired_level
        profile["career_rank"] = rank_name
        profile["career_years"] = int(profile["career_years"]) + 1
        await self.repository.update_profile(
            tx,
            character.char_id,
            career_level=desired_level,
            career_rank=rank_name,
            career_years=int(profile["career_years"]),
            dirty_cash=int(profile["dirty_cash"]),
        )
        await self.repository.add_cashflow(tx, character.char_id, character.age, "career_income", income, now)
        if desired_level >= 4:
            await self.repository.grant_front_business(tx, character.char_id, character.age, now)
            profile["front_business"] = 1
        messages.append(f"Criminal-career income added {format_cents(income)} as dirty cash.")
        return updated, profile, " ".join(messages)

    async def _advance_prison_year(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        profile: dict[str, Any],
        now: int,
    ) -> tuple[Character, dict[str, Any], list[str]]:
        """Pay affordable loans, tick a prison sentence, and resolve non-graphic violence."""
        messages: list[str] = []
        updated = character
        for loan in await self.repository.active_loans(tx, character.char_id):
            payment = min(int(loan["annual_payment"]), int(loan["balance"]))
            if payment <= 0:
                continue
            if updated.cash + updated.bank >= payment:
                cash_paid = min(max(0, updated.cash), payment)
                bank_paid = payment - cash_paid
                updated = replace(
                    updated,
                    cash=max(0, updated.cash - cash_paid),
                    bank=max(0, updated.bank - bank_paid),
                )
                await self.repository.pay_loan(tx, int(loan["loan_id"]), payment)
                messages.append(f"A loan payment of {format_cents(payment)} was auto-paid from available funds.")
            else:
                await self.repository.miss_loan_payment(tx, int(loan["loan_id"]))
                messages.append("A loan payment was missed because the bank balance was not enough.")
        years_left = max(0, updated.prison_years_left - 1)
        updated = replace(updated, prison_years_left=years_left)
        juvenile_release = profile.get("juvenile_release_age")
        release_due = years_left == 0 or (
            juvenile_release is not None and updated.age >= int(juvenile_release)
        )
        if release_due:
            updated, profile = await self._release(tx, updated, profile, juvenile=juvenile_release is not None)
            messages.append("Your sentence ended and you were released from custody.")
        elif not bool(profile["gang_protected"]) and self.rng.random() < 0.05:
            damage = self.rng.randint(2, 8)
            stats = replace(updated.stats)
            stats.health = max(0, stats.health - damage)
            stats.happiness = max(0, stats.happiness - self.rng.randint(2, 6))
            updated = replace(updated, stats=stats)
            messages.append("A non-graphic prison disturbance lowered your health and happiness.")
            if stats.health <= 0 or self.rng.random() < 0.02:
                updated = replace(
                    updated,
                    is_alive=False,
                    in_prison=False,
                    prison_years_left=0,
                    death_cause="prison violence",
                    death_age=updated.age,
                    died_at=now,
                )
                messages.append(f"Life ended at age {updated.age} after a prison-violence event.")
        elif bool(profile["gang_protected"]):
            messages.append("Gang protection deterred random prison violence this year.")
        return updated, profile, messages

    async def _release(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        profile: dict[str, Any],
        *,
        juvenile: bool,
    ) -> tuple[Character, dict[str, Any]]:
        """Clear prison flags and record the release age for hiring recovery."""
        updated = replace(character, in_prison=False, prison_years_left=0)
        profile["last_release_age"] = updated.age
        profile["juvenile_release_age"] = None
        profile["gang_protected"] = 0
        profile["escaped"] = 0
        await self.repository.update_profile(
            tx,
            character.char_id,
            last_release_age=updated.age,
            juvenile_release_age=None,
            gang_protected=0,
            escaped=0,
        )
        if juvenile:
            profile["juvenile_release_age"] = None
        return updated, profile

    async def _apply_conviction(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
        crime: CrimeDefinition,
        profile: dict[str, Any],
        *,
        source: str,
        loot: int,
        now: int,
        sentence_override: Optional[int],
        life_override: bool,
        assess_fine: bool,
        create_trial: bool = True,
    ) -> tuple[Character, dict[str, Any], int, bool, bool, int]:
        """Apply conviction consequences, including juvenile record-sealing chance."""
        updated = character
        juvenile = character.age < 18
        record_sealed = juvenile and self.rng.random() < 0.50
        if not record_sealed:
            updated = replace(updated, criminal_record=max(0, updated.criminal_record + 1))
        sentence_years, life_sentence, juvenile_release_age = self._sentence(
            crime, character, sentence_override=sentence_override, life_override=life_override
        )
        if sentence_years > 0:
            custody_years = sentence_years
            if juvenile:
                custody_years = min(sentence_years, max(1, 18 - character.age))
                juvenile_release_age = min(18, character.age + custody_years)
            elif life_sentence:
                custody_years = max(1, 120 - character.age)
            updated = replace(updated, in_prison=True, prison_years_left=custody_years)
            if juvenile:
                await self.repository.update_profile(
                    tx, character.char_id, juvenile_release_age=juvenile_release_age
                )
            else:
                await self.repository.update_profile(tx, character.char_id, juvenile_release_age=None)
            fired = await self.repository.fire_job_for_prison(tx, character.char_id, character.age)
            if fired:
                await self.repository.insert_life_log(
                    tx, character.char_id, character.age, "career",
                    "Employment ended because of a prison sentence.", 4, now,
                )
            if updated.housing_type is HousingType.RENT:
                updated = replace(updated, housing_type=HousingType.HOMELESS, housing_item_id=None, rent_amount=0)

        profile = await self.repository.get_profile(tx, character.char_id)
        fine_paid = 0
        if assess_fine and loot > 0:
            target_fine = int((Decimal(loot) * Decimal("0.50")).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
            available_dirty = min(int(profile["dirty_cash"]), max(0, updated.cash))
            fine_paid = min(target_fine, available_dirty)
            if fine_paid:
                updated = replace(updated, cash=max(0, updated.cash - fine_paid))
                profile["dirty_cash"] = max(0, int(profile["dirty_cash"]) - fine_paid)
                await self.repository.update_profile(tx, character.char_id, dirty_cash=int(profile["dirty_cash"]))
                await self.repository.add_cashflow(tx, character.char_id, character.age, "fine", fine_paid, now)

        for relation in await self.repository.relationship_scores(tx, character.char_id):
            penalty = self.rng.randint(10, 30)
            await self.repository.set_relationship_score(
                tx,
                character.char_id,
                int(relation["npc_id"]),
                max(0, int(relation["score"]) - penalty),
            )
        if await self.repository.has_marriage(tx, character.char_id) and self.rng.random() < 0.25:
            divorce, updated = await self.family_service._divorce_in_tx(
                tx,
                updated,
                expected_version,
                reason="npc_initiated",
                now=now,
                save_character=False,
            )
            logger.info("Automatic spouse divorce after conviction for character %s", character.char_id)
        updated = replace(updated, version=expected_version + 1)
        return updated, profile, sentence_years, life_sentence, record_sealed, fine_paid

    def _sentence(
        self,
        crime: CrimeDefinition,
        character: Character,
        *,
        sentence_override: Optional[int],
        life_override: bool,
    ) -> tuple[int, bool, Optional[int]]:
        """Roll and country-scale a sentence, halving juvenile terms and capping release at 18."""
        if sentence_override is not None:
            base_years = max(0, int(sentence_override))
            life = bool(life_override)
        elif crime.sentence_max is None:
            lifetime_remaining = max(crime.sentence_min, 120 - character.age)
            base_years = self.rng.randint(crime.sentence_min, lifetime_remaining)
            life = base_years >= max(1, 120 - character.age)
        elif crime.sentence_min == crime.sentence_max:
            base_years = crime.sentence_min
            life = False
        else:
            base_years = self.rng.randint(crime.sentence_min, int(crime.sentence_max))
            life = False
        severity = self._severity(character.country)
        scaled = 0 if base_years == 0 else max(1, math.ceil(base_years * severity))
        scaled = min(scaled, max(0, 120 - character.age))
        juvenile_release_age: Optional[int] = None
        if character.age < 18 and scaled > 0:
            scaled = max(1, math.ceil(scaled / 2))
            juvenile_release_age = min(18, character.age + scaled)
        return scaled, life, juvenile_release_age

    def _loot_bounds(self, crime: CrimeDefinition, character: Character, salary: int) -> tuple[int, int]:
        """Scale catalog dollars or salary-linked loot into integer cents."""
        if crime.requires_job:
            minimum = scale_cents(
                salary,
                Decimal(str(crime.salary_loot_min_fraction * crime.salary_loot_multiplier))
                * Decimal(str(character.price_index)),
            )
            maximum = scale_cents(
                salary,
                Decimal(str(crime.salary_loot_max_fraction * crime.salary_loot_multiplier))
                * Decimal(str(character.price_index)),
            )
            return min(minimum, maximum), max(minimum, maximum)
        minimum = scale_cents(dollars_to_cents(crime.loot_min_dollars), Decimal(str(character.price_index)))
        maximum = scale_cents(dollars_to_cents(crime.loot_max_dollars), Decimal(str(character.price_index)))
        return min(minimum, maximum), max(minimum, maximum)

    async def _active_character(
        self,
        tx: aiosqlite.Connection,
        user_id: int,
    ) -> tuple[Character, int]:
        """Load an active living character and its concurrency version."""
        row = await self.repository.load_active(tx, user_id)
        if row is None:
            if await self.repository.has_any_life(tx, user_id):
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.char_id = int(row["char_id"])
        character.user_id = int(row["user_id"])
        character.version = int(row["version"])
        if not character.is_alive:
            raise CharacterDead()
        return character, int(row["version"])

    async def _active_character_read(self, user_id: int) -> Character:
        """Load the user's living character for a read-only game command."""
        row = await self.repository.load_active_read(user_id)
        if row is None:
            if await self.repository.has_any_life_read(user_id):
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.char_id = int(row["char_id"])
        character.user_id = int(row["user_id"])
        character.version = int(row["version"])
        if not character.is_alive:
            raise CharacterDead()
        return character

    async def _check_pending_event(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Keep unresolved Stage 3 choices ahead of crime actions."""
        if await self.repository.has_pending_event(tx, char_id):
            raise PendingEventExists()

    async def _check_no_trial_or_tax(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Prevent replacing a pending court or tax choice with another criminal action."""
        if await self.repository.other_pending_prompt(tx, char_id):
            raise PendingEventExists("Resolve the pending court or tax buttons before starting another crime action.")

    @staticmethod
    def _check_not_imprisoned(character: Character) -> None:
        """Enforce prison gates inside the engine."""
        if character.in_prison:
            raise CharacterInPrison()

    @staticmethod
    def _check_age(character: Character, minimum: int, action: str) -> None:
        """Enforce an age gate in the service rather than trusting slash-command UI."""
        if character.age < minimum:
            raise EducationRequirementError(f"You must be at least {minimum} to {action}.")

    def _severity(self, country: str) -> float:
        """Get a country-specific crime_severity_mod sentencing modifier, with an explicit neutral default."""
        return self.country_severity.get(country.lower(), self.country_severity["default"])

    @staticmethod
    def _career_level(notoriety: int) -> int:
        """Return the highest criminal-career tier unlocked by notoriety."""
        selected = 0
        for index, (_, threshold, _) in enumerate(CAREER_RANKS):
            if int(notoriety) >= threshold:
                selected = index
        return selected

    @staticmethod
    def _deduct_funds(character: Character, amount: int) -> tuple[Character, int]:
        """Deduct from cash then bank, keeping both nonnegative and returning unpaid cents."""
        remaining = max(0, int(amount))
        cash_paid = min(max(0, character.cash), remaining)
        remaining -= cash_paid
        bank_paid = min(max(0, character.bank), remaining)
        remaining -= bank_paid
        return replace(
            character,
            cash=max(0, character.cash - cash_paid),
            bank=max(0, character.bank - bank_paid),
        ), remaining

    def _preview_from_row(self, row: dict[str, Any]) -> CrimePreview:
        """Recreate the visible risk card from a persisted preview row."""
        catch = float(row["catch_chance"])
        crime = self._by_id.get(str(row["crime_id"]))
        name = crime.name if crime is not None else str(row["crime_id"]).replace("_", " ").title()
        description = crime.description if crime is not None else "A pending crime confirmation."
        return CrimePreview(
            str(row["crime_id"]), name, description, int(row["age"]), str(row["nonce"]),
            float(row["success_chance"]), catch, clamp_chance(catch * 1.5),
            int(row["loot_min"]), int(row["loot_max"]), int(row["expires_at"]),
        )

    def _trial_from_row(self, row: Optional[dict[str, Any]]) -> Optional[TrialPrompt]:
        """Map a stored trial record to its command-view model."""
        if row is None:
            return None
        crime = self._by_id.get(str(row["crime_id"]))
        name = crime.name if crime is not None else str(row["crime_id"]).replace("_", " ").title()
        return TrialPrompt(
            str(row["nonce"]), int(row["attempt_id"]), str(row["crime_id"]), name,
            int(row["age"]), str(row["source"]),
        )

    @staticmethod
    def _tax_prompt_from_row(row: dict[str, Any]) -> TaxEvasionPrompt:
        """Map a stored tax choice row into a typed view model."""
        return TaxEvasionPrompt(
            str(row["nonce"]), int(row["age"]), int(row["tax_due"]),
            int(row.get("paid_amount", 0)), bool(row["prepaid"]),
        )
```

## `lifeline/core/data_loader.py`

```python
"""JSON game-data loading with schema validation and modification-time caching."""
from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any, Callable, Optional

from .validators import validate_career_catalog, validate_crime_catalog, validate_event_catalog


Validator = Callable[[Any], Any]


class DataLoader:
    """Load validated JSON files from the bot's ``data`` directory."""

    def __init__(self, data_dir: str | Path | None = None):
        self.data_dir = Path(data_dir) if data_dir is not None else Path(__file__).parent.parent / "data"
        self._cache: dict[str, tuple[int, Any]] = {}

    def load_json(self, filename: str, validator: Optional[Validator] = None) -> Any:
        """Read and validate a JSON file; cached copies are returned defensively."""
        if Path(filename).name != filename or not filename.endswith(".json"):
            raise ValueError("Game data filenames must be simple .json filenames")
        path = self.data_dir / filename
        try:
            modified_at = path.stat().st_mtime_ns
        except FileNotFoundError as exc:
            raise FileNotFoundError(f"Required game data file not found: {path}") from exc

        cached = self._cache.get(filename)
        if cached and cached[0] == modified_at:
            return copy.deepcopy(cached[1])

        try:
            with path.open("r", encoding="utf-8") as handle:
                document = json.load(handle)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON in {path} at line {exc.lineno}, column {exc.colno}: {exc.msg}") from exc

        validated = validator(document) if validator is not None else document
        self._cache[filename] = (modified_at, copy.deepcopy(validated))
        return copy.deepcopy(validated)

    def load_events(self) -> dict[str, Any]:
        """Load the validated life-event catalog."""
        return self.load_json("events.json", validate_event_catalog)

    def load_careers(self) -> dict[str, Any]:
        """Load the validated career catalog."""
        return self.load_json("careers.json", validate_career_catalog)

    def load_crimes(self) -> dict[str, Any]:
        """Load the fully validated crime and country-sentencing catalog."""
        return self.load_json("crimes.json", validate_crime_catalog)
```

## `lifeline/core/education.py`

```python
"""School progression, higher-education enrollment, and study actions."""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, replace
from typing import Any, Callable, Optional

import aiosqlite

from .errors import (
    CharacterDead,
    CharacterInPrison,
    CharacterNotFound,
    ConcurrentUpdate,
    EducationRequirementError,
    NotEnrolled,
    PendingEventExists,
    StudyAlreadyUsed,
    ValidationError,
)
from .locks import UserLockRegistry
from .models import Character, EducationLevel, Stats, StudyEffort

EDUCATION_RANK = {
    EducationLevel.NONE: 0,
    EducationLevel.PRIMARY: 1,
    EducationLevel.HIGH_SCHOOL: 2,
    EducationLevel.BACHELOR: 3,
    EducationLevel.MASTER: 4,
    EducationLevel.DOCTORATE: 5,
}

COLLEGE_PROGRAMS = {
    EducationLevel.BACHELOR: (EducationLevel.HIGH_SCHOOL, 4, 1.5),
    EducationLevel.MASTER: (EducationLevel.BACHELOR, 2, 2.0),
    EducationLevel.DOCTORATE: (EducationLevel.MASTER, 4, 2.5),
}

STUDY_EFFECTS = {
    StudyEffort.HARD: {"gpa": 0.30, "smarts": 2, "happiness": -1, "stress": 3},
    StudyEffort.NORMAL: {"gpa": 0.18, "smarts": 1, "happiness": 0, "stress": 1},
    StudyEffort.SLACK: {"gpa": -0.08, "smarts": 0, "happiness": 2, "stress": -1},
}


@dataclass(frozen=True, slots=True)
class EducationProgress:
    """Pure result of school progression during one age advancement."""

    character: Character
    messages: tuple[str, ...] = ()


def advance_school_year(character: Character) -> EducationProgress:
    """Advance mandatory schooling or an enrolled degree by one simulated year.

    The caller supplies a character whose age has already advanced. Starting a new
    school at age six or thirteen does not immediately consume a school year.
    """
    if not character.is_alive or character.in_prison:
        return EducationProgress(character)
    age = character.age
    program = character.school_program
    messages: list[str] = []

    if program is None:
        if age == 6 and EDUCATION_RANK[character.education_level] < EDUCATION_RANK[EducationLevel.PRIMARY]:
            updated = replace(
                character,
                current_school="Primary School",
                school_program=EducationLevel.PRIMARY,
                school_years_left=7,
                gpa=2.5,
                major=None,
            )
            return EducationProgress(updated, ("Started primary school.",))
        if age >= 13 and EDUCATION_RANK[character.education_level] < EDUCATION_RANK[EducationLevel.HIGH_SCHOOL]:
            updated = replace(
                character,
                education_level=EducationLevel.PRIMARY,
                current_school="High School",
                school_program=EducationLevel.HIGH_SCHOOL,
                school_years_left=5,
                gpa=2.5,
                major=None,
            )
            return EducationProgress(updated, ("Started high school.",))
        return EducationProgress(character)

    if program is EducationLevel.PRIMARY:
        if age <= 6:
            return EducationProgress(character)
        years_left = max(0, character.school_years_left - 1)
        if years_left > 0:
            return EducationProgress(replace(character, school_years_left=years_left))

        updated = replace(
            character,
            education_level=EducationLevel.PRIMARY,
            current_school=None,
            school_program=None,
            school_years_left=0,
        )
        messages.append("Completed primary school.")
        if age >= 13 and EDUCATION_RANK[updated.education_level] < EDUCATION_RANK[EducationLevel.HIGH_SCHOOL]:
            updated = replace(
                updated,
                current_school="High School",
                school_program=EducationLevel.HIGH_SCHOOL,
                school_years_left=5,
                gpa=2.5,
                major=None,
            )
            messages.append("Started high school.")
        return EducationProgress(updated, tuple(messages))

    if program is EducationLevel.HIGH_SCHOOL:
        if age <= 13:
            return EducationProgress(character)
        years_left = max(0, character.school_years_left - 1)
        if years_left > 0:
            return EducationProgress(replace(character, school_years_left=years_left))
        updated = replace(
            character,
            education_level=EducationLevel.HIGH_SCHOOL,
            current_school=None,
            school_program=None,
            school_years_left=0,
        )
        return EducationProgress(updated, ("Graduated from high school.",))

    # College, master's, and doctorate programs are started explicitly by the player.
    years_left = max(0, character.school_years_left - 1)
    if years_left > 0:
        return EducationProgress(replace(character, school_years_left=years_left))
    updated = replace(
        character,
        education_level=program,
        current_school=None,
        school_program=None,
        school_years_left=0,
    )
    degree_name = program.value.replace("_", " ").title()
    return EducationProgress(updated, (f"Graduated with a {degree_name} degree.",))


@dataclass(frozen=True, slots=True)
class StudyResult:
    character: Character
    effort: StudyEffort
    gpa_before: float
    gpa_after: float
    stat_changes: dict[str, int]


class EducationService:
    """Database-backed education actions; one study session is allowed per age."""

    def __init__(
        self,
        db: Any,
        locks: Optional[UserLockRegistry] = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.db = db
        self.locks = locks or UserLockRegistry()
        self.clock = clock

    async def status(self, user_id: int) -> Character:
        """Return the current active character, including education state."""
        row = await self.db.fetchone(
            "SELECT data_json FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        if row is None:
            latest = await self.db.fetchone(
                "SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,)
            )
            if latest is not None:
                raise CharacterDead()
            raise CharacterNotFound()
        return Character.from_dict(json.loads(row["data_json"]))

    async def enroll(
        self,
        user_id: int,
        program: EducationLevel | str,
        major: str,
    ) -> Character:
        """Enroll an eligible adult in a bachelor's, master's, or doctorate program."""
        if not isinstance(user_id, int) or user_id <= 0:
            raise ValidationError("A valid Discord user ID is required.")
        try:
            selected_program = program if isinstance(program, EducationLevel) else EducationLevel(str(program).lower())
        except ValueError as exc:
            raise ValidationError("Choose bachelor, master, or doctorate.") from exc
        if selected_program not in COLLEGE_PROGRAMS:
            raise ValidationError("Choose a college program: bachelor, master, or doctorate.")
        clean_major = self._validate_major(major)

        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._load_active(tx, user_id)
                await self._ensure_no_pending_event(tx, character.char_id)
                if character.in_prison:
                    raise CharacterInPrison()
                if character.age < 18:
                    raise EducationRequirementError("You must be at least 18 to enroll in college.")
                if character.school_program is not None or character.current_school is not None:
                    raise EducationRequirementError("Finish your current school program before enrolling again.")

                prerequisite, years, minimum_gpa = COLLEGE_PROGRAMS[selected_program]
                if EDUCATION_RANK[character.education_level] < EDUCATION_RANK[prerequisite]:
                    needed = prerequisite.value.replace("_", " ").title()
                    raise EducationRequirementError(f"You need to complete {needed} before enrolling in this program.")
                if EDUCATION_RANK[selected_program] <= EDUCATION_RANK[character.education_level]:
                    raise EducationRequirementError("You already hold this degree or a higher qualification.")
                current_gpa = 2.5 if character.gpa is None else character.gpa
                if current_gpa < minimum_gpa:
                    raise EducationRequirementError(
                        f"This program requires a GPA of at least {minimum_gpa:.1f}; your current GPA is {current_gpa:.2f}."
                    )

                updated = replace(
                    character,
                    current_school="University",
                    school_program=selected_program,
                    school_years_left=years,
                    major=clean_major,
                    gpa=2.5,
                    version=expected_version + 1,
                )
                await self._save_character(tx, updated, expected_version)
                await self._insert_log(
                    tx,
                    updated,
                    f"Enrolled in a {selected_program.value.replace('_', ' ')} program in {clean_major}.",
                    int(self.clock()),
                )
                return updated

    async def study(self, user_id: int, effort: StudyEffort | str = StudyEffort.NORMAL) -> StudyResult:
        """Study in the current school program, changing GPA and related stats."""
        try:
            selected_effort = effort if isinstance(effort, StudyEffort) else StudyEffort(str(effort).lower())
        except ValueError as exc:
            raise ValidationError("Choose hard, normal, or slack study effort.") from exc

        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._load_active(tx, user_id)
                await self._ensure_no_pending_event(tx, character.char_id)
                if character.in_prison:
                    raise CharacterInPrison()
                if character.school_program is None or character.current_school is None:
                    raise NotEnrolled()
                cursor = await tx.execute(
                    "SELECT 1 FROM education_actions WHERE char_id = ? AND age = ? LIMIT 1",
                    (character.char_id, character.age),
                )
                if await cursor.fetchone():
                    raise StudyAlreadyUsed()

                effects = STUDY_EFFECTS[selected_effort]
                gpa_before = 2.5 if character.gpa is None else float(character.gpa)
                gpa_after = max(0.0, min(4.0, round(gpa_before + effects["gpa"], 2)))
                original_stats = character.stats.to_dict()
                stats = Stats.from_dict(original_stats)
                stats.smarts += effects["smarts"]
                stats.happiness += effects["happiness"]
                stats.stress += effects["stress"]
                stats = stats.clamp_all()
                stat_changes = {
                    key: int(getattr(stats, key) - original_stats[key])
                    for key in ("smarts", "happiness", "stress")
                    if getattr(stats, key) != original_stats[key]
                }
                updated = replace(
                    character,
                    stats=stats,
                    gpa=gpa_after,
                    version=expected_version + 1,
                )
                await self._save_character(tx, updated, expected_version)
                created_at = int(self.clock())
                await tx.execute(
                    """INSERT INTO education_actions
                           (char_id, age, effort, gpa_before, gpa_after, effects_json, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (
                        character.char_id,
                        character.age,
                        selected_effort.value,
                        gpa_before,
                        gpa_after,
                        json.dumps({"stats": stat_changes}, separators=(",", ":")),
                        created_at,
                    ),
                )
                await self._insert_log(
                    tx,
                    updated,
                    f"Studied {selected_effort.value} at {character.current_school}; GPA is now {gpa_after:.2f}.",
                    created_at,
                )
                return StudyResult(updated, selected_effort, gpa_before, gpa_after, stat_changes)

    @staticmethod
    def _validate_major(major: str) -> str:
        if not isinstance(major, str):
            raise ValidationError("Enter a field of study.")
        clean = " ".join(major.split()).strip()
        if not 2 <= len(clean) <= 40 or any(ord(char) < 32 or ord(char) == 127 for char in clean):
            raise ValidationError("A major must be 2–40 characters and contain no control characters.")
        return clean

    async def _load_active(self, tx: aiosqlite.Connection, user_id: int) -> tuple[Character, int]:
        cursor = await tx.execute(
            "SELECT char_id, data_json, version FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        row = await cursor.fetchone()
        if row is None:
            cursor = await tx.execute("SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,))
            if await cursor.fetchone():
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.char_id = int(row["char_id"])
        character.version = int(row["version"])
        return character, int(row["version"])

    @staticmethod
    async def _ensure_no_pending_event(tx: aiosqlite.Connection, char_id: int) -> None:
        cursor = await tx.execute("SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1", (char_id,))
        if await cursor.fetchone():
            raise PendingEventExists()

    @staticmethod
    async def _save_character(
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
    ) -> None:
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET stats_json = ?, version = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (stats_json, character.version, data_json, character.char_id, expected_version),
        )
        if cursor.rowcount != 1:
            raise ConcurrentUpdate()

    @staticmethod
    async def _insert_log(
        tx: aiosqlite.Connection,
        character: Character,
        text: str,
        created_at: int,
    ) -> None:
        await tx.execute(
            """INSERT INTO life_logs (char_id, age, category, text, importance, created_at)
               VALUES (?, ?, 'education', ?, 2, ?)""",
            (character.char_id, character.age, text, created_at),
        )
```

## `lifeline/core/errors.py`

```python
"""User-safe domain exceptions for LIFELINE game operations."""
from __future__ import annotations


class GameError(Exception):
    """Expected game-rule error whose message is safe to show to a player."""

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message


class ValidationError(GameError):
    """An input value does not satisfy game rules."""


class CharacterNotFound(GameError):
    def __init__(self, message: str = "You do not have a life yet. Start one with `/life start`."):
        super().__init__(message)


class CharacterAlreadyExists(GameError):
    def __init__(self, message: str = "You already have an active life. Use `/life status` to view it."):
        super().__init__(message)


class CharacterDead(GameError):
    def __init__(self, message: str = "This life has ended. Start a new one to continue playing."):
        super().__init__(message)


class CharacterBusy(GameError):
    def __init__(self, message: str = "Your character is already processing an action. Try again in a moment."):
        super().__init__(message)


class ConcurrentUpdate(GameError):
    def __init__(self, message: str = "Your life changed while this action was processing. Please try again."):
        super().__init__(message)


class PendingEventExists(GameError):
    def __init__(self, message: str = "Resolve your pending life event with `/life choice` before aging again."):
        super().__init__(message)


class PendingEventNotFound(GameError):
    def __init__(self, message: str = "You have no pending life event. Use `/life age` to continue your story."):
        super().__init__(message)


class StaleEvent(GameError):
    def __init__(self, message: str = "This choice has already been resolved or is no longer available. Use `/life choice` to check for another event."):
        super().__init__(message)


class NotEnrolled(GameError):
    def __init__(self, message: str = "You are not currently enrolled. Check `/education status` for options."):
        super().__init__(message)


class StudyAlreadyUsed(GameError):
    def __init__(self, message: str = "You have already studied this year. You can study again after `/life age`."):
        super().__init__(message)


class EducationRequirementError(GameError):
    def __init__(self, message: str):
        super().__init__(message)


class JobAlreadyExists(GameError):
    def __init__(self, message: str = "You already have a job. Use `/career status` or `/career quit` first."):
        super().__init__(message)


class NoActiveJob(GameError):
    def __init__(self, message: str = "You do not have a job right now. Use `/career list` to explore careers."):
        super().__init__(message)


class WorkAlreadyUsed(GameError):
    def __init__(self, message: str = "You have already worked this in-game year. Work again after `/life age`."):
        super().__init__(message)


class RetiredCharacter(GameError):
    def __init__(self, message: str = "You are retired and cannot take a new job."):
        super().__init__(message)


class FamilyRequirementError(GameError):
    """A family or relationship action is not permitted by current life state."""


class RelationshipNotFound(GameError):
    def __init__(self, message: str = "That person is not in your relationship list."):
        super().__init__(message)


class InteractionLimitReached(GameError):
    def __init__(self, message: str = "You have used all three interactions with this person this year."):
        super().__init__(message)


class InsufficientFunds(GameError):
    def __init__(self, message: str = "You do not have enough available funds for that action."):
        super().__init__(message)


class DateSessionExpired(GameError):
    def __init__(self, message: str = "These date options expired. Use `/date find` to meet new people."):
        super().__init__(message)


class NoActiveMarriage(GameError):
    def __init__(self, message: str = "You are not currently married."):
        super().__init__(message)


class CharacterInPrison(GameError):
    """A command is unavailable while the active character is incarcerated."""

    def __init__(self, message: str = "This action is unavailable while your character is in prison."):
        super().__init__(message)


class CharacterNotInPrison(GameError):
    """A prison-only action was requested by a character outside custody."""

    def __init__(self, message: str = "Your character is not currently in prison."):
        super().__init__(message)


class CrimeLimitReached(GameError):
    """The character has used both crime attempts available this in-game year."""

    def __init__(self, message: str = "You have already attempted two crimes this in-game year."):
        super().__init__(message)


class CrimeSessionExpired(GameError):
    """A risk-confirmation nonce expired or was already consumed."""

    def __init__(self, message: str = "This crime confirmation expired. Use `/crime commit` to review the risk again."):
        super().__init__(message)


class TrialNotFound(GameError):
    """No owner-matched criminal trial is waiting for a lawyer choice."""

    def __init__(self, message: str = "There is no pending trial for this life. Use `/crime record` to review your record."):
        super().__init__(message)


class TaxDecisionNotFound(GameError):
    """No owner-matched high-earner tax decision is waiting for a choice."""

    def __init__(self, message: str = "There is no pending tax decision for this life."):
        super().__init__(message)


class CrimeActionAlreadyUsed(GameError):
    """A prisoner already used their one prison action for this in-game year."""

    def __init__(self, message: str = "You have already taken a prison action this year."):
        super().__init__(message)


class CareerApplicationRejected(GameError):
    """A criminal-record hiring roll did not result in a job offer."""

    def __init__(self, message: str = "Your application was declined after the employer's background check."):
        super().__init__(message)
```

## `lifeline/core/family.py`

```python
"""Stage 6 family generation, relationships, dating, marriage, and yearly care."""
from __future__ import annotations

import json
import logging
import secrets
import time
from dataclasses import dataclass, replace
from decimal import Decimal, ROUND_HALF_UP
from typing import Any, Callable, Optional

import aiosqlite

from .data_loader import DataLoader
from .errors import (
    CharacterDead,
    CharacterNotFound,
    ConcurrentUpdate,
    DateSessionExpired,
    EducationRequirementError,
    FamilyRequirementError,
    InsufficientFunds,
    InteractionLimitReached,
    NoActiveMarriage,
    PendingEventExists,
    RelationshipNotFound,
    ValidationError,
)
from .locks import UserLockRegistry
from .models import Character, EducationLevel, Gender, Stats
from .money import dollars_to_cents, scale_cents
from .repositories.family import FamilyRepository
from .rng import RNG

logger = logging.getLogger("lifeline.family")


@dataclass(frozen=True, slots=True)
class DateSearch:
    """Three generated NPC candidates and the owner/nonce-bound menu token."""

    nonce: str
    candidates: tuple[dict[str, Any], ...]
    expires_at: int


@dataclass(frozen=True, slots=True)
class DateOutcome:
    """Outcome of selecting one candidate from a date search."""

    npc: dict[str, Any]
    success_chance: float
    accepted: bool
    relationship_score: Optional[int]


@dataclass(frozen=True, slots=True)
class InteractionOutcome:
    """Result of one relationship interaction."""

    person_name: str
    action: str
    score_before: int
    score_after: int
    message: str
    money_delta: int = 0


@dataclass(frozen=True, slots=True)
class ProposalOutcome:
    """Outcome of proposing to an eligible partner."""

    person_name: str
    chance: int
    accepted: bool
    ring_bonus: int


@dataclass(frozen=True, slots=True)
class MarriageOutcome:
    """Wedding details after cost, prenup, and spouse income are recorded."""

    person_name: str
    wedding_cost: int
    prenup: bool
    annual_income: int


@dataclass(frozen=True, slots=True)
class DivorceSplit:
    """Pure integer-cent divorce asset allocation result."""

    eligible_assets: int
    spouse_share: int
    protected_assets: int


@dataclass(frozen=True, slots=True)
class DivorceOutcome:
    """Completed divorce settlement and its cash-flow consequences."""

    character: Character
    spouse_name: str
    marital_assets: int
    spouse_share: int
    lawyer_fee: int
    children: int
    alimony_annual: int
    alimony_years: float
    message: str


@dataclass(frozen=True, slots=True)
class FamilyYearResult:
    """Character state, messages, and tax details from the annual family tick."""

    character: Character
    messages: tuple[str, ...] = ()
    tax_assessed: int = 0
    tax_paid: int = 0
    household_income: int = 0


@dataclass(frozen=True, slots=True)
class InfidelityPrompt:
    """Nonce-protected choice between cheating and remaining faithful."""

    nonce: str
    spouse_name: str
    expires_at: int


RING_CATALOG: dict[str, dict[str, int | str]] = {
    "simple_ring": {"name": "Simple band", "price": 10_000, "bonus": 1},
    "silver_ring": {"name": "Silver ring", "price": 100_000, "bonus": 4},
    "gold_ring": {"name": "Gold ring", "price": 500_000, "bonus": 8},
    "diamond_ring": {"name": "Diamond ring", "price": 2_000_000, "bonus": 14},
    "heirloom_ring": {"name": "Heirloom ring", "price": 10_000_000, "bonus": 20},
}

WEDDING_TIERS: dict[str, tuple[str, int]] = {
    "courthouse": ("Courthouse", 10_000),
    "intimate": ("Intimate", 250_000),
    "traditional": ("Traditional", 2_500_000),
    "lavish": ("Lavish", 8_000_000),
}

_NAME_GENDERS = (Gender.MALE, Gender.FEMALE, Gender.NON_BINARY)
_WEALTH_RANGES = {
    "poor": (100_000, 1_500_000),
    "working": (1_500_000, 8_000_000),
    "middle": (8_000_000, 60_000_000),
    "upper": (60_000_000, 500_000_000),
    "rich": (500_000_000, 5_000_000_000),
}
_WEALTH_WEIGHTS = ("poor", "working", "middle", "upper", "rich")
_WEALTH_PROBABILITIES = (0.10, 0.25, 0.40, 0.18, 0.07)
_OCCUPATION_INCOMES = (
    ("Teacher", 5_200_000),
    ("Nurse", 6_000_000),
    ("Engineer", 8_400_000),
    ("Small business owner", 6_500_000),
    ("Artist", 3_800_000),
    ("Accountant", 6_200_000),
    ("Chef", 4_000_000),
    ("Researcher", 7_200_000),
    ("Mechanic", 4_600_000),
    ("Public servant", 5_000_000),
)
_COST_OF_LIVING = {"poor": 0.80, "working": 0.90, "middle": 1.00, "upper": 1.20, "rich": 1.50}


def can_date_ages(player_age: int, npc_age: int) -> bool:
    """Enforce the age boundary for dating independently of generated/UI options."""
    if player_age < 16 or npc_age < 0:
        return False
    if player_age < 18:
        return npc_age < 18 and abs(player_age - npc_age) <= 2
    return npc_age >= 18 and abs(player_age - npc_age) <= 5


def proposal_acceptance_chance(score: int, ring_bonus: int = 0) -> int:
    """Return a clamped proposal chance from relationship score and ring bonus."""
    return max(0, min(100, int(score) - 20 + max(0, min(20, int(ring_bonus)))))


def dating_success_chance(
    *,
    player_looks: int,
    npc_looks: int,
    player_smarts: int,
    npc_smarts: int,
    npc_prefers_smarts: bool,
    fame: int,
    npc_wealth: int,
) -> float:
    """Calculate the requested dating formula and clamp it to 5–90 percent."""
    smarts_bonus = (player_smarts - npc_smarts) * 0.4 if npc_prefers_smarts else 0.0
    wealthy_bonus = 10.0 if npc_wealth >= dollars_to_cents(1_000_000) else 0.0
    value = 40.0 + (player_looks - npc_looks) * 0.8 + smarts_bonus + fame * 0.2 + wealthy_bonus
    return max(5.0, min(90.0, value))


def calculate_fertility_factor(age: int) -> float:
    """Return the specified piecewise female fertility curve."""
    if age < 0:
        raise ValueError("age cannot be negative")
    if age < 30:
        return 1.0
    if age < 35:
        return 1.0 - (age - 30) * 0.06
    if age < 40:
        return 0.7 - (age - 35) * 0.08
    if age < 45:
        return 0.3 - (age - 40) * 0.05
    if age < 50:
        return max(0.0, 0.05 - (age - 45) * 0.01)
    return 0.0


def calculate_male_fertility_factor(age: int) -> float:
    """Return a gentle age-related male fertility multiplier."""
    if age < 0:
        raise ValueError("age cannot be negative")
    return max(0.2, 1.0 - max(0, age - 30) * 0.02)


def calculate_divorce_split(
    *,
    cash: int,
    bank: int,
    marital_item_values: list[int] | tuple[int, ...],
    prenup: bool,
    premarital_cash: int = 0,
    premarital_bank: int = 0,
) -> DivorceSplit:
    """Calculate a 50/50 split in integer cents without making balances negative."""
    values = (cash, bank, premarital_cash, premarital_bank, *marital_item_values)
    if any(isinstance(value, bool) or not isinstance(value, int) or value < 0 for value in values):
        raise ValueError("divorce assets must be non-negative integer cents")
    protected_cash = min(cash, premarital_cash) if prenup else 0
    protected_bank = min(bank, premarital_bank) if prenup else 0
    eligible = cash - protected_cash + bank - protected_bank + sum(marital_item_values)
    return DivorceSplit(
        eligible_assets=eligible,
        spouse_share=eligible // 2,
        protected_assets=protected_cash + protected_bank,
    )


def calculate_alimony(player_income: int, spouse_income: int, marriage_years: int) -> tuple[bool, int, float]:
    """Return (player_pays, annual amount, duration) from 20% of income difference."""
    if player_income < 0 or spouse_income < 0 or marriage_years < 0:
        raise ValueError("incomes and marriage duration must be non-negative")
    difference = abs(int(player_income) - int(spouse_income))
    annual = int((Decimal(difference) * Decimal("0.20")).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    duration = float(marriage_years) / 2.0
    return player_income > spouse_income, annual, duration


def calculate_joint_tax(combined_income: int) -> int:
    """Apply progressive US-style sample tax bands with every joint band doubled.

    This stage has no pre-existing tax service; these explicit game bands keep
    spouse income and the character's gross annual salary in one household basis.
    All thresholds and results are integer cents.
    """
    if combined_income <= 0:
        return 0
    single_bands = (
        (1_000_000, 0.10),
        (4_000_000, 0.12),
        (9_000_000, 0.22),
        (18_000_000, 0.24),
        (30_000_000, 0.32),
        (None, 0.35),
    )
    remaining = int(combined_income)
    lower = 0
    tax = 0
    for upper_single, rate in single_bands:
        upper = None if upper_single is None else upper_single * 2
        bracket_width = remaining if upper is None else max(0, min(remaining, upper - lower))
        tax += int((Decimal(bracket_width) * Decimal(str(rate))).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        remaining -= bracket_width
        if remaining <= 0:
            break
        if upper is not None:
            lower = upper
    return max(0, min(int(combined_income), tax))


class FamilyService:
    """Transactional family/NPC domain service integrated into LIFELINE's age tick."""

    def __init__(
        self,
        db: Any,
        rng: RNG,
        locks: Optional[UserLockRegistry] = None,
        *,
        repository: Optional[FamilyRepository] = None,
        data_loader: Optional[DataLoader] = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.db = db
        self.rng = rng.fork("lifeline-stage6-family")
        self.locks = locks or UserLockRegistry()
        self.repository = repository or FamilyRepository(db)
        self.clock = clock
        self.names = (data_loader or DataLoader()).load_json("names.json")
        self._validate_names(self.names)

    @staticmethod
    def _validate_names(document: Any) -> None:
        if not isinstance(document, dict) or document.get("schema_version") != 1:
            raise ValueError("names.json must be a schema-version-1 object")
        defaults = document.get("defaults")
        countries = document.get("countries")
        if not isinstance(defaults, dict) or not isinstance(countries, dict):
            raise ValueError("names.json requires defaults and countries objects")
        for group in (defaults, *countries.values()):
            if not isinstance(group, dict):
                raise ValueError("each names group must be an object")
            for gender in ("male", "female", "non_binary"):
                names = group.get(gender)
                if not isinstance(names, list) or not names or any(not isinstance(name, str) or not name.strip() for name in names):
                    raise ValueError(f"names.json requires non-empty {gender} name lists")

    def _name(self, country: str, gender: Gender) -> str:
        """Select a gender-aware name from the character's country or fallback list."""
        group = self.names["countries"].get(country.lower(), self.names["defaults"])
        return self.rng.choice(group[gender.value])

    def _wealth(self, wealth_class: str) -> int:
        """Roll integer-cent NPC net worth within a class-specific band."""
        low, high = _WEALTH_RANGES.get(wealth_class, _WEALTH_RANGES["middle"])
        return self.rng.randint(low, high)

    def _occupation(self, wealth_class: str, *, child: bool = False) -> tuple[str, int]:
        """Choose an NPC occupation and annual income in integer cents."""
        if child:
            return "Student", 0
        occupation, base_income = self.rng.choice(_OCCUPATION_INCOMES)
        multiplier = {"poor": 0.70, "working": 0.85, "middle": 1.0, "upper": 1.3, "rich": 1.8}.get(wealth_class, 1.0)
        return occupation, scale_cents(base_income, multiplier)

    def _stats(self, *, means: Optional[tuple[float, float, float]] = None) -> tuple[int, int, int]:
        """Generate bounded NPC looks, smarts, and health from Gaussian rolls."""
        look_mean, smarts_mean, health_mean = means or (50.0, 50.0, 75.0)
        values = (
            int(round(self.rng.gauss(look_mean, 15.0))),
            int(round(self.rng.gauss(smarts_mean, 15.0))),
            int(round(self.rng.gauss(health_mean, 12.0))),
        )
        return tuple(max(0, min(100, value)) for value in values)  # type: ignore[return-value]

    def _npc_fields(
        self,
        character: Character,
        *,
        gender: Gender,
        age: int,
        wealth_class: Optional[str] = None,
        occupation: Optional[str] = None,
        annual_income: Optional[int] = None,
        means: Optional[tuple[float, float, float]] = None,
        prefers_smarts: Optional[bool] = None,
    ) -> dict[str, Any]:
        """Create generation data while keeping gameplay randomness in the RNG wrapper."""
        selected_wealth = wealth_class or self.rng.weighted_choice(_WEALTH_WEIGHTS, _WEALTH_PROBABILITIES)
        selected_occupation, selected_income = self._occupation(selected_wealth, child=occupation == "Student")
        if occupation is not None:
            selected_occupation = occupation
        if annual_income is not None:
            selected_income = annual_income
        looks, smarts, health = self._stats(means=means)
        return {
            "owner_char_id": character.char_id,
            "name": self._name(character.country, gender),
            "gender": gender.value,
            "age": max(0, min(120, int(age))),
            "looks": looks,
            "smarts": smarts,
            "health": health,
            "wealth": 0 if occupation == "Student" else self._wealth(selected_wealth),
            "occupation": selected_occupation,
            "country": character.country,
            "annual_income": selected_income,
            "prefers_smarts": bool(self.rng.random() < 0.35) if prefers_smarts is None else prefers_smarts,
        }

    async def _insert_npc(self, tx: aiosqlite.Connection, fields: dict[str, Any]) -> int:
        """Persist one NPC using the Stage 6 repository."""
        return await self.repository.create_npc(tx, **fields)

    async def initialize_family(self, tx: aiosqlite.Connection, character: Character) -> tuple[str, ...]:
        """Generate two parents and zero to three siblings at the character's birth."""
        messages: list[str] = []
        parent_ages: list[int] = []
        for gender in (Gender.FEMALE, Gender.MALE):
            age = self.rng.randint(22, 40)
            parent_ages.append(age)
            npc_id = await self._insert_npc(
                tx,
                self._npc_fields(character, gender=gender, age=age, wealth_class=character.wealth_class),
            )
            score = self.rng.randint(60, 90)
            await self.repository.create_relationship(
                tx,
                char_id=character.char_id,
                npc_id=npc_id,
                relation_type="parent",
                score=score,
                since_age=0,
            )
        sibling_count = self.rng.randint(0, 3)
        for _ in range(sibling_count):
            gender = self.rng.choice(_NAME_GENDERS)
            age = self.rng.randint(0, 8)
            fields = self._npc_fields(
                character,
                gender=gender,
                age=age,
                wealth_class=character.wealth_class,
                occupation="Student",
                annual_income=0,
            )
            fields["wealth"] = self._wealth(character.wealth_class)
            npc_id = await self._insert_npc(tx, fields)
            await self.repository.create_relationship(
                tx,
                char_id=character.char_id,
                npc_id=npc_id,
                relation_type="sibling",
                score=self.rng.randint(60, 90),
                since_age=0,
            )
        message = f"Family generated: two parents and {sibling_count} sibling(s)."
        await self.repository.insert_life_log(
            tx,
            char_id=character.char_id,
            age=0,
            category="family",
            text=message,
            importance=2,
            created_at=int(self.clock()),
        )
        messages.append(message)
        return tuple(messages)

    async def _active_character(self, tx: aiosqlite.Connection, user_id: int) -> tuple[Character, int]:
        """Load a versioned active life or raise a user-safe life error."""
        row = await self.repository.load_active(tx, user_id)
        if row is None:
            if await self.repository.has_any_life(tx, user_id):
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.char_id = int(row["char_id"])
        character.user_id = int(row["user_id"])
        character.version = int(row["version"])
        if not character.is_alive:
            raise CharacterDead()
        return character, int(row["version"])

    async def _active_character_read(self, user_id: int) -> Character:
        """Load an active character outside a write transaction."""
        row = await self.repository.load_active_read(user_id)
        if row is None:
            if await self.repository.has_any_life_read(user_id):
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.char_id = int(row["char_id"])
        character.user_id = int(row["user_id"])
        character.version = int(row["version"])
        if not character.is_alive:
            raise CharacterDead()
        return character

    def _check_age(self, character: Character, minimum: int, action: str, *, maximum: Optional[int] = None) -> None:
        """Enforce age gates in the domain engine rather than relying on Discord UI."""
        if character.age < minimum:
            raise EducationRequirementError(f"You must be at least {minimum} to {action}.")
        if maximum is not None and character.age > maximum:
            raise EducationRequirementError(f"You must be age {maximum} or younger to {action}.")

    @staticmethod
    def _check_not_imprisoned(character: Character) -> None:
        """Prevent family actions while the character is serving a prison sentence."""
        if character.in_prison:
            raise FamilyRequirementError("You cannot do this while your character is in prison.")

    async def _check_pending_event(self, tx: aiosqlite.Connection, character: Character) -> None:
        """Keep unresolved Stage 3 choices ahead of new family decisions."""
        if await self.repository.has_pending_event(tx, character.char_id):
            raise PendingEventExists()

    async def family(self, user_id: int) -> tuple[Character, list[dict[str, Any]]]:
        """Return the active life and its complete relationship roster."""
        async with self.locks.hold(user_id):
            character = await self._active_character_read(user_id)
            people = await self.repository.list_people(character.char_id)
            return character, people

    async def relationship_list(self, user_id: int) -> tuple[Character, list[dict[str, Any]]]:
        """Return the same relationship roster for the explicit relationship command."""
        return await self.family(user_id)

    async def autocomplete_people(self, user_id: int, query: str) -> list[dict[str, Any]]:
        """Return owned, living NPC relationships matching a short autocomplete query."""
        character = await self._active_character_read(user_id)
        return await self.repository.autocomplete_people(character.char_id, query[:80])

    async def find_dates(self, user_id: int) -> DateSearch:
        """Create exactly three age-eligible, persistent dating candidates."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 16, "start dating")
                romance = await self.repository.active_romance(tx, character.char_id)
                if romance is not None:
                    raise FamilyRequirementError("End your current relationship before searching for dates.")
                candidates: list[dict[str, Any]] = []
                npc_ids: list[int] = []
                for _ in range(3):
                    gender = self.rng.choice(_NAME_GENDERS)
                    if character.age < 18:
                        low, high = max(0, character.age - 2), min(17, character.age + 2)
                    else:
                        low, high = max(18, character.age - 5), min(120, character.age + 5)
                    age = self.rng.randint(low, high)
                    fields = self._npc_fields(character, gender=gender, age=age)
                    npc_id = await self._insert_npc(tx, fields)
                    fields["npc_id"] = npc_id
                    candidates.append(fields)
                    npc_ids.append(npc_id)
                now = int(self.clock())
                nonce = secrets.token_urlsafe(16)
                expires = now + 900
                await self.repository.save_dating_session(tx, character.char_id, nonce, now, expires, npc_ids)
                return DateSearch(nonce, tuple(candidates), expires)

    async def choose_date(self, user_id: int, npc_id: int, nonce: str) -> DateOutcome:
        """Resolve a date select-menu choice, enforcing age and ownership in-engine."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 16, "date")
                candidate = await self.repository.get_dating_candidate(
                    tx, character.char_id, int(npc_id), nonce, int(self.clock())
                )
                if candidate is None:
                    raise DateSessionExpired()
                if not can_date_ages(character.age, int(candidate["age"])):
                    raise FamilyRequirementError("Dating age rules do not allow that match.")
                if await self.repository.active_romance(tx, character.char_id) is not None:
                    raise FamilyRequirementError("You already have an active relationship.")
                stats = character.stats
                chance = dating_success_chance(
                    player_looks=stats.looks,
                    npc_looks=int(candidate["looks"]),
                    player_smarts=stats.smarts,
                    npc_smarts=int(candidate["smarts"]),
                    npc_prefers_smarts=bool(candidate["prefers_smarts"]),
                    fame=stats.fame,
                    npc_wealth=int(candidate["wealth"]),
                )
                accepted = self.rng.random() * 100.0 < chance
                if accepted:
                    await self.repository.create_relationship(
                        tx,
                        char_id=character.char_id,
                        npc_id=int(candidate["npc_id"]),
                        relation_type="partner",
                        score=60,
                        since_age=character.age,
                    )
                await self.repository.consume_dating_session(tx, character.char_id, nonce)
                name = str(candidate["name"])
                await self.repository.insert_life_log(
                    tx,
                    char_id=character.char_id,
                    age=character.age,
                    category="relationship",
                    text=(f"Started dating {name}." if accepted else f"A date with {name} did not turn into a relationship."),
                    importance=2,
                    created_at=int(self.clock()),
                )
                return DateOutcome(dict(candidate), chance, accepted, 60 if accepted else None)

    async def find_friend(self, user_id: int) -> dict[str, Any]:
        """Meet one age-appropriate NPC friend and persist the relationship."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 6, "make new friends")
                if character.age < 18:
                    low, high = max(0, character.age - 2), min(17, character.age + 2)
                else:
                    low, high = max(18, character.age - 5), min(120, character.age + 5)
                age = self.rng.randint(low, high)
                gender = self.rng.choice(_NAME_GENDERS)
                npc_id = await self._insert_npc(
                    tx,
                    self._npc_fields(character, gender=gender, age=age),
                )
                score = self.rng.randint(50, 65)
                await self.repository.create_relationship(
                    tx,
                    char_id=character.char_id,
                    npc_id=npc_id,
                    relation_type="friend",
                    score=score,
                    since_age=character.age,
                )
                person = await self.repository.get_person(tx, character.char_id, npc_id)
                return dict(person or {"npc_id": npc_id, "name": "Friend", "age": age, "relationship_score": score})

    async def interact(self, user_id: int, npc_id: int, action: str, gift_dollars: Optional[int] = None) -> InteractionOutcome:
        """Interact with one connected NPC, enforcing three actions per person/year."""
        selected = str(action).lower()
        allowed = {"spend_time", "gift", "compliment", "argue", "ask_for_money", "insult"}
        if selected not in allowed:
            raise ValidationError("Choose spend_time, gift, compliment, argue, ask_for_money, or insult.")
        if selected == "gift" and (gift_dollars is None or gift_dollars <= 0):
            raise ValidationError("A gift requires a positive amount in whole dollars.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 6, "interact with people")
                person = await self.repository.get_person(tx, character.char_id, int(npc_id))
                if person is None:
                    raise RelationshipNotFound()
                if not bool(person["is_alive"]):
                    raise FamilyRequirementError("You cannot interact with someone who has died.")
                if not await self.repository.claim_interaction(tx, character.char_id, int(npc_id), character.age):
                    raise InteractionLimitReached()

                before = int(person["relationship_score"])
                money_delta = 0
                if selected == "spend_time":
                    delta = self.rng.randint(5, 10)
                    message = f"You spent quality time with {person['name']} (+{delta} relationship)."
                elif selected == "compliment":
                    delta = self.rng.randint(2, 8)
                    message = f"You gave {person['name']} a sincere compliment (+{delta})."
                elif selected == "argue":
                    delta = -self.rng.randint(5, 15)
                    message = f"You argued with {person['name']} ({delta} relationship)."
                elif selected == "insult":
                    delta = -self.rng.randint(10, 25)
                    message = f"You insulted {person['name']} ({delta} relationship)."
                elif selected == "gift":
                    gift_value = dollars_to_cents(gift_dollars or 0)
                    available = character.cash + character.bank
                    if gift_value > available:
                        raise InsufficientFunds("You do not have enough cash or bank balance for that gift.")
                    income = await self.repository.get_annual_job_income(tx, character.char_id)
                    reference = max(income, dollars_to_cents(1_000))
                    ratio = min(1.0, gift_value / reference)
                    delta = max(3, min(15, int(round(3 + 12 * ratio))))
                    character, _ = self._deduct_cash_bank(character, gift_value)
                    character = replace(character, version=expected_version + 1)
                    await self.repository.save_character(tx, character, expected_version)
                    await self.repository.add_npc_wealth(tx, int(npc_id), gift_value)
                    money_delta = -gift_value
                    message = f"You gave {person['name']} a gift worth {gift_dollars:,} dollars (+{delta} relationship)."
                else:
                    if person["relationship_type"] != "parent":
                        raise FamilyRequirementError("Only a parent can be asked for money.")
                    wealth = int(person["wealth"])
                    income_factor = min(25, (wealth // dollars_to_cents(100_000)) * 3)
                    chance = max(5, min(90, int(before * 0.60 + income_factor)))
                    if self.rng.random() * 100 < chance and wealth > 0:
                        amount = min(wealth, dollars_to_cents(self.rng.randint(100, 5_000)))
                        await self.repository.add_npc_wealth(tx, int(npc_id), -amount)
                        character = replace(character, cash=character.cash + amount, version=expected_version + 1)
                        await self.repository.save_character(tx, character, expected_version)
                        money_delta = amount
                        delta = self.rng.randint(1, 4)
                        message = f"{person['name']} agreed to help with {amount // 100:,} dollars."
                    else:
                        delta = -self.rng.randint(1, 3)
                        message = f"{person['name']} could not help with money this time."
                after = max(0, min(100, before + delta))
                await self.repository.set_relationship_score(tx, character.char_id, int(npc_id), after)
                await self.repository.log_relationship_interaction(
                    tx, character.char_id, character.age, message, int(self.clock())
                )
                return InteractionOutcome(str(person["name"]), selected, before, after, message, money_delta)

    async def propose(self, user_id: int, npc_id: int) -> ProposalOutcome:
        """Propose after a year of dating with a score of at least 70."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "propose")
                person = await self.repository.get_person(tx, character.char_id, int(npc_id))
                if person is None or not bool(person["is_alive"]):
                    raise RelationshipNotFound()
                if person["relationship_type"] != "partner" or int(person["relationship_score"]) < 70:
                    raise FamilyRequirementError("You need a living partner with relationship score 70 or higher.")
                if character.age - int(person["relationship_since_age"]) < 1:
                    raise FamilyRequirementError("You must have been dating for at least one in-game year.")
                if int(person["age"]) < 18:
                    raise FamilyRequirementError("Adults may only propose to adults.")
                active = await self.repository.active_romance(tx, character.char_id)
                if active is not None and int(active["npc_id"]) != int(npc_id):
                    raise FamilyRequirementError("End your other active relationship before proposing.")
                rings = await self.repository.list_ring_assets(tx, character.char_id)
                ring = rings[0] if rings else None
                ring_bonus = int(RING_CATALOG.get(str(ring["item_id"]), {}).get("bonus", 0)) if ring else 0
                chance = proposal_acceptance_chance(int(person["relationship_score"]), ring_bonus)
                if ring is not None:
                    await self.repository.consume_ring(tx, int(ring["asset_id"]))
                accepted = self.rng.random() * 100.0 < chance
                if accepted:
                    await self.repository.set_relationship_type(tx, character.char_id, int(npc_id), "fiance")
                    message = f"{person['name']} accepted your proposal!"
                else:
                    message = f"{person['name']} declined the proposal."
                await self.repository.insert_life_log(
                    tx, char_id=character.char_id, age=character.age,
                    category="relationship", text=message, importance=3, created_at=int(self.clock()),
                )
                return ProposalOutcome(str(person["name"]), chance, accepted, ring_bonus)

    async def buy_ring(self, user_id: int, item_id: str) -> tuple[int, int]:
        """Purchase one catalog ring for a future proposal."""
        ring = RING_CATALOG.get(str(item_id))
        if ring is None:
            raise ValidationError("That ring is not sold by the relationship shop.")
        price = int(ring["price"])
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "buy a wedding ring")
                if character.cash + character.bank < price:
                    raise InsufficientFunds("You do not have enough available funds for this ring.")
                updated, _ = self._deduct_cash_bank(character, price)
                updated = replace(updated, version=expected_version + 1)
                await self.repository.save_character(tx, updated, expected_version)
                await self.repository.add_asset(
                    tx, char_id=character.char_id, kind="item", item_id=str(item_id), quantity=1,
                    purchase_price=price, current_value=price, acquired_age=character.age,
                    acquired_at=int(self.clock()),
                )
                return price, int(ring["bonus"])

    async def marry(self, user_id: int, wedding: str = "courthouse", prenup: bool = False) -> MarriageOutcome:
        """Hold a wedding, charge its price-indexed cost, and save optional prenup terms."""
        selected = str(wedding).lower()
        if selected not in WEDDING_TIERS:
            raise ValidationError("Choose courthouse, intimate, traditional, or lavish.")
        if not isinstance(prenup, bool):
            raise ValidationError("Prenup must be true or false.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "get married")
                if await self.repository.get_marriage(tx, character.char_id) is not None:
                    raise FamilyRequirementError("You are already married.")
                person = await self.repository.active_romance(tx, character.char_id)
                if person is None or person["relationship_type"] != "fiance" or not bool(person["is_alive"]):
                    raise FamilyRequirementError("You need a living fiance before you can marry.")
                if int(person["age"]) < 18:
                    raise FamilyRequirementError("Both partners must be adults to marry.")
                label, base_cost = WEDDING_TIERS[selected]
                cost = scale_cents(base_cost, Decimal(str(character.price_index)))
                if character.cash + character.bank < cost:
                    raise InsufficientFunds(f"You need {cost // 100:,} dollars for this wedding.")
                updated, _ = self._deduct_cash_bank(character, cost)
                updated = replace(updated, version=expected_version + 1)
                await self.repository.save_character(tx, updated, expected_version)
                await self.repository.set_relationship_type(tx, character.char_id, int(person["npc_id"]), "spouse")
                await self.repository.create_marriage(
                    tx,
                    char_id=character.char_id,
                    spouse_npc_id=int(person["npc_id"]),
                    start_age=character.age,
                    spouse_income=int(person["annual_income"]),
                    prenup=prenup,
                    premarital_cash=updated.cash,
                    premarital_bank=updated.bank,
                    wedding_cost=cost,
                    created_at=int(self.clock()),
                )
                await self.repository.insert_life_log(
                    tx,
                    char_id=character.char_id,
                    age=character.age,
                    category="relationship",
                    text=f"{character.name} married {person['name']} in a {label.lower()} wedding.",
                    importance=4,
                    created_at=int(self.clock()),
                )
                return MarriageOutcome(str(person["name"]), cost, prenup, int(person["annual_income"]))

    async def divorce(self, user_id: int) -> DivorceOutcome:
        """Atomically divorce, divide eligible assets, roll custody, and record support."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "divorce")
                result, updated = await self._divorce_in_tx(
                    tx, character, expected_version, reason="player", now=int(self.clock()), save_character=True
                )
                return replace(result, character=updated)

    async def _divorce_in_tx(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
        *,
        reason: str,
        now: int,
        save_character: bool,
    ) -> tuple[DivorceOutcome, Character]:
        """Perform every divorce write in the caller's existing transaction."""
        marriage = await self.repository.get_marriage(tx, character.char_id)
        if marriage is None:
            raise NoActiveMarriage()
        spouse = await self.repository.get_person(tx, character.char_id, int(marriage["spouse_npc_id"]))
        if spouse is None:
            raise FamilyRequirementError("Your spouse record is unavailable.")
        marriage_years = max(0, character.age - int(marriage["start_age"]))
        player_income = await self.repository.get_annual_job_income(tx, character.char_id)
        spouse_income = int(spouse["annual_income"])
        player_pays_alimony, alimony_annual, alimony_years = calculate_alimony(
            player_income, spouse_income, marriage_years
        )
        updated = character

        # Liquidate marital stocks into bank cash before calculating the split.
        stock_total = await self.repository.liquidate_stock_assets(
            tx, character.char_id, int(marriage["created_at"])
        )
        updated = replace(updated, bank=updated.bank + stock_total)
        item_assets = await self.repository.get_marital_assets(
            tx, character.char_id, int(marriage["created_at"])
        )
        item_values = [int(asset["current_value"]) for asset in item_assets if asset["kind"] == "item"]
        split = calculate_divorce_split(
            cash=updated.cash,
            bank=updated.bank,
            marital_item_values=item_values,
            prenup=bool(marriage["prenup"]),
            premarital_cash=int(marriage["premarital_cash"]),
            premarital_bank=int(marriage["premarital_bank"]),
        )
        protected_cash = int(marriage["premarital_cash"]) if bool(marriage["prenup"]) else 0
        protected_bank = int(marriage["premarital_bank"]) if bool(marriage["prenup"]) else 0
        updated, _ = await self._pay_divorce_assets(
            tx,
            updated,
            split.spouse_share,
            marriage_timestamp=int(marriage["created_at"]),
            protect_cash=protected_cash,
            protect_bank=protected_bank,
            marital_only=True,
        )
        await self.repository.add_npc_wealth(tx, int(spouse["npc_id"]), split.spouse_share)

        lawyer_fee = self.rng.randint(dollars_to_cents(5_000), dollars_to_cents(50_000))
        updated, _ = await self._pay_divorce_assets(
            tx,
            updated,
            lawyer_fee,
            marriage_timestamp=int(marriage["created_at"]),
            marital_only=False,
        )

        children = await self.repository.get_children(tx, character.char_id)
        support_amount = int((Decimal(player_income) * Decimal("0.15")).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        for child in children:
            if not bool(child["is_alive"]) or int(child["age"]) >= 18:
                await self.repository.update_child_support(tx, int(child["npc_id"]), 0)
                continue
            custody = self._roll_custody(character, player_income)
            child_support = support_amount if custody != "full" else 0
            await self.repository.update_custody_and_support(
                tx, int(child["npc_id"]), custody, child_support
            )
        if alimony_annual > 0 and alimony_years > 0:
            await self.repository.create_alimony(
                tx,
                character.char_id,
                int(spouse["npc_id"]),
                alimony_annual,
                alimony_years,
                player_pays_alimony,
            )
        await self.repository.set_relationship_type(tx, character.char_id, int(spouse["npc_id"]), "ex")
        await self.repository.set_relationship_score(
            tx, character.char_id, int(spouse["npc_id"]), max(0, int(spouse.get("relationship_score", 50)) - 30)
        )
        await self.repository.delete_marriage(tx, character.char_id)
        await self.repository.delete_affair(tx, character.char_id)
        stats = replace(character.stats)
        stats.happiness = max(0, stats.happiness - 25)
        updated = replace(updated, stats=stats, version=expected_version + 1)
        if save_character:
            await self.repository.save_character(tx, updated, expected_version)
        await self.repository.increment_divorces(tx, character.char_id)
        await self.repository.insert_divorce_record(
            tx,
            char_id=character.char_id,
            spouse_npc_id=int(spouse["npc_id"]),
            age=character.age,
            prenup=bool(marriage["prenup"]),
            marital_assets=split.eligible_assets,
            spouse_share=split.spouse_share,
            lawyer_fee=lawyer_fee,
            reason=reason,
            created_at=now,
        )
        message = (
            f"Divorced {spouse['name']}. The spouse's share was {split.spouse_share // 100:,} dollars; "
            f"lawyer fees were {lawyer_fee // 100:,} dollars."
        )
        await self.repository.insert_life_log(
            tx,
            char_id=character.char_id,
            age=character.age,
            category="relationship",
            text=message,
            importance=4,
            created_at=now,
        )
        return (
            DivorceOutcome(
                updated,
                str(spouse["name"]),
                split.eligible_assets,
                split.spouse_share,
                lawyer_fee,
                sum(1 for child in children if bool(child["is_alive"]) and int(child["age"]) < 18),
                alimony_annual,
                alimony_years,
                message,
            ),
            updated,
        )

    async def breakup(self, user_id: int, npc_id: int) -> str:
        """End a dating or engagement relationship without legal divorce."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 16, "end a relationship")
                person = await self.repository.get_person(tx, character.char_id, int(npc_id))
                if (
                    person is None
                    or not bool(person["is_alive"])
                    or person["relationship_type"] not in {"partner", "fiance"}
                ):
                    raise FamilyRequirementError("You can only break up with a living partner or fiance.")
                await self.repository.set_relationship_type(tx, character.char_id, int(npc_id), "ex")
                await self.repository.add_relationship_score(tx, character.char_id, int(npc_id), -20)
                await self.repository.insert_life_log(
                    tx, char_id=character.char_id, age=character.age, category="relationship",
                    text=f"Ended the relationship with {person['name']}.", importance=3, created_at=int(self.clock()),
                )
                return f"You and {person['name']} have broken up."

    async def try_for_baby(self, user_id: int) -> tuple[bool, float]:
        """Try to conceive with a current partner or spouse using age-based fertility."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "try for a baby")
                partner = await self.repository.active_romance(tx, character.char_id)
                if (
                    partner is None
                    or partner["relationship_type"] not in {"partner", "spouse"}
                    or not bool(partner["is_alive"])
                ):
                    raise FamilyRequirementError("You need a living partner or spouse to try for a baby.")
                if int(partner["age"]) < 18:
                    raise FamilyRequirementError("Both partners must be adults to try for a baby.")
                if await self.repository.get_pregnancy(tx, character.char_id) is not None:
                    raise FamilyRequirementError("A pregnancy is already in progress.")
                if await self.repository.get_adoption(tx, character.char_id) is not None:
                    raise FamilyRequirementError("An adoption is already in progress.")
                if not await self.repository.claim_yearly_action(
                    tx, character.char_id, int(partner["npc_id"]), character.age, "try_for_baby"
                ):
                    raise FamilyRequirementError("You can try for a baby with this partner once per year.")
                probability = self._couple_fertility(character, partner)
                success = self.rng.random() < probability
                if success:
                    await self.repository.add_pregnancy(
                        tx,
                        char_id=character.char_id,
                        other_parent_npc_id=int(partner["npc_id"]),
                        conception_age=character.age,
                        due_age=character.age + 1,
                        accidental=False,
                    )
                    message = f"A pregnancy is underway with {partner['name']}; the baby is due after one year."
                else:
                    message = "There was no pregnancy this year. You can try again next year."
                await self.repository.insert_life_log(
                    tx, char_id=character.char_id, age=character.age, category="family",
                    text=message, importance=3, created_at=int(self.clock()),
                )
                return success, probability

    @staticmethod
    def _couple_fertility(character: Character, partner: dict[str, Any]) -> float:
        """Combine the gestational partner curve and the other partner's factor."""
        try:
            partner_gender = Gender(str(partner["gender"]))
        except ValueError:
            partner_gender = Gender.NON_BINARY
        if character.gender is Gender.FEMALE:
            female_age = character.age
            male_age = int(partner["age"]) if partner_gender is Gender.MALE else 30
        elif partner_gender is Gender.FEMALE:
            female_age = int(partner["age"])
            male_age = character.age
        else:
            return 0.0
        return 0.35 * calculate_fertility_factor(female_age) * calculate_male_fertility_factor(male_age)

    async def adopt(self, user_id: int) -> int:
        """Pay the indexed adoption cost and schedule an infant after one age tick."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 21, "adopt a child")
                if await self.repository.get_adoption(tx, character.char_id) is not None:
                    raise FamilyRequirementError("An adoption is already in progress.")
                if await self.repository.get_pregnancy(tx, character.char_id) is not None:
                    raise FamilyRequirementError("Resolve the current pregnancy before starting an adoption.")
                cost = scale_cents(dollars_to_cents(30_000), Decimal(str(character.price_index)))
                if character.cash + character.bank < cost:
                    raise InsufficientFunds("You need enough cash or bank balance to cover the adoption cost.")
                updated, _ = self._deduct_cash_bank(character, cost)
                updated = replace(updated, version=expected_version + 1)
                await self.repository.save_character(tx, updated, expected_version)
                await self.repository.add_adoption(tx, character.char_id, character.age, character.age + 1, cost)
                await self.repository.insert_life_log(
                    tx, char_id=character.char_id, age=character.age, category="family",
                    text=f"Started an adoption; the child will join the family after one year. Cost: {cost // 100:,} dollars.",
                    importance=3, created_at=int(self.clock()),
                )
                return cost

    async def buy_ring_options(self) -> tuple[dict[str, Any], ...]:
        """Return immutable view data for the ring shop."""
        return tuple({"id": item_id, **values} for item_id, values in RING_CATALOG.items())

    async def start_infidelity_choice(self, user_id: int) -> InfidelityPrompt:
        """Create a one-use choice prompt for a married character's temptation event."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "consider an affair")
                marriage = await self.repository.get_marriage(tx, character.char_id)
                if marriage is None:
                    raise NoActiveMarriage()
                if await self.repository.has_infidelity_choice(tx, character.char_id, character.age):
                    raise FamilyRequirementError("The relationship choice for this in-game year has already been resolved.")
                spouse = await self.repository.get_npc_owned(tx, character.char_id, int(marriage["spouse_npc_id"]))
                if spouse is None or not bool(spouse["is_alive"]):
                    raise FamilyRequirementError("There is no living spouse to betray.")
                nonce = secrets.token_urlsafe(16)
                now = int(self.clock())
                await self.repository.create_infidelity_prompt(
                    tx, character.char_id, int(spouse["npc_id"]), nonce, now, now + 300
                )
                return InfidelityPrompt(nonce, str(spouse["name"]), now + 300)

    async def resolve_infidelity_choice(self, user_id: int, nonce: str, cheat: bool) -> str:
        """Resolve a nonce-protected temptation choice and record an affair if chosen."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "resolve a relationship choice")
                prompt = await self.repository.get_infidelity_prompt(
                    tx, character.char_id, nonce, int(self.clock())
                )
                if prompt is None:
                    raise DateSessionExpired("This relationship choice expired. Start a new one with `/relationship temptation`.")
                marriage = await self.repository.get_marriage(tx, character.char_id)
                if marriage is None or int(marriage["spouse_npc_id"]) != int(prompt["spouse_npc_id"]):
                    raise FamilyRequirementError("The marriage ended before this choice was resolved.")
                now = int(self.clock())
                await self.repository.record_infidelity_choice(
                    tx,
                    character.char_id,
                    int(prompt["spouse_npc_id"]),
                    character.age,
                    "cheat" if cheat else "faithful",
                    now,
                )
                if cheat:
                    await self.repository.save_affair(
                        tx, character.char_id, int(prompt["spouse_npc_id"]), character.age, nonce
                    )
                    message = "You chose to cheat. There is a 35% chance of discovery each year."
                else:
                    message = "You stayed faithful and ended the temptation."
                await self.repository.delete_infidelity_prompt(tx, character.char_id, nonce)
                await self.repository.insert_life_log(
                    tx, char_id=character.char_id, age=character.age, category="relationship",
                    text=message, importance=3, created_at=now,
                )
                return message

    async def _create_child(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        other_parent_npc_id: Optional[int],
        *,
        adopted: bool,
    ) -> tuple[int, str]:
        """Create a child NPC with parent-average traits and a full-custody record."""
        other_parent = None
        if other_parent_npc_id is not None:
            other_parent = await self.repository.get_npc_owned(tx, character.char_id, other_parent_npc_id)
        if adopted or other_parent is None:
            means = (50.0, 50.0, 75.0)
        else:
            means = (
                (character.stats.looks + int(other_parent["looks"])) / 2,
                (character.stats.smarts + int(other_parent["smarts"])) / 2,
                (character.stats.health + int(other_parent["health"])) / 2,
            )
        gender = self.rng.choice(_NAME_GENDERS)
        fields = self._npc_fields(
            character,
            gender=gender,
            age=0,
            wealth_class="poor",
            occupation="Student",
            annual_income=0,
            means=means,
        )
        fields["wealth"] = 0
        npc_id = await self._insert_npc(tx, fields)
        score = self.rng.randint(80, 95)
        await self.repository.create_relationship(
            tx, char_id=character.char_id, npc_id=npc_id, relation_type="child", score=score, since_age=character.age
        )
        await self.repository.add_child(
            tx,
            npc_id=npc_id,
            char_id=character.char_id,
            other_parent_npc_id=other_parent_npc_id,
            custody="full",
            child_support=0,
        )
        return npc_id, str(fields["name"])

    async def advance_year(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        previous_age: int,
        personal_income: int,
        now: int,
    ) -> FamilyYearResult:
        """Settle family expenses/support and execute Stage 6 yearly step 11.

        This runs in the same BEGIN IMMEDIATE transaction as ``/life age``. It
        pays spouse wages/tax, child costs/support and alimony, completes adoptions
        and pregnancies, checks infidelity/divorce, then decays relationships and
        ages all NPCs. Stage 1-5 RNG is not consumed; this service owns a forked RNG.
        """
        updated = character
        messages: list[str] = []
        newborn_npc_ids: set[int] = set()
        tax_assessed = 0
        tax_paid = 0
        household_income = max(0, int(personal_income))
        marriage = await self.repository.get_marriage(tx, character.char_id)
        if marriage is not None:
            spouse = await self.repository.get_npc_owned(tx, character.char_id, int(marriage["spouse_npc_id"]))
            if spouse is not None and bool(spouse["is_alive"]):
                spouse_income = int(spouse["annual_income"])
                household_income += spouse_income
                if not character.in_prison:
                    joint_tax = calculate_joint_tax(max(0, personal_income) + spouse_income)
                    updated = replace(updated, cash=updated.cash + spouse_income)
                    updated, tax_unpaid = self._deduct_cash_bank(updated, joint_tax)
                    tax_assessed = joint_tax
                    tax_paid = max(0, joint_tax - tax_unpaid)
                    if tax_unpaid:
                        updated = replace(updated, debt_total=updated.debt_total + tax_unpaid)
                    messages.append(
                        f"Household income included {spouse_income // 100:,} dollars from {spouse['name']}; joint tax was {joint_tax // 100:,} dollars."
                    )
                else:
                    messages.append("Spouse income and household tax settlement were paused during imprisonment.")
            else:
                await self.repository.set_relationship_type(
                    tx, character.char_id, int(marriage["spouse_npc_id"]), "ex"
                )
                await self.repository.delete_marriage(tx, character.char_id)
                messages.append("The marriage ended after your spouse's death.")

        children = await self.repository.get_children(tx, character.char_id)
        for child in children:
            child_age = int(child["age"]) + (1 if bool(child["is_alive"]) else 0)
            custody = str(child["custody"])
            minor_alive = bool(child["is_alive"]) and child_age < 18
            if not character.in_prison and minor_alive and custody in {"full", "shared"}:
                cost = scale_cents(
                    dollars_to_cents(12_000),
                    Decimal(str(character.price_index))
                    * Decimal(str(_COST_OF_LIVING.get(character.wealth_class, 1.0)))
                    * (Decimal("0.5") if custody == "shared" else Decimal("1")),
                )
                updated, unpaid = self._deduct_cash_bank(updated, cost)
                if unpaid:
                    updated = replace(updated, debt_total=updated.debt_total + unpaid)
                messages.append(f"Child care cost for {child['name']}: {cost // 100:,} dollars.")
            if not character.in_prison and minor_alive and custody != "full":
                support = int((Decimal(max(0, personal_income)) * Decimal("0.15")).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
                await self.repository.update_child_support(tx, int(child["npc_id"]), support)
                updated, unpaid = self._deduct_cash_bank(updated, support)
                if unpaid:
                    updated = replace(updated, debt_total=updated.debt_total + unpaid)
                if support and child["other_parent_npc_id"] is not None:
                    await self.repository.add_npc_wealth(tx, int(child["other_parent_npc_id"]), support)
                if support:
                    messages.append(f"Child support paid for {child['name']}: {support // 100:,} dollars.")
            elif (child_age >= 18 or not bool(child["is_alive"])) and int(child["child_support"]) > 0:
                await self.repository.update_child_support(tx, int(child["npc_id"]), 0)
                if bool(child["is_alive"]):
                    messages.append(f"Child support ended for {child['name']} at age 18.")
                else:
                    messages.append(f"Child support ended for {child['name']} after their death.")

        alimony = await self.repository.get_alimony(tx, character.char_id)
        if alimony is not None and not character.in_prison:
            fraction = min(1.0, float(alimony["remaining_years"]))
            amount = int((Decimal(int(alimony["annual_amount"])) * Decimal(str(fraction))).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
            if bool(alimony["payer_is_player"]):
                updated, unpaid = self._deduct_cash_bank(updated, amount)
                if unpaid:
                    updated = replace(updated, debt_total=updated.debt_total + unpaid)
                if amount:
                    await self.repository.add_npc_wealth(tx, int(alimony["ex_npc_id"]), amount)
                    messages.append(f"Alimony paid: {amount // 100:,} dollars.")
            else:
                updated = replace(updated, cash=updated.cash + amount)
                await self.repository.add_npc_wealth(tx, int(alimony["ex_npc_id"]), -amount)
                if amount:
                    messages.append(f"Alimony received: {amount // 100:,} dollars.")
            await self.repository.update_alimony(
                tx, character.char_id, max(0.0, float(alimony["remaining_years"]) - 1.0)
            )

        pregnancy = await self.repository.get_pregnancy(tx, character.char_id)
        if pregnancy is not None and int(pregnancy["due_age"]) <= character.age:
            newborn_id, child_name = await self._create_child(
                tx, character, pregnancy["other_parent_npc_id"], adopted=False
            )
            newborn_npc_ids.add(newborn_id)
            await self.repository.delete_pregnancy(tx, character.char_id)
            messages.append(f"{child_name} joined the family.")

        adoption = await self.repository.get_adoption(tx, character.char_id)
        if adoption is not None and int(adoption["due_age"]) <= character.age:
            newborn_id, child_name = await self._create_child(tx, character, None, adopted=True)
            newborn_npc_ids.add(newborn_id)
            await self.repository.delete_adoption(tx, character.char_id)
            messages.append(f"The adoption was finalized: {child_name} joined the family.")

        if marriage is not None and not character.in_prison:
            affair = await self.repository.get_affair(tx, character.char_id)
            if affair is not None and int(affair["started_age"]) < character.age:
                if self.rng.random() < 0.35:
                    await self.repository.add_relationship_score(
                        tx, character.char_id, int(affair["spouse_npc_id"]), -40
                    )
                    await self.repository.delete_affair(tx, character.char_id)
                    messages.append("Your infidelity was discovered; your spouse's relationship score fell by 40.")
                    if self.rng.random() < 0.60:
                        expected = character.version
                        divorce, updated = await self._divorce_in_tx(
                            tx, updated, expected, reason="discovery", now=now, save_character=False
                        )
                        messages.append(divorce.message)

            # Below-20 spouse relationship scores can trigger an NPC-initiated divorce.
            current_marriage = await self.repository.get_marriage(tx, character.char_id)
            if current_marriage is not None:
                spouse_relation = await self.repository.get_person(
                    tx, character.char_id, int(current_marriage["spouse_npc_id"])
                )
                if spouse_relation is not None:
                    low_years = int(current_marriage.get("low_score_years", 0))
                    if int(spouse_relation["relationship_score"]) < 20:
                        low_years += 1
                    else:
                        low_years = 0
                    await self.repository.update_marriage_low_score_years(tx, character.char_id, low_years)
                    if low_years >= 2 and self.rng.random() < 0.50:
                        divorce, updated = await self._divorce_in_tx(
                            tx, updated, character.version, reason="npc_initiated", now=now, save_character=False
                        )
                        messages.append(divorce.message)

        # Accidentally conceived pregnancies are permitted while an adult is partnered.
        active = await self.repository.active_romance(tx, character.char_id)
        if (
            character.is_alive
            and not character.in_prison
            and character.age >= 18
            and active is not None
            and bool(active["is_alive"])
            and await self.repository.get_pregnancy(tx, character.char_id) is None
            and await self.repository.get_adoption(tx, character.char_id) is None
        ):
            fertility = self._couple_fertility(character, active)
            if fertility > 0 and self.rng.random() < 0.02 * fertility:
                await self.repository.add_pregnancy(
                    tx,
                    char_id=character.char_id,
                    other_parent_npc_id=int(active["npc_id"]),
                    conception_age=character.age,
                    due_age=character.age + 1,
                    accidental=True,
                )
                messages.append("An unexpected pregnancy began; the baby is due after one year.")

        # Step 11: decay scores for unattended connections, then age and roll NPC mortality.
        await self.repository.decay_relationships(tx, character.char_id, previous_age)
        npc_rows = await self.repository.list_live_npcs(tx, character.char_id)
        for npc in npc_rows:
            if int(npc["npc_id"]) in newborn_npc_ids:
                continue
            next_age = min(120, int(npc["age"]) + 1)
            risk = self._npc_death_chance(next_age, int(npc["health"]))
            alive = next_age < 120 and self.rng.random() >= risk
            await self.repository.update_npc_year(tx, int(npc["npc_id"]), next_age, alive=alive)
            if not alive:
                updated = await self._on_npc_death(tx, updated, npc, next_age, now, messages)

        romance = await self.repository.active_romance(tx, character.char_id)
        if (
            romance is not None
            and romance["relationship_type"] in {"partner", "fiance"}
            and not can_date_ages(character.age, int(romance["age"]))
        ):
            await self.repository.set_relationship_type(
                tx, character.char_id, int(romance["npc_id"]), "ex"
            )
            messages.append(f"The relationship with {romance['name']} ended as your ages no longer met dating rules.")
        if not character.in_prison:
            updated = await self._family_events(tx, updated, messages)
        return FamilyYearResult(updated, tuple(messages), tax_assessed, tax_paid, household_income)

    @staticmethod
    def _npc_death_chance(age: int, health: int) -> float:
        """Return an age- and health-sensitive annual NPC death probability."""
        if age >= 120:
            return 1.0
        age_risk = 0.0005 + max(0, age - 60) * 0.0015
        health_risk = max(0, 50 - health) * 0.0015
        if age < 18:
            age_risk *= 0.15
        return min(0.65, age_risk + health_risk)

    async def _on_npc_death(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        npc: dict[str, Any],
        death_age: int,
        now: int,
        messages: list[str],
    ) -> Character:
        """Apply grief, inheritance, or relationship changes after NPC death."""
        person = await self.repository.get_person(tx, character.char_id, int(npc["npc_id"]))
        if person is None:
            messages.append(f"{npc['name']} died at age {death_age}.")
            return character
        relation = str(person["relationship_type"])
        if relation == "parent":
            grief = self.rng.randint(15, 30)
            stats = replace(character.stats)
            stats.happiness = max(0, stats.happiness - grief)
            sibling_count = await self.repository.count_siblings(tx, character.char_id) + 1
            gross = int(npc["wealth"]) // sibling_count
            threshold = scale_cents(dollars_to_cents(1_000_000), Decimal(str(character.price_index)))
            tax = int(
                (Decimal(max(0, gross - threshold)) * Decimal("0.10"))
                .quantize(Decimal("1"), rounding=ROUND_HALF_UP)
            )
            inheritance = max(0, gross - tax)
            await self.repository.set_npc_wealth(tx, int(npc["npc_id"]), 0)
            if character.in_prison:
                messages.append(f"{npc['name']} died. Grief lowered happiness; inheritance was held during imprisonment.")
                return replace(character, stats=stats)
            messages.append(
                f"{npc['name']} died. Grief reduced happiness by {grief}; inheritance after tax was {inheritance // 100:,} dollars."
            )
            return replace(character, stats=stats, bank=character.bank + inheritance)
        if relation == "spouse":
            marriage = await self.repository.get_marriage(tx, character.char_id)
            if marriage is not None and int(marriage["spouse_npc_id"]) == int(npc["npc_id"]):
                await self.repository.delete_marriage(tx, character.char_id)
                await self.repository.delete_affair(tx, character.char_id)
                await self.repository.set_relationship_type(tx, character.char_id, int(npc["npc_id"]), "ex")
                messages.append(f"Your spouse {npc['name']} died; the marriage ended.")
                return character
        if relation in {"partner", "fiance"}:
            await self.repository.set_relationship_type(tx, character.char_id, int(npc["npc_id"]), "ex")
        messages.append(f"{npc['name']} ({relation}) died at age {death_age}.")
        return character

    async def _family_events(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        messages: list[str],
    ) -> Character:
        """Roll family reunion, sibling-rivalry, adult-child, and elder-care events."""
        updated = character
        siblings = [
            row for row in await self.repository.people_by_type(tx, character.char_id, ("sibling",))
            if bool(row["is_alive"])
        ]
        family = [
            row for row in await self.repository.people_by_type(tx, character.char_id, ("parent", "sibling"))
            if bool(row["is_alive"])
        ]
        if siblings and self.rng.random() < 0.04:
            sibling = self.rng.choice(siblings)
            delta = self.rng.randint(3, 10)
            await self.repository.add_relationship_score(tx, character.char_id, int(sibling["npc_id"]), -delta)
            messages.append(f"A bout of sibling rivalry strained things with {sibling['name']} (-{delta}).")
        elif family and self.rng.random() < 0.03:
            relative = self.rng.choice(family)
            delta = self.rng.randint(3, 8)
            await self.repository.add_relationship_score(tx, character.char_id, int(relative["npc_id"]), delta)
            stats = replace(updated.stats)
            stats.happiness = min(100, stats.happiness + 2)
            updated = replace(updated, stats=stats)
            messages.append(f"A family reunion brought {relative['name']} closer (+{delta}); happiness +2.")
        children = await self.repository.get_children(tx, character.char_id)
        adult_children = [child for child in children if int(child["age"]) >= 18 and bool(child["is_alive"])]
        if adult_children and character.age >= 60 and self.rng.random() < 0.05:
            child = self.rng.choice(adult_children)
            gift = dollars_to_cents(self.rng.randint(100, 2_000))
            updated = replace(updated, cash=updated.cash + gift)
            messages.append(f"Your adult child {child['name']} helped with {gift // 100:,} dollars.")
        elif adult_children and self.rng.random() < 0.03:
            child = self.rng.choice(adult_children)
            amount = dollars_to_cents(self.rng.randint(100, 1_000))
            updated, unpaid = self._deduct_cash_bank(updated, amount)
            if unpaid:
                updated = replace(updated, debt_total=updated.debt_total + unpaid)
            messages.append(f"Your adult child {child['name']} asked for {amount // 100:,} dollars.")
        parents = await self.repository.parent_relations(tx, character.char_id)
        elderly = [parent for parent in parents if bool(parent["is_alive"]) and int(parent["age"]) >= 75]
        if elderly and self.rng.random() < 0.03:
            parent = self.rng.choice(elderly)
            care_cost = dollars_to_cents(self.rng.randint(250, 2_500))
            updated, unpaid = self._deduct_cash_bank(updated, care_cost)
            if unpaid:
                updated = replace(updated, debt_total=updated.debt_total + unpaid)
            messages.append(f"Your elderly parent {parent['name']} needed care costing {care_cost // 100:,} dollars.")
        return updated

    def _roll_custody(self, character: Character, annual_income: int) -> str:
        """Choose full/shared/none custody using karma, income, and criminal history."""
        income_factor = min(20, max(0, int(annual_income // dollars_to_cents(10_000))))
        criminal_penalty = min(35, max(0, int(character.criminal_record)) * 5)
        full = max(5, 60 + (character.stats.karma - 50) // 2 + income_factor - criminal_penalty)
        shared = max(5, 30 + criminal_penalty // 2)
        none = max(5, 10 + criminal_penalty - income_factor)
        return self.rng.weighted_choice(("full", "shared", "none"), (full, shared, none))

    @staticmethod
    def _deduct_cash_bank(character: Character, amount: int) -> tuple[Character, int]:
        """Deduct integer cents from cash then bank without allowing negatives."""
        amount = max(0, int(amount))
        cash_paid = min(max(0, character.cash), amount)
        remaining = amount - cash_paid
        bank_paid = min(max(0, character.bank), remaining)
        unpaid = remaining - bank_paid
        return replace(
            character,
            cash=max(0, character.cash - cash_paid),
            bank=max(0, character.bank - bank_paid),
        ), unpaid

    async def _pay_divorce_assets(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        amount: int,
        *,
        marriage_timestamp: int,
        protect_cash: int = 0,
        protect_bank: int = 0,
        marital_only: bool,
    ) -> tuple[Character, int]:
        """Pay a divorce settlement by liquid cash, then assets, then recorded debt."""
        if marital_only:
            updated, remaining = self._pay_from_liquid_assets(
                character, amount, protected_cash=protect_cash, protected_bank=protect_bank
            )
            assets = await self.repository.get_marital_assets(
                tx, character.char_id, marriage_timestamp
            )
        else:
            updated, remaining = self._deduct_cash_bank(character, amount)
            assets = await self.repository.get_all_assets(tx, character.char_id)
        for asset in assets:
            if remaining <= 0:
                break
            used = await self.repository.reduce_asset(tx, int(asset["asset_id"]), remaining)
            remaining -= used
        if remaining > 0:
            updated = replace(updated, debt_total=updated.debt_total + remaining)
        return updated, remaining

    @staticmethod
    def _pay_from_liquid_assets(
        character: Character,
        amount: int,
        *,
        protected_cash: int = 0,
        protected_bank: int = 0,
    ) -> tuple[Character, int]:
        """Pay only from available cash/bank above prenup-protected baselines."""
        amount = max(0, int(amount))
        available_cash = max(0, character.cash - protected_cash)
        cash_paid = min(available_cash, amount)
        remaining = amount - cash_paid
        available_bank = max(0, character.bank - protected_bank)
        bank_paid = min(available_bank, remaining)
        remaining -= bank_paid
        return replace(
            character,
            cash=max(0, character.cash - cash_paid),
            bank=max(0, character.bank - bank_paid),
        ), remaining

    async def _settle_player_payment(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        amount: int,
        *,
        allow_assets: bool = False,
    ) -> tuple[Character, int]:
        """Pay a household expense, optionally liquidating all player assets."""
        updated, unpaid = self._deduct_cash_bank(character, amount)
        if allow_assets and unpaid:
            for asset in await self.repository.get_all_assets(tx, character.char_id):
                if unpaid <= 0:
                    break
                used = await self.repository.reduce_asset(tx, int(asset["asset_id"]), unpaid)
                unpaid -= used
        if unpaid:
            updated = replace(updated, debt_total=updated.debt_total + unpaid)
        return updated, unpaid
```

## `lifeline/core/life_engine.py`

```python
"""Birth creation, stat rolls, and one-year life simulation."""
from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass, replace
from typing import Any, Callable, Optional

import aiosqlite

from .careers import CareerService
from .crime import CrimeService, TaxEvasionPrompt, TrialPrompt
from .config import GameBalance
from .education import advance_school_year
from .family import FamilyService
from .errors import (
    CharacterAlreadyExists,
    CharacterDead,
    CharacterNotFound,
    ConcurrentUpdate,
    PendingEventExists,
    ValidationError,
)
from .events import EventEngine, EventPrompt
from .locks import UserLockRegistry
from .models import Character, Gender, HiddenTraits, LifeStage, Stats
from .rng import RNG

logger = logging.getLogger("lifeline.life")
_NAME_RE = re.compile(r"[^\x00-\x1f\x7f]+")


@dataclass(frozen=True, slots=True)
class YearOutcome:
    """Result of applying one simulated year to a character."""

    character: Character
    previous_age: int
    new_age: int
    died: bool
    death_cause: Optional[str]
    stat_changes: dict[str, int]
    previous_stage: LifeStage
    new_stage: LifeStage
    log_messages: tuple[str, ...]
    pending_event: Optional[EventPrompt] = None
    pending_trial: Optional[TrialPrompt] = None
    pending_tax: Optional[TaxEvasionPrompt] = None


def _clamp_stat(value: int | float) -> int:
    return max(GameBalance.STAT_MIN, min(GameBalance.STAT_MAX, int(round(value))))


def _random_stat(rng: RNG, mean: float, stddev: float) -> int:
    return _clamp_stat(rng.gauss(mean, stddev))


def roll_birth_attributes(rng: RNG) -> tuple[Stats, HiddenTraits, str]:
    """Roll reproducible starting stats, hidden traits, and household wealth class."""
    hidden = HiddenTraits(
        genetic_health_mod=rng.randint(-10, 10),
        lifespan_mod=rng.randint(*GameBalance.LIFESPAN_MOD_RANGE),
        luck=rng.randint(-5, 5),
        temperament=rng.weighted_choice(
            ("calm", "neutral", "volatile"),
            (0.25, 0.55, 0.20),
        ),
    )
    wealth_class = rng.weighted_choice(
        tuple(GameBalance.WEALTH_CLASSES),
        tuple(GameBalance.WEALTH_CLASSES.values()),
    )
    stats = Stats(
        health=_clamp_stat(
            _random_stat(rng, GameBalance.HEALTH_INIT_MEAN, GameBalance.HEALTH_INIT_STDDEV)
            + hidden.genetic_health_mod
        ),
        happiness=_random_stat(rng, GameBalance.HAPPINESS_INIT_MEAN, GameBalance.HAPPINESS_INIT_STDDEV),
        smarts=_random_stat(rng, GameBalance.SMARTS_INIT_MEAN, GameBalance.SMARTS_INIT_STDDEV),
        looks=_random_stat(rng, GameBalance.LOOKS_INIT_MEAN, GameBalance.LOOKS_INIT_STDDEV),
        fitness=_random_stat(rng, GameBalance.FITNESS_INIT_MEAN, GameBalance.FITNESS_INIT_STDDEV),
        karma=_clamp_stat(50 + rng.randint(-10, 10)),
        stress=GameBalance.BASE_STRESS,
        addiction=0,
        fame=0,
        credit_score=None,
    ).clamp_all()
    return stats, hidden, wealth_class


def simulate_year(character: Character, rng: RNG, *, now: Optional[int] = None) -> YearOutcome:
    """Purely calculate one year's aging effects without writing to a database.

    Each call advances exactly one year. Stats remain within 0–100 and a character
    is guaranteed to die no later than ``GameBalance.MAX_AGE``.
    """
    if not character.is_alive:
        raise CharacterDead()
    if character.age < 0:
        raise ValidationError("Character age cannot be negative.")
    if character.age >= GameBalance.MAX_AGE:
        raise CharacterDead("This life has reached the maximum age and has ended.")

    old_age = character.age
    new_age = old_age + 1
    old_stage = character.life_stage
    stats = replace(character.stats)
    before = stats.to_dict()

    # Health varies slightly year to year; age and inherited resilience shape the drift.
    health_delta = rng.randint(-1, 1)
    if new_age >= 50:
        health_delta -= 1
    if new_age >= 70:
        health_delta -= 1
    if character.hidden.genetic_health_mod >= 7 and new_age < 70:
        health_delta += 1
    elif character.hidden.genetic_health_mod <= -7:
        health_delta -= 1
    stats.health = _clamp_stat(stats.health + health_delta)

    # Happiness trends gently toward the game's neutral point; stress recovers naturally.
    target = GameBalance.HAPPINESS_DRIFT_TARGET
    if stats.happiness < target:
        stats.happiness += GameBalance.HAPPINESS_DRIFT_RATE
    elif stats.happiness > target:
        stats.happiness -= GameBalance.HAPPINESS_DRIFT_RATE
    stats.stress = max(0, stats.stress - GameBalance.STRESS_DECAY_PER_YEAR)

    # Childhood and young adulthood build learning and fitness; aging slowly reduces fitness.
    if 6 <= new_age <= 29 and rng.random() < 0.55:
        stats.smarts += 1
    if new_age <= 25 and rng.random() < 0.35:
        stats.fitness += 1
    elif new_age >= 40:
        stats.fitness -= 1
    if new_age >= 70:
        stats.fitness -= 1
    if new_age >= 35 and new_age % 5 == 0:
        stats.looks -= 1

    stats = stats.clamp_all()
    death_cause: Optional[str] = None

    # A low-health character is at higher risk. The hazard rises after expected lifespan.
    expected_lifespan = (
        GameBalance.BASE_LIFESPAN_MEAN
        + character.hidden.lifespan_mod
        + round(character.hidden.genetic_health_mod * 0.25)
    )
    age_hazard = 0.001 + max(0, new_age - 55) * 0.00035
    lifespan_hazard = max(0, new_age - expected_lifespan) * 0.018
    health_multiplier = max(0.55, min(1.8, 1.0 + (50 - stats.health) * 0.012))
    mortality_chance = min(0.95, (age_hazard + lifespan_hazard) * health_multiplier)
    if stats.health <= 0:
        death_cause = "illness"
    elif new_age >= GameBalance.MAX_AGE or rng.random() < mortality_chance:
        death_cause = "natural causes"

    timestamp = int(time.time()) if now is None else int(now)
    updated = replace(
        character,
        age=new_age,
        stats=stats,
        is_alive=death_cause is None,
        died_at=timestamp if death_cause else None,
        death_cause=death_cause,
        death_age=new_age if death_cause else None,
        last_age_at=timestamp,
    )
    new_stage = updated.life_stage
    changes = {
        key: int(stats.to_dict()[key] - before[key])
        for key in stats.to_dict()
        if stats.to_dict()[key] != before[key]
    }

    messages = [f"{updated.name or 'Your character'} turned {new_age}."]
    if new_stage != old_stage:
        messages.append(f"Entered the {new_stage.value.replace('_', ' ')} stage of life.")
    if death_cause:
        messages.append(f"Life ended at age {new_age} from {death_cause}.")

    return YearOutcome(
        character=updated,
        previous_age=old_age,
        new_age=new_age,
        died=death_cause is not None,
        death_cause=death_cause,
        stat_changes=changes,
        previous_stage=old_stage,
        new_stage=new_stage,
        log_messages=tuple(messages),
    )


class LifeEngine:
    """Persistence-backed API for creating, viewing, and aging a user's life."""

    def __init__(
        self,
        db: Any,
        rng: RNG,
        locks: Optional[UserLockRegistry] = None,
        clock: Callable[[], float] = time.time,
        event_engine: Optional[EventEngine] = None,
        event_chance: Optional[float] = None,
        career_service: Optional[CareerService] = None,
        family_service: Optional[FamilyService] = None,
        crime_service: Optional[CrimeService] = None,
    ) -> None:
        self.db = db
        self.rng = rng
        self.locks = locks or UserLockRegistry()
        self.clock = clock
        self.events = event_engine or EventEngine(
            db,
            rng,
            self.locks,
            event_chance=event_chance,
        )
        self.careers = career_service or CareerService(db, rng, self.locks, clock=clock)
        self.family = family_service or FamilyService(db, rng, self.locks, clock=clock)
        self.crimes = crime_service or CrimeService(
            db, rng, self.locks, family_service=self.family, clock=clock
        )

    async def create_character(
        self,
        user_id: int,
        name: str,
        *,
        gender: Gender | str = Gender.MALE,
        country: str = "usa",
        parent_char_id: Optional[int] = None,
    ) -> Character:
        """Create one active life for a Discord user, starting at age zero."""
        if not isinstance(user_id, int) or user_id <= 0:
            raise ValidationError("A valid Discord user ID is required.")
        clean_name = self._validate_name(name)
        clean_country = self._validate_country(country)
        try:
            clean_gender = gender if isinstance(gender, Gender) else Gender(str(gender).lower())
        except ValueError as exc:
            raise ValidationError("Choose male, female, or non-binary.") from exc

        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                cursor = await tx.execute(
                    "SELECT char_id FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
                    (user_id,),
                )
                if await cursor.fetchone():
                    raise CharacterAlreadyExists()

                generation = 1
                if parent_char_id is not None:
                    cursor = await tx.execute(
                        "SELECT data_json FROM characters WHERE char_id = ?",
                        (parent_char_id,),
                    )
                    parent_row = await cursor.fetchone()
                    if parent_row is None:
                        raise ValidationError("The selected parent life could not be found.")
                    parent = Character.from_dict(json.loads(parent_row["data_json"]))
                    generation = parent.generation + 1

                stats, hidden, wealth_class = roll_birth_attributes(self.rng)
                now = int(self.clock())
                character = Character(
                    user_id=user_id,
                    name=clean_name,
                    gender=clean_gender,
                    country=clean_country,
                    wealth_class=wealth_class,
                    age=0,
                    stats=stats,
                    hidden=hidden,
                    cash=0,
                    bank=0,
                    debt_total=0,
                    parent_char_id=parent_char_id,
                    generation=generation,
                    last_age_at=now,
                    born_at=now,
                )
                cursor = await tx.execute(
                    """INSERT INTO characters (
                           user_id, is_alive, name, gender, country, wealth_class, age,
                           stats_json, hidden_json, version, last_age_at, born_at,
                           died_at, death_cause, death_age, data_json
                       ) VALUES (?, 1, ?, ?, ?, ?, 0, ?, ?, 0, ?, ?, NULL, NULL, NULL, ?)""",
                    self._row_values(character),
                )
                char_id = int(cursor.lastrowid)
                character = replace(character, char_id=char_id)
                await self._refresh_data_json(tx, character)
                await self.family.initialize_family(tx, character)
                await self.crimes.initialize_character(tx, character)
                await self._insert_log(
                    tx,
                    character,
                    age=0,
                    category="birth",
                    text=f"{clean_name} was born into a {wealth_class} household.",
                    importance=3,
                    created_at=now,
                )
                return character

    async def get_active_character(self, user_id: int) -> Character:
        """Return a user's active character or raise ``CharacterNotFound``."""
        row = await self.db.fetchone(
            "SELECT data_json FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        if row is None:
            latest = await self.db.fetchone(
                "SELECT data_json FROM characters WHERE user_id = ? ORDER BY char_id DESC LIMIT 1",
                (user_id,),
            )
            if latest is not None:
                raise CharacterDead()
            raise CharacterNotFound()
        return Character.from_dict(json.loads(row["data_json"]))

    async def age_up(self, user_id: int) -> YearOutcome:
        """Advance the active life by one year as one serialized DB transaction."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                cursor = await tx.execute(
                    "SELECT data_json, version FROM characters "
                    "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
                    (user_id,),
                )
                row = await cursor.fetchone()
                if row is None:
                    # Distinguish a completed life from a user who never started.
                    cursor = await tx.execute(
                        "SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,)
                    )
                    if await cursor.fetchone():
                        raise CharacterDead()
                    raise CharacterNotFound()

                character = Character.from_dict(json.loads(row["data_json"]))
                # A pending choice must be resolved before the next simulated year.
                cursor = await tx.execute(
                    "SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1",
                    (character.char_id,),
                )
                if await cursor.fetchone():
                    raise PendingEventExists()
                await self.crimes.ensure_no_pending_decision(tx, character.char_id)

                # Keep the database version authoritative if a caller's JSON was stale.
                character.version = int(row["version"])
                timestamp = int(self.clock())
                outcome = simulate_year(character, self.rng, now=timestamp)
                school_progress = advance_school_year(outcome.character)
                career_progress = await self.careers.advance_year(
                    tx,
                    school_progress.character,
                    previous_age=outcome.previous_age,
                    now=timestamp,
                )
                personal_income = max(0, career_progress.character.cash - school_progress.character.cash)
                family_progress = await self.family.advance_year(
                    tx,
                    career_progress.character,
                    previous_age=outcome.previous_age,
                    personal_income=personal_income,
                    now=timestamp,
                )
                crime_progress = await self.crimes.advance_year(
                    tx,
                    family_progress.character,
                    previous_age=outcome.previous_age,
                    personal_income=personal_income,
                    household_income=family_progress.household_income,
                    tax_assessed=family_progress.tax_assessed,
                    tax_paid=family_progress.tax_paid,
                    now=timestamp,
                )
                updated = replace(crime_progress.character, version=character.version + 1)
                all_messages = (
                    outcome.log_messages
                    + school_progress.messages
                    + career_progress.messages
                    + family_progress.messages
                    + crime_progress.messages
                )
                outcome = replace(outcome, character=updated, log_messages=all_messages)
                await self._save_character(tx, updated, expected_version=character.version)

                for message in outcome.log_messages:
                    if message.startswith("Life ended at age"):
                        category, importance = "death", 5
                    elif message in school_progress.messages:
                        category, importance = "education", 3
                    elif message in career_progress.messages:
                        category, importance = "career", 2
                    elif message in family_progress.messages:
                        category, importance = "family", 2
                    elif message in crime_progress.messages:
                        category, importance = ("prison" if "prison" in message.lower() else "crime"), 3
                    else:
                        category = "aging"
                        importance = 3 if "stage of life" in message else 1
                    await self._insert_log(
                        tx,
                        updated,
                        age=updated.age,
                        category=category,
                        text=message,
                        importance=importance,
                        created_at=timestamp,
                    )

                pending_event = None
                has_stage7_prompt = crime_progress.pending_trial is not None or crime_progress.pending_tax is not None
                if updated.is_alive and not updated.in_prison and not has_stage7_prompt:
                    pending_event = await self.events.maybe_create_pending(
                        tx,
                        updated,
                        now=timestamp,
                    )
                    if pending_event is not None:
                        await self._insert_log(
                            tx,
                            updated,
                            age=updated.age,
                            category="event",
                            text=f"A choice event began: {pending_event.event.title}.",
                            importance=2,
                            created_at=timestamp,
                        )

                return replace(
                    outcome,
                    character=updated,
                    pending_event=pending_event,
                    pending_trial=crime_progress.pending_trial,
                    pending_tax=crime_progress.pending_tax,
                )

    @staticmethod
    def _validate_name(name: str) -> str:
        if not isinstance(name, str):
            raise ValidationError("Enter a character name.")
        clean = " ".join(name.split()).strip()
        if not clean or len(clean) > 32 or not _NAME_RE.fullmatch(clean):
            raise ValidationError("Name must be 1–32 characters and contain no control characters.")
        return clean

    @staticmethod
    def _validate_country(country: str) -> str:
        if not isinstance(country, str):
            raise ValidationError("Enter a country or region code.")
        clean = " ".join(country.split()).strip().lower()
        if not clean or len(clean) > 40 or not _NAME_RE.fullmatch(clean):
            raise ValidationError("Country or region must be 1–40 characters.")
        return clean

    @staticmethod
    def _row_values(character: Character) -> tuple[Any, ...]:
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        hidden_json = json.dumps({
            "genetic_health_mod": character.hidden.genetic_health_mod,
            "lifespan_mod": character.hidden.lifespan_mod,
            "luck": character.hidden.luck,
            "temperament": character.hidden.temperament,
        }, separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        return (
            character.user_id,
            character.name,
            character.gender.value,
            character.country,
            character.wealth_class,
            stats_json,
            hidden_json,
            character.last_age_at,
            character.born_at,
            data_json,
        )

    async def _refresh_data_json(self, tx: aiosqlite.Connection, character: Character) -> None:
        """Persist a newly assigned ID to the JSON snapshot."""
        await tx.execute(
            "UPDATE characters SET data_json = ? WHERE char_id = ?",
            (json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False), character.char_id),
        )

    async def _save_character(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        expected_version: int,
    ) -> None:
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        hidden_json = json.dumps({
            "genetic_health_mod": character.hidden.genetic_health_mod,
            "lifespan_mod": character.hidden.lifespan_mod,
            "luck": character.hidden.luck,
            "temperament": character.hidden.temperament,
        }, separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET
                   is_alive = ?, name = ?, gender = ?, country = ?, wealth_class = ?, age = ?,
                   stats_json = ?, hidden_json = ?, version = ?, last_age_at = ?,
                   died_at = ?, death_cause = ?, death_age = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (
                int(character.is_alive), character.name, character.gender.value,
                character.country, character.wealth_class, character.age,
                stats_json, hidden_json, character.version, character.last_age_at,
                character.died_at, character.death_cause, character.death_age,
                data_json, character.char_id, expected_version,
            ),
        )
        if cursor.rowcount != 1:
            raise ConcurrentUpdate()

    @staticmethod
    async def _insert_log(
        tx: aiosqlite.Connection,
        character: Character,
        *,
        age: int,
        category: str,
        text: str,
        importance: int,
        created_at: int,
    ) -> None:
        await tx.execute(
            """INSERT INTO life_logs (char_id, age, category, text, importance, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (character.char_id, age, category, text, importance, created_at),
        )
```

## `lifeline/core/migrations/006_crime_prison.sql`

```sql
-- Stage 7: crime, criminal careers, taxes/audits, trials, and prison.
-- Preserve the historical career rows while extending the allowed prison end reason.
CREATE TABLE career_history_stage7 (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id     INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    career_id   TEXT NOT NULL,
    max_level   INTEGER NOT NULL CHECK (max_level >= 1),
    start_age   INTEGER NOT NULL CHECK (start_age >= 0),
    end_age     INTEGER,
    end_reason  TEXT,
    CHECK (
        (end_age IS NULL AND end_reason IS NULL)
        OR
        (end_age IS NOT NULL AND end_reason IN ('quit', 'fired', 'retired', 'died', 'prison'))
    )
);
INSERT INTO career_history_stage7(id, char_id, career_id, max_level, start_age, end_age, end_reason)
SELECT id, char_id, career_id, max_level, start_age, end_age, end_reason FROM career_history;
DROP TABLE career_history;
ALTER TABLE career_history_stage7 RENAME TO career_history;
CREATE INDEX IF NOT EXISTS idx_career_history_character
    ON career_history(char_id, start_age DESC);

CREATE TABLE IF NOT EXISTS crime_profiles (
    char_id             INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    dirty_cash          INTEGER NOT NULL DEFAULT 0 CHECK (dirty_cash >= 0),
    career_rank         TEXT,
    career_years        INTEGER NOT NULL DEFAULT 0 CHECK (career_years >= 0),
    career_level        INTEGER NOT NULL DEFAULT -1 CHECK (career_level BETWEEN -1 AND 5),
    last_crime_id       TEXT,
    evaded_tax          INTEGER NOT NULL DEFAULT 0 CHECK (evaded_tax >= 0),
    gang_protected      INTEGER NOT NULL DEFAULT 0 CHECK (gang_protected IN (0, 1)),
    escaped             INTEGER NOT NULL DEFAULT 0 CHECK (escaped IN (0, 1)),
    juvenile_release_age INTEGER CHECK (juvenile_release_age BETWEEN 0 AND 120),
    last_release_age    INTEGER CHECK (last_release_age BETWEEN 0 AND 120),
    front_business      INTEGER NOT NULL DEFAULT 0 CHECK (front_business IN (0, 1))
);
INSERT OR IGNORE INTO crime_profiles(char_id) SELECT char_id FROM characters;

CREATE TABLE IF NOT EXISTS crime_previews (
    char_id            INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    crime_id           TEXT NOT NULL,
    age                INTEGER NOT NULL CHECK (age >= 0),
    nonce              TEXT NOT NULL UNIQUE,
    success_chance     REAL NOT NULL CHECK (success_chance BETWEEN 3.0 AND 97.0),
    catch_chance       REAL NOT NULL CHECK (catch_chance BETWEEN 3.0 AND 97.0),
    loot_min           INTEGER NOT NULL CHECK (loot_min >= 0),
    loot_max           INTEGER NOT NULL CHECK (loot_max >= loot_min),
    salary_snapshot    INTEGER NOT NULL DEFAULT 0 CHECK (salary_snapshot >= 0),
    created_at         INTEGER NOT NULL,
    expires_at         INTEGER NOT NULL CHECK (expires_at >= created_at)
);

CREATE TABLE IF NOT EXISTS crime_attempts (
    attempt_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id          INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    crime_id         TEXT NOT NULL,
    age              INTEGER NOT NULL CHECK (age >= 0),
    source           TEXT NOT NULL DEFAULT 'attempt'
                     CHECK (source IN ('attempt', 'career_arrest', 'escape_rearrest', 'tax_audit')),
    success          INTEGER NOT NULL CHECK (success IN (0, 1)),
    caught           INTEGER NOT NULL CHECK (caught IN (0, 1)),
    loot             INTEGER NOT NULL DEFAULT 0 CHECK (loot >= 0),
    success_chance   REAL NOT NULL CHECK (success_chance BETWEEN 0.0 AND 100.0),
    catch_chance     REAL NOT NULL CHECK (catch_chance BETWEEN 0.0 AND 100.0),
    case_status      TEXT NOT NULL DEFAULT 'clear'
                     CHECK (case_status IN ('clear', 'pending', 'convicted', 'acquitted')),
    lawyer_tier      TEXT CHECK (lawyer_tier IN ('public', 'standard', 'elite')),
    sentence_years   INTEGER NOT NULL DEFAULT 0 CHECK (sentence_years >= 0),
    life_sentence    INTEGER NOT NULL DEFAULT 0 CHECK (life_sentence IN (0, 1)),
    record_sealed    INTEGER NOT NULL DEFAULT 0 CHECK (record_sealed IN (0, 1)),
    fine_paid        INTEGER NOT NULL DEFAULT 0 CHECK (fine_paid >= 0),
    created_at       INTEGER NOT NULL,
    resolved_at      INTEGER
);
CREATE INDEX IF NOT EXISTS idx_crime_attempts_character_age
    ON crime_attempts(char_id, age DESC, attempt_id DESC);

CREATE TABLE IF NOT EXISTS crime_trials (
    char_id      INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    attempt_id   INTEGER NOT NULL UNIQUE REFERENCES crime_attempts(attempt_id) ON DELETE CASCADE,
    nonce        TEXT NOT NULL UNIQUE,
    created_at   INTEGER NOT NULL
);

-- The Stage 6 yearly_counters table requires an NPC foreign key. This fallback
-- counter supports migrated lives that predate family NPC initialization.
CREATE TABLE IF NOT EXISTS crime_yearly_actions (
    char_id  INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age      INTEGER NOT NULL CHECK (age >= 0),
    action   TEXT NOT NULL,
    count    INTEGER NOT NULL DEFAULT 0 CHECK (count >= 0),
    PRIMARY KEY(char_id, age, action)
);

CREATE TABLE IF NOT EXISTS crime_cashflows (
    flow_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id    INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age        INTEGER NOT NULL CHECK (age >= 0),
    action     TEXT NOT NULL CHECK (action IN ('crime_income', 'career_income', 'launder', 'fine', 'tax', 'audit')),
    amount     INTEGER NOT NULL CHECK (amount >= 0),
    created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_crime_cashflows_character_age
    ON crime_cashflows(char_id, age, action);

CREATE TABLE IF NOT EXISTS crime_laundering (
    laundering_id INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id       INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age           INTEGER NOT NULL CHECK (age >= 0),
    gross_amount  INTEGER NOT NULL CHECK (gross_amount > 0),
    fee_amount    INTEGER NOT NULL CHECK (fee_amount >= 0),
    net_amount    INTEGER NOT NULL CHECK (net_amount >= 0),
    created_at    INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_crime_laundering_character_age
    ON crime_laundering(char_id, age);

CREATE TABLE IF NOT EXISTS crime_tax_prompts (
    char_id      INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    nonce        TEXT NOT NULL UNIQUE,
    age          INTEGER NOT NULL CHECK (age >= 0),
    tax_due      INTEGER NOT NULL CHECK (tax_due >= 0),
    prepaid      INTEGER NOT NULL CHECK (prepaid IN (0, 1)),
    paid_amount  INTEGER NOT NULL DEFAULT 0 CHECK (paid_amount >= 0),
    created_at   INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS crime_tax_choices (
    choice_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id        INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age            INTEGER NOT NULL CHECK (age >= 0),
    choice         TEXT NOT NULL CHECK (choice IN ('pay', 'evade_50', 'evade_75', 'evade_100')),
    tax_due        INTEGER NOT NULL CHECK (tax_due >= 0),
    evaded_amount  INTEGER NOT NULL CHECK (evaded_amount >= 0),
    created_at     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS crime_audits (
    audit_id           INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id            INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age                INTEGER NOT NULL CHECK (age >= 0),
    audit_chance       REAL NOT NULL CHECK (audit_chance BETWEEN 0.0 AND 100.0),
    triggered          INTEGER NOT NULL CHECK (triggered IN (0, 1)),
    tax_evasion_found  INTEGER NOT NULL CHECK (tax_evasion_found IN (0, 1)),
    back_taxes         INTEGER NOT NULL DEFAULT 0 CHECK (back_taxes >= 0),
    sentence_years     INTEGER NOT NULL DEFAULT 0 CHECK (sentence_years >= 0),
    outcome            TEXT NOT NULL,
    created_at         INTEGER NOT NULL
);

-- Minimal persisted loan data for prison-only automatic annual payments.
CREATE TABLE IF NOT EXISTS loans (
    loan_id          INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id          INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    loan_type        TEXT NOT NULL DEFAULT 'personal',
    balance          INTEGER NOT NULL CHECK (balance >= 0),
    annual_payment   INTEGER NOT NULL CHECK (annual_payment >= 0),
    missed_payments  INTEGER NOT NULL DEFAULT 0 CHECK (missed_payments >= 0),
    status           TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'paid', 'defaulted'))
);
CREATE INDEX IF NOT EXISTS idx_loans_character_status ON loans(char_id, status);
```

## `lifeline/core/models.py`

```python
"""
Data models for LIFELINE bot.
All game entities as dataclasses with type hints.
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, List, Dict, Any
from enum import Enum


class Gender(str, Enum):
    MALE = "male"
    FEMALE = "female"
    NON_BINARY = "non_binary"


class LifeStage(str, Enum):
    BABY = "baby"
    CHILD = "child"
    TEEN = "teen"
    YOUNG_ADULT = "young_adult"
    ADULT = "adult"
    MIDDLE_AGE = "middle_age"
    SENIOR = "senior"


class HousingType(str, Enum):
    PARENTS = "parents"
    RENT = "rent"
    OWNED = "owned"
    HOMELESS = "homeless"
    PRISON = "prison"


class EducationLevel(str, Enum):
    NONE = "none"
    PRIMARY = "primary"
    HIGH_SCHOOL = "high_school"
    BACHELOR = "bachelor"
    MASTER = "master"
    DOCTORATE = "doctorate"


class RelationshipType(str, Enum):
    PARENT = "parent"
    SIBLING = "sibling"
    CHILD = "child"
    FRIEND = "friend"
    PARTNER = "partner"
    FIANCE = "fiance"
    SPOUSE = "spouse"
    EX = "ex"
    ENEMY = "enemy"
    COWORKER = "coworker"


class LoanType(str, Enum):
    PERSONAL = "personal"
    STUDENT = "student"
    MORTGAGE = "mortgage"
    AUTO = "auto"
    PAYDAY = "payday"
    LOAN_SHARK = "loan_shark"


class LoanStatus(str, Enum):
    ACTIVE = "active"
    PAID = "paid"
    DEFAULTED = "defaulted"
    DISCHARGED = "discharged"


class DiseaseStatus(str, Enum):
    ACTIVE = "active"
    CURED = "cured"
    CHRONIC = "chronic"
    IN_REMISSION = "in_remission"


class CrimeResult(str, Enum):
    SUCCESS = "success"
    FAILED = "failed"
    CAUGHT = "caught"


class JobAction(str, Enum):
    WORK_HARD = "hard"
    WORK_NORMAL = "normal"
    WORK_SLACK = "slack"


class StudyEffort(str, Enum):
    HARD = "hard"
    NORMAL = "normal"
    SLACK = "slack"


class Lifestyle(str, Enum):
    FRUGAL = "frugal"
    NORMAL = "normal"
    LAVISH = "lavish"


class PrisonAction(str, Enum):
    BEHAVE = "behave"
    WORKOUT = "workout"
    STUDY = "study"
    RIOT = "riot"
    ESCAPE = "escape"
    GANG = "gang"


class TradeStatus(str, Enum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    DECLINED = "declined"
    CANCELLED = "cancelled"
    EXPIRED = "expired"
    FAILED = "failed"


class EventType(str, Enum):
    AUTO = "auto"
    CHOICE = "choice"


class EventPolarity(str, Enum):
    POSITIVE = "positive"
    NEGATIVE = "negative"
    NEUTRAL = "neutral"


@dataclass
class Stats:
    """Core character stats (0-100)."""
    health: int = 80
    happiness: int = 70
    smarts: int = 50
    looks: int = 50
    fitness: int = 40
    karma: int = 50
    stress: int = 10
    addiction: int = 0
    fame: int = 0
    credit_score: Optional[int] = None

    def clamp_all(self) -> "Stats":
        """Return a copy with game stats clamped to 0–100 (credit score 300–850)."""
        def clamp(value: int | float) -> int:
            return max(0, min(100, int(round(value))))

        return Stats(
            health=clamp(self.health),
            happiness=clamp(self.happiness),
            smarts=clamp(self.smarts),
            looks=clamp(self.looks),
            fitness=clamp(self.fitness),
            karma=clamp(self.karma),
            stress=clamp(self.stress),
            addiction=clamp(self.addiction),
            fame=clamp(self.fame),
            credit_score=(max(300, min(850, int(round(self.credit_score)))) if self.credit_score is not None else None),
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "health": self.health,
            "happiness": self.happiness,
            "smarts": self.smarts,
            "looks": self.looks,
            "fitness": self.fitness,
            "karma": self.karma,
            "stress": self.stress,
            "addiction": self.addiction,
            "fame": self.fame,
            "credit_score": self.credit_score
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Stats":
        return cls(
            health=data.get("health", 80),
            happiness=data.get("happiness", 70),
            smarts=data.get("smarts", 50),
            looks=data.get("looks", 50),
            fitness=data.get("fitness", 40),
            karma=data.get("karma", 50),
            stress=data.get("stress", 10),
            addiction=data.get("addiction", 0),
            fame=data.get("fame", 0),
            credit_score=data.get("credit_score")
        )


@dataclass
class HiddenTraits:
    """Hidden traits rolled at birth."""
    genetic_health_mod: int = 0      # -10 to +10
    lifespan_mod: int = 0            # -8 to +8 years
    luck: int = 0                    # -5 to +5
    temperament: str = "neutral"     # calm, neutral, volatile


@dataclass
class Character:
    """Main character/life entity."""
    char_id: int = 0
    user_id: int = 0
    is_alive: bool = True
    name: str = ""
    gender: Gender = Gender.MALE
    country: str = "usa"
    wealth_class: str = "middle"
    age: int = 0
    stats: Stats = field(default_factory=Stats)
    hidden: HiddenTraits = field(default_factory=HiddenTraits)
    cash: int = 0
    bank: int = 0
    debt_total: int = 0
    price_index: float = 1.0
    housing_type: HousingType = HousingType.PARENTS
    housing_item_id: Optional[int] = None
    rent_amount: int = 0
    education_level: EducationLevel = EducationLevel.NONE
    current_school: Optional[str] = None
    school_program: Optional[EducationLevel] = None
    school_years_left: int = 0
    gpa: Optional[float] = None
    major: Optional[str] = None
    has_license: bool = False
    has_ged: bool = False
    criminal_record: int = 0
    notoriety: int = 0
    in_prison: bool = False
    prison_years_left: int = 0
    has_insurance: bool = False
    is_retired: bool = False
    bankrupt_until_age: Optional[int] = None
    parent_char_id: Optional[int] = None
    generation: int = 1
    last_age_at: Optional[int] = None
    busy: bool = False
    version: int = 0
    born_at: int = 0
    died_at: Optional[int] = None
    death_cause: Optional[str] = None
    death_age: Optional[int] = None

    @property
    def life_stage(self) -> LifeStage:
        if self.age <= 2:
            return LifeStage.BABY
        elif self.age <= 12:
            return LifeStage.CHILD
        elif self.age <= 17:
            return LifeStage.TEEN
        elif self.age <= 29:
            return LifeStage.YOUNG_ADULT
        elif self.age <= 49:
            return LifeStage.ADULT
        elif self.age <= 64:
            return LifeStage.MIDDLE_AGE
        else:
            return LifeStage.SENIOR

    @property
    def net_worth(self) -> int:
        """Calculate net worth - will be computed by engine with items/holdings/loans."""
        return self.cash + self.bank - self.debt_total

    def to_dict(self) -> Dict[str, Any]:
        return {
            "char_id": self.char_id,
            "user_id": self.user_id,
            "is_alive": self.is_alive,
            "name": self.name,
            "gender": self.gender.value,
            "country": self.country,
            "wealth_class": self.wealth_class,
            "age": self.age,
            "stats": self.stats.to_dict(),
            "hidden": {
                "genetic_health_mod": self.hidden.genetic_health_mod,
                "lifespan_mod": self.hidden.lifespan_mod,
                "luck": self.hidden.luck,
                "temperament": self.hidden.temperament
            },
            "cash": self.cash,
            "bank": self.bank,
            "debt_total": self.debt_total,
            "price_index": self.price_index,
            "housing_type": self.housing_type.value,
            "housing_item_id": self.housing_item_id,
            "rent_amount": self.rent_amount,
            "education_level": self.education_level.value,
            "current_school": self.current_school,
            "school_program": self.school_program.value if self.school_program else None,
            "school_years_left": self.school_years_left,
            "gpa": self.gpa,
            "major": self.major,
            "has_license": self.has_license,
            "has_ged": self.has_ged,
            "criminal_record": self.criminal_record,
            "notoriety": self.notoriety,
            "in_prison": self.in_prison,
            "prison_years_left": self.prison_years_left,
            "has_insurance": self.has_insurance,
            "is_retired": self.is_retired,
            "bankrupt_until_age": self.bankrupt_until_age,
            "parent_char_id": self.parent_char_id,
            "generation": self.generation,
            "last_age_at": self.last_age_at,
            "busy": self.busy,
            "version": self.version,
            "born_at": self.born_at,
            "died_at": self.died_at,
            "death_cause": self.death_cause,
            "death_age": self.death_age
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Character":
        """Build a character from the JSON-safe representation used by SQLite."""
        hidden_data = data.get("hidden") or {}
        return cls(
            char_id=int(data.get("char_id", 0)),
            user_id=int(data.get("user_id", 0)),
            is_alive=bool(data.get("is_alive", True)),
            name=str(data.get("name", "")),
            gender=Gender(data.get("gender", Gender.MALE.value)),
            country=str(data.get("country", "usa")),
            wealth_class=str(data.get("wealth_class", "middle")),
            age=int(data.get("age", 0)),
            stats=Stats.from_dict(data.get("stats") or {}),
            hidden=HiddenTraits(
                genetic_health_mod=int(hidden_data.get("genetic_health_mod", 0)),
                lifespan_mod=int(hidden_data.get("lifespan_mod", 0)),
                luck=int(hidden_data.get("luck", 0)),
                temperament=str(hidden_data.get("temperament", "neutral")),
            ),
            cash=int(data.get("cash", 0)),
            bank=int(data.get("bank", 0)),
            debt_total=int(data.get("debt_total", 0)),
            price_index=float(data.get("price_index", 1.0)),
            housing_type=HousingType(data.get("housing_type", HousingType.PARENTS.value)),
            housing_item_id=data.get("housing_item_id"),
            rent_amount=int(data.get("rent_amount", 0)),
            education_level=EducationLevel(data.get("education_level", EducationLevel.NONE.value)),
            current_school=data.get("current_school"),
            school_program=(EducationLevel(data["school_program"]) if data.get("school_program") else None),
            school_years_left=int(data.get("school_years_left", 0)),
            gpa=float(data["gpa"]) if data.get("gpa") is not None else None,
            major=data.get("major"),
            has_license=bool(data.get("has_license", False)),
            has_ged=bool(data.get("has_ged", False)),
            criminal_record=int(data.get("criminal_record", 0)),
            notoriety=int(data.get("notoriety", 0)),
            in_prison=bool(data.get("in_prison", False)),
            prison_years_left=int(data.get("prison_years_left", 0)),
            has_insurance=bool(data.get("has_insurance", False)),
            is_retired=bool(data.get("is_retired", False)),
            bankrupt_until_age=data.get("bankrupt_until_age"),
            parent_char_id=data.get("parent_char_id"),
            generation=int(data.get("generation", 1)),
            last_age_at=data.get("last_age_at"),
            busy=bool(data.get("busy", False)),
            version=int(data.get("version", 0)),
            born_at=int(data.get("born_at", 0)),
            died_at=data.get("died_at"),
            death_cause=data.get("death_cause"),
            death_age=data.get("death_age"),
        )


@dataclass
class Job:
    """Character's current job."""
    char_id: int = 0
    career_id: str = ""
    level: int = 0
    performance: int = 50
    years_in_role: int = 0
    years_in_career: int = 0
    salary: int = 0
    is_part_time: bool = False
    warnings: int = 0


@dataclass
class CareerHistory:
    """Historical career record."""
    id: int = 0
    char_id: int = 0
    career_id: str = ""
    max_level: int = 0
    start_age: int = 0
    end_age: Optional[int] = None
    end_reason: Optional[str] = None  # quit|fired|retired|laid_off|prison|died


@dataclass
class NPC:
    """Non-player character (family, partners, friends, children)."""
    npc_id: int = 0
    owner_char_id: int = 0
    name: str = ""
    gender: Gender = Gender.MALE
    age: int = 0
    looks: int = 50
    smarts: int = 50
    health: int = 80
    wealth: int = 0
    occupation: Optional[str] = None
    is_alive: bool = True
    death_age: Optional[int] = None


@dataclass
class Relationship:
    """Relationship between character and NPC."""
    id: int = 0
    char_id: int = 0
    npc_id: int = 0
    type: RelationshipType = RelationshipType.FRIEND
    score: int = 50
    since_age: int = 0


@dataclass
class ChildData:
    """Extra data for child NPCs."""
    npc_id: int = 0
    char_id: int = 0
    other_parent_npc_id: Optional[int] = None
    custody: str = "full"  # full|shared|none
    child_support: int = 0


@dataclass
class Item:
    """Item instance owned by character."""
    item_uid: int = 0
    char_id: int = 0
    item_id: str = ""
    quantity: int = 1
    purchase_price: int = 0
    current_value: int = 0
    condition: int = 100
    acquired_age: int = 0
    is_locked: bool = False


@dataclass
class Loan:
    """Loan held by character."""
    loan_id: int = 0
    char_id: int = 0
    type: LoanType = LoanType.PERSONAL
    principal: int = 0
    balance: int = 0
    annual_rate: float = 0.0
    term_years: int = 0
    annual_payment: int = 0
    years_remaining: int = 0
    missed_payments: int = 0
    collateral_item_uid: Optional[int] = None
    status: LoanStatus = LoanStatus.ACTIVE


@dataclass
class HealthCondition:
    """Active disease/condition."""
    id: int = 0
    char_id: int = 0
    disease_id: str = ""
    severity: int = 1
    diagnosed: bool = False
    onset_age: int = 0
    years_untreated: int = 0
    is_active: bool = True


@dataclass
class CrimeLog:
    """Record of committed crime."""
    id: int = 0
    char_id: int = 0
    crime_id: str = ""
    age: int = 0
    success: bool = False
    caught: bool = False
    loot: int = 0
    sentence_years: int = 0


@dataclass
class PendingEvent:
    """Unresolved choice event."""
    char_id: int = 0
    event_id: str = ""
    context_json: str = ""
    nonce: str = ""
    created_at: int = 0


@dataclass
class LifeLogEntry:
    """Yearly life log entry."""
    id: int = 0
    char_id: int = 0
    age: int = 0
    category: str = ""
    text: str = ""
    importance: int = 1


@dataclass
class Stock:
    """Stock market symbol."""
    symbol: str = ""
    name: str = ""
    sector: str = ""
    price: int = 0
    volatility: float = 0.0
    drift: float = 0.0
    last_tick: int = 0
    is_delisted: bool = False


@dataclass
class Holding:
    """Character's stock holding."""
    char_id: int = 0
    symbol: str = ""
    shares: int = 0
    avg_cost: int = 0


@dataclass
class Trade:
    """Player-to-player trade."""
    trade_id: int = 0
    from_char: int = 0
    to_char: int = 0
    offer_cash: int = 0
    request_cash: int = 0
    offer_items_json: str = "[]"
    request_items_json: str = "[]"
    status: TradeStatus = TradeStatus.PENDING
    created_at: int = 0
    resolved_at: Optional[int] = None
    nonce: str = ""


@dataclass
class AchievementUnlocked:
    """User achievement record."""
    user_id: int = 0
    achievement_id: str = ""
    char_id: Optional[int] = None
    unlocked_at: int = 0


@dataclass
class PastLife:
    """Archived dead character summary."""
    char_id: int = 0
    user_id: int = 0
    name: str = ""
    death_age: int = 0
    death_cause: str = ""
    peak_net_worth: int = 0
    final_net_worth: int = 0
    education: str = ""
    top_career: Optional[str] = None
    children_count: int = 0
    marriages: int = 0
    convictions: int = 0
    life_score: int = 0
    epitaph: str = ""
    summary_json: str = ""
    ended_at: int = 0


@dataclass
class Cooldown:
    """Action cooldown."""
    user_id: int = 0
    action: str = ""
    expires_at: int = 0


@dataclass
class YearlyCounter:
    """Per-year action counter."""
    char_id: int = 0
    age: int = 0
    action: str = ""
    count: int = 0


@dataclass
class AuditLog:
    """Audit trail for money movements."""
    id: int = 0
    ts: int = 0
    user_id: Optional[int] = None
    char_id: Optional[int] = None
    action: str = ""
    amount: Optional[int] = None
    details_json: str = ""


@dataclass
class StatsTracking:
    """Lifetime stats for achievements/summary."""
    char_id: int = 0
    peak_net_worth: int = 0
    total_earned: int = 0
    total_taxes: int = 0
    total_gambled: int = 0
    total_gambling_net: int = 0
    crimes_committed: int = 0
    years_in_prison: int = 0
    marriages: int = 0
    divorces: int = 0
    hospital_visits: int = 0
    times_fired: int = 0
    promotions: int = 0
```

## `lifeline/core/repositories/crime.py`

```python
"""Parameterized repository for Stage 7 crime, trial, tax, and prison data."""
from __future__ import annotations

import json
from typing import Any, Optional

import aiosqlite

from ..models import Character


class CrimeRepository:
    """Keep all Stage 7 SQL and transactional row mapping in one repository."""

    def __init__(self, db: Any) -> None:
        self.db = db

    @staticmethod
    async def _one(tx: aiosqlite.Connection, query: str, params: tuple[Any, ...] = ()) -> Any:
        cursor = await tx.execute(query, params)
        return await cursor.fetchone()

    @staticmethod
    async def _all(tx: aiosqlite.Connection, query: str, params: tuple[Any, ...] = ()) -> list[Any]:
        cursor = await tx.execute(query, params)
        return await cursor.fetchall()

    async def load_active(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Load the active life and optimistic version for an action transaction."""
        row = await self._one(
            tx,
            "SELECT char_id, user_id, data_json, version FROM characters "
            "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def load_active_read(self, user_id: int) -> Optional[dict[str, Any]]:
        """Read a user's active character without opening a write transaction."""
        row = await self.db.fetchone(
            "SELECT char_id, user_id, data_json, version FROM characters "
            "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def has_any_life(self, tx: aiosqlite.Connection, user_id: int) -> bool:
        """Check if a user has a historical life but no active character."""
        return await self._one(tx, "SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,)) is not None

    async def has_pending_event(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check for unresolved Stage 3 events before a new criminal decision."""
        return await self._one(tx, "SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1", (char_id,)) is not None

    async def insert_life_log(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        age: int,
        category: str,
        text: str,
        importance: int,
        now: int,
    ) -> None:
        """Append a parameterized message to the shared life journal."""
        await tx.execute(
            """INSERT INTO life_logs(char_id, age, category, text, importance, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (char_id, age, category, text, importance, now),
        )

    async def has_any_life_read(self, user_id: int) -> bool:
        """Read whether a user has a historical character."""
        return await self.db.fetchone("SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,)) is not None

    async def save_character(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
    ) -> None:
        """Persist a changed character snapshot with optimistic concurrency protection."""
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET stats_json = ?, version = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (stats_json, character.version, data_json, character.char_id, expected_version),
        )
        if cursor.rowcount != 1:
            from ..errors import ConcurrentUpdate
            raise ConcurrentUpdate()

    async def initialize_profile(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Create the default criminal profile once for a new or legacy character."""
        await tx.execute("INSERT OR IGNORE INTO crime_profiles(char_id) VALUES (?)", (char_id,))

    async def get_profile(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Any]:
        """Return a profile, initializing it if this is a pre-Stage-7 life."""
        await self.initialize_profile(tx, char_id)
        row = await self._one(tx, "SELECT * FROM crime_profiles WHERE char_id = ?", (char_id,))
        if row is None:
            raise RuntimeError("criminal profile could not be initialized")
        return dict(row)

    async def update_profile(self, tx: aiosqlite.Connection, char_id: int, **fields: Any) -> None:
        """Update a fixed allowlist of criminal-profile columns with bound values."""
        allowed = {
            "dirty_cash", "career_rank", "career_years", "career_level", "last_crime_id",
            "evaded_tax", "gang_protected", "escaped", "juvenile_release_age",
            "last_release_age", "front_business",
        }
        if not fields or set(fields) - allowed:
            raise ValueError("criminal profile update contains no fields or an unsupported field")
        assignments = ", ".join(f"{column} = ?" for column in fields)
        await tx.execute(
            f"UPDATE crime_profiles SET {assignments} WHERE char_id = ?",
            (*fields.values(), char_id),
        )

    async def save_preview(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        crime_id: str,
        age: int,
        nonce: str,
        success_chance: float,
        catch_chance: float,
        loot_min: int,
        loot_max: int,
        salary_snapshot: int,
        created_at: int,
        expires_at: int,
    ) -> None:
        """Replace an unconfirmed risk preview for this character."""
        await tx.execute("DELETE FROM crime_previews WHERE char_id = ?", (char_id,))
        await tx.execute(
            """INSERT INTO crime_previews
                   (char_id, crime_id, age, nonce, success_chance, catch_chance,
                    loot_min, loot_max, salary_snapshot, created_at, expires_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, crime_id, age, nonce, success_chance, catch_chance,
             loot_min, loot_max, salary_snapshot, created_at, expires_at),
        )

    async def get_preview(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        nonce: str,
        now: int,
    ) -> Optional[dict[str, Any]]:
        """Fetch a live preview only for its owner and unexpired nonce."""
        row = await self._one(
            tx,
            "SELECT * FROM crime_previews WHERE char_id = ? AND nonce = ? AND expires_at >= ? LIMIT 1",
            (char_id, nonce, now),
        )
        return dict(row) if row is not None else None

    async def delete_preview(self, tx: aiosqlite.Connection, char_id: int, nonce: str) -> None:
        """Consume a crime preview after confirmation or cancellation."""
        await tx.execute("DELETE FROM crime_previews WHERE char_id = ? AND nonce = ?", (char_id, nonce))

    async def cancel_preview(self, tx: aiosqlite.Connection, char_id: int, nonce: str) -> bool:
        """Remove the exact owner's pending preview and report whether it existed."""
        cursor = await tx.execute("DELETE FROM crime_previews WHERE char_id = ? AND nonce = ?", (char_id, nonce))
        return cursor.rowcount == 1

    async def claim_crime_attempt(self, tx: aiosqlite.Connection, char_id: int, age: int, *, limit: int = 2) -> bool:
        """Reserve a crime attempt using Stage 6 yearly_counters when an NPC anchor exists."""
        row = await self._one(
            tx,
            """SELECT COALESCE(SUM(count), 0) AS count FROM yearly_counters
               WHERE char_id = ? AND age = ? AND action = 'crime_commit'""",
            (char_id, age),
        )
        fallback = await self._one(
            tx,
            "SELECT count FROM crime_yearly_actions WHERE char_id = ? AND age = ? AND action = 'crime_commit'",
            (char_id, age),
        )
        count = int(row["count"] if row is not None else 0) + (int(fallback["count"]) if fallback is not None else 0)
        if count >= limit:
            return False
        anchor = await self._one(
            tx,
            "SELECT npc_id FROM npcs WHERE owner_char_id = ? ORDER BY npc_id LIMIT 1",
            (char_id,),
        )
        if anchor is not None:
            await tx.execute(
                """INSERT INTO yearly_counters(char_id, npc_id, age, action, count)
                   VALUES (?, ?, ?, 'crime_commit', 1)
                   ON CONFLICT(char_id, npc_id, age, action) DO UPDATE SET count = count + 1""",
                (char_id, int(anchor["npc_id"]), age),
            )
        else:
            await self.claim_action(tx, char_id, age, "crime_commit")
        return True

    async def claim_action(self, tx: aiosqlite.Connection, char_id: int, age: int, action: str) -> bool:
        """Reserve one prison action per in-game age."""
        row = await self._one(
            tx,
            "SELECT count FROM crime_yearly_actions WHERE char_id = ? AND age = ? AND action = ?",
            (char_id, age, action),
        )
        if row is not None and int(row["count"]) >= 1:
            return False
        await tx.execute(
            """INSERT INTO crime_yearly_actions(char_id, age, action, count) VALUES (?, ?, ?, 1)
               ON CONFLICT(char_id, age, action) DO UPDATE SET count = count + 1""",
            (char_id, age, action),
        )
        return True

    async def insert_attempt(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        crime_id: str,
        age: int,
        source: str,
        success: bool,
        caught: bool,
        loot: int,
        success_chance: float,
        catch_chance: float,
        case_status: str,
        created_at: int,
    ) -> int:
        """Insert a committed attempt or arrest and return its audit-record key."""
        cursor = await tx.execute(
            """INSERT INTO crime_attempts
                   (char_id, crime_id, age, source, success, caught, loot,
                    success_chance, catch_chance, case_status, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, crime_id, age, source, int(success), int(caught), loot,
             success_chance, catch_chance, case_status, created_at),
        )
        return int(cursor.lastrowid)

    async def create_trial(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        attempt_id: int,
        nonce: str,
        created_at: int,
    ) -> None:
        """Create a persistent one-case trial choice."""
        await tx.execute(
            "INSERT INTO crime_trials(char_id, attempt_id, nonce, created_at) VALUES (?, ?, ?, ?)",
            (char_id, attempt_id, nonce, created_at),
        )

    async def pending_trial(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Load an unresolved trial and its associated crime record."""
        row = await self._one(
            tx,
            """SELECT t.nonce, t.created_at AS trial_created_at, a.*
               FROM crime_trials AS t JOIN crime_attempts AS a ON a.attempt_id = t.attempt_id
               WHERE t.char_id = ? LIMIT 1""",
            (char_id,),
        )
        return dict(row) if row is not None else None

    async def pending_trial_read(self, user_id: int) -> Optional[dict[str, Any]]:
        """Read a pending trial for an active life to recreate its button view."""
        row = await self.db.fetchone(
            """SELECT t.nonce, t.created_at AS trial_created_at, a.*
               FROM crime_trials AS t JOIN crime_attempts AS a ON a.attempt_id = t.attempt_id
               JOIN characters AS c ON c.char_id = t.char_id
               WHERE c.user_id = ? AND c.is_alive = 1 LIMIT 1""",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def has_pending_decision(self, tx: aiosqlite.Connection, char_id: int, now: int) -> bool:
        """Check for an unexpired preview, trial, or tax decision before aging."""
        await tx.execute("DELETE FROM crime_previews WHERE char_id = ? AND expires_at < ?", (char_id, now))
        return await self._one(
            tx,
            """SELECT 1 FROM crime_previews WHERE char_id = ?
               UNION ALL SELECT 1 FROM crime_trials WHERE char_id = ?
               UNION ALL SELECT 1 FROM crime_tax_prompts WHERE char_id = ? LIMIT 1""",
            (char_id, char_id, char_id),
        ) is not None

    async def preview_for_character(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Load a pending preview in the caller's transaction."""
        row = await self._one(tx, "SELECT * FROM crime_previews WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def read_preview(self, user_id: int) -> Optional[dict[str, Any]]:
        """Read a pending crime confirmation for its living owner."""
        row = await self.db.fetchone(
            """SELECT p.* FROM crime_previews AS p JOIN characters AS c ON c.char_id = p.char_id
               WHERE c.user_id = ? AND c.is_alive = 1 LIMIT 1""",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def complete_trial(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        attempt_id: int,
        case_status: str,
        lawyer_tier: str,
        sentence_years: int,
        life_sentence: bool,
        record_sealed: bool,
        fine_paid: int,
        resolved_at: int,
    ) -> None:
        """Store verdict details and consume the persistent trial nonce."""
        await tx.execute(
            """UPDATE crime_attempts SET case_status = ?, lawyer_tier = ?, sentence_years = ?,
                   life_sentence = ?, record_sealed = ?, fine_paid = ?, resolved_at = ?
               WHERE attempt_id = ? AND char_id = ? AND case_status = 'pending'""",
            (case_status, lawyer_tier, sentence_years, int(life_sentence), int(record_sealed),
             fine_paid, resolved_at, attempt_id, char_id),
        )
        await tx.execute("DELETE FROM crime_trials WHERE char_id = ? AND attempt_id = ?", (char_id, attempt_id))

    async def resolve_audit_attempt(
        self,
        tx: aiosqlite.Connection,
        attempt_id: int,
        *,
        sentence_years: int,
        resolved_at: int,
    ) -> None:
        """Fill sentence metadata for a direct tax-audit conviction without a trial row."""
        await tx.execute(
            """UPDATE crime_attempts SET case_status = 'convicted', lawyer_tier = NULL,
                   sentence_years = ?, life_sentence = 0, record_sealed = 0,
                   fine_paid = 0, resolved_at = ? WHERE attempt_id = ? AND source = 'tax_audit'""",
            (max(0, sentence_years), resolved_at, attempt_id),
        )

    async def get_job(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return the active job required for embezzlement and prison dismissal."""
        row = await self._one(tx, "SELECT * FROM jobs WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def fire_job_for_prison(self, tx: aiosqlite.Connection, char_id: int, age: int) -> bool:
        """Close an active job with the Stage 7 'prison' history reason."""
        row = await self._one(tx, "SELECT 1 FROM jobs WHERE char_id = ? LIMIT 1", (char_id,))
        if row is None:
            return False
        await tx.execute(
            """UPDATE career_history SET end_age = ?, end_reason = 'prison'
               WHERE char_id = ? AND end_age IS NULL""",
            (age, char_id),
        )
        await tx.execute("DELETE FROM jobs WHERE char_id = ?", (char_id,))
        return True

    async def relationship_scores(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, int]]:
        """Return connected NPC IDs and scores for sentencing consequences."""
        rows = await self._all(tx, "SELECT npc_id, score FROM relationships WHERE char_id = ?", (char_id,))
        return [{"npc_id": int(row["npc_id"]), "score": int(row["score"])} for row in rows]

    async def set_relationship_score(self, tx: aiosqlite.Connection, char_id: int, npc_id: int, score: int) -> None:
        """Persist one nonnegative relationship score."""
        await tx.execute(
            "UPDATE relationships SET score = ? WHERE char_id = ? AND npc_id = ?",
            (max(0, min(100, score)), char_id, npc_id),
        )

    async def has_marriage(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check for an active marriage without leaking another life's spouse data."""
        return await self._one(tx, "SELECT 1 FROM marriages WHERE char_id = ? LIMIT 1", (char_id,)) is not None

    async def add_cashflow(self, tx: aiosqlite.Connection, char_id: int, age: int, action: str, amount: int, now: int) -> None:
        """Log one positive criminal cash-flow amount in integer cents."""
        await tx.execute(
            "INSERT INTO crime_cashflows(char_id, age, action, amount, created_at) VALUES (?, ?, ?, ?, ?)",
            (char_id, age, action, max(0, amount), now),
        )

    async def cashflow_totals(self, tx: aiosqlite.Connection, char_id: int, age: int) -> dict[str, int]:
        """Sum criminal proceeds and laundering for one in-game age."""
        rows = await self._all(
            tx,
            """SELECT action, COALESCE(SUM(amount), 0) AS total FROM crime_cashflows
               WHERE char_id = ? AND age = ? GROUP BY action""",
            (char_id, age),
        )
        return {str(row["action"]): int(row["total"]) for row in rows}

    async def laundering_total_read(self, char_id: int, age: int) -> int:
        """Read gross laundering already used in the current in-game year."""
        row = await self.db.fetchone(
            "SELECT COALESCE(SUM(gross_amount), 0) AS total FROM crime_laundering WHERE char_id = ? AND age = ?",
            (char_id, age),
        )
        return int(row["total"] if row is not None else 0)

    async def laundering_total(self, tx: aiosqlite.Connection, char_id: int, age: int) -> int:
        """Return gross laundering already used in the current in-game year."""
        row = await self._one(
            tx,
            "SELECT COALESCE(SUM(gross_amount), 0) AS total FROM crime_laundering WHERE char_id = ? AND age = ?",
            (char_id, age),
        )
        return int(row["total"] if row is not None else 0)

    async def add_laundering(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        age: int,
        gross: int,
        fee: int,
        net: int,
        now: int,
    ) -> None:
        """Persist a completed laundering transaction."""
        await tx.execute(
            """INSERT INTO crime_laundering(char_id, age, gross_amount, fee_amount, net_amount, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (char_id, age, gross, fee, net, now),
        )

    async def has_front_business(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check the existing item inventory for the required front-business item."""
        row = await self._one(
            tx,
            """SELECT 1 FROM family_assets WHERE char_id = ? AND kind = 'item'
                 AND item_id = 'front_business' AND quantity > 0 AND is_liquidated = 0 LIMIT 1""",
            (char_id,),
        )
        return row is not None

    async def grant_front_business(self, tx: aiosqlite.Connection, char_id: int, age: int, now: int) -> None:
        """Grant one zero-cost front-business item at the Crime Boss career tier."""
        if await self.has_front_business(tx, char_id):
            return
        await tx.execute(
            """INSERT INTO family_assets
                   (char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at)
               VALUES (?, 'item', 'front_business', 1, 0, 0, ?, ?)""",
            (char_id, age, now),
        )
        await self.update_profile(tx, char_id, front_business=1)

    async def save_tax_prompt(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        nonce: str,
        age: int,
        tax_due: int,
        prepaid: bool,
        now: int,
        *,
        paid_amount: int = 0,
    ) -> None:
        """Persist a one-use high-earner tax decision."""
        await tx.execute("DELETE FROM crime_tax_prompts WHERE char_id = ?", (char_id,))
        await tx.execute(
            """INSERT INTO crime_tax_prompts
                   (char_id, nonce, age, tax_due, prepaid, paid_amount, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (char_id, nonce, age, tax_due, int(prepaid), max(0, paid_amount), now),
        )

    async def pending_tax_prompt(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return the unresolved tax-evasion event for one life."""
        row = await self._one(tx, "SELECT * FROM crime_tax_prompts WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def pending_tax_prompt_read(self, user_id: int) -> Optional[dict[str, Any]]:
        """Read an active tax decision so its interactive view can be reopened."""
        row = await self.db.fetchone(
            """SELECT p.* FROM crime_tax_prompts AS p JOIN characters AS c ON c.char_id = p.char_id
               WHERE c.user_id = ? AND c.is_alive = 1 LIMIT 1""",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def consume_tax_prompt(self, tx: aiosqlite.Connection, char_id: int, nonce: str) -> bool:
        """Delete exactly one nonce-matched tax event after its choice is recorded."""
        cursor = await tx.execute("DELETE FROM crime_tax_prompts WHERE char_id = ? AND nonce = ?", (char_id, nonce))
        return cursor.rowcount == 1

    async def record_tax_choice(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        age: int,
        choice: str,
        tax_due: int,
        evaded_amount: int,
        now: int,
    ) -> None:
        """Append one selected tax decision to the audit history."""
        await tx.execute(
            """INSERT INTO crime_tax_choices(char_id, age, choice, tax_due, evaded_amount, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (char_id, age, choice, tax_due, evaded_amount, now),
        )

    async def record_audit(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        age: int,
        chance: float,
        triggered: bool,
        evasion_found: bool,
        back_taxes: int,
        sentence_years: int,
        outcome: str,
        now: int,
    ) -> None:
        """Persist an annual financial audit result."""
        await tx.execute(
            """INSERT INTO crime_audits
                   (char_id, age, audit_chance, triggered, tax_evasion_found,
                    back_taxes, sentence_years, outcome, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, age, chance, int(triggered), int(evasion_found), back_taxes, sentence_years, outcome, now),
        )

    async def active_loans(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return unpaid loans for prison's automatic-payment rule."""
        rows = await self._all(tx, "SELECT * FROM loans WHERE char_id = ? AND status = 'active' ORDER BY loan_id", (char_id,))
        return [dict(row) for row in rows]

    async def pay_loan(self, tx: aiosqlite.Connection, loan_id: int, payment: int) -> None:
        """Apply a full available annual payment to one loan."""
        row = await self._one(tx, "SELECT balance FROM loans WHERE loan_id = ? AND status = 'active'", (loan_id,))
        if row is None:
            return
        balance = int(row["balance"])
        remaining = max(0, balance - min(balance, max(0, payment)))
        await tx.execute(
            "UPDATE loans SET balance = ?, status = ? WHERE loan_id = ?",
            (remaining, "paid" if remaining == 0 else "active", loan_id),
        )

    async def miss_loan_payment(self, tx: aiosqlite.Connection, loan_id: int) -> None:
        """Increment missed prison-time loan payments without changing the balance."""
        await tx.execute("UPDATE loans SET missed_payments = missed_payments + 1 WHERE loan_id = ?", (loan_id,))

    async def crime_history_in_transaction(
        self, tx: aiosqlite.Connection, char_id: int, limit: int = 10
    ) -> list[dict[str, Any]]:
        """Return recent attempts using the caller's transaction connection."""
        rows = await self._all(
            tx,
            "SELECT * FROM crime_attempts WHERE char_id = ? ORDER BY age DESC, attempt_id DESC LIMIT ?",
            (char_id, max(1, min(25, limit))),
        )
        return [dict(row) for row in rows]

    async def crime_history(self, char_id: int, limit: int = 10) -> list[dict[str, Any]]:
        """Return recent attempts and court outcomes for a crime-record embed."""
        rows = await self.db.fetchall(
            """SELECT * FROM crime_attempts WHERE char_id = ? ORDER BY age DESC, attempt_id DESC LIMIT ?""",
            (char_id, max(1, min(25, limit))),
        )
        return [dict(row) for row in rows]

    async def read_profile(self, char_id: int) -> Optional[dict[str, Any]]:
        """Read a previously initialized criminal profile."""
        row = await self.db.fetchone("SELECT * FROM crime_profiles WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def get_hiring_context(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return release age and record metadata for a job-application calculation."""
        row = await self._one(tx, "SELECT last_release_age FROM crime_profiles WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def other_pending_prompt(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check trial and tax decisions that cannot overlap with a new age event."""
        return await self._one(
            tx,
            """SELECT 1 FROM crime_trials WHERE char_id = ?
               UNION ALL SELECT 1 FROM crime_tax_prompts WHERE char_id = ? LIMIT 1""",
            (char_id, char_id),
        ) is not None

    async def get_status_data(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Any]:
        """Load criminal profile and pending prompts for a combined record/status view."""
        profile = await self.get_profile(tx, char_id)
        trial = await self.pending_trial(tx, char_id)
        tax = await self.pending_tax_prompt(tx, char_id)
        return {"profile": profile, "trial": trial, "tax": tax}
```

## `lifeline/core/validators.py`

```python
"""Strict validation for game data files loaded at runtime."""
from __future__ import annotations

import math
import re
from typing import Any


class DataValidationError(ValueError):
    """Raised when a bundled game-data document is malformed or unsafe."""


_EVENT_ID = re.compile(r"^[a-z][a-z0-9_]{0,39}$")
_ALLOWED_POLARITIES = {"positive", "negative", "neutral"}
_ALLOWED_WEALTH = {"poor", "working", "middle", "upper", "rich"}
_ALLOWED_STATS = {
    "health", "happiness", "smarts", "looks", "fitness", "karma",
    "stress", "addiction", "fame",
}


def _fail(path: str, message: str) -> None:
    raise DataValidationError(f"{path}: {message}")


def _string(value: Any, path: str, *, minimum: int, maximum: int) -> str:
    if not isinstance(value, str):
        _fail(path, "must be a string")
    clean = value.strip()
    if not minimum <= len(clean) <= maximum:
        _fail(path, f"length must be between {minimum} and {maximum}")
    if any(ord(char) < 32 or ord(char) == 127 for char in clean):
        _fail(path, "must not contain control characters")
    return clean


def _integer(value: Any, path: str, *, minimum: int, maximum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        _fail(path, "must be an integer")
    if not minimum <= value <= maximum:
        _fail(path, f"must be between {minimum} and {maximum}")
    return value


def validate_event_catalog(document: Any) -> dict[str, Any]:
    """Validate and return a version-1 life-event catalog.

    Expressions and executable conditions are intentionally unsupported: event
    effects are finite integer stat deltas, never ``eval``-ed code.
    """
    if not isinstance(document, dict):
        _fail("events", "document must be an object")
    if document.get("schema_version") != 1:
        _fail("schema_version", "only version 1 is supported")
    events = document.get("events")
    if not isinstance(events, list) or not 1 <= len(events) <= 500:
        _fail("events", "must contain between 1 and 500 event definitions")

    seen_event_ids: set[str] = set()
    for event_index, event in enumerate(events):
        path = f"events[{event_index}]"
        if not isinstance(event, dict):
            _fail(path, "must be an object")

        event_id = _string(event.get("id"), f"{path}.id", minimum=1, maximum=40)
        if not _EVENT_ID.fullmatch(event_id):
            _fail(f"{path}.id", "use lowercase letters, digits, and underscores")
        if event_id in seen_event_ids:
            _fail(f"{path}.id", "event IDs must be unique")
        seen_event_ids.add(event_id)

        _string(event.get("title"), f"{path}.title", minimum=1, maximum=100)
        _string(event.get("description"), f"{path}.description", minimum=1, maximum=1000)
        category = _string(event.get("category"), f"{path}.category", minimum=1, maximum=32)
        if not re.fullmatch(r"[a-z][a-z0-9_]*", category):
            _fail(f"{path}.category", "must be a lowercase category key")
        if event.get("polarity") not in _ALLOWED_POLARITIES:
            _fail(f"{path}.polarity", "must be positive, negative, or neutral")

        minimum_age = _integer(event.get("min_age"), f"{path}.min_age", minimum=0, maximum=120)
        maximum_age = _integer(event.get("max_age"), f"{path}.max_age", minimum=0, maximum=120)
        if minimum_age > maximum_age:
            _fail(path, "min_age cannot exceed max_age")

        weight = event.get("weight")
        if isinstance(weight, bool) or not isinstance(weight, (int, float)):
            _fail(f"{path}.weight", "must be a number")
        if not math.isfinite(float(weight)) or not 0 < float(weight) <= 1000:
            _fail(f"{path}.weight", "must be greater than 0 and at most 1000")

        repeatable = event.get("repeatable", False)
        if not isinstance(repeatable, bool):
            _fail(f"{path}.repeatable", "must be true or false")

        wealth_classes = event.get("wealth_classes", [])
        if not isinstance(wealth_classes, list) or any(
            not isinstance(value, str) or value not in _ALLOWED_WEALTH for value in wealth_classes
        ):
            _fail(f"{path}.wealth_classes", "must be a list of valid wealth-class keys")
        if len(set(wealth_classes)) != len(wealth_classes):
            _fail(f"{path}.wealth_classes", "values must be unique")

        countries = event.get("countries", [])
        if not isinstance(countries, list) or any(
            not isinstance(value, str) or not re.fullmatch(r"[a-z0-9_-]{2,40}", value)
            for value in countries
        ):
            _fail(f"{path}.countries", "must be a list of lowercase country/region keys")

        choices = event.get("choices")
        if not isinstance(choices, list) or not 2 <= len(choices) <= 4:
            _fail(f"{path}.choices", "must contain between 2 and 4 choices")
        seen_choice_ids: set[str] = set()
        for choice_index, choice in enumerate(choices):
            choice_path = f"{path}.choices[{choice_index}]"
            if not isinstance(choice, dict):
                _fail(choice_path, "must be an object")
            choice_id = _string(choice.get("id"), f"{choice_path}.id", minimum=1, maximum=32)
            if not _EVENT_ID.fullmatch(choice_id):
                _fail(f"{choice_path}.id", "use lowercase letters, digits, and underscores")
            if choice_id in seen_choice_ids:
                _fail(f"{choice_path}.id", "choice IDs must be unique within an event")
            seen_choice_ids.add(choice_id)
            _string(choice.get("label"), f"{choice_path}.label", minimum=1, maximum=80)
            description = choice.get("description", "")
            if description:
                _string(description, f"{choice_path}.description", minimum=1, maximum=250)

            effects = choice.get("effects", {})
            if not isinstance(effects, dict) or set(effects) - {"stats"}:
                _fail(f"{choice_path}.effects", "may contain only a stats object")
            stat_effects = effects.get("stats", {})
            if not isinstance(stat_effects, dict):
                _fail(f"{choice_path}.effects.stats", "must be an object")
            for stat_name, delta in stat_effects.items():
                if stat_name not in _ALLOWED_STATS:
                    _fail(f"{choice_path}.effects.stats.{stat_name}", "is not a mutable game stat")
                _integer(delta, f"{choice_path}.effects.stats.{stat_name}", minimum=-25, maximum=25)

    return document


def validate_career_catalog(document: Any) -> dict[str, Any]:
    """Validate a career catalog containing finite, positive integer-cent salaries."""
    if not isinstance(document, dict):
        _fail("careers", "document must be an object")
    if document.get("schema_version") != 1:
        _fail("schema_version", "only version 1 is supported")
    careers = document.get("careers")
    if not isinstance(careers, list) or not 1 <= len(careers) <= 100:
        _fail("careers", "must contain between 1 and 100 career definitions")

    allowed_education = {"none", "primary", "high_school", "bachelor", "master", "doctorate"}
    career_ids: set[str] = set()
    for index, career in enumerate(careers):
        path = f"careers[{index}]"
        if not isinstance(career, dict):
            _fail(path, "must be an object")
        career_id = _string(career.get("id"), f"{path}.id", minimum=1, maximum=40)
        if not _EVENT_ID.fullmatch(career_id):
            _fail(f"{path}.id", "use lowercase letters, digits, and underscores")
        if career_id in career_ids:
            _fail(f"{path}.id", "career IDs must be unique")
        career_ids.add(career_id)
        _string(career.get("name"), f"{path}.name", minimum=1, maximum=80)
        minimum_age = _integer(career.get("minimum_age"), f"{path}.minimum_age", minimum=14, maximum=80)
        retirement_age = _integer(career.get("retirement_age"), f"{path}.retirement_age", minimum=40, maximum=120)
        if retirement_age <= minimum_age:
            _fail(path, "retirement_age must be greater than minimum_age")
        if career.get("minimum_education") not in allowed_education:
            _fail(f"{path}.minimum_education", "must be a supported education level")
        _integer(career.get("minimum_smarts"), f"{path}.minimum_smarts", minimum=0, maximum=100)
        part_time_allowed = career.get("part_time_allowed", False)
        if not isinstance(part_time_allowed, bool):
            _fail(f"{path}.part_time_allowed", "must be true or false")
        multiplier = career.get("part_time_multiplier", 0.5)
        if isinstance(multiplier, bool) or not isinstance(multiplier, (int, float)):
            _fail(f"{path}.part_time_multiplier", "must be a number")
        if not math.isfinite(float(multiplier)) or not 0 < float(multiplier) <= 1:
            _fail(f"{path}.part_time_multiplier", "must be greater than 0 and at most 1")

        levels = career.get("levels")
        if not isinstance(levels, list) or not 2 <= len(levels) <= 8:
            _fail(f"{path}.levels", "must contain between 2 and 8 levels")
        for level_index, level in enumerate(levels):
            level_path = f"{path}.levels[{level_index}]"
            if not isinstance(level, dict):
                _fail(level_path, "must be an object")
            _string(level.get("title"), f"{level_path}.title", minimum=1, maximum=80)
            _integer(level.get("annual_salary"), f"{level_path}.annual_salary", minimum=1, maximum=10_000_000_000)
            _integer(level.get("promotion_years"), f"{level_path}.promotion_years", minimum=1, maximum=30)

    return document


def validate_crime_catalog(document: Any) -> dict[str, Any]:
    """Validate the complete non-instructional crime catalog used at startup."""
    if not isinstance(document, dict):
        _fail("crimes", "document must be an object")
    if isinstance(document.get("schema_version"), bool) or document.get("schema_version") != 1:
        _fail("crimes.schema_version", "only version 1 is supported")
    allowed_top = {"schema_version", "crime_severity_mod", "crimes"}
    if set(document) != allowed_top:
        _fail("crimes", f"must contain exactly these keys: {', '.join(sorted(allowed_top))}")
    severity = document.get("crime_severity_mod")
    if not isinstance(severity, dict) or "default" not in severity:
        _fail("crimes.crime_severity_mod", "must be an object with a default modifier")
    for country, modifier in severity.items():
        _string(country, "crimes.crime_severity_mod key", minimum=2, maximum=40)
        if not re.fullmatch(r"[a-z][a-z0-9_]{1,39}", country):
            _fail("crimes.crime_severity_mod", "country keys must be lowercase codes")
        if isinstance(modifier, bool) or not isinstance(modifier, (int, float)):
            _fail(f"crimes.crime_severity_mod.{country}", "must be a number")
        if not math.isfinite(float(modifier)) or not 0.25 <= float(modifier) <= 3.0:
            _fail(f"crimes.crime_severity_mod.{country}", "must be between 0.25 and 3")
    crimes = document.get("crimes")
    if not isinstance(crimes, list) or len(crimes) < 14 or len(crimes) > 100:
        _fail("crimes", "must contain at least 14 and at most 100 crime definitions")
    seen: set[str] = set()
    has_event_only_tax = False
    for index, crime in enumerate(crimes):
        path = f"crimes[{index}]"
        if not isinstance(crime, dict):
            _fail(path, "must be an object")
        required_fields = {
            "id", "name", "description", "min_age", "base_success", "loot_min_dollars",
            "loot_max_dollars", "base_catch", "sentence_min", "sentence_max",
            "violence", "success_stat", "requires_job", "commit_enabled",
        }
        optional_fields = {
            "salary_loot_min_fraction", "salary_loot_max_fraction", "salary_loot_multiplier",
        }
        missing_fields = required_fields - set(crime)
        extra_fields = set(crime) - required_fields - optional_fields
        if missing_fields:
            _fail(path, f"missing required fields: {', '.join(sorted(missing_fields))}")
        if extra_fields:
            _fail(path, f"unsupported fields: {', '.join(sorted(extra_fields))}")
        crime_id = _string(crime.get("id"), f"{path}.id", minimum=1, maximum=40)
        if not _EVENT_ID.fullmatch(crime_id) or crime_id in seen:
            _fail(f"{path}.id", "must be unique and use lowercase letters, digits, and underscores")
        seen.add(crime_id)
        _string(crime.get("name"), f"{path}.name", minimum=1, maximum=80)
        _string(crime.get("description"), f"{path}.description", minimum=1, maximum=250)
        minimum_age = crime.get("min_age")
        if minimum_age is not None:
            _integer(minimum_age, f"{path}.min_age", minimum=0, maximum=120)
        enabled = crime.get("commit_enabled")
        if not isinstance(enabled, bool):
            _fail(f"{path}.commit_enabled", "must be true or false")
        for key in ("violence", "requires_job"):
            if not isinstance(crime.get(key), bool):
                _fail(f"{path}.{key}", "must be true or false")
        if crime.get("success_stat") not in {"none", "skill", "physical"}:
            _fail(f"{path}.success_stat", "must be none, skill, or physical")
        loot_min = _integer(crime.get("loot_min_dollars"), f"{path}.loot_min_dollars", minimum=0, maximum=10_000_000)
        loot_max = _integer(crime.get("loot_max_dollars"), f"{path}.loot_max_dollars", minimum=0, maximum=10_000_000)
        if loot_min > loot_max:
            _fail(path, "loot_min_dollars cannot exceed loot_max_dollars")
        sentence_min = _integer(crime.get("sentence_min"), f"{path}.sentence_min", minimum=0, maximum=120)
        sentence_max = crime.get("sentence_max")
        if sentence_max != "life":
            sentence_max = _integer(sentence_max, f"{path}.sentence_max", minimum=0, maximum=120)
            if sentence_min > sentence_max:
                _fail(path, "sentence_min cannot exceed sentence_max")
        if enabled:
            if minimum_age is None:
                _fail(f"{path}.min_age", "committable crimes require a minimum age")
            for key in ("base_success", "base_catch"):
                chance = crime.get(key)
                if isinstance(chance, bool) or not isinstance(chance, (int, float)):
                    _fail(f"{path}.{key}", "committable crimes require a numeric chance")
                if not math.isfinite(float(chance)) or not 0 <= float(chance) <= 100:
                    _fail(f"{path}.{key}", "must be between 0 and 100")
        else:
            if crime_id == "tax_evasion":
                has_event_only_tax = True
                if minimum_age != 18:
                    _fail(f"{path}.min_age", "tax_evasion is an adult-only event")
            if crime.get("base_success") is not None or crime.get("base_catch") is not None:
                _fail(path, "event-only crimes must not define commit chances")
        has_salary_range = "salary_loot_min_fraction" in crime or "salary_loot_max_fraction" in crime
        if "salary_loot_multiplier" in crime and not has_salary_range:
            _fail(path, "salary_loot_multiplier requires salary loot fractions")
        if crime["requires_job"] and not has_salary_range:
            _fail(path, "job-required crimes need salary loot fractions")
        if has_salary_range:
            for key in ("salary_loot_min_fraction", "salary_loot_max_fraction"):
                value = crime.get(key)
                if isinstance(value, bool) or not isinstance(value, (int, float)):
                    _fail(f"{path}.{key}", "must be a number")
                if not math.isfinite(float(value)) or not 0 <= float(value) <= 1:
                    _fail(f"{path}.{key}", "must be between 0 and 1")
            if crime["salary_loot_min_fraction"] > crime["salary_loot_max_fraction"]:
                _fail(path, "salary loot minimum fraction cannot exceed maximum fraction")
            _integer(crime.get("salary_loot_multiplier"), f"{path}.salary_loot_multiplier", minimum=1, maximum=10)
    if not has_event_only_tax:
        _fail("crimes", "must include event-only tax_evasion")
    return document
```

## `lifeline/data/crimes.json`

```json
{
  "schema_version": 1,
  "crime_severity_mod": {
    "default": 1.0,
    "usa": 1.0,
    "in": 1.0,
    "india": 1.0,
    "uk": 1.0,
    "ca": 1.0,
    "au": 1.0,
    "jp": 1.0,
    "fr": 1.0,
    "es": 1.0
  },
  "crimes": [
    {
      "id": "shoplift",
      "name": "Shoplift",
      "description": "A small fictional theft attempt; the game skips all real-world details.",
      "min_age": 10,
      "base_success": 75,
      "loot_min_dollars": 20,
      "loot_max_dollars": 300,
      "base_catch": 20,
      "sentence_min": 0,
      "sentence_max": 0,
      "violence": false,
      "success_stat": "skill",
      "requires_job": false,
      "commit_enabled": true
    },
    {
      "id": "pickpocket",
      "name": "Pickpocket",
      "description": "A fictional street theft attempt resolved only with game probabilities.",
      "min_age": 12,
      "base_success": 65,
      "loot_min_dollars": 10,
      "loot_max_dollars": 800,
      "base_catch": 25,
      "sentence_min": 0,
      "sentence_max": 1,
      "violence": false,
      "success_stat": "skill",
      "requires_job": false,
      "commit_enabled": true
    },
    {
      "id": "vandalism",
      "name": "Vandalism",
      "description": "A fictional property-damage event with no procedural detail or loot.",
      "min_age": 10,
      "base_success": 85,
      "loot_min_dollars": 0,
      "loot_max_dollars": 0,
      "base_catch": 25,
      "sentence_min": 0,
      "sentence_max": 0,
      "violence": false,
      "success_stat": "none",
      "requires_job": false,
      "commit_enabled": true
    },
    {
      "id": "car_break_in",
      "name": "Car Break-in",
      "description": "A fictional vehicle-related offense resolved without real-world instructions.",
      "min_age": 15,
      "base_success": 60,
      "loot_min_dollars": 100,
      "loot_max_dollars": 3000,
      "base_catch": 30,
      "sentence_min": 1,
      "sentence_max": 1,
      "violence": false,
      "success_stat": "skill",
      "requires_job": false,
      "commit_enabled": true
    },
    {
      "id": "burglary",
      "name": "Burglary",
      "description": "A fictional property crime represented by a chance roll and abstract outcome.",
      "min_age": 16,
      "base_success": 50,
      "loot_min_dollars": 500,
      "loot_max_dollars": 25000,
      "base_catch": 35,
      "sentence_min": 1,
      "sentence_max": 4,
      "violence": false,
      "success_stat": "skill",
      "requires_job": false,
      "commit_enabled": true
    },
    {
      "id": "grand_theft_auto",
      "name": "Grand Theft Auto",
      "description": "A fictional vehicle theft attempt resolved only by the game's risk system.",
      "min_age": 16,
      "base_success": 45,
      "loot_min_dollars": 3000,
      "loot_max_dollars": 40000,
      "base_catch": 40,
      "sentence_min": 2,
      "sentence_max": 5,
      "violence": false,
      "success_stat": "physical",
      "requires_job": false,
      "commit_enabled": true
    },
    {
      "id": "drug_dealing",
      "name": "Drug Dealing",
      "description": "A fictional illegal-market event with no real-world substance or sales details.",
      "min_age": 16,
      "base_success": 60,
      "loot_min_dollars": 2000,
      "loot_max_dollars": 30000,
      "base_catch": 25,
      "sentence_min": 2,
      "sentence_max": 8,
      "violence": false,
      "success_stat": "skill",
      "requires_job": false,
      "commit_enabled": true
    },
    {
      "id": "fraud_scam",
      "name": "Fraud / Scam",
      "description": "A fictional financial offense described without real-world methods.",
      "min_age": 18,
      "base_success": 55,
      "loot_min_dollars": 5000,
      "loot_max_dollars": 200000,
      "base_catch": 20,
      "sentence_min": 2,
      "sentence_max": 10,
      "violence": false,
      "success_stat": "skill",
      "requires_job": false,
      "commit_enabled": true
    },
    {
      "id": "embezzlement",
      "name": "Embezzlement",
      "description": "A fictional workplace financial offense resolved with abstract game rules.",
      "min_age": 21,
      "base_success": 50,
      "loot_min_dollars": 0,
      "loot_max_dollars": 0,
      "salary_loot_min_fraction": 0.05,
      "salary_loot_max_fraction": 0.30,
      "salary_loot_multiplier": 3,
      "base_catch": 30,
      "sentence_min": 3,
      "sentence_max": 12,
      "violence": false,
      "success_stat": "skill",
      "requires_job": true,
      "commit_enabled": true
    },
    {
      "id": "assault",
      "name": "Assault",
      "description": "A brief, non-graphic fictional altercation resolved by game chance.",
      "min_age": 14,
      "base_success": 70,
      "loot_min_dollars": 0,
      "loot_max_dollars": 0,
      "base_catch": 50,
      "sentence_min": 1,
      "sentence_max": 3,
      "violence": true,
      "success_stat": "physical",
      "requires_job": false,
      "commit_enabled": true
    },
    {
      "id": "armed_robbery",
      "name": "Armed Robbery",
      "description": "A fictional high-risk violent offense; no weapon or tactics are described.",
      "min_age": 18,
      "base_success": 40,
      "loot_min_dollars": 2000,
      "loot_max_dollars": 60000,
      "base_catch": 55,
      "sentence_min": 5,
      "sentence_max": 15,
      "violence": true,
      "success_stat": "physical",
      "requires_job": false,
      "commit_enabled": true
    },
    {
      "id": "bank_heist",
      "name": "Bank Heist",
      "description": "A fictional set-piece crime represented only by abstract risk and outcome rolls.",
      "min_age": 21,
      "base_success": 15,
      "loot_min_dollars": 100000,
      "loot_max_dollars": 5000000,
      "base_catch": 70,
      "sentence_min": 10,
      "sentence_max": 25,
      "violence": true,
      "success_stat": "skill",
      "requires_job": false,
      "commit_enabled": true
    },
    {
      "id": "murder",
      "name": "Murder",
      "description": "A serious, non-graphic fictional crime with no depicted method or instructions.",
      "min_age": 16,
      "base_success": 60,
      "loot_min_dollars": 0,
      "loot_max_dollars": 0,
      "base_catch": 65,
      "sentence_min": 20,
      "sentence_max": "life",
      "violence": true,
      "success_stat": "physical",
      "requires_job": false,
      "commit_enabled": true
    },
    {
      "id": "tax_evasion",
      "name": "Tax Evasion",
      "description": "A fictional high-earner tax decision presented only as a game event.",
      "min_age": 18,
      "base_success": null,
      "loot_min_dollars": 0,
      "loot_max_dollars": 0,
      "base_catch": null,
      "sentence_min": 1,
      "sentence_max": 5,
      "violence": false,
      "success_stat": "none",
      "requires_job": false,
      "commit_enabled": false
    }
  ]
}
```

## `lifeline/tests/test_crime.py`

```python
"""Stage 7 crime, criminal-career, tax, and prison regression tests."""
from __future__ import annotations

import json
from dataclasses import replace

import pytest

from core.careers import CareerService
from core.crime import (
    CAREER_RANKS,
    CrimeService,
    calculate_crime_catch_chance,
    calculate_crime_success_chance,
    calculate_job_application_chance,
    calculate_laundering,
)
from core.education import EducationService
from core.errors import (
    CareerApplicationRejected,
    CharacterInPrison,
    CharacterNotInPrison,
    CrimeActionAlreadyUsed,
    CrimeLimitReached,
    FamilyRequirementError,
    PendingEventExists,
    ValidationError,
)
from core.family import FamilyService
from core.models import EducationLevel, HousingType
from core.money import dollars_to_cents
from core.repositories.crime import CrimeRepository
from core.rng import RNG


class FixedRNG:
    """Small injected wrapper for deterministic probability and sentence tests."""

    def __init__(
        self,
        random_values: list[float] | None = None,
        randint_values: list[int] | None = None,
        *,
        default_random: float = 0.99,
        default_randint: str = "low",
    ) -> None:
        self.random_values = list(random_values or [])
        self.randint_values = list(randint_values or [])
        self.default_random = default_random
        self.default_randint = default_randint

    def random(self) -> float:
        return self.random_values.pop(0) if self.random_values else self.default_random

    def randint(self, lower: int, upper: int) -> int:
        if self.randint_values:
            value = self.randint_values.pop(0)
            return max(lower, min(upper, value))
        return lower if self.default_randint == "low" else upper


def _stats_with(**values):
    from core.models import Stats

    return replace(Stats(), **values)


async def _set_character(database, life_engine, character, **changes):
    """Persist selected active-character state through the same version guard as the engine."""
    async with database.transaction() as tx:
        cursor = await tx.execute(
            "SELECT data_json, version FROM characters WHERE char_id = ? AND is_alive = 1",
            (character.char_id,),
        )
        row = await cursor.fetchone()
        current = type(character).from_dict(json.loads(row["data_json"]))
        current.char_id = character.char_id
        current.user_id = character.user_id
        current.version = int(row["version"])
        updated = replace(current, **changes, version=int(row["version"]) + 1)
        await life_engine._save_character(tx, updated, expected_version=int(row["version"]))
        return updated


async def _new_adult(life_engine, database, user_id: int, **changes):
    character = await life_engine.create_character(user_id, f"Test {user_id}")
    return await _set_character(
        database,
        life_engine,
        character,
        age=25,
        education_level=EducationLevel.HIGH_SCHOOL,
        stats=_stats_with(health=100, happiness=80, smarts=70, fitness=60, karma=70),
        **changes,
    )


async def _create_pending_trial(database, service, character, crime_id: str, nonce: str = "test-trial") -> str:
    async with database.transaction() as tx:
        attempt_id = await service.repository.insert_attempt(
            tx,
            char_id=character.char_id,
            crime_id=crime_id,
            age=character.age,
            source="attempt",
            success=True,
            caught=True,
            loot=0,
            success_chance=60.0,
            catch_chance=30.0,
            case_status="pending",
            created_at=1_800_000_000,
        )
        await service.repository.create_trial(tx, character.char_id, attempt_id, nonce, 1_800_000_000)
    return nonce


def test_probability_clamps_and_failed_catch_multiplier():
    assert calculate_crime_success_chance(
        0, smarts=0, fitness=0, luck=-5, success_stat="skill"
    ) == 3
    assert calculate_crime_success_chance(
        100, smarts=100, fitness=100, luck=5, success_stat="physical"
    ) == 97
    assert calculate_crime_catch_chance(1, notoriety=0, criminal_record=0) == 3
    assert calculate_crime_catch_chance(
        90, notoriety=100, criminal_record=10, failed_attempt=True
    ) == 97


def test_hiring_probability_includes_record_and_decaying_release_penalty():
    assert calculate_job_application_chance(0, age=40, last_release_age=None) == 100
    assert calculate_job_application_chance(1, age=40, last_release_age=None) == 80
    assert calculate_job_application_chance(1, age=40, last_release_age=40) == 60
    assert calculate_job_application_chance(1, age=50, last_release_age=40) == 80


@pytest.mark.asyncio
async def test_crime_attempts_are_capped_at_two_per_age(database, life_engine):
    character = await _new_adult(life_engine, database, 7101)
    service = life_engine.crimes
    service.rng = FixedRNG(random_values=[0.0, 0.99, 0.0, 0.99])
    for _ in range(2):
        preview = await service.preview_crime(character.user_id, "shoplift")
        outcome = await service.confirm_crime(character.user_id, preview.nonce)
        assert not outcome.caught
    third = await service.preview_crime(character.user_id, "shoplift")
    with pytest.raises(CrimeLimitReached):
        await service.confirm_crime(character.user_id, third.nonce)
    rows = await database.fetchall(
        "SELECT attempt_id FROM crime_attempts WHERE char_id = ? AND age = ? AND source = 'attempt'",
        (character.char_id, character.age),
    )
    assert len(rows) == 2


@pytest.mark.asyncio
async def test_crime_preview_shows_price_scaled_integer_cent_proceeds(database, life_engine):
    character = await _new_adult(life_engine, database, 7102, price_index=2.5)
    preview = await life_engine.crimes.preview_crime(character.user_id, "shoplift")
    assert preview.loot_min == dollars_to_cents(20 * 2.5)
    assert preview.loot_max == dollars_to_cents(300 * 2.5)
    assert preview.failed_catch_chance >= preview.catch_chance


@pytest.mark.asyncio
async def test_criminal_record_reduces_actual_job_offer_chance(database, life_engine):
    character = await _new_adult(life_engine, database, 7103, criminal_record=1)
    career_service = CareerService(database, RNG(3), life_engine.locks)
    career_service.hiring_rng = FixedRNG(random_values=[0.90])
    with pytest.raises(CareerApplicationRejected):
        await career_service.apply(character.user_id, "retail")

    await _set_character(database, life_engine, character, criminal_record=0)
    career_service.hiring_rng = FixedRNG(random_values=[0.90])
    status = await career_service.apply(character.user_id, "retail")
    assert status.job.career_id == "retail"


@pytest.mark.asyncio
async def test_prison_service_and_existing_actions_enforce_custody_gates(database, life_engine):
    character = await _new_adult(life_engine, database, 7104)
    service = life_engine.crimes
    with pytest.raises(CharacterNotInPrison):
        await service.prison_action(character.user_id, "study")

    imprisoned = await _set_character(
        database,
        life_engine,
        character,
        in_prison=True,
        prison_years_left=3,
        housing_type=HousingType.HOMELESS,
    )
    with pytest.raises(CharacterInPrison):
        await service.preview_crime(imprisoned.user_id, "shoplift")

    family = FamilyService(database, life_engine.rng, life_engine.locks)
    with pytest.raises(FamilyRequirementError):
        await family.find_dates(imprisoned.user_id)
    career = CareerService(database, RNG(4), life_engine.locks)
    with pytest.raises(CharacterInPrison):
        await career.apply(imprisoned.user_id, "retail")
    education = EducationService(database, life_engine.locks)
    with pytest.raises(CharacterInPrison):
        await education.study(imprisoned.user_id)

    service.rng = FixedRNG(random_values=[0.99])
    await service.prison_action(imprisoned.user_id, "behave")
    with pytest.raises(CrimeActionAlreadyUsed):
        await service.prison_action(imprisoned.user_id, "workout")


@pytest.mark.asyncio
async def test_prison_sentence_counts_down_and_releases_on_annual_age(database, life_engine):
    character = await _new_adult(life_engine, database, 7105)
    character = await _set_character(
        database,
        life_engine,
        character,
        age=30,
        in_prison=True,
        prison_years_left=2,
        housing_type=HousingType.HOMELESS,
    )
    life_engine.crimes.rng = FixedRNG(default_random=0.99)
    first = await life_engine.age_up(character.user_id)
    assert first.character.in_prison
    assert first.character.prison_years_left == 1
    second = await life_engine.age_up(character.user_id)
    assert second.character.age == 32
    assert not second.character.in_prison
    assert second.character.prison_years_left == 0


@pytest.mark.asyncio
async def test_juvenile_sentence_is_halved_sealed_and_released_at_eighteen(database, life_engine):
    character = await _new_adult(life_engine, database, 7106)
    character = await _set_character(database, life_engine, character, age=17)
    service = life_engine.crimes
    service.rng = FixedRNG(random_values=[0.0, 0.10], randint_values=[4, 10, 10, 10])
    nonce = await _create_pending_trial(database, service, character, "burglary", "juvenile-case")
    resolution = await service.resolve_trial(character.user_id, nonce, "public")
    assert resolution.convicted
    assert resolution.sentence_years == 2
    assert resolution.record_sealed
    assert resolution.character.criminal_record == 0
    assert resolution.character.in_prison
    assert resolution.character.prison_years_left == 1
    status = await service.prison_status(character.user_id)
    assert status.juvenile_release_age == 18

    service.rng = FixedRNG(default_random=0.99)
    aged = await life_engine.age_up(character.user_id)
    assert aged.character.age == 18
    assert not aged.character.in_prison


@pytest.mark.asyncio
async def test_seeded_lawyer_conviction_rates_match_tiers(database, life_engine):
    character = await _new_adult(
        life_engine, database, 7107, cash=dollars_to_cents(20_000_000)
    )
    service = life_engine.crimes
    service.rng = RNG(202607)
    observed: dict[str, float] = {}
    trials_per_tier = 120
    for tier, target in (("public", 0.85), ("standard", 0.65), ("elite", 0.40)):
        convictions = 0
        for index in range(trials_per_tier):
            nonce = f"rate-{tier}-{index}"
            await _create_pending_trial(database, service, character, "vandalism", nonce)
            result = await service.resolve_trial(character.user_id, nonce, tier)
            convictions += int(result.convicted)
            character = result.character
        rate = convictions / trials_per_tier
        observed[tier] = rate
        assert abs(rate - target) < 0.10
    assert set(observed) == {"public", "standard", "elite"}


@pytest.mark.asyncio
async def test_laundering_fee_and_annual_cap(database, life_engine):
    character = await _new_adult(life_engine, database, 7108, cash=dollars_to_cents(100_000))
    async with database.transaction() as tx:
        await life_engine.crimes.repository.update_profile(
            tx, character.char_id, dirty_cash=dollars_to_cents(100_000)
        )
    fee, net = calculate_laundering(dollars_to_cents(50_000))
    assert fee == dollars_to_cents(12_500)
    assert net == dollars_to_cents(37_500)
    result = await life_engine.crimes.launder(character.user_id, 50_000)
    assert (result.gross_amount, result.fee_amount, result.net_amount) == (
        dollars_to_cents(50_000), dollars_to_cents(12_500), dollars_to_cents(37_500)
    )
    with pytest.raises(ValidationError):
        await life_engine.crimes.launder(character.user_id, 1)
    updated = await life_engine.get_active_character(character.user_id)
    assert updated.cash == dollars_to_cents(50_000)
    assert updated.bank == dollars_to_cents(37_500)
    profile = await life_engine.crimes.repository.read_profile(character.char_id)
    assert profile["dirty_cash"] == dollars_to_cents(50_000)


@pytest.mark.asyncio
async def test_front_business_removes_the_laundering_cap(database, life_engine):
    character = await _new_adult(life_engine, database, 7109, cash=dollars_to_cents(100_000))
    async with database.transaction() as tx:
        await life_engine.crimes.repository.update_profile(
            tx, character.char_id, dirty_cash=dollars_to_cents(100_000)
        )
        await life_engine.crimes.repository.grant_front_business(tx, character.char_id, character.age, 1)
    result = await life_engine.crimes.launder(character.user_id, 75_000)
    assert result.gross_amount == dollars_to_cents(75_000)
    assert result.annual_limit == 0


@pytest.mark.asyncio
async def test_escape_success_and_failure_outcomes(database, life_engine):
    character = await _new_adult(life_engine, database, 7110)
    await _set_character(database, life_engine, character, in_prison=True, prison_years_left=4)
    life_engine.crimes.rng = FixedRNG(random_values=[0.0])
    escaped = await life_engine.crimes.prison_action(character.user_id, "escape")
    assert not escaped.character.in_prison
    assert escaped.character.notoriety >= 40
    profile = await life_engine.crimes.repository.read_profile(character.char_id)
    assert profile["escaped"] == 1

    another = await _new_adult(life_engine, database, 7111)
    await _set_character(database, life_engine, another, age=26, in_prison=True, prison_years_left=4)
    life_engine.crimes.rng = FixedRNG(random_values=[0.99], randint_values=[3])
    failed = await life_engine.crimes.prison_action(another.user_id, "escape")
    assert failed.character.in_prison
    assert failed.character.prison_years_left == 7


@pytest.mark.asyncio
async def test_trial_transaction_rolls_back_all_verdict_writes(database, life_engine):
    character = await _new_adult(life_engine, database, 7112)
    service = life_engine.crimes
    nonce = await _create_pending_trial(database, service, character, "vandalism", "rollback-case")
    underlying = service.repository

    class FailingCrimeRepository(CrimeRepository):
        async def complete_trial(self, tx, **kwargs):
            await super().complete_trial(tx, **kwargs)
            raise RuntimeError("injected after trial writes")

    service.repository = FailingCrimeRepository(database)
    with pytest.raises(RuntimeError, match="injected"):
        await service.resolve_trial(character.user_id, nonce, "public")
    service.repository = underlying

    trial = await database.fetchone("SELECT nonce FROM crime_trials WHERE char_id = ?", (character.char_id,))
    case = await database.fetchone(
        "SELECT case_status FROM crime_attempts WHERE char_id = ? ORDER BY attempt_id DESC LIMIT 1",
        (character.char_id,),
    )
    current = await life_engine.get_active_character(character.user_id)
    assert trial is not None and trial["nonce"] == nonce
    assert case["case_status"] == "pending"
    assert current.version == character.version
    assert current.criminal_record == 0


@pytest.mark.asyncio
async def test_fines_never_make_cash_or_dirty_proceeds_negative(database, life_engine):
    character = await _new_adult(life_engine, database, 7113, cash=1, bank=0)
    async with database.transaction() as tx:
        await life_engine.crimes.repository.update_profile(
            tx, character.char_id, dirty_cash=dollars_to_cents(20_000)
        )
        attempt_id = await life_engine.crimes.repository.insert_attempt(
            tx,
            char_id=character.char_id,
            crime_id="shoplift",
            age=character.age,
            source="attempt",
            success=True,
            caught=True,
            loot=dollars_to_cents(10_000),
            success_chance=70.0,
            catch_chance=30.0,
            case_status="pending",
            created_at=1_800_000_000,
        )
        await life_engine.crimes.repository.create_trial(tx, character.char_id, attempt_id, "fine-case", 1_800_000_000)
    life_engine.crimes.rng = FixedRNG(random_values=[0.0])
    result = await life_engine.crimes.resolve_trial(character.user_id, "fine-case", "public")
    assert result.fine_paid <= 1
    assert result.character.cash >= 0
    assert result.character.bank >= 0
    profile = await life_engine.crimes.repository.read_profile(character.char_id)
    assert profile["dirty_cash"] >= 0


@pytest.mark.asyncio
async def test_high_earner_tax_choice_and_double_back_tax_audit(database, life_engine):
    character = await _new_adult(life_engine, database, 7114, cash=dollars_to_cents(200_000))
    service = life_engine.crimes
    service.rng = FixedRNG(random_values=[0.99])
    async with database.transaction() as tx:
        year = await service.advance_year(
            tx,
            character,
            previous_age=character.age - 1,
            personal_income=dollars_to_cents(200_000),
            household_income=dollars_to_cents(200_000),
            tax_assessed=0,
            tax_paid=0,
            now=1_800_000_000,
        )
    assert year.pending_tax is not None
    prompt = year.pending_tax
    choice = await service.resolve_tax_choice(character.user_id, prompt.nonce, "evade_50")
    assert choice.evaded_amount == prompt.tax_due // 2
    profile = await service.repository.read_profile(character.char_id)
    assert profile["evaded_tax"] == choice.evaded_amount

    # Force the following year's audit to catch the stored evasion; the 30% prison roll misses.
    service.rng = FixedRNG(random_values=[0.0, 0.99])
    current = await life_engine.get_active_character(character.user_id)
    async with database.transaction() as tx:
        audited = await service.advance_year(
            tx,
            current,
            previous_age=current.age,
            personal_income=0,
            household_income=0,
            tax_assessed=0,
            tax_paid=0,
            now=1_800_000_001,
        )
    audit = await database.fetchone(
        "SELECT back_taxes, triggered, tax_evasion_found FROM crime_audits WHERE char_id = ? ORDER BY audit_id DESC LIMIT 1",
        (character.char_id,),
    )
    assert audit["triggered"] == 1
    assert audit["tax_evasion_found"] == 1
    assert audit["back_taxes"] == choice.evaded_amount * 2
    assert not audited.character.in_prison


@pytest.mark.asyncio
async def test_stage7_pending_decisions_block_annual_aging(database, life_engine):
    character = await _new_adult(life_engine, database, 7115)
    preview = await life_engine.crimes.preview_crime(character.user_id, "shoplift")
    with pytest.raises(PendingEventExists):
        await life_engine.age_up(character.user_id)
    await life_engine.crimes.cancel_preview(character.user_id, preview.nonce)


@pytest.mark.asyncio
async def test_prison_pauses_wages_and_ordinary_bills_but_pays_only_loans(database, life_engine):
    character = await _new_adult(
        life_engine, database, 7116, cash=dollars_to_cents(1_000)
    )
    career = CareerService(database, RNG(5), life_engine.locks)
    await career.apply(character.user_id, "retail")
    character = await _set_character(
        database, life_engine, character, in_prison=True, prison_years_left=3
    )
    async with database.transaction() as tx:
        await tx.execute(
            "INSERT INTO loans(char_id, balance, annual_payment) VALUES (?, ?, ?)",
            (character.char_id, dollars_to_cents(100), dollars_to_cents(50)),
        )
    life_engine.crimes.rng = FixedRNG(default_random=0.99)
    outcome = await life_engine.age_up(character.user_id)
    assert outcome.character.cash == dollars_to_cents(950)
    loan = await database.fetchone(
        "SELECT balance, missed_payments FROM loans WHERE char_id = ?", (character.char_id,)
    )
    assert loan["balance"] == dollars_to_cents(50)
    assert loan["missed_payments"] == 0


def test_criminal_career_ranks_reach_kingpin():
    assert CAREER_RANKS[0][0] == "Street Dealer"
    assert CAREER_RANKS[-1][0] == "Kingpin"


@pytest.mark.asyncio
async def test_criminal_career_pays_dirty_income_and_can_roll_a_yearly_arrest(database, life_engine):
    character = await _new_adult(life_engine, database, 7117)
    service = life_engine.crimes
    service.rng = FixedRNG(random_values=[0.0, 0.99])
    preview = await service.preview_crime(character.user_id, "shoplift")
    attempt = await service.confirm_crime(character.user_id, preview.nonce)
    assert attempt.success and not attempt.caught
    after_attempt = await life_engine.get_active_character(character.user_id)
    cash_before_year = after_attempt.cash

    service.rng = FixedRNG(default_random=0.99)
    async with database.transaction() as tx:
        paid = await service.advance_year(
            tx,
            after_attempt,
            previous_age=after_attempt.age - 1,
            personal_income=0,
            household_income=0,
            tax_assessed=0,
            tax_paid=0,
            now=1_800_000_000,
        )
    assert paid.character.cash - cash_before_year == CAREER_RANKS[0][2]
    profile = await service.repository.read_profile(character.char_id)
    assert profile["career_rank"] == "Street Dealer"
    assert profile["career_years"] == 1
    assert profile["dirty_cash"] >= CAREER_RANKS[0][2]

    # A second yearly roll at the Street Dealer tier uses the 8% base arrest chance.
    service.rng = FixedRNG(random_values=[0.99, 0.0])
    async with database.transaction() as tx:
        arrested = await service.advance_year(
            tx,
            paid.character,
            previous_age=paid.character.age,
            personal_income=0,
            household_income=0,
            tax_assessed=0,
            tax_paid=0,
            now=1_800_000_001,
        )
    assert arrested.pending_trial is not None
    assert arrested.pending_trial.source == "career_arrest"
    assert CrimeService._career_level(95) == len(CAREER_RANKS) - 1


@pytest.mark.asyncio
async def test_conviction_fires_job_loses_rent_and_keeps_possessions(database, life_engine):
    character = await _new_adult(
        life_engine,
        database,
        7118,
        cash=dollars_to_cents(1_000),
        housing_type=HousingType.RENT,
        rent_amount=dollars_to_cents(1_200),
    )
    career = CareerService(database, RNG(6), life_engine.locks)
    await career.apply(character.user_id, "retail")
    async with database.transaction() as tx:
        await tx.execute(
            """INSERT INTO family_assets
                   (char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at)
               VALUES (?, 'item', 'heirloom_ring', 1, 10000, 10000, ?, 1)""",
            (character.char_id, character.age),
        )
    before = await database.fetchall(
        "SELECT npc_id, score FROM relationships WHERE char_id = ?", (character.char_id,)
    )
    nonce = await _create_pending_trial(database, life_engine.crimes, character, "burglary", "prison-job-case")
    life_engine.crimes.rng = FixedRNG(random_values=[0.0], randint_values=[1, 10, 10, 10])
    result = await life_engine.crimes.resolve_trial(character.user_id, nonce, "public")
    assert result.character.in_prison
    assert result.character.housing_type is HousingType.HOMELESS
    assert result.character.housing_item_id is None
    job = await database.fetchone("SELECT 1 FROM jobs WHERE char_id = ?", (character.char_id,))
    history = await database.fetchone(
        "SELECT end_reason FROM career_history WHERE char_id = ? ORDER BY id DESC LIMIT 1",
        (character.char_id,),
    )
    asset = await database.fetchone("SELECT item_id FROM family_assets WHERE char_id = ?", (character.char_id,))
    assert job is None
    assert history["end_reason"] == "prison"
    assert asset["item_id"] == "heirloom_ring"
    after = await database.fetchall(
        "SELECT npc_id, score FROM relationships WHERE char_id = ?", (character.char_id,)
    )
    before_scores = {int(row["npc_id"]): int(row["score"]) for row in before}
    assert all(int(row["score"]) <= before_scores[int(row["npc_id"])] for row in after)


@pytest.mark.asyncio
async def test_tax_audit_sentence_is_recorded_without_a_trial(database, life_engine):
    character = await _new_adult(life_engine, database, 7119, cash=dollars_to_cents(100_000))
    service = life_engine.crimes
    async with database.transaction() as tx:
        await service.repository.update_profile(tx, character.char_id, evaded_tax=dollars_to_cents(1_000))
    service.rng = FixedRNG(random_values=[0.0, 0.0], randint_values=[2])
    async with database.transaction() as tx:
        result = await service.advance_year(
            tx,
            character,
            previous_age=character.age - 1,
            personal_income=0,
            household_income=0,
            tax_assessed=0,
            tax_paid=0,
            now=1_800_000_000,
        )
    assert result.character.in_prison
    assert result.character.prison_years_left == 2
    audit = await database.fetchone(
        "SELECT sentence_years, back_taxes FROM crime_audits WHERE char_id = ? ORDER BY audit_id DESC LIMIT 1",
        (character.char_id,),
    )
    attempt = await database.fetchone(
        "SELECT case_status, sentence_years, source FROM crime_attempts WHERE char_id = ? ORDER BY attempt_id DESC LIMIT 1",
        (character.char_id,),
    )
    assert audit["sentence_years"] == 2
    assert audit["back_taxes"] == dollars_to_cents(2_000)
    assert attempt["case_status"] == "convicted"
    assert attempt["sentence_years"] == 2
    assert attempt["source"] == "tax_audit"


def test_crime_catalog_is_loaded_and_event_only_tax_is_validated():
    from core.data_loader import DataLoader
    from core.validators import DataValidationError, validate_crime_catalog

    catalog = DataLoader().load_crimes()
    assert len(catalog["crimes"]) >= 14
    tax = next(item for item in catalog["crimes"] if item["id"] == "tax_evasion")
    assert tax["commit_enabled"] is False
    broken = json.loads(json.dumps(catalog))
    broken["crimes"].pop()
    with pytest.raises(DataValidationError):
        validate_crime_catalog(broken)
```

## `lifeline/tests/test_migrations.py`

```python
"""Migration repeatability and Stage 2 schema checks."""
from __future__ import annotations

import pytest


@pytest.mark.asyncio
async def test_initialize_is_idempotent(database):
    await database.initialize()
    await database.close()
    await database.initialize()
    versions = await database.fetchall("SELECT version FROM schema_version ORDER BY version")
    assert [row["version"] for row in versions] == [1, 2, 3, 4, 5, 6]
    tables = {row["name"] for row in await database.fetchall(
        "SELECT name FROM sqlite_master WHERE type = 'table'"
    )}
    assert {
        "characters", "life_logs", "schema_version", "education_actions", "jobs",
        "career_history", "career_actions", "npcs", "relationships", "children",
        "yearly_counters", "dating_sessions", "dating_candidates", "marriages",
        "pregnancies", "adoptions", "family_assets", "alimony", "affairs",
        "divorce_records", "stats_tracking", "infidelity_prompts", "infidelity_choices",
    }.issubset(tables)
```

## `lifeline/tests/test_stage7_cog_loading.py`

```python
"""File-backed Discord.py extension smoke test for Stage 7 commands."""
from __future__ import annotations

import discord
import pytest
from discord.ext import commands

from core.crime import CrimeService
from core.family import FamilyService
from core.locks import UserLockRegistry
from core.rng import RNG


@pytest.mark.asyncio
async def test_stage7_cogs_load_against_file_backed_database(database):
    bot = commands.Bot(command_prefix="!", intents=discord.Intents.none())
    bot.db = database
    bot.rng = RNG(701)
    bot.locks = UserLockRegistry()
    bot.family_service = FamilyService(database, bot.rng, bot.locks)
    bot.crime_service = CrimeService(
        database,
        bot.rng,
        bot.locks,
        family_service=bot.family_service,
    )

    try:
        for extension in ("cogs.life", "cogs.crime", "cogs.prison"):
            await bot.load_extension(extension)
        assert bot.tree.get_command("life") is not None
        assert bot.tree.get_command("crime") is not None
        assert bot.tree.get_command("prison") is not None
    finally:
        await bot.close()
```
