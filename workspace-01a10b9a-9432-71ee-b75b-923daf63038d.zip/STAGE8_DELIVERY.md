# Stage 8 — Shop, Inventory, and Trading

## Summary

- Added a startup-validated catalog of 70 items across 13 categories, plus transactional shop, inventory, secured financing, trade, and yearly asset systems.
- Added `/shop browse`, `/shop buy`, preserved `/shop ring` in the unified shop group, `/inventory view|sell|use`, and `/trade offer|list|cancel`.
- Kept Stage 1–7 regression tests green. `/inventory view` is used because Discord command groups cannot also execute as a bare `/inventory` command.

## Verification results

- `python -m compileall -q .` — passed.
- `pytest -q` — **113 passed in 6.65s**.
- `pytest -q tests/test_shop.py tests/test_stage8_cog_loading.py` — **27 passed in 1.83s**.
- The Stage 8 registration test loads all eight production extensions together and checks the unified `/shop` children, including `ring`.

## Engineering self-review

- Writes use the shared `BEGIN IMMEDIATE` transaction manager with rollback; shop SQL is in repositories and parameterized.
- Currency remains integer cents. Charges round up; payouts and pro-rata allocations round down. Game randomness goes through the RNG wrapper.
- Purchases use persisted, expiring nonce/version/price/balance snapshots. Trade acceptance locks both users in ascending ID order, re-fetches lives and assets, validates eligibility, and commits cash/items/audit together; a savepoint prevents conditional item-transfer failures from partially committing.
- Trade controls and modals check owner and nonce; user-facing names are escaped. Item age and country gates are enforced in the service layer.
- Financing policy in this tree: mortgages require a 650 credit score (650 baseline when unset) and 10% down; auto financing requires 600 and 20% down; defaulted or three-missed-payment accounts are blocked. The pre-Stage-8 tree had no secured mortgage/auto policy to reuse, so those thresholds are explicit Stage 8 policy.
- Discord registration was smoke-tested offline; no live Discord API command sync or real-user interaction was exercised.

## Full contents of every new/modified file

19 complete files are included below. These are full current file contents, not diffs.

## `lifeline/bot.py`

````python
"""LIFELINE Discord bot entry point."""
from __future__ import annotations

import asyncio
import logging
import secrets

import discord
from discord import app_commands
from discord.ext import commands

from core.config import Config
from core.crime import CrimeService
from core.db import DatabaseManager
from core.errors import GameError
from core.family import FamilyService
from core.locks import UserLockRegistry
from core.rng import RNG
from core.shop import ShopService

logging.basicConfig(
    level=getattr(logging, Config.from_env().log_level, logging.INFO),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("lifeline")


class LifelineBot(commands.Bot):
    """Main bot class, owning shared database, RNG, and action-lock services."""

    def __init__(self, config: Config | None = None):
        self.config = config or Config.from_env()
        intents = discord.Intents.default()
        # The entertainment cog includes a small message listener; it needs the
        # privileged Message Content intent enabled in the Discord developer portal.
        intents.message_content = True
        super().__init__(
            command_prefix=commands.when_mentioned_or("!"),
            intents=intents,
            help_command=None,
            allowed_mentions=discord.AllowedMentions(
                everyone=False,
                users=True,
                roles=False,
                replied_user=False,
            ),
        )
        self.db: DatabaseManager | None = None
        self.family_service: FamilyService | None = None
        self.crime_service: CrimeService | None = None
        self.shop_service: ShopService | None = None
        self.rng: RNG = RNG(self.config.rng_seed)
        self.locks = UserLockRegistry()
        self.tree.on_error = self.on_app_command_error

    async def setup_hook(self) -> None:
        """Initialize shared services, extensions, and application commands."""
        self.db = DatabaseManager(self.config.db_path)
        await self.db.initialize()
        self.family_service = FamilyService(self.db, self.rng, self.locks)
        self.crime_service = CrimeService(
            self.db,
            self.rng,
            self.locks,
            family_service=self.family_service,
        )
        self.shop_service = ShopService(self.db, self.rng, self.locks)
        await self._load_cogs()

        if self.config.dev_guild_id is not None:
            guild = discord.Object(id=self.config.dev_guild_id)
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
            logger.info("Synced application commands to development guild %s", guild.id)
        else:
            await self.tree.sync()
            logger.info("Synced application commands globally")

    async def _load_cogs(self) -> None:
        """Load the life simulation and entertainment command extensions."""
        for extension in (
            "cogs.life",
            "cogs.education",
            "cogs.career",
            "cogs.relationships",
            "cogs.crime",
            "cogs.prison",
            "cogs.shop",
            "cogs.discobot",
        ):
            await self.load_extension(extension)
            logger.info("Loaded extension %s", extension)

    async def on_ready(self) -> None:
        if self.user is not None:
            logger.info("Logged in as %s (ID: %s)", self.user, self.user.id)
        logger.info("Connected to %s guilds", len(self.guilds))
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="lives unfold | /life",
            ),
            status=discord.Status.online,
        )

    async def on_app_command_error(
        self,
        interaction: discord.Interaction,
        error: app_commands.AppCommandError,
    ) -> None:
        """Send safe user-facing errors and retain unexpected errors in logs."""
        if isinstance(error, app_commands.CommandOnCooldown):
            message = f"⏳ Try again in {error.retry_after:.1f} seconds."
        elif isinstance(error, (app_commands.CheckFailure, commands.CheckFailure)):
            message = "❌ You do not have permission to use this command."
        else:
            original = getattr(error, "original", error)
            if isinstance(original, GameError):
                message = original.message
            else:
                error_id = __import__("secrets").token_hex(4)
                logger.error(
                    "Unexpected application-command error (ID %s)",
                    error_id,
                    exc_info=(type(original), original, original.__traceback__),
                )
                message = f"An unexpected error occurred (ID: {error_id}). Please try again later."
        await self._send_error(interaction, message)

    @staticmethod
    async def _send_error(interaction: discord.Interaction, message: str) -> None:
        try:
            if interaction.response.is_done():
                await interaction.followup.send(message, ephemeral=True)
            else:
                await interaction.response.send_message(message, ephemeral=True)
        except discord.HTTPException:
            logger.exception("Could not send an application-command error response")

    async def close(self) -> None:
        logger.info("Shutting down LIFELINE")
        if self.db is not None:
            await self.db.close()
        await super().close()


async def main() -> None:
    config = Config.from_env()
    token = config.require_token()
    bot = LifelineBot(config)
    async with bot:
        await bot.start(token)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
````

## `lifeline/cogs/life.py`

````python
"""Slash commands for starting and advancing a LIFELINE character."""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from core.events import EventPrompt
from core.life_engine import LifeEngine, YearOutcome
from core.models import Character
from core.views import EventChoiceView, event_embed
from cogs.crime_views import TaxChoiceView, TrialView, tax_prompt_embed, trial_embed


STAT_ORDER = (
    ("health", "❤️ Health"),
    ("happiness", "😊 Happiness"),
    ("smarts", "🧠 Smarts"),
    ("looks", "✨ Looks"),
    ("fitness", "💪 Fitness"),
    ("karma", "🍀 Karma"),
)


def _stat_bar(value: int) -> str:
    filled = max(0, min(10, round(value / 10)))
    return f"{'🟩' * filled}{'⬛' * (10 - filled)} **{value}/100**"


def _character_embed(character: Character) -> discord.Embed:
    status = "Alive" if character.is_alive else f"Deceased at age {character.death_age}"
    embed = discord.Embed(
        title=f"{character.name} · Age {character.age}",
        description=(
            f"**Life stage:** {character.life_stage.value.replace('_', ' ').title()}\n"
            f"**Status:** {status}\n"
            f"**Background:** {character.wealth_class.title()} household · {character.country.upper()}"
        ),
        color=discord.Color.green() if character.is_alive else discord.Color.dark_grey(),
    )
    embed.add_field(
        name="Core stats",
        value="\n".join(f"{label}  {_stat_bar(getattr(character.stats, key))}" for key, label in STAT_ORDER),
        inline=False,
    )
    education = character.education_level.value.replace("_", " ").title()
    if character.current_school:
        education += f" · {character.current_school} ({character.school_years_left} year(s) left)"
    embed.add_field(name="Education", value=education, inline=False)
    embed.set_footer(text=f"Generation {character.generation} · Life #{character.char_id}")
    return embed


def _outcome_description(outcome: YearOutcome) -> str:
    parts = list(outcome.log_messages)
    if outcome.stat_changes:
        changes = []
        label_map = dict(STAT_ORDER)
        for key, delta in outcome.stat_changes.items():
            label = label_map.get(key, key.replace("_", " ").title())
            changes.append(f"{label} {'+' if delta > 0 else ''}{delta}")
        parts.append("**Stat changes:** " + " · ".join(changes))
    if outcome.died:
        parts.append("Start a new life with `/life start` when you're ready.")
    return "\n".join(parts)


class LifeCog(commands.Cog):
    """Birth, status, and age-advance commands."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.engine = LifeEngine(
            bot.db,
            bot.rng,
            getattr(bot, "locks", None),
            family_service=getattr(bot, "family_service", None),
            crime_service=getattr(bot, "crime_service", None),
            shop_service=getattr(bot, "shop_service", None),
        )

    life = app_commands.Group(name="life", description="Create and guide your life simulation")

    @life.command(name="start", description="Begin a new life at birth")
    @app_commands.describe(
        name="Your character's name",
        gender="Character gender",
        country="Country or region code, such as usa or in",
    )
    @app_commands.choices(gender=[
        app_commands.Choice(name="Male", value="male"),
        app_commands.Choice(name="Female", value="female"),
        app_commands.Choice(name="Non-binary", value="non_binary"),
    ])
    async def start_life(
        self,
        interaction: discord.Interaction,
        name: str,
        gender: str = "male",
        country: str = "usa",
    ) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        character = await self.engine.create_character(
            interaction.user.id,
            name,
            gender=gender,
            country=country,
        )
        embed = _character_embed(character)
        embed.description = (
            "A new story begins. Your choices will shape the life ahead.\n\n"
            + (embed.description or "")
        )
        await interaction.followup.send(embed=embed, ephemeral=True)

    @life.command(name="status", description="View your current life and stats")
    async def life_status(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        character = await self.engine.get_active_character(interaction.user.id)
        await interaction.followup.send(embed=_character_embed(character), ephemeral=True)

    @life.command(name="age", description="Advance your life by one year")
    @app_commands.checks.cooldown(1, 8.0, key=lambda interaction: interaction.user.id)
    async def age_up(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        outcome = await self.engine.age_up(interaction.user.id)
        if outcome.pending_event is not None:
            prompt: EventPrompt = outcome.pending_event
            view = EventChoiceView(interaction.user.id, prompt, self.engine.events)
            message = await interaction.followup.send(
                embed=event_embed(prompt, lead=_outcome_description(outcome)),
                view=view,
                ephemeral=True,
                wait=True,
            )
            view.bind_message(message)
            return

        if outcome.pending_trial is not None:
            view = TrialView(interaction.user.id, outcome.pending_trial, self.engine.crimes)
            embed = trial_embed(outcome.pending_trial)
            embed.description = f"{_outcome_description(outcome)}\n\n{embed.description or ''}"
            message = await interaction.followup.send(embed=embed, view=view, ephemeral=True, wait=True)
            view.bind_message(message)
            return

        if outcome.pending_tax is not None:
            view = TaxChoiceView(interaction.user.id, outcome.pending_tax, self.engine.crimes)
            embed = tax_prompt_embed(outcome.pending_tax)
            embed.description = f"{_outcome_description(outcome)}\n\n{embed.description or ''}"
            message = await interaction.followup.send(embed=embed, view=view, ephemeral=True, wait=True)
            view.bind_message(message)
            return

        embed = _character_embed(outcome.character)
        embed.description = _outcome_description(outcome)
        if outcome.died:
            embed.color = discord.Color.dark_grey()
        elif outcome.new_stage != outcome.previous_stage:
            embed.color = discord.Color.gold()
        await interaction.followup.send(embed=embed, ephemeral=True)

    @life.command(name="choice", description="Reopen your unresolved life-event choice")
    async def resume_choice(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        prompt = await self.engine.events.get_pending_event(interaction.user.id)
        view = EventChoiceView(interaction.user.id, prompt, self.engine.events)
        message = await interaction.followup.send(
            embed=event_embed(prompt, lead="Your unresolved life event is saved."),
            view=view,
            ephemeral=True,
            wait=True,
        )
        view.bind_message(message)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(LifeCog(bot))
````

## `lifeline/cogs/relationships.py`

````python
"""Discord slash commands and nonce-protected menus for Stage 6 relationships."""
from __future__ import annotations

from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from core.errors import GameError, ValidationError
from core.family import (
    WEDDING_TIERS,
    DateOutcome,
    DateSearch,
    FamilyService,
    InfidelityPrompt,
    InteractionOutcome,
    ProposalOutcome,
)
from core.money import format_cents
from core.views import OwnedView


ACTION_CHOICES = [
    app_commands.Choice(name="Spend time", value="spend_time"),
    app_commands.Choice(name="Give a gift", value="gift"),
    app_commands.Choice(name="Compliment", value="compliment"),
    app_commands.Choice(name="Argue", value="argue"),
    app_commands.Choice(name="Ask for money (parents only)", value="ask_for_money"),
    app_commands.Choice(name="Insult", value="insult"),
]
WEDDING_CHOICES = [
    app_commands.Choice(name="Courthouse · $100", value="courthouse"),
    app_commands.Choice(name="Intimate · $2,500", value="intimate"),
    app_commands.Choice(name="Traditional · $25,000", value="traditional"),
    app_commands.Choice(name="Lavish · $80,000 × price index", value="lavish"),
]
def _safe(value: object) -> str:
    """Escape user-facing names and suppress every Discord mention."""
    text = discord.utils.escape_markdown(str(value))
    return discord.utils.escape_mentions(text)


def _person_label(person: dict[str, object]) -> str:
    """Build a compact, escaped person label for family embeds."""
    name = _safe(person.get("name", "Unknown"))
    relation = _safe(person.get("relationship_type", "relative")).title()
    score = int(person.get("relationship_score", 0))
    alive = "Alive" if bool(person.get("is_alive", True)) else f"Died at age {person.get('death_age', '?')}"
    age = int(person.get("age", 0))
    return f"**{name}** · {relation} · age {age} · relationship {score}/100 · {alive}"


def _roster_embed(title: str, character: object, people: list[dict[str, object]]) -> discord.Embed:
    """Render a character's connected NPCs without exposing raw markdown or mentions."""
    name = _safe(getattr(character, "name", "Life"))
    age = int(getattr(character, "age", 0))
    embed = discord.Embed(
        title=f"{title} · {name}",
        description=f"Age {age} · {len(people)} connected person(s)",
        color=discord.Color.blurple(),
    )
    if not people:
        embed.add_field(name="Family and relationships", value="No people are recorded yet.", inline=False)
    for person in people[:20]:
        relation = str(person.get("relationship_type", "relative")).replace("_", " ").title()
        score = int(person.get("relationship_score", 0))
        value = _person_label(person)
        if person.get("custody"):
            value += f"\nCustody: {_safe(person['custody'])}"
        if int(person.get("child_support", 0) or 0) > 0:
            value += f" · Annual support: {format_cents(int(person['child_support']))}"
        embed.add_field(name=f"{relation} · {score}/100", value=value[:1024], inline=False)
    if len(people) > 20:
        embed.set_footer(text=f"Showing 20 of {len(people)} people")
    return embed


def _date_embed(search: DateSearch) -> discord.Embed:
    """Show all three date candidates as selectable profile cards."""
    embed = discord.Embed(
        title="Meet someone new",
        description="Choose one candidate below. Dating age rules are checked again when you select.",
        color=discord.Color.magenta(),
    )
    for index, person in enumerate(search.candidates, start=1):
        embed.add_field(
            name=f"Candidate {index} · {_safe(person['name'])}",
            value=(
                f"Age {person['age']} · {_safe(person['occupation'])}\n"
                f"Looks {person['looks']}/100 · Smarts {person['smarts']}/100 · "
                f"Health {person['health']}/100\n"
                f"Wealth: {format_cents(int(person['wealth']))}"
            ),
            inline=False,
        )
    embed.set_footer(text="This private selection expires in 15 minutes")
    return embed


def _date_outcome_embed(outcome: DateOutcome) -> discord.Embed:
    """Render a date result while retaining the calculated chance for feedback."""
    person = outcome.npc
    if outcome.accepted:
        title = f"A new relationship with {_safe(person['name'])}!"
        description = f"They agreed to date you. Your relationship score is 60/100."
        color = discord.Color.green()
    else:
        title = "The date didn't work out"
        description = f"{_safe(person['name'])} declined this time. You can meet new people with `/date find`."
        color = discord.Color.orange()
    embed = discord.Embed(title=title, description=description, color=color)
    embed.set_footer(text=f"Success chance: {outcome.success_chance:.1f}%")
    return embed


def _interaction_embed(outcome: InteractionOutcome) -> discord.Embed:
    """Render the score and money effect of one person-to-person action."""
    embed = discord.Embed(
        title=f"Relationship · {_safe(outcome.person_name)}",
        description=_safe(outcome.message),
        color=discord.Color.green() if outcome.score_after >= outcome.score_before else discord.Color.orange(),
    )
    embed.add_field(
        name="Relationship score",
        value=f"{outcome.score_before}/100 → {outcome.score_after}/100",
        inline=True,
    )
    if outcome.money_delta:
        embed.add_field(name="Money change", value=format_cents(outcome.money_delta), inline=True)
    embed.set_footer(text="Three interactions per person per in-game year")
    return embed


def _proposal_embed(outcome: ProposalOutcome) -> discord.Embed:
    """Render a proposal result."""
    result = "accepted" if outcome.accepted else "declined"
    return discord.Embed(
        title="💍 Proposal " + result,
        description=(
            f"{_safe(outcome.person_name)} {result} your proposal.\n"
            f"Acceptance chance: {outcome.chance}% · Ring bonus: +{outcome.ring_bonus}%"
        ),
        color=discord.Color.green() if outcome.accepted else discord.Color.orange(),
    )


class DateCandidateSelect(discord.ui.Select["DateSearchView"]):
    """A select menu whose custom ID and server-side nonce protect date options."""

    def __init__(self, search: DateSearch):
        options = [
            discord.SelectOption(
                label=f"{_safe(person['name'])} · age {person['age']}"[:100],
                description=f"{_safe(person['occupation'])} · looks {person['looks']} · smarts {person['smarts']}"[:100],
                value=str(person["npc_id"]),
            )
            for person in search.candidates
        ]
        super().__init__(
            placeholder="Choose a date",
            min_values=1,
            max_values=1,
            options=options,
            custom_id=f"lifeline:date:{search.nonce}",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        """Resolve one candidate and disable the menu after the one-use session."""
        view = self.view
        if not isinstance(view, DateSearchView):
            return
        try:
            await interaction.response.defer()
            outcome = await view.service.choose_date(interaction.user.id, int(self.values[0]), view.nonce)
            if interaction.message is not None:
                await interaction.message.edit(embed=_date_outcome_embed(outcome), view=None)
            view.stop()
        except GameError as exc:
            await interaction.followup.send(exc.message, ephemeral=True)
        except (ValueError, TypeError):
            await interaction.followup.send("That date selection is invalid.", ephemeral=True)


class DateSearchView(OwnedView):
    """Owner-checked select menu backed by a database nonce and expiry."""

    def __init__(self, owner_id: int, search: DateSearch, service: FamilyService):
        super().__init__(owner_id, search.nonce, timeout=180.0)
        self.service = service
        self.add_item(DateCandidateSelect(search))


class InfidelityChoiceView(OwnedView):
    """Owner-checked cheat-or-not choice with a persistent one-use nonce."""

    def __init__(self, owner_id: int, prompt: InfidelityPrompt, service: FamilyService):
        super().__init__(owner_id, prompt.nonce, timeout=180.0)
        self.service = service
        self.spouse_name = prompt.spouse_name
        self.add_item(InfidelityChoiceButton("Cheat", True, prompt.nonce))
        self.add_item(InfidelityChoiceButton("Stay faithful", False, prompt.nonce))

    async def resolve_choice(self, interaction: discord.Interaction, cheat: bool) -> None:
        """Resolve the selected temptation and remove controls after use."""
        try:
            await interaction.response.defer()
            message = await self.service.resolve_infidelity_choice(interaction.user.id, self.nonce, cheat)
            embed = discord.Embed(
                title="Relationship choice",
                description=_safe(message),
                color=discord.Color.orange() if cheat else discord.Color.green(),
            )
            if interaction.message is not None:
                await interaction.message.edit(embed=embed, view=None)
            self.stop()
        except GameError as exc:
            await interaction.followup.send(exc.message, ephemeral=True)


class InfidelityChoiceButton(discord.ui.Button[InfidelityChoiceView]):
    """One nonce-tagged infidelity option."""

    def __init__(self, label: str, cheat: bool, nonce: str):
        super().__init__(
            label=label,
            style=discord.ButtonStyle.danger if cheat else discord.ButtonStyle.success,
            custom_id=f"lifeline:temptation:{nonce}:{'cheat' if cheat else 'faithful'}",
        )
        self.cheat = cheat

    async def callback(self, interaction: discord.Interaction) -> None:
        """Delegate after the base view confirms component ownership."""
        if isinstance(self.view, InfidelityChoiceView):
            await self.view.resolve_choice(interaction, self.cheat)


class RelationshipsCog(commands.Cog):
    """Family, relationship, dating, friendship, and ring-shop slash commands."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.service = getattr(bot, "family_service", None) or FamilyService(
            bot.db, bot.rng, getattr(bot, "locks", None)
        )

    relationship = app_commands.Group(name="relationship", description="Manage friends, romance, and family")
    date = app_commands.Group(name="date", description="Meet age-appropriate dating candidates")
    friends = app_commands.Group(name="friends", description="Meet and manage friends")

    @app_commands.command(name="family", description="View your parents, siblings, partner, and children")
    @app_commands.checks.cooldown(1, 3.0)
    async def family_command(self, interaction: discord.Interaction) -> None:
        """Show the full current family and relationship roster."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        character, people = await self.service.family(interaction.user.id)
        await interaction.followup.send(
            embed=_roster_embed("Family", character, people),
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @relationship.command(name="list", description="List people and relationship scores")
    @app_commands.checks.cooldown(1, 3.0)
    async def relationship_list(self, interaction: discord.Interaction) -> None:
        """List all relatives, friends, partners, former partners, and children."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        character, people = await self.service.relationship_list(interaction.user.id)
        await interaction.followup.send(
            embed=_roster_embed("Relationships", character, people),
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @relationship.command(name="interact", description="Interact with one person up to three times per year")
    @app_commands.describe(
        person="A relative, friend, partner, or other listed NPC",
        action="Choose how to interact",
        gift_dollars="Gift amount in whole dollars (required for the gift action)",
    )
    @app_commands.choices(action=ACTION_CHOICES)
    @app_commands.checks.cooldown(1, 3.0)
    async def interact(
        self,
        interaction: discord.Interaction,
        person: str,
        action: str,
        gift_dollars: Optional[int] = None,
    ) -> None:
        """Apply a selected action to an autocomplete-selected person."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        npc_id = self._person_id(person)
        outcome = await self.service.interact(interaction.user.id, npc_id, action, gift_dollars)
        await interaction.followup.send(
            embed=_interaction_embed(outcome),
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @interact.autocomplete("person")
    async def interaction_person_autocomplete(
        self,
        interaction: discord.Interaction,
        current: str,
    ) -> list[app_commands.Choice[str]]:
        """Offer living connected NPCs with their relationship types."""
        return await self._autocomplete(interaction, current)

    @relationship.command(name="propose", description="Propose after a year together with a strong partner score")
    @app_commands.describe(person="Your current partner; optional owned rings boost acceptance")
    @app_commands.checks.cooldown(1, 3.0)
    async def propose(self, interaction: discord.Interaction, person: str) -> None:
        """Propose to an eligible partner."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        outcome = await self.service.propose(interaction.user.id, self._person_id(person))
        await interaction.followup.send(
            embed=_proposal_embed(outcome),
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @propose.autocomplete("person")
    async def propose_person_autocomplete(
        self,
        interaction: discord.Interaction,
        current: str,
    ) -> list[app_commands.Choice[str]]:
        """Autocomplete connected living NPCs for a proposal."""
        return await self._autocomplete(interaction, current, types={"partner"})

    @relationship.command(name="marry", description="Hold a wedding with your fiance")
    @app_commands.describe(wedding="Wedding size", prenup="Protect premarital cash, bank, and property in divorce")
    @app_commands.choices(wedding=WEDDING_CHOICES)
    @app_commands.checks.cooldown(1, 3.0)
    async def marry(self, interaction: discord.Interaction, wedding: str = "courthouse", prenup: bool = False) -> None:
        """Complete a wedding at the chosen indexed cost and optionally record a prenup."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await self.service.marry(interaction.user.id, wedding, prenup)
        embed = discord.Embed(
            title="💒 Wedding complete",
            description=(
                f"You married **{_safe(result.person_name)}**.\n"
                f"Wedding cost: {format_cents(result.wedding_cost)}\n"
                f"Prenup: {'signed' if result.prenup else 'not signed'}\n"
                f"Spouse annual income: {format_cents(result.annual_income)}"
            ),
            color=discord.Color.gold(),
        )
        await interaction.followup.send(embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @relationship.command(name="divorce", description="End a marriage and settle assets, custody, and support")
    @app_commands.checks.cooldown(1, 3.0)
    async def divorce(self, interaction: discord.Interaction) -> None:
        """Run a transactional divorce with asset division, legal fees, and custody."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        outcome = await self.service.divorce(interaction.user.id)
        embed = discord.Embed(
            title="Divorce finalized",
            description=(
                f"{_safe(outcome.spouse_name)} is now your ex-spouse.\n"
                f"Eligible marital assets: {format_cents(outcome.marital_assets)}\n"
                f"Spouse share: {format_cents(outcome.spouse_share)}\n"
                f"Lawyer fees: {format_cents(outcome.lawyer_fee)}\n"
                f"Children affected: {outcome.children}"
            ),
            color=discord.Color.orange(),
        )
        if outcome.alimony_annual:
            embed.add_field(
                name="Alimony",
                value=(
                    f"{format_cents(outcome.alimony_annual)} per year for "
                    f"{outcome.alimony_years:g} year(s)"
                ),
                inline=False,
            )
        await interaction.followup.send(embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @relationship.command(name="breakup", description="End a dating or engagement relationship")
    @app_commands.describe(person="Your current partner or fiance")
    @app_commands.checks.cooldown(1, 3.0)
    async def breakup(self, interaction: discord.Interaction, person: str) -> None:
        """Break up with an autocomplete-selected partner or fiance."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        message = await self.service.breakup(interaction.user.id, self._person_id(person))
        await interaction.followup.send(_safe(message), ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @breakup.autocomplete("person")
    async def breakup_person_autocomplete(
        self,
        interaction: discord.Interaction,
        current: str,
    ) -> list[app_commands.Choice[str]]:
        """Autocomplete living partners and fiances for breakup."""
        return await self._autocomplete(interaction, current, types={"partner", "fiance"})

    @relationship.command(name="try_for_baby", description="Try for a baby with your partner or spouse")
    @app_commands.checks.cooldown(1, 3.0)
    async def try_for_baby(self, interaction: discord.Interaction) -> None:
        """Use the age-based fertility curve to start a one-year pregnancy."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        success, chance = await self.service.try_for_baby(interaction.user.id)
        message = (
            f"Pregnancy started. The baby is due after your next `/life age`. Chance was {chance * 100:.1f}%."
            if success
            else f"No pregnancy this year. Estimated chance was {chance * 100:.1f}%; you may try again next year."
        )
        await interaction.followup.send(_safe(message), ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @relationship.command(name="adopt", description="Begin a paid adoption with a one-year wait")
    @app_commands.checks.cooldown(1, 3.0)
    async def adopt(self, interaction: discord.Interaction) -> None:
        """Pay the indexed adoption fee and schedule the child's arrival next year."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        cost = await self.service.adopt(interaction.user.id)
        await interaction.followup.send(
            f"Adoption started. The child will join after your next `/life age`. Cost: {format_cents(cost)}.",
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @relationship.command(name="temptation", description="Choose whether to cheat or stay faithful")
    @app_commands.checks.cooldown(1, 3.0)
    async def temptation(self, interaction: discord.Interaction) -> None:
        """Create a one-use infidelity choice event for a married character."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        prompt = await self.service.start_infidelity_choice(interaction.user.id)
        embed = discord.Embed(
            title="A moment of temptation",
            description=f"Your spouse **{_safe(prompt.spouse_name)}** is not here. What do you do?\n\n"
                        "If you cheat, there is a 35% discovery chance each year.",
            color=discord.Color.orange(),
        )
        view = InfidelityChoiceView(interaction.user.id, prompt, self.service)
        message = await interaction.followup.send(
            embed=embed,
            view=view,
            ephemeral=True,
            wait=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        view.bind_message(message)

    @date.command(name="find", description="Find three age-appropriate dating candidates")
    @app_commands.checks.cooldown(1, 3.0)
    async def date_find(self, interaction: discord.Interaction) -> None:
        """Generate three NPC candidates and present an owner-only select menu."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        search = await self.service.find_dates(interaction.user.id)
        view = DateSearchView(interaction.user.id, search, self.service)
        message = await interaction.followup.send(
            embed=_date_embed(search),
            view=view,
            ephemeral=True,
            wait=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        view.bind_message(message)

    @friends.command(name="find", description="Meet an age-appropriate friend")
    @app_commands.checks.cooldown(1, 3.0)
    async def friend_find(self, interaction: discord.Interaction) -> None:
        """Generate one age-appropriate friend NPC."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        person = await self.service.find_friend(interaction.user.id)
        embed = discord.Embed(
            title=f"You met {_safe(person['name'])}!",
            description=(
                f"Age {person['age']} · {_safe(person['occupation'])}\n"
                f"Relationship score: {person['relationship_score']}/100"
            ),
            color=discord.Color.green(),
        )
        await interaction.followup.send(embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @staticmethod
    def _person_id(value: str) -> int:
        """Parse the opaque NPC ID supplied by autocomplete without accepting names."""
        try:
            npc_id = int(value)
        except (TypeError, ValueError) as exc:
            raise ValidationError("Select a person from the autocomplete list.") from exc
        if npc_id <= 0:
            raise ValidationError("Select a person from the autocomplete list.")
        return npc_id

    async def _autocomplete(
        self,
        interaction: discord.Interaction,
        current: str,
        *,
        types: Optional[set[str]] = None,
    ) -> list[app_commands.Choice[str]]:
        """Create escaped Discord choices from the current life's people."""
        people = await self.service.autocomplete_people(interaction.user.id, current)
        if types is not None:
            people = [person for person in people if str(person["relationship_type"]) in types]
        return [
            app_commands.Choice(
                name=f"{_safe(person['name'])} · {_safe(person['relationship_type'])} · age {person['age']}"[:100],
                value=str(person["npc_id"]),
            )
            for person in people[:25]
        ]


async def setup(bot: commands.Bot) -> None:
    """Load the Stage 6 command cog."""
    await bot.add_cog(RelationshipsCog(bot))
````

## `lifeline/cogs/shop.py`

````python
"""Slash commands for the Stage 8 shop, inventory, and player trade system."""
from __future__ import annotations

import logging
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands, tasks

from core.errors import GameError
from core.family import FamilyService, RING_CATALOG
from core.money import format_cents
from core.shop import ShopService
from cogs.shop_views import (
    ShopBrowseView,
    ShopQuoteView,
    TradeBuilderView,
    quote_embed,
)

logger = logging.getLogger("lifeline.shop.cog")
SHOP_CATEGORIES = (
    "housing", "vehicle", "jewelry", "electronics", "health", "collectibles",
    "business", "pet", "consumable", "license", "title", "leisure",
)
RING_CHOICES = [
    app_commands.Choice(name=f"{item['name']} · {format_cents(int(item['price']))}", value=item_id)
    for item_id, item in RING_CATALOG.items()
]


def safe_text(value: str, limit: int = 150) -> str:
    """Escape markdown and mention syntax before adding content to Discord embeds."""
    result = discord.utils.escape_mentions(discord.utils.escape_markdown(str(value)))
    return result[:limit]


async def shop_item_autocomplete(
    interaction: discord.Interaction,
    current: str,
) -> list[app_commands.Choice[str]]:
    """Suggest shop-visible item IDs by a case-insensitive name prefix."""
    service = getattr(interaction.client, "shop_service", None)
    if service is None:
        return []
    query = current.strip().lower()
    return [
        app_commands.Choice(name=f"{item['name']} · {item['category']}", value=item_id)
        for item_id, item in list(service.items.items())[:]
        if item["shop_available"] and (query in item["name"].lower() or query in item_id)
    ][:25]


async def inventory_item_autocomplete(
    interaction: discord.Interaction,
    current: str,
) -> list[app_commands.Choice[str]]:
    """Suggest item IDs currently held by the caller's active life."""
    service = getattr(interaction.client, "shop_service", None)
    if service is None:
        return []
    try:
        _, items = await service.inventory(interaction.user.id)
    except GameError:
        return []
    query = current.strip().lower()
    results: list[app_commands.Choice[str]] = []
    seen: set[str] = set()
    for row in items:
        item_id = str(row["item_id"])
        if item_id in seen or (query not in str(row["name"]).lower() and query not in item_id):
            continue
        seen.add(item_id)
        results.append(app_commands.Choice(name=f"{row['name']} ×{row['quantity']}", value=item_id))
    return results[:25]


class ShopCog(commands.Cog):
    """Shop, inventory, trade commands, and a robust trade-expiry background task."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        service = getattr(bot, "shop_service", None)
        if service is None:
            service = ShopService(bot.db, bot.rng, getattr(bot, "locks", None))
            bot.shop_service = service
        self.service: ShopService = service
        relationships = getattr(bot, "family_service", None)
        if relationships is None:
            relationships = FamilyService(bot.db, bot.rng, getattr(bot, "locks", None))
            bot.family_service = relationships
        self.relationship_service: FamilyService = relationships

    async def cog_load(self) -> None:
        """Start the ten-minute-trade reaper once this extension is loaded."""
        self.expire_trades.start()

    def cog_unload(self) -> None:
        """Stop the periodic expiry task when the extension unloads."""
        self.expire_trades.cancel()

    @tasks.loop(seconds=30.0)
    async def expire_trades(self) -> None:
        """Expire pending offers, logging any error so the loop survives failures."""
        try:
            expired = await self.service.expire_pending()
            if expired:
                logger.info("Expired %s player trade offer(s)", expired)
        except Exception:
            logger.exception("Trade-expiry task failed; it will retry on the next loop")

    @expire_trades.before_loop
    async def before_expire_trades(self) -> None:
        """Wait until the bot is connected before running background database work."""
        await self.bot.wait_until_ready()

    shop = app_commands.Group(name="shop", description="Browse and purchase items")
    inventory_group = app_commands.Group(name="inventory", description="Review and manage your items")
    trade = app_commands.Group(name="trade", description="Offer items and cash to another player")

    @shop.command(name="browse", description="Browse the paginated item shop")
    @app_commands.describe(category="Optional catalog category to browse")
    @app_commands.choices(category=[app_commands.Choice(name=value.title(), value=value) for value in SHOP_CATEGORIES])
    @app_commands.checks.cooldown(1, 4.0, key=lambda interaction: interaction.user.id)
    async def browse_shop(self, interaction: discord.Interaction, category: Optional[str] = None) -> None:
        """Render a paginated shop browser with age-gated purchase quotes."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        items = await self.service.browse(interaction.user.id, category)
        view = ShopBrowseView(interaction.user.id, self.service, items, category)
        message = await interaction.followup.send(embed=view.make_embed(), view=view, ephemeral=True, wait=True)
        view.bind_message(message)

    @shop.command(name="buy", description="Get a versioned purchase quote for an item")
    @app_commands.describe(item="Item catalog entry", quantity="Number to purchase for stackable items")
    @app_commands.autocomplete(item=shop_item_autocomplete)
    @app_commands.checks.cooldown(1, 4.0, key=lambda interaction: interaction.user.id)
    async def buy_item(self, interaction: discord.Interaction, item: str, quantity: int = 1) -> None:
        """Show a price, remaining balance, and cash or financing confirmation."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        quote = await self.service.quote_purchase(interaction.user.id, item, quantity)
        view = ShopQuoteView(interaction.user.id, quote, self.service)
        message = await interaction.followup.send(embed=quote_embed(quote), view=view, ephemeral=True, wait=True)
        view.bind_message(message)

    @shop.command(name="ring", description="Buy an engagement ring for your next proposal")
    @app_commands.describe(ring="Ring item to purchase")
    @app_commands.choices(ring=RING_CHOICES)
    @app_commands.checks.cooldown(1, 3.0, key=lambda interaction: interaction.user.id)
    async def buy_ring(self, interaction: discord.Interaction, ring: str) -> None:
        """Preserve relationship-ring purchases under the unified shop command group."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        cost, bonus = await self.relationship_service.buy_ring(interaction.user.id, ring)
        item = RING_CATALOG[ring]
        await interaction.followup.send(
            f"Purchased **{safe_text(item['name'])}** for {format_cents(cost)}. It gives +{bonus}% proposal acceptance.",
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @inventory_group.command(name="view", description="View your inventory and current item values")
    @app_commands.checks.cooldown(1, 4.0, key=lambda interaction: interaction.user.id)
    async def inventory_status(self, interaction: discord.Interaction) -> None:
        """Show current holdings, locks, collateral, and liquid balances."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        character, items = await self.service.inventory(interaction.user.id)
        embed = discord.Embed(title=f"{safe_text(character.name)} · Inventory", color=discord.Color.blurple())
        embed.description = (
            f"Cash: {format_cents(character.cash)} · Bank: {format_cents(character.bank)}\n"
            f"Life age: {character.age}"
        )
        if not items:
            embed.add_field(name="Items", value="Your inventory is empty.", inline=False)
        else:
            lines: list[str] = []
            for row in items[:25]:
                flags = []
                if row["is_locked"]:
                    flags.append("locked in trade")
                if row["collateralized"]:
                    flags.append("loan collateral")
                line = (
                    f"`#{row['asset_id']}` **{safe_text(row['name'], 100)}** ×{row['quantity']} — "
                    f"{format_cents(int(row['current_value']))}"
                )
                if flags:
                    line += " · " + ", ".join(flags)
                lines.append(line)
            embed.add_field(name="Items", value="\n".join(lines), inline=False)
            if len(items) > 25:
                embed.set_footer(text=f"Showing the first 25 of {len(items)} item lots")
        await interaction.followup.send(embed=embed, ephemeral=True)

    @inventory_group.command(name="sell", description="Sell unlocked items at current market value")
    @app_commands.describe(item="Item catalog entry in your inventory", quantity="Number of copies to sell")
    @app_commands.autocomplete(item=inventory_item_autocomplete)
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def sell_item(self, interaction: discord.Interaction, item: str, quantity: int = 1) -> None:
        """Sell at 85% of current value, or 94% for housing, never shop price."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        receipt = await self.service.sell(interaction.user.id, item, quantity)
        await interaction.followup.send(
            f"Sold {receipt.quantity} × **{safe_text(receipt.item_name)}** for "
            f"{format_cents(receipt.payout)}. Remaining liquid balance: {format_cents(receipt.remaining_balance)}.",
            ephemeral=True,
        )

    @inventory_group.command(name="use", description="Use an eligible item from your inventory")
    @app_commands.describe(item="Item catalog entry in your inventory")
    @app_commands.autocomplete(item=inventory_item_autocomplete)
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def use_item(self, interaction: discord.Interaction, item: str) -> None:
        """Apply item effects, consuming a consumable or recording a reusable use."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        receipt = await self.service.use(interaction.user.id, item)
        stats = receipt.stats
        await interaction.followup.send(
            f"Used **{safe_text(receipt.item_name)}**. Remaining in selected stack: {receipt.quantity_remaining}. "
            f"Lottery payout: {format_cents(receipt.payout)}.\n"
            f"Health {stats.health} · Happiness {stats.happiness} · Fitness {stats.fitness} · Stress {stats.stress}.",
            ephemeral=True,
        )

    @trade.command(name="offer", description="Build and send a trade offer to another player")
    @app_commands.describe(target="The other player to trade with")
    @app_commands.checks.cooldown(1, 8.0, key=lambda interaction: interaction.user.id)
    async def offer_trade(self, interaction: discord.Interaction, target: discord.User) -> None:
        """Open paginated item selectors and a cash-entry modal for a trade."""
        if target.id == interaction.user.id:
            await interaction.response.send_message("You cannot trade with yourself.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True, thinking=True)
        initiator_created = int(interaction.user.created_at.timestamp())
        target_created = int(target.created_at.timestamp())
        await self.service.register_player(interaction.user.id, initiator_created)
        await self.service.register_player(target.id, target_created)
        offered, requested = await self.service.trade_candidates(interaction.user.id, target.id)
        view = TradeBuilderView(interaction.user.id, target.id, self.service, offered, requested)
        message = await interaction.followup.send(embed=view.make_embed(), view=view, ephemeral=True, wait=True)
        view.bind_message(message)

    @trade.command(name="list", description="View your recent incoming and outgoing trades")
    @app_commands.checks.cooldown(1, 4.0, key=lambda interaction: interaction.user.id)
    async def list_trades(self, interaction: discord.Interaction) -> None:
        """Display the caller's recent trade status and any failure reason."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        character, rows = await self.service.trade_history(interaction.user.id)
        embed = discord.Embed(title=f"Recent trades · {safe_text(character.name)}", color=discord.Color.blurple())
        if not rows:
            embed.description = "No trade offers yet."
        else:
            lines = []
            for row in rows[:15]:
                side = "out" if int(row["from_user_id"]) == interaction.user.id else "in"
                line = (
                    f"**#{row['trade_id']}** · {side} · {safe_text(str(row['status']).title())} · "
                    f"offer {format_cents(int(row['offer_cash']))} / request {format_cents(int(row['request_cash']))}"
                )
                if row["outcome_message"]:
                    line += f"\n└ {safe_text(str(row['outcome_message']), 140)}"
                lines.append(line)
            embed.description = "\n".join(lines)
        await interaction.followup.send(embed=embed, ephemeral=True)

    @trade.command(name="cancel", description="Cancel one of your pending outgoing trades")
    @app_commands.describe(trade_id="Trade number shown by /trade list")
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def cancel_trade(self, interaction: discord.Interaction, trade_id: app_commands.Range[int, 1]) -> None:
        """Cancel an offer by ID and unlock its items."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await self.service.cancel_trade(int(trade_id), interaction.user.id)
        await interaction.followup.send(result.message, ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    """Register Stage 8 groups and start the persistent expiry worker."""
    await bot.add_cog(ShopCog(bot))
````

## `lifeline/cogs/shop_views.py`

````python
"""Owner-bound Discord UI for shop quotes and player trade offers."""
from __future__ import annotations

import logging
import secrets
from typing import Any, Optional

import discord

from core.errors import GameError
from core.money import format_cents, parse_cents
from core.shop import ShopQuote, ShopService, TradeReceipt, TradeResult

logger = logging.getLogger("lifeline.shop.views")


def safe_label(text: str, limit: int = 100) -> str:
    """Escape markdown and mentions before rendering catalog or player text."""
    escaped = discord.utils.escape_mentions(discord.utils.escape_markdown(str(text)))
    return escaped[:limit]


def quote_embed(quote: ShopQuote) -> discord.Embed:
    """Build a confirmation embed containing the quoted amount and resulting balance."""
    embed = discord.Embed(title=f"Confirm {safe_label(quote.item_name, 200)}", color=discord.Color.gold())
    embed.add_field(name="Quantity", value=str(quote.quantity), inline=True)
    embed.add_field(name="Unit price", value=format_cents(quote.unit_price), inline=True)
    embed.add_field(name="Total", value=format_cents(quote.total_price), inline=True)
    cash_remaining = quote.balance - quote.total_price
    embed.add_field(
        name="After cash purchase",
        value=format_cents(cash_remaining) if cash_remaining >= 0 else f"Need {format_cents(-cash_remaining)} more",
        inline=False,
    )
    if quote.finance_type is not None:
        finance_remaining = quote.balance - quote.down_payment
        embed.add_field(name="Financing", value=quote.finance_type.title(), inline=True)
        embed.add_field(name="Down payment", value=format_cents(quote.down_payment), inline=True)
        embed.add_field(name="Loan principal", value=format_cents(quote.loan_principal), inline=True)
        embed.add_field(name="Term", value=f"{quote.loan_term_years} in-game years", inline=True)
        embed.add_field(
            name="After down payment",
            value=format_cents(finance_remaining) if finance_remaining >= 0 else f"Need {format_cents(-finance_remaining)} more",
            inline=True,
        )
    embed.set_footer(text="This quote expires in 2 minutes. Any balance or price change requires a retry.")
    return embed


class ShopQuoteView(discord.ui.View):
    """Single-use, owner-only confirmation for one persisted shop quote."""

    def __init__(self, owner_id: int, quote: ShopQuote, service: ShopService) -> None:
        super().__init__(timeout=120)
        self.owner_id = owner_id
        self.quote = quote
        self.service = service
        self._used = False
        self._bound_message: Optional[discord.Message] = None
        cash = discord.ui.Button(
            label="Confirm cash purchase",
            style=discord.ButtonStyle.success,
            custom_id=f"shop:cash:{quote.nonce}",
            disabled=not quote.can_pay_cash,
            row=0,
        )
        cash.callback = self.confirm_cash
        self.add_item(cash)
        if quote.finance_type is not None:
            finance = discord.ui.Button(
                label=f"Finance · {format_cents(quote.down_payment)} down",
                style=discord.ButtonStyle.primary,
                custom_id=f"shop:finance:{quote.nonce}",
                disabled=quote.balance < quote.down_payment,
                row=0,
            )
            finance.callback = self.confirm_finance
            self.add_item(finance)
        cancel = discord.ui.Button(
            label="Cancel",
            style=discord.ButtonStyle.secondary,
            custom_id=f"shop:cancel:{quote.nonce}",
            row=1,
        )
        cancel.callback = self.cancel
        self.add_item(cancel)

    def bind_message(self, message: discord.Message) -> None:
        """Remember the sent quote message so its controls can be disabled on timeout."""
        self._bound_message = message

    async def confirm_cash(self, interaction: discord.Interaction) -> None:
        """Validate ownership and the stored quote nonce, then purchase for cash."""
        if not await self._authorize(interaction, "cash"):
            return
        await self._complete_purchase(interaction, "cash")

    async def confirm_finance(self, interaction: discord.Interaction) -> None:
        """Validate ownership and the stored quote nonce, then use secured financing."""
        if not await self._authorize(interaction, "finance"):
            return
        await self._complete_purchase(interaction, "finance")

    async def cancel(self, interaction: discord.Interaction) -> None:
        """Close the quote without changing the character's balances or items."""
        if not await self._authorize(interaction, "cancel"):
            return
        self._finish()
        await interaction.response.edit_message(content="Purchase cancelled.", embed=None, view=self)

    async def _authorize(self, interaction: discord.Interaction, action: str) -> bool:
        """Require the quote owner, matching custom-ID nonce, and unused view."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This shop confirmation belongs to another player.", ephemeral=True)
            return False
        expected = f"shop:{action}:{self.quote.nonce}"
        if self._used or not interaction.data or interaction.data.get("custom_id") != expected:
            await interaction.response.send_message("This shop button is stale. Request a new quote.", ephemeral=True)
            return False
        return True

    async def _complete_purchase(self, interaction: discord.Interaction, method: str) -> None:
        """Execute the purchase once and remove active controls on every result."""
        try:
            receipt = await self.service.purchase(
                self.owner_id,
                self.quote.item_id,
                self.quote.quantity,
                expected_version=self.quote.version,
                expected_total=self.quote.total_price,
                nonce=self.quote.nonce,
                payment_method=method,
                expected_down_payment=self.quote.down_payment if method == "finance" else None,
            )
            self._finish()
            embed = discord.Embed(title="Purchase complete", color=discord.Color.green())
            embed.description = (
                f"Bought **{receipt.quantity} × {safe_label(receipt.item_name, 150)}** for "
                f"{format_cents(receipt.total_price)}.\n"
                f"Paid now: {format_cents(receipt.paid_now)} · Remaining liquid balance: "
                f"{format_cents(receipt.remaining_balance)}."
            )
            if receipt.loan_principal:
                embed.add_field(name="Secured loan", value=format_cents(receipt.loan_principal), inline=False)
            await interaction.response.edit_message(content=None, embed=embed, view=self)
        except GameError as exc:
            self._finish()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
        except Exception:
            logger.exception("Unexpected error while confirming a shop quote")
            self._finish()
            await interaction.response.edit_message(
                content="The purchase could not be completed. Request a new quote and retry.", embed=None, view=self
            )

    def _finish(self) -> None:
        """Disable and stop this one-use view."""
        self._used = True
        self.disable_all_items()
        self.stop()

    async def on_timeout(self) -> None:
        """Disable expired shop controls if the message is still editable."""
        self._finish()
        if self._bound_message is not None:
            try:
                await self._bound_message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Timed-out shop quote message could not be edited", exc_info=True)


class ShopItemSelect(discord.ui.Select):
    """Select one paginated catalog entry, then request quantity when stackable."""

    def __init__(self, parent: "ShopBrowseView") -> None:
        self.parent_view = parent
        start = parent.page_index * parent.page_size
        page = parent.items[start:start + parent.page_size]
        options = [
            discord.SelectOption(
                label=safe_label(str(item["name"]), 100),
                value=str(item["id"]),
                description=f"{format_cents(int(item['price_cents']))} · age {item['min_age']}+",
            )
            for item in page
        ]
        super().__init__(
            placeholder="Choose an item to buy",
            min_values=1,
            max_values=1,
            options=options,
            custom_id=f"shop-browse:{parent.nonce}:select:{parent.page_index}",
            row=0,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        """Authorize the browser owner and create a quote or quantity prompt."""
        if not await self.parent_view._authorize(interaction, self.custom_id):
            return
        item = self.parent_view.service.get_item(self.values[0])
        if item is None:
            await interaction.response.send_message("That catalog entry is no longer available.", ephemeral=True)
            return
        if item["stackable"]:
            await interaction.response.send_modal(
                QuantityModal(self.parent_view.owner_id, self.parent_view.service, str(item["id"]), self.parent_view.nonce)
            )
            return
        try:
            quote = await self.parent_view.service.quote_purchase(self.parent_view.owner_id, str(item["id"]), 1)
            quote_view = ShopQuoteView(self.parent_view.owner_id, quote, self.parent_view.service)
            await interaction.response.send_message(embed=quote_embed(quote), view=quote_view, ephemeral=True)
            quote_view.bind_message(await interaction.original_response())
        except GameError as exc:
            await interaction.response.send_message(exc.message, ephemeral=True)


class ShopBrowseView(discord.ui.View):
    """Owner-only paginated shop browser with a quantity-select purchase flow."""

    page_size = 8

    def __init__(self, owner_id: int, service: ShopService, items: list[dict[str, Any]], category: Optional[str] = None) -> None:
        super().__init__(timeout=180)
        self.owner_id = owner_id
        self.service = service
        self.items = items
        self.category = category
        self.page_index = 0
        self.nonce = secrets.token_urlsafe(12)
        self._closed = False
        self._bound_message: Optional[discord.Message] = None
        self._refresh_items()

    def bind_message(self, message: discord.Message) -> None:
        """Remember the browser message for timeout cleanup."""
        self._bound_message = message

    def make_embed(self) -> discord.Embed:
        """Render the current page with local-price-index-adjusted prices."""
        embed = discord.Embed(
            title=f"Shop · {self.category.title() if self.category else 'All categories'}",
            color=discord.Color.blurple(),
        )
        start = self.page_index * self.page_size
        page = self.items[start:start + self.page_size]
        lines = [
            f"**{safe_label(str(item['name']), 100)}** — {format_cents(int(item['price_cents']))} · age {item['min_age']}+"
            for item in page
        ]
        embed.description = "\n".join(lines) if lines else "No items are available in this category."
        page_count = max(1, (len(self.items) + self.page_size - 1) // self.page_size)
        embed.set_footer(text=f"Page {self.page_index + 1}/{page_count} · Prices include your character's price index")
        return embed

    def _refresh_items(self) -> None:
        """Recreate page controls with unique session-scoped custom IDs."""
        self.clear_items()
        if self.items:
            self.add_item(ShopItemSelect(self))
        page_count = max(1, (len(self.items) + self.page_size - 1) // self.page_size)
        if page_count > 1:
            previous = discord.ui.Button(
                label="Previous", style=discord.ButtonStyle.secondary,
                custom_id=f"shop-browse:{self.nonce}:previous:{self.page_index}", row=1,
                disabled=self.page_index <= 0,
            )
            previous.callback = self.previous
            self.add_item(previous)
            following = discord.ui.Button(
                label="Next", style=discord.ButtonStyle.secondary,
                custom_id=f"shop-browse:{self.nonce}:next:{self.page_index}", row=1,
                disabled=self.page_index >= page_count - 1,
            )
            following.callback = self.next
            self.add_item(following)
        close = discord.ui.Button(
            label="Close", style=discord.ButtonStyle.danger,
            custom_id=f"shop-browse:{self.nonce}:close:{self.page_index}", row=1,
        )
        close.callback = self.close
        self.add_item(close)

    async def previous(self, interaction: discord.Interaction) -> None:
        """Move to the previous catalog page after owner/nonce validation."""
        if not await self._authorize(interaction, interaction.data.get("custom_id") if interaction.data else None):
            return
        self.page_index = max(0, self.page_index - 1)
        self._refresh_items()
        await interaction.response.edit_message(embed=self.make_embed(), view=self)

    async def next(self, interaction: discord.Interaction) -> None:
        """Move to the next catalog page after owner/nonce validation."""
        if not await self._authorize(interaction, interaction.data.get("custom_id") if interaction.data else None):
            return
        page_count = max(1, (len(self.items) + self.page_size - 1) // self.page_size)
        self.page_index = min(page_count - 1, self.page_index + 1)
        self._refresh_items()
        await interaction.response.edit_message(embed=self.make_embed(), view=self)

    async def close(self, interaction: discord.Interaction) -> None:
        """Close the browser and disable its controls."""
        if not await self._authorize(interaction, interaction.data.get("custom_id") if interaction.data else None):
            return
        self._closed = True
        self.disable_all_items()
        self.stop()
        await interaction.response.edit_message(content="Shop closed.", embed=None, view=self)

    async def _authorize(self, interaction: discord.Interaction, custom_id: Optional[str]) -> bool:
        """Require the owner and this browser's session nonce in the component ID."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This shop view belongs to another player.", ephemeral=True)
            return False
        if self._closed or not custom_id or not custom_id.startswith(f"shop-browse:{self.nonce}:"):
            await interaction.response.send_message("This shop view is stale. Open `/shop browse` again.", ephemeral=True)
            return False
        return True

    async def on_timeout(self) -> None:
        """Disable expired browse controls."""
        self.disable_all_items()
        self.stop()
        if self._bound_message is not None:
            try:
                await self._bound_message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Timed-out shop browser could not be edited", exc_info=True)


class QuantityModal(discord.ui.Modal, title="Choose a quantity"):
    """Owner-bound modal for stackable shop items."""

    quantity = discord.ui.TextInput(
        label="Quantity",
        placeholder="1",
        min_length=1,
        max_length=3,
        required=True,
    )

    def __init__(self, owner_id: int, service: ShopService, item_id: str, session_nonce: str) -> None:
        super().__init__(timeout=120, custom_id=f"quantity:{session_nonce}:{item_id}")
        self.owner_id = owner_id
        self.service = service
        self.item_id = item_id
        self.session_nonce = session_nonce

    async def on_submit(self, interaction: discord.Interaction) -> None:
        """Create a persisted quote only after validating the submitting owner and quantity."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This quantity form belongs to another player.", ephemeral=True)
            return
        expected_custom_id = f"quantity:{self.session_nonce}:{self.item_id}"
        if not interaction.data or interaction.data.get("custom_id") != expected_custom_id:
            await interaction.response.send_message("This quantity form is stale. Reopen the shop.", ephemeral=True)
            return
        try:
            amount = int(str(self.quantity.value).strip())
            quote = await self.service.quote_purchase(self.owner_id, self.item_id, amount)
            quote_view = ShopQuoteView(self.owner_id, quote, self.service)
            await interaction.response.send_message(embed=quote_embed(quote), view=quote_view, ephemeral=True)
            quote_view.bind_message(await interaction.original_response())
        except (ValueError, GameError) as exc:
            message = exc.message if isinstance(exc, GameError) else "Enter a whole-number quantity."
            await interaction.response.send_message(message, ephemeral=True)


class TradeBuilderView(discord.ui.View):
    """Owner-only trade composer with paginated item selectors and a cash modal."""

    def __init__(
        self,
        owner_id: int,
        target_id: int,
        service: ShopService,
        offered: list[dict[str, Any]],
        requested: list[dict[str, Any]],
    ) -> None:
        super().__init__(timeout=240)
        self.owner_id = owner_id
        self.target_id = target_id
        self.service = service
        self.offered_rows = offered
        self.requested_rows = requested
        self.selected_offer: set[int] = set()
        self.selected_request: set[int] = set()
        self.nonce = secrets.token_urlsafe(12)
        self._closed = False
        self._bound_message: Optional[discord.Message] = None
        self._add_controls()

    def bind_message(self, message: discord.Message) -> None:
        """Remember the builder's ephemeral message for timeout cleanup."""
        self._bound_message = message

    def make_embed(self) -> discord.Embed:
        """Summarize chosen item lots without exposing unescaped user-provided text."""
        offer_lines = self._selected_lines(self.offered_rows, self.selected_offer)
        request_lines = self._selected_lines(self.requested_rows, self.selected_request)
        embed = discord.Embed(title="Build a player trade", color=discord.Color.blurple())
        embed.description = (
            f"Choose unlocked, tradeable items for both sides, then enter cash amounts.\n"
            f"**Your items:** {', '.join(offer_lines) if offer_lines else 'None'}\n"
            f"**Requested items:** {', '.join(request_lines) if request_lines else 'None'}\n"
            "Cash is not escrowed; each side must have enough cash plus a 5% tax when accepted."
        )
        embed.set_footer(text="Trade proposals expire after 10 minutes · maximum 5 offers per player per UTC day")
        return embed

    def _add_controls(self) -> None:
        """Recreate composer buttons with a per-view nonce in each custom ID."""
        self.clear_items()
        offered = discord.ui.Button(
            label="Choose your items", style=discord.ButtonStyle.primary,
            custom_id=f"trade-build:{self.nonce}:offer", row=0,
        )
        offered.callback = self.choose_offered
        self.add_item(offered)
        requested = discord.ui.Button(
            label="Choose requested items", style=discord.ButtonStyle.primary,
            custom_id=f"trade-build:{self.nonce}:request", row=0,
        )
        requested.callback = self.choose_requested
        self.add_item(requested)
        send = discord.ui.Button(
            label="Enter cash and create offer", style=discord.ButtonStyle.success,
            custom_id=f"trade-build:{self.nonce}:cash", row=1,
        )
        send.callback = self.send_offer
        self.add_item(send)
        cancel = discord.ui.Button(
            label="Close", style=discord.ButtonStyle.secondary,
            custom_id=f"trade-build:{self.nonce}:close", row=1,
        )
        cancel.callback = self.close
        self.add_item(cancel)

    async def choose_offered(self, interaction: discord.Interaction) -> None:
        """Open a paginated selector for the initiator's eligible items."""
        if not await self._authorize(interaction):
            return
        picker = TradeItemPickerView(self, "offer")
        await interaction.response.edit_message(embed=picker.make_embed(), view=picker)

    async def choose_requested(self, interaction: discord.Interaction) -> None:
        """Open a paginated selector for the target's eligible items."""
        if not await self._authorize(interaction):
            return
        picker = TradeItemPickerView(self, "request")
        await interaction.response.edit_message(embed=picker.make_embed(), view=picker)

    async def send_offer(self, interaction: discord.Interaction) -> None:
        """Open the cash modal; the trade is created only on modal submission."""
        if not await self._authorize(interaction):
            return
        await interaction.response.send_modal(TradeCashModal(self))

    async def close(self, interaction: discord.Interaction) -> None:
        """Close the trade builder without reserving any items."""
        if not await self._authorize(interaction):
            return
        self._closed = True
        self.disable_all_items()
        self.stop()
        await interaction.response.edit_message(content="Trade builder closed.", embed=None, view=self)

    async def _authorize(self, interaction: discord.Interaction) -> bool:
        """Require the initiating owner and this builder's component nonce."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This trade builder belongs to another player.", ephemeral=True)
            return False
        custom_id = interaction.data.get("custom_id") if interaction.data else ""
        if self._closed or not str(custom_id).startswith(f"trade-build:{self.nonce}:"):
            await interaction.response.send_message("This trade builder is stale. Start `/trade offer` again.", ephemeral=True)
            return False
        return True

    @staticmethod
    def _selected_lines(rows: list[dict[str, Any]], selected: set[int]) -> list[str]:
        """Format selected item names and quantities for the current offer summary."""
        lines: list[str] = []
        for row in rows:
            if int(row["asset_id"]) in selected:
                lines.append(f"{int(row['quantity'])}× {safe_label(str(row['name']), 60)}")
        return lines

    async def on_timeout(self) -> None:
        """Disable an idle trade builder."""
        self._closed = True
        self.disable_all_items()
        self.stop()
        if self._bound_message is not None:
            try:
                await self._bound_message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Timed-out trade builder could not be edited", exc_info=True)


class TradeItemSelect(discord.ui.Select):
    """Multi-select one page of items while preserving choices on other pages."""

    def __init__(self, picker: "TradeItemPickerView") -> None:
        self.picker = picker
        rows = picker.page_rows()
        options = [
            discord.SelectOption(
                label=safe_label(f"{row['quantity']}× {row['name']}", 100),
                value=str(row["asset_id"]),
                description=f"Current value {format_cents(int(row['current_value']))} · lot #{row['asset_id']}",
                default=int(row["asset_id"]) in picker.selected_set,
            )
            for row in rows
        ]
        super().__init__(
            placeholder="Select item lots on this page",
            min_values=0,
            max_values=max(1, len(options)),
            options=options,
            custom_id=f"trade-picker:{picker.builder.nonce}:{picker.side}:{picker.page_index}",
            row=0,
            disabled=not options,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        """Update page selections after verifying the owner and component nonce."""
        if not await self.picker.authorize(interaction, self.custom_id):
            return
        current_ids = {int(row["asset_id"]) for row in self.picker.page_rows()}
        selection = self.picker.selected_set
        selection.difference_update(current_ids)
        selection.update(int(value) for value in self.values)
        await interaction.response.edit_message(embed=self.picker.make_embed(), view=self.picker)


class TradeItemPickerView(discord.ui.View):
    """Paginated owner-only selector that supports inventories over Discord's 25-option limit."""

    page_size = 25

    def __init__(self, builder: TradeBuilderView, side: str) -> None:
        super().__init__(timeout=240)
        self.builder = builder
        self.side = side
        self.owner_id = builder.owner_id
        self.page_index = 0
        self._closed = False
        self._refresh()

    @property
    def rows(self) -> list[dict[str, Any]]:
        """Return the side's current selectable item rows."""
        return self.builder.offered_rows if self.side == "offer" else self.builder.requested_rows

    @property
    def selected_set(self) -> set[int]:
        """Return the builder's persistent item selections for this side."""
        return self.builder.selected_offer if self.side == "offer" else self.builder.selected_request

    def page_rows(self) -> list[dict[str, Any]]:
        """Return rows on the currently selected page."""
        start = self.page_index * self.page_size
        return self.rows[start:start + self.page_size]

    def make_embed(self) -> discord.Embed:
        """Describe the current item page and selections retained across pages."""
        embed = discord.Embed(
            title="Choose offered item lots" if self.side == "offer" else "Choose requested item lots",
            color=discord.Color.blurple(),
        )
        selected_count = len(self.selected_set)
        if not self.rows:
            embed.description = "No unlocked, tradeable items are available on this side."
        else:
            page_count = max(1, (len(self.rows) + self.page_size - 1) // self.page_size)
            names = [safe_label(str(row["name"]), 80) for row in self.page_rows()]
            embed.description = f"Page {self.page_index + 1}/{page_count}: " + ", ".join(names)
        embed.set_footer(text=f"{selected_count} lot(s) selected. Revisit a page to change its selection.")
        return embed

    def _refresh(self) -> None:
        """Rebuild selector and page controls."""
        self.clear_items()
        if self.page_rows():
            self.add_item(TradeItemSelect(self))
        page_count = max(1, (len(self.rows) + self.page_size - 1) // self.page_size)
        if page_count > 1:
            previous = discord.ui.Button(
                label="Previous", style=discord.ButtonStyle.secondary,
                custom_id=f"trade-picker:{self.builder.nonce}:{self.side}:previous:{self.page_index}",
                row=1, disabled=self.page_index <= 0,
            )
            previous.callback = self.previous
            self.add_item(previous)
            following = discord.ui.Button(
                label="Next", style=discord.ButtonStyle.secondary,
                custom_id=f"trade-picker:{self.builder.nonce}:{self.side}:next:{self.page_index}",
                row=1, disabled=self.page_index >= page_count - 1,
            )
            following.callback = self.next
            self.add_item(following)
        done = discord.ui.Button(
            label="Done", style=discord.ButtonStyle.success,
            custom_id=f"trade-picker:{self.builder.nonce}:{self.side}:done:{self.page_index}", row=1,
        )
        done.callback = self.done
        self.add_item(done)

    async def previous(self, interaction: discord.Interaction) -> None:
        """Move to the previous selection page."""
        if not await self.authorize(interaction, interaction.data.get("custom_id") if interaction.data else None):
            return
        self.page_index = max(0, self.page_index - 1)
        self._refresh()
        await interaction.response.edit_message(embed=self.make_embed(), view=self)

    async def next(self, interaction: discord.Interaction) -> None:
        """Move to the next selection page."""
        if not await self.authorize(interaction, interaction.data.get("custom_id") if interaction.data else None):
            return
        page_count = max(1, (len(self.rows) + self.page_size - 1) // self.page_size)
        self.page_index = min(page_count - 1, self.page_index + 1)
        self._refresh()
        await interaction.response.edit_message(embed=self.make_embed(), view=self)

    async def done(self, interaction: discord.Interaction) -> None:
        """Return to the trade builder with selections intact."""
        if not await self.authorize(interaction, interaction.data.get("custom_id") if interaction.data else None):
            return
        self._closed = True
        self.stop()
        self.builder._add_controls()
        await interaction.response.edit_message(embed=self.builder.make_embed(), view=self.builder)

    async def authorize(self, interaction: discord.Interaction, custom_id: Optional[str]) -> bool:
        """Verify selector ownership and a current-side selector nonce."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This item selector belongs to another player.", ephemeral=True)
            return False
        expected_prefix = f"trade-picker:{self.builder.nonce}:{self.side}:"
        if self._closed or not custom_id or not custom_id.startswith(expected_prefix):
            await interaction.response.send_message("This item selector is stale. Reopen the trade builder.", ephemeral=True)
            return False
        return True


class TradeCashModal(discord.ui.Modal, title="Cash terms"):
    """Cash-entry form that creates the trade proposal on submit."""

    offer_cash = discord.ui.TextInput(
        label="Cash you offer (dollars)", placeholder="0.00", default="0.00", max_length=24, required=True
    )
    request_cash = discord.ui.TextInput(
        label="Cash you request (dollars)", placeholder="0.00", default="0.00", max_length=24, required=True
    )

    def __init__(self, builder: TradeBuilderView) -> None:
        super().__init__(timeout=180, custom_id=f"trade-cash:{builder.nonce}")
        self.builder = builder

    async def on_submit(self, interaction: discord.Interaction) -> None:
        """Validate author and money inputs, persist the offer, and DM its target."""
        if interaction.user.id != self.builder.owner_id:
            await interaction.response.send_message("This cash form belongs to another player.", ephemeral=True)
            return
        if not interaction.data or interaction.data.get("custom_id") != f"trade-cash:{self.builder.nonce}":
            await interaction.response.send_message("This cash form is stale. Reopen `/trade offer`.", ephemeral=True)
            return
        try:
            offer_amount = parse_cents(str(self.offer_cash.value))
            request_amount = parse_cents(str(self.request_cash.value))
            offer_map = {
                int(row["asset_id"]): int(row["quantity"])
                for row in self.builder.offered_rows if int(row["asset_id"]) in self.builder.selected_offer
            }
            request_map = {
                int(row["asset_id"]): int(row["quantity"])
                for row in self.builder.requested_rows if int(row["asset_id"]) in self.builder.selected_request
            }
            if not any(offer_map.values()) and not any(request_map.values()) and offer_amount == 0 and request_amount == 0:
                raise ValueError("A trade must contain at least one item or a nonzero cash amount.")
            await interaction.response.defer(ephemeral=True, thinking=True)
            receipt = await self.builder.service.create_trade(
                self.builder.owner_id,
                self.builder.target_id,
                offered_items=offer_map,
                requested_items=request_map,
                offer_cash=offer_amount,
                request_cash=request_amount,
            )
            target_view = TradeTargetView(self.builder.target_id, receipt, self.builder.service)
            try:
                target = await interaction.client.fetch_user(self.builder.target_id)
                target_embed = trade_offer_embed(receipt, self.builder.service, interaction.user)
                dm_message = await target.send(
                    embed=target_embed,
                    view=target_view,
                    allowed_mentions=discord.AllowedMentions.none(),
                )
                target_view.bind_message(dm_message)
            except discord.HTTPException:
                await self.builder.service.cancel_trade(receipt.trade_id, self.builder.owner_id, receipt.nonce)
                await interaction.followup.send(
                    "The target could not receive a trade DM, so the offer was cancelled and your items were unlocked.",
                    ephemeral=True,
                )
                return
            creator_view = TradeCreatorView(self.builder.owner_id, receipt, self.builder.service)
            creator_message = await interaction.followup.send(
                f"Trade **#{receipt.trade_id}** sent. Your offered items are locked until it is resolved or expires.",
                view=creator_view,
                ephemeral=True,
                wait=True,
            )
            creator_view.bind_message(creator_message)
            self.builder._closed = True
            self.builder.disable_all_items()
            self.builder.stop()
            if self.builder._bound_message is not None:
                try:
                    await self.builder._bound_message.edit(
                        content=f"Trade **#{receipt.trade_id}** sent; this builder is closed.",
                        embed=None,
                        view=self.builder,
                    )
                except discord.HTTPException:
                    logger.debug("Closed trade builder could not be refreshed", exc_info=True)
        except (ValueError, GameError) as exc:
            message = exc.message if isinstance(exc, GameError) else str(exc)
            if interaction.response.is_done():
                await interaction.followup.send(message, ephemeral=True)
            else:
                await interaction.response.send_message(message, ephemeral=True)
        except Exception:
            logger.exception("Unexpected error creating a player trade")
            if interaction.response.is_done():
                await interaction.followup.send("The trade could not be created. Please retry.", ephemeral=True)
            else:
                await interaction.response.send_message("The trade could not be created. Please retry.", ephemeral=True)


def trade_offer_embed(receipt: TradeReceipt, service: ShopService, initiator: Any) -> discord.Embed:
    """Format trade terms for the target without rendering untrusted mentions."""
    embed = discord.Embed(title=f"Trade Offer #{receipt.trade_id}", color=discord.Color.gold())
    embed.description = (
        f"From **{safe_label(getattr(initiator, 'display_name', getattr(initiator, 'name', 'Player')), 100)}**\n"
        f"Expires in 10 minutes. Cash is not escrowed; accepted cash transfers incur a 5% tax."
    )
    embed.add_field(name="They offer cash", value=format_cents(receipt.offer_cash), inline=True)
    embed.add_field(name="They request cash", value=format_cents(receipt.request_cash), inline=True)
    offer = [f"{quantity}× {safe_label(service.items[item_id]['name'], 80)}" for item_id, quantity in receipt.offer_items]
    request = [f"{quantity}× {safe_label(service.items[item_id]['name'], 80)}" for item_id, quantity in receipt.request_items]
    embed.add_field(name="Items offered to you", value="\n".join(offer) if offer else "None", inline=False)
    embed.add_field(name="Items requested from you", value="\n".join(request) if request else "None", inline=False)
    if receipt.imbalance_flag:
        embed.add_field(name="Value review", value="This offer was flagged for a large value imbalance.", inline=False)
    return embed


class TradeTargetView(discord.ui.View):
    """Nonce-bound Accept/Decline controls visible only to the target account."""

    def __init__(self, owner_id: int, receipt: TradeReceipt, service: ShopService) -> None:
        super().__init__(timeout=600)
        self.owner_id = owner_id
        self.receipt = receipt
        self.service = service
        self._used = False
        self._bound_message: Optional[discord.Message] = None
        accept = discord.ui.Button(
            label="Accept", style=discord.ButtonStyle.success,
            custom_id=f"trade-target:accept:{receipt.trade_id}:{receipt.nonce}", row=0,
        )
        accept.callback = self.accept
        self.add_item(accept)
        decline = discord.ui.Button(
            label="Decline", style=discord.ButtonStyle.danger,
            custom_id=f"trade-target:decline:{receipt.trade_id}:{receipt.nonce}", row=0,
        )
        decline.callback = self.decline
        self.add_item(decline)

    def bind_message(self, message: discord.Message) -> None:
        """Remember the target DM for expiry cleanup."""
        self._bound_message = message

    async def accept(self, interaction: discord.Interaction) -> None:
        """Revalidate and atomically accept the exact offer nonce."""
        if not await self._authorize(interaction, "accept"):
            return
        try:
            result = await self.service.accept_trade(self.receipt.trade_id, self.owner_id, self.receipt.nonce)
            self._finish()
            await interaction.response.edit_message(content=result.message, embed=None, view=self)
        except GameError as exc:
            self._finish()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
        except Exception:
            logger.exception("Unexpected error accepting trade %s", self.receipt.trade_id)
            self._finish()
            await interaction.response.edit_message(content="The trade could not be accepted. Check `/trade list`.", embed=None, view=self)

    async def decline(self, interaction: discord.Interaction) -> None:
        """Decline the target's offer and atomically release offered items."""
        if not await self._authorize(interaction, "decline"):
            return
        try:
            result = await self.service.decline_trade(self.receipt.trade_id, self.owner_id, self.receipt.nonce)
            self._finish()
            await interaction.response.edit_message(content=result.message, embed=None, view=self)
        except GameError as exc:
            self._finish()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)

    async def _authorize(self, interaction: discord.Interaction, action: str) -> bool:
        """Check target user, unused view, and the custom-ID trade nonce."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Only the target player can use these trade buttons.", ephemeral=True)
            return False
        expected = f"trade-target:{action}:{self.receipt.trade_id}:{self.receipt.nonce}"
        if self._used or not interaction.data or interaction.data.get("custom_id") != expected:
            await interaction.response.send_message("This trade button is stale or already used.", ephemeral=True)
            return False
        return True

    def _finish(self) -> None:
        """Disable both terminal controls after one target response."""
        self._used = True
        self.disable_all_items()
        self.stop()

    async def on_timeout(self) -> None:
        """Disable expired DM buttons; database expiry is handled by the cog task."""
        self._finish()
        if self._bound_message is not None:
            try:
                await self._bound_message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Timed-out trade DM could not be edited", exc_info=True)


class TradeCreatorView(discord.ui.View):
    """Nonce-bound cancel control for the player who opened the offer."""

    def __init__(self, owner_id: int, receipt: TradeReceipt, service: ShopService) -> None:
        super().__init__(timeout=600)
        self.owner_id = owner_id
        self.receipt = receipt
        self.service = service
        self._used = False
        self._bound_message: Optional[discord.Message] = None
        cancel = discord.ui.Button(
            label="Cancel offer", style=discord.ButtonStyle.danger,
            custom_id=f"trade-creator:cancel:{receipt.trade_id}:{receipt.nonce}",
        )
        cancel.callback = self.cancel
        self.add_item(cancel)

    def bind_message(self, message: discord.Message) -> None:
        """Remember the initiator's ephemeral offer message for timeout cleanup."""
        self._bound_message = message

    async def cancel(self, interaction: discord.Interaction) -> None:
        """Cancel the pending offer and unlock offered item lots."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Only the offerer can cancel this trade.", ephemeral=True)
            return
        expected = f"trade-creator:cancel:{self.receipt.trade_id}:{self.receipt.nonce}"
        if self._used or not interaction.data or interaction.data.get("custom_id") != expected:
            await interaction.response.send_message("This trade button is stale or already used.", ephemeral=True)
            return
        try:
            result = await self.service.cancel_trade(self.receipt.trade_id, self.owner_id, self.receipt.nonce)
            self._used = True
            self.disable_all_items()
            self.stop()
            await interaction.response.edit_message(content=result.message, view=self)
        except GameError as exc:
            self._used = True
            self.disable_all_items()
            self.stop()
            await interaction.response.edit_message(content=exc.message, view=self)

    async def on_timeout(self) -> None:
        """Disable the initiator's controls when their local view expires."""
        self._used = True
        self.disable_all_items()
        self.stop()
        if self._bound_message is not None:
            try:
                await self._bound_message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Timed-out trade creator view could not be edited", exc_info=True)
````

## `lifeline/core/crime.py`

````python
"""Stage 7 fictional crime, sentencing, laundering, audits, and prison rules.

Crime outcomes are abstract game rolls only. This module contains no real-world
procedural guidance; all persistence is delegated to ``CrimeRepository``.
"""
from __future__ import annotations

import json
import logging
import math
import secrets
import time
from dataclasses import dataclass, replace
from decimal import Decimal, ROUND_HALF_UP
from typing import Any, Callable, Optional

import aiosqlite

from .errors import (
    CharacterDead,
    CharacterInPrison,
    CharacterNotFound,
    CharacterNotInPrison,
    CrimeActionAlreadyUsed,
    CrimeLimitReached,
    CrimeSessionExpired,
    EducationRequirementError,
    InsufficientFunds,
    PendingEventExists,
    TaxDecisionNotFound,
    TrialNotFound,
    ValidationError,
)
from .family import FamilyService
from .locks import UserLockRegistry
from .models import Character, HousingType, Stats
from .money import dollars_to_cents, format_cents, scale_cents
from .repositories.crime import CrimeRepository
from .rng import RNG
from .data_loader import DataLoader

logger = logging.getLogger("lifeline.crime")

LAWYER_CONVICTION_CHANCES: dict[str, float] = {
    "public": 85.0,
    "standard": 65.0,
    "elite": 40.0,
}
LAWYER_FEES: dict[str, int] = {
    "public": 0,
    "standard": dollars_to_cents(10_000),
    "elite": dollars_to_cents(100_000),
}
CAREER_RANKS: tuple[tuple[str, int, int], ...] = (
    ("Street Dealer", 0, dollars_to_cents(10_000)),
    ("Hustler", 20, dollars_to_cents(25_000)),
    ("Crew Leader", 40, dollars_to_cents(50_000)),
    ("Enforcer", 60, dollars_to_cents(100_000)),
    ("Crime Boss", 80, dollars_to_cents(250_000)),
    ("Kingpin", 95, dollars_to_cents(500_000)),
)
TAX_EVENT_INCOME_THRESHOLD = dollars_to_cents(100_000)
LAUNDERING_ANNUAL_CAP = dollars_to_cents(50_000)
MAX_GAME_AGE = 120


@dataclass(frozen=True, slots=True)
class CrimeDefinition:
    """Validated, immutable crime data used by the engine and command UI."""

    id: str
    name: str
    description: str
    min_age: int
    base_success: Optional[float]
    loot_min_dollars: int
    loot_max_dollars: int
    base_catch: Optional[float]
    sentence_min: int
    sentence_max: Optional[int]
    life_sentence: bool
    violence: bool
    success_stat: str
    requires_job: bool
    commit_enabled: bool
    salary_loot_min_fraction: float = 0.0
    salary_loot_max_fraction: float = 0.0
    salary_loot_multiplier: int = 1

    @classmethod
    def from_dict(cls, values: dict[str, Any]) -> "CrimeDefinition":
        """Create a typed definition from a validated JSON object."""
        raw_max = values["sentence_max"]
        return cls(
            id=str(values["id"]),
            name=str(values["name"]),
            description=str(values["description"]),
            min_age=int(values["min_age"]),
            base_success=None if values["base_success"] is None else float(values["base_success"]),
            loot_min_dollars=int(values["loot_min_dollars"]),
            loot_max_dollars=int(values["loot_max_dollars"]),
            base_catch=None if values["base_catch"] is None else float(values["base_catch"]),
            sentence_min=int(values["sentence_min"]),
            sentence_max=None if raw_max == "life" else int(raw_max),
            life_sentence=raw_max == "life",
            violence=bool(values["violence"]),
            success_stat=str(values["success_stat"]),
            requires_job=bool(values["requires_job"]),
            commit_enabled=bool(values["commit_enabled"]),
            salary_loot_min_fraction=float(values.get("salary_loot_min_fraction", 0.0)),
            salary_loot_max_fraction=float(values.get("salary_loot_max_fraction", 0.0)),
            salary_loot_multiplier=int(values.get("salary_loot_multiplier", 1)),
        )


@dataclass(frozen=True, slots=True)
class CrimePreview:
    """Risk summary persisted before a crime can be confirmed."""

    crime_id: str
    crime_name: str
    description: str
    age: int
    nonce: str
    success_chance: float
    catch_chance: float
    failed_catch_chance: float
    loot_min: int
    loot_max: int
    expires_at: int


@dataclass(frozen=True, slots=True)
class CrimeAttemptOutcome:
    """Result of one confirmed fictional crime attempt."""

    crime_id: str
    crime_name: str
    success: bool
    caught: bool
    loot: int
    success_chance: float
    catch_chance: float
    message: str
    trial: Optional["TrialPrompt"] = None


@dataclass(frozen=True, slots=True)
class TrialPrompt:
    """Owner/nonce-bound lawyer selection for one pending case."""

    nonce: str
    attempt_id: int
    crime_id: str
    crime_name: str
    age: int
    source: str


@dataclass(frozen=True, slots=True)
class TrialResolution:
    """Verdict, sentence, fine, and updated life after lawyer selection."""

    character: Character
    crime_name: str
    lawyer_tier: str
    conviction_chance: float
    convicted: bool
    sentence_years: int
    life_sentence: bool
    record_sealed: bool
    fine_paid: int
    message: str


@dataclass(frozen=True, slots=True)
class TaxEvasionPrompt:
    """Persistent annual high-earner tax decision."""

    nonce: str
    age: int
    tax_due: int
    paid_amount: int
    prepaid: bool


@dataclass(frozen=True, slots=True)
class CrimeYearResult:
    """Character, journal messages, and any decision produced by yearly step 12."""

    character: Character
    messages: tuple[str, ...] = ()
    pending_trial: Optional[TrialPrompt] = None
    pending_tax: Optional[TaxEvasionPrompt] = None


@dataclass(frozen=True, slots=True)
class TaxChoiceResult:
    """Tax decision settlement returned to the interactive choice view."""

    character: Character
    choice: str
    tax_due: int
    evaded_amount: int
    message: str


@dataclass(frozen=True, slots=True)
class LaunderResult:
    """Gross cash, fee, and bank deposit from one laundering action."""

    gross_amount: int
    fee_amount: int
    net_amount: int
    annual_limit: int


@dataclass(frozen=True, slots=True)
class PrisonActionResult:
    """Outcome of one prison-only action."""

    character: Character
    action: str
    message: str


@dataclass(frozen=True, slots=True)
class PrisonStatus:
    """Concise prison status and criminal-career details for command output."""

    character: Character
    in_prison: bool
    years_left: int
    juvenile_release_age: Optional[int]
    career_rank: Optional[str]
    career_years: int
    dirty_cash: int
    gang_protected: bool
    escaped: bool


@dataclass(frozen=True, slots=True)
class CrimeRecord:
    """Recent offenses, criminal-career state, and recoverable pending prompts."""

    character: Character
    career_rank: Optional[str]
    career_years: int
    dirty_cash: int
    evaded_tax: int
    attempts: tuple[dict[str, Any], ...]
    trial: Optional[TrialPrompt]
    tax_prompt: Optional[TaxEvasionPrompt]
    preview: Optional[CrimePreview]


def clamp_chance(value: float) -> float:
    """Clamp probability in percentage points to the required 3–97 interval."""
    return max(3.0, min(97.0, float(value)))


def calculate_crime_success_chance(
    base_success: float,
    *,
    smarts: int,
    fitness: int,
    luck: int,
    success_stat: str,
) -> float:
    """Apply the specified skill/physical/luck modifiers to a crime success roll."""
    value = float(base_success)
    if success_stat == "skill":
        value += (int(smarts) - 50) * 0.3
    elif success_stat == "physical":
        value += (int(fitness) - 50) * 0.2
    elif success_stat != "none":
        raise ValueError("success_stat must be none, skill, or physical")
    value += int(luck) * 1.0
    return clamp_chance(value)


def calculate_crime_catch_chance(
    base_catch: float,
    *,
    notoriety: int,
    criminal_record: int,
    failed_attempt: bool = False,
) -> float:
    """Apply notoriety, record, and the 1.5 failed-attempt multiplier."""
    value = float(base_catch) + int(notoriety) * 0.4 + int(criminal_record) * 3.0
    if failed_attempt:
        value *= 1.5
    return clamp_chance(value)


def calculate_job_application_chance(
    criminal_record: int,
    *,
    age: int,
    last_release_age: Optional[int],
) -> float:
    """Apply a permanent per-record penalty and a release penalty that fades over 10 years."""
    count = max(0, int(criminal_record))
    if count == 0:
        return 100.0
    years_since_release = max(0, int(age) - int(last_release_age)) if last_release_age is not None else 0
    release_penalty = max(0.0, 20.0 - 2.0 * years_since_release) if last_release_age is not None else 0.0
    record_penalty = min(95.0, 20.0 * count)
    return max(5.0, 100.0 - record_penalty - release_penalty)


def calculate_single_income_tax(income: int) -> int:
    """Calculate annual single-filer tax using the game's integer-cent tax bands."""
    if income <= 0:
        return 0
    bands = (
        (1_000_000, Decimal("0.10")),
        (4_000_000, Decimal("0.12")),
        (9_000_000, Decimal("0.22")),
        (18_000_000, Decimal("0.24")),
        (30_000_000, Decimal("0.32")),
        (None, Decimal("0.35")),
    )
    remaining = int(income)
    lower = 0
    tax = 0
    for upper, rate in bands:
        width = remaining if upper is None else max(0, min(remaining, upper - lower))
        tax += int((Decimal(width) * rate).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        remaining -= width
        if remaining <= 0:
            break
        if upper is not None:
            lower = upper
    return max(0, min(int(income), tax))


def calculate_laundering(amount: int) -> tuple[int, int]:
    """Return a 25% integer-cent laundering fee and the remaining bank deposit."""
    if isinstance(amount, bool) or not isinstance(amount, int) or amount <= 0:
        raise ValueError("laundering amount must be positive integer cents")
    fee = int((Decimal(amount) * Decimal("0.25")).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    return fee, amount - fee


class CrimeService:
    """Transactional engine for abstract crime, court, tax, and prison gameplay."""

    def __init__(
        self,
        db: Any,
        rng: RNG,
        locks: Optional[UserLockRegistry] = None,
        *,
        repository: Optional[CrimeRepository] = None,
        family_service: Optional[FamilyService] = None,
        data_loader: Optional[DataLoader] = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.db = db
        self.rng = rng.fork("lifeline-stage7-crime")
        self.locks = locks or UserLockRegistry()
        self.repository = repository or CrimeRepository(db)
        self.family_service = family_service or FamilyService(db, rng, self.locks, clock=clock)
        self.clock = clock
        catalog = (data_loader or DataLoader()).load_crimes()
        self.country_severity = {str(key).lower(): float(value) for key, value in catalog["crime_severity_mod"].items()}
        self.crimes = tuple(CrimeDefinition.from_dict(item) for item in catalog["crimes"])
        self._by_id = {crime.id: crime for crime in self.crimes}

    async def initialize_character(self, tx: aiosqlite.Connection, character: Character) -> None:
        """Initialize Stage 7 profile data during birth without changing RNG streams."""
        await self.repository.initialize_profile(tx, character.char_id)

    async def list_crimes(self, user_id: int) -> tuple[CrimeDefinition, ...]:
        """Return the validated crime catalog only to a living player with an active life."""
        async with self.locks.hold(user_id):
            await self._active_character_read(user_id)
            return self.crimes

    async def preview_crime(self, user_id: int, crime_id: str) -> CrimePreview:
        """Persist risk estimates before the player sees a one-use confirm button."""
        crime = self._by_id.get(str(crime_id))
        if crime is None or not crime.commit_enabled:
            raise ValidationError("Choose a committable crime from `/crime list`.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character.char_id)
                await self._check_no_trial_or_tax(tx, character.char_id)
                self._check_not_imprisoned(character)
                if character.age < crime.min_age:
                    raise EducationRequirementError(f"You must be at least {crime.min_age} to attempt {crime.name}.")
                job = await self.repository.get_job(tx, character.char_id)
                if crime.requires_job and job is None:
                    raise EducationRequirementError(f"{crime.name} requires an active job.")
                salary = int(job["salary"]) if job is not None else 0
                success = calculate_crime_success_chance(
                    float(crime.base_success or 0.0),
                    smarts=character.stats.smarts,
                    fitness=character.stats.fitness,
                    luck=character.hidden.luck,
                    success_stat=crime.success_stat,
                )
                catch = calculate_crime_catch_chance(
                    float(crime.base_catch or 0.0),
                    notoriety=character.notoriety,
                    criminal_record=character.criminal_record,
                )
                loot_min, loot_max = self._loot_bounds(crime, character, salary)
                nonce = secrets.token_urlsafe(16)
                now = int(self.clock())
                await self.repository.save_preview(
                    tx,
                    char_id=character.char_id,
                    crime_id=crime.id,
                    age=character.age,
                    nonce=nonce,
                    success_chance=success,
                    catch_chance=catch,
                    loot_min=loot_min,
                    loot_max=loot_max,
                    salary_snapshot=salary,
                    created_at=now,
                    expires_at=now + 300,
                )
                return CrimePreview(
                    crime.id, crime.name, crime.description, character.age, nonce,
                    success, catch, clamp_chance(catch * 1.5), loot_min, loot_max, now + 300,
                )

    async def cancel_preview(self, user_id: int, nonce: str) -> None:
        """Consume a matching risk preview when its owner cancels."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                if not await self.repository.cancel_preview(tx, character.char_id, nonce):
                    raise CrimeSessionExpired()

    async def confirm_crime(self, user_id: int, nonce: str) -> CrimeAttemptOutcome:
        """Resolve a saved risk preview, record the attempt, and open trial if caught."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                self._check_not_imprisoned(character)
                await self._check_pending_event(tx, character.char_id)
                await self._check_no_trial_or_tax(tx, character.char_id)
                now = int(self.clock())
                preview = await self.repository.get_preview(tx, character.char_id, nonce, now)
                if preview is None or int(preview["age"]) != character.age:
                    raise CrimeSessionExpired()
                crime = self._by_id.get(str(preview["crime_id"]))
                if crime is None or not crime.commit_enabled:
                    raise CrimeSessionExpired()
                if crime.requires_job and await self.repository.get_job(tx, character.char_id) is None:
                    raise EducationRequirementError(f"{crime.name} requires an active job.")
                if not await self.repository.claim_crime_attempt(tx, character.char_id, character.age):
                    raise CrimeLimitReached()

                success_chance = float(preview["success_chance"])
                success = self.rng.random() * 100.0 < success_chance
                catch_chance = float(preview["catch_chance"])
                if not success:
                    catch_chance = clamp_chance(catch_chance * 1.5)
                caught = self.rng.random() * 100.0 < catch_chance
                loot = self.rng.randint(int(preview["loot_min"]), int(preview["loot_max"])) if success else 0
                notoriety_gain = self.rng.randint(5, 25)
                karma_loss = self.rng.randint(5, 50)
                stats = replace(character.stats)
                stats.karma = max(0, stats.karma - karma_loss)
                if crime.id == "vandalism" and character.hidden.temperament == "volatile" and success:
                    stats.happiness = min(100, stats.happiness + 5)
                updated = replace(
                    character,
                    cash=character.cash + loot,
                    stats=stats,
                    notoriety=max(0, min(100, character.notoriety + notoriety_gain)),
                    version=expected_version + 1,
                )
                profile = await self.repository.get_profile(tx, character.char_id)
                dirty_cash = int(profile["dirty_cash"]) + loot
                career_level = int(profile["career_level"])
                if career_level < 0:
                    career_level = 0
                else:
                    career_level = max(career_level, self._career_level(updated.notoriety))
                career_rank = CAREER_RANKS[career_level][0]
                attempt_id = await self.repository.insert_attempt(
                    tx,
                    char_id=character.char_id,
                    crime_id=crime.id,
                    age=character.age,
                    source="attempt",
                    success=success,
                    caught=caught,
                    loot=loot,
                    success_chance=success_chance,
                    catch_chance=catch_chance,
                    case_status="pending" if caught else "clear",
                    created_at=now,
                )
                await self.repository.delete_preview(tx, character.char_id, nonce)
                await self.repository.update_profile(
                    tx,
                    character.char_id,
                    dirty_cash=dirty_cash,
                    career_rank=career_rank,
                    career_level=career_level,
                    last_crime_id=crime.id,
                )
                if loot:
                    await self.repository.add_cashflow(tx, character.char_id, character.age, "crime_income", loot, now)
                if career_level >= 4:
                    await self.repository.grant_front_business(tx, character.char_id, character.age, now)
                trial = None
                if caught:
                    trial_nonce = secrets.token_urlsafe(16)
                    await self.repository.create_trial(tx, character.char_id, attempt_id, trial_nonce, now)
                    trial = TrialPrompt(trial_nonce, attempt_id, crime.id, crime.name, character.age, "attempt")
                    message = f"You were caught after the {crime.name} attempt. Choose a lawyer for your trial."
                elif success:
                    message = f"The fictional {crime.name} attempt succeeded; {format_cents(loot)} was added as dirty cash."
                else:
                    message = f"The fictional {crime.name} attempt failed, but you avoided arrest."
                await self.repository.save_character(tx, updated, expected_version)
                await self.repository.insert_life_log(
                    tx, character.char_id, character.age, "crime", message, 4, now
                )
                return CrimeAttemptOutcome(
                    crime.id, crime.name, success, caught, loot,
                    success_chance, catch_chance, message, trial,
                )

    async def resolve_trial(self, user_id: int, nonce: str, lawyer_tier: str) -> TrialResolution:
        """Roll a conviction using the selected lawyer and settle every consequence atomically."""
        tier = str(lawyer_tier).lower()
        if tier not in LAWYER_CONVICTION_CHANCES:
            raise ValidationError("Choose public defender, standard, or elite counsel.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                trial = await self.repository.pending_trial(tx, character.char_id)
                if trial is None or str(trial["nonce"]) != nonce:
                    raise TrialNotFound()
                crime = self._by_id.get(str(trial["crime_id"]))
                if crime is None:
                    raise TrialNotFound("The charge data could not be loaded for this trial.")
                fee = 0 if tier == "public" else LAWYER_FEES[tier]
                if tier == "elite":
                    fee = scale_cents(fee, Decimal(str(character.price_index)))
                if character.cash + character.bank < fee:
                    raise InsufficientFunds(f"You need {format_cents(fee)} for that lawyer. The public defender is free.")
                updated, _ = self._deduct_funds(character, fee)
                convicted = self.rng.random() * 100.0 < LAWYER_CONVICTION_CHANCES[tier]
                fine_paid = 0
                sentence_years = 0
                life_sentence = False
                record_sealed = False
                profile = await self.repository.get_profile(tx, character.char_id)
                if convicted:
                    updated, profile, sentence_years, life_sentence, record_sealed, fine_paid = await self._apply_conviction(
                        tx,
                        updated,
                        expected_version,
                        crime,
                        profile,
                        source=str(trial["source"]),
                        loot=int(trial["loot"]),
                        now=int(self.clock()),
                        sentence_override=None,
                        life_override=False,
                        assess_fine=True,
                    )
                    case_status = "convicted"
                    verdict = "convicted"
                else:
                    updated = replace(updated, version=expected_version + 1)
                    case_status = "acquitted"
                    verdict = "acquitted"
                now = int(self.clock())
                await self.repository.complete_trial(
                    tx,
                    char_id=character.char_id,
                    attempt_id=int(trial["attempt_id"]),
                    case_status=case_status,
                    lawyer_tier=tier,
                    sentence_years=sentence_years,
                    life_sentence=life_sentence,
                    record_sealed=record_sealed,
                    fine_paid=fine_paid,
                    resolved_at=now,
                )
                await self.repository.save_character(tx, updated, expected_version)
                message = (
                    f"The court {verdict} you. Lawyer: {tier.replace('_', ' ')}; "
                    f"conviction chance: {LAWYER_CONVICTION_CHANCES[tier]:.0f}%."
                )
                if convicted:
                    if sentence_years:
                        message += f" Sentence: {sentence_years} year(s){' (life sentence)' if life_sentence else ''}."
                    if record_sealed:
                        message += " Your juvenile record was sealed."
                    if fine_paid:
                        message += f" {format_cents(fine_paid)} was seized from available crime proceeds."
                    if updated.in_prison:
                        message += " You are now in prison."
                await self.repository.insert_life_log(tx, character.char_id, character.age, "crime", message, 5, now)
                return TrialResolution(
                    updated, crime.name, tier, LAWYER_CONVICTION_CHANCES[tier], convicted,
                    sentence_years, life_sentence, record_sealed, fine_paid, message,
                )

    async def launder(self, user_id: int, amount_dollars: int) -> LaunderResult:
        """Convert dirty cash to bank balance after the fixed 25% laundering fee."""
        if isinstance(amount_dollars, bool) or not isinstance(amount_dollars, int) or amount_dollars <= 0:
            raise ValidationError("Enter a positive whole-dollar amount to launder.")
        gross = dollars_to_cents(amount_dollars)
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character.char_id)
                await self._check_no_trial_or_tax(tx, character.char_id)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "launder money")
                profile = await self.repository.get_profile(tx, character.char_id)
                available_dirty = min(int(profile["dirty_cash"]), character.cash)
                if gross > available_dirty:
                    raise InsufficientFunds("You do not have that much available dirty cash to launder.")
                has_front = await self.repository.has_front_business(tx, character.char_id)
                used = await self.repository.laundering_total(tx, character.char_id, character.age)
                limit = 0 if has_front else LAUNDERING_ANNUAL_CAP
                if not has_front and used + gross > LAUNDERING_ANNUAL_CAP:
                    remaining = max(0, LAUNDERING_ANNUAL_CAP - used)
                    raise ValidationError(
                        f"Without a front-business item, the annual laundering cap is {format_cents(LAUNDERING_ANNUAL_CAP)}; "
                        f"you have {format_cents(remaining)} left this year."
                    )
                fee, net = calculate_laundering(gross)
                updated = replace(
                    character,
                    cash=max(0, character.cash - gross),
                    bank=character.bank + net,
                    version=expected_version + 1,
                )
                await self.repository.update_profile(
                    tx, character.char_id, dirty_cash=max(0, int(profile["dirty_cash"]) - gross)
                )
                now = int(self.clock())
                await self.repository.add_laundering(tx, character.char_id, character.age, gross, fee, net, now)
                await self.repository.add_cashflow(tx, character.char_id, character.age, "launder", gross, now)
                await self.repository.add_cashflow(tx, character.char_id, character.age, "fine", fee, now)
                await self.repository.save_character(tx, updated, expected_version)
                await self.repository.insert_life_log(
                    tx, character.char_id, character.age, "crime",
                    f"Laundered {format_cents(gross)}; the fee was {format_cents(fee)}.", 3, now,
                )
                return LaunderResult(gross, fee, net, limit)

    async def resolve_tax_choice(self, user_id: int, nonce: str, choice: str) -> TaxChoiceResult:
        """Resolve one high-earner pay-or-evade event and persist its audit exposure."""
        selected = str(choice).lower()
        evasion_rates = {"pay": 0.0, "evade_50": 0.50, "evade_75": 0.75, "evade_100": 1.0}
        if selected not in evasion_rates:
            raise ValidationError("Choose to pay tax or evade 50%, 75%, or 100%.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                prompt = await self.repository.pending_tax_prompt(tx, character.char_id)
                if prompt is None or str(prompt["nonce"]) != nonce:
                    raise TaxDecisionNotFound()
                tax_due = int(prompt["tax_due"])
                rate = Decimal(str(evasion_rates[selected]))
                evaded = int((Decimal(tax_due) * rate).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
                payable = max(0, tax_due - evaded)
                updated = character
                if bool(prompt["prepaid"]):
                    paid_before = min(int(prompt["paid_amount"]), tax_due)
                    unpaid_before = max(0, tax_due - paid_before)
                    debt_reduction = min(unpaid_before, evaded)
                    refund = min(paid_before, max(0, evaded - debt_reduction))
                    updated = replace(
                        updated,
                        cash=updated.cash + refund,
                        debt_total=max(0, updated.debt_total - debt_reduction),
                    )
                else:
                    updated, unpaid = self._deduct_funds(updated, payable)
                    if unpaid:
                        updated = replace(updated, debt_total=updated.debt_total + unpaid)
                profile = await self.repository.get_profile(tx, character.char_id)
                if evaded:
                    await self.repository.update_profile(
                        tx, character.char_id, evaded_tax=int(profile["evaded_tax"]) + evaded
                    )
                now = int(self.clock())
                await self.repository.record_tax_choice(
                    tx, character.char_id, int(prompt["age"]), selected, tax_due, evaded, now
                )
                if not await self.repository.consume_tax_prompt(tx, character.char_id, nonce):
                    raise TaxDecisionNotFound()
                updated = replace(updated, version=expected_version + 1)
                await self.repository.save_character(tx, updated, expected_version)
                await self.repository.insert_life_log(
                    tx, character.char_id, character.age, "crime",
                    f"Tax decision: {selected.replace('_', ' ')}; {format_cents(evaded)} was deferred.", 3, now,
                )
                message = (
                    f"Tax decision recorded. {format_cents(payable)} was paid or remained withheld; "
                    f"{format_cents(evaded)} is exposed to a future audit."
                )
                return TaxChoiceResult(updated, selected, tax_due, evaded, message)

    async def laundered_amount(self, user_id: int) -> int:
        """Return a read-only estimate of the current year's laundering cap usage."""
        async with self.locks.hold(user_id):
            character = await self._active_character_read(user_id)
            return await self.repository.laundering_total_read(character.char_id, character.age)

    async def get_trial_prompt(self, user_id: int) -> TrialPrompt:
        """Reopen a pending trial after a component timed out or its message was lost."""
        async with self.locks.hold(user_id):
            await self._active_character_read(user_id)
            row = await self.repository.pending_trial_read(user_id)
            if row is None:
                raise TrialNotFound()
            crime = self._by_id.get(str(row["crime_id"]))
            if crime is None:
                raise TrialNotFound("The charge data could not be loaded for this trial.")
            return TrialPrompt(
                str(row["nonce"]), int(row["attempt_id"]), crime.id, crime.name,
                int(row["age"]), str(row["source"]),
            )

    async def get_tax_prompt(self, user_id: int) -> TaxEvasionPrompt:
        """Reopen an unresolved tax choice through the /crime record command."""
        async with self.locks.hold(user_id):
            await self._active_character_read(user_id)
            row = await self.repository.pending_tax_prompt_read(user_id)
            if row is None:
                raise TaxDecisionNotFound()
            return self._tax_prompt_from_row(row)

    async def prison_action(self, user_id: int, action: str) -> PrisonActionResult:
        """Resolve one annual prison action using its own in-game-year counter."""
        selected = str(action).lower()
        if selected not in {"behave", "workout", "study", "riot", "escape", "gang"}:
            raise ValidationError("Choose behave, workout, study, riot, escape, or gang.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                if not character.in_prison:
                    raise CharacterNotInPrison()
                self._check_age(character, 10, "take a prison action")
                await self._check_pending_event(tx, character.char_id)
                if await self.repository.other_pending_prompt(tx, character.char_id):
                    raise PendingEventExists("Resolve your pending crime or tax decision before taking another action.")
                if not await self.repository.claim_action(tx, character.char_id, character.age, "prison_action"):
                    raise CrimeActionAlreadyUsed()
                profile = await self.repository.get_profile(tx, character.char_id)
                updated = character
                message = ""
                if selected == "behave":
                    if self.rng.random() < 0.20:
                        years_left = max(0, character.prison_years_left - 1)
                        updated = replace(updated, prison_years_left=years_left)
                        message = "Good behavior earned one year off your sentence."
                        if years_left == 0:
                            updated, profile = await self._release(tx, updated, profile, juvenile=False)
                            message += " Your sentence is complete; you are released."
                    else:
                        message = "You kept your conduct steady, but no sentence reduction was awarded this year."
                elif selected == "workout":
                    gain = self.rng.randint(3, 6)
                    stats = replace(updated.stats, fitness=min(100, updated.stats.fitness + gain))
                    updated = replace(updated, stats=stats)
                    message = f"A routine workout improved fitness by {gain}."
                elif selected == "study":
                    if not updated.has_ged:
                        updated = replace(updated, has_ged=True)
                        message = "Your study effort earned GED eligibility for future job applications."
                    else:
                        message = "You continued studying and kept your GED credential current."
                elif selected in {"escape", "riot"}:
                    if selected == "riot" and self.rng.random() >= 0.10:
                        message = "The riot did not turn into an escape attempt."
                    else:
                        if selected == "riot":
                            message = "The disturbance created an escape opportunity. "
                        escaped = self.rng.random() < 0.08
                        if escaped:
                            updated = replace(
                                updated,
                                in_prison=False,
                                prison_years_left=0,
                                notoriety=min(100, updated.notoriety + 40),
                            )
                            await self.repository.update_profile(
                                tx, character.char_id, escaped=1, juvenile_release_age=None, gang_protected=0
                            )
                            message += "You escaped. Notoriety rose by 40; re-arrest risk is 30% each year."
                        else:
                            extension = self.rng.randint(3, 5)
                            updated = replace(updated, prison_years_left=updated.prison_years_left + extension)
                            message += f"The escape failed and added {extension} year(s) to your sentence."
                else:
                    notoriety_gain = self.rng.randint(5, 10)
                    updated = replace(updated, notoriety=min(100, updated.notoriety + notoriety_gain))
                    await self.repository.update_profile(tx, character.char_id, gang_protected=1)
                    profile["gang_protected"] = 1
                    message = f"You gained protection from random prison violence; notoriety rose by {notoriety_gain}."
                updated = replace(updated, version=expected_version + 1)
                await self.repository.save_character(tx, updated, expected_version)
                now = int(self.clock())
                await self.repository.insert_life_log(
                    tx, character.char_id, character.age, "prison", message, 3, now
                )
                return PrisonActionResult(updated, selected, message)

    async def prison_status(self, user_id: int) -> PrisonStatus:
        """Return current custody, sentence, gang, and criminal-career status."""
        async with self.locks.hold(user_id):
            character = await self._active_character_read(user_id)
            profile = await self.repository.read_profile(character.char_id) or {}
            return PrisonStatus(
                character=character,
                in_prison=character.in_prison,
                years_left=character.prison_years_left,
                juvenile_release_age=(int(profile["juvenile_release_age"]) if profile.get("juvenile_release_age") is not None else None),
                career_rank=str(profile["career_rank"]) if profile.get("career_rank") else None,
                career_years=int(profile.get("career_years", 0)),
                dirty_cash=int(profile.get("dirty_cash", 0)),
                gang_protected=bool(profile.get("gang_protected", 0)),
                escaped=bool(profile.get("escaped", 0)),
            )

    async def crime_record(self, user_id: int) -> CrimeRecord:
        """Show lifetime criminal outcomes and recover any pending owner-only decision."""
        async with self.locks.hold(user_id):
            character = await self._active_character_read(user_id)
            async with self.db.transaction() as tx:
                await self.repository.initialize_profile(tx, character.char_id)
                profile = await self.repository.get_profile(tx, character.char_id)
                preview_row = await self.repository.preview_for_character(tx, character.char_id)
                if preview_row is not None and int(preview_row["expires_at"]) < int(self.clock()):
                    await self.repository.cancel_preview(tx, character.char_id, str(preview_row["nonce"]))
                    preview_row = None
                trial_row = await self.repository.pending_trial(tx, character.char_id)
                tax_row = await self.repository.pending_tax_prompt(tx, character.char_id)
                history = await self.repository.crime_history_in_transaction(tx, character.char_id, 10)
                preview = self._preview_from_row(preview_row) if preview_row else None
                trial = self._trial_from_row(trial_row) if trial_row else None
                tax = self._tax_prompt_from_row(tax_row) if tax_row else None
                return CrimeRecord(
                    character,
                    str(profile["career_rank"]) if profile["career_rank"] else None,
                    int(profile["career_years"]),
                    int(profile["dirty_cash"]),
                    int(profile["evaded_tax"]),
                    tuple(history),
                    trial,
                    tax,
                    preview,
                )

    async def advance_year(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        previous_age: int,
        personal_income: int,
        household_income: int,
        tax_assessed: int,
        tax_paid: int,
        now: int,
    ) -> CrimeYearResult:
        """Execute Stage 7 annual step 12 inside the existing /life age transaction."""
        if not character.is_alive:
            return CrimeYearResult(character)
        profile = await self.repository.get_profile(tx, character.char_id)
        messages: list[str] = []
        updated = character
        pending_trial: Optional[TrialPrompt] = None
        pending_tax: Optional[TaxEvasionPrompt] = None
        was_in_prison = bool(character.in_prison)

        if was_in_prison:
            updated, profile, prison_messages = await self._advance_prison_year(tx, updated, profile, now)
            messages.extend(prison_messages)
        else:
            updated, profile, audit_messages = await self._run_annual_audit(
                tx, updated, profile, previous_age, household_income, now
            )
            messages.extend(audit_messages)
            if updated.is_alive and not updated.in_prison:
                if bool(profile["escaped"]):
                    if self.rng.random() < 0.30:
                        pending_trial = await self._create_career_arrest_trial(
                            tx, updated, profile, source="escape_rearrest", now=now
                        )
                        messages.append("Authorities located you after your escape; a new trial is pending.")
                if pending_trial is None and int(profile["career_level"]) >= 0:
                    arrest_chance = min(0.97, 0.08 + updated.notoriety * 0.003)
                    if self.rng.random() < arrest_chance:
                        pending_trial = await self._create_career_arrest_trial(
                            tx, updated, profile, source="career_arrest", now=now
                        )
                        messages.append("A yearly criminal-career arrest roll resulted in a pending trial.")
                if pending_trial is None and int(profile["career_level"]) >= 0:
                    updated, profile, income_message = await self._pay_criminal_career_income(
                        tx, updated, profile, now
                    )
                    if income_message:
                        messages.append(income_message)

            if updated.is_alive and not updated.in_prison:
                has_marriage = await self.repository.has_marriage(tx, updated.char_id)
                if has_marriage:
                    annual_tax = max(0, int(tax_assessed))
                    prepaid = True
                    paid_amount = max(0, min(annual_tax, int(tax_paid)))
                else:
                    high_earner = (
                        updated.age >= 18
                        and household_income >= TAX_EVENT_INCOME_THRESHOLD
                    )
                    annual_tax = (
                        calculate_single_income_tax(max(0, int(personal_income)))
                        if high_earner else 0
                    )
                    prepaid = False
                    paid_amount = 0
                if annual_tax > 0 and household_income >= TAX_EVENT_INCOME_THRESHOLD:
                    nonce = secrets.token_urlsafe(16)
                    await self.repository.save_tax_prompt(
                        tx, updated.char_id, nonce, updated.age, annual_tax, prepaid, now,
                        paid_amount=paid_amount,
                    )
                    pending_tax = TaxEvasionPrompt(nonce, updated.age, annual_tax, paid_amount, prepaid)
                    messages.append("A high-earner tax decision is waiting for you.")
                elif annual_tax > 0 and prepaid:
                    await self.repository.add_cashflow(
                        tx, updated.char_id, updated.age, "tax", paid_amount, now
                    )
            elif updated.in_prison:
                messages.append("No wages or ordinary bills were charged during imprisonment.")

        # Notoriety cools by five points each completed year, after arrest/audit rolls.
        notoriety = max(0, updated.notoriety - 5)
        updated = replace(updated, notoriety=notoriety)
        await self.repository.update_profile(tx, updated.char_id, dirty_cash=max(0, int(profile["dirty_cash"])))
        return CrimeYearResult(updated, tuple(messages), pending_trial, pending_tax)

    async def ensure_no_pending_decision(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Block /life age until pending Stage 7 confirmation, trial, or tax buttons resolve."""
        if await self.repository.has_pending_decision(tx, char_id, int(self.clock())):
            raise PendingEventExists("Resolve the crime confirmation, trial, or tax choice before using `/life age`.")

    async def _run_annual_audit(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        profile: dict[str, Any],
        previous_age: int,
        annual_income: int,
        now: int,
    ) -> tuple[Character, dict[str, Any], list[str]]:
        """Roll annual tax and unlaundered-cash audits and settle a detected evasion."""
        messages: list[str] = []
        totals = await self.repository.cashflow_totals(tx, character.char_id, previous_age)
        income = int(totals.get("crime_income", 0)) + int(totals.get("career_income", 0))
        laundered = int(totals.get("launder", 0))
        threshold = scale_cents(dollars_to_cents(10_000), Decimal(str(character.price_index)))
        cash_flag = max(0, income - laundered) > threshold
        evaded = int(profile["evaded_tax"])
        auditable = evaded > 0 or int(annual_income) >= TAX_EVENT_INCOME_THRESHOLD or cash_flag
        tax_chance = min(0.97, 0.05 + character.notoriety * 0.002) if auditable else 0.0
        cash_chance = 0.20 if cash_flag else 0.0
        chance = 1.0 - (1.0 - tax_chance) * (1.0 - cash_chance)
        triggered = chance > 0 and self.rng.random() < chance
        sentence_years = 0
        back_taxes = 0
        updated = character
        if triggered and evaded > 0:
            back_taxes = evaded * 2
            updated, unpaid = self._deduct_funds(updated, back_taxes)
            if unpaid:
                updated = replace(updated, debt_total=updated.debt_total + unpaid)
            await self.repository.update_profile(tx, character.char_id, evaded_tax=0)
            await self.repository.add_cashflow(tx, character.char_id, character.age, "audit", back_taxes, now)
            messages.append(f"A tax audit found evaded taxes; {format_cents(back_taxes)} in back taxes was assessed.")
            if self.rng.random() < 0.30:
                tax_crime = self._by_id["tax_evasion"]
                source_record = await self.repository.insert_attempt(
                    tx,
                    char_id=character.char_id,
                    crime_id=tax_crime.id,
                    age=character.age,
                    source="tax_audit",
                    success=False,
                    caught=True,
                    loot=0,
                    success_chance=0.0,
                    catch_chance=chance * 100.0,
                    case_status="convicted",
                    created_at=now,
                )
                base_sentence = self.rng.randint(tax_crime.sentence_min, int(tax_crime.sentence_max or 5))
                updated, profile, sentence_years, _, _, _ = await self._apply_conviction(
                    tx,
                    updated,
                    character.version,
                    tax_crime,
                    profile,
                    source="tax_audit",
                    loot=0,
                    now=now,
                    sentence_override=base_sentence,
                    life_override=False,
                    assess_fine=False,
                )
                await self.repository.resolve_audit_attempt(
                    tx, source_record, sentence_years=sentence_years, resolved_at=now
                )
                messages.append(f"The tax audit also resulted in a {sentence_years}-year sentence.")
        elif triggered:
            messages.append("A financial audit reviewed the year's activity and found no tax evasion.")
        elif auditable:
            messages.append("The year's tax and cash activity passed its random audit roll.")
        await self.repository.record_audit(
            tx,
            character.char_id,
            character.age,
            chance * 100.0,
            triggered,
            bool(triggered and evaded > 0),
            back_taxes,
            sentence_years,
            "caught" if triggered and evaded > 0 else ("reviewed" if triggered else "not_triggered"),
            now,
        )
        return updated, profile, messages

    async def _create_career_arrest_trial(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        profile: dict[str, Any],
        *,
        source: str,
        now: int,
    ) -> TrialPrompt:
        """Open a lawyer-choice trial after a yearly career or escape arrest roll."""
        crime_id = str(profile["last_crime_id"] or "shoplift")
        crime = self._by_id.get(crime_id, self._by_id["shoplift"])
        attempt_id = await self.repository.insert_attempt(
            tx,
            char_id=character.char_id,
            crime_id=crime.id,
            age=character.age,
            source=source,
            success=False,
            caught=True,
            loot=0,
            success_chance=0.0,
            catch_chance=min(97.0, (0.30 if source == "escape_rearrest" else 0.08 + character.notoriety * 0.003) * 100.0),
            case_status="pending",
            created_at=now,
        )
        nonce = secrets.token_urlsafe(16)
        await self.repository.create_trial(tx, character.char_id, attempt_id, nonce, now)
        return TrialPrompt(nonce, attempt_id, crime.id, crime.name, character.age, source)

    async def _pay_criminal_career_income(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        profile: dict[str, Any],
        now: int,
    ) -> tuple[Character, dict[str, Any], str]:
        """Pay yearly illegal income into cash as dirty proceeds and advance career rank."""
        current_level = max(0, int(profile["career_level"]))
        desired_level = max(current_level, self._career_level(character.notoriety))
        rank_name, _, income = CAREER_RANKS[desired_level]
        updated = character
        messages: list[str] = []
        if desired_level > current_level:
            messages.append(f"Your criminal career advanced to {rank_name}.")
        updated = replace(updated, cash=updated.cash + income)
        profile["dirty_cash"] = int(profile["dirty_cash"]) + income
        profile["career_level"] = desired_level
        profile["career_rank"] = rank_name
        profile["career_years"] = int(profile["career_years"]) + 1
        await self.repository.update_profile(
            tx,
            character.char_id,
            career_level=desired_level,
            career_rank=rank_name,
            career_years=int(profile["career_years"]),
            dirty_cash=int(profile["dirty_cash"]),
        )
        await self.repository.add_cashflow(tx, character.char_id, character.age, "career_income", income, now)
        if desired_level >= 4:
            await self.repository.grant_front_business(tx, character.char_id, character.age, now)
            profile["front_business"] = 1
        messages.append(f"Criminal-career income added {format_cents(income)} as dirty cash.")
        return updated, profile, " ".join(messages)

    async def _advance_prison_year(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        profile: dict[str, Any],
        now: int,
    ) -> tuple[Character, dict[str, Any], list[str]]:
        """Pay affordable loans, tick a prison sentence, and resolve non-graphic violence."""
        messages: list[str] = []
        updated = character
        for loan in await self.repository.active_loans(tx, character.char_id):
            payment = min(int(loan["annual_payment"]), int(loan["balance"]))
            if payment <= 0:
                continue
            if updated.cash + updated.bank >= payment:
                cash_paid = min(max(0, updated.cash), payment)
                bank_paid = payment - cash_paid
                updated = replace(
                    updated,
                    cash=max(0, updated.cash - cash_paid),
                    bank=max(0, updated.bank - bank_paid),
                    debt_total=max(0, updated.debt_total - payment),
                )
                await self.repository.pay_loan(tx, int(loan["loan_id"]), payment)
                messages.append(f"A loan payment of {format_cents(payment)} was auto-paid from available funds.")
            else:
                await self.repository.miss_loan_payment(tx, int(loan["loan_id"]))
                messages.append("A loan payment was missed because the bank balance was not enough.")
        years_left = max(0, updated.prison_years_left - 1)
        updated = replace(updated, prison_years_left=years_left)
        juvenile_release = profile.get("juvenile_release_age")
        release_due = years_left == 0 or (
            juvenile_release is not None and updated.age >= int(juvenile_release)
        )
        if release_due:
            updated, profile = await self._release(tx, updated, profile, juvenile=juvenile_release is not None)
            messages.append("Your sentence ended and you were released from custody.")
        elif not bool(profile["gang_protected"]) and self.rng.random() < 0.05:
            damage = self.rng.randint(2, 8)
            stats = replace(updated.stats)
            stats.health = max(0, stats.health - damage)
            stats.happiness = max(0, stats.happiness - self.rng.randint(2, 6))
            updated = replace(updated, stats=stats)
            messages.append("A non-graphic prison disturbance lowered your health and happiness.")
            if stats.health <= 0 or self.rng.random() < 0.02:
                updated = replace(
                    updated,
                    is_alive=False,
                    in_prison=False,
                    prison_years_left=0,
                    death_cause="prison violence",
                    death_age=updated.age,
                    died_at=now,
                )
                messages.append(f"Life ended at age {updated.age} after a prison-violence event.")
        elif bool(profile["gang_protected"]):
            messages.append("Gang protection deterred random prison violence this year.")
        return updated, profile, messages

    async def _release(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        profile: dict[str, Any],
        *,
        juvenile: bool,
    ) -> tuple[Character, dict[str, Any]]:
        """Clear prison flags and record the release age for hiring recovery."""
        updated = replace(character, in_prison=False, prison_years_left=0)
        profile["last_release_age"] = updated.age
        profile["juvenile_release_age"] = None
        profile["gang_protected"] = 0
        profile["escaped"] = 0
        await self.repository.update_profile(
            tx,
            character.char_id,
            last_release_age=updated.age,
            juvenile_release_age=None,
            gang_protected=0,
            escaped=0,
        )
        if juvenile:
            profile["juvenile_release_age"] = None
        return updated, profile

    async def _apply_conviction(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
        crime: CrimeDefinition,
        profile: dict[str, Any],
        *,
        source: str,
        loot: int,
        now: int,
        sentence_override: Optional[int],
        life_override: bool,
        assess_fine: bool,
        create_trial: bool = True,
    ) -> tuple[Character, dict[str, Any], int, bool, bool, int]:
        """Apply conviction consequences, including juvenile record-sealing chance."""
        updated = character
        juvenile = character.age < 18
        record_sealed = juvenile and self.rng.random() < 0.50
        if not record_sealed:
            updated = replace(updated, criminal_record=max(0, updated.criminal_record + 1))
        sentence_years, life_sentence, juvenile_release_age = self._sentence(
            crime, character, sentence_override=sentence_override, life_override=life_override
        )
        if sentence_years > 0:
            custody_years = sentence_years
            if juvenile:
                custody_years = min(sentence_years, max(1, 18 - character.age))
                juvenile_release_age = min(18, character.age + custody_years)
            elif life_sentence:
                custody_years = max(1, 120 - character.age)
            updated = replace(updated, in_prison=True, prison_years_left=custody_years)
            if juvenile:
                await self.repository.update_profile(
                    tx, character.char_id, juvenile_release_age=juvenile_release_age
                )
            else:
                await self.repository.update_profile(tx, character.char_id, juvenile_release_age=None)
            fired = await self.repository.fire_job_for_prison(tx, character.char_id, character.age)
            if fired:
                await self.repository.insert_life_log(
                    tx, character.char_id, character.age, "career",
                    "Employment ended because of a prison sentence.", 4, now,
                )
            if updated.housing_type is HousingType.RENT:
                updated = replace(updated, housing_type=HousingType.HOMELESS, housing_item_id=None, rent_amount=0)

        profile = await self.repository.get_profile(tx, character.char_id)
        fine_paid = 0
        if assess_fine and loot > 0:
            target_fine = int((Decimal(loot) * Decimal("0.50")).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
            available_dirty = min(int(profile["dirty_cash"]), max(0, updated.cash))
            fine_paid = min(target_fine, available_dirty)
            if fine_paid:
                updated = replace(updated, cash=max(0, updated.cash - fine_paid))
                profile["dirty_cash"] = max(0, int(profile["dirty_cash"]) - fine_paid)
                await self.repository.update_profile(tx, character.char_id, dirty_cash=int(profile["dirty_cash"]))
                await self.repository.add_cashflow(tx, character.char_id, character.age, "fine", fine_paid, now)

        for relation in await self.repository.relationship_scores(tx, character.char_id):
            penalty = self.rng.randint(10, 30)
            await self.repository.set_relationship_score(
                tx,
                character.char_id,
                int(relation["npc_id"]),
                max(0, int(relation["score"]) - penalty),
            )
        if await self.repository.has_marriage(tx, character.char_id) and self.rng.random() < 0.25:
            divorce, updated = await self.family_service._divorce_in_tx(
                tx,
                updated,
                expected_version,
                reason="npc_initiated",
                now=now,
                save_character=False,
            )
            logger.info("Automatic spouse divorce after conviction for character %s", character.char_id)
        updated = replace(updated, version=expected_version + 1)
        return updated, profile, sentence_years, life_sentence, record_sealed, fine_paid

    def _sentence(
        self,
        crime: CrimeDefinition,
        character: Character,
        *,
        sentence_override: Optional[int],
        life_override: bool,
    ) -> tuple[int, bool, Optional[int]]:
        """Roll and country-scale a sentence, halving juvenile terms and capping release at 18."""
        if sentence_override is not None:
            base_years = max(0, int(sentence_override))
            life = bool(life_override)
        elif crime.sentence_max is None:
            lifetime_remaining = max(crime.sentence_min, 120 - character.age)
            base_years = self.rng.randint(crime.sentence_min, lifetime_remaining)
            life = base_years >= max(1, 120 - character.age)
        elif crime.sentence_min == crime.sentence_max:
            base_years = crime.sentence_min
            life = False
        else:
            base_years = self.rng.randint(crime.sentence_min, int(crime.sentence_max))
            life = False
        severity = self._severity(character.country)
        scaled = 0 if base_years == 0 else max(1, math.ceil(base_years * severity))
        scaled = min(scaled, max(0, 120 - character.age))
        juvenile_release_age: Optional[int] = None
        if character.age < 18 and scaled > 0:
            scaled = max(1, math.ceil(scaled / 2))
            juvenile_release_age = min(18, character.age + scaled)
        return scaled, life, juvenile_release_age

    def _loot_bounds(self, crime: CrimeDefinition, character: Character, salary: int) -> tuple[int, int]:
        """Scale catalog dollars or salary-linked loot into integer cents."""
        if crime.requires_job:
            minimum = scale_cents(
                salary,
                Decimal(str(crime.salary_loot_min_fraction * crime.salary_loot_multiplier))
                * Decimal(str(character.price_index)),
            )
            maximum = scale_cents(
                salary,
                Decimal(str(crime.salary_loot_max_fraction * crime.salary_loot_multiplier))
                * Decimal(str(character.price_index)),
            )
            return min(minimum, maximum), max(minimum, maximum)
        minimum = scale_cents(dollars_to_cents(crime.loot_min_dollars), Decimal(str(character.price_index)))
        maximum = scale_cents(dollars_to_cents(crime.loot_max_dollars), Decimal(str(character.price_index)))
        return min(minimum, maximum), max(minimum, maximum)

    async def _active_character(
        self,
        tx: aiosqlite.Connection,
        user_id: int,
    ) -> tuple[Character, int]:
        """Load an active living character and its concurrency version."""
        row = await self.repository.load_active(tx, user_id)
        if row is None:
            if await self.repository.has_any_life(tx, user_id):
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.char_id = int(row["char_id"])
        character.user_id = int(row["user_id"])
        character.version = int(row["version"])
        if not character.is_alive:
            raise CharacterDead()
        return character, int(row["version"])

    async def _active_character_read(self, user_id: int) -> Character:
        """Load the user's living character for a read-only game command."""
        row = await self.repository.load_active_read(user_id)
        if row is None:
            if await self.repository.has_any_life_read(user_id):
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.char_id = int(row["char_id"])
        character.user_id = int(row["user_id"])
        character.version = int(row["version"])
        if not character.is_alive:
            raise CharacterDead()
        return character

    async def _check_pending_event(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Keep unresolved Stage 3 choices ahead of crime actions."""
        if await self.repository.has_pending_event(tx, char_id):
            raise PendingEventExists()

    async def _check_no_trial_or_tax(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Prevent replacing a pending court or tax choice with another criminal action."""
        if await self.repository.other_pending_prompt(tx, char_id):
            raise PendingEventExists("Resolve the pending court or tax buttons before starting another crime action.")

    @staticmethod
    def _check_not_imprisoned(character: Character) -> None:
        """Enforce prison gates inside the engine."""
        if character.in_prison:
            raise CharacterInPrison()

    @staticmethod
    def _check_age(character: Character, minimum: int, action: str) -> None:
        """Enforce an age gate in the service rather than trusting slash-command UI."""
        if character.age < minimum:
            raise EducationRequirementError(f"You must be at least {minimum} to {action}.")

    def _severity(self, country: str) -> float:
        """Get a country-specific crime_severity_mod sentencing modifier, with an explicit neutral default."""
        return self.country_severity.get(country.lower(), self.country_severity["default"])

    @staticmethod
    def _career_level(notoriety: int) -> int:
        """Return the highest criminal-career tier unlocked by notoriety."""
        selected = 0
        for index, (_, threshold, _) in enumerate(CAREER_RANKS):
            if int(notoriety) >= threshold:
                selected = index
        return selected

    @staticmethod
    def _deduct_funds(character: Character, amount: int) -> tuple[Character, int]:
        """Deduct from cash then bank, keeping both nonnegative and returning unpaid cents."""
        remaining = max(0, int(amount))
        cash_paid = min(max(0, character.cash), remaining)
        remaining -= cash_paid
        bank_paid = min(max(0, character.bank), remaining)
        remaining -= bank_paid
        return replace(
            character,
            cash=max(0, character.cash - cash_paid),
            bank=max(0, character.bank - bank_paid),
        ), remaining

    def _preview_from_row(self, row: dict[str, Any]) -> CrimePreview:
        """Recreate the visible risk card from a persisted preview row."""
        catch = float(row["catch_chance"])
        crime = self._by_id.get(str(row["crime_id"]))
        name = crime.name if crime is not None else str(row["crime_id"]).replace("_", " ").title()
        description = crime.description if crime is not None else "A pending crime confirmation."
        return CrimePreview(
            str(row["crime_id"]), name, description, int(row["age"]), str(row["nonce"]),
            float(row["success_chance"]), catch, clamp_chance(catch * 1.5),
            int(row["loot_min"]), int(row["loot_max"]), int(row["expires_at"]),
        )

    def _trial_from_row(self, row: Optional[dict[str, Any]]) -> Optional[TrialPrompt]:
        """Map a stored trial record to its command-view model."""
        if row is None:
            return None
        crime = self._by_id.get(str(row["crime_id"]))
        name = crime.name if crime is not None else str(row["crime_id"]).replace("_", " ").title()
        return TrialPrompt(
            str(row["nonce"]), int(row["attempt_id"]), str(row["crime_id"]), name,
            int(row["age"]), str(row["source"]),
        )

    @staticmethod
    def _tax_prompt_from_row(row: dict[str, Any]) -> TaxEvasionPrompt:
        """Map a stored tax choice row into a typed view model."""
        return TaxEvasionPrompt(
            str(row["nonce"]), int(row["age"]), int(row["tax_due"]),
            int(row.get("paid_amount", 0)), bool(row["prepaid"]),
        )
````

## `lifeline/core/data_loader.py`

````python
"""JSON game-data loading with schema validation and modification-time caching."""
from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any, Callable, Optional

from .validators import (
    validate_career_catalog,
    validate_crime_catalog,
    validate_event_catalog,
    validate_item_catalog,
)


Validator = Callable[[Any], Any]


class DataLoader:
    """Load validated JSON files from the bot's ``data`` directory."""

    def __init__(self, data_dir: str | Path | None = None):
        self.data_dir = Path(data_dir) if data_dir is not None else Path(__file__).parent.parent / "data"
        self._cache: dict[str, tuple[int, Any]] = {}

    def load_json(self, filename: str, validator: Optional[Validator] = None) -> Any:
        """Read and validate a JSON file; cached copies are returned defensively."""
        if Path(filename).name != filename or not filename.endswith(".json"):
            raise ValueError("Game data filenames must be simple .json filenames")
        path = self.data_dir / filename
        try:
            modified_at = path.stat().st_mtime_ns
        except FileNotFoundError as exc:
            raise FileNotFoundError(f"Required game data file not found: {path}") from exc

        cached = self._cache.get(filename)
        if cached and cached[0] == modified_at:
            return copy.deepcopy(cached[1])

        try:
            with path.open("r", encoding="utf-8") as handle:
                document = json.load(handle)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON in {path} at line {exc.lineno}, column {exc.colno}: {exc.msg}") from exc

        validated = validator(document) if validator is not None else document
        self._cache[filename] = (modified_at, copy.deepcopy(validated))
        return copy.deepcopy(validated)

    def load_events(self) -> dict[str, Any]:
        """Load the validated life-event catalog."""
        return self.load_json("events.json", validate_event_catalog)

    def load_careers(self) -> dict[str, Any]:
        """Load the validated career catalog."""
        return self.load_json("careers.json", validate_career_catalog)

    def load_crimes(self) -> dict[str, Any]:
        """Load the fully validated crime and country-sentencing catalog."""
        return self.load_json("crimes.json", validate_crime_catalog)

    def load_items(self) -> dict[str, Any]:
        """Load the strictly validated Stage 8 shop and inventory catalog."""
        return self.load_json("items.json", validate_item_catalog)
````

## `lifeline/core/errors.py`

````python
"""User-safe domain exceptions for LIFELINE game operations."""
from __future__ import annotations


class GameError(Exception):
    """Expected game-rule error whose message is safe to show to a player."""

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message


class ValidationError(GameError):
    """An input value does not satisfy game rules."""


class CharacterNotFound(GameError):
    def __init__(self, message: str = "You do not have a life yet. Start one with `/life start`."):
        super().__init__(message)


class CharacterAlreadyExists(GameError):
    def __init__(self, message: str = "You already have an active life. Use `/life status` to view it."):
        super().__init__(message)


class CharacterDead(GameError):
    def __init__(self, message: str = "This life has ended. Start a new one to continue playing."):
        super().__init__(message)


class CharacterBusy(GameError):
    def __init__(self, message: str = "Your character is already processing an action. Try again in a moment."):
        super().__init__(message)


class ConcurrentUpdate(GameError):
    def __init__(self, message: str = "Your life changed while this action was processing. Please try again."):
        super().__init__(message)


class PendingEventExists(GameError):
    def __init__(self, message: str = "Resolve your pending life event with `/life choice` before aging again."):
        super().__init__(message)


class PendingEventNotFound(GameError):
    def __init__(self, message: str = "You have no pending life event. Use `/life age` to continue your story."):
        super().__init__(message)


class StaleEvent(GameError):
    def __init__(self, message: str = "This choice has already been resolved or is no longer available. Use `/life choice` to check for another event."):
        super().__init__(message)


class NotEnrolled(GameError):
    def __init__(self, message: str = "You are not currently enrolled. Check `/education status` for options."):
        super().__init__(message)


class StudyAlreadyUsed(GameError):
    def __init__(self, message: str = "You have already studied this year. You can study again after `/life age`."):
        super().__init__(message)


class EducationRequirementError(GameError):
    def __init__(self, message: str):
        super().__init__(message)


class JobAlreadyExists(GameError):
    def __init__(self, message: str = "You already have a job. Use `/career status` or `/career quit` first."):
        super().__init__(message)


class NoActiveJob(GameError):
    def __init__(self, message: str = "You do not have a job right now. Use `/career list` to explore careers."):
        super().__init__(message)


class WorkAlreadyUsed(GameError):
    def __init__(self, message: str = "You have already worked this in-game year. Work again after `/life age`."):
        super().__init__(message)


class RetiredCharacter(GameError):
    def __init__(self, message: str = "You are retired and cannot take a new job."):
        super().__init__(message)


class FamilyRequirementError(GameError):
    """A family or relationship action is not permitted by current life state."""


class RelationshipNotFound(GameError):
    def __init__(self, message: str = "That person is not in your relationship list."):
        super().__init__(message)


class InteractionLimitReached(GameError):
    def __init__(self, message: str = "You have used all three interactions with this person this year."):
        super().__init__(message)


class InsufficientFunds(GameError):
    def __init__(self, message: str = "You do not have enough available funds for that action."):
        super().__init__(message)


class DateSessionExpired(GameError):
    def __init__(self, message: str = "These date options expired. Use `/date find` to meet new people."):
        super().__init__(message)


class NoActiveMarriage(GameError):
    def __init__(self, message: str = "You are not currently married."):
        super().__init__(message)


class CharacterInPrison(GameError):
    """A command is unavailable while the active character is incarcerated."""

    def __init__(self, message: str = "This action is unavailable while your character is in prison."):
        super().__init__(message)


class CharacterNotInPrison(GameError):
    """A prison-only action was requested by a character outside custody."""

    def __init__(self, message: str = "Your character is not currently in prison."):
        super().__init__(message)


class CrimeLimitReached(GameError):
    """The character has used both crime attempts available this in-game year."""

    def __init__(self, message: str = "You have already attempted two crimes this in-game year."):
        super().__init__(message)


class CrimeSessionExpired(GameError):
    """A risk-confirmation nonce expired or was already consumed."""

    def __init__(self, message: str = "This crime confirmation expired. Use `/crime commit` to review the risk again."):
        super().__init__(message)


class TrialNotFound(GameError):
    """No owner-matched criminal trial is waiting for a lawyer choice."""

    def __init__(self, message: str = "There is no pending trial for this life. Use `/crime record` to review your record."):
        super().__init__(message)


class TaxDecisionNotFound(GameError):
    """No owner-matched high-earner tax decision is waiting for a choice."""

    def __init__(self, message: str = "There is no pending tax decision for this life."):
        super().__init__(message)


class CrimeActionAlreadyUsed(GameError):
    """A prisoner already used their one prison action for this in-game year."""

    def __init__(self, message: str = "You have already taken a prison action this year."):
        super().__init__(message)


class CareerApplicationRejected(GameError):
    """A criminal-record hiring roll did not result in a job offer."""

    def __init__(self, message: str = "Your application was declined after the employer's background check."):
        super().__init__(message)


class StaleShopQuote(GameError):
    """A shop confirmation no longer matches current prices or balances."""

    def __init__(self, message: str = "Your price or balance changed. Please retry the shop purchase."):
        super().__init__(message)


class TradeNotFound(GameError):
    """A trade identifier is missing or does not belong to the requesting player."""

    def __init__(self, message: str = "That trade is unavailable or does not belong to you."):
        super().__init__(message)


class TradeExpired(GameError):
    """A trade proposal is no longer pending or its ten-minute window elapsed."""

    def __init__(self, message: str = "That trade is no longer pending. Use `/trade list` to review its status."):
        super().__init__(message)
````

## `lifeline/core/life_engine.py`

````python
"""Birth creation, stat rolls, and one-year life simulation."""
from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass, replace
from typing import Any, Callable, Optional

import aiosqlite

from .careers import CareerService
from .crime import CrimeService, TaxEvasionPrompt, TrialPrompt
from .config import GameBalance
from .education import advance_school_year
from .family import FamilyService
from .errors import (
    CharacterAlreadyExists,
    CharacterDead,
    CharacterNotFound,
    ConcurrentUpdate,
    PendingEventExists,
    ValidationError,
)
from .events import EventEngine, EventPrompt
from .locks import UserLockRegistry
from .models import Character, Gender, HiddenTraits, LifeStage, Stats
from .rng import RNG
from .shop import ShopService

logger = logging.getLogger("lifeline.life")
_NAME_RE = re.compile(r"[^\x00-\x1f\x7f]+")


@dataclass(frozen=True, slots=True)
class YearOutcome:
    """Result of applying one simulated year to a character."""

    character: Character
    previous_age: int
    new_age: int
    died: bool
    death_cause: Optional[str]
    stat_changes: dict[str, int]
    previous_stage: LifeStage
    new_stage: LifeStage
    log_messages: tuple[str, ...]
    pending_event: Optional[EventPrompt] = None
    pending_trial: Optional[TrialPrompt] = None
    pending_tax: Optional[TaxEvasionPrompt] = None


def _clamp_stat(value: int | float) -> int:
    return max(GameBalance.STAT_MIN, min(GameBalance.STAT_MAX, int(round(value))))


def _random_stat(rng: RNG, mean: float, stddev: float) -> int:
    return _clamp_stat(rng.gauss(mean, stddev))


def roll_birth_attributes(rng: RNG) -> tuple[Stats, HiddenTraits, str]:
    """Roll reproducible starting stats, hidden traits, and household wealth class."""
    hidden = HiddenTraits(
        genetic_health_mod=rng.randint(-10, 10),
        lifespan_mod=rng.randint(*GameBalance.LIFESPAN_MOD_RANGE),
        luck=rng.randint(-5, 5),
        temperament=rng.weighted_choice(
            ("calm", "neutral", "volatile"),
            (0.25, 0.55, 0.20),
        ),
    )
    wealth_class = rng.weighted_choice(
        tuple(GameBalance.WEALTH_CLASSES),
        tuple(GameBalance.WEALTH_CLASSES.values()),
    )
    stats = Stats(
        health=_clamp_stat(
            _random_stat(rng, GameBalance.HEALTH_INIT_MEAN, GameBalance.HEALTH_INIT_STDDEV)
            + hidden.genetic_health_mod
        ),
        happiness=_random_stat(rng, GameBalance.HAPPINESS_INIT_MEAN, GameBalance.HAPPINESS_INIT_STDDEV),
        smarts=_random_stat(rng, GameBalance.SMARTS_INIT_MEAN, GameBalance.SMARTS_INIT_STDDEV),
        looks=_random_stat(rng, GameBalance.LOOKS_INIT_MEAN, GameBalance.LOOKS_INIT_STDDEV),
        fitness=_random_stat(rng, GameBalance.FITNESS_INIT_MEAN, GameBalance.FITNESS_INIT_STDDEV),
        karma=_clamp_stat(50 + rng.randint(-10, 10)),
        stress=GameBalance.BASE_STRESS,
        addiction=0,
        fame=0,
        credit_score=None,
    ).clamp_all()
    return stats, hidden, wealth_class


def simulate_year(character: Character, rng: RNG, *, now: Optional[int] = None) -> YearOutcome:
    """Purely calculate one year's aging effects without writing to a database.

    Each call advances exactly one year. Stats remain within 0–100 and a character
    is guaranteed to die no later than ``GameBalance.MAX_AGE``.
    """
    if not character.is_alive:
        raise CharacterDead()
    if character.age < 0:
        raise ValidationError("Character age cannot be negative.")
    if character.age >= GameBalance.MAX_AGE:
        raise CharacterDead("This life has reached the maximum age and has ended.")

    old_age = character.age
    new_age = old_age + 1
    old_stage = character.life_stage
    stats = replace(character.stats)
    before = stats.to_dict()

    # Health varies slightly year to year; age and inherited resilience shape the drift.
    health_delta = rng.randint(-1, 1)
    if new_age >= 50:
        health_delta -= 1
    if new_age >= 70:
        health_delta -= 1
    if character.hidden.genetic_health_mod >= 7 and new_age < 70:
        health_delta += 1
    elif character.hidden.genetic_health_mod <= -7:
        health_delta -= 1
    stats.health = _clamp_stat(stats.health + health_delta)

    # Happiness trends gently toward the game's neutral point; stress recovers naturally.
    target = GameBalance.HAPPINESS_DRIFT_TARGET
    if stats.happiness < target:
        stats.happiness += GameBalance.HAPPINESS_DRIFT_RATE
    elif stats.happiness > target:
        stats.happiness -= GameBalance.HAPPINESS_DRIFT_RATE
    stats.stress = max(0, stats.stress - GameBalance.STRESS_DECAY_PER_YEAR)

    # Childhood and young adulthood build learning and fitness; aging slowly reduces fitness.
    if 6 <= new_age <= 29 and rng.random() < 0.55:
        stats.smarts += 1
    if new_age <= 25 and rng.random() < 0.35:
        stats.fitness += 1
    elif new_age >= 40:
        stats.fitness -= 1
    if new_age >= 70:
        stats.fitness -= 1
    if new_age >= 35 and new_age % 5 == 0:
        stats.looks -= 1

    stats = stats.clamp_all()
    death_cause: Optional[str] = None

    # A low-health character is at higher risk. The hazard rises after expected lifespan.
    expected_lifespan = (
        GameBalance.BASE_LIFESPAN_MEAN
        + character.hidden.lifespan_mod
        + round(character.hidden.genetic_health_mod * 0.25)
    )
    age_hazard = 0.001 + max(0, new_age - 55) * 0.00035
    lifespan_hazard = max(0, new_age - expected_lifespan) * 0.018
    health_multiplier = max(0.55, min(1.8, 1.0 + (50 - stats.health) * 0.012))
    mortality_chance = min(0.95, (age_hazard + lifespan_hazard) * health_multiplier)
    if stats.health <= 0:
        death_cause = "illness"
    elif new_age >= GameBalance.MAX_AGE or rng.random() < mortality_chance:
        death_cause = "natural causes"

    timestamp = int(time.time()) if now is None else int(now)
    updated = replace(
        character,
        age=new_age,
        stats=stats,
        is_alive=death_cause is None,
        died_at=timestamp if death_cause else None,
        death_cause=death_cause,
        death_age=new_age if death_cause else None,
        last_age_at=timestamp,
    )
    new_stage = updated.life_stage
    changes = {
        key: int(stats.to_dict()[key] - before[key])
        for key in stats.to_dict()
        if stats.to_dict()[key] != before[key]
    }

    messages = [f"{updated.name or 'Your character'} turned {new_age}."]
    if new_stage != old_stage:
        messages.append(f"Entered the {new_stage.value.replace('_', ' ')} stage of life.")
    if death_cause:
        messages.append(f"Life ended at age {new_age} from {death_cause}.")

    return YearOutcome(
        character=updated,
        previous_age=old_age,
        new_age=new_age,
        died=death_cause is not None,
        death_cause=death_cause,
        stat_changes=changes,
        previous_stage=old_stage,
        new_stage=new_stage,
        log_messages=tuple(messages),
    )


class LifeEngine:
    """Persistence-backed API for creating, viewing, and aging a user's life."""

    def __init__(
        self,
        db: Any,
        rng: RNG,
        locks: Optional[UserLockRegistry] = None,
        clock: Callable[[], float] = time.time,
        event_engine: Optional[EventEngine] = None,
        event_chance: Optional[float] = None,
        career_service: Optional[CareerService] = None,
        family_service: Optional[FamilyService] = None,
        crime_service: Optional[CrimeService] = None,
        shop_service: Optional[ShopService] = None,
    ) -> None:
        self.db = db
        self.rng = rng
        self.locks = locks or UserLockRegistry()
        self.clock = clock
        self.events = event_engine or EventEngine(
            db,
            rng,
            self.locks,
            event_chance=event_chance,
        )
        self.careers = career_service or CareerService(db, rng, self.locks, clock=clock)
        self.family = family_service or FamilyService(db, rng, self.locks, clock=clock)
        self.crimes = crime_service or CrimeService(
            db, rng, self.locks, family_service=self.family, clock=clock
        )
        self.shop = shop_service or ShopService(db, rng, self.locks, clock=clock)

    async def create_character(
        self,
        user_id: int,
        name: str,
        *,
        gender: Gender | str = Gender.MALE,
        country: str = "usa",
        parent_char_id: Optional[int] = None,
    ) -> Character:
        """Create one active life for a Discord user, starting at age zero."""
        if not isinstance(user_id, int) or user_id <= 0:
            raise ValidationError("A valid Discord user ID is required.")
        clean_name = self._validate_name(name)
        clean_country = self._validate_country(country)
        try:
            clean_gender = gender if isinstance(gender, Gender) else Gender(str(gender).lower())
        except ValueError as exc:
            raise ValidationError("Choose male, female, or non-binary.") from exc

        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                cursor = await tx.execute(
                    "SELECT char_id FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
                    (user_id,),
                )
                if await cursor.fetchone():
                    raise CharacterAlreadyExists()

                generation = 1
                if parent_char_id is not None:
                    cursor = await tx.execute(
                        "SELECT data_json FROM characters WHERE char_id = ?",
                        (parent_char_id,),
                    )
                    parent_row = await cursor.fetchone()
                    if parent_row is None:
                        raise ValidationError("The selected parent life could not be found.")
                    parent = Character.from_dict(json.loads(parent_row["data_json"]))
                    generation = parent.generation + 1

                stats, hidden, wealth_class = roll_birth_attributes(self.rng)
                now = int(self.clock())
                character = Character(
                    user_id=user_id,
                    name=clean_name,
                    gender=clean_gender,
                    country=clean_country,
                    wealth_class=wealth_class,
                    age=0,
                    stats=stats,
                    hidden=hidden,
                    cash=0,
                    bank=0,
                    debt_total=0,
                    parent_char_id=parent_char_id,
                    generation=generation,
                    last_age_at=now,
                    born_at=now,
                )
                cursor = await tx.execute(
                    """INSERT INTO characters (
                           user_id, is_alive, name, gender, country, wealth_class, age,
                           stats_json, hidden_json, version, last_age_at, born_at,
                           died_at, death_cause, death_age, data_json
                       ) VALUES (?, 1, ?, ?, ?, ?, 0, ?, ?, 0, ?, ?, NULL, NULL, NULL, ?)""",
                    self._row_values(character),
                )
                char_id = int(cursor.lastrowid)
                character = replace(character, char_id=char_id)
                await self._refresh_data_json(tx, character)
                await self.family.initialize_family(tx, character)
                await self.crimes.initialize_character(tx, character)
                await self._insert_log(
                    tx,
                    character,
                    age=0,
                    category="birth",
                    text=f"{clean_name} was born into a {wealth_class} household.",
                    importance=3,
                    created_at=now,
                )
                return character

    async def get_active_character(self, user_id: int) -> Character:
        """Return a user's active character or raise ``CharacterNotFound``."""
        row = await self.db.fetchone(
            "SELECT data_json FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        if row is None:
            latest = await self.db.fetchone(
                "SELECT data_json FROM characters WHERE user_id = ? ORDER BY char_id DESC LIMIT 1",
                (user_id,),
            )
            if latest is not None:
                raise CharacterDead()
            raise CharacterNotFound()
        return Character.from_dict(json.loads(row["data_json"]))

    async def age_up(self, user_id: int) -> YearOutcome:
        """Advance the active life by one year as one serialized DB transaction."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                cursor = await tx.execute(
                    "SELECT data_json, version FROM characters "
                    "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
                    (user_id,),
                )
                row = await cursor.fetchone()
                if row is None:
                    # Distinguish a completed life from a user who never started.
                    cursor = await tx.execute(
                        "SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,)
                    )
                    if await cursor.fetchone():
                        raise CharacterDead()
                    raise CharacterNotFound()

                character = Character.from_dict(json.loads(row["data_json"]))
                # A pending choice must be resolved before the next simulated year.
                cursor = await tx.execute(
                    "SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1",
                    (character.char_id,),
                )
                if await cursor.fetchone():
                    raise PendingEventExists()
                await self.crimes.ensure_no_pending_decision(tx, character.char_id)

                # Keep the database version authoritative if a caller's JSON was stale.
                character.version = int(row["version"])
                timestamp = int(self.clock())
                outcome = simulate_year(character, self.rng, now=timestamp)
                school_progress = advance_school_year(outcome.character)
                career_progress = await self.careers.advance_year(
                    tx,
                    school_progress.character,
                    previous_age=outcome.previous_age,
                    now=timestamp,
                )
                shop_progress = await self.shop.advance_year(
                    tx,
                    career_progress.character,
                    now=timestamp,
                )
                career_income = max(0, career_progress.character.cash - school_progress.character.cash)
                personal_income = career_income + shop_progress.business_income
                family_progress = await self.family.advance_year(
                    tx,
                    shop_progress.character,
                    previous_age=outcome.previous_age,
                    personal_income=personal_income,
                    now=timestamp,
                )
                crime_progress = await self.crimes.advance_year(
                    tx,
                    family_progress.character,
                    previous_age=outcome.previous_age,
                    personal_income=personal_income,
                    household_income=family_progress.household_income,
                    tax_assessed=family_progress.tax_assessed,
                    tax_paid=family_progress.tax_paid,
                    now=timestamp,
                )
                updated = replace(crime_progress.character, version=character.version + 1)
                all_messages = (
                    outcome.log_messages
                    + school_progress.messages
                    + career_progress.messages
                    + shop_progress.messages
                    + family_progress.messages
                    + crime_progress.messages
                )
                outcome = replace(outcome, character=updated, log_messages=all_messages)
                await self._save_character(tx, updated, expected_version=character.version)

                for message in outcome.log_messages:
                    if message.startswith("Life ended at age"):
                        category, importance = "death", 5
                    elif message in school_progress.messages:
                        category, importance = "education", 3
                    elif message in career_progress.messages:
                        category, importance = "career", 2
                    elif message in shop_progress.messages:
                        category, importance = "economy", 2
                    elif message in family_progress.messages:
                        category, importance = "family", 2
                    elif message in crime_progress.messages:
                        category, importance = ("prison" if "prison" in message.lower() else "crime"), 3
                    else:
                        category = "aging"
                        importance = 3 if "stage of life" in message else 1
                    await self._insert_log(
                        tx,
                        updated,
                        age=updated.age,
                        category=category,
                        text=message,
                        importance=importance,
                        created_at=timestamp,
                    )

                pending_event = None
                has_stage7_prompt = crime_progress.pending_trial is not None or crime_progress.pending_tax is not None
                if updated.is_alive and not updated.in_prison and not has_stage7_prompt:
                    pending_event = await self.events.maybe_create_pending(
                        tx,
                        updated,
                        now=timestamp,
                    )
                    if pending_event is not None:
                        await self._insert_log(
                            tx,
                            updated,
                            age=updated.age,
                            category="event",
                            text=f"A choice event began: {pending_event.event.title}.",
                            importance=2,
                            created_at=timestamp,
                        )

                return replace(
                    outcome,
                    character=updated,
                    pending_event=pending_event,
                    pending_trial=crime_progress.pending_trial,
                    pending_tax=crime_progress.pending_tax,
                )

    @staticmethod
    def _validate_name(name: str) -> str:
        if not isinstance(name, str):
            raise ValidationError("Enter a character name.")
        clean = " ".join(name.split()).strip()
        if not clean or len(clean) > 32 or not _NAME_RE.fullmatch(clean):
            raise ValidationError("Name must be 1–32 characters and contain no control characters.")
        return clean

    @staticmethod
    def _validate_country(country: str) -> str:
        if not isinstance(country, str):
            raise ValidationError("Enter a country or region code.")
        clean = " ".join(country.split()).strip().lower()
        if not clean or len(clean) > 40 or not _NAME_RE.fullmatch(clean):
            raise ValidationError("Country or region must be 1–40 characters.")
        return clean

    @staticmethod
    def _row_values(character: Character) -> tuple[Any, ...]:
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        hidden_json = json.dumps({
            "genetic_health_mod": character.hidden.genetic_health_mod,
            "lifespan_mod": character.hidden.lifespan_mod,
            "luck": character.hidden.luck,
            "temperament": character.hidden.temperament,
        }, separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        return (
            character.user_id,
            character.name,
            character.gender.value,
            character.country,
            character.wealth_class,
            stats_json,
            hidden_json,
            character.last_age_at,
            character.born_at,
            data_json,
        )

    async def _refresh_data_json(self, tx: aiosqlite.Connection, character: Character) -> None:
        """Persist a newly assigned ID to the JSON snapshot."""
        await tx.execute(
            "UPDATE characters SET data_json = ? WHERE char_id = ?",
            (json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False), character.char_id),
        )

    async def _save_character(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        expected_version: int,
    ) -> None:
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        hidden_json = json.dumps({
            "genetic_health_mod": character.hidden.genetic_health_mod,
            "lifespan_mod": character.hidden.lifespan_mod,
            "luck": character.hidden.luck,
            "temperament": character.hidden.temperament,
        }, separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET
                   is_alive = ?, name = ?, gender = ?, country = ?, wealth_class = ?, age = ?,
                   stats_json = ?, hidden_json = ?, version = ?, last_age_at = ?,
                   died_at = ?, death_cause = ?, death_age = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (
                int(character.is_alive), character.name, character.gender.value,
                character.country, character.wealth_class, character.age,
                stats_json, hidden_json, character.version, character.last_age_at,
                character.died_at, character.death_cause, character.death_age,
                data_json, character.char_id, expected_version,
            ),
        )
        if cursor.rowcount != 1:
            raise ConcurrentUpdate()

    @staticmethod
    async def _insert_log(
        tx: aiosqlite.Connection,
        character: Character,
        *,
        age: int,
        category: str,
        text: str,
        importance: int,
        created_at: int,
    ) -> None:
        await tx.execute(
            """INSERT INTO life_logs (char_id, age, category, text, importance, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (character.char_id, age, category, text, importance, created_at),
        )
````

## `lifeline/core/migrations/007_shop_inventory_trading.sql`

````sql
-- Stage 8: player accounts, item inventory locks, collateral links, and atomic trades.
ALTER TABLE family_assets
    ADD COLUMN is_locked INTEGER NOT NULL DEFAULT 0 CHECK (is_locked IN (0, 1));

ALTER TABLE loans
    ADD COLUMN principal INTEGER NOT NULL DEFAULT 0 CHECK (principal >= 0);
ALTER TABLE loans
    ADD COLUMN annual_rate REAL NOT NULL DEFAULT 0 CHECK (annual_rate BETWEEN 0 AND 1);
ALTER TABLE loans
    ADD COLUMN term_years INTEGER NOT NULL DEFAULT 0 CHECK (term_years >= 0);
ALTER TABLE loans
    ADD COLUMN years_remaining INTEGER NOT NULL DEFAULT 0 CHECK (years_remaining >= 0);
ALTER TABLE loans
    ADD COLUMN collateral_item_uid INTEGER REFERENCES family_assets(asset_id);

CREATE TABLE IF NOT EXISTS shop_quotes (
    char_id             INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    nonce               TEXT NOT NULL UNIQUE,
    item_id             TEXT NOT NULL,
    quantity            INTEGER NOT NULL CHECK (quantity > 0),
    total_price         INTEGER NOT NULL CHECK (total_price >= 0),
    balance_cents       INTEGER NOT NULL CHECK (balance_cents >= 0),
    character_version   INTEGER NOT NULL CHECK (character_version >= 0),
    created_at          INTEGER NOT NULL CHECK (created_at >= 0),
    expires_at          INTEGER NOT NULL CHECK (expires_at >= created_at)
);

CREATE TABLE IF NOT EXISTS players (
    user_id       INTEGER PRIMARY KEY CHECK (user_id > 0),
    created_at    INTEGER NOT NULL CHECK (created_at >= 0),
    trade_banned  INTEGER NOT NULL DEFAULT 0 CHECK (trade_banned IN (0, 1))
);

CREATE TABLE IF NOT EXISTS trades (
    trade_id               INTEGER PRIMARY KEY AUTOINCREMENT,
    from_user_id           INTEGER NOT NULL REFERENCES players(user_id),
    from_char_id           INTEGER NOT NULL REFERENCES characters(char_id),
    to_user_id             INTEGER NOT NULL REFERENCES players(user_id),
    to_char_id             INTEGER NOT NULL REFERENCES characters(char_id),
    offer_cash             INTEGER NOT NULL DEFAULT 0 CHECK (offer_cash >= 0),
    request_cash           INTEGER NOT NULL DEFAULT 0 CHECK (request_cash >= 0),
    status                 TEXT NOT NULL DEFAULT 'pending'
                           CHECK (status IN ('pending', 'accepted', 'declined', 'cancelled', 'expired', 'failed')),
    created_at             INTEGER NOT NULL CHECK (created_at >= 0),
    expires_at             INTEGER NOT NULL CHECK (expires_at >= created_at),
    resolved_at            INTEGER,
    nonce                  TEXT NOT NULL UNIQUE,
    imbalance_flag         INTEGER NOT NULL DEFAULT 0 CHECK (imbalance_flag IN (0, 1)),
    imbalance_receiver_id  INTEGER,
    outcome_message        TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_trades_from_user_status ON trades(from_user_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_trades_to_user_status ON trades(to_user_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_trades_expiry ON trades(status, expires_at);
CREATE UNIQUE INDEX IF NOT EXISTS idx_trades_one_pending_outgoing
    ON trades(from_user_id) WHERE status = 'pending';

CREATE TABLE IF NOT EXISTS trade_items (
    trade_item_id  INTEGER PRIMARY KEY AUTOINCREMENT,
    trade_id       INTEGER NOT NULL REFERENCES trades(trade_id) ON DELETE CASCADE,
    side           TEXT NOT NULL CHECK (side IN ('offer', 'request')),
    item_uid       INTEGER NOT NULL,
    item_id        TEXT NOT NULL,
    quantity       INTEGER NOT NULL CHECK (quantity > 0),
    value_snapshot INTEGER NOT NULL CHECK (value_snapshot >= 0),
    UNIQUE(trade_id, side, item_uid)
);
CREATE INDEX IF NOT EXISTS idx_trade_items_trade_side ON trade_items(trade_id, side, item_uid);

CREATE TABLE IF NOT EXISTS trade_daily_usage (
    user_id   INTEGER NOT NULL REFERENCES players(user_id),
    day_key   TEXT NOT NULL,
    trades    INTEGER NOT NULL DEFAULT 0 CHECK (trades BETWEEN 0 AND 5),
    PRIMARY KEY(user_id, day_key)
);

CREATE TABLE IF NOT EXISTS inventory_uses (
    asset_id  INTEGER NOT NULL REFERENCES family_assets(asset_id) ON DELETE CASCADE,
    age       INTEGER NOT NULL CHECK (age >= 0),
    used_at   INTEGER NOT NULL CHECK (used_at >= 0),
    PRIMARY KEY(asset_id, age)
);

CREATE TABLE IF NOT EXISTS audit_log (
    audit_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    ts           INTEGER NOT NULL CHECK (ts >= 0),
    user_id      INTEGER,
    char_id      INTEGER,
    action       TEXT NOT NULL,
    amount       INTEGER CHECK (amount IS NULL OR amount >= 0),
    details_json TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_audit_log_character_time ON audit_log(char_id, ts DESC);
````

## `lifeline/core/repositories/crime.py`

````python
"""Parameterized repository for Stage 7 crime, trial, tax, and prison data."""
from __future__ import annotations

import json
from typing import Any, Optional

import aiosqlite

from ..models import Character


class CrimeRepository:
    """Keep all Stage 7 SQL and transactional row mapping in one repository."""

    def __init__(self, db: Any) -> None:
        self.db = db

    @staticmethod
    async def _one(tx: aiosqlite.Connection, query: str, params: tuple[Any, ...] = ()) -> Any:
        cursor = await tx.execute(query, params)
        return await cursor.fetchone()

    @staticmethod
    async def _all(tx: aiosqlite.Connection, query: str, params: tuple[Any, ...] = ()) -> list[Any]:
        cursor = await tx.execute(query, params)
        return await cursor.fetchall()

    async def load_active(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Load the active life and optimistic version for an action transaction."""
        row = await self._one(
            tx,
            "SELECT char_id, user_id, data_json, version FROM characters "
            "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def load_active_read(self, user_id: int) -> Optional[dict[str, Any]]:
        """Read a user's active character without opening a write transaction."""
        row = await self.db.fetchone(
            "SELECT char_id, user_id, data_json, version FROM characters "
            "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def has_any_life(self, tx: aiosqlite.Connection, user_id: int) -> bool:
        """Check if a user has a historical life but no active character."""
        return await self._one(tx, "SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,)) is not None

    async def has_pending_event(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check for unresolved Stage 3 events before a new criminal decision."""
        return await self._one(tx, "SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1", (char_id,)) is not None

    async def insert_life_log(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        age: int,
        category: str,
        text: str,
        importance: int,
        now: int,
    ) -> None:
        """Append a parameterized message to the shared life journal."""
        await tx.execute(
            """INSERT INTO life_logs(char_id, age, category, text, importance, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (char_id, age, category, text, importance, now),
        )

    async def has_any_life_read(self, user_id: int) -> bool:
        """Read whether a user has a historical character."""
        return await self.db.fetchone("SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,)) is not None

    async def save_character(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
    ) -> None:
        """Persist a changed character snapshot with optimistic concurrency protection."""
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET stats_json = ?, version = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (stats_json, character.version, data_json, character.char_id, expected_version),
        )
        if cursor.rowcount != 1:
            from ..errors import ConcurrentUpdate
            raise ConcurrentUpdate()

    async def initialize_profile(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Create the default criminal profile once for a new or legacy character."""
        await tx.execute("INSERT OR IGNORE INTO crime_profiles(char_id) VALUES (?)", (char_id,))

    async def get_profile(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Any]:
        """Return a profile, initializing it if this is a pre-Stage-7 life."""
        await self.initialize_profile(tx, char_id)
        row = await self._one(tx, "SELECT * FROM crime_profiles WHERE char_id = ?", (char_id,))
        if row is None:
            raise RuntimeError("criminal profile could not be initialized")
        return dict(row)

    async def update_profile(self, tx: aiosqlite.Connection, char_id: int, **fields: Any) -> None:
        """Update a fixed allowlist of criminal-profile columns with bound values."""
        allowed = {
            "dirty_cash", "career_rank", "career_years", "career_level", "last_crime_id",
            "evaded_tax", "gang_protected", "escaped", "juvenile_release_age",
            "last_release_age", "front_business",
        }
        if not fields or set(fields) - allowed:
            raise ValueError("criminal profile update contains no fields or an unsupported field")
        assignments = ", ".join(f"{column} = ?" for column in fields)
        await tx.execute(
            f"UPDATE crime_profiles SET {assignments} WHERE char_id = ?",
            (*fields.values(), char_id),
        )

    async def save_preview(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        crime_id: str,
        age: int,
        nonce: str,
        success_chance: float,
        catch_chance: float,
        loot_min: int,
        loot_max: int,
        salary_snapshot: int,
        created_at: int,
        expires_at: int,
    ) -> None:
        """Replace an unconfirmed risk preview for this character."""
        await tx.execute("DELETE FROM crime_previews WHERE char_id = ?", (char_id,))
        await tx.execute(
            """INSERT INTO crime_previews
                   (char_id, crime_id, age, nonce, success_chance, catch_chance,
                    loot_min, loot_max, salary_snapshot, created_at, expires_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, crime_id, age, nonce, success_chance, catch_chance,
             loot_min, loot_max, salary_snapshot, created_at, expires_at),
        )

    async def get_preview(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        nonce: str,
        now: int,
    ) -> Optional[dict[str, Any]]:
        """Fetch a live preview only for its owner and unexpired nonce."""
        row = await self._one(
            tx,
            "SELECT * FROM crime_previews WHERE char_id = ? AND nonce = ? AND expires_at >= ? LIMIT 1",
            (char_id, nonce, now),
        )
        return dict(row) if row is not None else None

    async def delete_preview(self, tx: aiosqlite.Connection, char_id: int, nonce: str) -> None:
        """Consume a crime preview after confirmation or cancellation."""
        await tx.execute("DELETE FROM crime_previews WHERE char_id = ? AND nonce = ?", (char_id, nonce))

    async def cancel_preview(self, tx: aiosqlite.Connection, char_id: int, nonce: str) -> bool:
        """Remove the exact owner's pending preview and report whether it existed."""
        cursor = await tx.execute("DELETE FROM crime_previews WHERE char_id = ? AND nonce = ?", (char_id, nonce))
        return cursor.rowcount == 1

    async def claim_crime_attempt(self, tx: aiosqlite.Connection, char_id: int, age: int, *, limit: int = 2) -> bool:
        """Reserve a crime attempt using Stage 6 yearly_counters when an NPC anchor exists."""
        row = await self._one(
            tx,
            """SELECT COALESCE(SUM(count), 0) AS count FROM yearly_counters
               WHERE char_id = ? AND age = ? AND action = 'crime_commit'""",
            (char_id, age),
        )
        fallback = await self._one(
            tx,
            "SELECT count FROM crime_yearly_actions WHERE char_id = ? AND age = ? AND action = 'crime_commit'",
            (char_id, age),
        )
        count = int(row["count"] if row is not None else 0) + (int(fallback["count"]) if fallback is not None else 0)
        if count >= limit:
            return False
        anchor = await self._one(
            tx,
            "SELECT npc_id FROM npcs WHERE owner_char_id = ? ORDER BY npc_id LIMIT 1",
            (char_id,),
        )
        if anchor is not None:
            await tx.execute(
                """INSERT INTO yearly_counters(char_id, npc_id, age, action, count)
                   VALUES (?, ?, ?, 'crime_commit', 1)
                   ON CONFLICT(char_id, npc_id, age, action) DO UPDATE SET count = count + 1""",
                (char_id, int(anchor["npc_id"]), age),
            )
        else:
            await self.claim_action(tx, char_id, age, "crime_commit")
        return True

    async def claim_action(self, tx: aiosqlite.Connection, char_id: int, age: int, action: str) -> bool:
        """Reserve one prison action per in-game age."""
        row = await self._one(
            tx,
            "SELECT count FROM crime_yearly_actions WHERE char_id = ? AND age = ? AND action = ?",
            (char_id, age, action),
        )
        if row is not None and int(row["count"]) >= 1:
            return False
        await tx.execute(
            """INSERT INTO crime_yearly_actions(char_id, age, action, count) VALUES (?, ?, ?, 1)
               ON CONFLICT(char_id, age, action) DO UPDATE SET count = count + 1""",
            (char_id, age, action),
        )
        return True

    async def insert_attempt(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        crime_id: str,
        age: int,
        source: str,
        success: bool,
        caught: bool,
        loot: int,
        success_chance: float,
        catch_chance: float,
        case_status: str,
        created_at: int,
    ) -> int:
        """Insert a committed attempt or arrest and return its audit-record key."""
        cursor = await tx.execute(
            """INSERT INTO crime_attempts
                   (char_id, crime_id, age, source, success, caught, loot,
                    success_chance, catch_chance, case_status, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, crime_id, age, source, int(success), int(caught), loot,
             success_chance, catch_chance, case_status, created_at),
        )
        return int(cursor.lastrowid)

    async def create_trial(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        attempt_id: int,
        nonce: str,
        created_at: int,
    ) -> None:
        """Create a persistent one-case trial choice."""
        await tx.execute(
            "INSERT INTO crime_trials(char_id, attempt_id, nonce, created_at) VALUES (?, ?, ?, ?)",
            (char_id, attempt_id, nonce, created_at),
        )

    async def pending_trial(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Load an unresolved trial and its associated crime record."""
        row = await self._one(
            tx,
            """SELECT t.nonce, t.created_at AS trial_created_at, a.*
               FROM crime_trials AS t JOIN crime_attempts AS a ON a.attempt_id = t.attempt_id
               WHERE t.char_id = ? LIMIT 1""",
            (char_id,),
        )
        return dict(row) if row is not None else None

    async def pending_trial_read(self, user_id: int) -> Optional[dict[str, Any]]:
        """Read a pending trial for an active life to recreate its button view."""
        row = await self.db.fetchone(
            """SELECT t.nonce, t.created_at AS trial_created_at, a.*
               FROM crime_trials AS t JOIN crime_attempts AS a ON a.attempt_id = t.attempt_id
               JOIN characters AS c ON c.char_id = t.char_id
               WHERE c.user_id = ? AND c.is_alive = 1 LIMIT 1""",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def has_pending_decision(self, tx: aiosqlite.Connection, char_id: int, now: int) -> bool:
        """Check for an unexpired preview, trial, or tax decision before aging."""
        await tx.execute("DELETE FROM crime_previews WHERE char_id = ? AND expires_at < ?", (char_id, now))
        return await self._one(
            tx,
            """SELECT 1 FROM crime_previews WHERE char_id = ?
               UNION ALL SELECT 1 FROM crime_trials WHERE char_id = ?
               UNION ALL SELECT 1 FROM crime_tax_prompts WHERE char_id = ? LIMIT 1""",
            (char_id, char_id, char_id),
        ) is not None

    async def preview_for_character(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Load a pending preview in the caller's transaction."""
        row = await self._one(tx, "SELECT * FROM crime_previews WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def read_preview(self, user_id: int) -> Optional[dict[str, Any]]:
        """Read a pending crime confirmation for its living owner."""
        row = await self.db.fetchone(
            """SELECT p.* FROM crime_previews AS p JOIN characters AS c ON c.char_id = p.char_id
               WHERE c.user_id = ? AND c.is_alive = 1 LIMIT 1""",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def complete_trial(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        attempt_id: int,
        case_status: str,
        lawyer_tier: str,
        sentence_years: int,
        life_sentence: bool,
        record_sealed: bool,
        fine_paid: int,
        resolved_at: int,
    ) -> None:
        """Store verdict details and consume the persistent trial nonce."""
        await tx.execute(
            """UPDATE crime_attempts SET case_status = ?, lawyer_tier = ?, sentence_years = ?,
                   life_sentence = ?, record_sealed = ?, fine_paid = ?, resolved_at = ?
               WHERE attempt_id = ? AND char_id = ? AND case_status = 'pending'""",
            (case_status, lawyer_tier, sentence_years, int(life_sentence), int(record_sealed),
             fine_paid, resolved_at, attempt_id, char_id),
        )
        await tx.execute("DELETE FROM crime_trials WHERE char_id = ? AND attempt_id = ?", (char_id, attempt_id))

    async def resolve_audit_attempt(
        self,
        tx: aiosqlite.Connection,
        attempt_id: int,
        *,
        sentence_years: int,
        resolved_at: int,
    ) -> None:
        """Fill sentence metadata for a direct tax-audit conviction without a trial row."""
        await tx.execute(
            """UPDATE crime_attempts SET case_status = 'convicted', lawyer_tier = NULL,
                   sentence_years = ?, life_sentence = 0, record_sealed = 0,
                   fine_paid = 0, resolved_at = ? WHERE attempt_id = ? AND source = 'tax_audit'""",
            (max(0, sentence_years), resolved_at, attempt_id),
        )

    async def get_job(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return the active job required for embezzlement and prison dismissal."""
        row = await self._one(tx, "SELECT * FROM jobs WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def fire_job_for_prison(self, tx: aiosqlite.Connection, char_id: int, age: int) -> bool:
        """Close an active job with the Stage 7 'prison' history reason."""
        row = await self._one(tx, "SELECT 1 FROM jobs WHERE char_id = ? LIMIT 1", (char_id,))
        if row is None:
            return False
        await tx.execute(
            """UPDATE career_history SET end_age = ?, end_reason = 'prison'
               WHERE char_id = ? AND end_age IS NULL""",
            (age, char_id),
        )
        await tx.execute("DELETE FROM jobs WHERE char_id = ?", (char_id,))
        return True

    async def relationship_scores(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, int]]:
        """Return connected NPC IDs and scores for sentencing consequences."""
        rows = await self._all(tx, "SELECT npc_id, score FROM relationships WHERE char_id = ?", (char_id,))
        return [{"npc_id": int(row["npc_id"]), "score": int(row["score"])} for row in rows]

    async def set_relationship_score(self, tx: aiosqlite.Connection, char_id: int, npc_id: int, score: int) -> None:
        """Persist one nonnegative relationship score."""
        await tx.execute(
            "UPDATE relationships SET score = ? WHERE char_id = ? AND npc_id = ?",
            (max(0, min(100, score)), char_id, npc_id),
        )

    async def has_marriage(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check for an active marriage without leaking another life's spouse data."""
        return await self._one(tx, "SELECT 1 FROM marriages WHERE char_id = ? LIMIT 1", (char_id,)) is not None

    async def add_cashflow(self, tx: aiosqlite.Connection, char_id: int, age: int, action: str, amount: int, now: int) -> None:
        """Log one positive criminal cash-flow amount in integer cents."""
        await tx.execute(
            "INSERT INTO crime_cashflows(char_id, age, action, amount, created_at) VALUES (?, ?, ?, ?, ?)",
            (char_id, age, action, max(0, amount), now),
        )

    async def cashflow_totals(self, tx: aiosqlite.Connection, char_id: int, age: int) -> dict[str, int]:
        """Sum criminal proceeds and laundering for one in-game age."""
        rows = await self._all(
            tx,
            """SELECT action, COALESCE(SUM(amount), 0) AS total FROM crime_cashflows
               WHERE char_id = ? AND age = ? GROUP BY action""",
            (char_id, age),
        )
        return {str(row["action"]): int(row["total"]) for row in rows}

    async def laundering_total_read(self, char_id: int, age: int) -> int:
        """Read gross laundering already used in the current in-game year."""
        row = await self.db.fetchone(
            "SELECT COALESCE(SUM(gross_amount), 0) AS total FROM crime_laundering WHERE char_id = ? AND age = ?",
            (char_id, age),
        )
        return int(row["total"] if row is not None else 0)

    async def laundering_total(self, tx: aiosqlite.Connection, char_id: int, age: int) -> int:
        """Return gross laundering already used in the current in-game year."""
        row = await self._one(
            tx,
            "SELECT COALESCE(SUM(gross_amount), 0) AS total FROM crime_laundering WHERE char_id = ? AND age = ?",
            (char_id, age),
        )
        return int(row["total"] if row is not None else 0)

    async def add_laundering(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        age: int,
        gross: int,
        fee: int,
        net: int,
        now: int,
    ) -> None:
        """Persist a completed laundering transaction."""
        await tx.execute(
            """INSERT INTO crime_laundering(char_id, age, gross_amount, fee_amount, net_amount, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (char_id, age, gross, fee, net, now),
        )

    async def has_front_business(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check the existing item inventory for the required front-business item."""
        row = await self._one(
            tx,
            """SELECT 1 FROM family_assets WHERE char_id = ? AND kind = 'item'
                 AND item_id IN ('front_business', 'laundromat', 'car_wash', 'nightclub')
                 AND quantity > 0 AND is_liquidated = 0 LIMIT 1""", 
            (char_id,),
        )
        return row is not None

    async def grant_front_business(self, tx: aiosqlite.Connection, char_id: int, age: int, now: int) -> None:
        """Grant one zero-cost front-business item at the Crime Boss career tier."""
        if await self.has_front_business(tx, char_id):
            return
        await tx.execute(
            """INSERT INTO family_assets
                   (char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at)
               VALUES (?, 'item', 'front_business', 1, 0, 0, ?, ?)""",
            (char_id, age, now),
        )
        await self.update_profile(tx, char_id, front_business=1)

    async def save_tax_prompt(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        nonce: str,
        age: int,
        tax_due: int,
        prepaid: bool,
        now: int,
        *,
        paid_amount: int = 0,
    ) -> None:
        """Persist a one-use high-earner tax decision."""
        await tx.execute("DELETE FROM crime_tax_prompts WHERE char_id = ?", (char_id,))
        await tx.execute(
            """INSERT INTO crime_tax_prompts
                   (char_id, nonce, age, tax_due, prepaid, paid_amount, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (char_id, nonce, age, tax_due, int(prepaid), max(0, paid_amount), now),
        )

    async def pending_tax_prompt(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return the unresolved tax-evasion event for one life."""
        row = await self._one(tx, "SELECT * FROM crime_tax_prompts WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def pending_tax_prompt_read(self, user_id: int) -> Optional[dict[str, Any]]:
        """Read an active tax decision so its interactive view can be reopened."""
        row = await self.db.fetchone(
            """SELECT p.* FROM crime_tax_prompts AS p JOIN characters AS c ON c.char_id = p.char_id
               WHERE c.user_id = ? AND c.is_alive = 1 LIMIT 1""",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def consume_tax_prompt(self, tx: aiosqlite.Connection, char_id: int, nonce: str) -> bool:
        """Delete exactly one nonce-matched tax event after its choice is recorded."""
        cursor = await tx.execute("DELETE FROM crime_tax_prompts WHERE char_id = ? AND nonce = ?", (char_id, nonce))
        return cursor.rowcount == 1

    async def record_tax_choice(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        age: int,
        choice: str,
        tax_due: int,
        evaded_amount: int,
        now: int,
    ) -> None:
        """Append one selected tax decision to the audit history."""
        await tx.execute(
            """INSERT INTO crime_tax_choices(char_id, age, choice, tax_due, evaded_amount, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (char_id, age, choice, tax_due, evaded_amount, now),
        )

    async def record_audit(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        age: int,
        chance: float,
        triggered: bool,
        evasion_found: bool,
        back_taxes: int,
        sentence_years: int,
        outcome: str,
        now: int,
    ) -> None:
        """Persist an annual financial audit result."""
        await tx.execute(
            """INSERT INTO crime_audits
                   (char_id, age, audit_chance, triggered, tax_evasion_found,
                    back_taxes, sentence_years, outcome, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, age, chance, int(triggered), int(evasion_found), back_taxes, sentence_years, outcome, now),
        )

    async def active_loans(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return unpaid loans for prison's automatic-payment rule."""
        rows = await self._all(tx, "SELECT * FROM loans WHERE char_id = ? AND status = 'active' ORDER BY loan_id", (char_id,))
        return [dict(row) for row in rows]

    async def pay_loan(self, tx: aiosqlite.Connection, loan_id: int, payment: int) -> None:
        """Apply a full available annual payment to one loan."""
        row = await self._one(tx, "SELECT balance FROM loans WHERE loan_id = ? AND status = 'active'", (loan_id,))
        if row is None:
            return
        balance = int(row["balance"])
        remaining = max(0, balance - min(balance, max(0, payment)))
        await tx.execute(
            "UPDATE loans SET balance = ?, status = ? WHERE loan_id = ?",
            (remaining, "paid" if remaining == 0 else "active", loan_id),
        )

    async def miss_loan_payment(self, tx: aiosqlite.Connection, loan_id: int) -> None:
        """Increment missed prison-time loan payments without changing the balance."""
        await tx.execute("UPDATE loans SET missed_payments = missed_payments + 1 WHERE loan_id = ?", (loan_id,))

    async def crime_history_in_transaction(
        self, tx: aiosqlite.Connection, char_id: int, limit: int = 10
    ) -> list[dict[str, Any]]:
        """Return recent attempts using the caller's transaction connection."""
        rows = await self._all(
            tx,
            "SELECT * FROM crime_attempts WHERE char_id = ? ORDER BY age DESC, attempt_id DESC LIMIT ?",
            (char_id, max(1, min(25, limit))),
        )
        return [dict(row) for row in rows]

    async def crime_history(self, char_id: int, limit: int = 10) -> list[dict[str, Any]]:
        """Return recent attempts and court outcomes for a crime-record embed."""
        rows = await self.db.fetchall(
            """SELECT * FROM crime_attempts WHERE char_id = ? ORDER BY age DESC, attempt_id DESC LIMIT ?""",
            (char_id, max(1, min(25, limit))),
        )
        return [dict(row) for row in rows]

    async def read_profile(self, char_id: int) -> Optional[dict[str, Any]]:
        """Read a previously initialized criminal profile."""
        row = await self.db.fetchone("SELECT * FROM crime_profiles WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def get_hiring_context(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return release age and record metadata for a job-application calculation."""
        row = await self._one(tx, "SELECT last_release_age FROM crime_profiles WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def other_pending_prompt(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check trial and tax decisions that cannot overlap with a new age event."""
        return await self._one(
            tx,
            """SELECT 1 FROM crime_trials WHERE char_id = ?
               UNION ALL SELECT 1 FROM crime_tax_prompts WHERE char_id = ? LIMIT 1""",
            (char_id, char_id),
        ) is not None

    async def get_status_data(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Any]:
        """Load criminal profile and pending prompts for a combined record/status view."""
        profile = await self.get_profile(tx, char_id)
        trial = await self.pending_trial(tx, char_id)
        tax = await self.pending_tax_prompt(tx, char_id)
        return {"profile": profile, "trial": trial, "tax": tax}
````

## `lifeline/core/repositories/family.py`

````python
"""Parameterized SQLite repository for Stage 6 family and relationship data."""
from __future__ import annotations

import json
from typing import Any, Optional

import aiosqlite

from ..models import Character


class FamilyRepository:
    """Own every SQL statement used by the Stage 6 family domain service."""

    def __init__(self, db: Any) -> None:
        self.db = db

    @staticmethod
    async def _tx_one(tx: aiosqlite.Connection, query: str, params: tuple[Any, ...] = ()) -> Any:
        cursor = await tx.execute(query, params)
        return await cursor.fetchone()

    @staticmethod
    async def _tx_all(tx: aiosqlite.Connection, query: str, params: tuple[Any, ...] = ()) -> list[Any]:
        cursor = await tx.execute(query, params)
        return await cursor.fetchall()

    async def load_active(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Return the active character row and version for a transactional action."""
        row = await self._tx_one(
            tx,
            "SELECT char_id, user_id, data_json, version FROM characters "
            "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def has_any_life(self, tx: aiosqlite.Connection, user_id: int) -> bool:
        """Check whether a user has a completed or active life."""
        row = await self._tx_one(tx, "SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,))
        return row is not None

    async def load_active_read(self, user_id: int) -> Optional[dict[str, Any]]:
        """Return an active character row for a read-only command."""
        row = await self.db.fetchone(
            "SELECT char_id, user_id, data_json, version FROM characters "
            "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def has_any_life_read(self, user_id: int) -> bool:
        """Check read-only character history for a user."""
        row = await self.db.fetchone("SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,))
        return row is not None

    async def has_pending_event(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check for an unresolved life choice before a new family action."""
        row = await self._tx_one(tx, "SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1", (char_id,))
        return row is not None

    async def save_character(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
    ) -> None:
        """Save character JSON and stats with optimistic-version protection."""
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET stats_json = ?, version = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (stats_json, character.version, data_json, character.char_id, expected_version),
        )
        if cursor.rowcount != 1:
            from ..errors import ConcurrentUpdate
            raise ConcurrentUpdate()

    async def create_npc(
        self,
        tx: aiosqlite.Connection,
        *,
        owner_char_id: int,
        name: str,
        gender: str,
        age: int,
        looks: int,
        smarts: int,
        health: int,
        wealth: int,
        occupation: str,
        country: str,
        annual_income: int = 0,
        prefers_smarts: bool = False,
    ) -> int:
        """Persist one generated NPC and return its key."""
        cursor = await tx.execute(
            """INSERT INTO npcs
                   (owner_char_id, name, gender, age, looks, smarts, health, wealth,
                    occupation, is_alive, death_age, country, annual_income, prefers_smarts)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NULL, ?, ?, ?)""",
            (
                owner_char_id, name, gender, age, looks, smarts, health, wealth,
                occupation, country, annual_income, int(prefers_smarts),
            ),
        )
        return int(cursor.lastrowid)

    async def create_relationship(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        npc_id: int,
        relation_type: str,
        score: int,
        since_age: int,
    ) -> None:
        """Insert or update the unique relationship between a life and an NPC."""
        await tx.execute(
            """INSERT INTO relationships(char_id, npc_id, type, score, since_age)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(char_id, npc_id) DO UPDATE SET
                   type = excluded.type, score = excluded.score, since_age = excluded.since_age""",
            (char_id, npc_id, relation_type, max(0, min(100, int(score))), since_age),
        )

    async def get_person(self, tx: aiosqlite.Connection, char_id: int, npc_id: int) -> Optional[dict[str, Any]]:
        """Return an NPC only when it belongs to the selected life."""
        row = await self._tx_one(
            tx,
            """SELECT n.*, r.type AS relationship_type, r.score AS relationship_score,
                      r.since_age AS relationship_since_age, c.custody, c.child_support
               FROM relationships AS r
               JOIN npcs AS n ON n.npc_id = r.npc_id
               LEFT JOIN children AS c ON c.npc_id = n.npc_id AND c.char_id = r.char_id
               WHERE r.char_id = ? AND n.owner_char_id = ? AND n.npc_id = ? LIMIT 1""",
            (char_id, char_id, npc_id),
        )
        return dict(row) if row is not None else None

    async def get_person_read(self, char_id: int, npc_id: int) -> Optional[dict[str, Any]]:
        """Return an owned NPC and relationship for autocomplete or UI rendering."""
        row = await self.db.fetchone(
            """SELECT n.*, r.type AS relationship_type, r.score AS relationship_score,
                      r.since_age AS relationship_since_age, c.custody, c.child_support
               FROM relationships AS r
               JOIN npcs AS n ON n.npc_id = r.npc_id
               LEFT JOIN children AS c ON c.npc_id = n.npc_id AND c.char_id = r.char_id
               WHERE r.char_id = ? AND n.owner_char_id = ? AND n.npc_id = ? LIMIT 1""",
            (char_id, char_id, npc_id),
        )
        return dict(row) if row is not None else None

    async def list_people(self, char_id: int, *, include_dead: bool = True) -> list[dict[str, Any]]:
        """List NPC relationships for one life in family-friendly display order."""
        condition = "" if include_dead else "AND n.is_alive = 1"
        rows = await self.db.fetchall(
            f"""SELECT n.*, r.type AS relationship_type, r.score AS relationship_score,
                       r.since_age AS relationship_since_age, c.custody, c.child_support
                FROM relationships AS r
                JOIN npcs AS n ON n.npc_id = r.npc_id
                LEFT JOIN children AS c ON c.npc_id = n.npc_id AND c.char_id = r.char_id
                WHERE r.char_id = ? {condition}
                ORDER BY CASE r.type WHEN 'spouse' THEN 0 WHEN 'fiance' THEN 1
                     WHEN 'partner' THEN 2 WHEN 'parent' THEN 3 WHEN 'child' THEN 4
                     WHEN 'sibling' THEN 5 WHEN 'friend' THEN 6 ELSE 7 END,
                     r.score DESC, n.name COLLATE NOCASE""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def autocomplete_people(self, char_id: int, query: str) -> list[dict[str, Any]]:
        """Find living connected NPCs for people-option autocomplete."""
        rows = await self.db.fetchall(
            """SELECT n.npc_id, n.name, n.age, r.type AS relationship_type
               FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
               WHERE r.char_id = ? AND n.is_alive = 1 AND lower(n.name) LIKE ?
               ORDER BY n.name COLLATE NOCASE LIMIT 25""",
            (char_id, f"%{query.lower()}%"),
        )
        return [dict(row) for row in rows]

    async def list_relationships_tx(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """List full relationship and NPC records inside an existing transaction."""
        rows = await self._tx_all(
            tx,
            """SELECT n.*, r.type AS relationship_type, r.score AS relationship_score,
                      r.since_age AS relationship_since_age, c.custody, c.child_support
               FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
               LEFT JOIN children AS c ON c.npc_id = n.npc_id AND c.char_id = r.char_id
               WHERE r.char_id = ? ORDER BY n.npc_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def set_relationship_score(self, tx: aiosqlite.Connection, char_id: int, npc_id: int, score: int) -> None:
        """Store a clamped relationship score."""
        await tx.execute(
            "UPDATE relationships SET score = ? WHERE char_id = ? AND npc_id = ?",
            (max(0, min(100, int(score))), char_id, npc_id),
        )

    async def add_relationship_score(self, tx: aiosqlite.Connection, char_id: int, npc_id: int, delta: int) -> None:
        """Apply and clamp a score delta in SQLite."""
        await tx.execute(
            """UPDATE relationships SET score = MIN(100, MAX(0, score + ?))
               WHERE char_id = ? AND npc_id = ?""",
            (int(delta), char_id, npc_id),
        )

    async def set_relationship_type(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        npc_id: int,
        relation_type: str,
    ) -> None:
        """Change one existing relationship's role."""
        await tx.execute(
            "UPDATE relationships SET type = ? WHERE char_id = ? AND npc_id = ?",
            (relation_type, char_id, npc_id),
        )

    async def active_romance(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Find the highest-scoring active partner, fiance, or spouse."""
        row = await self._tx_one(
            tx,
            """SELECT n.*, r.type AS relationship_type, r.score AS relationship_score,
                      r.since_age AS relationship_since_age
               FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
               WHERE r.char_id = ? AND r.type IN ('partner', 'fiance', 'spouse') AND n.is_alive = 1
               ORDER BY CASE r.type WHEN 'spouse' THEN 0 WHEN 'fiance' THEN 1 ELSE 2 END,
                        r.id DESC LIMIT 1""",
            (char_id,),
        )
        return dict(row) if row is not None else None

    async def claim_interaction(self, tx: aiosqlite.Connection, char_id: int, npc_id: int, age: int) -> bool:
        """Atomically reserve one of the three per-year interactions with an NPC."""
        row = await self._tx_one(
            tx,
            """SELECT count FROM yearly_counters
               WHERE char_id = ? AND npc_id = ? AND age = ? AND action = 'relationship_interact'""",
            (char_id, npc_id, age),
        )
        count = int(row["count"]) if row is not None else 0
        if count >= 3:
            return False
        await tx.execute(
            """INSERT INTO yearly_counters(char_id, npc_id, age, action, count)
               VALUES (?, ?, ?, 'relationship_interact', 1)
               ON CONFLICT(char_id, npc_id, age, action) DO UPDATE SET count = count + 1""",
            (char_id, npc_id, age),
        )
        return True

    async def claim_yearly_action(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        npc_id: int,
        age: int,
        action: str,
        *,
        limit: int = 1,
    ) -> bool:
        """Atomically reserve an action with a per-NPC, per-age limit."""
        row = await self._tx_one(
            tx,
            "SELECT count FROM yearly_counters WHERE char_id = ? AND npc_id = ? AND age = ? AND action = ?",
            (char_id, npc_id, age, action),
        )
        count = int(row["count"]) if row is not None else 0
        if count >= limit:
            return False
        await tx.execute(
            """INSERT INTO yearly_counters(char_id, npc_id, age, action, count)
               VALUES (?, ?, ?, ?, 1)
               ON CONFLICT(char_id, npc_id, age, action) DO UPDATE SET count = count + 1""",
            (char_id, npc_id, age, action),
        )
        return True

    async def list_live_npcs(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """List live NPCs owned by a life for the yearly NPC-ageing tick."""
        rows = await self._tx_all(
            tx,
            "SELECT * FROM npcs WHERE owner_char_id = ? AND is_alive = 1 ORDER BY npc_id",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def update_npc_year(self, tx: aiosqlite.Connection, npc_id: int, age: int, *, alive: bool) -> None:
        """Persist a single NPC's age and terminal death state."""
        await tx.execute(
            """UPDATE npcs SET age = ?, is_alive = ?, death_age = ? WHERE npc_id = ? AND is_alive = 1""",
            (age, int(alive), None if alive else age, npc_id),
        )

    async def decay_relationships(self, tx: aiosqlite.Connection, char_id: int, previous_age: int) -> None:
        """Apply annual score decay only to people with no prior-year interaction."""
        await tx.execute(
            """UPDATE relationships
               SET score = MAX(0, score - CASE
                   WHEN type IN ('parent', 'sibling', 'child') THEN 1
                   WHEN type IN ('partner', 'fiance', 'spouse') THEN 3
                   WHEN type = 'friend' THEN 2
                   ELSE 0 END)
               WHERE char_id = ? AND type IN ('parent', 'sibling', 'child', 'friend', 'partner', 'fiance', 'spouse')
                 AND NOT EXISTS (
                     SELECT 1 FROM yearly_counters AS yc
                     WHERE yc.char_id = relationships.char_id
                       AND yc.npc_id = relationships.npc_id
                       AND yc.age = ? AND yc.action = 'relationship_interact' AND yc.count > 0
                 )""",
            (char_id, previous_age),
        )

    async def count_siblings(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Count recorded sibling NPCs for inheritance division."""
        row = await self._tx_one(
            tx,
            """SELECT COUNT(*) AS count FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
               WHERE r.char_id = ? AND r.type = 'sibling' AND n.is_alive = 1""",
            (char_id,),
        )
        return int(row["count"] if row is not None else 0)

    async def parent_relations(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return parent NPC and relationship rows for grief/inheritance logic."""
        rows = await self._tx_all(
            tx,
            """SELECT n.*, r.type AS relationship_type, r.score AS relationship_score
               FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
               WHERE r.char_id = ? AND r.type = 'parent' ORDER BY n.npc_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def insert_life_log(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        age: int,
        category: str,
        text: str,
        importance: int,
        created_at: int,
    ) -> None:
        """Insert a family system log into the shared life journal."""
        await tx.execute(
            """INSERT INTO life_logs(char_id, age, category, text, importance, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (char_id, age, category, text, importance, created_at),
        )

    async def save_dating_session(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        nonce: str,
        created_at: int,
        expires_at: int,
        npc_ids: list[int],
    ) -> None:
        """Replace the previous date search and attach its three generated candidates."""
        await tx.execute(
            """DELETE FROM npcs WHERE npc_id IN (
                   SELECT d.npc_id FROM dating_candidates AS d WHERE d.char_id = ?
               ) AND NOT EXISTS (
                   SELECT 1 FROM relationships AS r WHERE r.npc_id = npcs.npc_id
               )""",
            (char_id,),
        )
        await tx.execute("DELETE FROM dating_sessions WHERE char_id = ?", (char_id,))
        await tx.execute(
            "INSERT INTO dating_sessions(char_id, nonce, created_at, expires_at) VALUES (?, ?, ?, ?)",
            (char_id, nonce, created_at, expires_at),
        )
        for npc_id in npc_ids:
            await tx.execute(
                "INSERT INTO dating_candidates(char_id, npc_id) VALUES (?, ?)",
                (char_id, npc_id),
            )

    async def get_dating_candidate(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        npc_id: int,
        nonce: str,
        now: int,
    ) -> Optional[dict[str, Any]]:
        """Return a candidate only for its live, nonce-matched owner session."""
        row = await self._tx_one(
            tx,
            """SELECT n.*, s.nonce, s.expires_at
               FROM dating_sessions AS s
               JOIN dating_candidates AS d ON d.char_id = s.char_id
               JOIN npcs AS n ON n.npc_id = d.npc_id
               WHERE s.char_id = ? AND s.nonce = ? AND s.expires_at >= ? AND n.npc_id = ?
                 AND n.owner_char_id = ? AND n.is_alive = 1 LIMIT 1""",
            (char_id, nonce, now, npc_id, char_id),
        )
        return dict(row) if row is not None else None

    async def consume_dating_session(self, tx: aiosqlite.Connection, char_id: int, nonce: str) -> None:
        """Remove all unused date candidates after one selection."""
        await tx.execute(
            """DELETE FROM npcs WHERE npc_id IN (
                   SELECT d.npc_id FROM dating_candidates AS d WHERE d.char_id = ?
               ) AND NOT EXISTS (
                   SELECT 1 FROM relationships AS r WHERE r.npc_id = npcs.npc_id
               )""",
            (char_id,),
        )
        await tx.execute("DELETE FROM dating_sessions WHERE char_id = ? AND nonce = ?", (char_id, nonce))

    async def get_marriage(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return the active marriage record."""
        row = await self._tx_one(tx, "SELECT * FROM marriages WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def create_marriage(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        spouse_npc_id: int,
        start_age: int,
        spouse_income: int,
        prenup: bool,
        premarital_cash: int,
        premarital_bank: int,
        wedding_cost: int,
        created_at: int,
    ) -> None:
        """Store marriage terms and premarital liquid-asset baselines."""
        await tx.execute(
            """INSERT INTO marriages
                   (char_id, spouse_npc_id, start_age, spouse_income, prenup,
                    premarital_cash, premarital_bank, wedding_cost, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                char_id, spouse_npc_id, start_age, spouse_income, int(prenup),
                premarital_cash, premarital_bank, wedding_cost, created_at,
            ),
        )

    async def delete_marriage(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Remove the current marriage record after divorce or spouse death."""
        await tx.execute("DELETE FROM marriages WHERE char_id = ?", (char_id,))

    async def get_children(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return each child NPC and custody/support state."""
        rows = await self._tx_all(
            tx,
            """SELECT n.*, c.custody, c.child_support, c.other_parent_npc_id
               FROM children AS c JOIN npcs AS n ON n.npc_id = c.npc_id
               WHERE c.char_id = ? ORDER BY n.age, n.npc_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def add_child(
        self,
        tx: aiosqlite.Connection,
        *,
        npc_id: int,
        char_id: int,
        other_parent_npc_id: Optional[int],
        custody: str = "full",
        child_support: int = 0,
    ) -> None:
        """Attach an NPC child to its player parent and support/custody record."""
        await tx.execute(
            """INSERT INTO children(npc_id, char_id, other_parent_npc_id, custody, child_support)
               VALUES (?, ?, ?, ?, ?)""",
            (npc_id, char_id, other_parent_npc_id, custody, max(0, child_support)),
        )

    async def update_child_support(self, tx: aiosqlite.Connection, npc_id: int, child_support: int) -> None:
        """Refresh the stored annual support amount in integer cents."""
        await tx.execute(
            "UPDATE children SET child_support = ? WHERE npc_id = ?",
            (max(0, int(child_support)), npc_id),
        )

    async def update_custody(self, tx: aiosqlite.Connection, npc_id: int, custody: str) -> None:
        """Persist a custody roll."""
        await tx.execute("UPDATE children SET custody = ? WHERE npc_id = ?", (custody, npc_id))

    async def add_pregnancy(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        other_parent_npc_id: Optional[int],
        conception_age: int,
        due_age: int,
        accidental: bool,
    ) -> None:
        """Persist a pregnancy until its one-year due date."""
        await tx.execute(
            """INSERT INTO pregnancies(char_id, other_parent_npc_id, conception_age, due_age, accidental)
               VALUES (?, ?, ?, ?, ?)""",
            (char_id, other_parent_npc_id, conception_age, due_age, int(accidental)),
        )

    async def get_pregnancy(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return a pending pregnancy if present."""
        row = await self._tx_one(tx, "SELECT * FROM pregnancies WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def delete_pregnancy(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Delete a pregnancy after birth or cancellation."""
        await tx.execute("DELETE FROM pregnancies WHERE char_id = ?", (char_id,))

    async def add_adoption(self, tx: aiosqlite.Connection, char_id: int, started_age: int, due_age: int, paid_cost: int) -> None:
        """Store an adoption completion date."""
        await tx.execute(
            "INSERT INTO adoptions(char_id, started_age, due_age, paid_cost) VALUES (?, ?, ?, ?)",
            (char_id, started_age, due_age, paid_cost),
        )

    async def get_adoption(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return a pending adoption."""
        row = await self._tx_one(tx, "SELECT * FROM adoptions WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def delete_adoption(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Delete a completed adoption."""
        await tx.execute("DELETE FROM adoptions WHERE char_id = ?", (char_id,))

    async def add_asset(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        kind: str,
        item_id: str,
        quantity: int,
        purchase_price: int,
        current_value: int,
        acquired_age: int,
        acquired_at: int,
    ) -> int:
        """Add an item or portfolio asset with integer-cent values."""
        cursor = await tx.execute(
            """INSERT INTO family_assets
                   (char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at),
        )
        return int(cursor.lastrowid)

    async def list_ring_assets(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return unused ring items available to a marriage proposal."""
        rows = await self._tx_all(
            tx,
            """SELECT * FROM family_assets
               WHERE char_id = ? AND kind = 'item' AND item_id LIKE '%_ring'
                 AND quantity > 0 AND is_liquidated = 0 AND is_locked = 0
               ORDER BY current_value DESC, asset_id""", 
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def consume_ring(self, tx: aiosqlite.Connection, asset_id: int) -> None:
        """Consume the selected ring at proposal time."""
        await tx.execute(
            "UPDATE family_assets SET quantity = 0, purchase_price = 0, current_value = 0, is_liquidated = 1 WHERE asset_id = ? AND is_locked = 0",
            (asset_id,),
        )

    async def get_marital_assets(self, tx: aiosqlite.Connection, char_id: int, marriage_started_at: int) -> list[dict[str, Any]]:
        """Return non-liquidated assets acquired at or after the wedding timestamp."""
        rows = await self._tx_all(
            tx,
            """SELECT * FROM family_assets
               WHERE char_id = ? AND acquired_at >= ? AND current_value > 0 AND is_liquidated = 0
                 AND (kind != 'item' OR is_locked = 0)
               ORDER BY CASE kind WHEN 'stock' THEN 0 ELSE 1 END, asset_id""", 
            (char_id, marriage_started_at),
        )
        return [dict(row) for row in rows]

    async def reduce_asset(self, tx: aiosqlite.Connection, asset_id: int, reduction: int) -> int:
        """Reduce an asset's value by up to an integer-cent payment amount."""
        row = await self._tx_one(
            tx, "SELECT current_value FROM family_assets WHERE asset_id = ? AND (kind != 'item' OR is_locked = 0)",
            (asset_id,),
        )
        if row is None:
            return 0
        current = int(row["current_value"])
        used = min(current, max(0, int(reduction)))
        remaining = current - used
        await tx.execute(
            "UPDATE family_assets SET current_value = ?, is_liquidated = ? WHERE asset_id = ?",
            (remaining, int(remaining == 0), asset_id),
        )
        return used

    async def liquidate_stock_assets(self, tx: aiosqlite.Connection, char_id: int, marriage_started_at: int) -> int:
        """Liquidate eligible marital stocks and return their total integer-cent value."""
        row = await self._tx_one(
            tx,
            """SELECT COALESCE(SUM(current_value), 0) AS total FROM family_assets
               WHERE char_id = ? AND kind = 'stock' AND acquired_at >= ?
                 AND current_value > 0 AND is_liquidated = 0""",
            (char_id, marriage_started_at),
        )
        total = int(row["total"] if row is not None else 0)
        await tx.execute(
            """UPDATE family_assets SET current_value = 0, quantity = 0, is_liquidated = 1
               WHERE char_id = ? AND kind = 'stock' AND acquired_at >= ?
                 AND current_value > 0 AND is_liquidated = 0""",
            (char_id, marriage_started_at),
        )
        return total

    async def get_annual_job_income(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Return the current annual salary as integer cents, or zero when unemployed."""
        row = await self._tx_one(tx, "SELECT salary FROM jobs WHERE char_id = ? LIMIT 1", (char_id,))
        return int(row["salary"]) if row is not None else 0

    async def create_alimony(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        ex_npc_id: int,
        annual_amount: int,
        remaining_years: float,
        payer_is_player: bool,
    ) -> None:
        """Persist an alimony agreement."""
        await tx.execute(
            """INSERT INTO alimony(char_id, ex_npc_id, annual_amount, remaining_years, payer_is_player)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(char_id) DO UPDATE SET
                   ex_npc_id = excluded.ex_npc_id,
                   annual_amount = excluded.annual_amount,
                   remaining_years = excluded.remaining_years,
                   payer_is_player = excluded.payer_is_player""",
            (char_id, ex_npc_id, max(0, annual_amount), max(0.0, remaining_years), int(payer_is_player)),
        )

    async def get_alimony(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return an active alimony order."""
        row = await self._tx_one(tx, "SELECT * FROM alimony WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def update_alimony(self, tx: aiosqlite.Connection, char_id: int, remaining_years: float) -> None:
        """Update or remove an expired alimony order."""
        if remaining_years <= 0:
            await tx.execute("DELETE FROM alimony WHERE char_id = ?", (char_id,))
        else:
            await tx.execute(
                "UPDATE alimony SET remaining_years = ? WHERE char_id = ?",
                (remaining_years, char_id),
            )

    async def get_affair(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return an active infidelity record."""
        row = await self._tx_one(tx, "SELECT * FROM affairs WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def save_affair(self, tx: aiosqlite.Connection, char_id: int, spouse_npc_id: int, age: int, nonce: str) -> None:
        """Persist a hidden affair after the player's infidelity choice."""
        await tx.execute(
            """INSERT INTO affairs(char_id, spouse_npc_id, started_age, nonce)
               VALUES (?, ?, ?, ?)
               ON CONFLICT(char_id) DO UPDATE SET
                   spouse_npc_id = excluded.spouse_npc_id,
                   started_age = excluded.started_age,
                   nonce = excluded.nonce""",
            (char_id, spouse_npc_id, age, nonce),
        )

    async def delete_affair(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Delete a discovered or ended affair."""
        await tx.execute("DELETE FROM affairs WHERE char_id = ?", (char_id,))

    async def increment_divorces(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Increment the persistent divorce statistic."""
        await tx.execute(
            """INSERT INTO stats_tracking(char_id, divorces) VALUES (?, 1)
               ON CONFLICT(char_id) DO UPDATE SET divorces = divorces + 1""",
            (char_id,),
        )

    async def insert_divorce_record(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        spouse_npc_id: int,
        age: int,
        prenup: bool,
        marital_assets: int,
        spouse_share: int,
        lawyer_fee: int,
        reason: str,
        created_at: int,
    ) -> None:
        """Persist an audit summary of one completed divorce."""
        await tx.execute(
            """INSERT INTO divorce_records
                   (char_id, spouse_npc_id, age, prenup, marital_assets, spouse_share,
                    lawyer_fee, reason, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, spouse_npc_id, age, int(prenup), marital_assets, spouse_share, lawyer_fee, reason, created_at),
        )

    async def update_custody_and_support(
        self,
        tx: aiosqlite.Connection,
        npc_id: int,
        custody: str,
        support: int,
    ) -> None:
        """Store divorce custody and its annual support amount."""
        await tx.execute(
            "UPDATE children SET custody = ?, child_support = ? WHERE npc_id = ?",
            (custody, max(0, support), npc_id),
        )

    async def list_children_public(self, char_id: int) -> list[dict[str, Any]]:
        """Read child NPCs for the family command."""
        rows = await self.db.fetchall(
            """SELECT n.*, c.custody, c.child_support, c.other_parent_npc_id
               FROM children AS c JOIN npcs AS n ON n.npc_id = c.npc_id
               WHERE c.char_id = ? ORDER BY n.age, n.npc_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def people_by_type(self, tx: aiosqlite.Connection, char_id: int, types: tuple[str, ...]) -> list[dict[str, Any]]:
        """Return NPC relationships filtered by a fixed type list."""
        placeholders = ",".join("?" for _ in types)
        rows = await self._tx_all(
            tx,
            f"""SELECT n.*, r.type AS relationship_type, r.score AS relationship_score,
                       r.since_age AS relationship_since_age
                FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
                WHERE r.char_id = ? AND r.type IN ({placeholders}) ORDER BY n.npc_id""",
            (char_id, *types),
        )
        return [dict(row) for row in rows]

    async def log_relationship_interaction(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        age: int,
        text: str,
        now: int,
    ) -> None:
        """Log one relationship action to the life journal."""
        await self.insert_life_log(
            tx,
            char_id=char_id,
            age=age,
            category="relationship",
            text=text,
            importance=2,
            created_at=now,
        )

    async def get_npc_owned(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        npc_id: int,
    ) -> Optional[dict[str, Any]]:
        """Return any NPC owned by a life, whether or not it has a relationship row."""
        row = await self._tx_one(
            tx,
            "SELECT * FROM npcs WHERE owner_char_id = ? AND npc_id = ? LIMIT 1",
            (char_id, npc_id),
        )
        return dict(row) if row is not None else None

    async def add_npc_wealth(self, tx: aiosqlite.Connection, npc_id: int, delta: int) -> None:
        """Apply a non-negative integer-cent wealth change to one NPC."""
        await tx.execute(
            "UPDATE npcs SET wealth = MAX(0, wealth + ?) WHERE npc_id = ?",
            (int(delta), npc_id),
        )

    async def set_npc_wealth(self, tx: aiosqlite.Connection, npc_id: int, wealth: int) -> None:
        """Set an NPC's wealth to a non-negative integer-cent value."""
        await tx.execute("UPDATE npcs SET wealth = ? WHERE npc_id = ?", (max(0, int(wealth)), npc_id))

    async def get_all_assets(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return every non-liquidated item/stock asset for a settlement cascade."""
        rows = await self._tx_all(
            tx,
            """SELECT * FROM family_assets WHERE char_id = ? AND current_value > 0
               AND is_liquidated = 0 AND (kind != 'item' OR is_locked = 0)
               ORDER BY CASE kind WHEN 'stock' THEN 0 ELSE 1 END, asset_id""", 
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def has_infidelity_choice(self, tx: aiosqlite.Connection, char_id: int, age: int) -> bool:
        """Check whether this life already resolved a temptation at this age."""
        row = await self._tx_one(
            tx,
            "SELECT 1 FROM infidelity_choices WHERE char_id = ? AND age = ? LIMIT 1",
            (char_id, age),
        )
        return row is not None

    async def record_infidelity_choice(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        spouse_npc_id: int,
        age: int,
        choice: str,
        created_at: int,
    ) -> None:
        """Persist one choice per in-game age; the unique key protects races."""
        await tx.execute(
            """INSERT INTO infidelity_choices(char_id, spouse_npc_id, age, choice, created_at)
               VALUES (?, ?, ?, ?, ?)""",
            (char_id, spouse_npc_id, age, choice, created_at),
        )

    async def create_infidelity_prompt(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        spouse_npc_id: int,
        nonce: str,
        created_at: int,
        expires_at: int,
    ) -> None:
        """Persist a one-use temptation prompt."""
        await tx.execute("DELETE FROM infidelity_prompts WHERE char_id = ?", (char_id,))
        await tx.execute(
            """INSERT INTO infidelity_prompts(char_id, spouse_npc_id, nonce, created_at, expires_at)
               VALUES (?, ?, ?, ?, ?)""",
            (char_id, spouse_npc_id, nonce, created_at, expires_at),
        )

    async def get_infidelity_prompt(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        nonce: str,
        now: int,
    ) -> Optional[dict[str, Any]]:
        """Return an unexpired prompt only when its owner and nonce match."""
        row = await self._tx_one(
            tx,
            """SELECT * FROM infidelity_prompts
               WHERE char_id = ? AND nonce = ? AND expires_at >= ? LIMIT 1""",
            (char_id, nonce, now),
        )
        return dict(row) if row is not None else None

    async def delete_infidelity_prompt(self, tx: aiosqlite.Connection, char_id: int, nonce: str) -> None:
        """Consume one temptation prompt."""
        await tx.execute("DELETE FROM infidelity_prompts WHERE char_id = ? AND nonce = ?", (char_id, nonce))

    async def update_marriage_low_score_years(self, tx: aiosqlite.Connection, char_id: int, years: int) -> None:
        """Store the consecutive low-score years needed for NPC divorce checks."""
        await tx.execute(
            "UPDATE marriages SET low_score_years = ? WHERE char_id = ?",
            (max(0, int(years)), char_id),
        )
````

## `lifeline/core/repositories/shop.py`

````python
"""Parameterized repository for Stage 8 shop, inventory, loans, and trades."""
from __future__ import annotations

import json
from typing import Any, Optional

import aiosqlite

from ..models import Character


class ShopRepository:
    """Own Stage 8 SQL while accepting the caller's ``BEGIN IMMEDIATE`` connection."""

    def __init__(self, db: Any) -> None:
        self.db = db

    @staticmethod
    async def _one(tx: aiosqlite.Connection, query: str, params: tuple[Any, ...] = ()) -> Any:
        cursor = await tx.execute(query, params)
        return await cursor.fetchone()

    @staticmethod
    async def _all(tx: aiosqlite.Connection, query: str, params: tuple[Any, ...] = ()) -> list[Any]:
        cursor = await tx.execute(query, params)
        return await cursor.fetchall()

    async def load_active(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Load the active character snapshot and its database version."""
        row = await self._one(
            tx,
            "SELECT char_id, user_id, data_json, version FROM characters "
            "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def load_active_many(self, tx: aiosqlite.Connection, user_ids: tuple[int, ...]) -> dict[int, dict[str, Any]]:
        """Load active character snapshots for a stable set of user IDs."""
        if not user_ids:
            return {}
        placeholders = ",".join("?" for _ in user_ids)
        rows = await self._all(
            tx,
            f"SELECT char_id, user_id, data_json, version FROM characters "
            f"WHERE user_id IN ({placeholders}) AND is_alive = 1 ORDER BY user_id",
            user_ids,
        )
        return {int(row["user_id"]): dict(row) for row in rows}

    async def has_any_life(self, tx: aiosqlite.Connection, user_id: int) -> bool:
        """Distinguish a completed life from a user who has never started."""
        return await self._one(tx, "SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,)) is not None

    async def has_pending_event(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check for an unresolved Stage 3 choice before a transactional action."""
        return await self._one(tx, "SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1", (char_id,)) is not None

    async def save_character(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
    ) -> None:
        """Save JSON/stats and reject a stale character snapshot."""
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET stats_json = ?, version = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (stats_json, character.version, data_json, character.char_id, expected_version),
        )
        if cursor.rowcount != 1:
            from ..errors import ConcurrentUpdate
            raise ConcurrentUpdate()

    async def save_shop_quote(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        nonce: str,
        item_id: str,
        quantity: int,
        total_price: int,
        balance_cents: int,
        character_version: int,
        created_at: int,
        expires_at: int,
    ) -> None:
        """Replace a character's single short-lived, owner-bound shop quote."""
        await tx.execute("DELETE FROM shop_quotes WHERE char_id = ?", (char_id,))
        await tx.execute(
            """INSERT INTO shop_quotes
                   (char_id, nonce, item_id, quantity, total_price, balance_cents,
                    character_version, created_at, expires_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, nonce, item_id, quantity, total_price, balance_cents,
             character_version, created_at, expires_at),
        )

    async def load_shop_quote(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        nonce: str,
        now: int,
    ) -> Optional[dict[str, Any]]:
        """Fetch the exact unexpired price/version quote associated with a nonce."""
        row = await self._one(
            tx,
            "SELECT * FROM shop_quotes WHERE char_id = ? AND nonce = ? AND expires_at >= ? LIMIT 1",
            (char_id, nonce, now),
        )
        return dict(row) if row is not None else None

    async def consume_shop_quote(self, tx: aiosqlite.Connection, char_id: int, nonce: str) -> None:
        """Consume a confirmed quote so it cannot be replayed."""
        await tx.execute("DELETE FROM shop_quotes WHERE char_id = ? AND nonce = ?", (char_id, nonce))

    async def list_items(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return active item assets with an authoritative collateral flag."""
        rows = await self._all(
            tx,
            """SELECT a.*,
                      EXISTS(SELECT 1 FROM loans AS l
                             WHERE l.collateral_item_uid = a.asset_id
                               AND l.status = 'active' AND l.balance > 0) AS collateralized
               FROM family_assets AS a
               WHERE a.char_id = ? AND a.kind = 'item' AND a.quantity > 0 AND a.is_liquidated = 0
               ORDER BY a.item_id COLLATE NOCASE, a.asset_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def load_item(self, tx: aiosqlite.Connection, asset_id: int) -> Optional[dict[str, Any]]:
        """Load one item asset and whether a live loan encumbers it."""
        row = await self._one(
            tx,
            """SELECT a.*,
                      EXISTS(SELECT 1 FROM loans AS l
                             WHERE l.collateral_item_uid = a.asset_id
                               AND l.status = 'active' AND l.balance > 0) AS collateralized
               FROM family_assets AS a
               WHERE a.asset_id = ? AND a.kind = 'item' AND a.quantity > 0 AND a.is_liquidated = 0
               LIMIT 1""",
            (asset_id,),
        )
        return dict(row) if row is not None else None

    async def count_item_quantity(self, tx: aiosqlite.Connection, char_id: int, item_id: str) -> int:
        """Sum all live stacks of an item owned by one character."""
        row = await self._one(
            tx,
            """SELECT COALESCE(SUM(quantity), 0) AS quantity FROM family_assets
               WHERE char_id = ? AND kind = 'item' AND item_id = ?
                 AND quantity > 0 AND is_liquidated = 0""",
            (char_id, item_id),
        )
        return int(row["quantity"] if row is not None else 0)

    async def insert_item(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        item_id: str,
        quantity: int,
        purchase_price: int,
        current_value: int,
        age: int,
        now: int,
    ) -> int:
        """Persist a purchased or event-awarded item as a family asset."""
        cursor = await tx.execute(
            """INSERT INTO family_assets
                   (char_id, kind, item_id, quantity, purchase_price, current_value,
                    acquired_age, acquired_at, is_liquidated, is_locked)
               VALUES (?, 'item', ?, ?, ?, ?, ?, ?, 0, 0)""",
            (char_id, item_id, quantity, purchase_price, current_value, age, now),
        )
        return int(cursor.lastrowid)

    async def set_item_value(self, tx: aiosqlite.Connection, asset_id: int, value: int) -> None:
        """Update an item's aggregate current market value in cents."""
        await tx.execute(
            "UPDATE family_assets SET current_value = ? WHERE asset_id = ? AND kind = 'item'",
            (max(0, int(value)), asset_id),
        )

    async def reduce_item(
        self,
        tx: aiosqlite.Connection,
        *,
        asset_id: int,
        owner_char_id: int,
        quantity: int,
    ) -> Optional[dict[str, int]]:
        """Remove part of an unlocked item lot and return its proportional cost/value."""
        row = await self._one(
            tx,
            """SELECT quantity, purchase_price, current_value FROM family_assets
               WHERE asset_id = ? AND char_id = ? AND kind = 'item' AND is_locked = 0
                 AND quantity > 0 AND is_liquidated = 0 LIMIT 1""",
            (asset_id, owner_char_id),
        )
        if row is None:
            return None
        old_quantity = int(row["quantity"])
        selected = int(quantity)
        if selected <= 0 or selected > old_quantity:
            return None
        old_cost = int(row["purchase_price"])
        old_value = int(row["current_value"])
        if selected == old_quantity:
            part_cost, part_value = old_cost, old_value
            await tx.execute(
                """UPDATE family_assets SET quantity = 0, purchase_price = 0,
                       current_value = 0, is_liquidated = 1 WHERE asset_id = ?""",
                (asset_id,),
            )
        else:
            part_cost = old_cost * selected // old_quantity
            part_value = old_value * selected // old_quantity
            await tx.execute(
                """UPDATE family_assets SET quantity = ?, purchase_price = ?, current_value = ?
                   WHERE asset_id = ?""",
                (old_quantity - selected, old_cost - part_cost, old_value - part_value, asset_id),
            )
        return {"purchase_price": part_cost, "current_value": part_value, "quantity": selected}

    async def begin_trade_item_transfers(self, tx: aiosqlite.Connection) -> None:
        """Start a savepoint so a conditional item-transfer failure cannot partially commit."""
        await tx.execute("SAVEPOINT shop_trade_item_transfers")

    async def rollback_trade_item_transfers(self, tx: aiosqlite.Connection) -> None:
        """Undo only trade asset mutations before marking an otherwise valid offer failed."""
        await tx.execute("ROLLBACK TO SAVEPOINT shop_trade_item_transfers")
        await tx.execute("RELEASE SAVEPOINT shop_trade_item_transfers")

    async def finish_trade_item_transfers(self, tx: aiosqlite.Connection) -> None:
        """Release the item-transfer savepoint after every conditional update succeeds."""
        await tx.execute("RELEASE SAVEPOINT shop_trade_item_transfers")

    async def transfer_item(
        self,
        tx: aiosqlite.Connection,
        *,
        asset_id: int,
        from_char_id: int,
        to_char_id: int,
        quantity: int,
        to_age: int,
        now: int,
    ) -> Optional[int]:
        """Transfer an unlocked, unencumbered item lot, splitting it if needed."""
        row = await self._one(
            tx,
            """SELECT a.* FROM family_assets AS a
               WHERE a.asset_id = ? AND a.char_id = ? AND a.kind = 'item'
                 AND a.quantity > 0 AND a.is_liquidated = 0 AND a.is_locked = 0
                 AND NOT EXISTS(SELECT 1 FROM loans AS l
                                WHERE l.collateral_item_uid = a.asset_id
                                  AND l.status = 'active' AND l.balance > 0)
               LIMIT 1""",
            (asset_id, from_char_id),
        )
        if row is None:
            return None
        original_quantity = int(row["quantity"])
        amount = int(quantity)
        if amount <= 0 or amount > original_quantity:
            return None
        old_cost = int(row["purchase_price"])
        old_value = int(row["current_value"])
        if amount == original_quantity:
            await tx.execute(
                """UPDATE family_assets SET char_id = ?, acquired_age = ?, acquired_at = ?, is_locked = 0
                   WHERE asset_id = ? AND char_id = ? AND is_locked = 0""",
                (to_char_id, to_age, now, asset_id, from_char_id),
            )
            return asset_id
        part_cost = old_cost * amount // original_quantity
        part_value = old_value * amount // original_quantity
        await tx.execute(
            """UPDATE family_assets SET quantity = ?, purchase_price = ?, current_value = ?
               WHERE asset_id = ? AND char_id = ? AND is_locked = 0""",
            (original_quantity - amount, old_cost - part_cost, old_value - part_value, asset_id, from_char_id),
        )
        return await self.insert_item(
            tx,
            char_id=to_char_id,
            item_id=str(row["item_id"]),
            quantity=amount,
            purchase_price=part_cost,
            current_value=part_value,
            age=to_age,
            now=now,
        )

    async def has_used_item(self, tx: aiosqlite.Connection, asset_id: int, age: int) -> bool:
        """Check whether a non-consumable item was used during this in-game year."""
        return await self._one(
            tx, "SELECT 1 FROM inventory_uses WHERE asset_id = ? AND age = ? LIMIT 1", (asset_id, age)
        ) is not None

    async def record_item_use(self, tx: aiosqlite.Connection, asset_id: int, age: int, now: int) -> None:
        """Record the one permitted annual use of a reusable item."""
        await tx.execute(
            "INSERT INTO inventory_uses(asset_id, age, used_at) VALUES (?, ?, ?)",
            (asset_id, age, now),
        )

    async def lock_items(self, tx: aiosqlite.Connection, char_id: int, asset_ids: tuple[int, ...]) -> bool:
        """Lock every selected offered item iff all are still owned and available."""
        for asset_id in asset_ids:
            cursor = await tx.execute(
                """UPDATE family_assets SET is_locked = 1
                   WHERE asset_id = ? AND char_id = ? AND kind = 'item' AND is_locked = 0
                     AND quantity > 0 AND is_liquidated = 0""",
                (asset_id, char_id),
            )
            if cursor.rowcount != 1:
                return False
        return True

    async def active_loans(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return live loans in deterministic payment order."""
        rows = await self._all(
            tx,
            "SELECT * FROM loans WHERE char_id = ? AND status = 'active' ORDER BY loan_id",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def has_defaulted_or_delinquent_loan(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check the conservative financing gate for a default or three missed payments."""
        return await self._one(
            tx,
            """SELECT 1 FROM loans WHERE char_id = ?
               AND (status = 'defaulted' OR (status = 'active' AND missed_payments >= 3)) LIMIT 1""",
            (char_id,),
        ) is not None

    async def create_loan(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        loan_type: str,
        principal: int,
        annual_payment: int,
        term_years: int,
        collateral_item_uid: int,
    ) -> int:
        """Create a zero-interest secured mortgage or auto loan."""
        cursor = await tx.execute(
            """INSERT INTO loans
                   (char_id, loan_type, balance, annual_payment, missed_payments, status,
                    principal, annual_rate, term_years, years_remaining, collateral_item_uid)
               VALUES (?, ?, ?, ?, 0, 'active', ?, 0, ?, ?, ?)""",
            (char_id, loan_type, principal, annual_payment, principal, term_years, term_years, collateral_item_uid),
        )
        return int(cursor.lastrowid)

    async def pay_loan(self, tx: aiosqlite.Connection, loan_id: int, payment: int) -> None:
        """Apply an annual loan payment and close a fully settled loan."""
        row = await self._one(tx, "SELECT balance, years_remaining FROM loans WHERE loan_id = ? AND status = 'active'", (loan_id,))
        if row is None:
            return
        balance = int(row["balance"])
        amount = min(balance, max(0, int(payment)))
        remaining = balance - amount
        years = max(0, int(row["years_remaining"]) - 1)
        await tx.execute(
            """UPDATE loans SET balance = ?, status = ?, years_remaining = ?, missed_payments = 0
               WHERE loan_id = ? AND status = 'active'""",
            (remaining, "paid" if remaining == 0 else "active", years, loan_id),
        )

    async def miss_loan_payment(self, tx: aiosqlite.Connection, loan_id: int) -> None:
        """Record a missed annual payment without making character balances negative."""
        await tx.execute("UPDATE loans SET missed_payments = missed_payments + 1 WHERE loan_id = ? AND status = 'active'", (loan_id,))

    async def insert_player(self, tx: aiosqlite.Connection, user_id: int, created_at: int) -> None:
        """Persist a Discord account's original creation time once."""
        await tx.execute(
            "INSERT OR IGNORE INTO players(user_id, created_at) VALUES (?, ?)",
            (user_id, created_at),
        )

    async def load_player(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Load a registered player and trade-ban flag."""
        row = await self._one(tx, "SELECT * FROM players WHERE user_id = ? LIMIT 1", (user_id,))
        return dict(row) if row is not None else None

    async def trade_daily_count(self, tx: aiosqlite.Connection, user_id: int, day_key: str) -> int:
        """Read this player's trade offers created on a UTC calendar day."""
        row = await self._one(
            tx, "SELECT trades FROM trade_daily_usage WHERE user_id = ? AND day_key = ?",
            (user_id, day_key),
        )
        return int(row["trades"]) if row is not None else 0

    async def increment_trade_daily(self, tx: aiosqlite.Connection, user_id: int, day_key: str) -> None:
        """Consume one daily trade allowance, guarded by the five-trade limit."""
        cursor = await tx.execute(
            """INSERT INTO trade_daily_usage(user_id, day_key, trades) VALUES (?, ?, 1)
               ON CONFLICT(user_id, day_key) DO UPDATE SET trades = trades + 1
               WHERE trades < 5""",
            (user_id, day_key),
        )
        if cursor.rowcount != 1:
            raise ValueError("daily trade limit reached")

    async def has_pending_outgoing(self, tx: aiosqlite.Connection, user_id: int) -> bool:
        """Check for one pending outgoing proposal by this player."""
        return await self._one(
            tx, "SELECT 1 FROM trades WHERE from_user_id = ? AND status = 'pending' LIMIT 1", (user_id,)
        ) is not None

    async def create_trade(
        self,
        tx: aiosqlite.Connection,
        *,
        from_user_id: int,
        from_char_id: int,
        to_user_id: int,
        to_char_id: int,
        offer_cash: int,
        request_cash: int,
        now: int,
        expires_at: int,
        nonce: str,
        imbalance_flag: bool,
        imbalance_receiver_id: Optional[int],
    ) -> int:
        """Insert an auditable trade proposal."""
        cursor = await tx.execute(
            """INSERT INTO trades
                   (from_user_id, from_char_id, to_user_id, to_char_id, offer_cash, request_cash,
                    status, created_at, expires_at, nonce, imbalance_flag, imbalance_receiver_id)
               VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?)""",
            (from_user_id, from_char_id, to_user_id, to_char_id, offer_cash, request_cash,
             now, expires_at, nonce, int(imbalance_flag), imbalance_receiver_id),
        )
        return int(cursor.lastrowid)

    async def add_trade_item(
        self,
        tx: aiosqlite.Connection,
        *,
        trade_id: int,
        side: str,
        item_uid: int,
        item_id: str,
        quantity: int,
        value_snapshot: int,
    ) -> None:
        """Persist a versioned item line in the offer or request."""
        await tx.execute(
            """INSERT INTO trade_items(trade_id, side, item_uid, item_id, quantity, value_snapshot)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (trade_id, side, item_uid, item_id, quantity, value_snapshot),
        )

    async def load_trade(self, tx: aiosqlite.Connection, trade_id: int) -> Optional[dict[str, Any]]:
        """Load one trade status, nonce, owners, and cash terms."""
        row = await self._one(tx, "SELECT * FROM trades WHERE trade_id = ? LIMIT 1", (trade_id,))
        return dict(row) if row is not None else None

    async def trade_users_read(self, trade_id: int) -> Optional[tuple[int, int]]:
        """Read the two lock keys needed before taking a trade-resolution lock."""
        row = await self.db.fetchone(
            "SELECT from_user_id, to_user_id FROM trades WHERE trade_id = ? LIMIT 1", (trade_id,)
        )
        return (int(row["from_user_id"]), int(row["to_user_id"])) if row is not None else None

    async def load_trade_items(self, tx: aiosqlite.Connection, trade_id: int) -> list[dict[str, Any]]:
        """Load every originally requested or offered line, including stale references."""
        rows = await self._all(
            tx, "SELECT * FROM trade_items WHERE trade_id = ? ORDER BY side, trade_item_id", (trade_id,)
        )
        return [dict(row) for row in rows]

    async def set_trade_status(
        self,
        tx: aiosqlite.Connection,
        trade_id: int,
        *,
        status: str,
        resolved_at: int,
        outcome_message: str,
    ) -> None:
        """Set one trade's terminal status inside the current transaction."""
        await tx.execute(
            """UPDATE trades SET status = ?, resolved_at = ?, outcome_message = ?
               WHERE trade_id = ? AND status = 'pending'""",
            (status, resolved_at, outcome_message, trade_id),
        )

    async def unlock_trade_items(self, tx: aiosqlite.Connection, trade_id: int) -> None:
        """Unlock all extant item lots offered by a trade after its terminal result."""
        await tx.execute(
            """UPDATE family_assets SET is_locked = 0
               WHERE is_locked = 1 AND asset_id IN (
                   SELECT item_uid FROM trade_items WHERE trade_id = ? AND side = 'offer'
               )""",
            (trade_id,),
        )

    async def expired_trade_ids(self, now: int) -> list[dict[str, int]]:
        """Read pending trades whose ten-minute deadline has passed."""
        rows = await self.db.fetchall(
            "SELECT trade_id, from_user_id, to_user_id FROM trades WHERE status = 'pending' AND expires_at <= ? ORDER BY trade_id",
            (now,),
        )
        return [dict(row) for row in rows]

    async def trade_history(self, tx: aiosqlite.Connection, user_id: int, limit: int = 20) -> list[dict[str, Any]]:
        """List a player's recent outgoing and incoming trades."""
        rows = await self._all(
            tx,
            """SELECT trade_id, from_user_id, to_user_id, offer_cash, request_cash, status,
                      created_at, expires_at, resolved_at, outcome_message, imbalance_flag
               FROM trades WHERE from_user_id = ? OR to_user_id = ?
               ORDER BY created_at DESC, trade_id DESC LIMIT ?""",
            (user_id, user_id, max(1, min(50, int(limit)))),
        )
        return [dict(row) for row in rows]

    async def insert_audit(
        self,
        tx: aiosqlite.Connection,
        *,
        now: int,
        user_id: Optional[int],
        char_id: Optional[int],
        action: str,
        amount: Optional[int],
        details: dict[str, Any],
    ) -> None:
        """Write a structured financial or anti-exploit audit record."""
        await tx.execute(
            """INSERT INTO audit_log(ts, user_id, char_id, action, amount, details_json)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (now, user_id, char_id, action, amount,
             json.dumps(details, sort_keys=True, separators=(",", ":"), allow_nan=False)),
        )

    async def create_loan_for_item(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        loan_type: str,
        principal: int,
        annual_payment: int,
        term_years: int,
        asset_id: int,
    ) -> int:
        """Insert a zero-interest secured loan for an already-created asset."""
        return await self.create_loan(
            tx, char_id=char_id, loan_type=loan_type, principal=principal,
            annual_payment=annual_payment, term_years=term_years,
            collateral_item_uid=asset_id,
        )

    async def has_front_business(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check new business assets and the legacy Stage 7 crime-career front."""
        return await self._one(
            tx,
            """SELECT 1 FROM family_assets WHERE char_id = ? AND kind = 'item'
                 AND item_id IN ('front_business', 'laundromat', 'car_wash', 'nightclub')
                 AND quantity > 0 AND is_liquidated = 0 LIMIT 1""",
            (char_id,),
        ) is not None

    async def set_front_business_flag(self, tx: aiosqlite.Connection, char_id: int, enabled: bool) -> None:
        """Keep Stage 7 laundering access synchronized with owned front businesses."""
        await tx.execute("UPDATE crime_profiles SET front_business = ? WHERE char_id = ?", (int(enabled), char_id))

    async def list_housing_assets(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return active housing lots for primary-home reconciliation."""
        rows = await self._all(
            tx,
            """SELECT * FROM family_assets WHERE char_id = ? AND kind = 'item'
                 AND item_id IN ('trailer', 'starter_home', 'suburban_house', 'townhouse',
                                 'luxury_villa', 'mansion', 'private_island')
                 AND quantity > 0 AND is_liquidated = 0
               ORDER BY current_value DESC, asset_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def due_pending_trade(self, tx: aiosqlite.Connection, trade_id: int, now: int) -> Optional[dict[str, Any]]:
        """Recheck one candidate expiry while holding both player locks."""
        row = await self._one(
            tx,
            "SELECT * FROM trades WHERE trade_id = ? AND status = 'pending' AND expires_at <= ? LIMIT 1",
            (trade_id, now),
        )
        return dict(row) if row is not None else None
````

## `lifeline/core/shop.py`

````python
"""Stage 8 shop, inventory, secured purchases, and atomic player trading."""
from __future__ import annotations

import copy
import json
import logging
import secrets
import time
from contextlib import AsyncExitStack, asynccontextmanager
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_FLOOR
from typing import Any, AsyncContextManager, AsyncIterator, Callable, Mapping, Optional

from .data_loader import DataLoader
from .db import DatabaseManager
from .errors import (
    CharacterDead,
    CharacterInPrison,
    CharacterNotFound,
    ConcurrentUpdate,
    InsufficientFunds,
    StaleShopQuote,
    TradeNotFound,
    ValidationError,
)
from .locks import UserLockRegistry
from .models import Character, HousingType, Stats
from .money import format_cents, validate_cents
from .repositories.shop import ShopRepository
from .rng import RNG

logger = logging.getLogger("lifeline.shop")
TRADE_TTL_SECONDS = 10 * 60
TRADE_DAILY_LIMIT = 5
TRADE_TAX_PERCENT = 5
IMBALANCE_BASE_CENTS = 10_000_000
ACCOUNT_AGE_REQUIRED_SECONDS = 7 * 24 * 60 * 60


@dataclass(frozen=True, slots=True)
class ShopQuote:
    """Versioned price snapshot shown before a purchase confirmation."""

    user_id: int
    char_id: int
    item_id: str
    item_name: str
    quantity: int
    unit_price: int
    total_price: int
    balance: int
    version: int
    nonce: str
    expires_at: int
    age: int
    can_pay_cash: bool
    finance_type: Optional[str]
    down_payment: int
    loan_principal: int
    loan_term_years: int


@dataclass(frozen=True, slots=True)
class PurchaseReceipt:
    """Summary of a completed shop purchase."""

    item_id: str
    item_name: str
    quantity: int
    total_price: int
    paid_now: int
    loan_principal: int
    asset_id: int
    remaining_balance: int


@dataclass(frozen=True, slots=True)
class SaleReceipt:
    """Summary of item liquidation using the item's stored market value."""

    item_id: str
    item_name: str
    quantity: int
    payout: int
    remaining_balance: int


@dataclass(frozen=True, slots=True)
class UseReceipt:
    """Summary of item use and any random in-game payout."""

    item_id: str
    item_name: str
    quantity_remaining: int
    payout: int
    stats: Stats


@dataclass(frozen=True, slots=True)
class TradeReceipt:
    """Persisted trade proposal with its nonce and immutable terms."""

    trade_id: int
    nonce: str
    created_at: int
    expires_at: int
    from_user_id: int
    to_user_id: int
    offer_cash: int
    request_cash: int
    offer_items: tuple[tuple[str, int], ...]
    request_items: tuple[tuple[str, int], ...]
    imbalance_flag: bool


@dataclass(frozen=True, slots=True)
class TradeResult:
    """Terminal or still-pending response to a trade button or command."""

    success: bool
    status: str
    message: str


@dataclass(frozen=True, slots=True)
class ShopYearProgress:
    """Stage 8 effects applied by the existing yearly age transaction."""

    character: Character
    messages: tuple[str, ...] = ()
    business_income: int = 0


class ShopService:
    """Transactional shop and trading domain service for the Discord bot."""

    def __init__(
        self,
        db: DatabaseManager,
        rng: RNG,
        locks: Optional[UserLockRegistry] = None,
        *,
        clock: Callable[[], float] = time.time,
        data_loader: Optional[DataLoader] = None,
    ) -> None:
        self.db = db
        self.rng = rng
        self.locks = locks or UserLockRegistry()
        self.clock = clock
        self.repository = ShopRepository(db)
        loader = data_loader or DataLoader()
        document = loader.load_items()
        self.items: dict[str, dict[str, Any]] = {str(item["id"]): item for item in document["items"]}
        self.categories: tuple[str, ...] = tuple(sorted({str(item["category"]) for item in document["items"]}))

    def get_item(self, item_id: str) -> Optional[dict[str, Any]]:
        """Return a defensive item definition by its stable catalog ID."""
        item = self.items.get(str(item_id).strip().lower())
        return copy.deepcopy(item) if item is not None else None

    async def register_player(self, user_id: int, account_created_at: int) -> None:
        """Record a Discord account's original creation timestamp for anti-abuse checks."""
        if isinstance(user_id, bool) or not isinstance(user_id, int) or user_id <= 0:
            raise ValidationError("A valid Discord user is required.")
        if isinstance(account_created_at, bool) or not isinstance(account_created_at, int) or account_created_at < 0:
            raise ValidationError("A valid account creation time is required.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                await self.repository.insert_player(tx, user_id, account_created_at)

    async def browse(self, user_id: int, category: Optional[str] = None) -> list[dict[str, Any]]:
        """Return shop-visible catalog entries after validating the active life."""
        selected_category = str(category).strip().lower() if category else None
        if selected_category is not None and selected_category not in self.categories:
            raise ValidationError("That shop category does not exist.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                return [
                    {**dict(item), "price_cents": self._charge(int(item["base_price_cents"]), character.price_index)}
                    for item in self.items.values()
                    if item["shop_available"] and (selected_category is None or item["category"] == selected_category)
                ]

    async def quote_purchase(self, user_id: int, item_id: str, quantity: int = 1) -> ShopQuote:
        """Create a read-only, versioned quote for a single shop purchase."""
        item = self._catalog_item(item_id)
        if not item["shop_available"]:
            raise ValidationError("That item is not sold in the shop.")
        selected_quantity = self._validate_quantity(item, quantity)
        now = int(self.clock())
        quote_nonce = secrets.token_urlsafe(20)
        expires_at = now + 120
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._active_character(tx, user_id)
                self._check_not_prison(character)
                self._check_age(character, int(item["min_age"]), f"buy {item['name']}")
                owned = await self.repository.count_item_quantity(tx, character.char_id, item["id"])
                if owned + selected_quantity > int(item["max_quantity"]):
                    raise ValidationError(f"You can own at most {item['max_quantity']} of {item['name']} at a time.")
                unit_price = self._charge(int(item["base_price_cents"]), character.price_index)
                total_price = unit_price * selected_quantity
                validate_cents(total_price)
                finance_type, down_payment, principal, term = await self._financing_terms(tx, character, item, total_price)
                await self.repository.save_shop_quote(
                    tx, char_id=character.char_id, nonce=quote_nonce, item_id=str(item["id"]),
                    quantity=selected_quantity,
                    total_price=total_price,
                    balance_cents=character.cash + character.bank,
                    character_version=version,
                    created_at=now,
                    expires_at=expires_at,
                )
                return ShopQuote(
                    user_id=user_id,
                    char_id=character.char_id,
                    item_id=str(item["id"]),
                    item_name=str(item["name"]),
                    quantity=selected_quantity,
                    unit_price=unit_price,
                    total_price=total_price,
                    balance=character.cash + character.bank,
                    version=version,
                    nonce=quote_nonce,
                    expires_at=expires_at,
                    age=character.age,
                    can_pay_cash=character.cash + character.bank >= total_price,
                    finance_type=finance_type,
                    down_payment=down_payment,
                    loan_principal=principal,
                    loan_term_years=term,
                )

    async def purchase(
        self,
        user_id: int,
        item_id: str,
        quantity: int,
        *,
        expected_version: int,
        expected_total: int,
        nonce: str,
        payment_method: str = "cash",
        expected_down_payment: Optional[int] = None,
    ) -> PurchaseReceipt:
        """Complete a cash or secured item purchase against its versioned quote."""
        item = self._catalog_item(item_id)
        selected_quantity = self._validate_quantity(item, quantity)
        method = str(payment_method).strip().lower()
        if method not in {"cash", "finance"}:
            raise ValidationError("Choose cash or financing.")
        validate_cents(expected_total)
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._active_character(tx, user_id)
                self._check_not_prison(character)
                self._check_age(character, int(item["min_age"]), f"buy {item['name']}")
                quote = await self.repository.load_shop_quote(tx, character.char_id, nonce, now)
                if (
                    quote is None
                    or version != expected_version
                    or int(quote["character_version"]) != expected_version
                    or str(quote["item_id"]) != str(item["id"])
                    or int(quote["quantity"]) != selected_quantity
                    or int(quote["total_price"]) != expected_total
                    or int(quote["balance_cents"]) != character.cash + character.bank
                ):
                    raise StaleShopQuote()
                if not item["shop_available"]:
                    raise ValidationError("That item is not sold in the shop.")
                owned = await self.repository.count_item_quantity(tx, character.char_id, item["id"])
                if owned + selected_quantity > int(item["max_quantity"]):
                    raise ValidationError(f"You can own at most {item['max_quantity']} of {item['name']} at a time.")
                unit_price = self._charge(int(item["base_price_cents"]), character.price_index)
                total_price = unit_price * selected_quantity
                if total_price != expected_total:
                    raise StaleShopQuote()

                finance_type: Optional[str] = None
                down_payment = total_price
                principal = 0
                term_years = 0
                if method == "cash":
                    if character.cash + character.bank < total_price:
                        raise InsufficientFunds("You do not have enough cash and bank balance for that purchase.")
                else:
                    finance_type, down_payment, principal, term_years = await self._financing_terms(
                        tx, character, item, total_price
                    )
                    if finance_type is None:
                        raise ValidationError("This item is not eligible for mortgage or auto financing.")
                    if expected_down_payment is not None and expected_down_payment != down_payment:
                        raise StaleShopQuote()
                    if character.cash + character.bank < down_payment:
                        raise InsufficientFunds("You do not have enough available funds for the required down payment.")

                paid_now = total_price if method == "cash" else down_payment
                await self.repository.consume_shop_quote(tx, character.char_id, nonce)
                updated = self._deduct_funds(character, paid_now)
                updated = self._apply_effects(updated, item["effects_on_buy"], selected_quantity)
                asset_id = await self.repository.insert_item(
                    tx,
                    char_id=character.char_id,
                    item_id=str(item["id"]),
                    quantity=selected_quantity,
                    purchase_price=total_price,
                    current_value=total_price,
                    age=character.age,
                    now=now,
                )
                if method == "finance":
                    annual_payment = self._divide_up(principal, term_years)
                    await self.repository.create_loan_for_item(
                        tx,
                        char_id=character.char_id,
                        loan_type=str(finance_type),
                        principal=principal,
                        annual_payment=annual_payment,
                        term_years=term_years,
                        asset_id=asset_id,
                    )
                    updated = replace(updated, debt_total=updated.debt_total + principal)
                if item["category"] == "housing":
                    updated = replace(
                        updated,
                        housing_type=HousingType.OWNED,
                        housing_item_id=asset_id,
                        rent_amount=0,
                    )
                updated = replace(updated, version=version + 1)
                await self.repository.save_character(tx, updated, version)
                if item["category"] == "business":
                    await self.repository.set_front_business_flag(tx, character.char_id, True)
                await self.repository.insert_audit(
                    tx,
                    now=now,
                    user_id=user_id,
                    char_id=character.char_id,
                    action="shop_purchase",
                    amount=total_price,
                    details={
                        "item_id": item["id"],
                        "quantity": selected_quantity,
                        "payment_method": method,
                        "down_payment": paid_now,
                        "loan_principal": principal,
                        "asset_id": asset_id,
                    },
                )
                return PurchaseReceipt(
                    item_id=str(item["id"]),
                    item_name=str(item["name"]),
                    quantity=selected_quantity,
                    total_price=total_price,
                    paid_now=paid_now,
                    loan_principal=principal,
                    asset_id=asset_id,
                    remaining_balance=updated.cash + updated.bank,
                )

    async def inventory(self, user_id: int) -> tuple[Character, list[dict[str, Any]]]:
        """Return one active character's live item rows, including lock/collateral state."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                assets = await self.repository.list_items(tx, character.char_id)
                return character, [self._inventory_display(row) for row in assets]

    async def sell(self, user_id: int, item_id: str, quantity: int = 1) -> SaleReceipt:
        """Sell unlocked items using only their stored current market values."""
        item = self._catalog_item(item_id)
        selected_quantity = self._validate_quantity(item, quantity)
        if item["category"] in {"license", "title", "weapon"} or item["crime_event_only"]:
            raise ValidationError("That item cannot be sold through the shop.")
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._active_character(tx, user_id)
                self._check_not_prison(character)
                rows = await self.repository.list_items(tx, character.char_id)
                candidates = [
                    row for row in rows
                    if row["item_id"] == item["id"] and not bool(row["is_locked"])
                    and not bool(row["collateralized"])
                ]
                available = sum(int(row["quantity"]) for row in candidates)
                if available < selected_quantity:
                    locked = any(row["item_id"] == item["id"] and bool(row["is_locked"]) for row in rows)
                    collateral = any(row["item_id"] == item["id"] and bool(row["collateralized"]) for row in rows)
                    if locked:
                        raise ValidationError("Items locked in a pending trade cannot be sold.")
                    if collateral:
                        raise ValidationError("Settle the collateral loan before selling that item.")
                    raise ValidationError("You do not own enough unlocked copies of that item to sell.")

                total_value = 0
                left = selected_quantity
                for row in candidates:
                    if left == 0:
                        break
                    selected = min(left, int(row["quantity"]))
                    portion = await self.repository.reduce_item(
                        tx,
                        asset_id=int(row["asset_id"]),
                        owner_char_id=character.char_id,
                        quantity=selected,
                    )
                    if portion is None:
                        raise ConcurrentUpdate("An item changed while the sale was processing. Please retry.")
                    total_value += int(portion["current_value"])
                    left -= selected
                multiplier = Decimal("0.94") if item["category"] == "housing" else Decimal("0.85")
                payout = self._payout(total_value, multiplier)
                updated = replace(character, cash=character.cash + payout, version=version + 1)
                if item["category"] == "housing":
                    updated = await self._reconcile_housing(tx, updated, now)
                await self.repository.save_character(tx, updated, version)
                if item["category"] == "business":
                    await self.repository.set_front_business_flag(
                        tx, character.char_id, await self.repository.has_front_business(tx, character.char_id)
                    )
                await self.repository.insert_audit(
                    tx,
                    now=now,
                    user_id=user_id,
                    char_id=character.char_id,
                    action="inventory_sell",
                    amount=payout,
                    details={"item_id": item["id"], "quantity": selected_quantity, "market_value": total_value},
                )
                return SaleReceipt(item["id"], item["name"], selected_quantity, payout, updated.cash + updated.bank)

    async def use(self, user_id: int, item_id: str) -> UseReceipt:
        """Apply one item-use effect, consuming one unit for consumables."""
        item = self._catalog_item(item_id)
        if not item["usable"]:
            raise ValidationError("That item has no use action.")
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._active_character(tx, user_id)
                self._check_not_prison(character)
                self._check_age(character, int(item["min_age"]), f"use {item['name']}")
                rows = await self.repository.list_items(tx, character.char_id)
                candidates = [
                    row for row in rows if row["item_id"] == item["id"]
                    and not bool(row["is_locked"]) and not bool(row["collateralized"])
                ]
                if not candidates:
                    if any(row["item_id"] == item["id"] and bool(row["is_locked"]) for row in rows):
                        raise ValidationError("Items locked in a pending trade cannot be used.")
                    raise ValidationError("You do not have an unlocked copy of that item.")
                asset = candidates[0]
                asset_id = int(asset["asset_id"])
                if not item["consumable"] and await self.repository.has_used_item(tx, asset_id, character.age):
                    raise ValidationError("You have already used this item during the current in-game year.")
                if item["consumable"]:
                    consumed = await self.repository.reduce_item(
                        tx, asset_id=asset_id, owner_char_id=character.char_id, quantity=1
                    )
                    if consumed is None:
                        raise ConcurrentUpdate("An item changed while the use action was processing. Please retry.")
                else:
                    await self.repository.record_item_use(tx, asset_id, character.age, now)
                updated = self._apply_effects(character, item["effects_on_use"], 1)
                payout_range = item["effects_on_use"].get("payout_range_cents")
                payout = 0
                if payout_range is not None:
                    payout = self.rng.randint(int(payout_range[0]), int(payout_range[1]))
                    updated = replace(updated, cash=updated.cash + payout)
                updated = replace(updated, version=version + 1)
                await self.repository.save_character(tx, updated, version)
                await self.repository.insert_audit(
                    tx,
                    now=now,
                    user_id=user_id,
                    char_id=character.char_id,
                    action="inventory_use",
                    amount=payout,
                    details={"item_id": item["id"], "asset_id": asset_id, "consumed": bool(item["consumable"])},
                )
                remaining = int(asset["quantity"]) - (1 if item["consumable"] else 0)
                return UseReceipt(item["id"], item["name"], remaining, payout, updated.stats)

    async def award_crime_event_item(self, user_id: int, item_id: str, quantity: int = 1) -> int:
        """Grant a legal, age-eligible crime-event-only item without exposing weapon purchases."""
        item = self._catalog_item(item_id)
        if not item["crime_event_only"] or item["category"] != "weapon":
            raise ValidationError("Only catalogued crime-event items can be awarded through this path.")
        selected_quantity = self._validate_quantity(item, quantity)
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._active_character(tx, user_id)
                self._check_not_prison(character)
                self._check_age(character, int(item["min_age"]), f"receive {item['name']}")
                if character.country.lower() not in {str(value) for value in item["legal_countries"]}:
                    raise ValidationError("That crime-event item is not legal in this character's country.")
                owned = await self.repository.count_item_quantity(tx, character.char_id, item["id"])
                if owned + selected_quantity > int(item["max_quantity"]):
                    raise ValidationError("The maximum quantity for that item has been reached.")
                item_value = self._charge(int(item["base_price_cents"]), character.price_index) * selected_quantity
                asset_id = await self.repository.insert_item(
                    tx, char_id=character.char_id, item_id=item["id"], quantity=selected_quantity,
                    purchase_price=0, current_value=item_value, age=character.age, now=now,
                )
                updated = replace(character, version=version + 1)
                await self.repository.save_character(tx, updated, version)
                await self.repository.insert_audit(
                    tx, now=now, user_id=user_id, char_id=character.char_id,
                    action="crime_event_item_award", amount=0,
                    details={"item_id": item["id"], "quantity": selected_quantity, "asset_id": asset_id},
                )
                return asset_id

    async def trade_candidates(self, from_user_id: int, to_user_id: int) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """Load both eligible adult inventories for the offer builder."""
        self._validate_distinct_users(from_user_id, to_user_id)
        async with self._hold_users((from_user_id, to_user_id)):
            async with self.db.transaction() as tx:
                characters = await self._load_trade_characters(tx, from_user_id, to_user_id)
                from_character = characters[from_user_id]
                to_character = characters[to_user_id]
                await self._validate_trade_player(tx, from_character)
                await self._validate_trade_player(tx, to_character)
                left = await self.repository.list_items(tx, from_character.char_id)
                right = await self.repository.list_items(tx, to_character.char_id)
                return self._tradeable_rows(left), self._tradeable_rows(right)

    async def create_trade(
        self,
        from_user_id: int,
        to_user_id: int,
        *,
        offered_items: Mapping[int, int],
        requested_items: Mapping[int, int],
        offer_cash: int = 0,
        request_cash: int = 0,
        nonce: Optional[str] = None,
    ) -> TradeReceipt:
        """Create a ten-minute offer, lock its offered items, and consume daily limits."""
        self._validate_distinct_users(from_user_id, to_user_id)
        offered = self._clean_item_quantities(offered_items)
        requested = self._clean_item_quantities(requested_items)
        sent_cash = self._validate_user_cash(offer_cash)
        received_cash = self._validate_user_cash(request_cash)
        if not offered and not requested and sent_cash == 0 and received_cash == 0:
            raise ValidationError("A trade must include at least one item or a nonzero cash amount.")
        now = int(self.clock())
        trade_nonce = nonce or secrets.token_urlsafe(24)
        day_key = datetime.fromtimestamp(now, tz=timezone.utc).strftime("%Y-%m-%d")
        async with self._hold_users((from_user_id, to_user_id)):
            async with self.db.transaction() as tx:
                characters = await self._load_trade_characters(tx, from_user_id, to_user_id)
                from_character = characters[from_user_id]
                to_character = characters[to_user_id]
                self._validate_trade_creation(from_character)
                self._validate_trade_creation(to_character)
                await self.repository.insert_player(tx, from_user_id, now)
                await self.repository.insert_player(tx, to_user_id, now)
                from_player = await self.repository.load_player(tx, from_user_id)
                to_player = await self.repository.load_player(tx, to_user_id)
                if from_player is None or to_player is None:
                    raise RuntimeError("trade player accounts could not be initialized")
                if bool(from_player["trade_banned"]) or bool(to_player["trade_banned"]):
                    raise ValidationError("A player in this trade is currently trade-banned.")
                if await self.repository.has_pending_outgoing(tx, from_user_id):
                    raise ValidationError("You already have a pending outgoing trade.")
                if await self.repository.trade_daily_count(tx, from_user_id, day_key) >= TRADE_DAILY_LIMIT:
                    raise ValidationError("You have reached the limit of five trades for today.")
                if await self.repository.trade_daily_count(tx, to_user_id, day_key) >= TRADE_DAILY_LIMIT:
                    raise ValidationError("The target player has reached the limit of five trades for today.")

                offered_rows = await self._validate_trade_lines(
                    tx, from_character, offered, expected_locked=False
                )
                requested_rows = await self._validate_trade_lines(
                    tx, to_character, requested, expected_locked=False
                )
                offer_value = sent_cash + sum(line["value"] for line in offered_rows)
                request_value = received_cash + sum(line["value"] for line in requested_rows)
                imbalance, receiver_id = self._imbalance_details(
                    offer_value, request_value, from_character, to_character, from_user_id, to_user_id
                )
                if imbalance:
                    receiver = from_player if receiver_id == from_user_id else to_player
                    created_at = int(receiver["created_at"])
                    if now - created_at < ACCOUNT_AGE_REQUIRED_SECONDS:
                        raise ValidationError("The higher-value side must go to a Discord account at least seven days old.")

                await self.repository.increment_trade_daily(tx, from_user_id, day_key)
                await self.repository.increment_trade_daily(tx, to_user_id, day_key)
                trade_id = await self.repository.create_trade(
                    tx,
                    from_user_id=from_user_id,
                    from_char_id=from_character.char_id,
                    to_user_id=to_user_id,
                    to_char_id=to_character.char_id,
                    offer_cash=sent_cash,
                    request_cash=received_cash,
                    now=now,
                    expires_at=now + TRADE_TTL_SECONDS,
                    nonce=trade_nonce,
                    imbalance_flag=imbalance,
                    imbalance_receiver_id=receiver_id,
                )
                for line in offered_rows:
                    await self.repository.add_trade_item(
                        tx, trade_id=trade_id, side="offer", item_uid=line["asset_id"],
                        item_id=line["item_id"], quantity=line["quantity"], value_snapshot=line["value"],
                    )
                for line in requested_rows:
                    await self.repository.add_trade_item(
                        tx, trade_id=trade_id, side="request", item_uid=line["asset_id"],
                        item_id=line["item_id"], quantity=line["quantity"], value_snapshot=line["value"],
                    )
                if offered and not await self.repository.lock_items(tx, from_character.char_id, tuple(offered)):
                    raise ValidationError("An offered item changed. Please rebuild the trade.")
                await self.repository.insert_audit(
                    tx,
                    now=now,
                    user_id=from_user_id,
                    char_id=from_character.char_id,
                    action="trade_offer_created",
                    amount=sent_cash + received_cash,
                    details={
                        "trade_id": trade_id,
                        "from_user_id": from_user_id,
                        "to_user_id": to_user_id,
                        "offered_item_uids": sorted(offered),
                        "requested_item_uids": sorted(requested),
                        "imbalance_flag": imbalance,
                        "imbalance_receiver_id": receiver_id,
                    },
                )
                if imbalance:
                    await self.repository.insert_audit(
                        tx,
                        now=now,
                        user_id=receiver_id,
                        char_id=(from_character.char_id if receiver_id == from_user_id else to_character.char_id),
                        action="trade_value_imbalance_flag",
                        amount=max(offer_value, request_value),
                        details={"trade_id": trade_id, "offer_value": offer_value, "request_value": request_value},
                    )
                return TradeReceipt(
                    trade_id=trade_id,
                    nonce=trade_nonce,
                    created_at=now,
                    expires_at=now + TRADE_TTL_SECONDS,
                    from_user_id=from_user_id,
                    to_user_id=to_user_id,
                    offer_cash=sent_cash,
                    request_cash=received_cash,
                    offer_items=tuple((str(line["item_id"]), int(line["quantity"])) for line in offered_rows),
                    request_items=tuple((str(line["item_id"]), int(line["quantity"])) for line in requested_rows),
                    imbalance_flag=imbalance,
                )

    async def accept_trade(self, trade_id: int, user_id: int, nonce: str) -> TradeResult:
        """Atomically accept a pending offer after re-fetching every life and item."""
        pair = await self.repository.trade_users_read(trade_id)
        if pair is None:
            raise TradeNotFound()
        if user_id != pair[1]:
            raise TradeNotFound("Only the target player can accept this trade.")
        now = int(self.clock())
        async with self._hold_users(pair):
            async with self.db.transaction() as tx:
                trade = await self.repository.load_trade(tx, trade_id)
                if trade is None:
                    raise TradeNotFound()
                if int(trade["to_user_id"]) != user_id:
                    raise TradeNotFound("Only the target player can accept this trade.")
                if trade["status"] != "pending":
                    return TradeResult(False, str(trade["status"]), str(trade["outcome_message"] or "This trade was already resolved."))
                if str(trade["nonce"]) != str(nonce):
                    return await self._fail_trade(tx, trade, now, "This trade confirmation was stale or invalid.")
                if int(trade["expires_at"]) <= now:
                    return await self._expire_trade(tx, trade, now)

                from_user = int(trade["from_user_id"])
                to_user = int(trade["to_user_id"])
                try:
                    characters = await self._load_trade_characters(tx, from_user, to_user, fail_not_found=True)
                except (CharacterDead, CharacterNotFound) as exc:
                    return await self._fail_trade(tx, trade, now, exc.message)
                from_character = characters[from_user]
                to_character = characters[to_user]
                if from_character.char_id != int(trade["from_char_id"]) or to_character.char_id != int(trade["to_char_id"]):
                    return await self._fail_trade(tx, trade, now, "A character life changed after the offer was made.")
                try:
                    self._validate_trade_creation(from_character)
                    self._validate_trade_creation(to_character)
                except (CharacterDead, CharacterInPrison, ValidationError) as exc:
                    return await self._fail_trade(tx, trade, now, exc.message)
                from_player = await self.repository.load_player(tx, from_user)
                to_player = await self.repository.load_player(tx, to_user)
                if from_player is None or to_player is None or bool(from_player["trade_banned"]) or bool(to_player["trade_banned"]):
                    return await self._fail_trade(tx, trade, now, "A player is no longer eligible to trade.")

                trade_lines = await self.repository.load_trade_items(tx, trade_id)
                if not trade_lines and (int(trade["offer_cash"]) == 0 and int(trade["request_cash"]) == 0):
                    return await self._fail_trade(tx, trade, now, "The trade has no items or cash to exchange.")
                validated_lines: list[dict[str, Any]] = []
                for line in trade_lines:
                    side = str(line["side"])
                    expected_owner = from_character.char_id if side == "offer" else to_character.char_id
                    asset = await self.repository.load_item(tx, int(line["item_uid"]))
                    if asset is None:
                        return await self._fail_trade(tx, trade, now, "An item in the offer was sold or no longer exists.")
                    if int(asset["char_id"]) != expected_owner or str(asset["item_id"]) != str(line["item_id"]):
                        return await self._fail_trade(tx, trade, now, "An item's ownership changed after the offer was made.")
                    item = self.items.get(str(line["item_id"]))
                    if item is None or not item["tradeable"]:
                        return await self._fail_trade(tx, trade, now, "An item in the offer is no longer tradeable.")
                    if bool(asset["collateralized"]):
                        return await self._fail_trade(tx, trade, now, "An item is now encumbered by an active collateral loan.")
                    if int(asset["quantity"]) < int(line["quantity"]):
                        return await self._fail_trade(tx, trade, now, "An item's available quantity changed after the offer was made.")
                    expected_locked = side == "offer"
                    if bool(asset["is_locked"]) != expected_locked:
                        return await self._fail_trade(tx, trade, now, "An item's lock state changed after the offer was made.")
                    current_value = self._portion(
                        int(asset["current_value"]), int(line["quantity"]), int(asset["quantity"])
                    )
                    validated_lines.append({
                        **dict(line),
                        "asset": asset,
                        "item": item,
                        "current_value": current_value,
                    })

                counts_from = await self.repository.list_items(tx, from_character.char_id)
                counts_to = await self.repository.list_items(tx, to_character.char_id)
                count_from = self._item_totals(counts_from)
                count_to = self._item_totals(counts_to)
                for line in validated_lines:
                    item_id = str(line["item_id"])
                    quantity = int(line["quantity"])
                    if line["side"] == "offer":
                        count_from[item_id] = count_from.get(item_id, 0) - quantity
                        count_to[item_id] = count_to.get(item_id, 0) + quantity
                    else:
                        count_to[item_id] = count_to.get(item_id, 0) - quantity
                        count_from[item_id] = count_from.get(item_id, 0) + quantity
                for item_id, count in count_from.items():
                    definition = self.items.get(item_id)
                    if definition is not None and count > int(definition["max_quantity"]):
                        return await self._fail_trade(tx, trade, now, "The sender would exceed the catalog quantity limit.")
                for item_id, count in count_to.items():
                    definition = self.items.get(item_id)
                    if definition is not None and count > int(definition["max_quantity"]):
                        return await self._fail_trade(tx, trade, now, "The recipient would exceed the catalog quantity limit.")

                offer_cash = int(trade["offer_cash"])
                request_cash = int(trade["request_cash"])
                offer_tax = self._percent_charge(offer_cash, TRADE_TAX_PERCENT)
                request_tax = self._percent_charge(request_cash, TRADE_TAX_PERCENT)
                from_due = offer_cash + offer_tax
                to_due = request_cash + request_tax
                if from_character.cash < from_due:
                    return await self._fail_trade(tx, trade, now, "The offerer no longer has enough cash for the transfer and trade tax.")
                if to_character.cash < to_due:
                    return await self._fail_trade(tx, trade, now, "The recipient no longer has enough cash for the transfer and trade tax.")

                offer_value = offer_cash + sum(int(line["current_value"]) for line in validated_lines if line["side"] == "offer")
                request_value = request_cash + sum(int(line["current_value"]) for line in validated_lines if line["side"] == "request")
                imbalance, receiver_id = self._imbalance_details(
                    offer_value, request_value, from_character, to_character, from_user, to_user
                )
                if imbalance:
                    receiver = from_player if receiver_id == from_user else to_player
                    if now - int(receiver["created_at"]) < ACCOUNT_AGE_REQUIRED_SECONDS:
                        return await self._fail_trade(tx, trade, now, "The high-value recipient account is too new for this imbalanced trade.")
                    if not bool(trade["imbalance_flag"]):
                        await self.repository.insert_audit(
                            tx, now=now, user_id=receiver_id,
                            char_id=(from_character.char_id if receiver_id == from_user else to_character.char_id),
                            action="trade_value_imbalance_flag", amount=max(offer_value, request_value),
                            details={"trade_id": trade_id, "offer_value": offer_value, "request_value": request_value},
                        )

                updated_from = replace(
                    from_character,
                    cash=from_character.cash - from_due + request_cash,
                    version=from_character.version + 1,
                )
                updated_to = replace(
                    to_character,
                    cash=to_character.cash - to_due + offer_cash,
                    version=to_character.version + 1,
                )
                # The savepoint keeps the terminal failure path all-or-nothing if a guarded update fails.
                await self.repository.begin_trade_item_transfers(tx)
                await self.repository.unlock_trade_items(tx, trade_id)
                for line in validated_lines:
                    side = str(line["side"])
                    sender = from_character if side == "offer" else to_character
                    recipient = to_character if side == "offer" else from_character
                    moved = await self.repository.transfer_item(
                        tx,
                        asset_id=int(line["item_uid"]),
                        from_char_id=sender.char_id,
                        to_char_id=recipient.char_id,
                        quantity=int(line["quantity"]),
                        to_age=recipient.age,
                        now=now,
                    )
                    if moved is None:
                        await self.repository.rollback_trade_item_transfers(tx)
                        return await self._fail_trade(tx, trade, now, "An item changed while the trade was being accepted.")
                await self.repository.finish_trade_item_transfers(tx)
                updated_from = await self._reconcile_housing(tx, updated_from, now)
                updated_to = await self._reconcile_housing(tx, updated_to, now)
                await self.repository.save_character(tx, updated_from, from_character.version)
                await self.repository.save_character(tx, updated_to, to_character.version)
                await self.repository.set_front_business_flag(
                    tx, from_character.char_id, await self.repository.has_front_business(tx, from_character.char_id)
                )
                await self.repository.set_front_business_flag(
                    tx, to_character.char_id, await self.repository.has_front_business(tx, to_character.char_id)
                )
                await self.repository.set_trade_status(
                    tx, trade_id, status="accepted", resolved_at=now,
                    outcome_message="Trade completed successfully.",
                )
                await self.repository.unlock_trade_items(tx, trade_id)
                await self.repository.insert_audit(
                    tx,
                    now=now,
                    user_id=to_user,
                    char_id=to_character.char_id,
                    action="trade_accepted",
                    amount=offer_cash + request_cash,
                    details={
                        "trade_id": trade_id,
                        "offer_cash": offer_cash,
                        "request_cash": request_cash,
                        "offer_tax": offer_tax,
                        "request_tax": request_tax,
                        "item_lines": [
                            {"side": line["side"], "item_id": line["item_id"], "quantity": line["quantity"]}
                            for line in validated_lines
                        ],
                        "imbalance_flag": imbalance,
                    },
                )
                return TradeResult(
                    True,
                    "accepted",
                    f"Trade completed. Cash tax: {format_cents(offer_tax + request_tax)}.",
                )

    async def decline_trade(self, trade_id: int, user_id: int, nonce: str) -> TradeResult:
        """Decline a pending offer and release its locked items."""
        return await self._resolve_non_accept(trade_id, user_id, nonce, expected_side="target", status="declined")

    async def cancel_trade(self, trade_id: int, user_id: int, nonce: Optional[str] = None) -> TradeResult:
        """Cancel the caller's pending outgoing offer and release its item locks."""
        return await self._resolve_non_accept(trade_id, user_id, nonce, expected_side="sender", status="cancelled")

    async def _resolve_non_accept(
        self,
        trade_id: int,
        user_id: int,
        nonce: Optional[str],
        *,
        expected_side: str,
        status: str,
    ) -> TradeResult:
        """Serialize one decline/cancel transition with a concurrent acceptance."""
        pair = await self.repository.trade_users_read(trade_id)
        if pair is None:
            raise TradeNotFound()
        expected_user = pair[1] if expected_side == "target" else pair[0]
        if user_id != expected_user:
            raise TradeNotFound("Only the player who owns this trade action can resolve it.")
        now = int(self.clock())
        async with self._hold_users(pair):
            async with self.db.transaction() as tx:
                trade = await self.repository.load_trade(tx, trade_id)
                if trade is None:
                    raise TradeNotFound()
                expected_user = int(trade["to_user_id"] if expected_side == "target" else trade["from_user_id"])
                if user_id != expected_user:
                    raise TradeNotFound("Only the player who owns this trade action can resolve it.")
                if trade["status"] != "pending":
                    return TradeResult(False, str(trade["status"]), str(trade["outcome_message"] or "This trade was already resolved."))
                active_row = await self.repository.load_active(tx, user_id)
                expected_char_id = int(trade["to_char_id"] if expected_side == "target" else trade["from_char_id"])
                if active_row is None:
                    return await self._fail_trade(tx, trade, now, "The player no longer has a living active character.")
                active_character = Character.from_dict(json.loads(active_row["data_json"]))
                if int(active_row["char_id"]) != expected_char_id or not active_character.is_alive:
                    return await self._fail_trade(tx, trade, now, "The active character changed after the offer was made.")
                if active_character.age < 18 or active_character.age < 5:
                    return await self._fail_trade(tx, trade, now, "The player no longer meets the adult trade age gate.")
                if nonce is not None and str(trade["nonce"]) != str(nonce):
                    return await self._fail_trade(tx, trade, now, "This trade confirmation was stale or invalid.")
                if int(trade["expires_at"]) <= now:
                    return await self._expire_trade(tx, trade, now)
                message = "Trade declined; offered items were unlocked." if status == "declined" else "Trade cancelled; offered items were unlocked."
                await self.repository.set_trade_status(
                    tx, trade_id, status=status, resolved_at=now, outcome_message=message
                )
                await self.repository.unlock_trade_items(tx, trade_id)
                await self.repository.insert_audit(
                    tx, now=now, user_id=user_id,
                    char_id=int(trade["to_char_id"] if expected_side == "target" else trade["from_char_id"]),
                    action=f"trade_{status}", amount=None, details={"trade_id": trade_id},
                )
                return TradeResult(True, status, message)

    async def expire_pending(self) -> int:
        """Expire due trade proposals; callers should also log uncaught loop errors."""
        now = int(self.clock())
        candidates = await self.repository.expired_trade_ids(now)
        expired = 0
        for candidate in candidates:
            pair = (int(candidate["from_user_id"]), int(candidate["to_user_id"]))
            async with self._hold_users(pair):
                async with self.db.transaction() as tx:
                    trade = await self.repository.due_pending_trade(tx, int(candidate["trade_id"]), now)
                    if trade is None:
                        continue
                    await self.repository.set_trade_status(
                        tx, int(trade["trade_id"]), status="expired", resolved_at=now,
                        outcome_message="Trade expired after ten minutes; offered items were unlocked.",
                    )
                    await self.repository.unlock_trade_items(tx, int(trade["trade_id"]))
                    await self.repository.insert_audit(
                        tx, now=now, user_id=int(trade["from_user_id"]),
                        char_id=int(trade["from_char_id"]), action="trade_expired", amount=None,
                        details={"trade_id": int(trade["trade_id"])},
                    )
                    expired += 1
        return expired

    async def trade_history(self, user_id: int) -> tuple[Character, list[dict[str, Any]]]:
        """Return the active character and its recent trade history."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                return character, await self.repository.trade_history(tx, user_id)

    async def advance_year(self, tx: Any, character: Character, *, now: int) -> ShopYearProgress:
        """Apply item markets, upkeep, business income, and non-prison loan payments."""
        if not character.is_alive:
            return ShopYearProgress(character)
        messages: list[str] = []
        assets = await self.repository.list_items(tx, character.char_id)
        updated = character
        for asset in assets:
            item = self.items.get(str(asset["item_id"]))
            if item is None or int(asset["current_value"]) <= 0:
                continue
            mean_return = -float(item["depreciation_rate_per_year"])
            volatility = float(item["market_volatility"])
            annual_return = self.rng.gauss(mean_return, volatility) if volatility > 0 else mean_return
            annual_return = max(-0.95, min(1.0, annual_return))
            new_value = max(0, int((Decimal(int(asset["current_value"])) * (Decimal("1") + Decimal(str(annual_return)))).to_integral_value(rounding=ROUND_FLOOR)))
            if new_value != int(asset["current_value"]):
                await self.repository.set_item_value(tx, int(asset["asset_id"]), new_value)
                messages.append(f"{item['name']} market value changed to {format_cents(new_value)}.")

        if updated.in_prison:
            return ShopYearProgress(updated, tuple(messages), 0)

        business_income = 0
        for asset in assets:
            item = self.items.get(str(asset["item_id"]))
            if item is None or item["category"] != "business":
                continue
            per_item_income = self._payout(int(item["yearly_effects"]["income_cents"]), Decimal(str(updated.price_index)))
            income = per_item_income * int(asset["quantity"])
            if income:
                updated = replace(updated, bank=updated.bank + income)
                business_income += income
                messages.append(f"{item['name']} earned {format_cents(income)} in annual business income.")

        stat_deltas: dict[str, int] = {}
        for asset in assets:
            item = self.items.get(str(asset["item_id"]))
            if item is None:
                continue
            quantity = int(asset["quantity"])
            upkeep = self._charge(int(item["yearly_upkeep_cents"]), updated.price_index) * quantity
            paid = min(upkeep, max(0, updated.cash) + max(0, updated.bank))
            if paid:
                updated = self._deduct_funds(updated, paid)
            if paid < upkeep:
                messages.append(f"You could not fully cover {item['name']} upkeep of {format_cents(upkeep)}.")
                continue
            for stat, delta in item["yearly_effects"]["stats"].items():
                stat_deltas[stat] = stat_deltas.get(stat, 0) + int(delta) * quantity
        if stat_deltas:
            stats = replace(updated.stats)
            for stat, delta in stat_deltas.items():
                setattr(stats, stat, getattr(stats, stat) + delta)
            updated = replace(updated, stats=stats.clamp_all())

        for loan in await self.repository.active_loans(tx, updated.char_id):
            if str(loan["loan_type"]) not in {"mortgage", "auto"} or int(loan.get("principal", 0)) <= 0:
                continue
            payment = min(int(loan["annual_payment"]), int(loan["balance"]))
            if payment <= 0:
                continue
            if updated.cash + updated.bank >= payment:
                updated = self._deduct_funds(updated, payment)
                updated = replace(updated, debt_total=max(0, updated.debt_total - payment))
                await self.repository.pay_loan(tx, int(loan["loan_id"]), payment)
                messages.append(f"A secured loan payment of {format_cents(payment)} was made.")
            else:
                await self.repository.miss_loan_payment(tx, int(loan["loan_id"]))
                messages.append("A secured loan payment was missed because available funds were not enough.")

        has_front = await self.repository.has_front_business(tx, updated.char_id)
        await self.repository.set_front_business_flag(tx, updated.char_id, has_front)
        return ShopYearProgress(updated, tuple(messages), business_income)

    async def _fail_trade(self, tx: Any, trade: dict[str, Any], now: int, message: str) -> TradeResult:
        """Commit a failed trade state and unlock items instead of rolling back validation failures."""
        trade_id = int(trade["trade_id"])
        await self.repository.set_trade_status(tx, trade_id, status="failed", resolved_at=now, outcome_message=message)
        await self.repository.unlock_trade_items(tx, trade_id)
        await self.repository.insert_audit(
            tx, now=now, user_id=int(trade["to_user_id"]), char_id=int(trade["to_char_id"]),
            action="trade_failed", amount=None, details={"trade_id": trade_id, "reason": message},
        )
        return TradeResult(False, "failed", message)

    async def _expire_trade(self, tx: Any, trade: dict[str, Any], now: int) -> TradeResult:
        """Commit an expired status when an interaction arrives after its deadline."""
        trade_id = int(trade["trade_id"])
        message = "Trade expired after ten minutes; offered items were unlocked."
        await self.repository.set_trade_status(tx, trade_id, status="expired", resolved_at=now, outcome_message=message)
        await self.repository.unlock_trade_items(tx, trade_id)
        return TradeResult(False, "expired", message)

    async def _validate_trade_lines(
        self,
        tx: Any,
        character: Character,
        quantities: dict[int, int],
        *,
        expected_locked: bool,
    ) -> list[dict[str, Any]]:
        """Validate trade item ownership and return its value at the offer snapshot."""
        rows_by_id = {int(row["asset_id"]): row for row in await self.repository.list_items(tx, character.char_id)}
        result: list[dict[str, Any]] = []
        for asset_id, quantity in quantities.items():
            row = rows_by_id.get(asset_id)
            if row is None:
                raise ValidationError("A selected item is no longer in that player's inventory.")
            item = self.items.get(str(row["item_id"]))
            if item is None or not item["tradeable"]:
                raise ValidationError("One selected item is not tradeable.")
            if bool(row["is_locked"]) != expected_locked:
                raise ValidationError("A selected item is locked in another trade or unavailable.")
            if bool(row["collateralized"]):
                raise ValidationError("Items with an active collateral loan cannot be traded.")
            if quantity > int(row["quantity"]):
                raise ValidationError("A selected item quantity changed; rebuild the trade.")
            if not item["stackable"] and quantity != 1:
                raise ValidationError("Non-stackable items can only be traded one at a time.")
            value = self._portion(int(row["current_value"]), quantity, int(row["quantity"]))
            result.append({
                "asset_id": asset_id,
                "item_id": str(row["item_id"]),
                "quantity": quantity,
                "value": value,
            })
        return result

    async def _financing_terms(
        self,
        tx: Any,
        character: Character,
        item: dict[str, Any],
        total_price: int,
    ) -> tuple[Optional[str], int, int, int]:
        """Return approved loan type, down payment, principal, and fixed annual term."""
        if not item["collateral_eligible"] or item["category"] not in {"housing", "vehicle"}:
            return None, total_price, 0, 0
        if await self.repository.has_defaulted_or_delinquent_loan(tx, character.char_id):
            return None, total_price, 0, 0
        credit_score = int(character.stats.credit_score if character.stats.credit_score is not None else 650)
        if item["category"] == "housing":
            loan_type = "mortgage"
            minimum_credit = 650
            down_payment = self._percent_charge(total_price, 10)
            term_years = 30
        else:
            loan_type = "auto"
            minimum_credit = 600
            down_payment = self._percent_charge(total_price, 20)
            term_years = 5
        if credit_score < minimum_credit:
            return None, down_payment, 0, term_years
        principal = total_price - down_payment
        return loan_type, down_payment, principal, term_years

    def _catalog_item(self, item_id: str) -> dict[str, Any]:
        """Resolve and validate a stable catalog ID or raise a user-safe error."""
        if not isinstance(item_id, str):
            raise ValidationError("Choose an item from the catalog.")
        item = self.items.get(item_id.strip().lower())
        if item is None:
            raise ValidationError("That item is not in the catalog.")
        return item

    @staticmethod
    def _validate_quantity(item: dict[str, Any], quantity: int) -> int:
        """Enforce stackability and the catalog's per-player quantity ceiling."""
        if isinstance(quantity, bool) or not isinstance(quantity, int):
            raise ValidationError("Quantity must be a whole number.")
        if quantity < 1 or quantity > int(item["max_quantity"]):
            raise ValidationError(f"Quantity must be between 1 and {item['max_quantity']}.")
        if not item["stackable"] and quantity != 1:
            raise ValidationError("That item is not stackable; buy, sell, or trade one at a time.")
        return quantity

    @staticmethod
    def _clean_item_quantities(values: Mapping[int, int]) -> dict[int, int]:
        """Normalize item UID quantities and reject malformed/non-positive lines."""
        if not isinstance(values, Mapping):
            raise ValidationError("Trade items must be selected from the inventory menu.")
        clean: dict[int, int] = {}
        for raw_uid, raw_quantity in values.items():
            if isinstance(raw_uid, bool) or isinstance(raw_quantity, bool):
                raise ValidationError("Trade item selections are invalid.")
            if not isinstance(raw_quantity, int) or not isinstance(raw_uid, (int, str)):
                raise ValidationError("Trade item selections must use whole-number IDs and quantities.")
            if isinstance(raw_uid, str) and not raw_uid.isdigit():
                raise ValidationError("Trade item selections must use whole-number IDs and quantities.")
            asset_id = int(raw_uid)
            quantity = raw_quantity
            if asset_id <= 0 or quantity <= 0:
                raise ValidationError("Trade item quantities must be positive whole numbers.")
            clean[asset_id] = quantity
        return clean

    async def _active_character(self, tx: Any, user_id: int) -> tuple[Character, int]:
        """Load an active life and authoritative optimistic version."""
        row = await self.repository.load_active(tx, user_id)
        if row is None:
            if await self.repository.has_any_life(tx, user_id):
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.version = int(row["version"])
        if not character.is_alive:
            raise CharacterDead()
        return character, int(row["version"])

    async def _load_trade_characters(
        self,
        tx: Any,
        from_user_id: int,
        to_user_id: int,
        *,
        fail_not_found: bool = False,
    ) -> dict[int, Character]:
        """Re-fetch and map the two active character rows inside a single transaction."""
        rows = await self.repository.load_active_many(tx, (from_user_id, to_user_id))
        result: dict[int, Character] = {}
        for user_id in (from_user_id, to_user_id):
            row = rows.get(user_id)
            if row is None:
                if fail_not_found:
                    continue
                if await self.repository.has_any_life(tx, user_id):
                    raise CharacterDead("A player in this trade no longer has a living active character.")
                raise CharacterNotFound("Both players need an active life to trade.")
            character = Character.from_dict(json.loads(row["data_json"]))
            character.version = int(row["version"])
            result[user_id] = character
        if fail_not_found and len(result) != 2:
            raise CharacterDead("A player in this trade no longer has a living active character.")
        return result

    @staticmethod
    def _validate_distinct_users(from_user_id: int, to_user_id: int) -> None:
        """Reject a self-trade before creating a database transaction."""
        if (
            isinstance(from_user_id, bool) or isinstance(to_user_id, bool)
            or not isinstance(from_user_id, int) or not isinstance(to_user_id, int)
            or from_user_id <= 0 or to_user_id <= 0
        ):
            raise ValidationError("Both players must be valid Discord users.")
        if from_user_id == to_user_id:
            raise ValidationError("You cannot trade with yourself or another character owned by you.")

    @staticmethod
    def _validate_trade_creation(character: Character) -> None:
        """Validate adult, living, out-of-custody status for a trade participant."""
        if not character.is_alive:
            raise CharacterDead("Both players must have living active characters to trade.")
        if character.in_prison:
            raise CharacterInPrison("Trading is unavailable while either character is in prison.")
        if character.age < 18 or character.age < 5:
            raise ValidationError("Both characters must be at least 18 and have lived at least five in-game years.")

    async def _validate_trade_player(self, tx: Any, character: Character) -> None:
        """Check life gates and any persisted trade-ban flag for offer building."""
        self._validate_trade_creation(character)
        player = await self.repository.load_player(tx, character.user_id)
        if player is not None and bool(player["trade_banned"]):
            raise ValidationError("This player is currently trade-banned.")

    @staticmethod
    def _check_not_prison(character: Character) -> None:
        """Reject shop, inventory modification, and item use while incarcerated."""
        if character.in_prison:
            raise CharacterInPrison()

    @staticmethod
    def _check_age(character: Character, minimum_age: int, action: str) -> None:
        """Enforce catalog age restrictions in the domain service, not only Discord UI."""
        if character.age < minimum_age:
            raise ValidationError(f"You must be at least {minimum_age} to {action}.")

    @staticmethod
    def _charge(amount: int, multiplier: float | Decimal) -> int:
        """Scale a price or upkeep with charge rounding toward the next cent."""
        try:
            factor = Decimal(str(multiplier))
            if not factor.is_finite() or factor < 0:
                raise ValueError
            result = int((Decimal(amount) * factor).to_integral_value(rounding=ROUND_CEILING))
        except (InvalidOperation, ValueError) as exc:
            raise ValidationError("This item's price index is invalid.") from exc
        return validate_cents(result)

    @staticmethod
    def _payout(amount: int, multiplier: float | Decimal) -> int:
        """Scale a market payout with round-down semantics."""
        factor = Decimal(str(multiplier))
        if not factor.is_finite() or factor < 0:
            raise ValueError("payout multiplier must be a finite non-negative number")
        result = int((Decimal(amount) * factor).to_integral_value(rounding=ROUND_FLOOR))
        return validate_cents(result)

    @staticmethod
    def _percent_charge(amount: int, percent: int) -> int:
        """Calculate a percentage fee in cents, rounding charges up."""
        if amount <= 0:
            return 0
        return (amount * percent + 99) // 100

    @staticmethod
    def _divide_up(amount: int, divisor: int) -> int:
        """Split loan principal into equal integer-cent annual payments, rounding up."""
        if amount <= 0 or divisor <= 0:
            return 0
        return (amount + divisor - 1) // divisor

    @staticmethod
    def _portion(total: int, selected_quantity: int, full_quantity: int) -> int:
        """Allocate an aggregate asset value pro rata, rounding a partial payout down."""
        if full_quantity <= 0 or selected_quantity <= 0:
            return 0
        if selected_quantity >= full_quantity:
            return total
        return max(0, total * selected_quantity // full_quantity)

    @staticmethod
    def _deduct_funds(character: Character, amount: int) -> Character:
        """Deduct cash before bank funds without allowing either balance to go negative."""
        if amount < 0 or character.cash + character.bank < amount:
            raise InsufficientFunds()
        cash_paid = min(max(0, character.cash), amount)
        bank_paid = amount - cash_paid
        return replace(
            character,
            cash=max(0, character.cash - cash_paid),
            bank=max(0, character.bank - bank_paid),
        )

    @staticmethod
    def _apply_effects(character: Character, effects: dict[str, Any], multiplier: int) -> Character:
        """Apply bounded catalog stats and flags, then use the shared stat clamp."""
        stats = replace(character.stats)
        for stat, delta in effects.get("stats", {}).items():
            setattr(stats, stat, getattr(stats, stat) + int(delta) * multiplier)
        flags = effects.get("flags", {})
        replacements: dict[str, Any] = {"stats": stats.clamp_all()}
        for key, value in flags.items():
            replacements[key] = bool(value)
        return replace(character, **replacements)

    def _inventory_display(self, row: dict[str, Any]) -> dict[str, Any]:
        """Combine stored item data with its catalog description for commands and views."""
        item = self.items.get(str(row["item_id"]))
        return {
            **row,
            "name": str(item["name"]) if item else str(row["item_id"]).replace("_", " ").title(),
            "category": str(item["category"]) if item else "legacy",
            "tradeable": bool(item and item["tradeable"]),
            "usable": bool(item and item["usable"]),
            "collateral_eligible": bool(item and item["collateral_eligible"]),
        }

    def _tradeable_rows(self, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Filter locked, collateralized, or nontradeable rows for the offer UI."""
        result: list[dict[str, Any]] = []
        for row in rows:
            item = self.items.get(str(row["item_id"]))
            if item is None or not item["tradeable"] or bool(row["is_locked"]) or bool(row["collateralized"]):
                continue
            result.append(self._inventory_display(row))
        return result

    @staticmethod
    def _item_totals(rows: list[dict[str, Any]]) -> dict[str, int]:
        """Aggregate item quantities by catalog ID."""
        totals: dict[str, int] = {}
        for row in rows:
            key = str(row["item_id"])
            totals[key] = totals.get(key, 0) + int(row["quantity"])
        return totals

    def _imbalance_details(
        self,
        offer_value: int,
        request_value: int,
        from_character: Character,
        to_character: Character,
        from_user_id: int,
        to_user_id: int,
    ) -> tuple[bool, Optional[int]]:
        """Detect a high-value transfer where one side contributes less than ten percent."""
        higher = max(offer_value, request_value)
        lower = min(offer_value, request_value)
        if higher <= 0 or lower * 10 >= higher:
            return False, None
        receiver_id = to_user_id if offer_value > request_value else from_user_id
        receiver = to_character if receiver_id == to_user_id else from_character
        threshold = self._charge(IMBALANCE_BASE_CENTS, receiver.price_index)
        return offer_value + request_value > threshold, receiver_id

    async def _reconcile_housing(self, tx: Any, character: Character, now: int) -> Character:
        """Keep the legacy character housing pointer aligned with owned home assets."""
        homes = await self.repository.list_housing_assets(tx, character.char_id)
        if character.housing_item_id is not None and any(
            int(home["asset_id"]) == int(character.housing_item_id) for home in homes
        ):
            return replace(character, housing_type=HousingType.OWNED, rent_amount=0)
        if homes:
            chosen = homes[0]
            return replace(
                character,
                housing_type=HousingType.OWNED,
                housing_item_id=int(chosen["asset_id"]),
                rent_amount=0,
            )
        if character.housing_type is HousingType.OWNED:
            if character.age < 18:
                return replace(character, housing_type=HousingType.PARENTS, housing_item_id=None, rent_amount=0)
            rent = self._charge(1_800_000, character.price_index)
            return replace(character, housing_type=HousingType.RENT, housing_item_id=None, rent_amount=rent)
        return character

    @staticmethod
    def _validate_user_cash(amount: int) -> int:
        """Validate nonnegative integer cents for a cash-trade field."""
        value = validate_cents(amount)
        if value < 0:
            raise ValidationError("Cash amounts cannot be negative.")
        return value

    def _hold_users(self, user_ids: tuple[int, ...]) -> AsyncContextManager[None]:
        """Return an ordered multi-user lock context using this service's registry."""
        return self._hold_users_with_registry(self.locks, user_ids)

    @staticmethod
    @asynccontextmanager
    async def _hold_users_with_registry(
        registry: UserLockRegistry,
        user_ids: tuple[int, ...],
    ) -> AsyncIterator[None]:
        """Acquire multiple shared locks in ascending Discord ID order."""
        async with AsyncExitStack() as stack:
            for user_id in sorted(set(user_ids)):
                await stack.enter_async_context(registry.hold(user_id))
            yield
````

## `lifeline/core/validators.py`

````python
"""Strict validation for game data files loaded at runtime."""
from __future__ import annotations

import math
import re
from typing import Any


class DataValidationError(ValueError):
    """Raised when a bundled game-data document is malformed or unsafe."""


_EVENT_ID = re.compile(r"^[a-z][a-z0-9_]{0,39}$")
_ALLOWED_POLARITIES = {"positive", "negative", "neutral"}
_ALLOWED_WEALTH = {"poor", "working", "middle", "upper", "rich"}
_ALLOWED_STATS = {
    "health", "happiness", "smarts", "looks", "fitness", "karma",
    "stress", "addiction", "fame",
}


def _fail(path: str, message: str) -> None:
    raise DataValidationError(f"{path}: {message}")


def _string(value: Any, path: str, *, minimum: int, maximum: int) -> str:
    if not isinstance(value, str):
        _fail(path, "must be a string")
    clean = value.strip()
    if not minimum <= len(clean) <= maximum:
        _fail(path, f"length must be between {minimum} and {maximum}")
    if any(ord(char) < 32 or ord(char) == 127 for char in clean):
        _fail(path, "must not contain control characters")
    return clean


def _integer(value: Any, path: str, *, minimum: int, maximum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        _fail(path, "must be an integer")
    if not minimum <= value <= maximum:
        _fail(path, f"must be between {minimum} and {maximum}")
    return value


def validate_event_catalog(document: Any) -> dict[str, Any]:
    """Validate and return a version-1 life-event catalog.

    Expressions and executable conditions are intentionally unsupported: event
    effects are finite integer stat deltas, never ``eval``-ed code.
    """
    if not isinstance(document, dict):
        _fail("events", "document must be an object")
    if document.get("schema_version") != 1:
        _fail("schema_version", "only version 1 is supported")
    events = document.get("events")
    if not isinstance(events, list) or not 1 <= len(events) <= 500:
        _fail("events", "must contain between 1 and 500 event definitions")

    seen_event_ids: set[str] = set()
    for event_index, event in enumerate(events):
        path = f"events[{event_index}]"
        if not isinstance(event, dict):
            _fail(path, "must be an object")

        event_id = _string(event.get("id"), f"{path}.id", minimum=1, maximum=40)
        if not _EVENT_ID.fullmatch(event_id):
            _fail(f"{path}.id", "use lowercase letters, digits, and underscores")
        if event_id in seen_event_ids:
            _fail(f"{path}.id", "event IDs must be unique")
        seen_event_ids.add(event_id)

        _string(event.get("title"), f"{path}.title", minimum=1, maximum=100)
        _string(event.get("description"), f"{path}.description", minimum=1, maximum=1000)
        category = _string(event.get("category"), f"{path}.category", minimum=1, maximum=32)
        if not re.fullmatch(r"[a-z][a-z0-9_]*", category):
            _fail(f"{path}.category", "must be a lowercase category key")
        if event.get("polarity") not in _ALLOWED_POLARITIES:
            _fail(f"{path}.polarity", "must be positive, negative, or neutral")

        minimum_age = _integer(event.get("min_age"), f"{path}.min_age", minimum=0, maximum=120)
        maximum_age = _integer(event.get("max_age"), f"{path}.max_age", minimum=0, maximum=120)
        if minimum_age > maximum_age:
            _fail(path, "min_age cannot exceed max_age")

        weight = event.get("weight")
        if isinstance(weight, bool) or not isinstance(weight, (int, float)):
            _fail(f"{path}.weight", "must be a number")
        if not math.isfinite(float(weight)) or not 0 < float(weight) <= 1000:
            _fail(f"{path}.weight", "must be greater than 0 and at most 1000")

        repeatable = event.get("repeatable", False)
        if not isinstance(repeatable, bool):
            _fail(f"{path}.repeatable", "must be true or false")

        wealth_classes = event.get("wealth_classes", [])
        if not isinstance(wealth_classes, list) or any(
            not isinstance(value, str) or value not in _ALLOWED_WEALTH for value in wealth_classes
        ):
            _fail(f"{path}.wealth_classes", "must be a list of valid wealth-class keys")
        if len(set(wealth_classes)) != len(wealth_classes):
            _fail(f"{path}.wealth_classes", "values must be unique")

        countries = event.get("countries", [])
        if not isinstance(countries, list) or any(
            not isinstance(value, str) or not re.fullmatch(r"[a-z0-9_-]{2,40}", value)
            for value in countries
        ):
            _fail(f"{path}.countries", "must be a list of lowercase country/region keys")

        choices = event.get("choices")
        if not isinstance(choices, list) or not 2 <= len(choices) <= 4:
            _fail(f"{path}.choices", "must contain between 2 and 4 choices")
        seen_choice_ids: set[str] = set()
        for choice_index, choice in enumerate(choices):
            choice_path = f"{path}.choices[{choice_index}]"
            if not isinstance(choice, dict):
                _fail(choice_path, "must be an object")
            choice_id = _string(choice.get("id"), f"{choice_path}.id", minimum=1, maximum=32)
            if not _EVENT_ID.fullmatch(choice_id):
                _fail(f"{choice_path}.id", "use lowercase letters, digits, and underscores")
            if choice_id in seen_choice_ids:
                _fail(f"{choice_path}.id", "choice IDs must be unique within an event")
            seen_choice_ids.add(choice_id)
            _string(choice.get("label"), f"{choice_path}.label", minimum=1, maximum=80)
            description = choice.get("description", "")
            if description:
                _string(description, f"{choice_path}.description", minimum=1, maximum=250)

            effects = choice.get("effects", {})
            if not isinstance(effects, dict) or set(effects) - {"stats"}:
                _fail(f"{choice_path}.effects", "may contain only a stats object")
            stat_effects = effects.get("stats", {})
            if not isinstance(stat_effects, dict):
                _fail(f"{choice_path}.effects.stats", "must be an object")
            for stat_name, delta in stat_effects.items():
                if stat_name not in _ALLOWED_STATS:
                    _fail(f"{choice_path}.effects.stats.{stat_name}", "is not a mutable game stat")
                _integer(delta, f"{choice_path}.effects.stats.{stat_name}", minimum=-25, maximum=25)

    return document


def validate_career_catalog(document: Any) -> dict[str, Any]:
    """Validate a career catalog containing finite, positive integer-cent salaries."""
    if not isinstance(document, dict):
        _fail("careers", "document must be an object")
    if document.get("schema_version") != 1:
        _fail("schema_version", "only version 1 is supported")
    careers = document.get("careers")
    if not isinstance(careers, list) or not 1 <= len(careers) <= 100:
        _fail("careers", "must contain between 1 and 100 career definitions")

    allowed_education = {"none", "primary", "high_school", "bachelor", "master", "doctorate"}
    career_ids: set[str] = set()
    for index, career in enumerate(careers):
        path = f"careers[{index}]"
        if not isinstance(career, dict):
            _fail(path, "must be an object")
        career_id = _string(career.get("id"), f"{path}.id", minimum=1, maximum=40)
        if not _EVENT_ID.fullmatch(career_id):
            _fail(f"{path}.id", "use lowercase letters, digits, and underscores")
        if career_id in career_ids:
            _fail(f"{path}.id", "career IDs must be unique")
        career_ids.add(career_id)
        _string(career.get("name"), f"{path}.name", minimum=1, maximum=80)
        minimum_age = _integer(career.get("minimum_age"), f"{path}.minimum_age", minimum=14, maximum=80)
        retirement_age = _integer(career.get("retirement_age"), f"{path}.retirement_age", minimum=40, maximum=120)
        if retirement_age <= minimum_age:
            _fail(path, "retirement_age must be greater than minimum_age")
        if career.get("minimum_education") not in allowed_education:
            _fail(f"{path}.minimum_education", "must be a supported education level")
        _integer(career.get("minimum_smarts"), f"{path}.minimum_smarts", minimum=0, maximum=100)
        part_time_allowed = career.get("part_time_allowed", False)
        if not isinstance(part_time_allowed, bool):
            _fail(f"{path}.part_time_allowed", "must be true or false")
        multiplier = career.get("part_time_multiplier", 0.5)
        if isinstance(multiplier, bool) or not isinstance(multiplier, (int, float)):
            _fail(f"{path}.part_time_multiplier", "must be a number")
        if not math.isfinite(float(multiplier)) or not 0 < float(multiplier) <= 1:
            _fail(f"{path}.part_time_multiplier", "must be greater than 0 and at most 1")

        levels = career.get("levels")
        if not isinstance(levels, list) or not 2 <= len(levels) <= 8:
            _fail(f"{path}.levels", "must contain between 2 and 8 levels")
        for level_index, level in enumerate(levels):
            level_path = f"{path}.levels[{level_index}]"
            if not isinstance(level, dict):
                _fail(level_path, "must be an object")
            _string(level.get("title"), f"{level_path}.title", minimum=1, maximum=80)
            _integer(level.get("annual_salary"), f"{level_path}.annual_salary", minimum=1, maximum=10_000_000_000)
            _integer(level.get("promotion_years"), f"{level_path}.promotion_years", minimum=1, maximum=30)

    return document


def _validate_item_effects(value: Any, path: str, *, allow_flags: bool = False, allow_payout: bool = False) -> dict[str, Any]:
    """Validate a bounded, declarative item effect document."""
    if not isinstance(value, dict):
        _fail(path, "must be an object")
    allowed = {"stats"}
    if allow_flags:
        allowed.add("flags")
    if allow_payout:
        allowed.add("payout_range_cents")
    if set(value) - allowed:
        _fail(path, f"may contain only: {', '.join(sorted(allowed))}")
    stats = value.get("stats", {})
    if not isinstance(stats, dict):
        _fail(f"{path}.stats", "must be an object")
    for stat_name, delta in stats.items():
        if stat_name not in _ALLOWED_STATS:
            _fail(f"{path}.stats.{stat_name}", "is not a supported game stat")
        _integer(delta, f"{path}.stats.{stat_name}", minimum=-100, maximum=100)
    if allow_flags:
        flags = value.get("flags", {})
        if not isinstance(flags, dict) or set(flags) - {"has_license", "has_ged"}:
            _fail(f"{path}.flags", "may contain only supported character flags")
        for flag, enabled in flags.items():
            if not isinstance(enabled, bool):
                _fail(f"{path}.flags.{flag}", "must be true or false")
    if allow_payout and "payout_range_cents" in value:
        payout = value["payout_range_cents"]
        if not isinstance(payout, list) or len(payout) != 2:
            _fail(f"{path}.payout_range_cents", "must contain a minimum and maximum")
        minimum = _integer(payout[0], f"{path}.payout_range_cents[0]", minimum=0, maximum=9_000_000_000_000_000_000)
        maximum = _integer(payout[1], f"{path}.payout_range_cents[1]", minimum=minimum, maximum=9_000_000_000_000_000_000)
    return value


def validate_item_catalog(document: Any) -> dict[str, Any]:
    """Validate the full Stage 8 item catalog and its finite gameplay effects."""
    if not isinstance(document, dict):
        _fail("items", "document must be an object")
    if isinstance(document.get("schema_version"), bool) or document.get("schema_version") != 1:
        _fail("items.schema_version", "only version 1 is supported")
    if set(document) != {"schema_version", "items"}:
        _fail("items", "must contain exactly schema_version and items")
    items = document.get("items")
    if not isinstance(items, list) or not 60 <= len(items) <= 500:
        _fail("items", "must contain between 60 and 500 item definitions")
    categories = {
        "housing", "vehicle", "jewelry", "electronics", "health", "collectibles",
        "business", "pet", "weapon", "consumable", "license", "title", "leisure",
    }
    required = {
        "id", "name", "category", "base_price_cents", "min_age", "stackable",
        "max_quantity", "tradeable", "effects_on_buy", "effects_on_use", "yearly_effects",
        "yearly_upkeep_cents", "depreciation_rate_per_year", "market_volatility",
        "collateral_eligible", "consumable", "usable", "shop_available",
        "crime_event_only", "legal_countries",
    }
    seen: set[str] = set()
    for index, item in enumerate(items):
        path = f"items[{index}]"
        if not isinstance(item, dict):
            _fail(path, "must be an object")
        if set(item) != required:
            missing = required - set(item)
            extra = set(item) - required
            detail = []
            if missing:
                detail.append(f"missing {', '.join(sorted(missing))}")
            if extra:
                detail.append(f"unsupported {', '.join(sorted(extra))}")
            _fail(path, "; ".join(detail))
        item_id = _string(item.get("id"), f"{path}.id", minimum=1, maximum=40)
        if not _EVENT_ID.fullmatch(item_id) or item_id in seen:
            _fail(f"{path}.id", "must be unique and use lowercase letters, digits, and underscores")
        seen.add(item_id)
        _string(item.get("name"), f"{path}.name", minimum=1, maximum=80)
        if item.get("category") not in categories:
            _fail(f"{path}.category", "is not a supported shop category")
        _integer(item.get("base_price_cents"), f"{path}.base_price_cents", minimum=0, maximum=9_000_000_000_000_000_000)
        _integer(item.get("min_age"), f"{path}.min_age", minimum=0, maximum=120)
        stackable = item.get("stackable")
        if not isinstance(stackable, bool):
            _fail(f"{path}.stackable", "must be true or false")
        maximum = _integer(item.get("max_quantity"), f"{path}.max_quantity", minimum=1, maximum=999)
        if not stackable and maximum != 1:
            _fail(f"{path}.max_quantity", "non-stackable items must have max_quantity 1")
        for field in ("tradeable", "collateral_eligible", "consumable", "usable", "shop_available", "crime_event_only"):
            if not isinstance(item.get(field), bool):
                _fail(f"{path}.{field}", "must be true or false")
        if not isinstance(item.get("legal_countries"), list):
            _fail(f"{path}.legal_countries", "must be a list")
        legal_countries = item["legal_countries"]
        if any(
            not isinstance(country, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{1,39}", country)
            for country in legal_countries
        ):
            _fail(f"{path}.legal_countries", "must contain lowercase country codes")
        if len(set(legal_countries)) != len(legal_countries):
            _fail(f"{path}.legal_countries", "country codes must be unique")
        if item["crime_event_only"] and (item["shop_available"] or item["category"] != "weapon"):
            _fail(path, "crime-event-only items must be weapons and unavailable in /shop")
        if item["category"] == "weapon" and (not item["crime_event_only"] or not legal_countries or item["min_age"] < 18 or item["tradeable"]):
            _fail(path, "weapons must be nontradeable, crime-event-only, adult-gated items with country legality")
        if item["category"] in {"title", "license"} and item["tradeable"]:
            _fail(path, "titles and licenses cannot be traded")
        if item["category"] == "consumable" and not item["tradeable"]:
            _fail(path, "consumables must be tradeable")
        if item["base_price_cents"] == 0 and not (item["crime_event_only"] or not item["shop_available"]):
            _fail(f"{path}.base_price_cents", "zero-price items must be event-only or hidden")
        if item["collateral_eligible"] and item["category"] not in {"housing", "vehicle"}:
            _fail(f"{path}.collateral_eligible", "only housing and vehicles may secure loans")
        if item["category"] in {"housing", "vehicle"} and (not item["tradeable"] or not item["collateral_eligible"]):
            _fail(path, "housing and vehicles must be tradeable and collateral-eligible")
        if item["consumable"] and (not stackable or not item["usable"]):
            _fail(path, "consumables must be stackable and usable")
        _validate_item_effects(item["effects_on_buy"], f"{path}.effects_on_buy", allow_flags=True)
        _validate_item_effects(item["effects_on_use"], f"{path}.effects_on_use", allow_payout=True)
        yearly = item["yearly_effects"]
        if not isinstance(yearly, dict) or set(yearly) != {"stats", "income_cents"}:
            _fail(f"{path}.yearly_effects", "must contain stats and income_cents")
        _validate_item_effects({"stats": yearly["stats"]}, f"{path}.yearly_effects")
        _integer(yearly["income_cents"], f"{path}.yearly_effects.income_cents", minimum=0, maximum=9_000_000_000_000_000_000)
        _integer(item["yearly_upkeep_cents"], f"{path}.yearly_upkeep_cents", minimum=0, maximum=9_000_000_000_000_000_000)
        rate = item["depreciation_rate_per_year"]
        volatility = item["market_volatility"]
        for field, number in (("depreciation_rate_per_year", rate), ("market_volatility", volatility)):
            if isinstance(number, bool) or not isinstance(number, (int, float)) or not math.isfinite(float(number)):
                _fail(f"{path}.{field}", "must be a finite number")
        if not -0.95 <= float(rate) <= 0.95:
            _fail(f"{path}.depreciation_rate_per_year", "must be between -0.95 and 0.95")
        if not 0 <= float(volatility) <= 0.5:
            _fail(f"{path}.market_volatility", "must be between 0 and 0.5")
        if item["shop_available"] and item["crime_event_only"]:
            _fail(path, "crime-event-only items cannot be sold in /shop")
    return document


def validate_crime_catalog(document: Any) -> dict[str, Any]:
    """Validate the complete non-instructional crime catalog used at startup."""
    if not isinstance(document, dict):
        _fail("crimes", "document must be an object")
    if isinstance(document.get("schema_version"), bool) or document.get("schema_version") != 1:
        _fail("crimes.schema_version", "only version 1 is supported")
    allowed_top = {"schema_version", "crime_severity_mod", "crimes"}
    if set(document) != allowed_top:
        _fail("crimes", f"must contain exactly these keys: {', '.join(sorted(allowed_top))}")
    severity = document.get("crime_severity_mod")
    if not isinstance(severity, dict) or "default" not in severity:
        _fail("crimes.crime_severity_mod", "must be an object with a default modifier")
    for country, modifier in severity.items():
        _string(country, "crimes.crime_severity_mod key", minimum=2, maximum=40)
        if not re.fullmatch(r"[a-z][a-z0-9_]{1,39}", country):
            _fail("crimes.crime_severity_mod", "country keys must be lowercase codes")
        if isinstance(modifier, bool) or not isinstance(modifier, (int, float)):
            _fail(f"crimes.crime_severity_mod.{country}", "must be a number")
        if not math.isfinite(float(modifier)) or not 0.25 <= float(modifier) <= 3.0:
            _fail(f"crimes.crime_severity_mod.{country}", "must be between 0.25 and 3")
    crimes = document.get("crimes")
    if not isinstance(crimes, list) or len(crimes) < 14 or len(crimes) > 100:
        _fail("crimes", "must contain at least 14 and at most 100 crime definitions")
    seen: set[str] = set()
    has_event_only_tax = False
    for index, crime in enumerate(crimes):
        path = f"crimes[{index}]"
        if not isinstance(crime, dict):
            _fail(path, "must be an object")
        required_fields = {
            "id", "name", "description", "min_age", "base_success", "loot_min_dollars",
            "loot_max_dollars", "base_catch", "sentence_min", "sentence_max",
            "violence", "success_stat", "requires_job", "commit_enabled",
        }
        optional_fields = {
            "salary_loot_min_fraction", "salary_loot_max_fraction", "salary_loot_multiplier",
        }
        missing_fields = required_fields - set(crime)
        extra_fields = set(crime) - required_fields - optional_fields
        if missing_fields:
            _fail(path, f"missing required fields: {', '.join(sorted(missing_fields))}")
        if extra_fields:
            _fail(path, f"unsupported fields: {', '.join(sorted(extra_fields))}")
        crime_id = _string(crime.get("id"), f"{path}.id", minimum=1, maximum=40)
        if not _EVENT_ID.fullmatch(crime_id) or crime_id in seen:
            _fail(f"{path}.id", "must be unique and use lowercase letters, digits, and underscores")
        seen.add(crime_id)
        _string(crime.get("name"), f"{path}.name", minimum=1, maximum=80)
        _string(crime.get("description"), f"{path}.description", minimum=1, maximum=250)
        minimum_age = crime.get("min_age")
        if minimum_age is not None:
            _integer(minimum_age, f"{path}.min_age", minimum=0, maximum=120)
        enabled = crime.get("commit_enabled")
        if not isinstance(enabled, bool):
            _fail(f"{path}.commit_enabled", "must be true or false")
        for key in ("violence", "requires_job"):
            if not isinstance(crime.get(key), bool):
                _fail(f"{path}.{key}", "must be true or false")
        if crime.get("success_stat") not in {"none", "skill", "physical"}:
            _fail(f"{path}.success_stat", "must be none, skill, or physical")
        loot_min = _integer(crime.get("loot_min_dollars"), f"{path}.loot_min_dollars", minimum=0, maximum=10_000_000)
        loot_max = _integer(crime.get("loot_max_dollars"), f"{path}.loot_max_dollars", minimum=0, maximum=10_000_000)
        if loot_min > loot_max:
            _fail(path, "loot_min_dollars cannot exceed loot_max_dollars")
        sentence_min = _integer(crime.get("sentence_min"), f"{path}.sentence_min", minimum=0, maximum=120)
        sentence_max = crime.get("sentence_max")
        if sentence_max != "life":
            sentence_max = _integer(sentence_max, f"{path}.sentence_max", minimum=0, maximum=120)
            if sentence_min > sentence_max:
                _fail(path, "sentence_min cannot exceed sentence_max")
        if enabled:
            if minimum_age is None:
                _fail(f"{path}.min_age", "committable crimes require a minimum age")
            for key in ("base_success", "base_catch"):
                chance = crime.get(key)
                if isinstance(chance, bool) or not isinstance(chance, (int, float)):
                    _fail(f"{path}.{key}", "committable crimes require a numeric chance")
                if not math.isfinite(float(chance)) or not 0 <= float(chance) <= 100:
                    _fail(f"{path}.{key}", "must be between 0 and 100")
        else:
            if crime_id == "tax_evasion":
                has_event_only_tax = True
                if minimum_age != 18:
                    _fail(f"{path}.min_age", "tax_evasion is an adult-only event")
            if crime.get("base_success") is not None or crime.get("base_catch") is not None:
                _fail(path, "event-only crimes must not define commit chances")
        has_salary_range = "salary_loot_min_fraction" in crime or "salary_loot_max_fraction" in crime
        if "salary_loot_multiplier" in crime and not has_salary_range:
            _fail(path, "salary_loot_multiplier requires salary loot fractions")
        if crime["requires_job"] and not has_salary_range:
            _fail(path, "job-required crimes need salary loot fractions")
        if has_salary_range:
            for key in ("salary_loot_min_fraction", "salary_loot_max_fraction"):
                value = crime.get(key)
                if isinstance(value, bool) or not isinstance(value, (int, float)):
                    _fail(f"{path}.{key}", "must be a number")
                if not math.isfinite(float(value)) or not 0 <= float(value) <= 1:
                    _fail(f"{path}.{key}", "must be between 0 and 1")
            if crime["salary_loot_min_fraction"] > crime["salary_loot_max_fraction"]:
                _fail(path, "salary loot minimum fraction cannot exceed maximum fraction")
            _integer(crime.get("salary_loot_multiplier"), f"{path}.salary_loot_multiplier", minimum=1, maximum=10)
    if not has_event_only_tax:
        _fail("crimes", "must include event-only tax_evasion")
    return document
````

## `lifeline/data/items.json`

````json
{
  "schema_version": 1,
  "items": [
    {
      "id": "trailer",
      "name": "Trailer",
      "category": "housing",
      "base_price_cents": 4000000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 2
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {
          "happiness": 1
        },
        "income_cents": 0
      },
      "yearly_upkeep_cents": 40000,
      "depreciation_rate_per_year": -0.035,
      "market_volatility": 0.05,
      "collateral_eligible": true,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "starter_home",
      "name": "Starter Home",
      "category": "housing",
      "base_price_cents": 18000000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 4
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {
          "happiness": 1
        },
        "income_cents": 0
      },
      "yearly_upkeep_cents": 90000,
      "depreciation_rate_per_year": -0.035,
      "market_volatility": 0.05,
      "collateral_eligible": true,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "suburban_house",
      "name": "Suburban House",
      "category": "housing",
      "base_price_cents": 35000000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 6
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {
          "happiness": 1
        },
        "income_cents": 0
      },
      "yearly_upkeep_cents": 150000,
      "depreciation_rate_per_year": -0.035,
      "market_volatility": 0.05,
      "collateral_eligible": true,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "townhouse",
      "name": "Townhouse",
      "category": "housing",
      "base_price_cents": 50000000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 7
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {
          "happiness": 1
        },
        "income_cents": 0
      },
      "yearly_upkeep_cents": 220000,
      "depreciation_rate_per_year": -0.035,
      "market_volatility": 0.05,
      "collateral_eligible": true,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "luxury_villa",
      "name": "Luxury Villa",
      "category": "housing",
      "base_price_cents": 200000000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 12
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {
          "happiness": 1
        },
        "income_cents": 0
      },
      "yearly_upkeep_cents": 800000,
      "depreciation_rate_per_year": -0.035,
      "market_volatility": 0.05,
      "collateral_eligible": true,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "mansion",
      "name": "Mansion",
      "category": "housing",
      "base_price_cents": 800000000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 16
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {
          "happiness": 1
        },
        "income_cents": 0
      },
      "yearly_upkeep_cents": 2500000,
      "depreciation_rate_per_year": -0.035,
      "market_volatility": 0.05,
      "collateral_eligible": true,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "private_island",
      "name": "Private Island",
      "category": "housing",
      "base_price_cents": 4000000000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 20
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {
          "happiness": 1
        },
        "income_cents": 0
      },
      "yearly_upkeep_cents": 8000000,
      "depreciation_rate_per_year": -0.035,
      "market_volatility": 0.05,
      "collateral_eligible": true,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "used_car",
      "name": "Used Car",
      "category": "vehicle",
      "base_price_cents": 500000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 2
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 25000,
      "depreciation_rate_per_year": 0.15,
      "market_volatility": 0.0,
      "collateral_eligible": true,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "sedan",
      "name": "Sedan",
      "category": "vehicle",
      "base_price_cents": 2800000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 2
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 55000,
      "depreciation_rate_per_year": 0.15,
      "market_volatility": 0.0,
      "collateral_eligible": true,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "suv",
      "name": "SUV",
      "category": "vehicle",
      "base_price_cents": 4500000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 2
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 85000,
      "depreciation_rate_per_year": 0.15,
      "market_volatility": 0.0,
      "collateral_eligible": true,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "sports_car",
      "name": "Sports Car",
      "category": "vehicle",
      "base_price_cents": 12000000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 2
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 180000,
      "depreciation_rate_per_year": 0.15,
      "market_volatility": 0.0,
      "collateral_eligible": true,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "supercar",
      "name": "Supercar",
      "category": "vehicle",
      "base_price_cents": 40000000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 2
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 500000,
      "depreciation_rate_per_year": 0.15,
      "market_volatility": 0.0,
      "collateral_eligible": true,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "motorcycle",
      "name": "Motorcycle",
      "category": "vehicle",
      "base_price_cents": 1200000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 2
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 35000,
      "depreciation_rate_per_year": 0.15,
      "market_volatility": 0.0,
      "collateral_eligible": true,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "yacht",
      "name": "Yacht",
      "category": "vehicle",
      "base_price_cents": 200000000,
      "min_age": 21,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 2
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 1500000,
      "depreciation_rate_per_year": 0.15,
      "market_volatility": 0.0,
      "collateral_eligible": true,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "private_jet",
      "name": "Private Jet",
      "category": "vehicle",
      "base_price_cents": 2500000000,
      "min_age": 21,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 2
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 15000000,
      "depreciation_rate_per_year": 0.15,
      "market_volatility": 0.0,
      "collateral_eligible": true,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "simple_ring",
      "name": "Simple Band",
      "category": "jewelry",
      "base_price_cents": 10000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "looks": 1
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.01,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "silver_ring",
      "name": "Silver Ring",
      "category": "jewelry",
      "base_price_cents": 100000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "looks": 1
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.01,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "gold_ring",
      "name": "Gold Ring",
      "category": "jewelry",
      "base_price_cents": 500000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "looks": 2
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.01,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "diamond_ring",
      "name": "Diamond Ring",
      "category": "jewelry",
      "base_price_cents": 2000000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "looks": 3
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.01,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "heirloom_ring",
      "name": "Heirloom Ring",
      "category": "jewelry",
      "base_price_cents": 10000000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "looks": 4
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.01,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "classic_watch",
      "name": "Classic Watch",
      "category": "jewelry",
      "base_price_cents": 250000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": -0.02,
      "market_volatility": 0.08,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "dress_watch",
      "name": "Dress Watch",
      "category": "jewelry",
      "base_price_cents": 1500000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": -0.02,
      "market_volatility": 0.08,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "luxury_watch",
      "name": "Luxury Watch",
      "category": "jewelry",
      "base_price_cents": 7500000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": -0.02,
      "market_volatility": 0.08,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "chronograph_watch",
      "name": "Chronograph Watch",
      "category": "jewelry",
      "base_price_cents": 20000000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": -0.02,
      "market_volatility": 0.08,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "collector_watch",
      "name": "Collector Watch",
      "category": "jewelry",
      "base_price_cents": 100000000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": -0.02,
      "market_volatility": 0.08,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "silver_necklace",
      "name": "Silver Necklace",
      "category": "jewelry",
      "base_price_cents": 25000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "looks": 1
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.01,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "gold_necklace",
      "name": "Gold Necklace",
      "category": "jewelry",
      "base_price_cents": 250000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "looks": 1
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.01,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "pearl_necklace",
      "name": "Pearl Necklace",
      "category": "jewelry",
      "base_price_cents": 1500000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "looks": 1
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.01,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "diamond_necklace",
      "name": "Diamond Necklace",
      "category": "jewelry",
      "base_price_cents": 10000000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "looks": 1
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.01,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "heirloom_necklace",
      "name": "Heirloom Necklace",
      "category": "jewelry",
      "base_price_cents": 100000000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "looks": 1
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.01,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "phone",
      "name": "Smartphone",
      "category": "electronics",
      "base_price_cents": 80000,
      "min_age": 12,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 1
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.25,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "laptop",
      "name": "Laptop",
      "category": "electronics",
      "base_price_cents": 150000,
      "min_age": 12,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 1
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.25,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "gaming_pc",
      "name": "Gaming PC",
      "category": "electronics",
      "base_price_cents": 300000,
      "min_age": 13,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 3
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.25,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "television",
      "name": "Television",
      "category": "electronics",
      "base_price_cents": 120000,
      "min_age": 12,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 2
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.25,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "gym_membership",
      "name": "Gym Membership",
      "category": "health",
      "base_price_cents": 50000,
      "min_age": 16,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": false,
      "effects_on_buy": {
        "stats": {
          "fitness": 1
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {
          "fitness": 2
        },
        "income_cents": 0
      },
      "yearly_upkeep_cents": 120000,
      "depreciation_rate_per_year": 0.0,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "supplements",
      "name": "Supplements Pack",
      "category": "health",
      "base_price_cents": 5000,
      "min_age": 16,
      "stackable": true,
      "max_quantity": 20,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {
          "fitness": 2
        }
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.0,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": true,
      "usable": true,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "medication",
      "name": "Basic Medication",
      "category": "health",
      "base_price_cents": 4000,
      "min_age": 0,
      "stackable": true,
      "max_quantity": 30,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {
          "health": 5,
          "stress": -2
        }
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.0,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": true,
      "usable": true,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "vitamins",
      "name": "Daily Vitamins",
      "category": "health",
      "base_price_cents": 2000,
      "min_age": 8,
      "stackable": true,
      "max_quantity": 30,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {
          "health": 2
        }
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.0,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": true,
      "usable": true,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "first_aid_kit",
      "name": "First Aid Kit",
      "category": "health",
      "base_price_cents": 3500,
      "min_age": 0,
      "stackable": true,
      "max_quantity": 10,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {
          "health": 8
        }
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.05,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": true,
      "usable": true,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "original_art",
      "name": "Original Artwork",
      "category": "collectibles",
      "base_price_cents": 50000000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": -0.05,
      "market_volatility": 0.2,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "sculpture",
      "name": "Collector Sculpture",
      "category": "collectibles",
      "base_price_cents": 15000000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": -0.05,
      "market_volatility": 0.2,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "antique_vase",
      "name": "Antique Vase",
      "category": "collectibles",
      "base_price_cents": 3000000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": -0.05,
      "market_volatility": 0.2,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "rare_comic",
      "name": "Rare Comic Book",
      "category": "collectibles",
      "base_price_cents": 500000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": -0.05,
      "market_volatility": 0.2,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "rare_wine",
      "name": "Rare Wine Bottle",
      "category": "collectibles",
      "base_price_cents": 2500000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": -0.05,
      "market_volatility": 0.2,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "wine_collection",
      "name": "Rare Wine Collection",
      "category": "collectibles",
      "base_price_cents": 25000000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": -0.05,
      "market_volatility": 0.2,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "limited_sneakers",
      "name": "Limited-Edition Sneakers",
      "category": "collectibles",
      "base_price_cents": 100000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.2,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "laundromat",
      "name": "Laundromat",
      "category": "business",
      "base_price_cents": 25000000,
      "min_age": 21,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 250000
      },
      "yearly_upkeep_cents": 50000,
      "depreciation_rate_per_year": 0.1,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "car_wash",
      "name": "Car Wash",
      "category": "business",
      "base_price_cents": 50000000,
      "min_age": 21,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 500000
      },
      "yearly_upkeep_cents": 100000,
      "depreciation_rate_per_year": 0.1,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "nightclub",
      "name": "Nightclub",
      "category": "business",
      "base_price_cents": 150000000,
      "min_age": 21,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 1000000
      },
      "yearly_upkeep_cents": 400000,
      "depreciation_rate_per_year": 0.1,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "front_business",
      "name": "Legacy Business Front",
      "category": "business",
      "base_price_cents": 0,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.0,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": false,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "dog",
      "name": "Dog",
      "category": "pet",
      "base_price_cents": 50000,
      "min_age": 8,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 4
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {
          "happiness": 2
        },
        "income_cents": 0
      },
      "yearly_upkeep_cents": 50000,
      "depreciation_rate_per_year": 0.1,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "cat",
      "name": "Cat",
      "category": "pet",
      "base_price_cents": 30000,
      "min_age": 8,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 3
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {
          "happiness": 2
        },
        "income_cents": 0
      },
      "yearly_upkeep_cents": 35000,
      "depreciation_rate_per_year": 0.1,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "prop_weapon",
      "name": "Fictional Prop Weapon",
      "category": "weapon",
      "base_price_cents": 25000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": false,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.3,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": false,
      "crime_event_only": true,
      "legal_countries": [
        "usa",
        "ca",
        "gb",
        "au"
      ]
    },
    {
      "id": "antique_firearm",
      "name": "Antique Firearm",
      "category": "weapon",
      "base_price_cents": 25000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": false,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.3,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": false,
      "crime_event_only": true,
      "legal_countries": [
        "usa",
        "ca",
        "gb",
        "au"
      ]
    },
    {
      "id": "training_knife",
      "name": "Training Prop",
      "category": "weapon",
      "base_price_cents": 25000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": false,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.3,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": false,
      "crime_event_only": true,
      "legal_countries": [
        "usa",
        "ca",
        "gb",
        "au"
      ]
    },
    {
      "id": "lottery_ticket",
      "name": "Lottery Ticket",
      "category": "consumable",
      "base_price_cents": 500,
      "min_age": 18,
      "stackable": true,
      "max_quantity": 99,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {},
        "payout_range_cents": [
          0,
          1000000
        ]
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.0,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": true,
      "usable": true,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "energy_drink",
      "name": "Energy Drink",
      "category": "consumable",
      "base_price_cents": 400,
      "min_age": 16,
      "stackable": true,
      "max_quantity": 99,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {
          "fitness": 2,
          "health": 1,
          "stress": 2
        }
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.0,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": true,
      "usable": true,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "snack",
      "name": "Snack",
      "category": "consumable",
      "base_price_cents": 250,
      "min_age": 0,
      "stackable": true,
      "max_quantity": 99,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {
          "happiness": 1
        }
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.0,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": true,
      "usable": true,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "driver_license",
      "name": "Driver License",
      "category": "license",
      "base_price_cents": 5000,
      "min_age": 16,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": false,
      "effects_on_buy": {
        "stats": {},
        "flags": {
          "has_license": true
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.0,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "fishing_license",
      "name": "Fishing License",
      "category": "license",
      "base_price_cents": 2000,
      "min_age": 12,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": false,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.0,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "hunting_license",
      "name": "Hunting License",
      "category": "license",
      "base_price_cents": 8000,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": false,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.0,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "title_homeowner",
      "name": "Homeowner Title",
      "category": "title",
      "base_price_cents": 0,
      "min_age": 18,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": false,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.0,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": false,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "title_community_service",
      "name": "Community Service Title",
      "category": "title",
      "base_price_cents": 0,
      "min_age": 16,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": false,
      "effects_on_buy": {
        "stats": {}
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.0,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": false,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "bicycle",
      "name": "Bicycle",
      "category": "leisure",
      "base_price_cents": 40000,
      "min_age": 8,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "fitness": 1
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.15,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "guitar",
      "name": "Acoustic Guitar",
      "category": "leisure",
      "base_price_cents": 75000,
      "min_age": 10,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 2
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.1,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "camera",
      "name": "Digital Camera",
      "category": "leisure",
      "base_price_cents": 120000,
      "min_age": 12,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "looks": 1
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.25,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "yoga_mat",
      "name": "Yoga Mat",
      "category": "leisure",
      "base_price_cents": 2500,
      "min_age": 10,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "fitness": 1
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.1,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "bookshelf",
      "name": "Bookshelf",
      "category": "leisure",
      "base_price_cents": 25000,
      "min_age": 8,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "smarts": 1
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.12,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "home_theater",
      "name": "Home Theater System",
      "category": "leisure",
      "base_price_cents": 250000,
      "min_age": 16,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 3
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.25,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    },
    {
      "id": "art_supplies",
      "name": "Art Supplies",
      "category": "leisure",
      "base_price_cents": 8000,
      "min_age": 6,
      "stackable": false,
      "max_quantity": 1,
      "tradeable": true,
      "effects_on_buy": {
        "stats": {
          "happiness": 1
        }
      },
      "effects_on_use": {
        "stats": {}
      },
      "yearly_effects": {
        "stats": {},
        "income_cents": 0
      },
      "yearly_upkeep_cents": 0,
      "depreciation_rate_per_year": 0.1,
      "market_volatility": 0.0,
      "collateral_eligible": false,
      "consumable": false,
      "usable": false,
      "shop_available": true,
      "crime_event_only": false,
      "legal_countries": []
    }
  ]
}
````

## `lifeline/tests/test_migrations.py`

````python
"""Migration repeatability and Stage 2 schema checks."""
from __future__ import annotations

import pytest


@pytest.mark.asyncio
async def test_initialize_is_idempotent(database):
    await database.initialize()
    await database.close()
    await database.initialize()
    versions = await database.fetchall("SELECT version FROM schema_version ORDER BY version")
    assert [row["version"] for row in versions] == [1, 2, 3, 4, 5, 6, 7]
    tables = {row["name"] for row in await database.fetchall(
        "SELECT name FROM sqlite_master WHERE type = 'table'"
    )}
    assert {
        "characters", "life_logs", "schema_version", "education_actions", "jobs",
        "career_history", "career_actions", "npcs", "relationships", "children",
        "yearly_counters", "dating_sessions", "dating_candidates", "marriages",
        "pregnancies", "adoptions", "family_assets", "alimony", "affairs",
        "divorce_records", "stats_tracking", "infidelity_prompts", "infidelity_choices",
        "players", "shop_quotes", "trades", "trade_items", "trade_daily_usage",
        "inventory_uses", "audit_log",
    }.issubset(tables)
    family_asset_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(family_assets)")}
    loan_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(loans)")}
    shop_quote_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(shop_quotes)")}
    assert "is_locked" in family_asset_columns
    assert {"principal", "annual_rate", "term_years", "years_remaining", "collateral_item_uid"}.issubset(loan_columns)
    assert {"nonce", "total_price", "balance_cents", "character_version", "expires_at"}.issubset(shop_quote_columns)
````

## `lifeline/tests/test_shop.py`

````python
"""Stage 8 shop, inventory, financing, depreciation, and trade invariants."""
from __future__ import annotations

import asyncio
import json
from dataclasses import replace

import pytest
import pytest_asyncio

from core.errors import CharacterInPrison, InsufficientFunds, StaleShopQuote, ValidationError
from core.life_engine import LifeEngine
from core.locks import UserLockRegistry
from core.models import Character, Stats
from core.rng import RNG
from core.shop import ShopService
from core.validators import DataValidationError, validate_item_catalog


class MutableClock:
    """Simple injectable clock for reproducible trade expiry and account-age tests."""

    def __init__(self, value: int = 1_900_000_000) -> None:
        self.value = value

    def __call__(self) -> float:
        return float(self.value)


@pytest_asyncio.fixture
async def shop_context(database, life_engine):
    """Create a Stage 8 service with deterministic randomness and a mutable clock."""
    clock = MutableClock()
    service = ShopService(database, RNG(seed=808), UserLockRegistry(), clock=clock)
    return database, life_engine, service, clock


async def create_adult(life_engine: LifeEngine, service: ShopService, user_id: int, *, cash: int = 100_000_000, age: int = 25) -> Character:
    """Create an active adult character with enough test funds and a known age."""
    character = await life_engine.create_character(user_id, f"Player {user_id}")
    return await update_character(service, user_id, age=age, cash=cash, bank=0, in_prison=False)


async def update_character(service: ShopService, user_id: int, **changes: object) -> Character:
    """Apply test-only character fixture values through the versioned repository save."""
    async with service.db.transaction() as tx:
        character, version = await service._active_character(tx, user_id)
        updated = replace(character, **changes, version=version + 1)
        await service.repository.save_character(tx, updated, version)
        return updated


async def register_old_account(service: ShopService, user_id: int, clock: MutableClock) -> None:
    """Register a Discord account older than the seven-day imbalance threshold."""
    await service.register_player(user_id, clock.value - 8 * 24 * 60 * 60)


async def buy(service: ShopService, user_id: int, item_id: str, quantity: int = 1, method: str = "cash"):
    """Quote and confirm one item purchase using the quote's exact nonce/version."""
    quote = await service.quote_purchase(user_id, item_id, quantity)
    return await service.purchase(
        user_id,
        item_id,
        quantity,
        expected_version=quote.version,
        expected_total=quote.total_price,
        nonce=quote.nonce,
        payment_method=method,
        expected_down_payment=quote.down_payment if method == "finance" else None,
    )


async def item_uid(service: ShopService, user_id: int, item_id: str) -> int:
    """Return one matching inventory asset ID."""
    _, rows = await service.inventory(user_id)
    return next(int(row["asset_id"]) for row in rows if row["item_id"] == item_id)


@pytest.mark.asyncio
async def test_atomic_trade_transfers_items_and_audits(database, life_engine, shop_context):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1001)
    await create_adult(life_engine, service, 1002)
    await register_old_account(service, 1001, clock)
    await register_old_account(service, 1002, clock)
    await buy(service, 1001, "phone")
    await buy(service, 1002, "guitar")
    phone_uid = await item_uid(service, 1001, "phone")
    guitar_uid = await item_uid(service, 1002, "guitar")

    offer = await service.create_trade(
        1001, 1002,
        offered_items={phone_uid: 1},
        requested_items={guitar_uid: 1},
    )
    _, locked = await service.inventory(1001)
    assert next(row for row in locked if row["asset_id"] == phone_uid)["is_locked"]

    result = await service.accept_trade(offer.trade_id, 1002, offer.nonce)

    assert result.success
    assert result.status == "accepted"
    _, left = await service.inventory(1001)
    _, right = await service.inventory(1002)
    assert any(row["item_id"] == "guitar" for row in left)
    assert any(row["item_id"] == "phone" for row in right)
    trade = await database.fetchone("SELECT status FROM trades WHERE trade_id = ?", (offer.trade_id,))
    assert trade["status"] == "accepted"
    audit = await database.fetchone("SELECT action FROM audit_log WHERE action = 'trade_accepted' AND char_id = (SELECT char_id FROM characters WHERE user_id = 1002 AND is_alive = 1)")
    assert audit is not None


@pytest.mark.asyncio
async def test_requested_item_sold_mid_trade_fails_and_unlocks_offer(shop_context, life_engine):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1011)
    await create_adult(life_engine, service, 1012)
    await register_old_account(service, 1011, clock)
    await register_old_account(service, 1012, clock)
    await buy(service, 1011, "phone")
    await buy(service, 1012, "guitar")
    phone_uid = await item_uid(service, 1011, "phone")
    guitar_uid = await item_uid(service, 1012, "guitar")
    offer = await service.create_trade(
        1011, 1012,
        offered_items={phone_uid: 1},
        requested_items={guitar_uid: 1},
    )
    await service.sell(1012, "guitar", 1)

    result = await service.accept_trade(offer.trade_id, 1012, offer.nonce)

    assert not result.success
    assert result.status == "failed"
    _, rows = await service.inventory(1011)
    phone = next(row for row in rows if row["asset_id"] == phone_uid)
    assert not phone["is_locked"]


@pytest.mark.asyncio
async def test_locked_items_cannot_be_sold_or_used(shop_context, life_engine):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1021)
    await create_adult(life_engine, service, 1022)
    await register_old_account(service, 1021, clock)
    await register_old_account(service, 1022, clock)
    await buy(service, 1021, "energy_drink", 2)
    energy_uid = await item_uid(service, 1021, "energy_drink")
    offer = await service.create_trade(1021, 1022, offered_items={energy_uid: 1}, requested_items={})

    with pytest.raises(ValidationError, match="locked"):
        await service.sell(1021, "energy_drink", 1)
    with pytest.raises(ValidationError, match="locked"):
        await service.use(1021, "energy_drink")
    await service.cancel_trade(offer.trade_id, 1021, offer.nonce)


@pytest.mark.asyncio
async def test_self_trade_and_same_owner_are_blocked(shop_context, life_engine):
    _, _, service, _ = shop_context
    await create_adult(life_engine, service, 1031)
    with pytest.raises(ValidationError, match="yourself"):
        await service.create_trade(1031, 1031, offered_items={}, requested_items={}, offer_cash=1)


@pytest.mark.asyncio
async def test_pending_outgoing_rule_and_daily_limit_of_five(shop_context, life_engine):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1041, cash=1_000)
    await register_old_account(service, 1041, clock)
    for user_id in range(1042, 1049):
        await create_adult(life_engine, service, user_id, cash=1_000)
        await register_old_account(service, user_id, clock)
    first = await service.create_trade(1041, 1042, offered_items={}, requested_items={}, request_cash=1)
    with pytest.raises(ValidationError, match="pending outgoing"):
        await service.create_trade(1041, 1043, offered_items={}, requested_items={}, request_cash=1)
    await service.cancel_trade(first.trade_id, 1041, first.nonce)

    for target_id in range(1042, 1046):
        receipt = await service.create_trade(1041, target_id, offered_items={}, requested_items={}, request_cash=1)
        await service.cancel_trade(receipt.trade_id, 1041, receipt.nonce)
    with pytest.raises(ValidationError, match="five trades"):
        await service.create_trade(1041, 1046, offered_items={}, requested_items={}, request_cash=1)


@pytest.mark.asyncio
async def test_collateralized_items_are_not_tradeable_or_sellable(shop_context, life_engine):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1051, cash=2_000_000)
    await create_adult(life_engine, service, 1052)
    await register_old_account(service, 1051, clock)
    await register_old_account(service, 1052, clock)
    receipt = await buy(service, 1051, "trailer", method="finance")
    _, rows = await service.inventory(1051)
    trailer = next(row for row in rows if row["asset_id"] == receipt.asset_id)
    assert trailer["collateralized"]
    with pytest.raises(ValidationError, match="collateral loan"):
        await service.sell(1051, "trailer", 1)
    with pytest.raises(ValidationError, match="collateral loan"):
        await service.create_trade(1051, 1052, offered_items={receipt.asset_id: 1}, requested_items={})


@pytest.mark.asyncio
async def test_concurrent_accept_and_cancel_resolves_exactly_once(shop_context, life_engine):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1061, cash=10_000)
    await create_adult(life_engine, service, 1062, cash=10_000)
    await register_old_account(service, 1061, clock)
    await register_old_account(service, 1062, clock)
    offer = await service.create_trade(1061, 1062, offered_items={}, requested_items={}, offer_cash=100)

    accepted, cancelled = await asyncio.gather(
        service.accept_trade(offer.trade_id, 1062, offer.nonce),
        service.cancel_trade(offer.trade_id, 1061, offer.nonce),
    )
    terminal = [result for result in (accepted, cancelled) if result.success]
    assert len(terminal) == 1
    trade = await service.repository.trade_users_read(offer.trade_id)
    assert trade is not None
    row = await service.db.fetchone("SELECT status FROM trades WHERE trade_id = ?", (offer.trade_id,))
    assert row["status"] in {"accepted", "cancelled"}


@pytest.mark.asyncio
async def test_trade_tax_is_a_sunk_charge_rounded_up(shop_context, life_engine):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1071, cash=10)
    await create_adult(life_engine, service, 1072, cash=10)
    await register_old_account(service, 1071, clock)
    await register_old_account(service, 1072, clock)
    offer = await service.create_trade(1071, 1072, offered_items={}, requested_items={}, offer_cash=1)

    result = await service.accept_trade(offer.trade_id, 1072, offer.nonce)

    assert result.success
    left = await life_engine.get_active_character(1071)
    right = await life_engine.get_active_character(1072)
    assert left.cash == 8
    assert right.cash == 11
    fees = await service.db.fetchone("SELECT details_json FROM audit_log WHERE action = 'trade_accepted' AND char_id = ?", (right.char_id,))
    details = json.loads(fees["details_json"])
    assert details["offer_tax"] == 1
    assert details["request_tax"] == 0


@pytest.mark.asyncio
async def test_value_imbalance_requires_old_high_value_recipient_account(shop_context, life_engine):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1081)
    await create_adult(life_engine, service, 1082)
    await service.register_player(1081, clock.value - 3600)
    await register_old_account(service, 1082, clock)
    async with service.db.transaction() as tx:
        target, _ = await service._active_character(tx, 1082)
        rare_uid = await service.repository.insert_item(
            tx, char_id=target.char_id, item_id="original_art", quantity=1,
            purchase_price=10_000_001, current_value=10_000_001,
            age=target.age, now=clock.value,
        )

    with pytest.raises(ValidationError, match="seven days"):
        await service.create_trade(1081, 1082, offered_items={}, requested_items={rare_uid: 1})

    await create_adult(life_engine, service, 1083)
    await create_adult(life_engine, service, 1084)
    await register_old_account(service, 1083, clock)
    await register_old_account(service, 1084, clock)
    async with service.db.transaction() as tx:
        target, _ = await service._active_character(tx, 1084)
        uid = await service.repository.insert_item(
            tx, char_id=target.char_id, item_id="original_art", quantity=1,
            purchase_price=10_000_001, current_value=10_000_001,
            age=target.age, now=clock.value,
        )
    accepted_offer = await service.create_trade(1083, 1084, offered_items={}, requested_items={uid: 1})
    assert accepted_offer.imbalance_flag
    flag = await service.db.fetchone("SELECT 1 FROM audit_log WHERE action = 'trade_value_imbalance_flag' AND user_id = ?", (1083,))
    assert flag is not None


@pytest.mark.asyncio
async def test_overspending_is_blocked_and_balances_stay_nonnegative(shop_context, life_engine):
    _, _, service, _ = shop_context
    await create_adult(life_engine, service, 1091, cash=500)
    quote = await service.quote_purchase(1091, "phone")
    assert not quote.can_pay_cash
    with pytest.raises(InsufficientFunds):
        await service.purchase(
            1091, "phone", 1, expected_version=quote.version, expected_total=quote.total_price,
            nonce=quote.nonce,
        )
    character = await life_engine.get_active_character(1091)
    assert character.cash == 500
    assert character.bank == 0


@pytest.mark.asyncio
async def test_buy_then_sell_uses_current_value_and_always_loses(shop_context, life_engine):
    _, _, service, _ = shop_context
    await create_adult(life_engine, service, 1101, cash=10_000_000)
    purchase = await buy(service, 1101, "phone")
    sale = await service.sell(1101, "phone", 1)
    assert sale.payout == purchase.total_price * 85 // 100
    assert sale.payout < purchase.total_price


@pytest.mark.asyncio
async def test_depreciation_and_market_appreciation_by_category(shop_context, life_engine, monkeypatch):
    database, _, service, clock = shop_context
    await create_adult(life_engine, service, 1111, cash=10_000_000_000)
    purchases = {}
    for item_id in ("used_car", "phone", "starter_home", "original_art"):
        purchases[item_id] = await buy(service, 1111, item_id)
    monkeypatch.setattr(service.rng, "gauss", lambda mean, deviation: mean)
    async with database.transaction() as tx:
        character, _ = await service._active_character(tx, 1111)
        await service.advance_year(tx, character, now=clock.value + 1)
    _, rows = await service.inventory(1111)
    values = {row["item_id"]: int(row["current_value"]) for row in rows}
    assert values["used_car"] == purchases["used_car"].total_price * 85 // 100
    assert values["phone"] == purchases["phone"].total_price * 75 // 100
    assert values["starter_home"] == purchases["starter_home"].total_price * 1035 // 1000
    assert values["original_art"] == purchases["original_art"].total_price * 105 // 100


@pytest.mark.asyncio
async def test_expired_trade_unlocks_offered_items(shop_context, life_engine):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1121)
    await create_adult(life_engine, service, 1122)
    await register_old_account(service, 1121, clock)
    await register_old_account(service, 1122, clock)
    await buy(service, 1121, "energy_drink", 1)
    asset_id = await item_uid(service, 1121, "energy_drink")
    offer = await service.create_trade(1121, 1122, offered_items={asset_id: 1}, requested_items={})
    clock.value += 601

    count = await service.expire_pending()

    assert count == 1
    row = await service.db.fetchone("SELECT status FROM trades WHERE trade_id = ?", (offer.trade_id,))
    assert row["status"] == "expired"
    _, items = await service.inventory(1121)
    assert not next(row for row in items if row["asset_id"] == asset_id)["is_locked"]


@pytest.mark.asyncio
async def test_exception_mid_trade_rolls_back_both_characters_and_assets(shop_context, life_engine, monkeypatch):
    database, _, service, clock = shop_context
    await create_adult(life_engine, service, 1131, cash=1_000_000)
    await create_adult(life_engine, service, 1132, cash=1_000_000)
    await register_old_account(service, 1131, clock)
    await register_old_account(service, 1132, clock)
    await buy(service, 1131, "phone")
    await buy(service, 1132, "guitar")
    phone_uid = await item_uid(service, 1131, "phone")
    guitar_uid = await item_uid(service, 1132, "guitar")
    offer = await service.create_trade(
        1131, 1132,
        offered_items={phone_uid: 1},
        requested_items={guitar_uid: 1},
        offer_cash=100,
    )
    sender_before = await life_engine.get_active_character(1131)
    receiver_before = await life_engine.get_active_character(1132)
    original_transfer = service.repository.transfer_item
    calls = 0

    async def raise_after_first_transfer(tx, **kwargs):
        nonlocal calls
        result = await original_transfer(tx, **kwargs)
        calls += 1
        if calls == 1:
            raise RuntimeError("injected mid-trade failure")
        return result

    monkeypatch.setattr(service.repository, "transfer_item", raise_after_first_transfer)
    with pytest.raises(RuntimeError, match="injected"):
        await service.accept_trade(offer.trade_id, 1132, offer.nonce)
    monkeypatch.setattr(service.repository, "transfer_item", original_transfer)

    sender_after = await life_engine.get_active_character(1131)
    receiver_after = await life_engine.get_active_character(1132)
    assert (sender_after.cash, sender_after.bank, sender_after.version) == (sender_before.cash, sender_before.bank, sender_before.version)
    assert (receiver_after.cash, receiver_after.bank, receiver_after.version) == (receiver_before.cash, receiver_before.bank, receiver_before.version)
    trade = await database.fetchone("SELECT status FROM trades WHERE trade_id = ?", (offer.trade_id,))
    assert trade["status"] == "pending"
    _, sender_items = await service.inventory(1131)
    _, receiver_items = await service.inventory(1132)
    assert next(row for row in sender_items if row["asset_id"] == phone_uid)["is_locked"]
    assert any(row["asset_id"] == guitar_uid for row in receiver_items)


@pytest.mark.asyncio
async def test_conditional_transfer_failure_rolls_back_partial_assets_and_marks_failed(shop_context, life_engine, monkeypatch):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1211, cash=1_000_000)
    await create_adult(life_engine, service, 1212, cash=1_000_000)
    await register_old_account(service, 1211, clock)
    await register_old_account(service, 1212, clock)
    await buy(service, 1211, "phone")
    await buy(service, 1212, "guitar")
    phone_uid = await item_uid(service, 1211, "phone")
    guitar_uid = await item_uid(service, 1212, "guitar")
    offer = await service.create_trade(
        1211, 1212, offered_items={phone_uid: 1}, requested_items={guitar_uid: 1}
    )
    original_transfer = service.repository.transfer_item
    calls = 0

    async def fail_second_transfer(tx, **kwargs):
        nonlocal calls
        calls += 1
        if calls == 2:
            return None
        return await original_transfer(tx, **kwargs)

    monkeypatch.setattr(service.repository, "transfer_item", fail_second_transfer)
    result = await service.accept_trade(offer.trade_id, 1212, offer.nonce)

    assert not result.success
    assert result.status == "failed"
    _, left = await service.inventory(1211)
    _, right = await service.inventory(1212)
    assert not bool(next(row for row in left if row["asset_id"] == phone_uid)["is_locked"])
    assert any(row["asset_id"] == guitar_uid for row in right)
    assert not any(row["asset_id"] == phone_uid for row in right)
    assert not any(row["asset_id"] == guitar_uid for row in left)


@pytest.mark.asyncio
async def test_stale_shop_quote_nonce_or_version_is_rejected(shop_context, life_engine):
    _, _, service, _ = shop_context
    await create_adult(life_engine, service, 1141, cash=1_000_000)
    quote = await service.quote_purchase(1141, "phone")
    await update_character(service, 1141, cash=900_000)
    with pytest.raises(StaleShopQuote, match="changed"):
        await service.purchase(
            1141, "phone", 1, expected_version=quote.version, expected_total=quote.total_price,
            nonce=quote.nonce,
        )


@pytest.mark.asyncio
async def test_stale_balance_snapshot_is_rejected_even_if_version_was_not_advanced(shop_context, life_engine):
    database, _, service, _ = shop_context
    await create_adult(life_engine, service, 1221, cash=1_000_000)
    quote = await service.quote_purchase(1221, "phone")
    row = await database.fetchone(
        "SELECT char_id, data_json FROM characters WHERE user_id = ? AND is_alive = 1", (1221,)
    )
    character_data = json.loads(row["data_json"])
    character_data["cash"] -= 1
    await database.execute(
        "UPDATE characters SET data_json = ? WHERE char_id = ?",
        (json.dumps(character_data, separators=(",", ":")), row["char_id"]),
    )

    with pytest.raises(StaleShopQuote, match="balance changed"):
        await service.purchase(
            1221,
            "phone",
            1,
            expected_version=quote.version,
            expected_total=quote.total_price,
            nonce=quote.nonce,
        )


@pytest.mark.asyncio
async def test_catalog_has_seventy_valid_items_and_weapon_purchase_is_blocked(shop_context, life_engine):
    _, _, service, _ = shop_context
    assert len(service.items) >= 60
    await create_adult(life_engine, service, 1151)
    with pytest.raises(ValidationError, match="not sold"):
        await service.quote_purchase(1151, "prop_weapon")


def test_item_catalog_rejects_missing_required_item_fields():
    """Startup validation rejects malformed item definitions before bot service starts."""
    with pytest.raises(DataValidationError):
        validate_item_catalog({"schema_version": 1, "items": []})


@pytest.mark.asyncio
async def test_mortgage_uses_ten_percent_down_and_secures_the_house(shop_context, life_engine):
    _, _, service, _ = shop_context
    await create_adult(life_engine, service, 1161, cash=25_000_000)
    quote = await service.quote_purchase(1161, "starter_home")
    assert quote.total_price == 18_000_000
    assert quote.down_payment == 1_800_000
    receipt = await service.purchase(
        1161,
        "starter_home",
        1,
        expected_version=quote.version,
        expected_total=quote.total_price,
        nonce=quote.nonce,
        payment_method="finance",
        expected_down_payment=quote.down_payment,
    )
    assert receipt.paid_now == 1_800_000
    assert receipt.loan_principal == 16_200_000
    loan = await service.db.fetchone("SELECT loan_type, balance, collateral_item_uid FROM loans WHERE char_id = (SELECT char_id FROM characters WHERE user_id = ? AND is_alive = 1)", (1161,))
    assert loan["loan_type"] == "mortgage"
    assert loan["balance"] == 16_200_000
    assert loan["collateral_item_uid"] == receipt.asset_id


@pytest.mark.asyncio
async def test_consumable_use_clamps_stats_and_reduces_quantity(shop_context, life_engine):
    _, _, service, _ = shop_context
    await create_adult(life_engine, service, 1171, cash=100_000)
    character = await life_engine.get_active_character(1171)
    await update_character(service, 1171, stats=replace(character.stats, health=99, stress=99))
    await buy(service, 1171, "medication", 2)

    result = await service.use(1171, "medication")

    assert result.quantity_remaining == 1
    assert result.stats.health == 100
    assert result.stats.stress == 97
    _, rows = await service.inventory(1171)
    assert next(row for row in rows if row["item_id"] == "medication")["quantity"] == 1


@pytest.mark.asyncio
async def test_age_gates_and_crime_event_weapon_country_legality(shop_context, life_engine):
    _, _, service, _ = shop_context
    await create_adult(life_engine, service, 1181, age=17)
    with pytest.raises(ValidationError, match="at least 21"):
        await service.quote_purchase(1181, "nightclub")
    with pytest.raises(ValidationError, match="at least 18"):
        await service.award_crime_event_item(1181, "prop_weapon")
    await update_character(service, 1181, age=18, country="in")
    with pytest.raises(ValidationError, match="not legal"):
        await service.award_crime_event_item(1181, "prop_weapon")
    await update_character(service, 1181, country="usa")
    asset_id = await service.award_crime_event_item(1181, "prop_weapon")
    _, rows = await service.inventory(1181)
    assert any(row["asset_id"] == asset_id and row["item_id"] == "prop_weapon" for row in rows)


@pytest.mark.asyncio
async def test_yearly_shop_effects_run_inside_life_age_transaction(shop_context, life_engine):
    _, _, service, _ = shop_context
    await create_adult(life_engine, service, 1191, cash=100_000_000)
    await buy(service, 1191, "dog")
    await buy(service, 1191, "laundromat")
    character = await life_engine.get_active_character(1191)
    await update_character(service, 1191, stats=replace(character.stats, happiness=50))

    outcome = await life_engine.age_up(1191)

    assert outcome.character.age == 26
    assert outcome.character.stats.happiness >= 51
    assert outcome.character.bank >= 250_000
    assert outcome.character.cash < 74_950_000
    front = await service.db.fetchone("SELECT front_business FROM crime_profiles WHERE char_id = ?", (outcome.character.char_id,))
    assert front["front_business"] == 1
    assert any("annual business income" in message for message in outcome.log_messages)
    assert outcome.character.cash < 74_950_000


@pytest.mark.asyncio
async def test_trade_age_prison_and_ban_gates_are_enforced(shop_context, life_engine):
    database, _, service, clock = shop_context
    await create_adult(life_engine, service, 1201, age=17)
    await create_adult(life_engine, service, 1202)
    await register_old_account(service, 1201, clock)
    await register_old_account(service, 1202, clock)
    with pytest.raises(ValidationError, match="at least 18"):
        await service.create_trade(1201, 1202, offered_items={}, requested_items={}, offer_cash=1)
    await update_character(service, 1201, age=25, in_prison=True)
    with pytest.raises(CharacterInPrison, match="prison"):
        await service.create_trade(1201, 1202, offered_items={}, requested_items={}, offer_cash=1)
    await update_character(service, 1201, in_prison=False)
    await database.execute("UPDATE players SET trade_banned = 1 WHERE user_id = ?", (1201,))
    with pytest.raises(ValidationError, match="trade-banned"):
        await service.create_trade(1201, 1202, offered_items={}, requested_items={}, offer_cash=1)


@pytest.mark.asyncio
async def test_catalog_licenses_titles_and_weapons_are_not_shop_trade_offers(shop_context):
    """Protected catalog types cannot be sold from the regular inventory shop."""
    _, _, service, _ = shop_context
    assert service.items["title_homeowner"]["tradeable"] is False
    assert service.items["fishing_license"]["tradeable"] is False
    assert service.items["prop_weapon"]["tradeable"] is False
    assert service.items["prop_weapon"]["shop_available"] is False
````

## `lifeline/tests/test_stage8_cog_loading.py`

````python
"""File-backed Discord.py extension smoke test for Stage 8 commands."""
from __future__ import annotations

import discord
import pytest
from discord.ext import commands

from core.crime import CrimeService
from core.family import FamilyService
from core.locks import UserLockRegistry
from core.rng import RNG
from core.shop import ShopService


@pytest.mark.asyncio
async def test_shop_cog_loads_and_registers_all_stage8_groups(database):
    """Load the Stage 8 extension against migrated SQLite and inspect its slash groups."""
    bot = commands.Bot(command_prefix="!", intents=discord.Intents.none())
    bot.db = database
    bot.rng = RNG(808)
    bot.locks = UserLockRegistry()
    bot.shop_service = ShopService(database, bot.rng, bot.locks)

    try:
        await bot.load_extension("cogs.shop")
        shop = bot.tree.get_command("shop")
        inventory = bot.tree.get_command("inventory")
        trade = bot.tree.get_command("trade")
        assert shop is not None and {command.name for command in shop.commands} == {"browse", "buy", "ring"}
        assert inventory is not None and {command.name for command in inventory.commands} == {"view", "sell", "use"}
        assert trade is not None and {command.name for command in trade.commands} == {"offer", "list", "cancel"}
    finally:
        await bot.close()


@pytest.mark.asyncio
async def test_all_bot_extensions_load_without_shop_command_collisions(database):
    """Register all production extensions together and preserve the existing ring subcommand."""
    bot = commands.Bot(command_prefix="!", intents=discord.Intents.none())
    bot.db = database
    bot.rng = RNG(809)
    bot.locks = UserLockRegistry()
    bot.family_service = FamilyService(database, bot.rng, bot.locks)
    bot.crime_service = CrimeService(
        database,
        bot.rng,
        bot.locks,
        family_service=bot.family_service,
    )
    bot.shop_service = ShopService(database, bot.rng, bot.locks)
    extensions = (
        "cogs.life",
        "cogs.education",
        "cogs.career",
        "cogs.relationships",
        "cogs.crime",
        "cogs.prison",
        "cogs.shop",
        "cogs.discobot",
    )

    try:
        for extension in extensions:
            await bot.load_extension(extension)
        commands_by_name = {command.name: command for command in bot.tree.get_commands()}
        assert {"life", "relationship", "shop", "inventory", "trade"}.issubset(commands_by_name)
        assert {command.name for command in commands_by_name["shop"].commands} == {"browse", "buy", "ring"}
    finally:
        await bot.close()
````
