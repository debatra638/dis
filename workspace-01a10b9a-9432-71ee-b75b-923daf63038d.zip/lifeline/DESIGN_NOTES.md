# LIFELINE design notes — Casino, Investing, and Final Verification

This stage is a fictional, in-game economy. It has no real-money deposits, withdrawal, or cash-out. Persistent currency and prices are integer cents; external Discord dollar inputs are converted to cents at the command boundary. User-facing casino and investment commands use one shared user lock plus SQLite `BEGIN IMMEDIATE` transactions.

## Casino payout conventions and exact mathematics

Unless stated otherwise, a casino `payout_cents` is the **gross amount credited**, including the returned stake. Net result is `payout - bet`. A losing wager returns zero. Charges are rounded up; winnings are rounded down to cents.

### Slots — theoretical return to player (RTP)

Each of three reels is independent and uses the same weighted symbol table:

| Symbol | Weight | Probability |
|---|---:|---:|
| Cherry | 50 | 0.50 |
| Lemon | 30 | 0.30 |
| Bell | 15 | 0.15 |
| Diamond | 5 | 0.05 |

A two-of-a-kind (exactly one pair) returns `1.00 × stake` gross (the stake only); a three-of-a-kind returns the following gross multiple:

| Three matching symbols | Gross return |
|---|---:|
| Cherry | `1.50 × stake` |
| Lemon | `3.00 × stake` |
| Bell | `6.00 × stake` |
| Diamond | `22.00 × stake` |
| No pair | `0` |

For symbol probability `p`, the probability of exactly one pair is `3p²(1-p)`. Across all four symbols these probabilities sum to `0.6285`; because each such result returns 1×, pair outcomes contribute `0.6285` to expected gross return per unit staked. Three-of-a-kind outcomes contribute:

`0.50³×1.50 + 0.30³×3 + 0.15³×6 + 0.05³×22`

`= 0.1875 + 0.081 + 0.02025 + 0.00275 = 0.2915`.

Therefore theoretical gross RTP is `0.6285 + 0.2915 = 0.9200`, exactly **92.00%** before cent rounding; theoretical net expected value is `-8.00%`. Three-of-a-kind cherry returns are rounded down for odd-cent wagers, so integer-cent implementation can be microscopically below the theoretical figure. The Monte Carlo acceptance test uses a $100 stake so every listed multiplier is exact in cents.

### Blackjack

The player and dealer use a freshly shuffled six-deck shoe for each hand. The dealer stands on soft 17. Natural blackjack is two cards totaling 21; it pays 3:2 profit (gross return `2.5×` the bet, including returned stake). A regular win pays `1:1` profit (gross `2×`); pushes return `1×`; losses/busts pay zero. Double adds a second equal wager and receives exactly one card before automatic settlement.

### European roulette

The wheel has 37 equally likely pockets, `0` through `36`; zero is green and loses all red/black/odd/even/dozen bets. The payout ratios below are profit odds, with gross returns including returned stake:

| Bet | Profit odds | Gross return on a win | Win probability |
|---|---:|---:|---:|
| Red / black / odd / even | 1:1 | `2×` | `18/37` |
| Dozen (1–12, 13–24, 25–36) | 2:1 | `3×` | `12/37` |
| Straight number (0–36) | 35:1 | `36×` | `1/37` |

Each listed bet has net expected value `-1/37` of stake (about `-2.7027%`).

### Coinflip

A winning chosen side returns `1.94×` gross, including stake; a loss returns zero. With a fair 50/50 outcome, expected gross return is `0.5×1.94 = 0.97×`, for net expected value `-3.00%`.

### Lottery ticket

The shop's $10 ticket is a one-use casino item; its face price is the wager and it is consumed at use. Prize credits do **not** refund the ticket price. Probabilities are implemented as disjoint integer ranges from one 10,000,000-outcome draw:

| Prize | Outcomes | Probability | Expected prize at index 1.0 |
|---|---:|---:|---:|
| $50,000,000 jackpot | 1 | 1 in 10,000,000 | $5.00 |
| $10,000 tier | 100 | 1 in 100,000 | $0.10 |
| $100 tier | 10,000 | 1 in 1,000 | $0.10 |
| $10 tier | 100,000 | 1 in 100 | $0.10 |
| $2.50 tier | 1,000,000 | 1 in 10 | $0.25 |
| No prize | 8,888,899 | remainder | $0.00 |

Expected gross prize is `$5.55 × price_index`; the ticket costs `$10.00 × price_index`, so expected net value is `-$4.45 × price_index` (negative EV). The jackpot and each smaller prize scale with the world's price index and are floored to integer cents.

### Gambling limits, addiction, and taxes

Casino wagers are available from age `max(18, gambling_ages[country])`, require an active, living, non-imprisoned character, and cannot exceed `min(cash + bank, $250,000 × price_index)`. A persistent per-Discord-user three-second cooldown applies across casino games and lives; each character may place at most 25 wagers per in-game year. Standard lives record that count in `yearly_counters` anchored to an owned NPC. Legacy lives without NPC rows use `casino_yearly_bets` instead, avoiding a fake family member/foreign-key violation.

Each wager adds `0.2` to a float remainder in `stats_tracking`; each complete point is applied to the integer addiction stat. At addiction 60+, the `health_conditions` record `gambling_addiction` is diagnosed/active and an annual 25% chance creates a persisted resist-or-indulge compulsion choice. The recovery-program shop item reduces addiction by 20; below 60 the condition enters remission. Unresolved choices can be reopened with `/casino compulsion` and block the next `/life age`.

At the next yearly tick, positive annual gambling net above 500,000 cents ($5,000) is taxed at 24%, rounded up. Settled `casino_plays` are used; refunded hands do not create taxable net. When available cash and bank cannot cover a tax, balances remain non-negative and the unpaid amount is added to `debt_total`.

## Investing model

`stocks.json` is schema-validated at startup and contains 15 fictional companies in tech, energy, health, finance, consumer, and crypto-like sectors. HyperCoin is the high-volatility crypto-like ticker. Unknown country keys use the validated minimum-age fallback of 18 from `gambling_ages.json`; these are game rules, not legal advice.

Every 10 minutes the global market applies the specified geometric Brownian motion:

`price_new = floor(price × exp((drift - 0.5 × volatility²) × (1/52) + volatility × sqrt(1/52) × Z))`, with `Z ~ N(0,1)` and a one-cent floor.

A UTC market day gets at most one global event: a 2% crash chance, otherwise a 3% boom chance. Crash drops are 15–40%; boom gains are 10–25%. After movement, a still-listed stock below $1 has a 0.05% per-tick chance to delist at zero cents. Existing holdings remain recorded and are worth zero. The ticker commits all prices, histories, event markers, and cursor changes in one transaction; it writes no more than six catch-up ticks, skips the rest rather than backfilling, and unique `(symbol, tick_no)` history keys make a repeated tick idempotent. The most recent 500 points per symbol are retained.

Stock buy/sell execution reads current price and writes cash, holdings, trade, and audit rows in the same transaction. Orders are whole shares, paid from bank only. Brokerage is 0.5%, rounded up, with a $1 minimum. Buy fees are included in total cost basis; sale fees reduce realized proceeds. Partial sales allocate fee-inclusive basis proportionally, with integer-cent floor and the remaining basis retained in the position. Stock trades are limited to 20 per rolling real-time hour per player; an opposite-direction order for the same ticker is blocked for 60 seconds. Realized net capital gains (after sale fee and cost basis, net of realized losses) are taxed at 15% on the next yearly tick.

Bonds are purchased from bank, compound at 3.5% annually with interest rounded down to cents, and release principal plus interest after five character-year ticks. They have no early-withdrawal command. A second owned housing item is treated as a rental (the designated home, or the oldest home if none is designated, remains the primary residence): each extra home has a 10% yearly vacancy chance, earns 6% of current value if rented, and incurs price-index-adjusted upkeep. Rental net and bond interest are passed into the existing yearly household-income integration.

## Persistence and recovery

Migration `008_casino_investing.sql` adds the casino/game ledgers, pending sessions, disease row, global market, positions, bond ledger, and yearly accounting. Every write is parameterized and transaction-owned by the service caller. Blackjack escrow records the exact cash/bank debit and a rotating nonce; startup recovery changes only still-active sessions to `refunded`, restores those exact amounts, and settles the linked play row in the same transaction. Re-running recovery cannot refund a terminal session twice. Interactive buttons are owner-checked, nonce-checked server-side, and replaced/disabled after use; inactivity auto-stands after two minutes.

## Stage 12 — historical integration verification

Stage 12 originally added verification and defect repair only. Its 500-life run and archive-summary migration are retained in `core/migrations/011_repair_archived_life_summaries.sql` and `STAGE12_SOURCE_CONTENTS.md`. The historic report is not an apples-to-apples economy baseline for Parts A/B: those later parts add annual taxes, expenses, credit, loans, health incidence, and condition-aware competing mortality.

## Part A — integer-cent household economy

All persistent and service-layer money is integer cents. Discord amount text is parsed at the boundary by `core/money.py`; invalid signs, exponents, non-finite values, malformed grouping, excess decimal places, and out-of-range amounts are rejected. `charge_cents` rounds charges/fees upward; `payout_cents` rounds salaries, interest, and credits downward. Repository SQL is parameterized and mutations are performed within the caller's `BEGIN IMMEDIATE` transaction so a failed write rolls back balances and ledgers together.

Progressive income tax uses inflation-indexed marginal brackets. For each bracket, the taxable width is multiplied by the configured rate and country tax modifier; the final liability is rounded up to a cent and cannot exceed income. Joint filing doubles bracket thresholds. Realized net capital gains are taxed separately at the configured rate. Each annual inflation draw is Gaussian with the configured mean and standard deviation, clamped to the configured minimum and maximum; the price index updates as `min(INFLATION_INDEX_CAP, max(0.1, prior_index × (1 + annual_inflation_draw)))`. Annual living costs, rent, insurance, healthcare, and other indexed prices use that index.

The annual settlement sequence is: earned and business/investment income; criminal household income and income-tax decision; mandatory living, rent, and annual insurance charges; collections recovery capped at 20% of available balances; active-loan interest and scheduled payments; forced low-price stock liquidation if needed for required bills; loan default/repo/deficiency collection; bank interest and theft; then index/counter persistence. Rent shortfalls trigger eviction to temporary housing. Bills do not overdraft: unpaid balances become debt/collections. Banking transfers move cash and deposits without changing total wealth.

Loans use the standard fixed-rate amortizing payment formula `payment = P × r × (1+r)^n / ((1+r)^n − 1)` (rounded up), with `P/n` for zero-rate loans. The six configured types are personal, student, mortgage, auto, payday, and loan shark. Conventional loans require salary-based debt-service capacity; collateral is server-validated, student loans have a grace period, and three missed required payments trigger default. Bankruptcy is available only to insolvent adults outside prison; eligible unsecured personal/payday/loan-shark balances and open collections may be discharged. Student and secured debt survive. The current balance constants set a 10-year filing cooldown and seven-year rebuilding period.

## Part B — health progression and care

The fictional catalog has 28 unique conditions. Annual onset probability is

`min(0.25, base_probability × HEALTH_DISEASE_ONSET_MULTIPLIER × age_factor × health_factor × fitness_factor)`,

where the current balance multiplier is `0.09`, `age_factor = 1 + max(0, age − 30) × 0.01`, `health_factor = clamp(1 + (60 − health)/1000 × 6, 0.50, 1.50)`, and `fitness_factor = clamp(1 + (50 − fitness)/100 × 0.5, 0.75, 1.25)`. Gambling addiction has no random catalog onset; casino rules create its condition record. Non-chronic conditions resolve after catalog duration. Untreated active conditions progress after three untreated years with a 20% annual roll; diagnosed doctor/hospital/surgery/therapy actions reduce severity or resolve eligible conditions. Each health action type is limited to once per in-game year; insurance is prepaid for one year, charges the configured premium, and applies the configured copay to eligible care.

The health baseline retains the configured age/lifespan curve: `age_hazard = 0.001 + max(0, age − 55) × 0.00035`; `lifespan_hazard = max(0, age − expected_lifespan) × 0.018`; health and fitness multipliers adjust that natural hazard. Active illness adds `severity × 0.0012 + min(10, years_untreated) × 0.0005` per condition, capped at `HEALTH_MAX_ILLNESS_HAZARD = 0.25`. Independent natural and illness risks combine as `1 − (1 − natural) × (1 − illness)`. Health at zero and configured maximum age end the life. The baseline measurement in `tools/measure_balance.py` is explicitly no-condition; integrated illness incidence and mortality are measured by the SQLite-backed full-life harness.

Care prices start at $350 per doctor visit, $2,500 per hospital visit, $125 per therapy visit, and $2,000 plus $1,000 per severity point for medical surgery; country healthcare modifiers and the world price index apply. Insurance reduces eligible care to the configured 20% copay. The existing `/health surgery` command retains medical treatment and exposes plastic surgery as the `procedure: plastic` choice; that elective option is adult-only, unavailable in prison, adds up to five looks points (capped at 100), shares the once-per-year surgery limit, and charges a $20,000 base fee indexed by country and inflation. Cosmetic surgery is not insured. The top-level `/doctor`, `/hospital`, `/therapy`, and `/insurance` commands are aliases that call the same validated services as `/health doctor`, `/health hospital`, `/health therapy`, and `/health insurance`. These are fictional, supportive, PG-13 systems and are not medical advice; no self-harm mechanic is present.

## Part C — balance constants and observed limits

The current balance values are documented from `core/config.py`, not inferred from older pilot notes: disease onset multiplier `0.09`; annual inflation mean `2.8%` (standard deviation `1.2%`, bounded from `−1%` to `9%`); wage-inflation pass-through `0.8`; career salary-base multiplier `0.83`; and degree salary multiplier `0.71`. The earlier 50-life onset probes remain historical evidence: at multiplier `0.25`, the probe had 35 illness deaths and a 64.5-year median; at `0.10`, it had 16 illness deaths and a 77.5-year median. Those probes support reducing excessive incidence but do not isolate the precise effect of `0.09`. The current `0.09` is retained rather than reset to `1.0`: the 100-life checks at `0.09` had normal medians 80.5/82.5 and addiction medians 52.5/46 (PASS), with one heavy-crime median 66.5 (FAIL) and one 48.5 (PASS). In the final-size 500-life cohorts, normal medians were 79/79.5, crime medians 58/53, and addiction medians 53/53; all six lifespan measures were in range. This is supportive, not a controlled estimate of the multiplier's causal effect. Resetting to `1.0` would multiply uncapped onset probability by about 11.1 relative to the configured value and has not been validated; no outcome at `1.0` is claimed. The crime custody opportunity-cost proxy remains `$52,000 per sentence year` (`5,200,000` cents) and is reported separately from direct loot/fine EV.

Numeric acceptance ranges are supplied by the current full-life harness and are listed in the final PASS/FAIL tables in this report and `VERIFICATION_REPORT.md`; historic Stage 12 measurements are context, not a substitute for those checks. Casino payout rules were measured, not retuned; their RTPs are controlled by existing game rules rather than a new config knob. The 100-life tuning cohorts use separate stress-profile parameters for sustained crime and gambling exposure; these are measurement settings in `tests/test_full_lives.py`, not player-facing balance constants.

Exact current seeds, sample sizes, distributions, tests, known limitations, and the source-file bundle are documented in `VERIFICATION_REPORT.md`.

## Final validation — 2026-10-05

The configured bankruptcy floor remains `181,200,000` cents ($1,812,000). The higher floor makes bankruptcy rare for ordinary players because an adult must have at least $1.812m of dischargeable unsecured debt, more than twice gross assets, and insufficient cash/bank plus ten years of after-tax surplus to repay; student, mortgage, auto, and linked-mirror amounts are excluded, prison and the two-year first-loan rule remain in force. The $1.2m request is unmet: the source diagnostic found $1.215m–$1.396m of standalone living-expense arrears with no assets or modeled repayment capacity, so that lower floor admitted accounts below the desired rarity threshold under the prior automatic-file policy. That historical 20% filing result is not a natural population rate. The corrected cohort now audits eligibility but never calls the filing service. With no modeled player decision, its observed actual filing rate is 0% (FAIL against 3–10%); changing the debt floor cannot produce user actions, so no new threshold was selected from these runs. The $1.812m setting is retained per the latest direction, not presented as a passed natural-filing-rate result.

The disease-onset multiplier stays at `0.09`, rather than resetting to `1.0`. Historical 50-life pilots recorded 35 illness deaths and 64.5 median lifespan at `0.25`, versus 16 illness deaths and 77.5 median at `0.10`. In the two new `0.09` cohorts, normal-life medians were 82.5/80.5 and addiction-profile medians 46/52.5 (PASS); crime medians were 48.5 (PASS) and 66.5 (FAIL). These are descriptive fixed-seed results, not a controlled multiplier comparison. Multiplier `1.0` has not been run; it would increase uncapped onset risk about 11.1-fold versus `0.09`, so no claim that it would pass is made.

The health commands retain `/health surgery` with an optional `procedure` choice; choose `plastic` for adult-only elective cosmetic surgery, or `medical` plus a condition ID for existing treatment. Plastic surgery is $20,000 base, indexed, non-insured, once per in-game year, and improves looks by up to five points to a cap of 100. Top-level `/doctor`, `/hospital`, `/therapy`, and `/insurance` are aliases to the existing health services.

### 100-life tuning cohorts (small-sample check)

Commands run: `LIFELINE_RUN_FULL_LIVES=1 LIFELINE_LIFE_COUNT=100 LIFELINE_SIMULATION_SEED=20261004 python -m pytest -q -s tests/test_full_lives.py` and `LIFELINE_RUN_FULL_LIVES=1 LIFELINE_LIFE_COUNT=100 LIFELINE_SIMULATION_SEED=20261005 python -m pytest -q -s tests/test_full_lives.py`. Each `pytest` run completed, but the table below reports acceptance statuses separately; a successful test process does not make an out-of-range target pass.

| Acceptance target | Required range | Seed 20261004 (n=100) | Seed 20261005 (n=100) |
|---|---:|---:|---:|
| Normal median lifespan | 75–85 years | 82.5 — PASS | 80.5 — PASS |
| Heavy-crime median lifespan | 45–65 years | 48.5 — PASS | 66.5 — FAIL |
| Heavy-addiction median lifespan | 45–65 years | 46 — PASS | 52.5 — PASS |
| Normal lives reaching $1m peak net worth | 8–20% | 21.67% — FAIL | 20.00% — PASS |
| Normal lives reaching $1b peak net worth | <0.5% | 0% — PASS | 0% — PASS |
| Actual bankruptcy filing rate (not eligibility rate) | 3–10% | 0/60 = 0% — FAIL | 0/60 = 0% — FAIL |
| College-graduate median final net worth | 25,000,000–150,000,000¢ | 98,031,477¢ — PASS | 79,170,182¢ — PASS |
| No-high-school median final net worth | 0–15,000,000¢ | No observations (n=0) — FAIL | No observations (n=0) — FAIL |
| Average-performer time to first promotion | 2–4 years | 3.5 — PASS | 3.0 — PASS |

The 100-life cohorts recorded 42 and 38 eligible-debt checks respectively, but no life submitted `/finance bankruptcy`; the measured 0% filing rate is FAIL against 3–10% and is not a population propensity estimate. The no-high-school subgroup had no observations at 100 lives, so that value is FAIL/not measured in these smaller cohorts.

### Final-size 500-life no-forced-filing cohorts

These cohorts use the same accepted settings and seeds, with 500 complete lives per seed (300 normal, 100 heavy-crime, 100 heavy-addiction). They reduce the small-sample subgroup issue; they still do not model a user filing decision.

| Acceptance target | Required range | Seed 20261004 (n=500) | Seed 20261005 (n=500) |
|---|---:|---:|---:|
| Normal median lifespan | 75–85 years | 79.0 — PASS | 79.5 — PASS |
| Heavy-crime median lifespan | 45–65 years | 58.0 — PASS | 53.0 — PASS |
| Heavy-addiction median lifespan | 45–65 years | 53.0 — PASS | 53.0 — PASS |
| Normal lives reaching $1m peak net worth | 8–20% | 20.33% — FAIL | 19.67% — PASS |
| Normal lives reaching $1b peak net worth | <0.5% | 0% — PASS | 0% — PASS |
| Actual bankruptcy filing rate (not eligibility rate) | 3–10% | 0/300 = 0% — FAIL | 0/300 = 0% — FAIL |
| College-graduate median final net worth | 25,000,000–150,000,000¢ | 58,109,698.5¢ — PASS | 66,044,299¢ — PASS |
| No-high-school median final net worth | 0–15,000,000¢ | 0¢ (n=6) — PASS | 0¢ (n=7) — PASS |
| Average-performer time to first promotion | 2–4 years | 3 — PASS | 3 — PASS |

The 500-life runs recorded 88 and 175 eligibility checks, respectively, but still no filing actions. Thus the 3–10% result remains 0% regardless of cohort size; no threshold can supply player behavior. The other 500-life results are within range except the seed-20261004 millionaire rate, 0.33 percentage points over the ceiling. The multiplier `0.09` cohorts meet all three lifespan bands at this larger sample size.
