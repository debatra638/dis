"""Runnable regressions for strict money, credit, bills, loans, and bankruptcy."""
from __future__ import annotations

import json
from dataclasses import replace
import aiosqlite
import pytest

from core.config import GameBalance
from core.economy import (
    EconomyService,
    amortized_annual_payment,
    capital_gains_tax,
    loan_interest_cents,
    progressive_income_tax,
)
from core.errors import InsufficientFunds, ValidationError
from core.life_engine import LifeEngine
from core.models import Character, EducationLevel, HousingType, Lifestyle
from core.money import MAX_INPUT_CENTS, charge_cents, parse_cents, payout_cents
from core.rng import RNG


async def set_character(engine: LifeEngine, user_id: int, **changes: object) -> Character:
    """Set up explicit economic test state through the optimistic character save."""
    async with engine.db.transaction() as tx:
        cursor = await tx.execute(
            "SELECT data_json, version FROM characters WHERE user_id = ? AND is_alive = 1", (user_id,)
        )
        row = await cursor.fetchone()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.version = int(row["version"])
        updated = replace(character, **changes, version=character.version + 1)
        await engine._save_character(tx, updated, expected_version=character.version)
        return updated


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("$1,234.56", 123456),
        ("1.2k", 120000),
        ("$3m", 300_000_000),
        ("0", 0),
        ("$100,000,000,000", MAX_INPUT_CENTS),
    ],
)
def test_money_parser_accepts_only_nonnegative_cents_grammar(text: str, expected: int) -> None:
    assert parse_cents(text) == expected


@pytest.mark.parametrize("text", ["-$1", "+$1", "1e3", "NaN", "inf", "$1,23", "$100,000,000,000.01", "1.234"])
def test_money_parser_rejects_negative_exponent_nonfinite_and_out_of_range(text: str) -> None:
    with pytest.raises(ValueError):
        parse_cents(text)


def test_money_parser_supports_all_only_when_a_command_opts_in() -> None:
    assert parse_cents(" ALL ", allow_all=True) is None
    with pytest.raises(ValueError):
        parse_cents("all")


def test_progressive_tax_boundaries_inflation_and_capital_gains() -> None:
    assert progressive_income_tax(999_999) == 100_000
    assert progressive_income_tax(1_000_000) == 100_000
    assert progressive_income_tax(1_000_001) == 100_001
    assert progressive_income_tax(4_000_000) == 1_150_000
    assert progressive_income_tax(4_000_001) == 1_150_001
    assert progressive_income_tax(1_000_000, price_index=2.0) == 100_000
    assert progressive_income_tax(1_000_000, price_index=2.0, tax_mod=0.5) == 50_000
    assert progressive_income_tax(10_000_000, joint=True) < progressive_income_tax(10_000_000)
    assert capital_gains_tax(101) == 21
    assert capital_gains_tax(-1) == 0
    assert amortized_annual_payment(1_000_000, 0.12, 5) == 277_410
    assert amortized_annual_payment(100, 0, 3) == 34
    assert loan_interest_cents(101, 0.05) == 6


@pytest.mark.asyncio
async def test_bank_transfers_all_and_checked_balance_mirrors(database, life_engine) -> None:
    user_id = 880_001
    await life_engine.create_character(user_id, "Bank Test")
    await set_character(life_engine, user_id, cash=123_456, bank=789)
    service: EconomyService = life_engine.economy

    character, moved = await service.bank_transfer(user_id, "deposit", None)
    assert moved == 123_456
    assert (character.cash, character.bank) == (0, 124_245)
    character, moved = await service.bank_transfer(user_id, "withdraw", 24_245)
    assert moved == 24_245
    assert (character.cash, character.bank) == (24_245, 100_000)

    row = await database.fetchone(
        "SELECT cash_cents, bank_cents FROM characters WHERE user_id = ? AND is_alive = 1", (user_id,)
    )
    assert (row["cash_cents"], row["bank_cents"]) == (24_245, 100_000)
    with pytest.raises(InsufficientFunds):
        await service.bank_transfer(user_id, "withdraw", 100_001)
    with pytest.raises(ValidationError):
        await service.bank_transfer(user_id, "deposit", -1)


@pytest.mark.asyncio
async def test_randomized_transfers_never_make_either_balance_negative(database, life_engine) -> None:
    user_id = 880_002
    await life_engine.create_character(user_id, "Balance Fuzz")
    await set_character(life_engine, user_id, cash=50_000, bank=75_000)
    service = life_engine.economy
    fuzz = RNG(20261001)
    for _ in range(500):
        direction = fuzz.choice(("deposit", "withdraw"))
        amount = fuzz.randint(1, 200_000)
        try:
            await service.bank_transfer(user_id, direction, amount)
        except InsufficientFunds:
            pass
        row = await database.fetchone(
            "SELECT cash_cents, bank_cents FROM characters WHERE user_id = ? AND is_alive = 1", (user_id,)
        )
        assert row["cash_cents"] >= 0
        assert row["bank_cents"] >= 0
    async with database.transaction() as tx:
        with pytest.raises(aiosqlite.IntegrityError):
            await tx.execute(
                "UPDATE characters SET cash_cents = -1 WHERE user_id = ? AND is_alive = 1", (user_id,)
            )


@pytest.mark.asyncio
async def test_lifestyle_inflation_savings_interest_and_bank_theft(database, life_engine, monkeypatch) -> None:
    user_id = 880_003
    await life_engine.create_character(user_id, "Yearly Economy")
    character = await set_character(
        life_engine, user_id, age=20, bank=10_000_000, cash=0,
        housing_type=HousingType.PARENTS, lifestyle=Lifestyle.FRUGAL,
        price_index=1.0, wealth_class="middle", has_insurance=False,
    )
    monkeypatch.setattr(GameBalance, "BANK_INTEREST_RATE", 0.10)
    monkeypatch.setattr(GameBalance, "BANK_THEFT_ANNUAL_CHANCE", 1.0)
    monkeypatch.setattr(GameBalance, "BANK_THEFT_MIN_FRACTION", 0.10)
    monkeypatch.setattr(GameBalance, "BANK_THEFT_MAX_FRACTION", 0.10)
    service = life_engine.economy
    service.rng = RNG(4)
    expected_rng = RNG(4)
    expected_rng.random()  # annual bank-theft roll
    expected_rng.uniform(0.10, 0.10)  # theft amount draw
    expected_inflation = min(
        GameBalance.ANNUAL_INFLATION_MAX,
        max(
            GameBalance.ANNUAL_INFLATION_MIN,
            expected_rng.gauss(
                GameBalance.ANNUAL_INFLATION_MEAN,
                GameBalance.ANNUAL_INFLATION_STDDEV,
            ),
        ),
    )
    async with database.transaction() as tx:
        result = await service.advance_year(tx, character, previous_age=19, now=1_800_000_001)
    expected_living = charge_cents(GameBalance.BASE_ANNUAL_LIVING_COST_CENTS, 0.75)
    expected_interest = payout_cents(10_000_000 - expected_living, 0.10)
    expected_theft = charge_cents(10_000_000 - expected_living + expected_interest, 0.10)
    assert result.living_cost_cents == expected_living
    assert result.interest_cents == expected_interest
    assert result.theft_cents == expected_theft
    assert result.character.bank == 10_000_000 - expected_living + expected_interest - expected_theft
    assert result.character.price_index == pytest.approx(1 + expected_inflation)
    assert any("theft" in message.lower() for message in result.messages)


@pytest.mark.asyncio
async def test_rent_shortfall_evicts_and_records_collections(database, life_engine) -> None:
    user_id = 880_004
    await life_engine.create_character(user_id, "Eviction Test")
    character = await set_character(
        life_engine, user_id, age=22, cash=0, bank=0, debt_total=0,
        housing_type=HousingType.RENT, rent_amount=1_000_000,
    )
    async with database.transaction() as tx:
        result = await life_engine.economy.advance_year(tx, character, previous_age=21, now=1_800_000_002)
        rows = await life_engine.economy.repository.collection_rows(tx, character.char_id)
    assert result.character.housing_type is HousingType.HOMELESS
    assert result.character.cash >= 0 and result.character.bank >= 0
    assert result.character.debt_total >= GameBalance.BASE_ANNUAL_LIVING_COST_CENTS + 1_000_000
    assert any(row["source"] == "rent" and row["status"] == "open" for row in rows)
    assert any("eviction" in message.lower() for message in result.messages)


@pytest.mark.asyncio
async def test_all_six_loan_products_have_amortizing_terms_and_credit_gates(database, life_engine) -> None:
    expected = {"personal", "student", "mortgage", "auto", "payday", "loan_shark"}
    assert set(GameBalance.LOAN_TERMS) == expected
    for kind, terms in GameBalance.LOAN_TERMS.items():
        principal = min(100_000, int(terms["max_cents"]))
        payment = amortized_annual_payment(principal, float(terms["annual_rate"]), int(terms["term_years"]))
        assert payment > 0
        assert payment >= loan_interest_cents(principal, float(terms["annual_rate"]))

    user_id = 880_009
    await life_engine.create_character(user_id, "Credit Gate")
    await set_character(life_engine, user_id, age=25, stats=replace(
        (await life_engine.economy.loan_status(user_id))[0].stats, credit_score=500
    ))
    with pytest.raises(ValidationError, match="credit score"):
        await life_engine.economy.apply_for_loan(user_id, "personal", 100_000)


@pytest.mark.asyncio
async def test_mandatory_expense_cascade_sells_lowest_price_stock_first(database, life_engine) -> None:
    user_id = 880_010
    await life_engine.create_character(user_id, "Cascade Test")
    character = await set_character(
        life_engine, user_id, age=20, cash=0, bank=0, debt_total=0,
        housing_type=HousingType.PARENTS, wealth_class="middle",
    )
    await life_engine.investing.initialize_market()
    async with database.transaction() as tx:
        rows = await life_engine.investing.repository.list_stocks(tx)
        low_symbol, high_symbol = str(rows[0]["symbol"]), str(rows[1]["symbol"])
        await tx.execute("UPDATE stock_market SET price_cents = 100 WHERE symbol = ?", (low_symbol,))
        await tx.execute("UPDATE stock_market SET price_cents = 1000 WHERE symbol = ?", (high_symbol,))
        await tx.execute(
            "INSERT INTO stock_holdings(char_id, symbol, shares, cost_basis_cents, updated_at) VALUES (?, ?, ?, ?, ?)",
            (character.char_id, low_symbol, 10_000, 1_000_000, 1),
        )
        await tx.execute(
            "INSERT INTO stock_holdings(char_id, symbol, shares, cost_basis_cents, updated_at) VALUES (?, ?, ?, ?, ?)",
            (character.char_id, high_symbol, 1_000, 1_000_000, 1),
        )
        result = await life_engine.economy.advance_year(tx, character, previous_age=19, now=1_800_000_003)
        trades = await tx.execute(
            "SELECT symbol, shares FROM investment_trades WHERE char_id = ? ORDER BY investment_trade_id",
            (character.char_id,),
        )
        sold = await trades.fetchall()
        remaining = await tx.execute(
            "SELECT symbol, shares FROM stock_holdings WHERE char_id = ? ORDER BY symbol", (character.char_id,)
        )
        holdings = {row["symbol"]: int(row["shares"]) for row in await remaining.fetchall()}
    assert result.stock_liquidation_cents >= result.living_cost_cents
    assert [row["symbol"] for row in sold] == [low_symbol, high_symbol]
    assert low_symbol not in holdings
    assert holdings[high_symbol] < 1_000
    assert result.character.cash >= 0 and result.character.bank >= 0


@pytest.mark.asyncio
async def test_student_loan_origination_and_manual_full_payoff(database, life_engine) -> None:
    user_id = 880_005
    await life_engine.create_character(user_id, "Student Loan")
    await set_character(life_engine, user_id, age=20, cash=0, bank=0, debt_total=0)
    quote, character, loan_id = await life_engine.economy.apply_for_loan(
        user_id, "student", 500_000
    )
    assert quote.annual_rate == 0.05
    assert quote.term_years == 10
    assert quote.annual_payment_cents == amortized_annual_payment(500_000, 0.05, 10)
    assert character.bank == 500_000
    assert character.debt_total == 500_000
    character, paid, remaining = await life_engine.economy.pay_loan(user_id, loan_id, None)
    assert paid == 500_000 and remaining == 0
    loan = await database.fetchone("SELECT status, balance FROM loans WHERE loan_id = ?", (loan_id,))
    assert loan["status"] == "paid" and loan["balance"] == 0
    assert character.debt_total == 0


@pytest.mark.asyncio
async def test_unpaid_loan_defaults_and_repossesses_collateral(database, life_engine) -> None:
    user_id = 880_006
    await life_engine.create_character(user_id, "Repo Test")
    character = await set_character(
        life_engine, user_id, age=25, cash=0, bank=0, debt_total=100,
        housing_type=HousingType.PARENTS,
    )
    async with database.transaction() as tx:
        cursor = await tx.execute(
            """INSERT INTO family_assets
                   (char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at)
               VALUES (?, 'item', 'starter_home', 1, 50_000, 50_000, 20, 1)""",
            (character.char_id,),
        )
        asset_id = int(cursor.lastrowid)
        loan_id = await life_engine.economy.repository.create_loan(
            tx, char_id=character.char_id, loan_type="mortgage", principal=100,
            annual_rate=0.0, term_years=5, annual_payment=100,
            age=20, collateral_item_uid=asset_id,
        )
    current = character
    for previous_age in (20, 21, 22):
        current = replace(current, age=previous_age + 1)
        async with database.transaction() as tx:
            result = await life_engine.economy.advance_year(
                tx, current, previous_age=previous_age, now=1_800_000_010 + previous_age
            )
        current = result.character
    loan = await database.fetchone("SELECT status, consecutive_misses FROM loans WHERE loan_id = ?", (loan_id,))
    asset = await database.fetchone("SELECT is_liquidated, quantity FROM family_assets WHERE asset_id = ?", (asset_id,))
    assert loan["status"] == "defaulted"
    assert loan["consecutive_misses"] == 3
    assert asset["is_liquidated"] == 1 and asset["quantity"] == 0
    assert current.cash >= 0 and current.bank >= 0


@pytest.mark.asyncio
async def test_bankruptcy_discharge_cooldown_and_student_debt_survival(database, life_engine) -> None:
    user_id = 880_007
    await life_engine.create_character(user_id, "Bankruptcy Test")
    character = await set_character(life_engine, user_id, age=30, cash=0, bank=0, debt_total=206_000_000)
    async with database.transaction() as tx:
        personal_id = await life_engine.economy.repository.create_loan(
            tx, char_id=character.char_id, loan_type="personal", principal=200_000_000,
            annual_rate=0.12, term_years=5, annual_payment=55_482_000, age=22,
        )
        await tx.execute("UPDATE loans SET status = 'defaulted' WHERE loan_id = ?", (personal_id,))
        await life_engine.economy.repository.add_collection(
            tx, char_id=character.char_id, source="loan_deficiency", balance=200_000_000,
            age=29, now=1_800_000_000, loan_id=personal_id,
        )
        student_id = await life_engine.economy.repository.create_loan(
            tx, char_id=character.char_id, loan_type="student", principal=5_000_000,
            annual_rate=0.05, term_years=10, annual_payment=647_505, age=22,
        )
        mortgage_id = await life_engine.economy.repository.create_loan(
            tx, char_id=character.char_id, loan_type="mortgage", principal=500_000_000,
            annual_rate=0.06, term_years=30, annual_payment=36_000_000, age=22,
        )
        auto_id = await life_engine.economy.repository.create_loan(
            tx, char_id=character.char_id, loan_type="auto", principal=400_000_000,
            annual_rate=0.08, term_years=7, annual_payment=80_000_000, age=22,
        )
        for loan_id, balance in ((student_id, 5_000_000), (mortgage_id, 500_000_000), (auto_id, 400_000_000)):
            await life_engine.economy.repository.add_collection(
                tx, char_id=character.char_id, source="loan_deficiency", balance=balance,
                age=29, now=1_800_000_000, loan_id=loan_id,
            )
        await life_engine.economy.repository.add_collection(
            tx, char_id=character.char_id, source="rent", balance=1_000_000,
            age=29, now=1_800_000_000,
        )
    assessment = await life_engine.economy.bankruptcy_eligibility(user_id)
    assert assessment.eligible is True
    assert assessment.dischargeable_debt_cents == 201_000_000
    updated, debt_before, discharged = await life_engine.economy.file_bankruptcy(user_id)
    assert debt_before >= 206_000_000
    assert discharged == 201_000_000
    assert updated.stats.credit_score == GameBalance.CREDIT_SCORE_MIN
    assert updated.bankrupt_until_age == 37
    async with database.transaction() as tx:
        rows = {row["loan_id"]: row for row in await life_engine.economy.repository.loan_rows(tx, character.char_id)}
        collections = await life_engine.economy.repository.collection_rows(tx, character.char_id)
    # Only dischargeable unsecured balances are cleared; student and secured debt survive.
    assert rows[personal_id]["status"] == "discharged"
    assert rows[student_id]["status"] == "active"
    assert rows[mortgage_id]["status"] == "active"
    assert rows[auto_id]["status"] == "active"
    collection_status_by_loan_id = {row["loan_id"]: row["status"] for row in collections if row["loan_id"] is not None}
    assert collection_status_by_loan_id[personal_id] == "discharged"
    assert collection_status_by_loan_id[student_id] == "open"
    assert collection_status_by_loan_id[mortgage_id] == "open"
    assert collection_status_by_loan_id[auto_id] == "open"
    assert next(row for row in collections if row["source"] == "rent")["status"] == "discharged"
    unlocked = await life_engine.achievements.check_user(user_id)
    assert any(row["id"] == "bankrupt" for row in unlocked)
    with pytest.raises(ValidationError, match="wait"):
        await life_engine.economy.file_bankruptcy(user_id)


@pytest.mark.asyncio
async def test_bankruptcy_assessment_excludes_secured_debt_and_linked_mirrors(database, life_engine) -> None:
    user_id = 880_014
    await life_engine.create_character(user_id, "Secured Debt Test")
    character = await set_character(
        life_engine, user_id, age=30, cash=0, bank=0, debt_total=1_200_000_000
    )
    async with database.transaction() as tx:
        mortgage_id = await life_engine.economy.repository.create_loan(
            tx, char_id=character.char_id, loan_type="mortgage", principal=700_000_000,
            annual_rate=0.06, term_years=30, annual_payment=50_000_000, age=22,
        )
        auto_id = await life_engine.economy.repository.create_loan(
            tx, char_id=character.char_id, loan_type="auto", principal=500_000_000,
            annual_rate=0.08, term_years=7, annual_payment=100_000_000, age=22,
        )
        for loan_id, balance in ((mortgage_id, 700_000_000), (auto_id, 500_000_000)):
            await life_engine.economy.repository.add_collection(
                tx, char_id=character.char_id, source="loan_deficiency", balance=balance,
                age=29, now=1_800_000_000, loan_id=loan_id,
            )

    assessment = await life_engine.economy.bankruptcy_eligibility(user_id)
    assert assessment.eligible is False
    assert assessment.reason_code == "no_dischargeable_debt"
    assert assessment.dischargeable_debt_cents == 0
    with pytest.raises(ValidationError, match="dischargeable"):
        await life_engine.economy.file_bankruptcy(user_id)
    async with database.transaction() as tx:
        rows = {row["loan_id"]: row for row in await life_engine.economy.repository.loan_rows(tx, character.char_id)}
        collections = await life_engine.economy.repository.collection_rows(tx, character.char_id)
    assert rows[mortgage_id]["status"] == "active"
    assert rows[auto_id]["status"] == "active"
    assert len(collections) == 2
    assert all(row["status"] == "open" for row in collections)


@pytest.mark.asyncio
async def test_bankruptcy_assessment_excludes_student_debt_and_waits_for_first_loan_age(database, life_engine) -> None:
    student_user_id = 880_009
    await life_engine.create_character(student_user_id, "Student Debt Test")
    student_character = await set_character(
        life_engine, student_user_id, age=30, cash=0, bank=0, debt_total=150_000
    )
    async with database.transaction() as tx:
        await life_engine.economy.repository.create_loan(
            tx, char_id=student_character.char_id, loan_type="student", principal=150_000,
            annual_rate=0.05, term_years=10, annual_payment=6_475, age=22,
        )
    student_assessment = await life_engine.economy.bankruptcy_eligibility(student_user_id)
    assert student_assessment.eligible is False
    assert student_assessment.reason_code == "no_dischargeable_debt"
    assert student_assessment.dischargeable_debt_cents == 0
    with pytest.raises(ValidationError, match="dischargeable"):
        await life_engine.economy.file_bankruptcy(student_user_id)

    recent_user_id = 880_010
    await life_engine.create_character(recent_user_id, "Recent Loan Test")
    recent_character = await set_character(
        life_engine, recent_user_id, age=30, cash=0, bank=0, debt_total=200_000_000
    )
    async with database.transaction() as tx:
        await life_engine.economy.repository.create_loan(
            tx, char_id=recent_character.char_id, loan_type="personal", principal=200_000_000,
            annual_rate=0.12, term_years=5, annual_payment=55_482_000, age=29,
        )
    recent_assessment = await life_engine.economy.bankruptcy_eligibility(recent_user_id)
    assert recent_assessment.eligible is False
    assert recent_assessment.reason_code == "first_loan_too_young"
    with pytest.raises(ValidationError, match="first loan"):
        await life_engine.economy.file_bankruptcy(recent_user_id)


@pytest.mark.asyncio
async def test_bankruptcy_requires_dischargeable_debt_above_twice_gross_assets(database, life_engine) -> None:
    user_id = 880_011
    await life_engine.create_character(user_id, "Asset Ratio Test")
    character = await set_character(
        life_engine, user_id, age=30, cash=100_000_000, bank=0, debt_total=200_000_000
    )
    async with database.transaction() as tx:
        await life_engine.economy.repository.create_loan(
            tx, char_id=character.char_id, loan_type="personal", principal=200_000_000,
            annual_rate=0.12, term_years=5, annual_payment=55_482_000, age=28,
        )
    assessment = await life_engine.economy.bankruptcy_eligibility(user_id)
    assert assessment.eligible is False
    assert assessment.reason_code == "debt_not_over_asset_multiple"
    assert assessment.dischargeable_debt_cents == 200_000_000
    assert assessment.gross_assets_cents == 100_000_000


@pytest.mark.asyncio
async def test_bankruptcy_has_a_material_dischargeable_debt_minimum(database, life_engine) -> None:
    minimum_cents = GameBalance.BANKRUPTCY_MIN_DISCHARGEABLE_DEBT_CENTS
    below_cents = minimum_cents - 1
    below_user_id = 880_012
    await life_engine.create_character(below_user_id, "Small Balance Test")
    below_character = await set_character(
        life_engine, below_user_id, age=30, cash=0, bank=0, debt_total=below_cents
    )
    async with database.transaction() as tx:
        await life_engine.economy.repository.create_loan(
            tx, char_id=below_character.char_id, loan_type="personal", principal=below_cents,
            annual_rate=0.12, term_years=5,
            annual_payment=amortized_annual_payment(below_cents, 0.12, 5), age=28,
        )
    below = await life_engine.economy.bankruptcy_eligibility(below_user_id)
    assert below.eligible is False
    assert below.reason_code == "dischargeable_debt_below_minimum"

    threshold_user_id = 880_013
    await life_engine.create_character(threshold_user_id, "Threshold Balance Test")
    threshold_character = await set_character(
        life_engine, threshold_user_id, age=30, cash=0, bank=0, debt_total=minimum_cents
    )
    async with database.transaction() as tx:
        await life_engine.economy.repository.create_loan(
            tx, char_id=threshold_character.char_id, loan_type="personal", principal=minimum_cents,
            annual_rate=0.12, term_years=5,
            annual_payment=amortized_annual_payment(minimum_cents, 0.12, 5), age=28,
        )
    at_threshold = await life_engine.economy.bankruptcy_eligibility(threshold_user_id)
    assert at_threshold.dischargeable_debt_cents == minimum_cents
    assert at_threshold.eligible is True


@pytest.mark.asyncio
async def test_bankruptcy_ten_year_after_tax_surplus_blocks_filing(database, life_engine, monkeypatch) -> None:
    minimum_cents = GameBalance.BANKRUPTCY_MIN_DISCHARGEABLE_DEBT_CENTS
    user_id = 880_015
    await life_engine.create_character(user_id, "Repayment Capacity Test")
    character = await set_character(
        life_engine, user_id, age=30, cash=0, bank=0, debt_total=minimum_cents
    )
    async with database.transaction() as tx:
        await life_engine.economy.repository.create_loan(
            tx, char_id=character.char_id, loan_type="personal", principal=minimum_cents,
            annual_rate=0.12, term_years=5,
            annual_payment=amortized_annual_payment(minimum_cents, 0.12, 5), age=28,
        )

    async def high_annual_income(_tx: aiosqlite.Connection, _char_id: int) -> int:
        return 100_000_000

    monkeypatch.setattr(life_engine.economy.repository, "annual_income", high_annual_income)
    assessment = await life_engine.economy.bankruptcy_eligibility(user_id)
    assert assessment.eligible is False
    assert assessment.reason_code == "income_can_repay"
    assert assessment.annual_surplus_cents > 0
    assert assessment.liquid_assets_cents == 0
    assert assessment.repayment_capacity_cents >= assessment.dischargeable_debt_cents
    with pytest.raises(ValidationError, match="years of after-tax surplus"):
        await life_engine.economy.file_bankruptcy(user_id)


@pytest.mark.asyncio
async def test_economy_annual_settlement_rolls_back_all_partial_writes(database, life_engine, monkeypatch) -> None:
    user_id = 880_008
    await life_engine.create_character(user_id, "Rollback Economy")
    character = await set_character(life_engine, user_id, age=20, cash=0, bank=0, debt_total=1_000)
    async with database.transaction() as tx:
        await life_engine.economy.repository.create_loan(
            tx, char_id=character.char_id, loan_type="personal", principal=1_000,
            annual_rate=0.10, term_years=5, annual_payment=300, age=18,
        )
    before = await database.fetchone("SELECT balance, interest_paid_cents FROM loans WHERE char_id = ?", (character.char_id,))
    original = life_engine.economy.repository.save_year_settlement

    async def fail_after_updates(*args: object, **kwargs: object) -> None:
        raise RuntimeError("injected annual-economy failure")

    monkeypatch.setattr(life_engine.economy.repository, "save_year_settlement", fail_after_updates)
    with pytest.raises(RuntimeError, match="injected"):
        async with database.transaction() as tx:
            await life_engine.economy.advance_year(tx, replace(character, age=21), previous_age=20, now=1_800_000_020)
    monkeypatch.setattr(life_engine.economy.repository, "save_year_settlement", original)
    after = await database.fetchone("SELECT balance, interest_paid_cents FROM loans WHERE char_id = ?", (character.char_id,))
    assert dict(after) == dict(before)
    assert await database.fetchone("SELECT 1 FROM economy_years WHERE char_id = ? AND age = 20", (character.char_id,)) is None
    assert await database.fetchone("SELECT 1 FROM economy_collections WHERE char_id = ?", (character.char_id,)) is None
