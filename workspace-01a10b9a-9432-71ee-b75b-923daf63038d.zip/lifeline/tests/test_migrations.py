"""Migration repeatability and Stage 10 schema/rollback checks."""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import aiosqlite
import pytest

from core.db import DatabaseManager


@pytest.mark.asyncio
async def test_initialize_is_idempotent(database):
    await database.initialize()
    await database.close()
    await database.initialize()
    versions = await database.fetchall("SELECT version FROM schema_version ORDER BY version")
    assert [row["version"] for row in versions] == list(range(1, 14))
    tables = {row["name"] for row in await database.fetchall(
        "SELECT name FROM sqlite_master WHERE type = 'table'"
    )}
    assert {
        "characters", "life_logs", "schema_version", "education_actions", "jobs",
        "career_history", "career_actions", "npcs", "relationships", "children",
        "yearly_counters", "dating_sessions", "dating_candidates", "marriages",
        "pregnancies", "adoptions", "family_assets", "alimony", "affairs",
        "divorce_records", "stats_tracking", "infidelity_prompts", "infidelity_choices",
        "players", "shop_quotes", "trades", "trade_items", "trade_daily_usage",
        "inventory_uses", "audit_log", "health_conditions", "casino_player_state",
        "casino_yearly_bets", "casino_plays", "casino_sessions", "casino_compulsions",
        "casino_yearly_tax", "market_state", "stock_market", "stock_history",
        "stock_holdings", "investment_trades", "savings_bonds", "investment_yearly_income",
        "achievements_unlocked", "life_year_metrics", "marriage_history", "past_lives",
        "life_estates", "retirement_prompts", "legacy_start_purchases", "guild_player_seen",
        "guild_stage10_settings", "player_bans", "player_settings", "economy_years",
        "economy_collections", "economy_activity_uses", "bankruptcies", "health_visits",
    }.issubset(tables)
    family_asset_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(family_assets)")}
    loan_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(loans)")}
    shop_quote_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(shop_quotes)")}
    assert "is_locked" in family_asset_columns
    assert {"principal", "annual_rate", "term_years", "years_remaining", "collateral_item_uid",
            "origination_age", "consecutive_misses", "grace_until_age", "defaulted_at_age"}.issubset(loan_columns)
    character_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(characters)")}
    assert {"cash_cents", "bank_cents"}.issubset(character_columns)
    health_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(health_conditions)")}
    assert {"duration_years", "last_treated_age", "last_progressed_age", "progression_count"}.issubset(health_columns)
    assert {"nonce", "total_price", "balance_cents", "character_version", "expires_at"}.issubset(shop_quote_columns)
    stats_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(stats_tracking)")}
    assert {"total_gambled", "total_gambling_net", "gambling_addiction_fraction"}.issubset(stats_columns)
    player_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(players)")}
    assert {"lives_lived", "legacy_points", "leaderboard_opt_out"}.issubset(player_columns)
    achievement_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(achievements_unlocked)")}
    assert {"user_id", "achievement_id", "char_id", "unlocked_at"}.issubset(achievement_columns)
    archive_triggers = {
        row["name"] for row in await database.fetchall(
            "SELECT name FROM sqlite_master WHERE type = 'trigger' AND tbl_name = 'past_lives'"
        )
    }
    assert {"trg_past_lives_immutable_update", "trg_past_lives_immutable_delete"}.issubset(archive_triggers)
    audit_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(audit_log)")}
    assert {"admin_id", "target_user_id"}.issubset(audit_columns)
    settings_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(player_settings)")}
    assert {
        "user_id", "public_year_summaries", "public_deaths",
        "public_casino_results", "public_leaderboards", "updated_at",
    }.issubset(settings_columns)


@pytest.mark.asyncio
async def test_stage12_migration_unwraps_legacy_archive_json_and_restores_immutability(tmp_path):
    """Migration 011 unwraps old summaries before 012 adds economic schema."""
    db_path = tmp_path / "migration-011-archive-repair.sqlite3"
    old_summary = {"char_id": 41, "name": "Legacy Archive", "death_age": 73}
    old_envelope = json.dumps({"char_id": 41, "user_id": 42, "summary_json": old_summary})
    async with aiosqlite.connect(db_path) as db:
        await db.execute(
            "CREATE TABLE schema_version(version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)"
        )
        await db.execute("INSERT INTO schema_version(version, applied_at) VALUES (10, 0)")
        await db.execute(
            "CREATE TABLE past_lives(char_id INTEGER PRIMARY KEY, summary_json TEXT NOT NULL)"
        )
        await db.execute(
            """CREATE TRIGGER trg_past_lives_immutable_update BEFORE UPDATE ON past_lives
               BEGIN SELECT RAISE(ABORT, 'past_lives rows are immutable'); END"""
        )
        await db.execute(
            "INSERT INTO past_lives(char_id, summary_json) VALUES (?, ?)",
            (41, old_envelope),
        )
        # Minimal parent/leaf tables let the following 012 economy migration run too.
        await db.execute(
            "CREATE TABLE characters(char_id INTEGER PRIMARY KEY, data_json TEXT NOT NULL)"
        )
        await db.execute(
            "INSERT INTO characters(char_id, data_json) VALUES (1, '{\"cash\": 0, \"bank\": 0}')"
        )
        await db.execute("CREATE TABLE family_assets(asset_id INTEGER PRIMARY KEY)")
        await db.execute("CREATE TABLE health_conditions(condition_id INTEGER PRIMARY KEY)")
        await db.execute(
            """CREATE TABLE loans(
                   loan_id INTEGER PRIMARY KEY AUTOINCREMENT, char_id INTEGER NOT NULL,
                   loan_type TEXT NOT NULL, balance INTEGER NOT NULL, annual_payment INTEGER NOT NULL,
                   missed_payments INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL,
                   principal INTEGER NOT NULL DEFAULT 0, annual_rate REAL NOT NULL DEFAULT 0,
                   term_years INTEGER NOT NULL DEFAULT 0, years_remaining INTEGER NOT NULL DEFAULT 0,
                   collateral_item_uid INTEGER
               )"""
        )
        await db.commit()

    database = DatabaseManager(str(db_path))
    await database.initialize()
    row = await database.fetchone("SELECT summary_json FROM past_lives WHERE char_id = ?", (41,))
    assert json.loads(row["summary_json"]) == old_summary
    versions = await database.fetchall("SELECT version FROM schema_version ORDER BY version")
    assert [int(item["version"]) for item in versions] == [10, 11, 12, 13]
    await database.close()

    with sqlite3.connect(db_path) as connection:
        with pytest.raises(sqlite3.IntegrityError, match="immutable"):
            connection.execute(
                "UPDATE past_lives SET summary_json = '{}' WHERE char_id = 41"
            )


@pytest.mark.asyncio
async def test_migration_012_backfills_checked_balances_and_preserves_loans(tmp_path):
    """An upgrade from schema 011 preserves secured loan metadata and mirrors JSON cents."""
    db_path = tmp_path / "migration-012-loans.sqlite3"
    async with aiosqlite.connect(db_path) as db:
        await db.execute("CREATE TABLE schema_version(version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)")
        await db.execute("INSERT INTO schema_version(version, applied_at) VALUES (11, 0)")
        await db.execute("CREATE TABLE characters(char_id INTEGER PRIMARY KEY, data_json TEXT NOT NULL)")
        await db.execute(
            "INSERT INTO characters(char_id, data_json) VALUES (1, '{\"cash\": 12345, \"bank\": 67890}')"
        )
        await db.execute("CREATE TABLE family_assets(asset_id INTEGER PRIMARY KEY)")
        await db.execute("CREATE TABLE health_conditions(condition_id INTEGER PRIMARY KEY)")
        await db.execute("INSERT INTO family_assets(asset_id) VALUES (7)")
        await db.execute(
            """CREATE TABLE loans(
                   loan_id INTEGER PRIMARY KEY AUTOINCREMENT, char_id INTEGER NOT NULL,
                   loan_type TEXT NOT NULL, balance INTEGER NOT NULL, annual_payment INTEGER NOT NULL,
                   missed_payments INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL,
                   principal INTEGER NOT NULL DEFAULT 0, annual_rate REAL NOT NULL DEFAULT 0,
                   term_years INTEGER NOT NULL DEFAULT 0, years_remaining INTEGER NOT NULL DEFAULT 0,
                   collateral_item_uid INTEGER
               )"""
        )
        await db.execute(
            """INSERT INTO loans
                   (loan_id, char_id, loan_type, balance, annual_payment, missed_payments, status,
                    principal, annual_rate, term_years, years_remaining, collateral_item_uid)
               VALUES (9, 1, 'auto', 70000, 16000, 1, 'active', 90000, 0.08, 5, 4, 7)"""
        )
        await db.commit()

    database = DatabaseManager(str(db_path))
    await database.initialize()
    character = await database.fetchone("SELECT cash_cents, bank_cents FROM characters WHERE char_id = 1")
    loan = await database.fetchone("SELECT * FROM loans WHERE loan_id = 9")
    assert (character["cash_cents"], character["bank_cents"]) == (12_345, 67_890)
    assert (loan["balance"], loan["principal"], loan["annual_rate"], loan["years_remaining"]) == (70_000, 90_000, 0.08, 4)
    assert loan["status"] == "active" and loan["collateral_item_uid"] == 7
    assert await database.fetchall("PRAGMA foreign_key_check") == []
    await database.close()


@pytest.mark.asyncio
async def test_migration_013_preserves_existing_health_conditions(tmp_path):
    """Migration 013 extends an existing health record without losing diagnosis state."""
    db_path = tmp_path / "migration-013-health.sqlite3"
    async with aiosqlite.connect(db_path) as db:
        await db.execute("CREATE TABLE schema_version(version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)")
        await db.execute("INSERT INTO schema_version(version, applied_at) VALUES (12, 0)")
        await db.execute("CREATE TABLE characters(char_id INTEGER PRIMARY KEY)")
        await db.execute("INSERT INTO characters(char_id) VALUES (4)")
        await db.execute(
            """CREATE TABLE health_conditions(
                   condition_id INTEGER PRIMARY KEY, char_id INTEGER NOT NULL, disease_id TEXT NOT NULL,
                   severity INTEGER NOT NULL DEFAULT 1, diagnosed INTEGER NOT NULL DEFAULT 1,
                   onset_age INTEGER NOT NULL, years_untreated INTEGER NOT NULL DEFAULT 0,
                   status TEXT NOT NULL DEFAULT 'active', is_active INTEGER NOT NULL DEFAULT 1,
                   created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
                   UNIQUE(char_id, disease_id)
               )"""
        )
        await db.execute(
            """INSERT INTO health_conditions
                   (condition_id, char_id, disease_id, severity, diagnosed, onset_age,
                    years_untreated, status, is_active, created_at, updated_at)
               VALUES (12, 4, 'asthma', 3, 1, 20, 2, 'chronic', 1, 10, 11)"""
        )
        await db.commit()
    database = DatabaseManager(str(db_path))
    await database.initialize()
    row = await database.fetchone("SELECT * FROM health_conditions WHERE condition_id = 12")
    assert (row["char_id"], row["disease_id"], row["severity"], row["diagnosed"], row["status"]) == (
        4, "asthma", 3, 1, "chronic"
    )
    assert row["duration_years"] == 1 and row["progression_count"] == 0
    assert await database.fetchall("PRAGMA foreign_key_check") == []
    await database.close()


@pytest.mark.asyncio
async def test_stage11_migration_rolls_back_all_schema_changes_on_failure(tmp_path):
    """A failure after migration 010 statements leaves no partial admin/privacy schema."""
    db_path = tmp_path / "migration-010-rollback.sqlite3"
    async with aiosqlite.connect(db_path) as db:
        await db.execute("PRAGMA foreign_keys = ON")
        await db.execute("CREATE TABLE schema_version(version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)")
        await db.execute("INSERT INTO schema_version(version, applied_at) VALUES (9, 0)")
        await db.execute("CREATE TABLE players(user_id INTEGER PRIMARY KEY, created_at INTEGER NOT NULL)")
        await db.execute(
            """CREATE TABLE audit_log(
                   audit_id INTEGER PRIMARY KEY, ts INTEGER NOT NULL, user_id INTEGER,
                   char_id INTEGER, action TEXT NOT NULL, amount INTEGER, details_json TEXT NOT NULL
               )"""
        )
        await db.commit()

    migration = Path(__file__).resolve().parents[1] / "core" / "migrations" / "010_stage11_admin_settings.sql"
    sql = migration.read_text(encoding="utf-8")
    script = (
        "BEGIN IMMEDIATE;\n"
        + sql
        + "\nINSERT INTO schema_version(version, applied_at) VALUES (10, 1);"
        + "\nINSERT INTO deliberately_missing_table(value) VALUES (1);\nCOMMIT;"
    )
    async with aiosqlite.connect(db_path) as db:
        await db.execute("PRAGMA foreign_keys = ON")
        with pytest.raises(sqlite3.OperationalError, match="no such table"):
            await db.executescript(script)
        await db.rollback()

    async with aiosqlite.connect(db_path) as db:
        audit_columns = {row[1] for row in await (await db.execute("PRAGMA table_info(audit_log)")).fetchall()}
        tables = {row[0] for row in await (await db.execute("SELECT name FROM sqlite_master WHERE type = 'table'")).fetchall()}
        version = await (await db.execute("SELECT MAX(version) FROM schema_version")).fetchone()
    assert audit_columns == {"audit_id", "ts", "user_id", "char_id", "action", "amount", "details_json"}
    assert not {"player_bans", "player_settings"}.intersection(tables)
    assert int(version[0]) == 9


@pytest.mark.asyncio
async def test_stage10_migration_rolls_back_all_schema_changes_on_failure(tmp_path):
    """A failure after migration 009 statements leaves no partial columns or tables."""
    db_path = tmp_path / "migration-009-rollback.sqlite3"
    async with aiosqlite.connect(db_path) as db:
        await db.execute("PRAGMA foreign_keys = ON")
        await db.execute("CREATE TABLE schema_version(version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)")
        await db.execute("INSERT INTO schema_version(version, applied_at) VALUES (8, 0)")
        await db.execute("CREATE TABLE players(user_id INTEGER PRIMARY KEY, created_at INTEGER NOT NULL)")
        await db.execute("CREATE TABLE characters(char_id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, born_at INTEGER NOT NULL)")
        await db.commit()

    migration = Path(__file__).resolve().parents[1] / "core" / "migrations" / "009_achievements_legacy.sql"
    sql = migration.read_text(encoding="utf-8")
    script = (
        "BEGIN IMMEDIATE;\n"
        + sql
        + "\nINSERT INTO schema_version(version, applied_at) VALUES (9, 1);"
        + "\nINSERT INTO deliberately_missing_table(value) VALUES (1);\nCOMMIT;"
    )
    async with aiosqlite.connect(db_path) as db:
        await db.execute("PRAGMA foreign_keys = ON")
        with pytest.raises(sqlite3.OperationalError, match="no such table"):
            await db.executescript(script)
        await db.rollback()

    async with aiosqlite.connect(db_path) as db:
        columns = await (await db.execute("PRAGMA table_info(players)")).fetchall()
        tables = await (await db.execute("SELECT name FROM sqlite_master WHERE type = 'table'")).fetchall()
        version = await (await db.execute("SELECT MAX(version) FROM schema_version")).fetchone()
    assert {row[1] for row in columns} == {"user_id", "created_at"}
    assert "achievements_unlocked" not in {row[0] for row in tables}
    assert int(version[0]) == 8
