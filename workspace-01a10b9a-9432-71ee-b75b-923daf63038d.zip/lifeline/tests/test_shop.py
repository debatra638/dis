"""Stage 8 shop, inventory, financing, depreciation, and trade invariants."""
from __future__ import annotations

import asyncio
import json
from dataclasses import replace

import pytest
import pytest_asyncio

from core.errors import CharacterInPrison, InsufficientFunds, StaleShopQuote, ValidationError
from core.life_engine import LifeEngine
from core.locks import UserLockRegistry
from core.models import Character, Stats
from core.rng import RNG
from core.shop import ShopService
from core.validators import DataValidationError, validate_item_catalog


class MutableClock:
    """Simple injectable clock for reproducible trade expiry and account-age tests."""

    def __init__(self, value: int = 1_900_000_000) -> None:
        self.value = value

    def __call__(self) -> float:
        return float(self.value)


@pytest_asyncio.fixture
async def shop_context(database, life_engine):
    """Create a Stage 8 service with deterministic randomness and a mutable clock."""
    clock = MutableClock()
    service = ShopService(database, RNG(seed=808), UserLockRegistry(), clock=clock)
    return database, life_engine, service, clock


async def create_adult(life_engine: LifeEngine, service: ShopService, user_id: int, *, cash: int = 100_000_000, age: int = 25) -> Character:
    """Create an active adult character with enough test funds and a known age."""
    character = await life_engine.create_character(user_id, f"Player {user_id}")
    return await update_character(service, user_id, age=age, cash=cash, bank=0, in_prison=False)


async def update_character(service: ShopService, user_id: int, **changes: object) -> Character:
    """Apply test-only character fixture values through the versioned repository save."""
    async with service.db.transaction() as tx:
        character, version = await service._active_character(tx, user_id)
        updated = replace(character, **changes, version=version + 1)
        await service.repository.save_character(tx, updated, version)
        return updated


async def register_old_account(service: ShopService, user_id: int, clock: MutableClock) -> None:
    """Register a Discord account older than the seven-day imbalance threshold."""
    await service.register_player(user_id, clock.value - 8 * 24 * 60 * 60)


async def buy(service: ShopService, user_id: int, item_id: str, quantity: int = 1, method: str = "cash"):
    """Quote and confirm one item purchase using the quote's exact nonce/version."""
    quote = await service.quote_purchase(user_id, item_id, quantity)
    return await service.purchase(
        user_id,
        item_id,
        quantity,
        expected_version=quote.version,
        expected_total=quote.total_price,
        nonce=quote.nonce,
        payment_method=method,
        expected_down_payment=quote.down_payment if method == "finance" else None,
    )


async def item_uid(service: ShopService, user_id: int, item_id: str) -> int:
    """Return one matching inventory asset ID."""
    _, rows = await service.inventory(user_id)
    return next(int(row["asset_id"]) for row in rows if row["item_id"] == item_id)


@pytest.mark.asyncio
async def test_atomic_trade_transfers_items_and_audits(database, life_engine, shop_context):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1001)
    await create_adult(life_engine, service, 1002)
    await register_old_account(service, 1001, clock)
    await register_old_account(service, 1002, clock)
    await buy(service, 1001, "phone")
    await buy(service, 1002, "guitar")
    phone_uid = await item_uid(service, 1001, "phone")
    guitar_uid = await item_uid(service, 1002, "guitar")

    offer = await service.create_trade(
        1001, 1002,
        offered_items={phone_uid: 1},
        requested_items={guitar_uid: 1},
    )
    _, locked = await service.inventory(1001)
    assert next(row for row in locked if row["asset_id"] == phone_uid)["is_locked"]

    result = await service.accept_trade(offer.trade_id, 1002, offer.nonce)

    assert result.success
    assert result.status == "accepted"
    _, left = await service.inventory(1001)
    _, right = await service.inventory(1002)
    assert any(row["item_id"] == "guitar" for row in left)
    assert any(row["item_id"] == "phone" for row in right)
    trade = await database.fetchone("SELECT status FROM trades WHERE trade_id = ?", (offer.trade_id,))
    assert trade["status"] == "accepted"
    audit = await database.fetchone("SELECT action FROM audit_log WHERE action = 'trade_accepted' AND char_id = (SELECT char_id FROM characters WHERE user_id = 1002 AND is_alive = 1)")
    assert audit is not None


@pytest.mark.asyncio
async def test_requested_item_sold_mid_trade_fails_and_unlocks_offer(shop_context, life_engine):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1011)
    await create_adult(life_engine, service, 1012)
    await register_old_account(service, 1011, clock)
    await register_old_account(service, 1012, clock)
    await buy(service, 1011, "phone")
    await buy(service, 1012, "guitar")
    phone_uid = await item_uid(service, 1011, "phone")
    guitar_uid = await item_uid(service, 1012, "guitar")
    offer = await service.create_trade(
        1011, 1012,
        offered_items={phone_uid: 1},
        requested_items={guitar_uid: 1},
    )
    await service.sell(1012, "guitar", 1)

    result = await service.accept_trade(offer.trade_id, 1012, offer.nonce)

    assert not result.success
    assert result.status == "failed"
    _, rows = await service.inventory(1011)
    phone = next(row for row in rows if row["asset_id"] == phone_uid)
    assert not phone["is_locked"]


@pytest.mark.asyncio
async def test_locked_items_cannot_be_sold_or_used(shop_context, life_engine):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1021)
    await create_adult(life_engine, service, 1022)
    await register_old_account(service, 1021, clock)
    await register_old_account(service, 1022, clock)
    await buy(service, 1021, "energy_drink", 2)
    energy_uid = await item_uid(service, 1021, "energy_drink")
    offer = await service.create_trade(1021, 1022, offered_items={energy_uid: 1}, requested_items={})

    with pytest.raises(ValidationError, match="locked"):
        await service.sell(1021, "energy_drink", 1)
    with pytest.raises(ValidationError, match="locked"):
        await service.use(1021, "energy_drink")
    await service.cancel_trade(offer.trade_id, 1021, offer.nonce)


@pytest.mark.asyncio
async def test_self_trade_and_same_owner_are_blocked(shop_context, life_engine):
    _, _, service, _ = shop_context
    await create_adult(life_engine, service, 1031)
    with pytest.raises(ValidationError, match="yourself"):
        await service.create_trade(1031, 1031, offered_items={}, requested_items={}, offer_cash=1)


@pytest.mark.asyncio
async def test_pending_outgoing_rule_and_daily_limit_of_five(shop_context, life_engine):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1041, cash=1_000)
    await register_old_account(service, 1041, clock)
    for user_id in range(1042, 1049):
        await create_adult(life_engine, service, user_id, cash=1_000)
        await register_old_account(service, user_id, clock)
    first = await service.create_trade(1041, 1042, offered_items={}, requested_items={}, request_cash=1)
    with pytest.raises(ValidationError, match="pending outgoing"):
        await service.create_trade(1041, 1043, offered_items={}, requested_items={}, request_cash=1)
    await service.cancel_trade(first.trade_id, 1041, first.nonce)

    for target_id in range(1042, 1046):
        receipt = await service.create_trade(1041, target_id, offered_items={}, requested_items={}, request_cash=1)
        await service.cancel_trade(receipt.trade_id, 1041, receipt.nonce)
    with pytest.raises(ValidationError, match="five trades"):
        await service.create_trade(1041, 1046, offered_items={}, requested_items={}, request_cash=1)


@pytest.mark.asyncio
async def test_collateralized_items_are_not_tradeable_or_sellable(shop_context, life_engine):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1051, cash=2_000_000)
    await create_adult(life_engine, service, 1052)
    await register_old_account(service, 1051, clock)
    await register_old_account(service, 1052, clock)
    receipt = await buy(service, 1051, "trailer", method="finance")
    _, rows = await service.inventory(1051)
    trailer = next(row for row in rows if row["asset_id"] == receipt.asset_id)
    assert trailer["collateralized"]
    with pytest.raises(ValidationError, match="collateral loan"):
        await service.sell(1051, "trailer", 1)
    with pytest.raises(ValidationError, match="collateral loan"):
        await service.create_trade(1051, 1052, offered_items={receipt.asset_id: 1}, requested_items={})


@pytest.mark.asyncio
async def test_concurrent_accept_and_cancel_resolves_exactly_once(shop_context, life_engine):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1061, cash=10_000)
    await create_adult(life_engine, service, 1062, cash=10_000)
    await register_old_account(service, 1061, clock)
    await register_old_account(service, 1062, clock)
    offer = await service.create_trade(1061, 1062, offered_items={}, requested_items={}, offer_cash=100)

    accepted, cancelled = await asyncio.gather(
        service.accept_trade(offer.trade_id, 1062, offer.nonce),
        service.cancel_trade(offer.trade_id, 1061, offer.nonce),
    )
    terminal = [result for result in (accepted, cancelled) if result.success]
    assert len(terminal) == 1
    trade = await service.repository.trade_users_read(offer.trade_id)
    assert trade is not None
    row = await service.db.fetchone("SELECT status FROM trades WHERE trade_id = ?", (offer.trade_id,))
    assert row["status"] in {"accepted", "cancelled"}


@pytest.mark.asyncio
async def test_trade_tax_is_a_sunk_charge_rounded_up(shop_context, life_engine):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1071, cash=10)
    await create_adult(life_engine, service, 1072, cash=10)
    await register_old_account(service, 1071, clock)
    await register_old_account(service, 1072, clock)
    offer = await service.create_trade(1071, 1072, offered_items={}, requested_items={}, offer_cash=1)

    result = await service.accept_trade(offer.trade_id, 1072, offer.nonce)

    assert result.success
    left = await life_engine.get_active_character(1071)
    right = await life_engine.get_active_character(1072)
    assert left.cash == 8
    assert right.cash == 11
    fees = await service.db.fetchone("SELECT details_json FROM audit_log WHERE action = 'trade_accepted' AND char_id = ?", (right.char_id,))
    details = json.loads(fees["details_json"])
    assert details["offer_tax"] == 1
    assert details["request_tax"] == 0


@pytest.mark.asyncio
async def test_value_imbalance_requires_old_high_value_recipient_account(shop_context, life_engine):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1081)
    await create_adult(life_engine, service, 1082)
    await service.register_player(1081, clock.value - 3600)
    await register_old_account(service, 1082, clock)
    async with service.db.transaction() as tx:
        target, _ = await service._active_character(tx, 1082)
        rare_uid = await service.repository.insert_item(
            tx, char_id=target.char_id, item_id="original_art", quantity=1,
            purchase_price=10_000_001, current_value=10_000_001,
            age=target.age, now=clock.value,
        )

    with pytest.raises(ValidationError, match="seven days"):
        await service.create_trade(1081, 1082, offered_items={}, requested_items={rare_uid: 1})

    await create_adult(life_engine, service, 1083)
    await create_adult(life_engine, service, 1084)
    await register_old_account(service, 1083, clock)
    await register_old_account(service, 1084, clock)
    async with service.db.transaction() as tx:
        target, _ = await service._active_character(tx, 1084)
        uid = await service.repository.insert_item(
            tx, char_id=target.char_id, item_id="original_art", quantity=1,
            purchase_price=10_000_001, current_value=10_000_001,
            age=target.age, now=clock.value,
        )
    accepted_offer = await service.create_trade(1083, 1084, offered_items={}, requested_items={uid: 1})
    assert accepted_offer.imbalance_flag
    flag = await service.db.fetchone("SELECT 1 FROM audit_log WHERE action = 'trade_value_imbalance_flag' AND user_id = ?", (1083,))
    assert flag is not None


@pytest.mark.asyncio
async def test_overspending_is_blocked_and_balances_stay_nonnegative(shop_context, life_engine):
    _, _, service, _ = shop_context
    await create_adult(life_engine, service, 1091, cash=500)
    quote = await service.quote_purchase(1091, "phone")
    assert not quote.can_pay_cash
    with pytest.raises(InsufficientFunds):
        await service.purchase(
            1091, "phone", 1, expected_version=quote.version, expected_total=quote.total_price,
            nonce=quote.nonce,
        )
    character = await life_engine.get_active_character(1091)
    assert character.cash == 500
    assert character.bank == 0


@pytest.mark.asyncio
async def test_buy_then_sell_uses_current_value_and_always_loses(shop_context, life_engine):
    _, _, service, _ = shop_context
    await create_adult(life_engine, service, 1101, cash=10_000_000)
    purchase = await buy(service, 1101, "phone")
    sale = await service.sell(1101, "phone", 1)
    assert sale.payout == purchase.total_price * 85 // 100
    assert sale.payout < purchase.total_price


@pytest.mark.asyncio
async def test_depreciation_and_market_appreciation_by_category(shop_context, life_engine, monkeypatch):
    database, _, service, clock = shop_context
    await create_adult(life_engine, service, 1111, cash=10_000_000_000)
    purchases = {}
    for item_id in ("used_car", "phone", "starter_home", "original_art"):
        purchases[item_id] = await buy(service, 1111, item_id)
    monkeypatch.setattr(service.rng, "gauss", lambda mean, deviation: mean)
    async with database.transaction() as tx:
        character, _ = await service._active_character(tx, 1111)
        await service.advance_year(tx, character, now=clock.value + 1)
    _, rows = await service.inventory(1111)
    values = {row["item_id"]: int(row["current_value"]) for row in rows}
    assert values["used_car"] == purchases["used_car"].total_price * 85 // 100
    assert values["phone"] == purchases["phone"].total_price * 75 // 100
    assert values["starter_home"] == purchases["starter_home"].total_price * 1035 // 1000
    assert values["original_art"] == purchases["original_art"].total_price * 105 // 100


@pytest.mark.asyncio
async def test_expired_trade_unlocks_offered_items(shop_context, life_engine):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1121)
    await create_adult(life_engine, service, 1122)
    await register_old_account(service, 1121, clock)
    await register_old_account(service, 1122, clock)
    await buy(service, 1121, "energy_drink", 1)
    asset_id = await item_uid(service, 1121, "energy_drink")
    offer = await service.create_trade(1121, 1122, offered_items={asset_id: 1}, requested_items={})
    clock.value += 601

    count = await service.expire_pending()

    assert count == 1
    row = await service.db.fetchone("SELECT status FROM trades WHERE trade_id = ?", (offer.trade_id,))
    assert row["status"] == "expired"
    _, items = await service.inventory(1121)
    assert not next(row for row in items if row["asset_id"] == asset_id)["is_locked"]


@pytest.mark.asyncio
async def test_exception_mid_trade_rolls_back_both_characters_and_assets(shop_context, life_engine, monkeypatch):
    database, _, service, clock = shop_context
    await create_adult(life_engine, service, 1131, cash=1_000_000)
    await create_adult(life_engine, service, 1132, cash=1_000_000)
    await register_old_account(service, 1131, clock)
    await register_old_account(service, 1132, clock)
    await buy(service, 1131, "phone")
    await buy(service, 1132, "guitar")
    phone_uid = await item_uid(service, 1131, "phone")
    guitar_uid = await item_uid(service, 1132, "guitar")
    offer = await service.create_trade(
        1131, 1132,
        offered_items={phone_uid: 1},
        requested_items={guitar_uid: 1},
        offer_cash=100,
    )
    sender_before = await life_engine.get_active_character(1131)
    receiver_before = await life_engine.get_active_character(1132)
    original_transfer = service.repository.transfer_item
    calls = 0

    async def raise_after_first_transfer(tx, **kwargs):
        nonlocal calls
        result = await original_transfer(tx, **kwargs)
        calls += 1
        if calls == 1:
            raise RuntimeError("injected mid-trade failure")
        return result

    monkeypatch.setattr(service.repository, "transfer_item", raise_after_first_transfer)
    with pytest.raises(RuntimeError, match="injected"):
        await service.accept_trade(offer.trade_id, 1132, offer.nonce)
    monkeypatch.setattr(service.repository, "transfer_item", original_transfer)

    sender_after = await life_engine.get_active_character(1131)
    receiver_after = await life_engine.get_active_character(1132)
    assert (sender_after.cash, sender_after.bank, sender_after.version) == (sender_before.cash, sender_before.bank, sender_before.version)
    assert (receiver_after.cash, receiver_after.bank, receiver_after.version) == (receiver_before.cash, receiver_before.bank, receiver_before.version)
    trade = await database.fetchone("SELECT status FROM trades WHERE trade_id = ?", (offer.trade_id,))
    assert trade["status"] == "pending"
    _, sender_items = await service.inventory(1131)
    _, receiver_items = await service.inventory(1132)
    assert next(row for row in sender_items if row["asset_id"] == phone_uid)["is_locked"]
    assert any(row["asset_id"] == guitar_uid for row in receiver_items)


@pytest.mark.asyncio
async def test_conditional_transfer_failure_rolls_back_partial_assets_and_marks_failed(shop_context, life_engine, monkeypatch):
    _, _, service, clock = shop_context
    await create_adult(life_engine, service, 1211, cash=1_000_000)
    await create_adult(life_engine, service, 1212, cash=1_000_000)
    await register_old_account(service, 1211, clock)
    await register_old_account(service, 1212, clock)
    await buy(service, 1211, "phone")
    await buy(service, 1212, "guitar")
    phone_uid = await item_uid(service, 1211, "phone")
    guitar_uid = await item_uid(service, 1212, "guitar")
    offer = await service.create_trade(
        1211, 1212, offered_items={phone_uid: 1}, requested_items={guitar_uid: 1}
    )
    original_transfer = service.repository.transfer_item
    calls = 0

    async def fail_second_transfer(tx, **kwargs):
        nonlocal calls
        calls += 1
        if calls == 2:
            return None
        return await original_transfer(tx, **kwargs)

    monkeypatch.setattr(service.repository, "transfer_item", fail_second_transfer)
    result = await service.accept_trade(offer.trade_id, 1212, offer.nonce)

    assert not result.success
    assert result.status == "failed"
    _, left = await service.inventory(1211)
    _, right = await service.inventory(1212)
    assert not bool(next(row for row in left if row["asset_id"] == phone_uid)["is_locked"])
    assert any(row["asset_id"] == guitar_uid for row in right)
    assert not any(row["asset_id"] == phone_uid for row in right)
    assert not any(row["asset_id"] == guitar_uid for row in left)


@pytest.mark.asyncio
async def test_stale_shop_quote_nonce_or_version_is_rejected(shop_context, life_engine):
    _, _, service, _ = shop_context
    await create_adult(life_engine, service, 1141, cash=1_000_000)
    quote = await service.quote_purchase(1141, "phone")
    await update_character(service, 1141, cash=900_000)
    with pytest.raises(StaleShopQuote, match="changed"):
        await service.purchase(
            1141, "phone", 1, expected_version=quote.version, expected_total=quote.total_price,
            nonce=quote.nonce,
        )


@pytest.mark.asyncio
async def test_stale_balance_snapshot_is_rejected_even_if_version_was_not_advanced(shop_context, life_engine):
    database, _, service, _ = shop_context
    await create_adult(life_engine, service, 1221, cash=1_000_000)
    quote = await service.quote_purchase(1221, "phone")
    row = await database.fetchone(
        "SELECT char_id, data_json FROM characters WHERE user_id = ? AND is_alive = 1", (1221,)
    )
    character_data = json.loads(row["data_json"])
    character_data["cash"] -= 1
    await database.execute(
        "UPDATE characters SET data_json = ? WHERE char_id = ?",
        (json.dumps(character_data, separators=(",", ":")), row["char_id"]),
    )

    with pytest.raises(StaleShopQuote, match="balance changed"):
        await service.purchase(
            1221,
            "phone",
            1,
            expected_version=quote.version,
            expected_total=quote.total_price,
            nonce=quote.nonce,
        )


@pytest.mark.asyncio
async def test_catalog_has_seventy_valid_items_and_weapon_purchase_is_blocked(shop_context, life_engine):
    _, _, service, _ = shop_context
    assert len(service.items) >= 60
    await create_adult(life_engine, service, 1151)
    with pytest.raises(ValidationError, match="not sold"):
        await service.quote_purchase(1151, "prop_weapon")


def test_item_catalog_rejects_missing_required_item_fields():
    """Startup validation rejects malformed item definitions before bot service starts."""
    with pytest.raises(DataValidationError):
        validate_item_catalog({"schema_version": 1, "items": []})


@pytest.mark.asyncio
async def test_mortgage_uses_ten_percent_down_and_secures_the_house(shop_context, life_engine):
    _, _, service, _ = shop_context
    await create_adult(life_engine, service, 1161, cash=25_000_000)
    quote = await service.quote_purchase(1161, "starter_home")
    assert quote.total_price == 18_000_000
    assert quote.down_payment == 1_800_000
    receipt = await service.purchase(
        1161,
        "starter_home",
        1,
        expected_version=quote.version,
        expected_total=quote.total_price,
        nonce=quote.nonce,
        payment_method="finance",
        expected_down_payment=quote.down_payment,
    )
    assert receipt.paid_now == 1_800_000
    assert receipt.loan_principal == 16_200_000
    loan = await service.db.fetchone("SELECT loan_type, balance, collateral_item_uid FROM loans WHERE char_id = (SELECT char_id FROM characters WHERE user_id = ? AND is_alive = 1)", (1161,))
    assert loan["loan_type"] == "mortgage"
    assert loan["balance"] == 16_200_000
    assert loan["collateral_item_uid"] == receipt.asset_id


@pytest.mark.asyncio
async def test_consumable_use_clamps_stats_and_reduces_quantity(shop_context, life_engine):
    _, _, service, _ = shop_context
    await create_adult(life_engine, service, 1171, cash=100_000)
    character = await life_engine.get_active_character(1171)
    await update_character(service, 1171, stats=replace(character.stats, health=99, stress=99))
    await buy(service, 1171, "medication", 2)

    result = await service.use(1171, "medication")

    assert result.quantity_remaining == 1
    assert result.stats.health == 100
    assert result.stats.stress == 97
    _, rows = await service.inventory(1171)
    assert next(row for row in rows if row["item_id"] == "medication")["quantity"] == 1


@pytest.mark.asyncio
async def test_age_gates_and_crime_event_weapon_country_legality(shop_context, life_engine):
    _, _, service, _ = shop_context
    await create_adult(life_engine, service, 1181, age=17)
    with pytest.raises(ValidationError, match="at least 21"):
        await service.quote_purchase(1181, "nightclub")
    with pytest.raises(ValidationError, match="at least 18"):
        await service.award_crime_event_item(1181, "prop_weapon")
    await update_character(service, 1181, age=18, country="in")
    with pytest.raises(ValidationError, match="not legal"):
        await service.award_crime_event_item(1181, "prop_weapon")
    await update_character(service, 1181, country="usa")
    asset_id = await service.award_crime_event_item(1181, "prop_weapon")
    _, rows = await service.inventory(1181)
    assert any(row["asset_id"] == asset_id and row["item_id"] == "prop_weapon" for row in rows)


@pytest.mark.asyncio
async def test_yearly_shop_effects_run_inside_life_age_transaction(shop_context, life_engine):
    _, _, service, _ = shop_context
    await create_adult(life_engine, service, 1191, cash=100_000_000)
    await buy(service, 1191, "dog")
    await buy(service, 1191, "laundromat")
    character = await life_engine.get_active_character(1191)
    await update_character(service, 1191, stats=replace(character.stats, happiness=50))

    outcome = await life_engine.age_up(1191)

    assert outcome.character.age == 26
    assert outcome.character.stats.happiness >= 51
    # The new yearly living-cost settlement can consume business income after it is paid.
    assert outcome.character.cash >= 0 and outcome.character.bank >= 0
    assert outcome.character.cash < 74_950_000
    front = await service.db.fetchone("SELECT front_business FROM crime_profiles WHERE char_id = ?", (outcome.character.char_id,))
    assert front["front_business"] == 1
    assert any("annual business income" in message for message in outcome.log_messages)
    assert outcome.character.cash < 74_950_000


@pytest.mark.asyncio
async def test_trade_age_prison_and_ban_gates_are_enforced(shop_context, life_engine):
    database, _, service, clock = shop_context
    await create_adult(life_engine, service, 1201, age=17)
    await create_adult(life_engine, service, 1202)
    await register_old_account(service, 1201, clock)
    await register_old_account(service, 1202, clock)
    with pytest.raises(ValidationError, match="at least 18"):
        await service.create_trade(1201, 1202, offered_items={}, requested_items={}, offer_cash=1)
    await update_character(service, 1201, age=25, in_prison=True)
    with pytest.raises(CharacterInPrison, match="prison"):
        await service.create_trade(1201, 1202, offered_items={}, requested_items={}, offer_cash=1)
    await update_character(service, 1201, in_prison=False)
    await database.execute("UPDATE players SET trade_banned = 1 WHERE user_id = ?", (1201,))
    with pytest.raises(ValidationError, match="trade-banned"):
        await service.create_trade(1201, 1202, offered_items={}, requested_items={}, offer_cash=1)


@pytest.mark.asyncio
async def test_catalog_licenses_titles_and_weapons_are_not_shop_trade_offers(shop_context):
    """Protected catalog types cannot be sold from the regular inventory shop."""
    _, _, service, _ = shop_context
    assert service.items["title_homeowner"]["tradeable"] is False
    assert service.items["fishing_license"]["tradeable"] is False
    assert service.items["prop_weapon"]["tradeable"] is False
    assert service.items["prop_weapon"]["shop_available"] is False
