"""Casino RTP, EV, blackjack, limits, addiction, tax, and refund acceptance tests."""
from __future__ import annotations

import json
from dataclasses import replace

import pytest

from core.casino import CasinoService, GAMBLING_DISEASE_ID, SLOT_SYMBOLS, SLOT_WEIGHTS
from core.config import GameBalance
from core.errors import ConcurrentUpdate, ValidationError
from core.models import Character
from core.rng import RNG


class Clock:
    """Mutable deterministic real-time clock for cooldown/session tests."""

    def __init__(self, value: int = 1_800_000_000) -> None:
        self.value = value

    def __call__(self) -> int:
        return self.value


class FixedShuffleRNG(RNG):
    """Seedable RNG that supplies predetermined blackjack deal order(s)."""

    def __init__(self, orders: list[list[str]], seed: int = 7) -> None:
        super().__init__(seed)
        self.orders = [list(order) for order in orders]

    def shuffle(self, values: list[str]) -> None:
        if not self.orders:
            super().shuffle(values)
            return
        order = self.orders.pop(0)
        for card in order:
            values.remove(card)
        values.extend(reversed(order))


async def _set_life(database, life_engine, user_id: int, *, age: int = 21, cash: int = 1_000_000, bank: int = 1_000_000, country: str = "uk", addiction: int = 0) -> Character:
    """Create a real life/family, then set deterministic age and integer-cent balances."""
    character = await life_engine.create_character(user_id, f"Casino Test {user_id}", country=country)
    character = replace(
        character, age=age, cash=cash, bank=bank,
        stats=replace(character.stats, addiction=addiction),
        version=character.version + 1,
    )
    async with database.transaction() as tx:
        await tx.execute(
            "UPDATE characters SET age = ?, stats_json = ?, data_json = ?, version = ? WHERE char_id = ?",
            (character.age, json.dumps(character.stats.to_dict()),
             json.dumps(character.to_dict(), separators=(",", ":")), character.version, character.char_id),
        )
    return character


def _service(database, life_engine, clock: Clock, rng: RNG | None = None) -> CasinoService:
    """Construct a shared-lock casino domain service with deterministic time/RNG."""
    return CasinoService(database, rng or life_engine.rng, life_engine.locks, clock=clock)


def test_slots_million_spin_seeded_monte_carlo_92_percent_rtp(life_engine, database):
    """A one-million-spin seeded simulation remains within one percentage point of 92%."""
    casino = CasinoService(database, RNG(20260930), life_engine.locks)
    bet = 10_000
    payout = 0
    spins = 1_000_000
    for _ in range(spins):
        _, gross = casino.spin_slots(bet)
        payout += gross
    observed_rtp = payout / (spins * bet)
    assert abs(observed_rtp - 0.92) <= 0.01


def test_bet_ceiling_uses_combined_balance_and_price_index_cap():
    """Maximum wager is the lesser of combined funds and $250,000 times price index."""
    character = Character(cash=100_000_000, bank=100_000_000, price_index=2.0)
    assert CasinoService.max_bet_cents(character) == 50_000_000
    character = replace(character, cash=3_000, bank=4_000)
    assert CasinoService.max_bet_cents(character) == 7_000


def test_slots_paytable_and_roulette_expected_value():
    """The exact paytable and all roulette bet classes have their documented EV."""
    assert SLOT_SYMBOLS == ("cherry", "lemon", "bell", "diamond")
    assert SLOT_WEIGHTS == (50, 30, 15, 5)
    assert CasinoService.slot_payout(("cherry", "cherry", "cherry"), 101) == 151
    assert CasinoService.slot_payout(("lemon", "lemon", "lemon"), 101) == 303
    assert CasinoService.slot_payout(("bell", "bell", "bell"), 101) == 606
    assert CasinoService.slot_payout(("diamond", "diamond", "diamond"), 101) == 2_222
    assert CasinoService.slot_payout(("cherry", "cherry", "bell"), 101) == 101
    assert CasinoService.slot_payout(("cherry", "lemon", "bell"), 101) == 0

    bet = 10_000
    for kind in ("red", "black", "odd", "even"):
        payouts = [CasinoService.roulette_payout(bet, kind, None, landed) for landed in range(37)]
        assert 0.90 <= sum(payouts) / (37 * bet) <= 0.97
    for dozen in (1, 2, 3):
        payouts = [CasinoService.roulette_payout(bet, "dozen", dozen, landed) for landed in range(37)]
        assert 0.90 <= sum(payouts) / (37 * bet) <= 0.97
    for number in range(37):
        payouts = [CasinoService.roulette_payout(bet, "straight", number, landed) for landed in range(37)]
        assert 0.90 <= sum(payouts) / (37 * bet) <= 0.97


def test_coinflip_and_lottery_expected_values_are_negative():
    """Coinflip and the configured lottery retain negative EV within the RTP target."""
    bet_cents = 10_000
    winning_gross = bet_cents * 194 // 100
    expected_coinflip_net = (winning_gross / 2) - bet_cents
    assert expected_coinflip_net == -300

    expected_lottery_prize_cents = (
        1 * GameBalance.CASINO_LOTTERY_JACKPOT_CENTS
        + 100 * 1_000_000
        + 10_000 * 10_000
        + 100_000 * 1_000
        + 1_000_000 * 250
    ) / 10_000_000
    assert expected_lottery_prize_cents == 955
    assert 0.90 <= expected_lottery_prize_cents / 1_000 <= 0.97
    assert expected_lottery_prize_cents - 1_000 < 0


def test_blackjack_soft_17_natural_bust_and_six_deck_shoe():
    """Dealer stands on soft 17; naturals, busts, and the six-deck shoe are correct."""
    assert CasinoService._hand_total(["A♠", "6♦"]) == (17, True)
    assert not CasinoService._dealer_hits(["A♠", "6♦"])
    assert CasinoService._dealer_hits(["A♠", "5♦"])
    assert CasinoService._is_natural(["A♠", "K♦"])
    assert not CasinoService._is_natural(["A♠", "5♦", "5♣"])
    assert len(CasinoService._new_shoe()) == 312
    assert CasinoService._hand_total(["K♠", "9♦", "5♣"])[0] == 24


@pytest.mark.asyncio
async def test_blackjack_natural_pays_three_to_two_and_soft_17_stands(database, life_engine):
    """A natural pays 3:2 profit and the dealer does not draw from soft 17."""
    clock = Clock()
    await _set_life(database, life_engine, 301, cash=50_000, bank=50_000)
    natural_rng = FixedShuffleRNG([["A♠", "10♥", "K♦", "7♣"]])
    natural = _service(database, life_engine, clock, natural_rng)
    result = await natural.blackjack_start(301, 1_000)
    assert result.status == "settled"
    assert result.payout_cents == 2_500
    assert result.net_cents == 1_500
    assert "natural blackjack" in result.message

    # A fresh owner/life avoids the cross-game real-time cooldown.
    await _set_life(database, life_engine, 302, cash=50_000, bank=50_000)
    soft_rng = FixedShuffleRNG([["10♠", "A♥", "8♣", "6♦"]])
    soft = _service(database, life_engine, clock, soft_rng)
    started = await soft.blackjack_start(302, 1_000)
    assert started.status == "active"
    stood = await soft.blackjack_action(302, started.session_id, started.nonce, "stand")
    assert stood.outcome["dealer_total"] == 17
    assert len(stood.outcome["dealer"]) == 2
    assert stood.net_cents == 1_000


@pytest.mark.asyncio
async def test_blackjack_bust_double_and_nonce_protected_settlement(database, life_engine):
    """Hit busts lose; Double adds a second wager, draws once, and settles only once."""
    clock = Clock()
    await _set_life(database, life_engine, 303, cash=100_000, bank=100_000)
    bust_rng = FixedShuffleRNG([["10♠", "8♥", "9♣", "7♦", "5♣"]])
    bust_service = _service(database, life_engine, clock, bust_rng)
    started = await bust_service.blackjack_start(303, 1_000)
    bust = await bust_service.blackjack_action(303, started.session_id, started.nonce, "hit")
    assert bust.status == "settled"
    assert bust.payout_cents == 0
    assert bust.outcome["player_total"] == 24

    double_character = await _set_life(database, life_engine, 304, cash=100_000, bank=100_000)
    double_rng = FixedShuffleRNG([["5♠", "10♥", "6♠", "6♦", "K♣", "3♣"]])
    double_service = _service(database, life_engine, clock, double_rng)
    started = await double_service.blackjack_start(304, 1_000)
    doubled = await double_service.blackjack_action(304, started.session_id, started.nonce, "double")
    assert doubled.status == "settled"
    assert doubled.bet_cents == 2_000
    assert doubled.payout_cents == 4_000
    assert doubled.net_cents == 2_000
    with pytest.raises(ConcurrentUpdate):
        await double_service.blackjack_action(304, started.session_id, started.nonce, "stand")
    plays = await database.fetchall("SELECT * FROM casino_plays WHERE char_id = ?", (double_character.char_id,))
    assert len(plays) == 1 and plays[0]["status"] == "settled"
    counter = await database.fetchone(
        "SELECT count FROM yearly_counters WHERE char_id = ? AND action = 'casino_bet'",
        (double_character.char_id,),
    )
    assert counter["count"] == 2


@pytest.mark.asyncio
async def test_blackjack_restart_refunds_escrow_exactly_once(database, life_engine):
    """Startup recovers the exact cash/bank split and cannot replay a second refund."""
    clock = Clock()
    original = await _set_life(database, life_engine, 305, cash=1_234, bank=9_876)
    rng = FixedShuffleRNG([["10♠", "8♥", "9♣", "7♦"]])
    casino = _service(database, life_engine, clock, rng)
    started = await casino.blackjack_start(305, 1_000)
    assert started.status == "active"
    after_start = Character.from_dict(json.loads((await database.fetchone(
        "SELECT data_json FROM characters WHERE char_id = ?", (original.char_id,)
    ))["data_json"]))
    assert after_start.cash + after_start.bank == original.cash + original.bank - 1_000

    assert await casino.recover_sessions() == 1
    refunded = Character.from_dict(json.loads((await database.fetchone(
        "SELECT data_json FROM characters WHERE char_id = ?", (original.char_id,)
    ))["data_json"]))
    assert (refunded.cash, refunded.bank) == (original.cash, original.bank)
    assert await casino.recover_sessions() == 0
    again = Character.from_dict(json.loads((await database.fetchone(
        "SELECT data_json FROM characters WHERE char_id = ?", (original.char_id,)
    ))["data_json"]))
    assert (again.cash, again.bank) == (original.cash, original.bank)
    play = await database.fetchone("SELECT status, payout_cents, net_cents FROM casino_plays WHERE char_id = ?", (original.char_id,))
    assert play["status"] == "refunded" and play["payout_cents"] == 1_000 and play["net_cents"] == 0


@pytest.mark.asyncio
async def test_casino_country_age_bet_cap_cooldown_and_annual_limit_fallback(database, life_engine):
    """Country age, available-funds caps, cross-game cooldown, and both bet counters are enforced."""
    clock = Clock(10_000)
    await _set_life(database, life_engine, 306, age=20, country="india", cash=20_000, bank=20_000)
    casino = _service(database, life_engine, clock)
    with pytest.raises(ValidationError, match="age 21"):
        await casino.play_slots(306, 100)

    adult = await _set_life(database, life_engine, 307, age=21, country="uk", cash=500, bank=500)
    with pytest.raises(ValidationError):
        await casino.play_slots(307, 1_001)
    await casino.play_slots(307, 100)
    clock.value += 2
    with pytest.raises(ValidationError, match="cooldown"):
        await casino.play_coinflip(307, "heads", 100)
    clock.value += 1
    await casino.play_coinflip(307, "heads", 100)
    updated = Character.from_dict(json.loads((await database.fetchone(
        "SELECT data_json FROM characters WHERE char_id = ?", (adult.char_id,)
    ))["data_json"]))
    assert updated.cash >= 0 and updated.bank >= 0
    tracking = await database.fetchone("SELECT total_gambled, total_gambling_net FROM stats_tracking WHERE char_id = ?", (adult.char_id,))
    plays = await database.fetchall("SELECT net_cents FROM casino_plays WHERE char_id = ? AND status = 'settled'", (adult.char_id,))
    assert tracking["total_gambled"] == 200
    assert tracking["total_gambling_net"] == sum(int(row["net_cents"]) for row in plays)

    normal = await _set_life(database, life_engine, 308, cash=2_000_000, bank=2_000_000)
    for _ in range(25):
        clock.value += 3
        await casino.play_slots(308, 100)
    with pytest.raises(ValidationError, match="25 bets"):
        clock.value += 3
        await casino.play_slots(308, 100)
    row = await database.fetchone(
        "SELECT count FROM yearly_counters WHERE char_id = ? AND action = 'casino_bet'", (normal.char_id,)
    )
    assert row["count"] == 25

    legacy = await _set_life(database, life_engine, 309, cash=2_000_000, bank=2_000_000)
    async with database.transaction() as tx:
        await tx.execute("DELETE FROM npcs WHERE owner_char_id = ?", (legacy.char_id,))
    for _ in range(25):
        clock.value += 3
        await casino.play_slots(309, 100)
    with pytest.raises(ValidationError, match="25 bets"):
        clock.value += 3
        await casino.play_slots(309, 100)
    fallback = await database.fetchone("SELECT count FROM casino_yearly_bets WHERE char_id = ? AND age = ?", (legacy.char_id, legacy.age))
    assert fallback["count"] == 25


@pytest.mark.asyncio
async def test_addiction_fraction_disease_compulsion_and_rehab(database, life_engine):
    """Each bet accrues fractional addiction, diagnoses at 60, and treatment moves it to remission."""
    clock = Clock()
    character = await _set_life(database, life_engine, 310, addiction=59, cash=100_000, bank=100_000)
    async with database.transaction() as tx:
        await tx.execute(
            "INSERT INTO stats_tracking(char_id, gambling_addiction_fraction) VALUES (?, 0.8)",
            (character.char_id,),
        )
    casino = _service(database, life_engine, clock)
    await casino.play_slots(310, 100)
    updated = Character.from_dict(json.loads((await database.fetchone(
        "SELECT data_json FROM characters WHERE char_id = ?", (character.char_id,)
    ))["data_json"]))
    assert updated.stats.addiction == 60
    disease = await database.fetchone(
        "SELECT status, is_active, severity FROM health_conditions WHERE char_id = ? AND disease_id = ?",
        (character.char_id, GAMBLING_DISEASE_ID),
    )
    assert disease["status"] == "active" and disease["is_active"] == 1 and disease["severity"] >= 1

    async with database.transaction() as tx:
        await tx.execute(
            "INSERT INTO family_assets(char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at) "
            "VALUES (?, 'item', 'gambling_rehab', 1, 250000, 250000, ?, ?)",
            (character.char_id, character.age, clock.value),
        )
    before, after = await casino.use_rehab(310)
    assert (before, after) == (60, 40)
    disease = await database.fetchone(
        "SELECT status, is_active FROM health_conditions WHERE char_id = ? AND disease_id = ?",
        (character.char_id, GAMBLING_DISEASE_ID),
    )
    assert disease["status"] == "in_remission" and disease["is_active"] == 0

    # A scripted 25% roll creates one durable annual choice at addiction 60+.
    addicted = await _set_life(database, life_engine, 311, addiction=60, cash=20_000, bank=20_000)
    class AlwaysZero(RNG):
        def random(self) -> float:
            return 0.0
    forced_rng = AlwaysZero(3)
    forced = _service(database, life_engine, clock, forced_rng)
    async with database.transaction() as tx:
        progress = await forced.advance_year(tx, addicted, previous_age=20, now=clock.value)
    assert progress.compulsion is not None
    result = await forced.resolve_compulsion(
        311, int(progress.compulsion["compulsion_id"]), str(progress.compulsion["nonce"]), "resist"
    )
    assert result.status == "resisted"
    saved = await database.fetchone("SELECT status FROM casino_compulsions WHERE compulsion_id = ?", (progress.compulsion["compulsion_id"],))
    assert saved["status"] == "resisted"


@pytest.mark.asyncio
async def test_lottery_ticket_uses_specified_jackpot_and_is_consumed(database, life_engine):
    """A 1-in-10,000,000 draw pays the configured jackpot and consumes one ticket."""
    clock = Clock()
    character = await _set_life(database, life_engine, 313, cash=100_000, bank=100_000)
    class JackpotRNG(RNG):
        def randrange(self, *args: int) -> int:
            return 0
    casino = _service(database, life_engine, clock, JackpotRNG(9))
    async with database.transaction() as tx:
        await tx.execute(
            "INSERT INTO family_assets(char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at) "
            "VALUES (?, 'item', 'lottery_ticket', 1, 1000, 1000, ?, ?)",
            (character.char_id, character.age, clock.value),
        )
    receipt = await casino.use_lottery_ticket(313)
    assert receipt.payout_cents == GameBalance.CASINO_LOTTERY_JACKPOT_CENTS
    assert receipt.net_cents == GameBalance.CASINO_LOTTERY_JACKPOT_CENTS - 1_000
    asset = await database.fetchone("SELECT quantity, is_liquidated FROM family_assets WHERE char_id = ? AND item_id = 'lottery_ticket'", (character.char_id,))
    assert asset["quantity"] == 0 and asset["is_liquidated"] == 1


@pytest.mark.asyncio
async def test_casino_exception_rolls_back_all_writes_and_balances(database, life_engine, monkeypatch):
    """A late failure rolls back bet debit, play row, cooldown, counter, and addiction."""
    clock = Clock()
    character = await _set_life(database, life_engine, 314, cash=100_000, bank=200_000)
    casino = _service(database, life_engine, clock)
    async def fail_audit(*args, **kwargs):
        raise RuntimeError("injected audit failure")
    monkeypatch.setattr(casino.repository, "insert_audit", fail_audit)
    with pytest.raises(RuntimeError, match="injected audit failure"):
        await casino.play_slots(314, 10_000)
    saved = Character.from_dict(json.loads((await database.fetchone(
        "SELECT data_json FROM characters WHERE char_id = ?", (character.char_id,)
    ))["data_json"]))
    assert (saved.cash, saved.bank, saved.stats.addiction) == (character.cash, character.bank, character.stats.addiction)
    assert await database.fetchone("SELECT 1 FROM casino_plays WHERE char_id = ?", (character.char_id,)) is None
    assert await database.fetchone("SELECT 1 FROM yearly_counters WHERE char_id = ? AND action = 'casino_bet'", (character.char_id,)) is None
    assert await database.fetchone("SELECT 1 FROM casino_player_state WHERE user_id = ?", (314,)) is None


@pytest.mark.asyncio
async def test_gambling_winnings_tax_is_24_percent_above_5000_and_idempotent(database, life_engine):
    """The yearly net threshold and tax write once, with no negative cash or bank."""
    clock = Clock()
    character = await _set_life(database, life_engine, 312, cash=200_000, bank=500_000)
    casino = _service(database, life_engine, clock)
    async with database.transaction() as tx:
        await casino.repository.insert_play(
            tx, char_id=character.char_id, user_id=312, age=character.age,
            game="slots", bet_cents=500_000, status="settled",
            outcome={"test": True}, created_at=clock.value,
        )
        await tx.execute("UPDATE casino_plays SET payout_cents = 1_500_000, net_cents = 1_000_000 WHERE char_id = ?", (character.char_id,))
        first = await casino.advance_year(tx, character, previous_age=character.age, now=clock.value)
        second = await casino.advance_year(tx, first.character, previous_age=character.age, now=clock.value + 1)
    assert first.character.cash == 80_000  # 24% × ($10,000 net − $5,000 allowance) = $1,200
    assert second.character.cash == first.character.cash
    tax = await database.fetchone("SELECT gambling_net_cents, gambling_tax_cents FROM casino_yearly_tax WHERE char_id = ? AND age = ?", (character.char_id, character.age))
    assert tax["gambling_net_cents"] == 1_000_000
    assert tax["gambling_tax_cents"] == 120_000


@pytest.mark.asyncio
async def test_life_age_integrates_gambling_tax_and_compulsion_choice(database, life_engine):
    """The yearly life transaction settles gambling tax, emits an addiction prompt, and blocks a second tick."""
    clock = Clock()
    character = await _set_life(database, life_engine, 315, age=21, addiction=60, cash=100_000, bank=100_000)
    class AlwaysZero(RNG):
        def random(self) -> float:
            return 0.0
    life_engine.casino = CasinoService(database, AlwaysZero(10), life_engine.locks, clock=clock)
    async with database.transaction() as tx:
        await life_engine.casino.repository.insert_play(
            tx, char_id=character.char_id, user_id=315, age=21,
            game="slots", bet_cents=500_000, status="settled",
            outcome={"seeded": True}, created_at=clock.value,
        )
        await tx.execute("UPDATE casino_plays SET payout_cents = 1_500_000, net_cents = 1_000_000 WHERE char_id = ?", (character.char_id,))
    outcome = await life_engine.age_up(315)
    assert outcome.character.age == 22
    assert outcome.pending_compulsion is not None
    assert any("Gambling winnings tax" in message for message in outcome.log_messages)
    tax = await database.fetchone("SELECT gambling_tax_cents FROM casino_yearly_tax WHERE char_id = ? AND age = 21", (character.char_id,))
    assert tax["gambling_tax_cents"] == 120_000
    with pytest.raises(ValidationError, match="compulsion"):
        await life_engine.age_up(315)
    result = await life_engine.casino.resolve_compulsion(
        315, int(outcome.pending_compulsion["compulsion_id"]),
        str(outcome.pending_compulsion["nonce"]), "resist",
    )
    assert result.status == "resisted"
