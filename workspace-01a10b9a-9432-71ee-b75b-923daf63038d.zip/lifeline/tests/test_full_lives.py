"""Opt-in seeded balance cohort using real, unmodified LIFELINE lives.

Run a tuning cohort with ``LIFELINE_RUN_FULL_LIVES=1 LIFELINE_LIFE_COUNT=100 pytest -q -s tests/test_full_lives.py``.
The final acceptance cohort uses 500 lives. Crime and addiction profiles take only
real service actions; no stats, funds, or debt are injected by the harness. Bankruptcy
eligibility is audited, but the harness never submits a filing on the player's behalf.
"""
from __future__ import annotations

import json
import os
import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from statistics import mean, median
from typing import Any

import pytest

from core.config import GameBalance
from core.education import EducationService
from core.errors import GameError
from core.life_engine import LifeEngine
from core.locks import UserLockRegistry
from core.models import Character, EducationLevel, JobAction, StudyEffort
from core.rng import RNG

LIFE_COUNT = int(os.getenv("LIFELINE_LIFE_COUNT", "500"))
USER_ID_BASE = 930_000
SIMULATION_SEED = int(os.getenv("LIFELINE_SIMULATION_SEED", "20261001"))
CRIME_PROFILE_MODULO = frozenset({0, 1})
ADDICTION_PROFILE_MODULO = frozenset({2, 3})
NORMAL_PROFILE_NAME = "normal"
CRIME_PROFILE_NAME = "heavy_crime"
ADDICTION_PROFILE_NAME = "heavy_addiction"
MILLIONAIRE_THRESHOLD_CENTS = 100_000_000
BILLIONAIRE_THRESHOLD_CENTS = 100_000_000_000


class SimulationClock:
    """Mutable simulated real-time clock for cooldown and expiry services."""

    def __init__(self, value: int = 1_900_000_000) -> None:
        self.value = value

    def __call__(self) -> int:
        return self.value

    def advance(self, seconds: int = 1) -> None:
        self.value += int(seconds)


@dataclass(slots=True)
class RunCounters:
    """Counters describing the decisions and routes exercised by the cohort."""

    annual_steps: int = 0
    events_resolved: int = 0
    studies: int = 0
    college_enrollments: int = 0
    jobs_started: int = 0
    work_actions: int = 0
    promotions: int = 0
    crime_attempts: int = 0
    crime_trials: int = 0
    addiction_bets: int = 0
    compulsion_choices: int = 0
    bankruptcies: int = 0
    bankruptcy_policy_checks: int = 0
    bankruptcy_policy_eligible_checks: int = 0
    bankruptcy_policy_blocked: Counter[str] = field(default_factory=Counter)
    bankruptcy_candidate_debts_cents: list[int] = field(default_factory=list)
    bankruptcy_candidate_assets_cents: list[int] = field(default_factory=list)
    bankruptcy_candidate_surplus_cents: list[int] = field(default_factory=list)
    bankruptcy_candidate_repayment_capacity_cents: list[int] = field(default_factory=list)
    bankruptcy_candidate_debt_breakdowns: list[dict[str, dict[str, int]]] = field(default_factory=list)


def _profile_for_index(index: int) -> str:
    """Return a deterministic cohort profile without modifying the starting life."""
    bucket = index % 10
    if bucket in CRIME_PROFILE_MODULO:
        return CRIME_PROFILE_NAME
    if bucket in ADDICTION_PROFILE_MODULO:
        return ADDICTION_PROFILE_NAME
    return NORMAL_PROFILE_NAME


def _assert_character_invariants(character: Character) -> None:
    """Check the monetary and stat bounds at each completed service decision."""
    for name in ("cash", "bank", "debt_total"):
        value = getattr(character, name)
        assert isinstance(value, int) and not isinstance(value, bool), (name, value)
        assert 0 <= value <= 9_000_000_000_000_000, (name, value)
    for name, value in character.stats.to_dict().items():
        if name == "credit_score":
            assert value is None or 300 <= int(value) <= 850
        else:
            assert 0 <= int(value) <= 100, (name, value)


def _distribution_summary(values: list[int]) -> dict[str, int | float]:
    """Return reproducible population summaries and empirical age/wealth quantiles."""
    if not values:
        return {"count": 0}
    ordered = sorted(int(value) for value in values)

    def quantile(fraction: float) -> int:
        return ordered[round((len(ordered) - 1) * fraction)]

    return {
        "count": len(ordered),
        "mean": round(mean(ordered), 2),
        "median": median(ordered),
        "p10": quantile(0.10),
        "p25": quantile(0.25),
        "p75": quantile(0.75),
        "p90": quantile(0.90),
        "min": ordered[0],
        "max": ordered[-1],
    }


def _target_status(value: float | int | None, lower: float, upper: float) -> dict[str, Any]:
    """Return a measured PASS/FAIL result for one inclusive numeric target."""
    passed = value is not None and lower <= float(value) <= upper
    return {"measured": value, "target": [lower, upper], "status": "PASS" if passed else "FAIL"}


async def _resolve_year_prompts(
    engine: LifeEngine,
    user_id: int,
    profile: str,
    outcome: Any,
    decision_rng: RNG,
    counters: RunCounters,
) -> None:
    """Resolve age-up decisions through their real nonce-validated services."""
    if outcome.pending_event is not None:
        choice = decision_rng.choice(outcome.pending_event.event.choices)
        await engine.events.resolve_choice(user_id, outcome.pending_event.nonce, choice.id)
        counters.events_resolved += 1
    if outcome.pending_trial is not None:
        await engine.crimes.resolve_trial(user_id, outcome.pending_trial.nonce, "public")
        counters.crime_trials += 1
    if outcome.pending_tax is not None:
        await engine.crimes.resolve_tax_choice(user_id, outcome.pending_tax.nonce, "pay")
    if outcome.pending_compulsion is not None:
        prompt = outcome.pending_compulsion
        character = await engine.get_active_character(user_id)
        forced_bet = int(prompt.get("forced_bet_cents", 0))
        can_afford = character.cash + character.bank >= forced_bet > 0
        choice = "indulge" if profile == ADDICTION_PROFILE_NAME and can_afford else "resist"
        await engine.casino.resolve_compulsion(
            user_id,
            int(prompt["compulsion_id"]),
            str(prompt["nonce"]),
            choice,
        )
        counters.compulsion_choices += 1


async def _audit_bankruptcy_eligibility(
    engine: LifeEngine,
    user_id: int,
    character: Character,
    counters: RunCounters,
) -> Character:
    """Measure eligibility without simulating or forcing the player's filing decision."""
    if character.age < 18 or character.in_prison:
        return character
    assessment = await engine.economy.bankruptcy_eligibility(user_id)
    counters.bankruptcy_policy_checks += 1
    if not assessment.eligible:
        counters.bankruptcy_policy_blocked[assessment.reason_code] += 1
        return character
    counters.bankruptcy_policy_eligible_checks += 1
    counters.bankruptcy_candidate_debts_cents.append(assessment.dischargeable_debt_cents)
    counters.bankruptcy_candidate_assets_cents.append(assessment.gross_assets_cents)
    counters.bankruptcy_candidate_surplus_cents.append(assessment.annual_surplus_cents)
    counters.bankruptcy_candidate_repayment_capacity_cents.append(assessment.repayment_capacity_cents)
    async with engine.db.transaction() as tx:
        debt_breakdown = await engine.economy.repository.bankruptcy_debt_breakdown(
            tx, character.char_id
        )
    dischargeable_loans = sum(
        debt_breakdown["live_loan_balances_cents_by_type"].get(loan_type, 0)
        for loan_type in ("personal", "payday", "loan_shark")
    )
    standalone_collections = sum(
        debt_breakdown["standalone_open_collections_cents_by_source"].values()
    )
    if dischargeable_loans + standalone_collections != assessment.dischargeable_debt_cents:
        raise AssertionError("bankruptcy source breakdown does not match the eligibility debt total")
    counters.bankruptcy_candidate_debt_breakdowns.append(debt_breakdown)
    return character


async def _try_college_enrollment(
    education: EducationService,
    user_id: int,
    character: Character,
    index: int,
    counters: RunCounters,
) -> Character:
    """Apply the normal cohort's predeclared one-in-four college choice via service."""
    if (
        character.age != 18
        or index % 4 != 2
        or character.education_level is not EducationLevel.HIGH_SCHOOL
        or character.school_program is not None
    ):
        return character
    try:
        updated = await education.enroll(user_id, EducationLevel.BACHELOR, "computer science")
    except GameError:
        return character
    counters.college_enrollments += 1
    return updated


async def _apply_average_work_policy(
    engine: LifeEngine,
    education: EducationService,
    user_id: int,
    character: Character,
    index: int,
    profile: str,
    decision_rng: RNG,
    clock: SimulationClock,
    counters: RunCounters,
) -> Character:
    """Choose regular study/work, then take any profile-specific real action."""
    if character.in_prison:
        try:
            await engine.crimes.prison_action(user_id, "behave")
        except GameError:
            pass
        return await engine.get_active_character(user_id)

    if character.school_program is not None:
        try:
            result = await education.study(user_id, StudyEffort.NORMAL)
        except GameError:
            pass
        else:
            character = result.character
            counters.studies += 1

    character = await _try_college_enrollment(
        education, user_id, character, index, counters
    )

    job = await engine.db.fetchone(
        "SELECT career_id, salary, is_part_time FROM jobs WHERE char_id = ?", (character.char_id,)
    )
    if job is None and 16 <= character.age <= 55 and not character.is_retired:
        eligible = engine.careers.eligible_careers(character)
        if eligible:
            career = decision_rng.choice(eligible)
            try:
                status = await engine.careers.apply(user_id, career.id, part_time=False)
            except GameError:
                pass
            else:
                counters.jobs_started += 1
                character = await engine.get_active_character(user_id)
                job = {
                    "career_id": career.id,
                    "salary": status.job.salary,
                    "is_part_time": status.job.is_part_time,
                }

    # A graduate normally seeks a field-appropriate job if still in an entry job.
    if (
        job is not None
        and character.education_level in {EducationLevel.BACHELOR, EducationLevel.MASTER, EducationLevel.DOCTORATE}
        and character.age >= 18
    ):
        current_career = engine.careers.get_career(str(job["career_id"]))
        degree_rank = {EducationLevel.BACHELOR: 3, EducationLevel.MASTER: 4, EducationLevel.DOCTORATE: 5}[
            character.education_level
        ]
        current_rank = {EducationLevel.NONE: 0, EducationLevel.PRIMARY: 1, EducationLevel.HIGH_SCHOOL: 2,
                        EducationLevel.BACHELOR: 3, EducationLevel.MASTER: 4, EducationLevel.DOCTORATE: 5}[
            current_career.minimum_education
        ]
        if current_rank < degree_rank:
            degree_jobs = [
                career for career in engine.careers.careers
                if career.minimum_education is character.education_level
                and character.stats.smarts >= career.minimum_smarts
                and career.minimum_age <= character.age <= career.retirement_age
                and career.salary_for(
                    1,
                    part_time=bool(job["is_part_time"]),
                    price_index=character.price_index,
                ) > int(job["salary"])
            ]
            if degree_jobs:
                target = decision_rng.choice(degree_jobs)
                try:
                    await engine.careers.quit(user_id)
                    status = await engine.careers.apply(user_id, target.id, part_time=False)
                except GameError:
                    pass
                else:
                    counters.jobs_started += 1
                    character = await engine.get_active_character(user_id)
                    job = {
                        "career_id": target.id,
                        "salary": status.job.salary,
                        "is_part_time": status.job.is_part_time,
                    }

    if job is not None and 16 <= character.age <= 60:
        try:
            result = await engine.careers.work(user_id, JobAction.WORK_NORMAL)
        except GameError:
            pass
        else:
            character = result.character
            counters.work_actions += 1

    if profile == CRIME_PROFILE_NAME and character.age >= 20 and not character.in_prison:
        job = await engine.db.fetchone(
            "SELECT career_id FROM jobs WHERE char_id = ?", (character.char_id,)
        )
        eligible_crimes = [
            crime for crime in engine.crimes.crimes
            if crime.commit_enabled
            and crime.min_age <= character.age
            and (not crime.requires_job or job is not None)
            and (crime.violence or crime.sentence_min >= 1)
        ]
        if eligible_crimes:
            crime = decision_rng.choice(eligible_crimes)
            try:
                preview = await engine.crimes.preview_crime(user_id, crime.id)
            except GameError:
                pass
            else:
                attempt = await engine.crimes.confirm_crime(user_id, preview.nonce)
                counters.crime_attempts += 1
                if attempt.trial is not None:
                    await engine.crimes.resolve_trial(user_id, attempt.trial.nonce, "public")
                    counters.crime_trials += 1

    if profile == ADDICTION_PROFILE_NAME and character.age >= 21 and not character.in_prison:
        # Fifteen $1 wagers per eligible year is below the service's 25-bet annual
        # limit and builds addiction only through ordinary casino transactions.
        for _ in range(15):
            character = await engine.get_active_character(user_id)
            if character.stats.addiction >= 100 or character.cash + character.bank < 100 or character.in_prison:
                break
            clock.advance(4)
            game = decision_rng.choice(("slots", "coinflip", "roulette"))
            try:
                if game == "slots":
                    await engine.casino.play_slots(user_id, 100)
                elif game == "coinflip":
                    await engine.casino.play_coinflip(user_id, decision_rng.choice(("heads", "tails")), 100)
                else:
                    await engine.casino.play_roulette(user_id, decision_rng.choice(("red", "black")), 100)
            except GameError:
                break
            counters.addiction_bets += 1

    character = await engine.get_active_character(user_id)
    if profile == NORMAL_PROFILE_NAME:
        character = await _audit_bankruptcy_eligibility(engine, user_id, character, counters)
    return await engine.get_active_character(user_id)


@pytest.mark.asyncio
@pytest.mark.skipif(
    os.getenv("LIFELINE_RUN_FULL_LIVES") != "1",
    reason="The balance cohort is opt-in; use 100 lives while tuning and 500 at final verification.",
)
async def test_500_fixed_seed_complete_lives(database: Any) -> None:
    """Run real default lives and report each supplied acceptance target explicitly."""
    if LIFE_COUNT < 1:
        raise ValueError("LIFELINE_LIFE_COUNT must be positive")
    clock = SimulationClock()
    locks = UserLockRegistry()
    engine = LifeEngine(
        database,
        RNG(SIMULATION_SEED),
        locks,
        clock=clock,
        event_chance=GameBalance.ANNUAL_EVENT_CHANCE,
    )
    education = EducationService(database, locks, clock=clock)
    decision_rng = RNG(SIMULATION_SEED ^ 0x5A17)
    await engine.investing.initialize_market()

    profiles = {
        USER_ID_BASE + index: _profile_for_index(index)
        for index in range(LIFE_COUNT)
    }
    active_users = set(profiles)
    counters = RunCounters()
    birth_wealth_classes: dict[int, str] = {}
    for index, user_id in enumerate(sorted(profiles)):
        character = await engine.create_character(user_id, f"Balance Life {index:03d}")
        birth_wealth_classes[user_id] = character.wealth_class

    for _simulated_year in range(1, GameBalance.MAX_AGE + 1):
        clock.advance(3_600)
        for user_id in sorted(tuple(active_users)):
            profile = profiles[user_id]
            try:
                outcome = await engine.age_up(user_id)
            except GameError as exc:
                if exc.__class__.__name__ == "CharacterDead":
                    active_users.discard(user_id)
                    continue
                raise
            counters.annual_steps += 1
            _assert_character_invariants(outcome.character)
            await _resolve_year_prompts(
                engine, user_id, profile, outcome, decision_rng, counters
            )
            if outcome.died:
                active_users.discard(user_id)
                continue
            character = await engine.get_active_character(user_id)
            character = await _apply_average_work_policy(
                engine,
                education,
                user_id,
                character,
                user_id - USER_ID_BASE,
                profile,
                decision_rng,
                clock,
                counters,
            )
            _assert_character_invariants(character)
            if not character.is_alive:
                active_users.discard(user_id)
        if not active_users:
            break

    assert not active_users, f"{len(active_users)} lives did not reach a terminal state by max age"
    archive_rows = await database.fetchall(
        "SELECT char_id, user_id, death_age, death_cause, final_net_worth_cents, summary_json, abandoned "
        "FROM past_lives ORDER BY user_id"
    )
    assert len(archive_rows) == LIFE_COUNT
    assert await database.fetchone("SELECT 1 FROM characters WHERE is_alive = 1") is None
    assert await database.fetchone("SELECT 1 FROM pending_events LIMIT 1") is None
    assert await database.fetchone("SELECT 1 FROM casino_compulsions WHERE status = 'pending' LIMIT 1") is None
    assert await database.fetchone("SELECT 1 FROM casino_sessions WHERE status = 'active' LIMIT 1") is None
    assert await database.fetchone("SELECT 1 FROM crime_trials LIMIT 1") is None
    assert await database.fetchone("SELECT 1 FROM crime_tax_prompts LIMIT 1") is None
    assert await database.fetchone("SELECT 1 FROM loans WHERE status = 'active' LIMIT 1") is None
    integrity = await database.fetchone("PRAGMA integrity_check")
    assert integrity is not None and integrity[0] == "ok"
    assert await database.fetchall("PRAGMA foreign_key_check") == []

    summaries = [json.loads(row["summary_json"]) for row in archive_rows]
    by_user = {int(row["user_id"]): json.loads(row["summary_json"]) for row in archive_rows}
    normal_users = {user_id for user_id, profile in profiles.items() if profile == NORMAL_PROFILE_NAME}
    normal_lives = [by_user[user_id] for user_id in sorted(normal_users)]
    crime_lives = [
        by_user[user_id] for user_id, profile in profiles.items() if profile == CRIME_PROFILE_NAME
    ]
    addiction_lives = [
        by_user[user_id] for user_id, profile in profiles.items() if profile == ADDICTION_PROFILE_NAME
    ]
    normal_ages = [int(summary["death_age"]) for summary in normal_lives]
    crime_ages = [int(summary["death_age"]) for summary in crime_lives]
    addiction_ages = [int(summary["death_age"]) for summary in addiction_lives]
    peak_worths = [int(summary["peak_net_worth_cents"]) for summary in normal_lives]
    final_worths = [int(summary["final_net_worth_cents"]) for summary in normal_lives]
    millionaire_rate = sum(value >= MILLIONAIRE_THRESHOLD_CENTS for value in peak_worths) / len(peak_worths)
    billionaire_rate = sum(value >= BILLIONAIRE_THRESHOLD_CENTS for value in peak_worths) / len(peak_worths)

    college_values = [
        int(summary["final_net_worth_cents"])
        for summary in normal_lives
        if summary["education"]["level"] in {"bachelor", "master", "doctorate"}
    ]
    no_high_school_values = [
        int(summary["final_net_worth_cents"])
        for summary in normal_lives
        if summary["education"]["level"] in {"none", "primary"}
    ]
    normal_wealth_by_char = {
        int(summary["char_id"]): birth_wealth_classes[int(summary["user_id"])]
        for summary in normal_lives
    }
    normal_wealth_class_counts = Counter(normal_wealth_by_char.values())
    millionaire_lives_by_wealth_class = Counter(
        normal_wealth_by_char[int(summary["char_id"])]
        for summary in normal_lives
        if int(summary["peak_net_worth_cents"]) >= MILLIONAIRE_THRESHOLD_CENTS
    )
    inheritance_rows = await database.fetchall(
        "SELECT char_id, text FROM life_logs WHERE text LIKE '%inheritance after tax was %'"
    )
    inheritance_events_by_wealth_class: Counter[str] = Counter()
    inheritance_lives_by_wealth_class: dict[str, set[int]] = defaultdict(set)
    inheritance_cents_by_wealth_class: Counter[str] = Counter()
    inheritance_cents_by_normal_life: Counter[int] = Counter()
    for row in inheritance_rows:
        char_id = int(row["char_id"])
        wealth_class = normal_wealth_by_char.get(char_id)
        match = re.search(r"inheritance after tax was ([\d,]+) dollars", str(row["text"]))
        if wealth_class is None or match is None:
            continue
        inherited_cents = int(match.group(1).replace(",", "")) * 100
        inheritance_events_by_wealth_class[wealth_class] += 1
        inheritance_lives_by_wealth_class[wealth_class].add(char_id)
        inheritance_cents_by_wealth_class[wealth_class] += inherited_cents
        inheritance_cents_by_normal_life[char_id] += inherited_cents

    bankrupt_rows = await database.fetchall(
        """SELECT DISTINCT c.user_id
           FROM bankruptcies AS b JOIN characters AS c ON c.char_id = b.char_id"""
    )
    filed_users = {int(row["user_id"]) for row in bankrupt_rows}
    normal_bankruptcy_rate = len(normal_users & filed_users) / len(normal_users)

    candidate_breakdowns = counters.bankruptcy_candidate_debt_breakdowns

    def component_distributions(key: str) -> dict[str, dict[str, int | float]]:
        """Summarize source balances across the exact pre-filing eligibility checks."""
        components = sorted({
            component
            for breakdown in candidate_breakdowns
            for component in breakdown[key]
        })
        return {
            component: _distribution_summary([
                int(breakdown[key].get(component, 0)) for breakdown in candidate_breakdowns
            ])
            for component in components
        }

    dischargeable_loan_balances = [
        sum(
            int(breakdown["live_loan_balances_cents_by_type"].get(loan_type, 0))
            for loan_type in ("personal", "payday", "loan_shark")
        )
        for breakdown in candidate_breakdowns
    ]
    standalone_collection_balances = [
        sum(breakdown["standalone_open_collections_cents_by_source"].values())
        for breakdown in candidate_breakdowns
    ]
    linked_collection_balances = [
        sum(breakdown["linked_open_collection_mirrors_cents_by_source"].values())
        for breakdown in candidate_breakdowns
    ]

    first_promotion_rows = await database.fetchall(
        """SELECT h.char_id, h.start_age, MIN(l.age) AS first_promotion_age
           FROM career_history AS h
           JOIN life_logs AS l ON l.char_id = h.char_id
           WHERE l.text LIKE 'Promoted to %' AND l.age >= h.start_age
           GROUP BY h.char_id, h.start_age"""
    )
    normal_char_ids = {int(summary["char_id"]) for summary in normal_lives}
    promotion_years = [
        int(row["first_promotion_age"]) - int(row["start_age"])
        for row in first_promotion_rows
        if int(row["char_id"]) in normal_char_ids
    ]
    promotion_median = median(promotion_years) if promotion_years else None
    counters.promotions = len(promotion_years)

    death_causes = Counter(str(summary["death_cause"]) for summary in summaries)
    profile_counts = Counter(profiles.values())
    crime_attempt_rows = await database.fetchall(
        "SELECT COUNT(*) AS count FROM crime_attempts"
    )
    bankruptcy_target = _target_status(normal_bankruptcy_rate, 0.03, 0.10)
    bankruptcy_minimum_dollars, bankruptcy_minimum_remainder = divmod(
        GameBalance.BANKRUPTCY_MIN_DISCHARGEABLE_DEBT_CENTS, 100
    )
    bankruptcy_minimum_display = (
        f"${bankruptcy_minimum_dollars:,}.{bankruptcy_minimum_remainder:02d}"
    )
    billionaire_target = {
        "measured": billionaire_rate,
        "target": "<0.005",
        "status": "PASS" if billionaire_rate < 0.005 else "FAIL",
    }
    acceptance = {
        "normal_lifestyle_median_lifespan_years": _target_status(median(normal_ages), 75, 85),
        "heavy_crime_median_lifespan_years": _target_status(median(crime_ages) if crime_ages else None, 45, 65),
        "heavy_addiction_median_lifespan_years": _target_status(median(addiction_ages) if addiction_ages else None, 45, 65),
        "normal_lives_reaching_1m_net_worth": _target_status(millionaire_rate, 0.08, 0.20),
        "normal_lives_reaching_1b_net_worth": billionaire_target,
        "natural_bankruptcy_filing_rate": bankruptcy_target,
        "college_graduate_median_final_net_worth_cents": _target_status(
            median(college_values) if college_values else None, 25_000_000, 150_000_000
        ),
        "no_high_school_median_final_net_worth_cents": _target_status(
            median(no_high_school_values) if no_high_school_values else None, 0, 15_000_000
        ),
        "average_performer_years_to_first_promotion": _target_status(promotion_median, 2, 4),
    }
    report = {
        "seed": SIMULATION_SEED,
        "lives": LIFE_COUNT,
        "profiles": dict(sorted(profile_counts.items())),
        "annual_steps": counters.annual_steps,
        "death_causes": dict(sorted(death_causes.items())),
        "normal_lifestyle_lifespan_distribution_years": _distribution_summary(normal_ages),
        "heavy_crime_lifespan_distribution_years": _distribution_summary(crime_ages),
        "heavy_addiction_lifespan_distribution_years": _distribution_summary(addiction_ages),
        "normal_peak_net_worth_distribution_cents": _distribution_summary(peak_worths),
        "normal_final_net_worth_distribution_cents": _distribution_summary(final_worths),
        "normal_birth_wealth_class_counts": dict(sorted(normal_wealth_class_counts.items())),
        "normal_millionaire_lives_by_birth_wealth_class": dict(sorted(millionaire_lives_by_wealth_class.items())),
        "normal_parent_inheritance_events_by_birth_wealth_class": dict(sorted(inheritance_events_by_wealth_class.items())),
        "normal_parent_inheritance_lives_by_birth_wealth_class": {
            key: len(value) for key, value in sorted(inheritance_lives_by_wealth_class.items())
        },
        "normal_parent_inheritance_total_cents_by_birth_wealth_class": dict(sorted(inheritance_cents_by_wealth_class.items())),
        "normal_parent_inheritance_per_life_cents": _distribution_summary(
            list(inheritance_cents_by_normal_life.values())
        ),
        "millionaire_rate_by_peak_net_worth": round(millionaire_rate, 4),
        "billionaire_rate_by_peak_net_worth": round(billionaire_rate, 4),
        "natural_bankruptcy_filing_lives": len(normal_users & filed_users),
        "natural_bankruptcy_filing_rate": round(normal_bankruptcy_rate, 4),
        "college_graduate_count": len(college_values),
        "college_graduate_median_final_net_worth_cents": median(college_values) if college_values else None,
        "no_high_school_count": len(no_high_school_values),
        "no_high_school_median_final_net_worth_cents": median(no_high_school_values) if no_high_school_values else None,
        "first_promotion_observations": len(promotion_years),
        "average_performer_years_to_first_promotion_median": promotion_median,
        "crime_attempt_rows": int(crime_attempt_rows[0]["count"]) if crime_attempt_rows else 0,
        "natural_bankruptcy_definition": "At least one actual bankruptcies-table row for a normal-profile life; only dischargeable unsecured debt over twice gross assets can qualify, liquid funds must be insufficient, and any first loan must be at least two in-game years old.",
        "insolvency_definition": "All liabilities greater than gross assets; distinct from dischargeable debt and filing incidence.",
        "bankruptcy_policy": {
            "checks": counters.bankruptcy_policy_checks,
            "eligible_checks": counters.bankruptcy_policy_eligible_checks,
            "blocked_reasons": dict(sorted(counters.bankruptcy_policy_blocked.items())),
            "eligible_candidate_dischargeable_debt_cents": _distribution_summary(counters.bankruptcy_candidate_debts_cents),
            "eligible_candidate_gross_assets_cents": _distribution_summary(counters.bankruptcy_candidate_assets_cents),
            "eligible_candidate_annual_surplus_cents": _distribution_summary(counters.bankruptcy_candidate_surplus_cents),
            "eligible_candidate_repayment_capacity_cents": _distribution_summary(counters.bankruptcy_candidate_repayment_capacity_cents),
            "eligible_candidate_dischargeable_loan_balances_cents": _distribution_summary(dischargeable_loan_balances),
            "eligible_candidate_standalone_collection_balances_cents": _distribution_summary(standalone_collection_balances),
            "eligible_candidate_linked_collection_mirror_balances_cents": _distribution_summary(linked_collection_balances),
            "eligible_candidate_live_loan_balances_cents_by_type": component_distributions(
                "live_loan_balances_cents_by_type"
            ),
            "eligible_candidate_standalone_open_collections_cents_by_source": component_distributions(
                "standalone_open_collections_cents_by_source"
            ),
            "eligible_candidate_linked_open_collection_mirrors_cents_by_source": component_distributions(
                "linked_open_collection_mirrors_cents_by_source"
            ),
            "criteria": (
                "Dischargeable personal/payday/loan-shark balances plus standalone open collections; "
                "excludes student, mortgage, and auto loan balances and linked collection mirrors. "
                f"Requires at least {bankruptcy_minimum_display} dischargeable debt, debt > 2x gross assets, "
                "cash+bank plus ten years of after-tax disposable income below dischargeable debt, and—if "
                "any loan exists—the first loan at least two in-game years old."
            ),
        },
        "route_counters": {
            "events_resolved": counters.events_resolved,
            "studies": counters.studies,
            "college_enrollments": counters.college_enrollments,
            "jobs_started": counters.jobs_started,
            "work_actions": counters.work_actions,
            "promotions": counters.promotions,
            "crime_attempts_by_heavy_profiles": counters.crime_attempts,
            "addiction_bets_by_heavy_profiles": counters.addiction_bets,
            "compulsion_choices": counters.compulsion_choices,
            "bankruptcies_by_normal_profiles": counters.bankruptcies,
        },
        "acceptance": acceptance,
    }
    print("FULL_LIFE_SIMULATION_REPORT=" + json.dumps(report, sort_keys=True))

    persisted_characters = await database.fetchall("SELECT data_json FROM characters")
    assert len(persisted_characters) == LIFE_COUNT
    assert all(
        Character.from_dict(json.loads(row["data_json"])).lifestyle.value == "normal"
        for row in persisted_characters
    )
    assert len(normal_lives) + len(crime_lives) + len(addiction_lives) == LIFE_COUNT
    assert counters.annual_steps >= LIFE_COUNT * 20
    assert counters.events_resolved > 0
    assert counters.jobs_started > 0 and counters.work_actions > 0
    assert counters.college_enrollments > 0 and counters.studies > 0
    if crime_lives:
        assert counters.crime_attempts > 0
    if addiction_lives:
        assert counters.addiction_bets > 0
    # Every target is printed even when a small tuning cohort misses it; final
    # acceptance is decided from the full 500-life report, not stress coverage.
