"""Deterministic checks for the headless Stage 12 balance measurement logic."""
from __future__ import annotations

from core.config import GameBalance
from core.data_loader import DataLoader
from core.rng import RNG
from tools import measure_balance


class FailedButCaughtRNG(RNG):
    """Force an unsuccessful, caught assault followed by a public-defender conviction."""

    def __init__(self, seed: int | None = None) -> None:
        super().__init__(seed)
        self.rolls = iter((0.99, 0.0, 0.0))

    def random(self) -> float:
        return next(self.rolls)

    def randint(self, a: int, b: int) -> int:
        return a


def test_violent_crime_measurement_counts_conviction_after_failed_attempt(monkeypatch) -> None:
    """Caught failed attempts include custody, lost wages, and record effects in EV."""
    assault = next(
        row for row in DataLoader().load_crimes()["crimes"]
        if row["id"] == "assault"
    )
    monkeypatch.setattr(
        measure_balance.DataLoader,
        "load_crimes",
        lambda self: {"crimes": [assault], "crime_severity_mod": {"default": 1.0, "usa": 1.0}},
    )
    monkeypatch.setattr(measure_balance, "RNG", FailedButCaughtRNG)

    result = measure_balance.crime_expected_values(trials=1, seed=123)
    measured = result["crimes"]["assault"]

    assert measured["observed_success_pct"] == 0.0
    assert measured["observed_arrest_pct"] == 100.0
    assert measured["observed_conviction_pct"] == 100.0
    assert measured["direct_net_ev_cents_per_attempt"] == 0
    assert measured["observed_custody_years_per_attempt"] == 1.0
    assert measured["prison_time_cost_ev_cents_per_attempt"] == GameBalance.CRIME_PRISON_TIME_COST_PER_YEAR_CENTS
    assert measured["lost_wages_ev_cents_per_attempt"] == GameBalance.CRIME_LOST_WAGES_PER_PRISON_YEAR_CENTS
    assert measured["record_effect_ev_cents_per_attempt"] == round(
        GameBalance.CRIME_RECORD_EV_BASE_ANNUAL_WAGE_CENTS
        * GameBalance.CRIME_RECORD_EV_JOB_SEARCH_CHANCE
        * GameBalance.CRIME_RECORD_HIRING_PENALTY_PERCENT / 100
    )
    assert measured["net_ev_after_all_costs_cents_per_attempt"] == -(
        GameBalance.CRIME_PRISON_TIME_COST_PER_YEAR_CENTS
        + GameBalance.CRIME_LOST_WAGES_PER_PRISON_YEAR_CENTS
        + measured["record_effect_ev_cents_per_attempt"]
    )


def test_exact_blackjack_return_is_inside_configured_casino_rtp_range() -> None:
    """The finite six-deck, hit-below-17 policy has a deterministic RTP in range."""
    exact_rtp = measure_balance.exact_blackjack_hit_below_17_rtp()
    assert round(exact_rtp, 6) == 0.943244
    assert 0.90 <= exact_rtp <= 0.97
