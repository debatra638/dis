"""Tests for career eligibility, work actions, pay, and promotions."""
from __future__ import annotations

import json

import pytest

from core.careers import CareerService
from core.config import GameBalance
from core.economy import progressive_income_tax
from core.errors import EducationRequirementError, JobAlreadyExists, NoActiveJob, RetiredCharacter, WorkAlreadyUsed
from core.models import EducationLevel
from core.money import format_cents, scale_cents


async def _save_character(database, character):
    async with database.transaction() as tx:
        await tx.execute(
            "UPDATE characters SET age = ?, stats_json = ?, data_json = ? WHERE char_id = ?",
            (
                character.age,
                json.dumps(character.stats.to_dict(), separators=(",", ":")),
                json.dumps(character.to_dict(), separators=(",", ":")),
                character.char_id,
            ),
        )


@pytest.mark.asyncio
async def test_apply_checks_requirements_and_persists_part_time_job(database, life_engine):
    character = await life_engine.create_character(1301, "Ari")
    service = CareerService(database, life_engine.rng, life_engine.locks, clock=lambda: 1_850_000_000)
    with pytest.raises(EducationRequirementError):
        await service.apply(1301, "teaching")

    character.age = 18
    character.education_level = EducationLevel.HIGH_SCHOOL
    character.stats.smarts = 50
    await _save_character(database, character)

    status = await service.apply(1301, "office_admin", part_time=True)
    assert status.job.level == 1
    assert status.job.is_part_time is True
    assert status.job.salary == scale_cents(
        scale_cents(3_400_000, GameBalance.CAREER_SALARY_BASE_MULTIPLIER), 0.6
    )
    assert status.level_title == "Administrative Assistant"
    with pytest.raises(JobAlreadyExists):
        await service.apply(1301, "retail")


@pytest.mark.asyncio
async def test_work_once_then_age_up_pays_salary(database, life_engine):
    character = await life_engine.create_character(1302, "Morgan")
    character.age = 18
    character.education_level = EducationLevel.HIGH_SCHOOL
    character.stats.smarts = 60
    await _save_character(database, character)

    service = CareerService(database, life_engine.rng, life_engine.locks, clock=lambda: 1_860_000_000)
    status = await service.apply(1302, "retail", part_time=True)
    result = await service.work(1302, "hard")
    assert result.performance_after == min(100, result.performance_before + 12)
    assert result.character.version >= 1
    with pytest.raises(WorkAlreadyUsed):
        await service.work(1302, "normal")

    outcome = await life_engine.age_up(1302)
    assert outcome.new_age == 19
    assert any(f"Earned {format_cents(status.job.salary)}" in message for message in outcome.log_messages)
    # New economy settlements apply progressive tax and mandatory living bills after salary.
    assert outcome.character.cash == 0
    assert outcome.character.bank == 0
    salary_cents = status.job.salary
    annual_tax = progressive_income_tax(salary_cents, price_index=character.price_index)
    assert outcome.character.debt_total == max(
        0,
        GameBalance.BASE_ANNUAL_LIVING_COST_CENTS + annual_tax - salary_cents,
    )
    current_status = await service.status(1302)
    assert current_status.job.years_in_career == 1


@pytest.mark.asyncio
async def test_high_performance_promotion_updates_job_and_history(database, life_engine):
    character = await life_engine.create_character(1303, "Rae")
    character.age = 20
    character.education_level = EducationLevel.HIGH_SCHOOL
    character.stats.smarts = 60
    await _save_character(database, character)

    service = CareerService(database, life_engine.rng, life_engine.locks, clock=lambda: 1_870_000_000)
    await service.apply(1303, "retail")
    async with database.transaction() as tx:
        await tx.execute(
            "UPDATE jobs SET performance = 90, years_in_role = 1 WHERE char_id = ?",
            (character.char_id,),
        )

    outcome = await life_engine.age_up(1303)
    status = await service.status(1303)
    history = await database.fetchone(
        "SELECT max_level FROM career_history WHERE char_id = ? AND end_age IS NULL",
        (character.char_id,),
    )
    assert "Promoted to Shift Supervisor in Retail!" in outcome.log_messages
    assert status.job.level == 2
    assert status.level_title == "Shift Supervisor"
    assert history["max_level"] == 2


@pytest.mark.asyncio
async def test_quit_closes_history_and_status_reports_no_job(database, life_engine):
    character = await life_engine.create_character(1304, "Dev")
    character.age = 18
    character.education_level = EducationLevel.HIGH_SCHOOL
    character.stats.smarts = 50
    await _save_character(database, character)
    service = CareerService(database, life_engine.rng, life_engine.locks)
    await service.apply(1304, "office_admin")

    message = await service.quit(1304)
    assert "quit your job" in message
    with pytest.raises(NoActiveJob):
        await service.status(1304)
    history = await database.fetchone(
        "SELECT end_age, end_reason FROM career_history WHERE char_id = ?",
        (character.char_id,),
    )
    assert history["end_age"] == 18
    assert history["end_reason"] == "quit"
    records = await service.history(1304)
    assert records[0].career_name == "Office Administration"
    assert records[0].end_reason == "quit"


@pytest.mark.asyncio
async def test_manual_retirement_closes_job_and_prevents_new_applications(database, life_engine):
    character = await life_engine.create_character(1305, "Alex")
    character.age = 60
    character.education_level = EducationLevel.HIGH_SCHOOL
    character.stats.smarts = 60
    await _save_character(database, character)
    service = CareerService(database, life_engine.rng, life_engine.locks)
    await service.apply(1305, "office_admin")

    retired = await service.retire(1305)
    assert retired.is_retired is True
    with pytest.raises(NoActiveJob):
        await service.status(1305)
    with pytest.raises(RetiredCharacter):
        await service.apply(1305, "retail")
    records = await service.history(1305)
    assert records[0].end_reason == "retired"
    assert records[0].end_age == 60
