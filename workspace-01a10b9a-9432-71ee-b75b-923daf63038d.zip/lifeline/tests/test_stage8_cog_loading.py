"""File-backed Discord.py extension smoke test for Stage 8 commands."""
from __future__ import annotations

import discord
import pytest
from discord.ext import commands

from core.crime import CrimeService
from core.family import FamilyService
from core.locks import UserLockRegistry
from core.rng import RNG
from core.shop import ShopService


@pytest.mark.asyncio
async def test_shop_cog_loads_and_registers_all_stage8_groups(database):
    """Load the Stage 8 extension against migrated SQLite and inspect its slash groups."""
    bot = commands.Bot(command_prefix="!", intents=discord.Intents.none())
    bot.db = database
    bot.rng = RNG(808)
    bot.locks = UserLockRegistry()
    bot.shop_service = ShopService(database, bot.rng, bot.locks)

    try:
        await bot.load_extension("cogs.shop")
        shop = bot.tree.get_command("shop")
        inventory = bot.tree.get_command("inventory")
        trade = bot.tree.get_command("trade")
        assert shop is not None and {command.name for command in shop.commands} == {"browse", "buy", "ring"}
        assert inventory is not None and {command.name for command in inventory.commands} == {"view", "sell", "use"}
        assert trade is not None and {command.name for command in trade.commands} == {"offer", "list", "cancel"}
    finally:
        await bot.close()


@pytest.mark.asyncio
async def test_all_bot_extensions_load_without_shop_command_collisions(database):
    """Register all production extensions together and preserve the existing ring subcommand."""
    bot = commands.Bot(command_prefix="!", intents=discord.Intents.none())
    bot.db = database
    bot.rng = RNG(809)
    bot.locks = UserLockRegistry()
    bot.family_service = FamilyService(database, bot.rng, bot.locks)
    bot.crime_service = CrimeService(
        database,
        bot.rng,
        bot.locks,
        family_service=bot.family_service,
    )
    bot.shop_service = ShopService(database, bot.rng, bot.locks)
    extensions = (
        "cogs.life",
        "cogs.education",
        "cogs.career",
        "cogs.relationships",
        "cogs.crime",
        "cogs.prison",
        "cogs.shop",
        "cogs.discobot",
    )

    try:
        for extension in extensions:
            await bot.load_extension(extension)
        commands_by_name = {command.name: command for command in bot.tree.get_commands()}
        assert {"life", "relationship", "shop", "inventory", "trade"}.issubset(commands_by_name)
        assert {command.name for command in commands_by_name["shop"].commands} == {"browse", "buy", "ring"}
    finally:
        await bot.close()
