"""Shared fixtures for LIFELINE core tests."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest_asyncio

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.db import DatabaseManager
from core.life_engine import LifeEngine
from core.locks import UserLockRegistry
from core.rng import RNG


@pytest_asyncio.fixture
async def database(tmp_path):
    db = DatabaseManager(str(tmp_path / "lifeline-test.sqlite3"))
    await db.initialize()
    yield db
    await db.close()


@pytest_asyncio.fixture
async def life_engine(database):
    return LifeEngine(
        database,
        RNG(seed=2026),
        locks=UserLockRegistry(),
        clock=lambda: 1_800_000_000,
        event_chance=0.0,
    )
