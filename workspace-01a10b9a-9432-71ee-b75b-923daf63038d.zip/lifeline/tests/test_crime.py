"""Stage 7 crime, criminal-career, tax, and prison regression tests."""
from __future__ import annotations

import json
from dataclasses import replace

import pytest

from core.careers import CareerService
from core.crime import (
    CAREER_RANKS,
    CrimeService,
    calculate_crime_catch_chance,
    calculate_crime_success_chance,
    calculate_job_application_chance,
    calculate_laundering,
)
from core.education import EducationService
from core.errors import (
    CareerApplicationRejected,
    CharacterInPrison,
    CharacterNotInPrison,
    CrimeActionAlreadyUsed,
    CrimeLimitReached,
    FamilyRequirementError,
    PendingEventExists,
    ValidationError,
)
from core.family import FamilyService
from core.models import EducationLevel, HousingType
from core.money import dollars_to_cents
from core.repositories.crime import CrimeRepository
from core.rng import RNG


class FixedRNG:
    """Small injected wrapper for deterministic probability and sentence tests."""

    def __init__(
        self,
        random_values: list[float] | None = None,
        randint_values: list[int] | None = None,
        *,
        default_random: float = 0.99,
        default_randint: str = "low",
    ) -> None:
        self.random_values = list(random_values or [])
        self.randint_values = list(randint_values or [])
        self.default_random = default_random
        self.default_randint = default_randint

    def random(self) -> float:
        return self.random_values.pop(0) if self.random_values else self.default_random

    def randint(self, lower: int, upper: int) -> int:
        if self.randint_values:
            value = self.randint_values.pop(0)
            return max(lower, min(upper, value))
        return lower if self.default_randint == "low" else upper


def _stats_with(**values):
    from core.models import Stats

    return replace(Stats(), **values)


async def _set_character(database, life_engine, character, **changes):
    """Persist selected active-character state through the same version guard as the engine."""
    async with database.transaction() as tx:
        cursor = await tx.execute(
            "SELECT data_json, version FROM characters WHERE char_id = ? AND is_alive = 1",
            (character.char_id,),
        )
        row = await cursor.fetchone()
        current = type(character).from_dict(json.loads(row["data_json"]))
        current.char_id = character.char_id
        current.user_id = character.user_id
        current.version = int(row["version"])
        updated = replace(current, **changes, version=int(row["version"]) + 1)
        await life_engine._save_character(tx, updated, expected_version=int(row["version"]))
        return updated


async def _new_adult(life_engine, database, user_id: int, **changes):
    character = await life_engine.create_character(user_id, f"Test {user_id}")
    return await _set_character(
        database,
        life_engine,
        character,
        age=25,
        education_level=EducationLevel.HIGH_SCHOOL,
        stats=_stats_with(health=100, happiness=80, smarts=70, fitness=60, karma=70),
        **changes,
    )


async def _create_pending_trial(database, service, character, crime_id: str, nonce: str = "test-trial") -> str:
    async with database.transaction() as tx:
        attempt_id = await service.repository.insert_attempt(
            tx,
            char_id=character.char_id,
            crime_id=crime_id,
            age=character.age,
            source="attempt",
            success=True,
            caught=True,
            loot=0,
            success_chance=60.0,
            catch_chance=30.0,
            case_status="pending",
            created_at=1_800_000_000,
        )
        await service.repository.create_trial(tx, character.char_id, attempt_id, nonce, 1_800_000_000)
    return nonce


def test_probability_clamps_and_failed_catch_multiplier():
    assert calculate_crime_success_chance(
        0, smarts=0, fitness=0, luck=-5, success_stat="skill"
    ) == 3
    assert calculate_crime_success_chance(
        100, smarts=100, fitness=100, luck=5, success_stat="physical"
    ) == 97
    assert calculate_crime_catch_chance(1, notoriety=0, criminal_record=0) == 3
    assert calculate_crime_catch_chance(
        90, notoriety=100, criminal_record=10, failed_attempt=True
    ) == 97


def test_hiring_probability_includes_record_and_decaying_release_penalty():
    assert calculate_job_application_chance(0, age=40, last_release_age=None) == 100
    assert calculate_job_application_chance(1, age=40, last_release_age=None) == 80
    assert calculate_job_application_chance(1, age=40, last_release_age=40) == 60
    assert calculate_job_application_chance(1, age=50, last_release_age=40) == 80


@pytest.mark.asyncio
async def test_crime_attempts_are_capped_at_two_per_age(database, life_engine):
    character = await _new_adult(life_engine, database, 7101)
    service = life_engine.crimes
    service.rng = FixedRNG(random_values=[0.0, 0.99, 0.0, 0.99])
    for _ in range(2):
        preview = await service.preview_crime(character.user_id, "shoplift")
        outcome = await service.confirm_crime(character.user_id, preview.nonce)
        assert not outcome.caught
    third = await service.preview_crime(character.user_id, "shoplift")
    with pytest.raises(CrimeLimitReached):
        await service.confirm_crime(character.user_id, third.nonce)
    rows = await database.fetchall(
        "SELECT attempt_id FROM crime_attempts WHERE char_id = ? AND age = ? AND source = 'attempt'",
        (character.char_id, character.age),
    )
    assert len(rows) == 2


@pytest.mark.asyncio
async def test_crime_preview_shows_price_scaled_integer_cent_proceeds(database, life_engine):
    character = await _new_adult(life_engine, database, 7102, price_index=2.5)
    preview = await life_engine.crimes.preview_crime(character.user_id, "shoplift")
    assert preview.loot_min == dollars_to_cents(20 * 2.5)
    assert preview.loot_max == dollars_to_cents(300 * 2.5)
    assert preview.failed_catch_chance >= preview.catch_chance


@pytest.mark.asyncio
async def test_criminal_record_reduces_actual_job_offer_chance(database, life_engine):
    character = await _new_adult(life_engine, database, 7103, criminal_record=1)
    career_service = CareerService(database, RNG(3), life_engine.locks)
    career_service.hiring_rng = FixedRNG(random_values=[0.90])
    with pytest.raises(CareerApplicationRejected):
        await career_service.apply(character.user_id, "retail")

    await _set_character(database, life_engine, character, criminal_record=0)
    career_service.hiring_rng = FixedRNG(random_values=[0.90])
    status = await career_service.apply(character.user_id, "retail")
    assert status.job.career_id == "retail"


@pytest.mark.asyncio
async def test_prison_service_and_existing_actions_enforce_custody_gates(database, life_engine):
    character = await _new_adult(life_engine, database, 7104)
    service = life_engine.crimes
    with pytest.raises(CharacterNotInPrison):
        await service.prison_action(character.user_id, "study")

    imprisoned = await _set_character(
        database,
        life_engine,
        character,
        in_prison=True,
        prison_years_left=3,
        housing_type=HousingType.HOMELESS,
    )
    with pytest.raises(CharacterInPrison):
        await service.preview_crime(imprisoned.user_id, "shoplift")

    family = FamilyService(database, life_engine.rng, life_engine.locks)
    with pytest.raises(FamilyRequirementError):
        await family.find_dates(imprisoned.user_id)
    career = CareerService(database, RNG(4), life_engine.locks)
    with pytest.raises(CharacterInPrison):
        await career.apply(imprisoned.user_id, "retail")
    education = EducationService(database, life_engine.locks)
    with pytest.raises(CharacterInPrison):
        await education.study(imprisoned.user_id)

    service.rng = FixedRNG(random_values=[0.99])
    await service.prison_action(imprisoned.user_id, "behave")
    with pytest.raises(CrimeActionAlreadyUsed):
        await service.prison_action(imprisoned.user_id, "workout")


@pytest.mark.asyncio
async def test_prison_sentence_counts_down_and_releases_on_annual_age(database, life_engine):
    character = await _new_adult(life_engine, database, 7105)
    character = await _set_character(
        database,
        life_engine,
        character,
        age=30,
        in_prison=True,
        prison_years_left=2,
        housing_type=HousingType.HOMELESS,
    )
    life_engine.crimes.rng = FixedRNG(default_random=0.99)
    first = await life_engine.age_up(character.user_id)
    assert first.character.in_prison
    assert first.character.prison_years_left == 1
    second = await life_engine.age_up(character.user_id)
    assert second.character.age == 32
    assert not second.character.in_prison
    assert second.character.prison_years_left == 0


@pytest.mark.asyncio
async def test_juvenile_sentence_is_halved_sealed_and_released_at_eighteen(database, life_engine):
    character = await _new_adult(life_engine, database, 7106)
    character = await _set_character(database, life_engine, character, age=17)
    service = life_engine.crimes
    service.rng = FixedRNG(random_values=[0.0, 0.10], randint_values=[4, 10, 10, 10])
    nonce = await _create_pending_trial(database, service, character, "burglary", "juvenile-case")
    resolution = await service.resolve_trial(character.user_id, nonce, "public")
    assert resolution.convicted
    assert resolution.sentence_years == 2
    assert resolution.record_sealed
    assert resolution.character.criminal_record == 0
    assert resolution.character.in_prison
    assert resolution.character.prison_years_left == 1
    status = await service.prison_status(character.user_id)
    assert status.juvenile_release_age == 18

    service.rng = FixedRNG(default_random=0.99)
    aged = await life_engine.age_up(character.user_id)
    assert aged.character.age == 18
    assert not aged.character.in_prison


@pytest.mark.asyncio
async def test_seeded_lawyer_conviction_rates_match_tiers(database, life_engine):
    character = await _new_adult(
        life_engine, database, 7107, cash=dollars_to_cents(20_000_000)
    )
    service = life_engine.crimes
    service.rng = RNG(202607)
    observed: dict[str, float] = {}
    trials_per_tier = 120
    for tier, target in (("public", 0.85), ("standard", 0.65), ("elite", 0.40)):
        convictions = 0
        for index in range(trials_per_tier):
            nonce = f"rate-{tier}-{index}"
            await _create_pending_trial(database, service, character, "vandalism", nonce)
            result = await service.resolve_trial(character.user_id, nonce, tier)
            convictions += int(result.convicted)
            character = result.character
        rate = convictions / trials_per_tier
        observed[tier] = rate
        assert abs(rate - target) < 0.10
    assert set(observed) == {"public", "standard", "elite"}


@pytest.mark.asyncio
async def test_laundering_fee_and_annual_cap(database, life_engine):
    character = await _new_adult(life_engine, database, 7108, cash=dollars_to_cents(100_000))
    async with database.transaction() as tx:
        await life_engine.crimes.repository.update_profile(
            tx, character.char_id, dirty_cash=dollars_to_cents(100_000)
        )
    fee, net = calculate_laundering(dollars_to_cents(50_000))
    assert fee == dollars_to_cents(12_500)
    assert net == dollars_to_cents(37_500)
    result = await life_engine.crimes.launder(character.user_id, 50_000)
    assert (result.gross_amount, result.fee_amount, result.net_amount) == (
        dollars_to_cents(50_000), dollars_to_cents(12_500), dollars_to_cents(37_500)
    )
    with pytest.raises(ValidationError):
        await life_engine.crimes.launder(character.user_id, 1)
    updated = await life_engine.get_active_character(character.user_id)
    assert updated.cash == dollars_to_cents(50_000)
    assert updated.bank == dollars_to_cents(37_500)
    profile = await life_engine.crimes.repository.read_profile(character.char_id)
    assert profile["dirty_cash"] == dollars_to_cents(50_000)


@pytest.mark.asyncio
async def test_front_business_removes_the_laundering_cap(database, life_engine):
    character = await _new_adult(life_engine, database, 7109, cash=dollars_to_cents(100_000))
    async with database.transaction() as tx:
        await life_engine.crimes.repository.update_profile(
            tx, character.char_id, dirty_cash=dollars_to_cents(100_000)
        )
        await life_engine.crimes.repository.grant_front_business(tx, character.char_id, character.age, 1)
    result = await life_engine.crimes.launder(character.user_id, 75_000)
    assert result.gross_amount == dollars_to_cents(75_000)
    assert result.annual_limit == 0


@pytest.mark.asyncio
async def test_escape_success_and_failure_outcomes(database, life_engine):
    character = await _new_adult(life_engine, database, 7110)
    await _set_character(database, life_engine, character, in_prison=True, prison_years_left=4)
    life_engine.crimes.rng = FixedRNG(random_values=[0.0])
    escaped = await life_engine.crimes.prison_action(character.user_id, "escape")
    assert not escaped.character.in_prison
    assert escaped.character.notoriety >= 40
    profile = await life_engine.crimes.repository.read_profile(character.char_id)
    assert profile["escaped"] == 1

    another = await _new_adult(life_engine, database, 7111)
    await _set_character(database, life_engine, another, age=26, in_prison=True, prison_years_left=4)
    life_engine.crimes.rng = FixedRNG(random_values=[0.99], randint_values=[3])
    failed = await life_engine.crimes.prison_action(another.user_id, "escape")
    assert failed.character.in_prison
    assert failed.character.prison_years_left == 7


@pytest.mark.asyncio
async def test_trial_transaction_rolls_back_all_verdict_writes(database, life_engine):
    character = await _new_adult(life_engine, database, 7112)
    service = life_engine.crimes
    nonce = await _create_pending_trial(database, service, character, "vandalism", "rollback-case")
    underlying = service.repository

    class FailingCrimeRepository(CrimeRepository):
        async def complete_trial(self, tx, **kwargs):
            await super().complete_trial(tx, **kwargs)
            raise RuntimeError("injected after trial writes")

    service.repository = FailingCrimeRepository(database)
    with pytest.raises(RuntimeError, match="injected"):
        await service.resolve_trial(character.user_id, nonce, "public")
    service.repository = underlying

    trial = await database.fetchone("SELECT nonce FROM crime_trials WHERE char_id = ?", (character.char_id,))
    case = await database.fetchone(
        "SELECT case_status FROM crime_attempts WHERE char_id = ? ORDER BY attempt_id DESC LIMIT 1",
        (character.char_id,),
    )
    current = await life_engine.get_active_character(character.user_id)
    assert trial is not None and trial["nonce"] == nonce
    assert case["case_status"] == "pending"
    assert current.version == character.version
    assert current.criminal_record == 0


@pytest.mark.asyncio
async def test_fines_never_make_cash_or_dirty_proceeds_negative(database, life_engine):
    character = await _new_adult(life_engine, database, 7113, cash=1, bank=0)
    async with database.transaction() as tx:
        await life_engine.crimes.repository.update_profile(
            tx, character.char_id, dirty_cash=dollars_to_cents(20_000)
        )
        attempt_id = await life_engine.crimes.repository.insert_attempt(
            tx,
            char_id=character.char_id,
            crime_id="shoplift",
            age=character.age,
            source="attempt",
            success=True,
            caught=True,
            loot=dollars_to_cents(10_000),
            success_chance=70.0,
            catch_chance=30.0,
            case_status="pending",
            created_at=1_800_000_000,
        )
        await life_engine.crimes.repository.create_trial(tx, character.char_id, attempt_id, "fine-case", 1_800_000_000)
    life_engine.crimes.rng = FixedRNG(random_values=[0.0])
    result = await life_engine.crimes.resolve_trial(character.user_id, "fine-case", "public")
    assert result.fine_paid <= 1
    assert result.character.cash >= 0
    assert result.character.bank >= 0
    profile = await life_engine.crimes.repository.read_profile(character.char_id)
    assert profile["dirty_cash"] >= 0


@pytest.mark.asyncio
async def test_high_earner_tax_choice_and_double_back_tax_audit(database, life_engine):
    character = await _new_adult(life_engine, database, 7114, cash=dollars_to_cents(200_000))
    service = life_engine.crimes
    service.rng = FixedRNG(random_values=[0.99])
    async with database.transaction() as tx:
        year = await service.advance_year(
            tx,
            character,
            previous_age=character.age - 1,
            personal_income=dollars_to_cents(200_000),
            household_income=dollars_to_cents(200_000),
            tax_assessed=0,
            tax_paid=0,
            now=1_800_000_000,
        )
    assert year.pending_tax is not None
    prompt = year.pending_tax
    choice = await service.resolve_tax_choice(character.user_id, prompt.nonce, "evade_50")
    assert choice.evaded_amount == prompt.tax_due // 2
    profile = await service.repository.read_profile(character.char_id)
    assert profile["evaded_tax"] == choice.evaded_amount

    # Force the following year's audit to catch the stored evasion; the 30% prison roll misses.
    service.rng = FixedRNG(random_values=[0.0, 0.99])
    current = await life_engine.get_active_character(character.user_id)
    async with database.transaction() as tx:
        audited = await service.advance_year(
            tx,
            current,
            previous_age=current.age,
            personal_income=0,
            household_income=0,
            tax_assessed=0,
            tax_paid=0,
            now=1_800_000_001,
        )
    audit = await database.fetchone(
        "SELECT back_taxes, triggered, tax_evasion_found FROM crime_audits WHERE char_id = ? ORDER BY audit_id DESC LIMIT 1",
        (character.char_id,),
    )
    assert audit["triggered"] == 1
    assert audit["tax_evasion_found"] == 1
    assert audit["back_taxes"] == choice.evaded_amount * 2
    assert not audited.character.in_prison


@pytest.mark.asyncio
async def test_stage7_pending_decisions_block_annual_aging(database, life_engine):
    character = await _new_adult(life_engine, database, 7115)
    preview = await life_engine.crimes.preview_crime(character.user_id, "shoplift")
    with pytest.raises(PendingEventExists):
        await life_engine.age_up(character.user_id)
    await life_engine.crimes.cancel_preview(character.user_id, preview.nonce)


@pytest.mark.asyncio
async def test_prison_pauses_wages_and_ordinary_bills_but_pays_only_loans(database, life_engine):
    character = await _new_adult(
        life_engine, database, 7116, cash=dollars_to_cents(1_000)
    )
    career = CareerService(database, RNG(5), life_engine.locks)
    await career.apply(character.user_id, "retail")
    character = await _set_character(
        database, life_engine, character, in_prison=True, prison_years_left=3
    )
    async with database.transaction() as tx:
        await tx.execute(
            "INSERT INTO loans(char_id, balance, annual_payment) VALUES (?, ?, ?)",
            (character.char_id, dollars_to_cents(100), dollars_to_cents(50)),
        )
    life_engine.crimes.rng = FixedRNG(default_random=0.99)
    outcome = await life_engine.age_up(character.user_id)
    assert outcome.character.cash == dollars_to_cents(950)
    loan = await database.fetchone(
        "SELECT balance, missed_payments FROM loans WHERE char_id = ?", (character.char_id,)
    )
    assert loan["balance"] == dollars_to_cents(50)
    assert loan["missed_payments"] == 0


def test_criminal_career_ranks_reach_kingpin():
    assert CAREER_RANKS[0][0] == "Street Dealer"
    assert CAREER_RANKS[-1][0] == "Kingpin"


@pytest.mark.asyncio
async def test_criminal_career_pays_dirty_income_and_can_roll_a_yearly_arrest(database, life_engine):
    character = await _new_adult(life_engine, database, 7117)
    service = life_engine.crimes
    service.rng = FixedRNG(random_values=[0.0, 0.99])
    preview = await service.preview_crime(character.user_id, "shoplift")
    attempt = await service.confirm_crime(character.user_id, preview.nonce)
    assert attempt.success and not attempt.caught
    after_attempt = await life_engine.get_active_character(character.user_id)
    cash_before_year = after_attempt.cash

    service.rng = FixedRNG(default_random=0.99)
    async with database.transaction() as tx:
        paid = await service.advance_year(
            tx,
            after_attempt,
            previous_age=after_attempt.age - 1,
            personal_income=0,
            household_income=0,
            tax_assessed=0,
            tax_paid=0,
            now=1_800_000_000,
        )
    assert paid.character.cash - cash_before_year == CAREER_RANKS[0][2]
    profile = await service.repository.read_profile(character.char_id)
    assert profile["career_rank"] == "Street Dealer"
    assert profile["career_years"] == 1
    assert profile["dirty_cash"] >= CAREER_RANKS[0][2]

    # A second yearly roll at the Street Dealer tier uses the 8% base arrest chance.
    service.rng = FixedRNG(random_values=[0.99, 0.0])
    async with database.transaction() as tx:
        arrested = await service.advance_year(
            tx,
            paid.character,
            previous_age=paid.character.age,
            personal_income=0,
            household_income=0,
            tax_assessed=0,
            tax_paid=0,
            now=1_800_000_001,
        )
    assert arrested.pending_trial is not None
    assert arrested.pending_trial.source == "career_arrest"
    assert CrimeService._career_level(95) == len(CAREER_RANKS) - 1


@pytest.mark.asyncio
async def test_conviction_fires_job_loses_rent_and_keeps_possessions(database, life_engine):
    character = await _new_adult(
        life_engine,
        database,
        7118,
        cash=dollars_to_cents(1_000),
        housing_type=HousingType.RENT,
        rent_amount=dollars_to_cents(1_200),
    )
    career = CareerService(database, RNG(6), life_engine.locks)
    await career.apply(character.user_id, "retail")
    async with database.transaction() as tx:
        await tx.execute(
            """INSERT INTO family_assets
                   (char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at)
               VALUES (?, 'item', 'heirloom_ring', 1, 10000, 10000, ?, 1)""",
            (character.char_id, character.age),
        )
    before = await database.fetchall(
        "SELECT npc_id, score FROM relationships WHERE char_id = ?", (character.char_id,)
    )
    nonce = await _create_pending_trial(database, life_engine.crimes, character, "burglary", "prison-job-case")
    life_engine.crimes.rng = FixedRNG(random_values=[0.0], randint_values=[1, 10, 10, 10])
    result = await life_engine.crimes.resolve_trial(character.user_id, nonce, "public")
    assert result.character.in_prison
    assert result.character.housing_type is HousingType.HOMELESS
    assert result.character.housing_item_id is None
    job = await database.fetchone("SELECT 1 FROM jobs WHERE char_id = ?", (character.char_id,))
    history = await database.fetchone(
        "SELECT end_reason FROM career_history WHERE char_id = ? ORDER BY id DESC LIMIT 1",
        (character.char_id,),
    )
    asset = await database.fetchone("SELECT item_id FROM family_assets WHERE char_id = ?", (character.char_id,))
    assert job is None
    assert history["end_reason"] == "prison"
    assert asset["item_id"] == "heirloom_ring"
    after = await database.fetchall(
        "SELECT npc_id, score FROM relationships WHERE char_id = ?", (character.char_id,)
    )
    before_scores = {int(row["npc_id"]): int(row["score"]) for row in before}
    assert all(int(row["score"]) <= before_scores[int(row["npc_id"])] for row in after)


@pytest.mark.asyncio
async def test_tax_audit_sentence_is_recorded_without_a_trial(database, life_engine):
    character = await _new_adult(life_engine, database, 7119, cash=dollars_to_cents(100_000))
    service = life_engine.crimes
    async with database.transaction() as tx:
        await service.repository.update_profile(tx, character.char_id, evaded_tax=dollars_to_cents(1_000))
    service.rng = FixedRNG(random_values=[0.0, 0.0], randint_values=[2])
    async with database.transaction() as tx:
        result = await service.advance_year(
            tx,
            character,
            previous_age=character.age - 1,
            personal_income=0,
            household_income=0,
            tax_assessed=0,
            tax_paid=0,
            now=1_800_000_000,
        )
    assert result.character.in_prison
    assert result.character.prison_years_left == 2
    audit = await database.fetchone(
        "SELECT sentence_years, back_taxes FROM crime_audits WHERE char_id = ? ORDER BY audit_id DESC LIMIT 1",
        (character.char_id,),
    )
    attempt = await database.fetchone(
        "SELECT case_status, sentence_years, source FROM crime_attempts WHERE char_id = ? ORDER BY attempt_id DESC LIMIT 1",
        (character.char_id,),
    )
    assert audit["sentence_years"] == 2
    assert audit["back_taxes"] == dollars_to_cents(2_000)
    assert attempt["case_status"] == "convicted"
    assert attempt["sentence_years"] == 2
    assert attempt["source"] == "tax_audit"


def test_crime_catalog_is_loaded_and_event_only_tax_is_validated():
    from core.data_loader import DataLoader
    from core.validators import DataValidationError, validate_crime_catalog

    catalog = DataLoader().load_crimes()
    assert len(catalog["crimes"]) >= 14
    tax = next(item for item in catalog["crimes"] if item["id"] == "tax_evasion")
    assert tax["commit_enabled"] is False
    broken = json.loads(json.dumps(catalog))
    broken["crimes"].pop()
    with pytest.raises(DataValidationError):
        validate_crime_catalog(broken)
