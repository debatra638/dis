"""Headless Discord.py registration smoke test for the complete command surface."""
from __future__ import annotations

import discord
import pytest
from discord.ext import commands

from core.config import Config
from cogs.help import build_help_pages

from core.achievements import AchievementService
from core.casino import CasinoService
from core.crime import CrimeService
from core.family import FamilyService
from core.economy import EconomyService
from core.investing import InvestingService
from core.locks import UserLockRegistry
from core.rng import RNG
from core.shop import ShopService


@pytest.mark.asyncio
async def test_stage10_extensions_register_all_legacy_commands(database):
    """Load all Stage 1–10 cogs with no privileged member intent and inspect commands."""
    bot = commands.Bot(
        command_prefix="!",
        intents=discord.Intents.none(),
        allowed_mentions=discord.AllowedMentions.none(),
    )
    bot.config = Config(token="", owner_ids=frozenset({1}))
    bot.db = database
    bot.rng = RNG(seed=1010)
    bot.locks = UserLockRegistry()
    bot.economy_service = EconomyService(database, bot.rng, bot.locks, clock=lambda: 1_800_000_000)
    bot.achievement_service = AchievementService(database, bot.locks, clock=lambda: 1_800_000_000)
    assert len(bot.achievement_service.definitions) >= 60
    achievement_names = {row["name"] for row in bot.achievement_service.definitions}
    assert {
        "First Steps", "Graduate", "Doctorate", "Millionaire", "Billionaire",
        "Rags to Riches", "Centenarian", "Married 50 Years", "Big Family", "Jailbird",
        "Kingpin", "Great Escape", "High Roller", "Jackpot", "Bankrupt", "Serial Divorcé",
        "Straight-A Student", "CEO", "Famous", "Lifelong Learner", "Dynasty", "Died Young",
        "Clean Record Centenarian",
    }.issubset(achievement_names)
    assert {
        "education", "career", "family", "wealth", "hardship", "recovery",
        "crime", "longevity", "completion",
    }.issubset({row["category"] for row in bot.achievement_service.definitions})
    bot.family_service = FamilyService(database, bot.rng, bot.locks)
    bot.crime_service = CrimeService(
        database, bot.rng, bot.locks, family_service=bot.family_service
    )
    bot.shop_service = ShopService(database, bot.rng, bot.locks)
    bot.casino_service = CasinoService(database, bot.rng, bot.locks, clock=lambda: 1_800_000_000)
    bot.investing_service = InvestingService(database, bot.rng, bot.locks, clock=lambda: 1_800_000_000)

    async def ready() -> None:
        """Satisfy background-loop setup without connecting to Discord."""
        return None

    bot.wait_until_ready = ready
    await bot.investing_service.initialize_market()
    extensions = (
        "cogs.life",
        "cogs.health",
        "cogs.economy",
        "cogs.education",
        "cogs.career",
        "cogs.relationships",
        "cogs.crime",
        "cogs.prison",
        "cogs.shop",
        "cogs.casino",
        "cogs.invest",
        "cogs.discobot",
        "cogs.legacy",
        "cogs.settings",
        "cogs.admin",
        "cogs.help",
    )
    try:
        for extension in extensions:
            await bot.load_extension(extension)
        commands_by_name = {command.name: command for command in bot.tree.get_commands()}
        assert {
            "life", "start", "leaderboard", "achievements", "lives", "graveyard",
            "inheritance", "retire_life", "leaderboard_privacy", "guild_death_summaries",
            "family", "relationship", "date", "friends", "crime", "shop", "inventory",
            "trade", "casino", "invest", "education", "career", "prison", "settings",
            "admin", "help", "health", "doctor", "hospital", "therapy", "insurance",
            "bank", "loan", "finance", "economy", "coinflip", "randomuser",
        }.issubset(commands_by_name)
        assert {command.name for command in commands_by_name["life"].commands} == {
            "start", "status", "age", "choice"
        }
        assert {command.name for command in commands_by_name["lives"].commands} == {"list", "view"}
        assert {command.name for command in commands_by_name["casino"].commands} == {
            "slots", "blackjack", "roulette", "coinflip", "compulsion"
        }
        assert {command.name for command in commands_by_name["invest"].commands} == {
            "market", "buy", "sell", "portfolio", "history", "bonds"
        }
        assert {command.name for command in commands_by_name["settings"].commands} == {
            "privacy", "leaderboard"
        }
        assert {command.name for command in commands_by_name["health"].commands} == {
            "status", "doctor", "hospital", "therapy", "activity", "insurance", "surgery"
        }
        surgery_command = next(
            command for command in commands_by_name["health"].commands if command.name == "surgery"
        )
        surgery_parameters = {parameter.name: parameter for parameter in surgery_command.parameters}
        assert surgery_parameters["condition_id"].required is False
        assert surgery_parameters["procedure"].required is False
        assert {choice.value for choice in surgery_parameters["procedure"].choices} == {
            "medical", "plastic"
        }
        assert {command.name for command in commands_by_name["bank"].commands} == {
            "status", "deposit", "withdraw"
        }
        assert {command.name for command in commands_by_name["loan"].commands} == {"list", "apply", "pay"}
        assert {command.name for command in commands_by_name["finance"].commands} == {"status", "bankruptcy"}
        assert {command.name for command in commands_by_name["economy"].commands} == {
            "status", "lifestyle", "housing"
        }
        assert {command.name for command in commands_by_name["admin"].commands} == {
            "give_money", "set_stat", "kill", "reset_player", "ban", "unban",
            "market_event", "reload_data", "audit", "sync",
        }
        assert commands_by_name["leaderboard"].description
        assert commands_by_name["achievements"].description

        def leaf_names(items):
            """Return each registered callable's full slash-command path."""
            found = set()
            for item in items:
                children = getattr(item, "commands", None)
                if children:
                    found.update(leaf_names(children))
                else:
                    found.add(item.qualified_name)
            return found

        expected = {
            "life start", "life status", "life age", "life choice",
            "health status", "health doctor", "health hospital", "health therapy",
            "health activity", "health insurance", "health surgery",
            "doctor", "hospital", "therapy", "insurance",
            "bank status", "bank deposit", "bank withdraw",
            "loan list", "loan apply", "loan pay",
            "finance status", "finance bankruptcy",
            "economy status", "economy lifestyle", "economy housing",
            "education status", "education study", "education enroll",
            "career list", "career apply", "career status", "career history",
            "career work", "career quit", "career retire",
            "family", "relationship list", "relationship interact", "relationship propose",
            "relationship marry", "relationship divorce", "relationship breakup",
            "relationship try_for_baby", "relationship adopt", "relationship temptation",
            "date find", "friends find",
            "crime list", "crime commit", "crime launder", "crime record",
            "prison status", "prison action",
            "shop browse", "shop buy", "shop ring", "inventory view", "inventory sell",
            "inventory use", "trade offer", "trade list", "trade cancel",
            "casino slots", "casino blackjack", "casino roulette", "casino coinflip",
            "casino compulsion",
            "invest market", "invest buy", "invest sell", "invest portfolio",
            "invest history", "invest bonds buy",
            "leaderboard", "achievements", "lives list", "lives view", "graveyard",
            "inheritance", "retire_life", "start", "leaderboard_privacy",
            "guild_death_summaries",
            "settings privacy", "settings leaderboard",
            "admin give_money", "admin set_stat", "admin kill", "admin reset_player",
            "admin ban", "admin unban", "admin market_event", "admin reload_data",
            "admin audit", "admin sync", "help",
            "coinflip", "roll", "bet", "8ball", "trivia", "rps", "slots", "random",
            "choose", "ship", "fact", "joke", "randomuser", "poll", "rate",
            "compliment", "roast", "hug",
        }
        actual = leaf_names(bot.tree.get_commands())
        assert actual == expected
        assert all(command.description for command in _leaf_commands(bot.tree.get_commands()))
        pages = build_help_pages(bot)
        help_text = "\n".join(entry for category_pages in pages.values() for page in category_pages for entry in page)
        assert all(f"/{name}" in help_text for name in expected)
    finally:
        await bot.close()


def _leaf_commands(items):
    """Yield every registered slash command below root command groups."""
    for item in items:
        children = getattr(item, "commands", None)
        if children:
            yield from _leaf_commands(children)
        else:
            yield item
