"""Tests for school progression, enrollment, and yearly study actions."""
from __future__ import annotations

import json
from dataclasses import replace

import pytest

from core.education import EducationService, advance_school_year
from core.errors import EducationRequirementError, NotEnrolled, StudyAlreadyUsed
from core.models import Character, EducationLevel, StudyEffort


def test_primary_and_high_school_progression():
    character = Character(name="Alex", age=5)
    current = advance_school_year(replace(character, age=6)).character
    assert current.school_program is EducationLevel.PRIMARY
    assert current.current_school == "Primary School"
    assert current.school_years_left == 7

    for age in range(7, 13):
        current = advance_school_year(replace(current, age=age)).character
        assert current.school_program is EducationLevel.PRIMARY
        assert current.school_years_left == 13 - age

    completed_primary = advance_school_year(replace(current, age=13))
    current = completed_primary.character
    assert "Completed primary school." in completed_primary.messages
    assert current.education_level is EducationLevel.PRIMARY
    assert current.school_program is EducationLevel.HIGH_SCHOOL
    assert current.school_years_left == 5

    for age in range(14, 18):
        current = advance_school_year(replace(current, age=age)).character
        assert current.school_program is EducationLevel.HIGH_SCHOOL
        assert current.school_years_left == 18 - age

    graduation = advance_school_year(replace(current, age=18))
    assert graduation.character.education_level is EducationLevel.HIGH_SCHOOL
    assert graduation.character.school_program is None
    assert graduation.character.school_years_left == 0
    assert graduation.messages == ("Graduated from high school.",)


def test_college_program_graduates_after_remaining_years():
    character = Character(
        name="Sam",
        age=21,
        education_level=EducationLevel.BACHELOR,
        current_school="University",
        school_program=EducationLevel.MASTER,
        school_years_left=1,
        gpa=3.2,
        major="History",
    )
    result = advance_school_year(replace(character, age=22))
    assert result.character.education_level is EducationLevel.MASTER
    assert result.character.school_program is None
    assert result.character.current_school is None
    assert result.character.school_years_left == 0
    assert "Master" in result.messages[0]


@pytest.mark.asyncio
async def test_study_effects_and_once_per_age_limit(database, life_engine):
    character = await life_engine.create_character(1201, "Casey")
    character.age = 10
    character.current_school = "Primary School"
    character.school_program = EducationLevel.PRIMARY
    character.school_years_left = 3
    character.gpa = 2.5
    async with database.transaction() as tx:
        await tx.execute(
            "UPDATE characters SET age = ?, data_json = ? WHERE char_id = ?",
            (character.age, json.dumps(character.to_dict()), character.char_id),
        )

    service = EducationService(database, life_engine.locks, clock=lambda: 1_840_000_000)
    result = await service.study(1201, StudyEffort.HARD)
    assert result.gpa_before == 2.5
    assert result.gpa_after == 2.8
    assert result.character.stats.smarts >= character.stats.smarts
    assert result.character.stats.stress >= character.stats.stress
    with pytest.raises(StudyAlreadyUsed):
        await service.study(1201, "normal")

    actions = await database.fetchall(
        "SELECT age, effort, gpa_after FROM education_actions WHERE char_id = ?",
        (character.char_id,),
    )
    assert len(actions) == 1
    assert actions[0]["effort"] == "hard"


@pytest.mark.asyncio
async def test_enroll_requires_age_and_prerequisite(database, life_engine):
    character = await life_engine.create_character(1202, "Robin")
    service = EducationService(database, life_engine.locks)
    with pytest.raises(EducationRequirementError):
        await service.enroll(1202, "bachelor", "Biology")

    character.age = 18
    character.education_level = EducationLevel.HIGH_SCHOOL
    character.gpa = 3.1
    async with database.transaction() as tx:
        await tx.execute(
            "UPDATE characters SET age = ?, data_json = ? WHERE char_id = ?",
            (character.age, json.dumps(character.to_dict()), character.char_id),
        )

    enrolled = await service.enroll(1202, "bachelor", "  Computer   Science ")
    assert enrolled.current_school == "University"
    assert enrolled.school_program is EducationLevel.BACHELOR
    assert enrolled.school_years_left == 4
    assert enrolled.major == "Computer Science"
    assert enrolled.gpa == 2.5


@pytest.mark.asyncio
async def test_age_up_starts_primary_school_at_six(database, life_engine):
    character = await life_engine.create_character(1203, "Jamie")
    character.age = 5
    async with database.transaction() as tx:
        await tx.execute(
            "UPDATE characters SET age = ?, data_json = ? WHERE char_id = ?",
            (character.age, json.dumps(character.to_dict()), character.char_id),
        )

    outcome = await life_engine.age_up(1203)
    assert outcome.character.age == 6
    assert outcome.character.school_program is EducationLevel.PRIMARY
    assert outcome.character.school_years_left == 7
    assert "Started primary school." in outcome.log_messages


@pytest.mark.asyncio
async def test_study_requires_current_enrollment(life_engine):
    service = EducationService(life_engine.db, life_engine.locks)
    await life_engine.create_character(1204, "Jordan")
    with pytest.raises(NotEnrolled):
        await service.study(1204)
