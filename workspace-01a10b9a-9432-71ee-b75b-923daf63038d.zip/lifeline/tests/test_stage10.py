"""Integration coverage for Stage 10 scoring, death, estates, achievements, and rankings."""
from __future__ import annotations

import json
from dataclasses import replace
from typing import Any

import aiosqlite
import pytest

from core.death import (
    calculate_estate_settlement,
    calculate_life_score,
    grade_for_life_score,
    legacy_points_for_score,
    select_epitaph,
)
from core.errors import InsufficientFunds, ValidationError
from core.leaderboard import LeaderboardService
from core.money import dollars_to_cents
from core.repositories.legacy import LegacyRepository
from core.rng import RNG
from core.life_engine import LifeEngine
from core.locks import UserLockRegistry
from cogs.legacy_views import EmbedPager, leaderboard_embed


async def _make_dead_life(
    engine: LifeEngine,
    user_id: int,
    *,
    age: int = 40,
    cash_cents: int = 0,
    bank_cents: int = 0,
    debt_cents: int = 0,
    price_index: float = 1.0,
    happiness: int = 70,
    cause: str = "natural causes",
    now: int = 1_800_000_000,
    guild_id: int | None = None,
) -> tuple[Any, Any]:
    """Create and atomically archive one persisted terminal character."""
    character = await engine.create_character(user_id, f"Life {user_id}")
    dead = replace(
        character,
        is_alive=False,
        age=age,
        cash=cash_cents,
        bank=bank_cents,
        debt_total=debt_cents,
        price_index=price_index,
        stats=replace(character.stats, happiness=happiness),
        death_cause=cause,
        death_age=age,
        died_at=now,
        last_age_at=now,
        version=character.version + 1,
    )
    async with engine.db.transaction() as tx:
        await engine._save_character(tx, dead, expected_version=character.version)
        result = await engine.death.handle_death(
            tx, dead, now=now, guild_id=guild_id
        )
    return dead, result


async def _insert_child(
    engine: LifeEngine,
    parent_char_id: int,
    *,
    name: str,
    age: int,
    health: int,
    smarts: int,
    looks: int,
    wealth_cents: int,
    gender: str = "female",
    country: str = "usa",
) -> int:
    """Insert one authoritative child NPC for estate-continuation tests."""
    async with engine.db.transaction() as tx:
        cursor = await tx.execute(
            """INSERT INTO npcs
                   (owner_char_id, name, gender, age, looks, smarts, health, wealth,
                    occupation, is_alive, country, annual_income, prefers_smarts)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Student', 1, ?, 0, 0)""",
            (parent_char_id, name, gender, age, looks, smarts, health, wealth_cents, country),
        )
        npc_id = int(cursor.lastrowid)
        await tx.execute(
            "INSERT INTO children(npc_id, char_id, custody, child_support) VALUES (?, ?, 'full', 0)",
            (npc_id, parent_char_id),
        )
    return npc_id


async def _set_character_age(engine: LifeEngine, user_id: int, age: int) -> Any:
    """Change an active character's authoritative persisted age for ranking checks."""
    character = await engine.get_active_character(user_id)
    updated = replace(character, age=age, version=character.version + 1)
    async with engine.db.transaction() as tx:
        await engine._save_character(tx, updated, expected_version=character.version)
    return updated


def test_life_score_examples_grade_boundaries_and_legacy_rounding():
    """The documented score components, grade boundaries, and points rule are stable."""
    maximum = calculate_life_score(
        age=120,
        average_happiness=100,
        final_health=100,
        education_level="doctorate",
        career_years=100,
        children=20,
        marriage_count=1,
        peak_net_worth_cents=dollars_to_cents(20_000_000),
        unsealed_convictions=0,
    )
    minimum = calculate_life_score(
        age=0,
        average_happiness=0,
        final_health=0,
        education_level="none",
        career_years=0,
        children=0,
        marriage_count=0,
        peak_net_worth_cents=0,
        unsealed_convictions=1,
    )
    assert maximum == 100.0
    assert minimum == 0.0
    assert [(score, grade_for_life_score(score)) for score in (0, 39.99, 40, 54.99, 55, 69.99, 70, 79.99, 80, 89.99, 90, 100)] == [
        (0, "F"), (39.99, "F"), (40, "D"), (54.99, "D"),
        (55, "C"), (69.99, "C"), (70, "B"), (79.99, "B"),
        (80, "A"), (89.99, "A"), (90, "S"), (100, "S"),
    ]
    assert legacy_points_for_score(99.99) == 9
    assert legacy_points_for_score(100) == 10


@pytest.mark.parametrize(
    ("gross", "debt", "price_index", "paid", "tax", "estate", "unpaid"),
    [
        (dollars_to_cents(5_500_000), dollars_to_cents(500_000), 1.0,
         dollars_to_cents(500_000), 0, dollars_to_cents(5_000_000), 0),
        (dollars_to_cents(10_000_000), dollars_to_cents(1_000_000), 1.0,
         dollars_to_cents(1_000_000), dollars_to_cents(1_600_000), dollars_to_cents(7_400_000), 0),
        (dollars_to_cents(100), dollars_to_cents(500), 1.0, dollars_to_cents(100), 0, 0, dollars_to_cents(400)),
        (0, dollars_to_cents(2_000_000), 10.0, 0, 0, 0, dollars_to_cents(2_000_000)),
    ],
)
def test_estate_settlement_pays_debt_before_tax_and_never_goes_negative(
    gross: int,
    debt: int,
    price_index: float,
    paid: int,
    tax: int,
    estate: int,
    unpaid: int,
):
    """Debt is paid before the indexed threshold tax and every remainder is nonnegative."""
    result = calculate_estate_settlement(
        gross_assets_cents=gross,
        debts_due_cents=debt,
        price_index=price_index,
    )
    assert result.debts_paid_cents == paid
    assert result.estate_tax_cents == tax
    assert result.estate_cents == estate
    assert result.unpaid_debt_cents == unpaid
    assert min(result.debts_paid_cents, result.estate_tax_cents, result.estate_cents, result.unpaid_debt_cents) >= 0
    assert result.estate_cents + result.estate_tax_cents <= gross - paid


@pytest.mark.asyncio
async def test_death_is_exactly_once_archived_immutable_and_closes_career(database, life_engine):
    """A terminal life archives once, preserves its score, and closes career rows as died."""
    character = await life_engine.create_character(51001, "Archived Life")
    async with database.transaction() as tx:
        await tx.execute(
            """INSERT INTO career_history(char_id, career_id, max_level, start_age)
               VALUES (?, 'teacher', 2, 20)""",
            (character.char_id,),
        )
        await tx.execute(
            """INSERT INTO jobs(char_id, career_id, level, performance, years_in_role,
                                years_in_career, salary, is_part_time, warnings)
               VALUES (?, 'teacher', 2, 60, 4, 10, 5_000_000, 0, 0)""",
            (character.char_id,),
        )
        await life_engine.legacy_repository.record_life_year(
            tx, character=replace(character, stats=replace(character.stats, happiness=80)),
            age=1, served_prison_year=False, now=1_800_000_001,
        )
        await life_engine.legacy_repository.record_life_year(
            tx, character=replace(character, stats=replace(character.stats, happiness=100)),
            age=2, served_prison_year=False, now=1_800_000_002,
        )
    dead = replace(
        character,
        is_alive=False,
        age=40,
        death_cause="illness",
        death_age=40,
        died_at=1_800_000_010,
        last_age_at=1_800_000_010,
        version=character.version + 1,
        stats=replace(character.stats, happiness=60),
    )
    async with database.transaction() as tx:
        await life_engine._save_character(tx, dead, expected_version=character.version)
        await life_engine.legacy_repository.record_life_year(
            tx, character=dead, age=40, served_prison_year=False, now=1_800_000_010
        )
        result = await life_engine.death.handle_death(tx, dead, now=1_800_000_010)
    assert result is not None
    assert result.summary["death_age"] == 40
    assert result.summary["career_years"] == 20
    assert result.summary["average_happiness"] == 80.0
    assert result.summary["grade"] == grade_for_life_score(result.summary["life_score"])
    assert result.summary["legacy_points"] == legacy_points_for_score(result.summary["life_score"])
    career = await database.fetchone(
        "SELECT end_age, end_reason FROM career_history WHERE char_id = ?",
        (character.char_id,),
    )
    assert dict(career) == {"end_age": 40, "end_reason": "died"}
    assert await database.fetchone("SELECT 1 FROM jobs WHERE char_id = ?", (character.char_id,)) is None

    async with database.transaction() as tx:
        assert await life_engine.death.handle_death(tx, dead, now=1_800_000_011) is None
    archive_count = await database.fetchone(
        "SELECT COUNT(*) AS n FROM past_lives WHERE char_id = ?", (character.char_id,)
    )
    assert int(archive_count["n"]) == 1
    archived_summary_row = await database.fetchone(
        "SELECT summary_json FROM past_lives WHERE char_id = ?", (character.char_id,)
    )
    archived_summary = json.loads(archived_summary_row["summary_json"])
    assert archived_summary["name"] == "Archived Life"
    assert archived_summary["death_age"] == 40
    assert archived_summary["debts_due_cents"] == 0
    assert archived_summary["life_years"]
    assert "summary_json" not in archived_summary
    player = await database.fetchone("SELECT lives_lived, legacy_points FROM players WHERE user_id = ?", (character.user_id,))
    assert int(player["lives_lived"]) == 1
    assert int(player["legacy_points"]) == result.summary["legacy_points"]

    with pytest.raises(aiosqlite.IntegrityError, match="immutable"):
        async with database.transaction() as tx:
            await tx.execute("UPDATE past_lives SET grade = 'S' WHERE char_id = ?", (character.char_id,))
    with pytest.raises(aiosqlite.IntegrityError, match="immutable"):
        async with database.transaction() as tx:
            await tx.execute("DELETE FROM past_lives WHERE char_id = ?", (character.char_id,))
    archived = await database.fetchone("SELECT grade FROM past_lives WHERE char_id = ?", (character.char_id,))
    assert archived["grade"] == result.summary["grade"]


@pytest.mark.asyncio
async def test_estate_lot_value_debt_first_tax_and_heir_split_and_copy(database, life_engine):
    """Death values each inventory lot once, pays debt before tax, and divides heirs fairly."""
    character = await life_engine.create_character(51002, "Estate Parent")
    character = replace(
        character,
        cash=dollars_to_cents(6_000_000),
        bank=0,
        debt_total=dollars_to_cents(1_000_000),
        price_index=1.25,
        version=character.version + 1,
    )
    async with database.transaction() as tx:
        await life_engine._save_character(tx, character, expected_version=character.version - 1)
        await tx.execute(
            """INSERT INTO family_assets
                   (char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at)
               VALUES (?, 'item', 'house', 10, ?, ?, 25, 1_800_000_001)""",
            (character.char_id, dollars_to_cents(200_000), dollars_to_cents(2_000_000)),
        )
    child_ids = [
        await _insert_child(
            life_engine, character.char_id, name="Avery", age=35, health=91,
            smarts=87, looks=73, wealth_cents=dollars_to_cents(250_000), gender="female", country="ca",
        ),
        await _insert_child(
            life_engine, character.char_id, name="Rowan", age=29, health=82,
            smarts=94, looks=68, wealth_cents=dollars_to_cents(150_000), gender="non_binary", country="in",
        ),
    ]
    dead = replace(
        character,
        is_alive=False,
        age=60,
        death_cause="natural causes",
        death_age=60,
        died_at=1_800_000_020,
        last_age_at=1_800_000_020,
        version=character.version + 1,
    )
    async with database.transaction() as tx:
        await life_engine._save_character(tx, dead, expected_version=character.version)
        result = await life_engine.death.handle_death(tx, dead, now=1_800_000_020)
    assert result is not None
    assert result.summary["gross_assets_cents"] == dollars_to_cents(8_000_000)
    assert result.summary["debts_paid_cents"] == dollars_to_cents(1_000_000)
    assert result.summary["estate_tax_threshold_cents"] == dollars_to_cents(6_250_000)
    assert result.summary["estate_tax_cents"] == dollars_to_cents(300_000)
    assert result.summary["estate_cents"] == dollars_to_cents(6_700_000)
    assert result.estate_id is not None and result.estate_nonce
    assert len(result.heirs) == 2
    assert [row["inheritance_cents"] for row in result.heirs] == [dollars_to_cents(3_350_000)] * 2
    assert sum(int(row["inheritance_cents"]) for row in result.heirs) == result.summary["estate_cents"]

    selected_id = child_ids[0]
    heir = await life_engine.death.choose_heir(
        character.user_id, result.estate_id, result.estate_nonce, selected_id,
        now=1_800_000_030,
    )
    assert heir is not None
    assert heir.name == "Avery"
    assert heir.age == 35
    assert heir.gender.value == "female"
    assert heir.country == "ca"
    assert heir.stats.health == 91
    assert heir.stats.smarts == 87
    assert heir.stats.looks == 73
    assert heir.cash == dollars_to_cents(3_350_000)
    assert heir.bank == 0 and heir.debt_total == 0
    assert heir.price_index == 1.25
    assert heir.parent_char_id == character.char_id
    assert heir.generation == character.generation + 1
    assert heir.is_alive
    active = await life_engine.get_active_character(character.user_id)
    assert active.char_id == heir.char_id
    assert active.cash >= 0 and active.bank >= 0 and active.debt_total >= 0
    estate = await database.fetchone("SELECT status, selected_npc_id FROM life_estates WHERE estate_id = ?", (result.estate_id,))
    assert estate["status"] == "claimed"
    assert int(estate["selected_npc_id"]) == selected_id


@pytest.mark.asyncio
async def test_zero_value_estate_still_offers_living_adult_heir(database, life_engine):
    """A living adult child can continue the family even when the inheritance is zero."""
    character = await life_engine.create_character(51012, "No Estate Parent")
    npc_id = await _insert_child(
        life_engine, character.char_id, name="Sam", age=22, health=76,
        smarts=81, looks=63, wealth_cents=0,
    )
    dead = replace(
        character,
        is_alive=False,
        age=50,
        death_cause="natural causes",
        death_age=50,
        died_at=1_800_000_025,
        last_age_at=1_800_000_025,
        version=character.version + 1,
    )
    async with database.transaction() as tx:
        await life_engine._save_character(tx, dead, expected_version=character.version)
        result = await life_engine.death.handle_death(tx, dead, now=1_800_000_025)
    assert result is not None and result.estate_id is not None
    assert result.summary["estate_cents"] == 0
    assert len(result.heirs) == 1
    assert int(result.heirs[0]["inheritance_cents"]) == 0
    heir = await life_engine.death.choose_heir(
        character.user_id, result.estate_id, result.estate_nonce or "", npc_id,
        now=1_800_000_026,
    )
    assert heir is not None
    assert heir.cash == 0 and heir.bank == 0 and heir.debt_total == 0
    assert heir.parent_char_id == character.char_id


@pytest.mark.asyncio
async def test_death_summary_visibility_obeys_guild_setting_and_player_opt_out(database, life_engine):
    """Public obituaries require both guild permission and the player's consent."""
    repository = LegacyRepository(database)
    async with database.transaction() as tx:
        await repository.set_guild_public_death_summaries(
            tx, guild_id=9002, enabled=True, user_id=51013, now=1_800_000_010
        )
    _, public_result = await _make_dead_life(
        life_engine, 51013, now=1_800_000_011, guild_id=9002
    )
    assert public_result is not None and public_result.public_summary is True
    async with database.transaction() as tx:
        await repository.set_leaderboard_privacy(
            tx, 51014, True, now=1_800_000_012
        )
    _, private_result = await _make_dead_life(
        life_engine, 51014, now=1_800_000_013, guild_id=9002
    )
    assert private_result is not None and private_result.public_summary is False


@pytest.mark.asyncio
async def test_death_transaction_rolls_back_every_write_and_pending_notice(database, life_engine, monkeypatch):
    """An injected mid-archive error rolls back death fields, archives, balances, and unlocks."""
    character = await life_engine.create_character(51003, "Rollback Life")
    dead = replace(
        character,
        is_alive=False,
        age=1,
        death_cause="natural causes",
        death_age=1,
        died_at=1_800_000_040,
        last_age_at=1_800_000_040,
        version=character.version + 1,
    )
    insert_past_life = life_engine.death.repository.insert_past_life

    async def insert_then_fail(tx: Any, summary: dict[str, Any]) -> bool:
        await insert_past_life(tx, summary)
        raise RuntimeError("forced failure after archive insert")

    monkeypatch.setattr(life_engine.death.repository, "insert_past_life", insert_then_fail)
    with pytest.raises(RuntimeError, match="forced failure"):
        async with database.transaction() as tx:
            await life_engine._save_character(tx, dead, expected_version=character.version)
            await life_engine.death.handle_death(tx, dead, now=1_800_000_040)
    persisted = await database.fetchone("SELECT is_alive, death_cause FROM characters WHERE char_id = ?", (character.char_id,))
    assert int(persisted["is_alive"]) == 1
    assert persisted["death_cause"] is None
    assert await database.fetchone("SELECT 1 FROM past_lives WHERE char_id = ?", (character.char_id,)) is None
    assert await database.fetchone("SELECT 1 FROM achievements_unlocked WHERE user_id = ?", (character.user_id,)) is None
    assert await database.fetchone(
        "SELECT 1 FROM players WHERE user_id = ?", (character.user_id,)
    ) is None
    assert life_engine.achievements.consume_notifications(character.user_id) == []


@pytest.mark.asyncio
async def test_achievement_unlocks_are_authoritative_and_idempotent(database, life_engine):
    """Unlocks derive from persisted character state; repeated checks cannot duplicate rows."""
    character = await life_engine.create_character(51004, "New Steps")
    initial = await life_engine.achievements.check_user(character.user_id, now=1_800_000_050)
    assert "first_steps" not in {row["id"] for row in initial}
    life_engine.achievements.consume_notifications(character.user_id)
    with pytest.raises(TypeError):
        await life_engine.achievements.check_user(character.user_id, age=100)  # type: ignore[call-arg]
    with pytest.raises(TypeError):
        await life_engine.achievements.check_user(character.user_id, achievement_id="jackpot")  # type: ignore[call-arg]

    aged = replace(character, age=1, version=character.version + 1)
    async with database.transaction() as tx:
        await life_engine._save_character(tx, aged, expected_version=character.version)
    unlocked = await life_engine.achievements.check_user(character.user_id, now=1_800_000_051)
    assert "first_steps" in {row["id"] for row in unlocked}
    assert "first_steps" in {row["id"] for row in life_engine.achievements.consume_notifications(character.user_id)}
    repeated = await life_engine.achievements.check_user(character.user_id, now=1_800_000_052)
    assert "first_steps" not in {row["id"] for row in repeated}
    rows = await database.fetchall(
        "SELECT achievement_id FROM achievements_unlocked WHERE user_id = ? AND achievement_id = 'first_steps'",
        (character.user_id,),
    )
    assert len(rows) == 1


@pytest.mark.asyncio
async def test_year_tick_step_15_records_happiness_and_unlocks_first_steps(life_engine):
    """An ordinary age tick runs the Stage 10 metric and achievement step atomically."""
    character = await life_engine.create_character(51005, "Yearly Check")
    outcome = await life_engine.age_up(character.user_id)
    assert outcome.character.age == 1
    assert "first_steps" in {row["id"] for row in outcome.unlocked_achievements}
    metrics = await life_engine.db.fetchall(
        "SELECT age, happiness FROM life_year_metrics WHERE char_id = ? ORDER BY age",
        (character.char_id,),
    )
    assert len(metrics) == 1
    assert int(metrics[0]["age"]) == 1
    assert int(metrics[0]["happiness"]) == outcome.character.stats.happiness
    assert "first_steps" in {row["id"] for row in life_engine.achievements.consume_notifications(character.user_id)}


@pytest.mark.asyncio
async def test_legacy_purchase_is_capped_to_two_and_changes_no_money(database, life_engine):
    """Two earned purchases add at most ten stat points and deduct exactly 100 cosmetic points."""
    control_engine = LifeEngine(
        database,
        RNG(seed=2026),
        UserLockRegistry(),
        clock=lambda: 1_800_000_000,
        event_chance=0.0,
    )
    baseline = await control_engine.create_character(51006, "Baseline")
    async with database.transaction() as tx:
        await life_engine.legacy_repository.ensure_player(tx, 51007, 1_800_000_000)
        await tx.execute("UPDATE players SET legacy_points = 200 WHERE user_id = ?", (51007,))
    boosted = await life_engine.create_character(
        51007, "Boosted", legacy_stat="health", legacy_purchases=2
    )
    assert boosted.stats.health == min(100, baseline.stats.health + 10)
    for key in ("happiness", "smarts", "looks", "fitness", "karma", "stress", "addiction", "fame"):
        assert getattr(boosted.stats, key) == getattr(baseline.stats, key)
    assert boosted.cash == baseline.cash == 0
    assert boosted.bank == baseline.bank == 0
    player = await database.fetchone("SELECT legacy_points FROM players WHERE user_id = ?", (51007,))
    assert int(player["legacy_points"]) == 100
    purchase = await database.fetchone(
        "SELECT stat_name, purchase_count, points_spent FROM legacy_start_purchases WHERE char_id = ?",
        (boosted.char_id,),
    )
    assert dict(purchase) == {"stat_name": "health", "purchase_count": 2, "points_spent": 100}
    with pytest.raises(ValidationError):
        await life_engine.create_character(51008, "Over the Cap", legacy_stat="health", legacy_purchases=3)
    async with database.transaction() as tx:
        await life_engine.legacy_repository.ensure_player(tx, 51009, 1_800_000_000)
        await tx.execute("UPDATE players SET legacy_points = 50 WHERE user_id = ?", (51009,))
    with pytest.raises(InsufficientFunds):
        await life_engine.create_character(51009, "Too Costly", legacy_stat="smarts", legacy_purchases=2)
    assert await database.fetchone("SELECT 1 FROM characters WHERE user_id = 51009") is None


@pytest.mark.asyncio
async def test_retirement_has_no_points_heir_or_debt_transfer(database, life_engine):
    """Confirmed abandonment archives once but awards neither legacy points nor inheritance."""
    character = await life_engine.create_character(51010, "Retired Life")
    updated = replace(
        character,
        age=45,
        cash=dollars_to_cents(100_000),
        debt_total=dollars_to_cents(500_000),
        version=character.version + 1,
    )
    async with database.transaction() as tx:
        await life_engine._save_character(tx, updated, expected_version=character.version)
    prompt = await life_engine.death.begin_retirement(character.user_id, now=1_800_000_100)
    result = await life_engine.death.confirm_retirement(
        character.user_id, prompt.prompt_id, prompt.nonce, now=1_800_000_101
    )
    assert result.summary["death_cause"] == "Life abandoned"
    assert result.summary["abandoned"] is True
    assert result.summary["legacy_points"] == 0
    assert result.summary["estate_cents"] == 0
    assert result.summary["debts_paid_cents"] == 0
    assert result.summary["unpaid_debt_cents"] == dollars_to_cents(500_000)
    assert await database.fetchone("SELECT 1 FROM life_estates WHERE user_id = ?", (character.user_id,)) is None
    player = await database.fetchone("SELECT lives_lived, legacy_points FROM players WHERE user_id = ?", (character.user_id,))
    assert int(player["lives_lived"]) == 0
    assert int(player["legacy_points"]) == 0
    with pytest.raises(ValidationError):
        await life_engine.death.confirm_retirement(
            character.user_id, prompt.prompt_id, prompt.nonce, now=1_800_000_102
        )
    await life_engine.create_character(character.user_id, "Another Abandoned Life")
    second_prompt = await life_engine.death.begin_retirement(
        character.user_id, now=1_800_000_200
    )
    await life_engine.death.confirm_retirement(
        character.user_id, second_prompt.prompt_id, second_prompt.nonce,
        now=1_800_000_201,
    )
    player = await database.fetchone("SELECT lives_lived, legacy_points FROM players WHERE user_id = ?", (character.user_id,))
    assert int(player["lives_lived"]) == 0
    assert int(player["legacy_points"]) == 0
    archives = await database.fetchone(
        "SELECT COUNT(*) AS n FROM past_lives WHERE user_id = ?", (character.user_id,)
    )
    assert int(archives["n"]) == 2


@pytest.mark.asyncio
async def test_leaderboard_ties_pagination_cache_expiry_privacy_and_server_fallback(database, life_engine):
    """Rankings tie by account ID, page after ten, expire at 60 seconds, and use seen guild users."""
    user_ids = list(range(51100, 51112))
    for user_id in user_ids:
        await life_engine.create_character(user_id, f"Rank {user_id}")
        async with database.transaction() as tx:
            await life_engine.legacy_repository.ensure_player(tx, user_id, 1_800_000_000)
    await _set_character_age(life_engine, user_ids[-1], 10)

    clock = [100.0]
    leaderboard = LeaderboardService(
        database,
        life_engine.achievements,
        life_engine.locks,
        clock=lambda: clock[0],
        cache_seconds=60,
    )
    first = await leaderboard.get_leaderboard(
        user_ids[0], metric="age", scope="global", period="current"
    )
    assert len(first.entries) == 12
    assert first.entries[0]["user_id"] == user_ids[-1]
    assert [row["user_id"] for row in first.entries[1:]] == user_ids[:-1]
    first_embed = leaderboard_embed(first, 0)
    second_embed = leaderboard_embed(first, 1)
    assert len((first_embed.description or "").splitlines()) == 10
    assert len((second_embed.description or "").splitlines()) == 2
    pager = EmbedPager(user_ids[0], [first_embed, second_embed])
    assert len(pager.embeds) == 2

    await _set_character_age(life_engine, user_ids[0], 99)
    clock[0] = 159.99
    cached = await leaderboard.get_leaderboard(
        user_ids[0], metric="age", scope="global", period="current"
    )
    assert cached.entries == first.entries
    clock[0] = 160.0
    refreshed = await leaderboard.get_leaderboard(
        user_ids[0], metric="age", scope="global", period="current"
    )
    assert refreshed.entries[0]["user_id"] == user_ids[0]

    await leaderboard.set_opt_out(user_ids[1], True, now=1_800_000_200)
    private_filtered = await leaderboard.get_leaderboard(
        user_ids[0], metric="age", scope="global", period="current"
    )
    assert user_ids[1] not in {row["user_id"] for row in private_filtered.entries}
    async with database.transaction() as tx:
        await LegacyRepository(database).record_guild_seen(tx, 9001, user_ids[2], 1_800_000_201)
    server = await leaderboard.get_leaderboard(
        user_ids[0], metric="age", scope="server", period="current", guild_id=9001
    )
    assert {row["user_id"] for row in server.entries} == {user_ids[0], user_ids[2]}


def test_epitaph_selection_is_deterministic_and_catalog_has_twenty_templates():
    """Epitaph choice is based on stable life facts and contains ample PG-13 variants."""
    from core.death import _EPITAPHS

    assert sum(len(templates) for templates in _EPITAPHS.values()) >= 20
    arguments = dict(
        char_id=75,
        age=24,
        cause="natural causes",
        education_level="none",
        children=0,
        marriage_years=0,
        career_count=0,
        conviction_count=0,
        sealed_convictions=0,
        net_worth_cents=0,
        hardship_recovered=False,
    )
    assert select_epitaph(**arguments) == select_epitaph(**arguments)
    assert select_epitaph(**{**arguments, "cause": "Life abandoned"}) in _EPITAPHS["abandoned"]
