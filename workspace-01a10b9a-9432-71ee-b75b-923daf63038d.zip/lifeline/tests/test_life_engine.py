"""Tests for birth creation, stats, and yearly aging."""
from __future__ import annotations

import asyncio
import json
from dataclasses import replace

import pytest

from core.crime import CrimeYearResult
from core.errors import CharacterAlreadyExists, CharacterDead, CharacterNotFound, ValidationError
from core.life_engine import LifeEngine, roll_birth_attributes, simulate_year
from core.models import Character, Gender, HiddenTraits, LifeStage, Stats
from core.rng import RNG


def test_birth_rolls_are_reproducible_and_in_range():
    first = roll_birth_attributes(RNG(7))
    second = roll_birth_attributes(RNG(7))
    assert first == second
    stats, hidden, wealth = first
    for key, value in stats.to_dict().items():
        if key != "credit_score":
            assert 0 <= value <= 100
    assert -10 <= hidden.genetic_health_mod <= 10
    assert -8 <= hidden.lifespan_mod <= 8
    assert -5 <= hidden.luck <= 5
    assert wealth in {"poor", "working", "middle", "upper", "rich"}


def test_character_life_stage_boundaries():
    cases = {
        0: LifeStage.BABY,
        2: LifeStage.BABY,
        3: LifeStage.CHILD,
        12: LifeStage.CHILD,
        13: LifeStage.TEEN,
        17: LifeStage.TEEN,
        18: LifeStage.YOUNG_ADULT,
        29: LifeStage.YOUNG_ADULT,
        30: LifeStage.ADULT,
        49: LifeStage.ADULT,
        50: LifeStage.MIDDLE_AGE,
        64: LifeStage.MIDDLE_AGE,
        65: LifeStage.SENIOR,
    }
    for age, expected in cases.items():
        assert Character(age=age).life_stage is expected


def test_simulate_year_advances_once_and_keeps_stats_bounded():
    original = Character(name="Ari", age=17, stats=Stats(health=99, happiness=99, smarts=50))
    result = simulate_year(original, RNG(13), now=1234)
    assert result.previous_age == 17
    assert result.new_age == 18
    assert result.character.age == 18
    assert result.previous_stage is LifeStage.TEEN
    assert result.new_stage is LifeStage.YOUNG_ADULT
    assert result.character.last_age_at == 1234
    assert original.age == 17  # Simulation calculation does not mutate its input.
    assert all(0 <= value <= 100 for key, value in result.character.stats.to_dict().items() if key != "credit_score")


def test_max_age_ends_life():
    character = Character(
        name="Morgan",
        age=119,
        stats=Stats(health=100),
        hidden=HiddenTraits(lifespan_mod=8),
    )
    result = simulate_year(character, RNG(1), now=500)
    assert result.new_age == 120
    assert result.died is True
    assert result.death_cause == "natural causes"
    assert result.character.death_age == 120
    assert result.character.died_at == 500
    with pytest.raises(CharacterDead):
        simulate_year(result.character, RNG(1))


def test_stats_credit_score_clamps_without_treating_zero_as_missing():
    assert Stats(credit_score=0).clamp_all().credit_score == 300
    assert Stats(credit_score=900).clamp_all().credit_score == 850
    assert Stats(credit_score=None).clamp_all().credit_score is None
    assert Stats(health=100.6).clamp_all().health == 100


@pytest.mark.asyncio
async def test_create_character_and_reload(life_engine: LifeEngine):
    character = await life_engine.create_character(
        101,
        "  Casey   Lane ",
        gender=Gender.NON_BINARY,
        country="IN",
    )
    loaded = await life_engine.get_active_character(101)
    assert character.char_id > 0
    assert character.name == "Casey Lane"
    assert character.age == 0
    assert character.gender is Gender.NON_BINARY
    assert character.country == "in"
    assert loaded.to_dict() == character.to_dict()


@pytest.mark.asyncio
async def test_only_one_active_life_per_user(life_engine: LifeEngine):
    await life_engine.create_character(202, "First")
    with pytest.raises(CharacterAlreadyExists):
        await life_engine.create_character(202, "Second")


@pytest.mark.asyncio
async def test_child_generation_uses_parent_life(life_engine: LifeEngine):
    parent = await life_engine.create_character(252, "Parent")
    child = await life_engine.create_character(253, "Child", parent_char_id=parent.char_id)
    assert child.parent_char_id == parent.char_id
    assert child.generation == parent.generation + 1


@pytest.mark.asyncio
async def test_invalid_birth_inputs_are_rejected(life_engine: LifeEngine):
    with pytest.raises(ValidationError):
        await life_engine.create_character(0, "Invalid")
    with pytest.raises(ValidationError):
        await life_engine.create_character(303, "  ")
    with pytest.raises(ValidationError):
        await life_engine.create_character(304, "Name", gender="unknown")


@pytest.mark.asyncio
async def test_age_up_persists_age_and_logs(database, life_engine: LifeEngine):
    await life_engine.create_character(404, "Sam")
    outcome = await life_engine.age_up(404)
    saved = await life_engine.get_active_character(404)
    logs = await database.fetchall(
        "SELECT age, category, text FROM life_logs WHERE char_id = ? ORDER BY id",
        (saved.char_id,),
    )
    assert outcome.new_age == 1
    assert saved.age == 1
    assert len(logs) >= 2  # birth record plus the first birthday
    assert logs[-1]["age"] == 1


@pytest.mark.asyncio
async def test_age_up_reports_death_from_late_annual_service(life_engine: LifeEngine, monkeypatch):
    """Keep the outcome flags synchronized when a later annual service ends a life."""
    character = await life_engine.create_character(405, "Prison outcome")

    async def end_life_in_crime_step(tx, current, *, previous_age, personal_income,
                                     household_income, tax_assessed, tax_paid, now):
        dead = replace(
            current,
            is_alive=False,
            in_prison=False,
            prison_years_left=0,
            death_cause="prison violence",
            death_age=current.age,
            died_at=now,
        )
        return CrimeYearResult(dead, (f"Life ended at age {current.age} after a prison-violence event.",))

    monkeypatch.setattr(life_engine.crimes, "advance_year", end_life_in_crime_step)
    outcome = await life_engine.age_up(character.user_id)

    assert outcome.character.is_alive is False
    assert outcome.died is True
    assert outcome.death_cause == "prison violence"
    archived = await life_engine.db.fetchone(
        "SELECT death_cause FROM past_lives WHERE char_id = ?", (character.char_id,)
    )
    assert archived is not None and archived["death_cause"] == "prison violence"


@pytest.mark.asyncio
async def test_concurrent_age_requests_are_serialized(life_engine: LifeEngine):
    await life_engine.create_character(505, "Taylor")
    results = await asyncio.gather(life_engine.age_up(505), life_engine.age_up(505))
    current = await life_engine.get_active_character(505)
    assert sorted(result.new_age for result in results) == [1, 2]
    assert current.age == 2


@pytest.mark.asyncio
async def test_death_is_persisted_and_a_new_life_can_begin(database, life_engine: LifeEngine):
    character = await life_engine.create_character(550, "Morgan")
    character.age = 119
    character.stats.health = 100
    payload = json.dumps(character.to_dict(), separators=(",", ":"))
    async with database.transaction() as tx:
        await tx.execute(
            "UPDATE characters SET age = ?, data_json = ? WHERE char_id = ?",
            (119, payload, character.char_id),
        )

    outcome = await life_engine.age_up(550)
    assert outcome.died is True
    assert outcome.character.age == 120
    with pytest.raises(CharacterDead):
        await life_engine.age_up(550)
    with pytest.raises(CharacterDead):
        await life_engine.get_active_character(550)

    next_life = await life_engine.create_character(550, "Morgan II")
    assert next_life.age == 0
    assert next_life.char_id != character.char_id


@pytest.mark.asyncio
async def test_missing_character_errors(life_engine: LifeEngine):
    with pytest.raises(CharacterNotFound):
        await life_engine.get_active_character(606)
    with pytest.raises(CharacterNotFound):
        await life_engine.age_up(606)
