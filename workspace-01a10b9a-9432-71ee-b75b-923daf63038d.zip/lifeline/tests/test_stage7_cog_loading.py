"""File-backed Discord.py extension smoke test for Stage 7 commands."""
from __future__ import annotations

import discord
import pytest
from discord.ext import commands

from core.crime import CrimeService
from core.family import FamilyService
from core.locks import UserLockRegistry
from core.rng import RNG


@pytest.mark.asyncio
async def test_stage7_cogs_load_against_file_backed_database(database):
    bot = commands.Bot(command_prefix="!", intents=discord.Intents.none())
    bot.db = database
    bot.rng = RNG(701)
    bot.locks = UserLockRegistry()
    bot.family_service = FamilyService(database, bot.rng, bot.locks)
    bot.crime_service = CrimeService(
        database,
        bot.rng,
        bot.locks,
        family_service=bot.family_service,
    )

    try:
        for extension in ("cogs.life", "cogs.crime", "cogs.prison"):
            await bot.load_extension(extension)
        assert bot.tree.get_command("life") is not None
        assert bot.tree.get_command("crime") is not None
        assert bot.tree.get_command("prison") is not None
    finally:
        await bot.close()
