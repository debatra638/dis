"""Stage 9 investing acceptance tests for markets, orders, bonds, taxes, and rentals."""
from __future__ import annotations

import json
from dataclasses import replace

import pytest

from core.data_loader import DataLoader
from core.errors import InsufficientFunds, ValidationError
from core.investing import InvestingService, MAX_CATCH_UP_TICKS
from core.models import Character, HousingType
from core.rng import RNG


class Clock:
    """Mutable deterministic clock for ticker and order-window tests."""

    def __init__(self, value: int = 1_800_000_000) -> None:
        self.value = value

    def __call__(self) -> int:
        return self.value


class MarketRNG(RNG):
    """Controlled market event/GBM stream."""

    def __init__(self, event_roll: float = 0.5, bankruptcy_roll: float = 0.5, seed: int = 1) -> None:
        super().__init__(seed)
        self.event_roll = event_roll
        self.bankruptcy_roll = bankruptcy_roll
        self._first_random = True

    def random(self) -> float:
        if self._first_random:
            self._first_random = False
            return self.event_roll
        return self.bankruptcy_roll

    def gauss(self, mu: float, sigma: float) -> float:
        return 0.0

    def uniform(self, a: float, b: float) -> float:
        return a


async def _adult(database, life_engine, user_id: int, *, age: int = 25, cash: int = 0, bank: int = 10_000_000) -> Character:
    """Create a normal Stage 1–8 life and set it to an adult with deterministic funds."""
    character = await life_engine.create_character(user_id, f"Investor Test {user_id}", country="usa")
    character = replace(character, age=age, cash=cash, bank=bank, version=character.version + 1)
    async with database.transaction() as tx:
        await tx.execute(
            "UPDATE characters SET age = ?, stats_json = ?, data_json = ?, version = ? WHERE char_id = ?",
            (character.age, json.dumps(character.stats.to_dict()),
             json.dumps(character.to_dict(), separators=(",", ":")), character.version, character.char_id),
        )
    return character


def _service(database, life_engine, clock: Clock, rng: RNG | None = None) -> InvestingService:
    """Construct the market service with the fixture's shared locks."""
    return InvestingService(database, rng or life_engine.rng, life_engine.locks, clock=clock)


def test_gbm_formula_cent_floor_and_brokerage_rounding(database, life_engine):
    """GBM follows the exact equation and never returns less than one cent for listed stock."""
    unchanged = InvestingService.gbm_price_step(10_000, 0.0, 0.0, 5.0)
    assert unchanged == 10_000
    assert InvestingService.gbm_price_step(1, -1.0, 2.0, -10.0) == 1
    assert InvestingService.gbm_price_step(0, 0.1, 0.2, 0.0) == 0
    assert InvestingService.brokerage_fee(1) == 100
    assert InvestingService.brokerage_fee(20_001) == 101


def test_validated_stock_catalog_covers_required_sectors_and_hypercoin():
    """Startup catalogs include all required sectors and the high-volatility HyperCoin ticker."""
    catalog = DataLoader().load_stocks()["stocks"]
    sectors = {row["sector"] for row in catalog}
    hypercoin = next(row for row in catalog if row["symbol"] == "HYPER")
    assert len(catalog) >= 12
    assert {"tech", "energy", "health", "finance", "consumer"}.issubset(sectors)
    assert hypercoin["name"] == "HyperCoin" and hypercoin["volatility"] >= 1.0
    ages = DataLoader().load_gambling_ages()
    assert ages["default_age"] == 18 and ages["countries"]["in"] >= 18


@pytest.mark.asyncio
async def test_market_snapshot_has_24_hour_change_sparklines_and_symbol_autocomplete(database, life_engine):
    """Market readout includes movement/sparkline data and catalog-prefix autocomplete."""
    clock = Clock(10_000)
    service = _service(database, life_engine, clock)
    await _adult(database, life_engine, 400, age=21, bank=100_000)
    await service.initialize_market()
    await service.tick_global(10_600)
    clock.value = 10_600
    quotes = await service.market(400)
    qant = next(row for row in quotes if row.symbol == "QANT")
    assert qant.price_cents > 0 and qant.sparkline
    assert len(service.symbol_options("hyp")) == 1
    assert service.symbol_options("hyp")[0][0] == "HYPER"
    stock, history, trades = await service.trade_history(400, "QANT")
    assert stock["symbol"] == "QANT" and len(history) >= 2 and trades == []


@pytest.mark.asyncio
async def test_ticker_catch_up_is_capped_idempotent_and_does_not_backfill(database, life_engine):
    """Ticker advances at most six missed ticks and a duplicate timestamp writes no history."""
    clock = Clock(10_000)
    service = _service(database, life_engine, clock)
    await service.initialize_market()
    before = await database.fetchone("SELECT price_cents FROM stock_market WHERE symbol = 'QANT'")
    result = await service.tick_global(10_000 + 15 * 600)
    assert result.ticks == MAX_CATCH_UP_TICKS
    assert result.last_tick_no == MAX_CATCH_UP_TICKS
    assert result.last_tick_at == 10_000 + 15 * 600
    count_before = await database.fetchone("SELECT COUNT(*) AS n FROM stock_history WHERE symbol = 'QANT'")
    repeat = await service.tick_global(10_000 + 15 * 600)
    count_after = await database.fetchone("SELECT COUNT(*) AS n FROM stock_history WHERE symbol = 'QANT'")
    assert repeat.ticks == 0 and count_after["n"] == count_before["n"]

    later = await service.tick_global(10_000 + 35 * 600)
    assert later.ticks == MAX_CATCH_UP_TICKS
    immediate = await service.tick_global(10_000 + 35 * 600 + 1)
    assert immediate.ticks == 0
    final = await database.fetchone("SELECT tick_no FROM market_state WHERE singleton_id = 1")
    assert final["tick_no"] == MAX_CATCH_UP_TICKS * 2
    assert before["price_cents"] > 0


@pytest.mark.asyncio
async def test_market_crash_boom_events_and_delisting_make_holdings_worthless(database, life_engine):
    """Daily crash/boom events apply globally and sub-$1 bankruptcy delists at zero."""
    clock = Clock(10_000)
    crash_rng = MarketRNG(event_roll=0.0)
    service = _service(database, life_engine, clock, crash_rng)
    await service.initialize_market()
    initial = {row["symbol"]: row["price_cents"] for row in await database.fetchall("SELECT symbol, price_cents FROM stock_market")}
    crash = await service.tick_global(10_600)
    assert any(event.startswith("crash:") for event in crash.events)
    crashed = {row["symbol"]: int(row["price_cents"]) for row in await database.fetchall("SELECT symbol, price_cents FROM stock_market WHERE is_delisted = 0")}
    assert all(crashed[symbol] < price for symbol, price in initial.items())
    hist_event = await database.fetchone("SELECT event_type FROM stock_history WHERE symbol = 'QANT' ORDER BY tick_no DESC LIMIT 1")
    assert hist_event["event_type"] == "crash"

    boom_rng = MarketRNG(event_roll=0.04)
    boom_service = _service(database, life_engine, clock, boom_rng)
    before_boom = await database.fetchone("SELECT price_cents FROM stock_market WHERE symbol = 'QANT'")
    boom = await boom_service.tick_global(10_000 + 86_400 + 1_200)
    assert any(event.startswith("boom:") for event in boom.events)
    after_boom = await database.fetchone("SELECT price_cents FROM stock_market WHERE symbol = 'QANT'")
    assert after_boom["price_cents"] > before_boom["price_cents"]

    # One penny-priced listed ticker receives the 0.05% bankruptcy roll.
    delist_service = _service(database, life_engine, clock, MarketRNG(event_roll=0.0, bankruptcy_roll=0.0))
    await database.execute("UPDATE stock_market SET price_cents = 99, is_delisted = 0, delisted_at = NULL WHERE symbol = 'BYTE'")
    await delist_service.tick_global(10_000 + 86_400 + 4_200)
    delisted = await database.fetchone("SELECT price_cents, is_delisted FROM stock_market WHERE symbol = 'BYTE'")
    assert delisted["is_delisted"] == 1 and delisted["price_cents"] == 0

    character = await _adult(database, life_engine, 401, bank=100_000)
    await database.execute(
        "INSERT INTO stock_holdings(char_id, symbol, shares, cost_basis_cents, updated_at) VALUES (?, 'BYTE', 5, 500, 1)",
        (character.char_id,),
    )
    holdings, _, _ = await delist_service.portfolio(401)
    byte = next(row for row in holdings if row["symbol"] == "BYTE")
    assert byte["market_value_cents"] == 0 and byte["unrealized_gain_cents"] == -500
    with pytest.raises(ValidationError, match="delisted"):
        await delist_service.sell(401, "BYTE", "all")


@pytest.mark.asyncio
async def test_market_tick_failure_rolls_back_prices_history_and_cursor(database, life_engine, monkeypatch):
    """An exception after a price update rolls back the complete market transaction."""
    clock = Clock(10_000)
    service = _service(database, life_engine, clock)
    await service.initialize_market()
    old_state = dict(await database.fetchone("SELECT * FROM market_state WHERE singleton_id = 1"))
    old_price = dict(await database.fetchone("SELECT price_cents FROM stock_market WHERE symbol = 'QANT'"))
    async def fail_history(*args, **kwargs):
        raise RuntimeError("injected history failure")
    monkeypatch.setattr(service.repository, "insert_history", fail_history)
    with pytest.raises(RuntimeError, match="injected history failure"):
        await service.tick_global(10_600)
    state_after = dict(await database.fetchone("SELECT * FROM market_state WHERE singleton_id = 1"))
    price_after = dict(await database.fetchone("SELECT price_cents FROM stock_market WHERE symbol = 'QANT'"))
    assert state_after == old_state
    assert price_after == old_price
    assert await database.fetchone("SELECT COUNT(*) AS n FROM stock_history WHERE symbol = 'QANT'") is not None


@pytest.mark.asyncio
async def test_average_cost_fees_portfolio_and_realized_sale_gain(database, life_engine):
    """Buy fees enter average cost; sale fees reduce realized gains and portfolio basis."""
    clock = Clock()
    character = await _adult(database, life_engine, 402, cash=0, bank=2_000_000)
    service = _service(database, life_engine, clock)
    await service.initialize_market()
    first = await service.buy(402, "qant", 2)
    assert first.gross_cents == 25_100 and first.fee_cents == 126
    await database.execute("UPDATE stock_market SET price_cents = 15000 WHERE symbol = 'QANT'")
    clock.value += 60
    second = await service.buy(402, "QANT", 2)
    assert second.gross_cents == 30_000 and second.fee_cents == 150
    holdings, _, bank = await service.portfolio(402)
    qant = holdings[0]
    assert qant["shares"] == 4
    assert qant["cost_basis_cents"] == 55_376
    assert qant["market_value_cents"] == 60_000
    assert qant["unrealized_gain_cents"] == 4_624
    assert bank == character.bank - 25_226 - 30_150

    clock.value += 60
    sold = await service.sell(402, "QANT", 1)
    assert sold.gross_cents == 15_000 and sold.fee_cents == 100
    assert sold.realized_gain_cents == 1_056
    remaining, _, _ = await service.portfolio(402)
    assert remaining[0]["shares"] == 3 and remaining[0]["cost_basis_cents"] == 41_532
    clock.value += 60
    sold_all = await service.sell(402, "QANT", "all")
    assert sold_all.shares == 3
    empty, _, final_bank = await service.portfolio(402)
    assert empty == [] and final_bank >= 0
    trades = await database.fetchall("SELECT side, realized_gain_cents FROM investment_trades WHERE char_id = ? ORDER BY investment_trade_id", (character.char_id,))
    assert len(trades) == 4 and trades[2]["realized_gain_cents"] == 1_056


@pytest.mark.asyncio
async def test_stock_opposite_cooldown_hourly_cap_and_bank_only_funds(database, life_engine):
    """Stock orders enforce 60 seconds, 20 hourly trades, and never debit cash."""
    clock = Clock()
    character = await _adult(database, life_engine, 403, cash=1_000_000, bank=100_000)
    service = _service(database, life_engine, clock)
    await service.initialize_market()
    with pytest.raises(InsufficientFunds):
        await service.buy(403, "BYTE", 100)
    await service.buy(403, "FOOD", 1)
    updated = Character.from_dict(json.loads((await database.fetchone("SELECT data_json FROM characters WHERE char_id = ?", (character.char_id,)))["data_json"]))
    assert updated.cash == character.cash
    with pytest.raises(ValidationError, match="Wait"):
        await service.sell(403, "FOOD", "all")
    clock.value += 60
    await service.sell(403, "FOOD", "all")

    capped = await _adult(database, life_engine, 404, cash=0, bank=100_000)
    for _ in range(20):
        await service.buy(404, "FOOD", 1)
    with pytest.raises(ValidationError, match="20 stock trades"):
        await service.buy(404, "FOOD", 1)
    count = await database.fetchone("SELECT COUNT(*) AS n FROM investment_trades WHERE char_id = ?", (capped.char_id,))
    assert count["n"] == 20


@pytest.mark.asyncio
async def test_delisted_symbols_reject_trading_and_no_balance_goes_negative(database, life_engine):
    """A delisted company is untradeable and a minimum-fee sale cannot create negative bank."""
    character = await _adult(database, life_engine, 405, cash=0, bank=0)
    service = _service(database, life_engine, Clock())
    await service.initialize_market()
    await database.execute("UPDATE stock_market SET is_delisted = 1, price_cents = 0 WHERE symbol = 'NOVA'")
    await database.execute("INSERT INTO stock_holdings(char_id, symbol, shares, cost_basis_cents, updated_at) VALUES (?, 'NOVA', 1, 100, 0)", (character.char_id,))
    with pytest.raises(ValidationError, match="delisted"):
        await service.sell(405, "NOVA", "all")
    saved = Character.from_dict(json.loads((await database.fetchone("SELECT data_json FROM characters WHERE char_id = ?", (character.char_id,)))["data_json"]))
    assert saved.cash >= 0 and saved.bank >= 0


@pytest.mark.asyncio
async def test_realized_gain_tax_is_20_percent_at_next_yearly_tick(database, life_engine):
    """Realized gains after fees/basis are taxed once at the following age tick."""
    clock = Clock()
    character = await _adult(database, life_engine, 406, cash=0, bank=100_000)
    service = _service(database, life_engine, clock)
    await service.initialize_market()
    async with database.transaction() as tx:
        await service.repository.insert_trade(
            tx, char_id=character.char_id, symbol="QANT", side="sell", shares=1,
            price_cents=20_000, gross_cents=20_000, fee_cents=100,
            realized_gain_cents=10_001, age=character.age, created_at=clock.value,
        )
        first = await service.advance_year(tx, character, previous_age=character.age, now=clock.value)
        second = await service.advance_year(tx, first.character, previous_age=character.age, now=clock.value + 1)
    assert first.character.bank == 97_999
    assert second.character.bank == first.character.bank
    tax = await database.fetchone("SELECT capital_gain_cents, capital_tax_cents FROM casino_yearly_tax WHERE char_id = ? AND age = ?", (character.char_id, character.age))
    assert tax["capital_gain_cents"] == 10_001 and tax["capital_tax_cents"] == 2_001


@pytest.mark.asyncio
async def test_bond_five_year_lock_compounds_and_matures(database, life_engine):
    """Bonds compound at 3.5% for five character years and release only at maturity."""
    clock = Clock()
    character = await _adult(database, life_engine, 407, age=25, cash=0, bank=500_000)
    service = _service(database, life_engine, clock)
    await service.initialize_market()
    receipt = await service.bond_buy(407, 100_000)
    assert receipt.bank_balance_cents == 400_000
    char = Character.from_dict(json.loads((await database.fetchone("SELECT data_json FROM characters WHERE char_id = ?", (character.char_id,)))["data_json"]))
    expected_balance = 100_000
    for age in range(25, 30):
        interest = expected_balance * 35 // 1000
        expected_balance += interest
        async with database.transaction() as tx:
            progress = await service.advance_year(tx, char, previous_age=age, now=clock.value + age)
        char = progress.character
        if age < 29:
            assert char.bank == 400_000
    bond = await database.fetchone("SELECT status, balance_cents, maturity_age FROM savings_bonds WHERE char_id = ?", (character.char_id,))
    assert bond["status"] == "matured" and bond["balance_cents"] == expected_balance and bond["maturity_age"] == 30
    assert char.bank == 400_000 + expected_balance


@pytest.mark.asyncio
async def test_rental_income_vacancy_upkeep_and_life_engine_yearly_integration(database, life_engine):
    """Only an extra home rents; vacancy and upkeep feed the existing yearly life tick."""
    clock = Clock()
    character = await _adult(database, life_engine, 408, age=25, cash=0, bank=1_000_000)
    primary = await database.execute(
        "INSERT INTO family_assets(char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at) "
        "VALUES (?, 'item', 'starter_home', 1, 18000000, 18000000, 20, 0)", (character.char_id,),
    )
    await database.execute(
        "INSERT INTO family_assets(char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at) "
        "VALUES (?, 'item', 'suburban_house', 1, 35000000, 35000000, 22, 0)", (character.char_id,),
    )
    character = replace(character, housing_item_id=int(primary.lastrowid), housing_type=HousingType.OWNED)
    async with database.transaction() as tx:
        await tx.execute("UPDATE characters SET data_json = ? WHERE char_id = ?", (json.dumps(character.to_dict(), separators=(",", ":")), character.char_id))

    service = _service(database, life_engine, clock, MarketRNG(event_roll=0.5))
    async with database.transaction() as tx:
        progress = await service.advance_year(tx, character, previous_age=25, now=clock.value)
    assert progress.income_cents == 1_950_000  # $21,000 rent less $1,500 upkeep
    assert any("Suburban House was rented" in message for message in progress.messages)
    assert not any("Starter Home was" in message for message in progress.messages)

    # Next in-game year: a scripted 10% vacancy still incurs upkeep.
    vacant = _service(database, life_engine, clock, MarketRNG(event_roll=0.0))
    async with database.transaction() as tx:
        vacancy = await vacant.advance_year(tx, progress.character, previous_age=26, now=clock.value + 1)
    assert vacancy.income_cents == -150_000
    assert any("Suburban House was vacant" in message for message in vacancy.messages)

    # The real /life age transaction calls the same passive service and surfaces its result.
    integration_user = 409
    integ = await _adult(database, life_engine, integration_user, age=25, cash=0, bank=1_000_000)
    await database.execute(
        "INSERT INTO family_assets(char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at) "
        "VALUES (?, 'item', 'starter_home', 1, 18000000, 18000000, 20, 0)", (integ.char_id,),
    )
    await database.execute(
        "INSERT INTO family_assets(char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at) "
        "VALUES (?, 'item', 'suburban_house', 1, 35000000, 35000000, 22, 0)", (integ.char_id,),
    )
    home_row = await database.fetchone("SELECT asset_id FROM family_assets WHERE char_id = ? AND item_id = 'starter_home'", (integ.char_id,))
    current = await life_engine.get_active_character(integration_user)
    current = replace(current, housing_item_id=int(home_row["asset_id"]), housing_type=HousingType.OWNED)
    async with database.transaction() as tx:
        await tx.execute("UPDATE characters SET data_json = ? WHERE char_id = ?", (json.dumps(current.to_dict(), separators=(",", ":")), integ.char_id))
    outcome = await life_engine.age_up(integration_user)
    assert any("Suburban House was" in message for message in outcome.log_messages)
    income = await database.fetchone("SELECT rental_income_cents FROM investment_yearly_income WHERE char_id = ? AND age = 25", (integ.char_id,))
    assert income is not None
