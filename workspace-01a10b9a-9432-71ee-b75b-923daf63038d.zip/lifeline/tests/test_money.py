"""Tests for integer-cent money helpers."""
from decimal import Decimal

import pytest

from core.money import cents_to_dollars, dollars_to_cents, format_cents, parse_cents, scale_cents


def test_money_rounds_half_up_to_integer_cents():
    assert dollars_to_cents("1.234") == 123
    assert dollars_to_cents("1.235") == 124
    assert dollars_to_cents(Decimal("-1.235")) == -124


def test_parse_and_format_currency():
    assert parse_cents("$1,234.56") == 123456
    with pytest.raises(ValueError):
        parse_cents("-$12.30")
    assert format_cents(123456) == "$1,234.56"
    assert format_cents(-1230) == "-$12.30"
    assert format_cents(25, include_plus=True) == "+$0.25"


def test_cents_scale_and_roundtrip():
    assert scale_cents(101, 0.5) == 51
    assert cents_to_dollars(123) == Decimal("1.23")


def test_invalid_money_values_are_rejected():
    with pytest.raises(ValueError):
        parse_cents("not money")
    with pytest.raises(ValueError):
        dollars_to_cents("NaN")
    with pytest.raises(TypeError):
        format_cents(1.5)
