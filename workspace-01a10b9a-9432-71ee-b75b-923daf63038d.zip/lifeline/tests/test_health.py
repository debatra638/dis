"""Real health catalog, progression, care, insurance, mortality, and rollback tests."""
from __future__ import annotations

import json
from dataclasses import replace

import pytest

from core.config import GameBalance
from core.errors import InsufficientFunds, ValidationError
from core.health import calculate_mortality_risk
from core.life_engine import LifeEngine
from core.models import Character, DiseaseStatus, HousingType, Stats
from core.rng import RNG


async def set_character(engine: LifeEngine, user_id: int, **changes: object) -> Character:
    """Save explicit health-test inputs through the standard optimistic transaction."""
    async with engine.db.transaction() as tx:
        row = await engine.economy.repository.active_character(tx, user_id)
        character = Character.from_dict(json.loads(row["data_json"]))
        character.char_id = int(row["char_id"])
        character.user_id = int(row["user_id"])
        character.version = int(row["version"])
        updated = replace(character, **changes, version=character.version + 1)
        await engine._save_character(tx, updated, expected_version=character.version)
        return updated


async def add_condition(
    engine: LifeEngine,
    character: Character,
    disease_id: str,
    *,
    severity: int = 3,
    age: int | None = None,
    chronic: bool = True,
    years_untreated: int = 0,
) -> int:
    """Insert a catalog condition and optionally age its untreated ledger."""
    onset_age = character.age if age is None else age
    async with engine.db.transaction() as tx:
        await engine.health.repository.add_condition(
            tx,
            char_id=character.char_id,
            disease_id=disease_id,
            severity=severity,
            age=onset_age,
            duration_years=0 if chronic else 3,
            chronic=chronic,
            now=1_800_000_000,
        )
        row = await engine.health.repository.condition(tx, character.char_id, disease_id)
        await tx.execute(
            "UPDATE health_conditions SET years_untreated = ? WHERE condition_id = ?",
            (years_untreated, int(row["condition_id"])),
        )
        return int(row["condition_id"])


@pytest.mark.asyncio
async def test_every_disease_definition_is_loaded_and_validated(life_engine: LifeEngine) -> None:
    assert len(life_engine.health.diseases) == 28
    assert "gambling_addiction" in life_engine.health.diseases
    for disease_id, definition in life_engine.health.diseases.items():
        assert disease_id == definition["id"]
        assert 0 <= float(definition["base_probability"]) <= 1
        assert 1 <= int(definition["severity_min"]) <= int(definition["severity_max"]) <= 5
        assert int(definition["min_age"]) <= int(definition["max_age"]) <= 120


@pytest.mark.asyncio
async def test_catalog_conditions_onset_with_undetected_symptoms_and_health_deltas(life_engine, monkeypatch) -> None:
    user_id = 881_001
    await life_engine.create_character(user_id, "Onset Test")
    character = await set_character(life_engine, user_id, age=29, stats=Stats(health=100, fitness=50))
    monkeypatch.setattr(life_engine.health.rng, "random", lambda: 0.0)
    monkeypatch.setattr(life_engine.health.rng, "randint", lambda low, high: low)
    aged = replace(character, age=30)
    async with life_engine.db.transaction() as tx:
        result = await life_engine.health.advance_year(tx, aged, previous_age=29, now=1_800_000_001)
        rows = await life_engine.health.repository.conditions(tx, character.char_id, active_only=True)
    expected_delta = sum(
        int(definition["annual_health_delta"])
        for definition in life_engine.health.diseases.values()
        if float(definition["base_probability"]) > 0
    )
    assert len(rows) == 27  # gambling addiction is only created by the casino rules
    assert all(not bool(row["diagnosed"]) for row in rows)
    assert result.character.stats.health == max(0, 100 + expected_delta)
    assert any("undiagnosed" in message.lower() for message in result.messages)


@pytest.mark.asyncio
async def test_disease_onset_balance_multiplier_scales_catalog_probability(life_engine, monkeypatch) -> None:
    """Apply the configured incidence multiplier without suppressing zero-risk cases."""
    user_id = 881_021
    await life_engine.create_character(user_id, "Incidence Balance")
    character = await set_character(
        life_engine, user_id, age=0, stats=Stats(health=60, fitness=50)
    )
    for definition in life_engine.health.diseases.values():
        definition["base_probability"] = 0.0
    life_engine.health.diseases["common_cold"]["base_probability"] = 0.055
    monkeypatch.setattr(GameBalance, "HEALTH_DISEASE_ONSET_MULTIPLIER", 0.10)
    monkeypatch.setattr(life_engine.health.rng, "random", lambda: 0.01)
    monkeypatch.setattr(life_engine.health.rng, "randint", lambda low, high: low)

    age_one = replace(character, age=1)
    async with life_engine.db.transaction() as tx:
        reduced_risk = await life_engine.health.advance_year(
            tx, age_one, previous_age=0, now=1_800_000_001
        )
    assert not await life_engine.db.fetchone(
        "SELECT 1 FROM health_conditions WHERE char_id = ? AND disease_id = 'common_cold'",
        (character.char_id,),
    )

    monkeypatch.setattr(GameBalance, "HEALTH_DISEASE_ONSET_MULTIPLIER", 1.0)
    async with life_engine.db.transaction() as tx:
        full_risk = await life_engine.health.advance_year(
            tx, replace(reduced_risk.character, age=2), previous_age=1, now=1_800_000_002
        )
    condition = await life_engine.db.fetchone(
        "SELECT 1 FROM health_conditions WHERE char_id = ? AND disease_id = 'common_cold'",
        (character.char_id,),
    )
    assert condition is not None
    assert full_risk.character.stats.health == 59


@pytest.mark.asyncio
async def test_untreated_chronic_condition_progression_is_persisted(life_engine, monkeypatch) -> None:
    user_id = 881_002
    await life_engine.create_character(user_id, "Progression Test")
    character = await set_character(life_engine, user_id, age=30, stats=Stats(health=90, fitness=50))
    condition_id = await add_condition(
        life_engine, character, "heart_condition", severity=2, age=25, chronic=True, years_untreated=2
    )
    for disease_id, definition in life_engine.health.diseases.items():
        if disease_id != "heart_condition":
            definition["base_probability"] = 0.0
    monkeypatch.setattr(life_engine.health.rng, "random", lambda: 0.0)
    async with life_engine.db.transaction() as tx:
        result = await life_engine.health.advance_year(
            tx, replace(character, age=31), previous_age=30, now=1_800_000_002
        )
        row = await life_engine.health.repository.condition(tx, character.char_id, "heart_condition")
    assert int(row["condition_id"]) == condition_id
    assert int(row["severity"]) == 3
    assert int(row["progression_count"]) == 1
    assert int(row["years_untreated"]) == 3
    assert str(row["status"]) == DiseaseStatus.CHRONIC.value
    assert result.character.stats.health == 89


@pytest.mark.asyncio
async def test_doctor_hospital_therapy_and_surgery_treat_conditions(database, life_engine) -> None:
    user_id = 881_003
    await life_engine.create_character(user_id, "Care Test")
    character = await set_character(
        life_engine, user_id, age=30, cash=0, bank=10_000_000,
        stats=Stats(health=50, happiness=40, stress=60, fitness=40),
    )
    heart_id = await add_condition(life_engine, character, "heart_condition", severity=4)
    doctor = await life_engine.health.doctor_visit(user_id, "heart_condition")
    assert doctor.cost_cents > 0
    row = await database.fetchone("SELECT * FROM health_conditions WHERE condition_id = ?", (heart_id,))
    assert bool(row["diagnosed"]) and row["severity"] == 3 and row["last_treated_age"] == 30
    hospital = await life_engine.health.hospital_visit(user_id, "heart_condition")
    row = await database.fetchone("SELECT severity, status FROM health_conditions WHERE condition_id = ?", (heart_id,))
    assert row["severity"] == 1 and row["status"] == "chronic"
    assert hospital.character.stats.health >= doctor.character.stats.health

    depression_id = await add_condition(life_engine, character, "depressive_episode", severity=2)
    therapy = await life_engine.health.therapy_visit(user_id)
    row = await database.fetchone("SELECT severity, diagnosed FROM health_conditions WHERE condition_id = ?", (depression_id,))
    assert row["severity"] == 1 and bool(row["diagnosed"])
    assert therapy.character.stats.happiness >= 44 and therapy.character.stats.stress <= 52

    surgery_id = await add_condition(life_engine, character, "arthritis", severity=4)
    surgery = await life_engine.health.surgery(user_id, "arthritis")
    row = await database.fetchone("SELECT severity, status, is_active FROM health_conditions WHERE condition_id = ?", (surgery_id,))
    assert row["severity"] == 1 and row["status"] == "cured" and row["is_active"] == 0
    assert surgery.cost_cents > hospital.cost_cents
    current, conditions, visits = await life_engine.health.status(user_id)
    assert current.stats.health >= 50
    assert len(visits) == 4
    assert {row["visit_type"] for row in visits} == {"doctor", "hospital", "therapy", "surgery"}


@pytest.mark.asyncio
async def test_plastic_surgery_is_adult_elective_noninsured_and_once_per_year(database, life_engine) -> None:
    user_id = 881_026
    await life_engine.create_character(user_id, "Plastic Surgery Test")
    character = await set_character(
        life_engine,
        user_id,
        age=30,
        cash=500_000,
        bank=5_000_000,
        has_insurance=True,
        insurance_paid_through_age=31,
        stats=Stats(health=72, looks=48),
    )
    expected_cost = life_engine.health._medical_cost(
        character, GameBalance.HEALTH_PLASTIC_SURGERY_FEE_CENTS, insured=False
    )
    insured_cost = life_engine.health._medical_cost(
        character, GameBalance.HEALTH_PLASTIC_SURGERY_FEE_CENTS, insured=True
    )

    result = await life_engine.health.surgery(user_id, procedure="plastic")

    assert result.cost_cents == expected_cost > insured_cost
    assert result.character.stats.looks == 48 + GameBalance.HEALTH_PLASTIC_SURGERY_LOOKS_BONUS
    assert result.character.stats.health == 72
    assert result.character.has_insurance is True
    assert "not covered by insurance" in result.message
    row = await database.fetchone(
        "SELECT * FROM health_visits WHERE char_id = ? AND visit_type = 'surgery'",
        (character.char_id,),
    )
    assert row["disease_id"] is None
    outcome = json.loads(row["outcome_json"])
    assert outcome == {
        "insured": False,
        "looks_after": result.character.stats.looks,
        "looks_before": 48,
        "result": "plastic_surgery_success",
    }
    with pytest.raises(ValidationError, match="already been used"):
        await life_engine.health.surgery(user_id, procedure="plastic")


@pytest.mark.asyncio
async def test_plastic_surgery_validates_adult_status_and_rolls_back_failed_charges(
    database, life_engine
) -> None:
    minor_id = 881_027
    await life_engine.create_character(minor_id, "Minor Surgery Test")
    minor = await set_character(
        life_engine, minor_id, age=17, bank=5_000_000, stats=Stats(looks=40)
    )
    before_minor = await database.fetchone(
        "SELECT data_json FROM characters WHERE char_id = ?", (minor.char_id,)
    )
    with pytest.raises(ValidationError, match="age 18"):
        await life_engine.health.surgery(minor_id, procedure="plastic")
    after_minor = await database.fetchone(
        "SELECT data_json FROM characters WHERE char_id = ?", (minor.char_id,)
    )
    assert json.loads(after_minor["data_json"]) == json.loads(before_minor["data_json"])

    broke_id = 881_028
    await life_engine.create_character(broke_id, "No Funds Surgery Test")
    broke = await set_character(
        life_engine, broke_id, age=28, cash=0, bank=0, stats=Stats(looks=40)
    )
    before_broke = await database.fetchone(
        "SELECT data_json FROM characters WHERE char_id = ?", (broke.char_id,)
    )
    with pytest.raises(InsufficientFunds):
        await life_engine.health.surgery(broke_id, procedure="plastic")
    after_broke = await database.fetchone(
        "SELECT data_json FROM characters WHERE char_id = ?", (broke.char_id,)
    )
    assert json.loads(after_broke["data_json"]) == json.loads(before_broke["data_json"])
    assert await database.fetchone(
        "SELECT 1 FROM health_visits WHERE char_id = ? AND visit_type = 'surgery'",
        (broke.char_id,),
    ) is None


@pytest.mark.asyncio
async def test_plastic_surgery_rolls_back_when_visit_ledger_fails(
    database, life_engine, monkeypatch
) -> None:
    user_id = 881_029
    await life_engine.create_character(user_id, "Surgery Ledger Rollback")
    character = await set_character(
        life_engine, user_id, age=35, bank=5_000_000, stats=Stats(looks=40)
    )
    before = await database.fetchone(
        "SELECT data_json FROM characters WHERE char_id = ?", (character.char_id,)
    )

    async def fail(*args: object, **kwargs: object) -> int:
        raise RuntimeError("injected plastic-surgery ledger failure")

    monkeypatch.setattr(life_engine.health.repository, "record_visit", fail)
    with pytest.raises(RuntimeError, match="plastic-surgery ledger failure"):
        await life_engine.health.surgery(user_id, procedure="plastic")
    after = await database.fetchone(
        "SELECT data_json FROM characters WHERE char_id = ?", (character.char_id,)
    )
    assert json.loads(after["data_json"]) == json.loads(before["data_json"])
    assert await database.fetchone(
        "SELECT 1 FROM health_visits WHERE char_id = ? AND visit_type = 'surgery'",
        (character.char_id,),
    ) is None


@pytest.mark.asyncio
async def test_doctor_visit_is_atomic_when_visit_ledger_fails(database, life_engine, monkeypatch) -> None:
    user_id = 881_004
    await life_engine.create_character(user_id, "Health Rollback")
    character = await set_character(life_engine, user_id, age=35, bank=1_000_000)
    condition_id = await add_condition(life_engine, character, "asthma", severity=3)
    before = await database.fetchone("SELECT data_json FROM characters WHERE char_id = ?", (character.char_id,))
    original = life_engine.health.repository.record_visit

    async def fail(*args: object, **kwargs: object) -> int:
        raise RuntimeError("injected health visit failure")

    monkeypatch.setattr(life_engine.health.repository, "record_visit", fail)
    with pytest.raises(RuntimeError, match="injected"):
        await life_engine.health.doctor_visit(user_id, "asthma")
    monkeypatch.setattr(life_engine.health.repository, "record_visit", original)
    after = await database.fetchone("SELECT data_json FROM characters WHERE char_id = ?", (character.char_id,))
    condition = await database.fetchone("SELECT * FROM health_conditions WHERE condition_id = ?", (condition_id,))
    assert json.loads(after["data_json"]) == json.loads(before["data_json"])
    assert condition["severity"] == 3 and condition["diagnosed"] == 0
    assert await database.fetchone("SELECT 1 FROM health_visits WHERE char_id = ?", (character.char_id,)) is None


@pytest.mark.asyncio
async def test_activity_effects_once_per_year_and_insurance_copay(life_engine) -> None:
    user_id = 881_005
    await life_engine.create_character(user_id, "Fitness Test")
    character = await set_character(
        life_engine, user_id, age=25, bank=2_000_000,
        stats=Stats(health=50, fitness=50, happiness=50, stress=50),
    )
    result = await life_engine.health.activity(user_id, "run")
    assert (result.character.stats.health, result.character.stats.fitness) == (52, 53)
    assert result.character.stats.happiness == 51 and result.character.stats.stress == 48
    with pytest.raises(ValidationError, match="already been used"):
        await life_engine.health.activity(user_id, "run")

    purchased = await life_engine.health.set_insurance(user_id, True)
    assert purchased.character.has_insurance is True
    assert purchased.character.insurance_paid_through_age == 26
    assert purchased.cost_cents > 0
    doctor = await life_engine.health.doctor_visit(user_id)
    assert doctor.cost_cents == (GameBalance.HEALTH_DOCTOR_FEE_CENTS * GameBalance.HEALTH_INSURANCE_COPAY_PERCENT + 99) // 100
    cancelled = await life_engine.health.set_insurance(user_id, False)
    assert cancelled.character.has_insurance is False


@pytest.mark.asyncio
async def test_expired_insurance_renews_in_annual_settlement(database, life_engine, monkeypatch) -> None:
    user_id = 881_006
    await life_engine.create_character(user_id, "Insurance Renewal")
    character = await set_character(
        life_engine, user_id, age=22, bank=20_000_000, has_insurance=True,
        insurance_paid_through_age=21, housing_type=HousingType.PARENTS,
        wealth_class="rich",
    )
    monkeypatch.setattr(GameBalance, "BANK_THEFT_ANNUAL_CHANCE", 0.0)
    async with database.transaction() as tx:
        result = await life_engine.economy.advance_year(
            tx, character, previous_age=21, now=1_800_000_010
        )
    assert result.character.has_insurance is True
    assert result.character.insurance_paid_through_age == 22
    assert any("insurance renewed" in message.lower() for message in result.messages)


@pytest.mark.asyncio
async def test_life_engine_age_tick_integrates_disease_mortality_and_archive(database, life_engine, monkeypatch) -> None:
    user_id = 881_007
    await life_engine.create_character(user_id, "Illness Tick")
    await set_character(
        life_engine, user_id, age=30, cash=0, bank=5_000_000,
        stats=Stats(health=1, fitness=20, happiness=50),
    )
    monkeypatch.setattr(life_engine.health.rng, "random", lambda: 0.0)
    monkeypatch.setattr(life_engine.health.rng, "randint", lambda low, high: low)
    outcome = await life_engine.age_up(user_id)
    assert outcome.died is True
    assert outcome.death_cause is not None and outcome.death_cause.startswith("illness:")
    assert any("undiagnosed" in message.lower() for message in outcome.log_messages)
    archive = await database.fetchone("SELECT death_cause, summary_json FROM past_lives WHERE user_id = ?", (user_id,))
    assert archive is not None and archive["death_cause"] == outcome.death_cause
    assert await database.fetchone("SELECT 1 FROM characters WHERE user_id = ? AND is_alive = 1", (user_id,)) is None


@pytest.mark.asyncio
async def test_mortality_competing_hazards_and_cause_selection(life_engine) -> None:
    healthy = Character(age=30, stats=Stats(health=100, fitness=100))
    severe = {"disease_id": "heart_condition", "severity": 5, "years_untreated": 10,
              "status": "chronic", "is_active": 1}
    baseline = calculate_mortality_risk(healthy, [])
    illness = calculate_mortality_risk(healthy, [severe])
    frail = calculate_mortality_risk(replace(healthy, stats=Stats(health=10, fitness=10)), [])
    assert illness.illness_hazard > baseline.illness_hazard
    assert illness.total_probability > baseline.total_probability
    assert frail.natural_hazard > baseline.natural_hazard

    dead, cause, risk = life_engine.health.resolve_mortality(
        replace(healthy, age=GameBalance.MAX_AGE), [severe], now=1_800_000_020
    )
    assert not dead.is_alive and cause == "natural causes" and risk.total_probability == 1.0
    ill, cause, risk = life_engine.health.resolve_mortality(
        replace(healthy, stats=Stats(health=0)), [severe], now=1_800_000_021
    )
    assert not ill.is_alive and cause == "illness: Heart condition" and risk.illness_hazard == 1.0


def test_mortality_probability_is_monotone_in_illness_and_health() -> None:
    character = Character(age=60, stats=Stats(health=70, fitness=50))
    light = {"disease_id": "asthma", "severity": 1, "years_untreated": 0, "is_active": 1, "status": "active"}
    heavy = {**light, "severity": 5, "years_untreated": 10, "status": "chronic"}
    assert calculate_mortality_risk(character, [heavy]).total_probability > calculate_mortality_risk(character, [light]).total_probability


@pytest.mark.asyncio
async def test_annual_addiction_health_damage_accumulates_fractional_points(life_engine, monkeypatch) -> None:
    """Carry sub-point damage so repeated addiction/20 loss is not rounded away."""
    user_id = 881_030
    await life_engine.create_character(user_id, "Addiction Damage")
    character = await set_character(
        life_engine,
        user_id,
        age=30,
        stats=Stats(health=80, addiction=11),
        addiction_health_remainder=0.0,
    )
    monkeypatch.setattr(life_engine.health.rng, "random", lambda: 1.0)
    for age in range(31, 36):
        async with life_engine.db.transaction() as tx:
            result = await life_engine.health.advance_year(
                tx, replace(character, age=age), previous_age=age - 1,
                now=1_800_000_100 + age,
            )
        character = result.character
    assert character.stats.health == 78
    assert character.addiction_health_remainder == pytest.approx(0.75)
    restored = Character.from_dict(character.to_dict())
    assert restored.addiction_health_remainder == pytest.approx(0.75)


@pytest.mark.asyncio
async def test_addiction_homelessness_and_prison_multiply_natural_mortality() -> None:
    """Apply the specified additive lifestyle factors to the baseline natural hazard."""
    baseline = Character(age=60, stats=Stats(health=80, fitness=50, addiction=0))
    base_risk = calculate_mortality_risk(baseline, []).natural_hazard
    addicted = replace(baseline, stats=replace(baseline.stats, addiction=100))
    homeless = replace(baseline, housing_type=HousingType.HOMELESS)
    imprisoned = replace(baseline, in_prison=True)
    assert calculate_mortality_risk(addicted, []).natural_hazard == pytest.approx(base_risk * 1.5)
    assert calculate_mortality_risk(homeless, []).natural_hazard == pytest.approx(base_risk * 1.3)
    assert calculate_mortality_risk(imprisoned, []).natural_hazard == pytest.approx(base_risk * 1.2)
