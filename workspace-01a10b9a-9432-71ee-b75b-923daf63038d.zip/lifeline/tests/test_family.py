"""Runnable Stage 6 tests for family, dating, support, and divorce rules."""
from __future__ import annotations

import json
from dataclasses import replace
from typing import Any

import pytest

from core.config import GameBalance
from core.errors import FamilyRequirementError, InteractionLimitReached
from core.family import (
    FamilyService,
    calculate_alimony,
    calculate_divorce_split,
    calculate_fertility_factor,
    can_date_ages,
    proposal_acceptance_chance,
)
from core.repositories.family import FamilyRepository
from core.rng import RNG
from core.money import payout_cents


async def _set_character(database: Any, character: Any, **changes: Any) -> Any:
    """Persist test-only character state through the database transaction API."""
    updated = replace(character, **changes)
    async with database.transaction() as tx:
        await tx.execute(
            """UPDATE characters SET age = ?, stats_json = ?, data_json = ? WHERE char_id = ?""",
            (
                updated.age,
                json.dumps(updated.stats.to_dict(), separators=(",", ":")),
                json.dumps(updated.to_dict(), separators=(",", ":")),
                updated.char_id,
            ),
        )
    return updated


async def _add_npc(
    repository: FamilyRepository,
    tx: Any,
    *,
    char_id: int,
    name: str = "Jordan",
    age: int = 30,
    gender: str = "female",
    wealth: int = 10_000_000,
    annual_income: int = 5_000_000,
    relation: str = "friend",
    score: int = 80,
    since_age: int = 18,
) -> int:
    """Create one deterministic NPC and connect it to the test life."""
    npc_id = await repository.create_npc(
        tx,
        owner_char_id=char_id,
        name=name,
        gender=gender,
        age=age,
        looks=55,
        smarts=60,
        health=85,
        wealth=wealth,
        occupation="Engineer",
        country="usa",
        annual_income=annual_income,
        prefers_smarts=True,
    )
    await repository.create_relationship(
        tx,
        char_id=char_id,
        npc_id=npc_id,
        relation_type=relation,
        score=score,
        since_age=since_age,
    )
    return npc_id


async def _add_marriage(
    database: Any,
    character: Any,
    *,
    spouse_income: int = 5_000_000,
    prenup: bool = False,
    premarital_cash: int = 0,
    premarital_bank: int = 0,
    start_age: int | None = None,
) -> int:
    """Create an adult spouse and a persisted wedding record for settlement tests."""
    repository = FamilyRepository(database)
    async with database.transaction() as tx:
        spouse_id = await _add_npc(
            repository,
            tx,
            char_id=character.char_id,
            name="Morgan Spouse",
            age=max(18, character.age),
            gender="female",
            annual_income=spouse_income,
            relation="spouse",
            since_age=max(0, character.age - 1),
        )
        start = max(18, character.age - 2) if start_age is None else start_age
        await repository.create_marriage(
            tx,
            char_id=character.char_id,
            spouse_npc_id=spouse_id,
            start_age=start,
            spouse_income=spouse_income,
            prenup=prenup,
            premarital_cash=premarital_cash,
            premarital_bank=premarital_bank,
            wedding_cost=10_000,
            created_at=int(character.last_age_at or 1_800_000_000),
        )
    return spouse_id


@pytest.mark.asyncio
async def test_family_birth_generates_two_parents_and_zero_to_three_siblings(life_engine):
    """Birth setup creates the requested relatives with class-aligned parent wealth."""
    character = await life_engine.create_character(2101, "Family Test", country="in")
    people = await life_engine.db.fetchall(
        """SELECT r.type, r.score, n.age, n.gender, n.wealth, n.country, n.occupation
           FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
           WHERE r.char_id = ?""",
        (character.char_id,),
    )
    parents = [row for row in people if row["type"] == "parent"]
    siblings = [row for row in people if row["type"] == "sibling"]
    assert len(parents) == 2
    assert 0 <= len(siblings) <= 3
    assert {row["gender"] for row in parents} == {"male", "female"}
    assert all(60 <= row["score"] <= 90 for row in parents + siblings)
    assert all(22 <= row["age"] <= 40 and row["country"] == "in" for row in parents)
    wealth_ranges = {
        "poor": (100_000, 1_500_000),
        "working": (1_500_000, 8_000_000),
        "middle": (8_000_000, 60_000_000),
        "upper": (60_000_000, 500_000_000),
        "rich": (500_000_000, 5_000_000_000),
    }
    minimum, maximum = wealth_ranges[character.wealth_class]
    assert all(minimum <= row["wealth"] <= maximum for row in parents + siblings)
    assert all(row["occupation"] == "Student" for row in siblings)


def test_minors_cannot_date_adults_and_minor_age_gap_is_two_years():
    """The engine's reusable dating rule rejects adult/minor pairings explicitly."""
    assert can_date_ages(16, 14) is True
    assert can_date_ages(17, 15) is True
    assert can_date_ages(16, 13) is False
    assert can_date_ages(17, 18) is False
    assert can_date_ages(18, 17) is False
    assert can_date_ages(18, 23) is True
    assert can_date_ages(18, 24) is False


@pytest.mark.asyncio
async def test_date_search_generates_three_minor_candidates_and_engine_rejects_adult(database, life_engine):
    """Date options obey the minor rule and forged adult candidates fail server-side."""
    character = await life_engine.create_character(2102, "Minor Date")
    character = await _set_character(database, character, age=17)
    search = await life_engine.family.find_dates(2102)
    assert len(search.candidates) == 3
    assert all(person["age"] < 18 and abs(person["age"] - 17) <= 2 for person in search.candidates)
    candidate_id = int(search.candidates[0]["npc_id"])
    await database.execute("UPDATE npcs SET age = 18 WHERE npc_id = ?", (candidate_id,))
    with pytest.raises(FamilyRequirementError, match="Dating age rules"):
        await life_engine.family.choose_date(2102, candidate_id, search.nonce)


def test_dating_success_formula_is_clamped_to_five_and_ninety_percent():
    """The date formula weights smarts at 0.4 and clamps chance to 5–90%."""
    from core.family import dating_success_chance

    assert dating_success_chance(
        player_looks=50, npc_looks=45, player_smarts=70, npc_smarts=50,
        npc_prefers_smarts=True, fame=50, npc_wealth=100_000_000,
    ) == 72.0
    assert dating_success_chance(
        player_looks=100, npc_looks=0, player_smarts=100, npc_smarts=0,
        npc_prefers_smarts=True, fame=100, npc_wealth=100_000_000,
    ) == 90.0
    assert dating_success_chance(
        player_looks=0, npc_looks=100, player_smarts=0, npc_smarts=100,
        npc_prefers_smarts=True, fame=0, npc_wealth=0,
    ) == 5.0


@pytest.mark.asyncio
async def test_three_interactions_per_person_per_year(database, life_engine):
    """Each person has an independent persistent three-action annual cap."""
    character = await life_engine.create_character(2103, "Interaction Test")
    await _set_character(database, character, age=18)
    person = await life_engine.family.find_friend(2103)
    npc_id = int(person["npc_id"])
    for _ in range(3):
        await life_engine.family.interact(2103, npc_id, "spend_time")
    with pytest.raises(InteractionLimitReached):
        await life_engine.family.interact(2103, npc_id, "compliment")


@pytest.mark.parametrize(
    ("age", "expected"),
    [(20, 1.0), (29, 1.0), (30, 1.0), (32, 0.88), (35, 0.7), (37, 0.54), (40, 0.3), (43, 0.15), (45, 0.05), (50, 0.0)],
)
def test_fertility_curve_values(age: int, expected: float):
    """The fertility curve has the specified anchors and linear interpolation."""
    assert calculate_fertility_factor(age) == pytest.approx(expected)


def test_proposal_acceptance_bounds():
    """Proposal score and ring bonuses are clamped to valid probability bounds."""
    assert proposal_acceptance_chance(0, 0) == 0
    assert proposal_acceptance_chance(80, 14) == 74
    assert proposal_acceptance_chance(100, 99) == 100


def test_divorce_split_math_with_and_without_prenup():
    """Prenups protect liquid premarital balances while marital property splits evenly."""
    unprotected = calculate_divorce_split(
        cash=1_000_000,
        bank=3_000_000,
        marital_item_values=[400_000, 1_500_000],
        prenup=False,
    )
    protected = calculate_divorce_split(
        cash=1_000_000,
        bank=3_000_000,
        marital_item_values=[400_000, 1_500_000],
        prenup=True,
        premarital_cash=500_000,
        premarital_bank=1_000_000,
    )
    assert unprotected.eligible_assets == 5_900_000
    assert unprotected.spouse_share == 2_950_000
    assert unprotected.protected_assets == 0
    assert protected.eligible_assets == 4_400_000
    assert protected.spouse_share == 2_200_000
    assert protected.protected_assets == 1_500_000


def test_alimony_calculation_uses_twenty_percent_and_half_marriage_duration():
    """Alimony uses the income gap, paying direction, and half the marriage years."""
    player_pays, annual, years = calculate_alimony(10_000_000, 5_000_000, 4)
    assert player_pays is True
    assert annual == 1_000_000
    assert years == 2.0
    player_pays, annual, years = calculate_alimony(3_000_000, 8_000_000, 3)
    assert player_pays is False
    assert annual == 1_000_000
    assert years == 1.5


@pytest.mark.asyncio
async def test_npcs_age_die_and_parent_inheritance_is_shared_and_taxed(database, life_engine):
    """The age tick advances an NPC to death, applies grief, and credits net inheritance."""
    character = await life_engine.create_character(2104, "Inheritance Test")
    parents = await database.fetchall(
        """SELECT n.npc_id, n.wealth FROM npcs AS n JOIN relationships AS r ON r.npc_id=n.npc_id
           WHERE r.char_id=? AND r.type='parent' ORDER BY n.npc_id""",
        (character.char_id,),
    )
    parent_id = int(parents[0]["npc_id"])
    parent_wealth = 150_000_000
    await database.execute(
        "UPDATE npcs SET age = 119, health = 100, wealth = ? WHERE npc_id = ?",
        (parent_wealth, parent_id),
    )
    sibling_count = int((await database.fetchone(
        "SELECT COUNT(*) AS count FROM relationships WHERE char_id=? AND type='sibling'",
        (character.char_id,),
    ))["count"])
    gross = parent_wealth // (sibling_count + 1)
    inheritance_base = payout_cents(gross, GameBalance.INHERITANCE_BASE_MULTIPLIER)
    threshold = 100_000_000
    tax = max(0, inheritance_base - threshold) // 10
    expected_inheritance = inheritance_base - tax

    outcome = await life_engine.age_up(2104)
    parent = await database.fetchone("SELECT age, is_alive, death_age, wealth FROM npcs WHERE npc_id=?", (parent_id,))
    assert parent["age"] == 120
    assert parent["is_alive"] == 0
    assert parent["death_age"] == 120
    assert parent["wealth"] == 0
    # Savings interest is credited after annual income/tax and family inheritance settle.
    assert outcome.character.bank == expected_inheritance + expected_inheritance // 100
    assert any("inheritance after tax" in message for message in outcome.log_messages)
    assert outcome.character.stats.happiness < character.stats.happiness


@pytest.mark.asyncio
async def test_child_support_deducts_income_and_stops_at_age_eighteen(database, life_engine):
    """Shared-custody support is 15% of gross income and ends on the 18th birthday."""
    character = await life_engine.create_character(2105, "Support Test")
    character = await _set_character(
        database, character, age=30, cash=10_000_000, wealth_class="middle"
    )
    repository = FamilyRepository(database)
    async with database.transaction() as tx:
        other_parent = int((await repository.parent_relations(tx, character.char_id))[0]["npc_id"])
        child_id = await repository.create_npc(
            tx,
            owner_char_id=character.char_id,
            name="Child Support NPC",
            gender="male",
            age=16,
            looks=50,
            smarts=50,
            health=85,
            wealth=0,
            occupation="Student",
            country="usa",
        )
        await repository.create_relationship(
            tx,
            char_id=character.char_id,
            npc_id=child_id,
            relation_type="child",
            score=85,
            since_age=20,
        )
        await repository.add_child(
            tx,
            npc_id=child_id,
            char_id=character.char_id,
            other_parent_npc_id=other_parent,
            custody="shared",
            child_support=150_000,
        )

    first = replace(character, age=31)
    async with database.transaction() as tx:
        result_one = await life_engine.family.advance_year(
            tx, first, previous_age=30, personal_income=1_000_000, now=101
        )
    assert result_one.character.cash == 9_250_000  # $6,000 shared-care cost + $1,500 support.
    assert int((await database.fetchone("SELECT child_support FROM children WHERE npc_id=?", (child_id,)))["child_support"]) == 150_000

    second = replace(result_one.character, age=32)
    async with database.transaction() as tx:
        result_two = await life_engine.family.advance_year(
            tx, second, previous_age=31, personal_income=1_000_000, now=102
        )
    assert result_two.character.cash == second.cash
    assert int((await database.fetchone("SELECT child_support FROM children WHERE npc_id=?", (child_id,)))["child_support"]) == 0
    assert any("ended for Child Support NPC at age 18" in message for message in result_two.messages)


@pytest.mark.asyncio
async def test_deceased_minor_child_stops_costs_and_support(database, life_engine):
    """A deceased minor remains in records but generates no annual expense or support."""
    character = await life_engine.create_character(2111, "Deceased Child Test")
    character = await _set_character(database, character, age=30, cash=5_000_000)
    repository = FamilyRepository(database)
    async with database.transaction() as tx:
        parent_id = int((await repository.parent_relations(tx, character.char_id))[0]["npc_id"])
        child_id = await repository.create_npc(
            tx,
            owner_char_id=character.char_id,
            name="Deceased Minor",
            gender="female",
            age=12,
            looks=50,
            smarts=50,
            health=0,
            wealth=0,
            occupation="Student",
            country="usa",
        )
        await tx.execute("UPDATE npcs SET is_alive=0, death_age=12 WHERE npc_id=?", (child_id,))
        await repository.create_relationship(
            tx,
            char_id=character.char_id,
            npc_id=child_id,
            relation_type="child",
            score=85,
            since_age=25,
        )
        await repository.add_child(
            tx,
            npc_id=child_id,
            char_id=character.char_id,
            other_parent_npc_id=parent_id,
            custody="shared",
            child_support=200_000,
        )
    async with database.transaction() as tx:
        result = await life_engine.family.advance_year(
            tx, replace(character, age=31), previous_age=30, personal_income=1_000_000, now=104
        )
    assert result.character.cash == character.cash
    support_row = await database.fetchone("SELECT child_support FROM children WHERE npc_id=?", (child_id,))
    assert support_row["child_support"] == 0
    assert any("after their death" in message for message in result.messages)


@pytest.mark.asyncio
async def test_divorce_does_not_create_support_for_a_deceased_minor(database, life_engine):
    """A late divorce clears support for a deceased child instead of opening a new order."""
    character = await life_engine.create_character(2115, "Deceased Custody Test")
    character = await _set_character(database, character, age=30, cash=5_000_000, bank=5_000_000)
    await _add_marriage(database, character, spouse_income=0)
    repository = FamilyRepository(database)
    async with database.transaction() as tx:
        child_id = await repository.create_npc(
            tx,
            owner_char_id=character.char_id,
            name="Child Who Passed",
            gender="male",
            age=12,
            looks=45,
            smarts=55,
            health=0,
            wealth=0,
            occupation="Student",
            country="usa",
        )
        await tx.execute("UPDATE npcs SET is_alive=0, death_age=12 WHERE npc_id=?", (child_id,))
        await repository.create_relationship(
            tx,
            char_id=character.char_id,
            npc_id=child_id,
            relation_type="child",
            score=70,
            since_age=25,
        )
        await repository.add_child(
            tx,
            npc_id=child_id,
            char_id=character.char_id,
            other_parent_npc_id=None,
            custody="shared",
            child_support=100_000,
        )
    outcome = await life_engine.family.divorce(2115)
    assert outcome.children == 0
    support = await database.fetchone("SELECT child_support FROM children WHERE npc_id=?", (child_id,))
    assert support["child_support"] == 0


@pytest.mark.asyncio
async def test_try_for_baby_is_limited_to_once_per_partner_per_year(database, life_engine, monkeypatch):
    """A failed conception cannot be spammed repeatedly in the same simulated year."""
    character = await life_engine.create_character(2112, "Baby Limit Test")
    character = await _set_character(database, character, age=30)
    spouse_id = await _add_marriage(database, character)
    monkeypatch.setattr(life_engine.family.rng, "random", lambda: 1.0)
    success, _ = await life_engine.family.try_for_baby(2112)
    assert not success
    with pytest.raises(FamilyRequirementError, match="once per year"):
        await life_engine.family.try_for_baby(2112)
    assert await database.fetchone("SELECT 1 FROM pregnancies WHERE char_id=?", (character.char_id,)) is None
    assert spouse_id > 0


@pytest.mark.asyncio
async def test_infidelity_choice_can_only_be_resolved_once_per_game_year(database, life_engine):
    """The spouse cannot receive repeated temptation prompts after choosing."""
    character = await life_engine.create_character(2113, "Temptation Limit Test")
    await _set_character(database, character, age=30)
    await _add_marriage(database, character)
    prompt = await life_engine.family.start_infidelity_choice(2113)
    await life_engine.family.resolve_infidelity_choice(2113, prompt.nonce, False)
    with pytest.raises(FamilyRequirementError, match="already been resolved"):
        await life_engine.family.start_infidelity_choice(2113)


@pytest.mark.asyncio
async def test_joint_spouse_income_is_taxed_with_doubled_brackets(database, life_engine):
    """The yearly marriage settlement adds spouse income and taxes the combined gross."""
    character = await life_engine.create_character(2106, "Joint Tax")
    character = await _set_character(database, character, age=30, cash=10_000_000)
    await _add_marriage(database, character, spouse_income=5_000_000)
    from core.family import calculate_joint_tax

    expected_tax = calculate_joint_tax(15_000_000)
    async with database.transaction() as tx:
        result = await life_engine.family.advance_year(
            tx, replace(character, age=31), previous_age=30, personal_income=10_000_000, now=103
        )
    assert result.character.cash == 15_000_000 - expected_tax
    assert any("joint tax" in message for message in result.messages)


class _FailingDivorceRepository(FamilyRepository):
    """Inject an exception after the divorce record write to verify rollback."""

    async def insert_divorce_record(self, tx: Any, **values: Any) -> None:
        await super().insert_divorce_record(tx, **values)
        raise RuntimeError("injected failure after divorce updates")


@pytest.mark.asyncio
async def test_divorce_exception_rolls_back_every_database_change(database, life_engine):
    """A mid-divorce exception leaves balances, marriage, and statistics unchanged."""
    character = await life_engine.create_character(2107, "Rollback Test")
    character = await _set_character(database, character, age=30, cash=8_000_000, bank=3_000_000)
    spouse_id = await _add_marriage(
        database,
        character,
        spouse_income=6_000_000,
        prenup=True,
        premarital_cash=2_000_000,
        premarital_bank=1_000_000,
    )
    service = FamilyService(
        database,
        RNG(991),
        life_engine.locks,
        repository=_FailingDivorceRepository(database),
        clock=lambda: 1_800_000_000,
    )
    before_character = await database.fetchone("SELECT data_json, version FROM characters WHERE char_id=?", (character.char_id,))
    before_marriage = await database.fetchone("SELECT * FROM marriages WHERE char_id=?", (character.char_id,))
    before_relationship = await database.fetchone("SELECT type, score FROM relationships WHERE char_id=? AND npc_id=?", (character.char_id, spouse_id))

    with pytest.raises(RuntimeError, match="injected failure"):
        await service.divorce(2107)

    after_character = await database.fetchone("SELECT data_json, version FROM characters WHERE char_id=?", (character.char_id,))
    after_marriage = await database.fetchone("SELECT * FROM marriages WHERE char_id=?", (character.char_id,))
    after_relationship = await database.fetchone("SELECT type, score FROM relationships WHERE char_id=? AND npc_id=?", (character.char_id, spouse_id))
    assert dict(after_character) == dict(before_character)
    assert dict(after_marriage) == dict(before_marriage)
    assert dict(after_relationship) == dict(before_relationship)
    assert await database.fetchone("SELECT 1 FROM stats_tracking WHERE char_id=?", (character.char_id,)) is None
    assert await database.fetchone("SELECT 1 FROM divorce_records WHERE char_id=?", (character.char_id,)) is None


@pytest.mark.asyncio
async def test_divorce_payment_cascade_never_makes_balances_negative(database, life_engine):
    """Very small balances become debt after the cascade, never negative cash/bank."""
    character = await life_engine.create_character(2108, "Low Funds")
    character = await _set_character(database, character, age=30, cash=50, bank=0, debt_total=0)
    await _add_marriage(database, character, spouse_income=0, prenup=False)
    outcome = await life_engine.family.divorce(2108)
    saved = await life_engine.get_active_character(2108)
    assert saved.cash >= 0
    assert saved.bank >= 0
    assert saved.debt_total >= 0
    assert saved.cash == 0
    assert saved.bank == 0
    assert saved.debt_total > 0
    assert outcome.spouse_share >= 0
    record = await database.fetchone("SELECT lawyer_fee FROM divorce_records WHERE char_id=?", (character.char_id,))
    assert 500_000 <= record["lawyer_fee"] <= 5_000_000


@pytest.mark.asyncio
async def test_adoption_completes_after_one_year_and_newborn_stays_age_zero(database, life_engine):
    """The indexed adoption fee is paid immediately and NPC child arrives one tick later."""
    character = await life_engine.create_character(2109, "Adoption Test")
    await _set_character(database, character, age=21, cash=4_000_000)
    cost = await life_engine.family.adopt(2109)
    assert cost == 3_000_000
    assert await database.fetchone("SELECT 1 FROM children WHERE char_id=?", (character.char_id,)) is None
    await life_engine.age_up(2109)
    child = await database.fetchone(
        """SELECT n.age, n.occupation, c.custody FROM children AS c
           JOIN npcs AS n ON n.npc_id=c.npc_id WHERE c.char_id=?""",
        (character.char_id,),
    )
    assert child["age"] == 0
    assert child["occupation"] == "Student"
    assert child["custody"] == "full"


@pytest.mark.asyncio
async def test_infidelity_choice_is_nonce_backed_and_stored(database, life_engine):
    """Cheating is a one-use owner-side choice persisted for yearly discovery checks."""
    character = await life_engine.create_character(2110, "Temptation Test")
    character = await _set_character(database, character, age=30)
    await _add_marriage(database, character)
    prompt = await life_engine.family.start_infidelity_choice(2110)
    message = await life_engine.family.resolve_infidelity_choice(2110, prompt.nonce, True)
    assert "35%" in message
    affair = await database.fetchone("SELECT spouse_npc_id, started_age, nonce FROM affairs WHERE char_id=?", (character.char_id,))
    assert affair is not None
    assert affair["started_age"] == 30
    assert affair["nonce"] == prompt.nonce
    assert await database.fetchone("SELECT 1 FROM infidelity_prompts WHERE char_id=?", (character.char_id,)) is None
