"""Discord.py smoke tests for the Stage 9 casino and investment extensions."""
from __future__ import annotations

import discord
import pytest
from discord.ext import commands

from core.casino import CasinoService
from core.crime import CrimeService
from core.family import FamilyService
from core.investing import InvestingService
from core.locks import UserLockRegistry
from core.rng import RNG
from core.shop import ShopService


@pytest.mark.asyncio
async def test_stage9_groups_and_nested_bond_command_load(database):
    """Load new groups alongside the existing entertainment /slots and /coinflip commands."""
    bot = commands.Bot(command_prefix="!", intents=discord.Intents.none())
    bot.db = database
    bot.rng = RNG(909)
    bot.locks = UserLockRegistry()
    bot.family_service = FamilyService(database, bot.rng, bot.locks)
    bot.crime_service = CrimeService(database, bot.rng, bot.locks, family_service=bot.family_service)
    bot.shop_service = ShopService(database, bot.rng, bot.locks)
    bot.casino_service = CasinoService(database, bot.rng, bot.locks, clock=lambda: 1_800_000_000)
    bot.investing_service = InvestingService(database, bot.rng, bot.locks, clock=lambda: 1_800_000_000)
    async def ready() -> None:
        return None
    bot.wait_until_ready = ready
    await bot.investing_service.initialize_market()
    extensions = (
        "cogs.life", "cogs.education", "cogs.career", "cogs.relationships",
        "cogs.crime", "cogs.prison", "cogs.shop", "cogs.casino", "cogs.invest", "cogs.discobot",
    )

    try:
        for extension in extensions:
            await bot.load_extension(extension)
        commands_by_name = {command.name: command for command in bot.tree.get_commands()}
        assert {"life", "shop", "inventory", "trade", "casino", "invest", "slots", "coinflip"}.issubset(commands_by_name)
        casino = commands_by_name["casino"]
        assert {command.name for command in casino.commands} == {"slots", "blackjack", "roulette", "coinflip", "compulsion"}
        invest = commands_by_name["invest"]
        assert {command.name for command in invest.commands} == {"market", "buy", "sell", "portfolio", "history", "bonds"}
        bond_group = next(command for command in invest.commands if command.name == "bonds")
        assert {command.name for command in bond_group.commands} == {"buy"}
        assert commands_by_name["slots"].name == "slots"
        assert commands_by_name["coinflip"].name == "coinflip"
    finally:
        await bot.close()
