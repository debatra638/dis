"""Tests for data-driven event selection and exactly-once choice resolution."""
from __future__ import annotations

import pytest

from core.data_loader import DataLoader
from core.errors import PendingEventExists, PendingEventNotFound
from core.life_engine import LifeEngine
from core.locks import UserLockRegistry
from core.rng import RNG
from core.validators import DataValidationError, validate_event_catalog


@pytest.mark.asyncio
async def test_age_up_persists_pending_event_and_choice_effects(database):
    engine = LifeEngine(
        database,
        RNG(77),
        UserLockRegistry(),
        clock=lambda: 1_810_000_000,
        event_chance=1.0,
    )
    character = await engine.create_character(707, "Riley")
    aged = await engine.age_up(707)

    prompt = aged.pending_event
    assert prompt is not None
    assert prompt.event.id == "first_birthday"
    assert prompt.age == 1
    saved_prompt = await engine.events.get_pending_event(707)
    assert saved_prompt.nonce == prompt.nonce

    with pytest.raises(PendingEventExists):
        await engine.age_up(707)

    resolution = await engine.events.resolve_choice(707, prompt.nonce, "reach_for_toy")
    reloaded = await engine.get_active_character(707)
    assert resolution.choice.id == "reach_for_toy"
    assert reloaded.age == 1
    assert reloaded.version == character.version + 2  # one age update and one choice update
    assert reloaded.stats.happiness >= character.stats.happiness
    assert reloaded.stats.smarts >= character.stats.smarts

    history = await database.fetchall(
        "SELECT event_key, choice_id, age FROM character_events WHERE char_id = ?",
        (character.char_id,),
    )
    assert len(history) == 1
    assert history[0]["event_key"] == "first_birthday"
    assert history[0]["choice_id"] == "reach_for_toy"
    with pytest.raises(PendingEventNotFound):
        await engine.events.resolve_choice(707, prompt.nonce, "reach_for_toy")

    next_year = await engine.age_up(707)
    assert next_year.new_age == 2
    assert next_year.pending_event is None  # the non-repeatable birthday event was already used


@pytest.mark.asyncio
async def test_event_snapshot_survives_catalog_edits(database, tmp_path):
    import json

    from core.events import EventEngine

    source = DataLoader().load_events()
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    event_file = data_dir / "events.json"
    event_file.write_text(json.dumps(source), encoding="utf-8")
    locks = UserLockRegistry()
    rng = RNG(10)
    event_engine = EventEngine(
        database,
        rng,
        locks,
        data_loader=DataLoader(data_dir),
        event_chance=1.0,
    )
    engine = LifeEngine(
        database,
        rng,
        locks,
        clock=lambda: 1_820_000_000,
        event_engine=event_engine,
    )
    await engine.create_character(808, "Avery")
    outcome = await engine.age_up(808)
    assert outcome.pending_event is not None
    original_title = outcome.pending_event.event.title

    # The pending DB row stores a validated definition snapshot. Simulate a
    # restart against a changed catalog and confirm the original choice survives.
    event_data = json.loads(event_file.read_text(encoding="utf-8"))
    event_data["events"][0]["title"] = "Edited title"
    event_file.write_text(json.dumps(event_data), encoding="utf-8")
    restarted_events = EventEngine(
        database,
        RNG(10),
        UserLockRegistry(),
        data_loader=DataLoader(data_dir),
        event_chance=1.0,
    )
    reloaded = await restarted_events.get_pending_event(808)
    assert reloaded.event.title == original_title


@pytest.mark.asyncio
async def test_user_cannot_resolve_another_users_event(database):
    engine = LifeEngine(
        database,
        RNG(99),
        UserLockRegistry(),
        clock=lambda: 1_830_000_000,
        event_chance=1.0,
    )
    await engine.create_character(909, "Jordan")
    prompt = (await engine.age_up(909)).pending_event
    assert prompt is not None
    with pytest.raises(PendingEventNotFound):
        await engine.events.resolve_choice(910, prompt.nonce, prompt.event.choices[0].id)
    # The real owner can still resolve it after a rejected attempt.
    result = await engine.events.resolve_choice(909, prompt.nonce, prompt.event.choices[0].id)
    assert result.character.user_id == 909


def test_bundled_event_data_validates_and_loader_returns_defensive_copies():
    loader = DataLoader()
    first = loader.load_events()
    expected_title = first["events"][0]["title"]
    first["events"][0]["title"] = "mutated in caller"
    second = loader.load_events()
    assert second["events"][0]["title"] == expected_title


def test_event_validator_rejects_unsafe_or_unknown_effects():
    document = {
        "schema_version": 1,
        "events": [{
            "id": "bad_event",
            "title": "Invalid event",
            "description": "The data tries to target an unsupported field.",
            "category": "test",
            "polarity": "neutral",
            "min_age": 1,
            "max_age": 2,
            "weight": 1,
            "choices": [
                {"id": "safe", "label": "Safe choice", "effects": {"stats": {"health": 1}}},
                {"id": "unsafe", "label": "Unsafe choice", "effects": {"stats": {"__class__": 1}}},
            ],
        }],
    }
    with pytest.raises(DataValidationError):
        validate_event_catalog(document)
