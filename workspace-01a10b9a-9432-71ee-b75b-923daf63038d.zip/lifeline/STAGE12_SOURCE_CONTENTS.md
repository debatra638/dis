# Stage 12 — Verbatim Source Contents

This bundle contains full snapshots of all Stage 12 added/changed files, plus the unchanged README and pinned requirements reviewed during verification. Each code block is the complete file content at the time this bundle was generated.

## `bot.py`

~~~~python
"""LIFELINE Discord bot entry point."""
from __future__ import annotations

import asyncio
import logging
import secrets
import time

import discord
from discord import app_commands
from discord.ext import commands

from core.achievements import AchievementService
from core.casino import CasinoService
from core.config import Config
from core.crime import CrimeService
from core.data_loader import DataLoader
from core.db import DatabaseManager
from core.errors import GameError
from core.repositories.admin import AdminRepository
from core.family import FamilyService
from core.investing import InvestingService
from core.locks import UserLockRegistry
from core.rng import RNG
from core.shop import ShopService

logging.basicConfig(
    level=getattr(logging, Config.from_env().log_level, logging.INFO),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("lifeline")


class LifelineBot(commands.Bot):
    """Main bot class, owning shared database, RNG, and action-lock services."""

    def __init__(self, config: Config | None = None):
        self.config = config or Config.from_env()
        intents = discord.Intents.default()
        # Default intents intentionally leave Message Content, Members, and Presence disabled.
        super().__init__(
            command_prefix=commands.when_mentioned_or("!"),
            intents=intents,
            help_command=None,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        self.db: DatabaseManager | None = None
        self.data_loader = DataLoader()
        self.family_service: FamilyService | None = None
        self.crime_service: CrimeService | None = None
        self.shop_service: ShopService | None = None
        self.casino_service: CasinoService | None = None
        self.investing_service: InvestingService | None = None
        self.achievement_service: AchievementService | None = None
        self.rng: RNG = RNG(self.config.rng_seed)
        self.locks = UserLockRegistry()
        self.tree.on_error = self.on_app_command_error
        self.tree.interaction_check = self._tree_interaction_check

    async def setup_hook(self) -> None:
        """Validate data, initialize services/extensions, and sync only a dev guild automatically."""
        self.data_loader.load_all()
        self.db = DatabaseManager(self.config.db_path)
        await self.db.initialize()
        self.family_service = FamilyService(self.db, self.rng, self.locks)
        self.crime_service = CrimeService(
            self.db,
            self.rng,
            self.locks,
            family_service=self.family_service,
            data_loader=self.data_loader,
        )
        self.shop_service = ShopService(self.db, self.rng, self.locks, data_loader=self.data_loader)
        self.casino_service = CasinoService(self.db, self.rng, self.locks, data_loader=self.data_loader)
        recovered = await self.casino_service.recover_sessions()
        if recovered:
            logger.warning("Refunded %s unfinished blackjack session(s) at startup", recovered)
        self.investing_service = InvestingService(self.db, self.rng, self.locks, data_loader=self.data_loader)
        await self.investing_service.initialize_market()
        # Catalog loading is validated at process startup, not deferred until a command.
        self.achievement_service = AchievementService(self.db, self.locks, data_loader=self.data_loader)
        await self._load_cogs()

        if self.config.dev_guild_id is not None:
            guild = discord.Object(id=self.config.dev_guild_id)
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
            logger.info("Synced application commands to development guild %s", guild.id)
        else:
            logger.info("Global command sync is disabled at startup; use /admin sync explicitly")

    async def _load_cogs(self) -> None:
        """Load the simulation, legacy, settings, admin, and help command extensions."""
        for extension in (
            "cogs.life",
            "cogs.education",
            "cogs.career",
            "cogs.relationships",
            "cogs.crime",
            "cogs.prison",
            "cogs.shop",
            "cogs.casino",
            "cogs.invest",
            "cogs.discobot",
            "cogs.legacy",
            "cogs.settings",
            "cogs.admin",
            "cogs.help",
        ):
            await self.load_extension(extension)
            logger.info("Loaded extension %s", extension)

    async def _tree_interaction_check(self, interaction: discord.Interaction) -> bool:
        """Block active bans from game commands while keeping errors private and clear."""
        if interaction.type is discord.InteractionType.autocomplete or self.db is None:
            return True
        command = interaction.command
        if command is None:
            return True
        root = str(command.qualified_name).split(" ", 1)[0]
        if root in {"admin", "help", "settings"}:
            return True
        try:
            banned = await AdminRepository(self.db).is_banned(int(interaction.user.id))
        except Exception:
            logger.exception("Could not verify game-command ban for user %s", interaction.user.id)
            if not interaction.response.is_done():
                await interaction.response.send_message(
                    "The game could not verify your access right now. Please try again shortly.",
                    ephemeral=True,
                    allowed_mentions=discord.AllowedMentions.none(),
                )
            return False
        if not banned:
            return True
        if not interaction.response.is_done():
            await interaction.response.send_message(
                "Your account is currently banned from LIFELINE game commands. "
                "Contact a bot administrator if you believe this is an error.",
                ephemeral=True,
                allowed_mentions=discord.AllowedMentions.none(),
            )
        return False

    async def on_ready(self) -> None:
        if self.user is not None:
            logger.info("Logged in as %s (ID: %s)", self.user, self.user.id)
        logger.info("Connected to %s guilds", len(self.guilds))
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="lives unfold | /life",
            ),
            status=discord.Status.online,
        )

    async def on_app_command_completion(
        self, interaction: discord.Interaction, command: app_commands.Command
    ) -> None:
        """Record guild participation and deliver new authoritative unlock notices."""
        if self.db is None or self.achievement_service is None:
            return
        user_id = int(interaction.user.id)
        try:
            if interaction.guild_id is not None:
                from core.repositories.legacy import LegacyRepository
                async with self.db.transaction() as tx:
                    await LegacyRepository(self.db).record_guild_seen(
                        tx, int(interaction.guild_id), user_id, int(time.time())
                    )
            root = str(command.qualified_name).split()[0]
            relevant_roots = {
                "life", "start", "education", "career", "relationship", "relationships",
                "date", "friends", "family", "crime", "prison", "shop", "casino", "invest",
                "stocks", "bonds", "trade", "inventory", "retire_life",
            }
            if root in relevant_roots:
                await self.achievement_service.check_user(
                    user_id, guild_id=interaction.guild_id
                )
            notices = self.achievement_service.consume_notifications(user_id)
            for start in range(0, len(notices), 5):
                group = notices[start:start + 5]
                lines = [
                    f"🏆 **{discord.utils.escape_markdown(str(item['name']))}** — "
                    f"{discord.utils.escape_mentions(str(item['description']))}"
                    for item in group
                ]
                embed = discord.Embed(
                    title="Achievement unlocked!" if len(group) == 1 else "Achievements unlocked!",
                    description="\n".join(lines),
                    color=discord.Color.gold(),
                )
                await interaction.followup.send(
                    embed=embed,
                    ephemeral=True,
                    allowed_mentions=discord.AllowedMentions.none(),
                )
        except Exception:
            logger.exception("Could not evaluate Stage 10 achievements for user %s", user_id)

    async def on_app_command_error(
        self,
        interaction: discord.Interaction,
        error: app_commands.AppCommandError,
    ) -> None:
        """Send safe user-facing errors and retain unexpected errors in logs."""
        if isinstance(error, app_commands.CommandOnCooldown):
            message = f"⏳ Try again in {error.retry_after:.1f} seconds."
        elif isinstance(error, (app_commands.CheckFailure, commands.CheckFailure)):
            message = "❌ You do not have permission to use this command."
        else:
            original = getattr(error, "original", error)
            if isinstance(original, GameError):
                message = original.message
            else:
                error_id = __import__("secrets").token_hex(4)
                logger.error(
                    "Unexpected application-command error (ID %s)",
                    error_id,
                    exc_info=(type(original), original, original.__traceback__),
                )
                message = f"An unexpected error occurred (ID: {error_id}). Please try again later."
        await self._send_error(interaction, message)

    @staticmethod
    async def _send_error(interaction: discord.Interaction, message: str) -> None:
        try:
            if interaction.response.is_done():
                await interaction.followup.send(message, ephemeral=True)
            else:
                await interaction.response.send_message(message, ephemeral=True)
        except discord.HTTPException:
            logger.exception("Could not send an application-command error response")

    async def close(self) -> None:
        logger.info("Shutting down LIFELINE")
        if self.db is not None:
            await self.db.close()
        await super().close()


async def main() -> None:
    config = Config.from_env()
    token = config.require_token()
    bot = LifelineBot(config)
    async with bot:
        await bot.start(token)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
~~~~

## `core/repositories/legacy.py`

~~~~python
"""Parameterized persistence for Stage 10 achievements, death, estates, and legacy."""
from __future__ import annotations

import json
from typing import Any, Optional, Sequence

import aiosqlite

from ..models import Character


class LegacyRepository:
    """Own all Stage 10 SQL; callers provide an already-open write transaction."""

    def __init__(self, db: Any) -> None:
        self.db = db

    @staticmethod
    async def _one(tx: aiosqlite.Connection, sql: str, params: tuple[Any, ...] = ()) -> Any:
        """Fetch one row from a caller-owned transaction."""
        cursor = await tx.execute(sql, params)
        return await cursor.fetchone()

    @staticmethod
    async def _all(tx: aiosqlite.Connection, sql: str, params: tuple[Any, ...] = ()) -> list[Any]:
        """Fetch all rows from a caller-owned transaction."""
        cursor = await tx.execute(sql, params)
        return await cursor.fetchall()

    async def has_pending_event(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Return whether a life has an unresolved choice event."""
        row = await self._one(tx, "SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1", (char_id,))
        return row is not None

    async def ensure_player(self, tx: aiosqlite.Connection, user_id: int, now: int) -> None:
        """Create the account row needed by achievements and legacy balances."""
        await tx.execute(
            "INSERT OR IGNORE INTO players(user_id, created_at) VALUES (?, ?)",
            (user_id, now),
        )

    async def player_row(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Return a player's privacy, life-count, and legacy-point state."""
        row = await self._one(tx, "SELECT * FROM players WHERE user_id = ? LIMIT 1", (user_id,))
        return dict(row) if row is not None else None

    async def spend_legacy_points(
        self,
        tx: aiosqlite.Connection,
        *,
        user_id: int,
        char_id: int,
        stat_name: str,
        purchase_count: int,
        now: int,
    ) -> int:
        """Spend 50 cosmetic points per starting-stat purchase, up to two."""
        await self.ensure_player(tx, user_id, now)
        cost = purchase_count * 50
        cursor = await tx.execute(
            "UPDATE players SET legacy_points = legacy_points - ? WHERE user_id = ? AND legacy_points >= ?",
            (cost, user_id, cost),
        )
        if cursor.rowcount != 1:
            raise ValueError("not enough legacy points")
        await tx.execute(
            """INSERT INTO legacy_start_purchases
                   (char_id, user_id, stat_name, purchase_count, points_spent, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (char_id, user_id, stat_name, purchase_count, cost, now),
        )
        return cost

    async def audit_legacy_purchase(
        self,
        tx: aiosqlite.Connection,
        *,
        user_id: int,
        char_id: int,
        stat_name: str,
        purchase_count: int,
        now: int,
    ) -> None:
        """Record cosmetic starting-stat spending in the transaction audit log."""
        await tx.execute(
            """INSERT INTO audit_log(ts, user_id, char_id, action, amount, details_json)
               VALUES (?, ?, ?, 'legacy_start_purchase', ?, ?)""",
            (
                now, user_id, char_id, purchase_count * 50,
                json.dumps({"stat": stat_name, "purchases": purchase_count}, separators=(",", ":")),
            ),
        )

    async def active_character(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Return the user's current active character row."""
        row = await self._one(
            tx,
            "SELECT char_id, user_id, is_alive, age, data_json, version FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def character_record(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Load a character whether alive or archived."""
        row = await self._one(tx, "SELECT * FROM characters WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def user_character_rows(self, tx: aiosqlite.Connection, user_id: int) -> list[dict[str, Any]]:
        """Load every persisted life for one player in stable order."""
        rows = await self._all(
            tx,
            "SELECT * FROM characters WHERE user_id = ? ORDER BY char_id ASC",
            (user_id,),
        )
        return [dict(row) for row in rows]

    async def save_heir_character(self, tx: aiosqlite.Connection, character: Character) -> int:
        """Insert one new heir life with its authoritative serialized attributes."""
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        hidden_json = json.dumps(
            {
                "genetic_health_mod": character.hidden.genetic_health_mod,
                "lifespan_mod": character.hidden.lifespan_mod,
                "luck": character.hidden.luck,
                "temperament": character.hidden.temperament,
            },
            separators=(",", ":"),
            allow_nan=False,
        )
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """INSERT INTO characters
                   (user_id, is_alive, name, gender, country, wealth_class, age,
                    stats_json, hidden_json, version, last_age_at, born_at,
                    died_at, death_cause, death_age, data_json)
               VALUES (?, 1, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, NULL, NULL, NULL, ?)""",
            (
                character.user_id, character.name, character.gender.value, character.country,
                character.wealth_class, character.age, stats_json, hidden_json,
                character.last_age_at, character.born_at, data_json,
            ),
        )
        return int(cursor.lastrowid)

    async def refresh_character_json(self, tx: aiosqlite.Connection, character: Character) -> None:
        """Update a newly assigned character ID inside its serialized snapshot."""
        await tx.execute(
            "UPDATE characters SET data_json = ? WHERE char_id = ?",
            (
                json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False),
                character.char_id,
            ),
        )

    async def save_death_character(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
    ) -> None:
        """Persist the terminal character state once, using the life version as a guard."""
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        hidden_json = json.dumps(
            {
                "genetic_health_mod": character.hidden.genetic_health_mod,
                "lifespan_mod": character.hidden.lifespan_mod,
                "luck": character.hidden.luck,
                "temperament": character.hidden.temperament,
            },
            separators=(",", ":"),
            allow_nan=False,
        )
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET is_alive = 0, age = ?, stats_json = ?, hidden_json = ?,
                   version = ?, last_age_at = ?, died_at = ?, death_cause = ?, death_age = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (
                character.age, stats_json, hidden_json, character.version, character.last_age_at,
                character.died_at, character.death_cause, character.death_age, data_json,
                character.char_id, expected_version,
            ),
        )
        if cursor.rowcount != 1:
            from ..errors import ConcurrentUpdate
            raise ConcurrentUpdate("This life has already ended or changed.")

    async def economy_snapshot(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, int]:
        """Compute liquid and recorded asset values without trusting command arguments."""
        record = await self._one(tx, "SELECT data_json FROM characters WHERE char_id = ?", (char_id,))
        if record is None:
            raise ValueError("character not found")
        data = json.loads(record["data_json"])
        cash = max(0, int(data.get("cash", 0)))
        bank = max(0, int(data.get("bank", 0)))
        debt = max(0, int(data.get("debt_total", 0)))
        item_row = await self._one(
            tx,
            """SELECT COALESCE(SUM(current_value), 0) AS value
               FROM family_assets WHERE char_id = ? AND kind = 'item' AND quantity > 0 AND is_liquidated = 0""", 
            (char_id,),
        )
        stock_row = await self._one(
            tx,
            """SELECT COALESCE(SUM(h.shares * CASE WHEN m.is_delisted = 1 OR m.price_cents < 1
                                                     THEN 0 ELSE m.price_cents END), 0) AS value
               FROM stock_holdings AS h LEFT JOIN stock_market AS m ON m.symbol = h.symbol
               WHERE h.char_id = ?""",
            (char_id,),
        )
        bond_row = await self._one(
            tx,
            "SELECT COALESCE(SUM(balance_cents), 0) AS value FROM savings_bonds WHERE char_id = ? AND status = 'locked'",
            (char_id,),
        )
        loan_row = await self._one(
            tx,
            "SELECT COALESCE(SUM(balance), 0) AS value FROM loans WHERE char_id = ? AND status = 'active'",
            (char_id,),
        )
        items = max(0, int(item_row["value"]))
        stocks = max(0, int(stock_row["value"]))
        bonds = max(0, int(bond_row["value"]))
        liabilities = max(debt, max(0, int(loan_row["value"])))
        gross = cash + bank + items + stocks + bonds
        return {
            "cash_cents": cash,
            "bank_cents": bank,
            "item_assets_cents": items,
            "stock_assets_cents": stocks,
            "bond_assets_cents": bonds,
            "gross_assets_cents": gross,
            "debts_cents": liabilities,
            "net_worth_cents": gross - liabilities,
        }

    async def record_life_year(
        self,
        tx: aiosqlite.Connection,
        *,
        character: Character,
        age: int,
        served_prison_year: bool,
        now: int,
    ) -> dict[str, int]:
        """Record annual happiness and the high-water net worth for one age."""
        economy = await self.economy_snapshot(tx, character.char_id)
        prior = await self._one(
            tx,
            "SELECT COALESCE(MAX(peak_net_worth_cents), 0) AS peak FROM life_year_metrics WHERE char_id = ?",
            (character.char_id,),
        )
        peak = max(int(prior["peak"]), economy["net_worth_cents"])
        await tx.execute(
            """INSERT INTO life_year_metrics
                   (char_id, age, happiness, net_worth_cents, peak_net_worth_cents, served_prison_year, recorded_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(char_id, age) DO UPDATE SET
                   net_worth_cents = excluded.net_worth_cents,
                   peak_net_worth_cents = MAX(life_year_metrics.peak_net_worth_cents, excluded.peak_net_worth_cents),
                   served_prison_year = MAX(life_year_metrics.served_prison_year, excluded.served_prison_year)""",
            (
                character.char_id, age, max(0, min(100, int(character.stats.happiness))),
                economy["net_worth_cents"], peak, int(served_prison_year), now,
            ),
        )
        economy["peak_net_worth_cents"] = peak
        return economy

    async def life_year_metrics(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Read yearly happiness, wealth, and prison-time observations chronologically."""
        rows = await self._all(
            tx,
            "SELECT * FROM life_year_metrics WHERE char_id = ? ORDER BY age ASC",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def ensure_player_for_character(self, tx: aiosqlite.Connection, char_id: int, now: int) -> int:
        """Ensure the player row exists for a character and return its Discord ID."""
        row = await self._one(tx, "SELECT user_id FROM characters WHERE char_id = ?", (char_id,))
        if row is None:
            raise ValueError("character not found")
        user_id = int(row["user_id"])
        await self.ensure_player(tx, user_id, now)
        return user_id

    async def close_open_career(self, tx: aiosqlite.Connection, char_id: int, age: int, reason: str) -> None:
        """Close any still-open career history and remove the active job row."""
        await tx.execute(
            "UPDATE career_history SET end_age = ?, end_reason = ? WHERE char_id = ? AND end_age IS NULL",
            (age, reason, char_id),
        )
        await tx.execute("DELETE FROM jobs WHERE char_id = ?", (char_id,))

    async def archive_marriage(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        end_age: int,
        end_reason: str,
        now: int,
    ) -> Optional[dict[str, Any]]:
        """Move a current marriage into durable history before its live row is removed."""
        row = await self._one(
            tx,
            """SELECT m.*, n.name AS spouse_name FROM marriages AS m
               JOIN npcs AS n ON n.npc_id = m.spouse_npc_id WHERE m.char_id = ? LIMIT 1""",
            (char_id,),
        )
        if row is None:
            return None
        result = dict(row)
        final_age = max(int(result["start_age"]), int(end_age))
        await tx.execute(
            """INSERT INTO marriage_history
                   (char_id, spouse_npc_id, spouse_name, start_age, end_age, end_reason, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                char_id, int(result["spouse_npc_id"]), str(result["spouse_name"]),
                int(result["start_age"]), final_age, end_reason, now,
            ),
        )
        await tx.execute("DELETE FROM marriages WHERE char_id = ?", (char_id,))
        return result

    async def children(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Load all children and their live NPC attributes for summaries and inheritance."""
        rows = await self._all(
            tx,
            """SELECT n.*, c.custody, c.child_support, c.other_parent_npc_id
               FROM children AS c JOIN npcs AS n ON n.npc_id = c.npc_id
               WHERE c.char_id = ? ORDER BY n.npc_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def insert_life_log(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        age: int,
        category: str,
        text: str,
        importance: int,
        created_at: int,
    ) -> None:
        """Insert one sanitized-by-caller life moment using parameterized SQL."""
        await tx.execute(
            """INSERT INTO life_logs(char_id, age, category, text, importance, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (char_id, age, category, text, importance, created_at),
        )

    async def top_life_logs(self, tx: aiosqlite.Connection, char_id: int, limit: int = 10) -> list[dict[str, Any]]:
        """Load the most important life moments with deterministic age/ID ordering."""
        rows = await self._all(
            tx,
            """SELECT age, category, text, importance FROM life_logs WHERE char_id = ?
               ORDER BY importance DESC, age ASC, id ASC LIMIT ?""",
            (char_id, limit),
        )
        return [dict(row) for row in rows]

    async def career_history(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Load recorded careers and maximum levels for a life."""
        rows = await self._all(
            tx,
            "SELECT * FROM career_history WHERE char_id = ? ORDER BY start_age, id",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def marriage_history(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Load ended marriages in chronological order."""
        rows = await self._all(
            tx,
            "SELECT * FROM marriage_history WHERE char_id = ? ORDER BY start_age, marriage_history_id",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def current_marriage(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Load a current spouse and marriage start age."""
        row = await self._one(
            tx,
            """SELECT m.*, n.name AS spouse_name, n.is_alive AS spouse_alive
               FROM marriages AS m JOIN npcs AS n ON n.npc_id = m.spouse_npc_id
               WHERE m.char_id = ? LIMIT 1""",
            (char_id,),
        )
        return dict(row) if row is not None else None

    async def crime_summary(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Any]:
        """Aggregate attempts, convictions, successful escapes, and served years."""
        attempts = await self._one(
            tx,
            """SELECT COUNT(*) AS attempts,
                      SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) AS successes,
                      SUM(CASE WHEN case_status = 'convicted' AND record_sealed = 0 THEN 1 ELSE 0 END) AS convictions,
                      SUM(CASE WHEN record_sealed = 1 THEN 1 ELSE 0 END) AS sealed
               FROM crime_attempts WHERE char_id = ?""",
            (char_id,),
        )
        profile = await self._one(tx, "SELECT * FROM crime_profiles WHERE char_id = ?", (char_id,))
        served = await self._one(
            tx,
            "SELECT COALESCE(SUM(served_prison_year), 0) AS years FROM life_year_metrics WHERE char_id = ?",
            (char_id,),
        )
        escaped_log = await self._one(
            tx,
            "SELECT 1 FROM life_logs WHERE char_id = ? AND category = 'prison' AND lower(text) LIKE '%escaped%' LIMIT 1",
            (char_id,),
        )
        return {
            "attempts": int(attempts["attempts"] or 0),
            "successes": int(attempts["successes"] or 0),
            "convictions": int(attempts["convictions"] or 0),
            "sealed_convictions": int(attempts["sealed"] or 0),
            "profile": dict(profile) if profile is not None else {},
            "years_in_prison": int(served["years"] or 0),
            "escaped": bool(escaped_log) or bool(profile and int(profile["escaped"])),
        }

    async def casino_rows(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Load settled casino outcomes for authoritative achievement checks."""
        rows = await self._all(
            tx,
            "SELECT game, bet_cents, payout_cents, net_cents, status, outcome_json FROM casino_plays WHERE char_id = ? ORDER BY play_id",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def investment_rows(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Any]:
        """Return stock trade, bond maturity, rental, and current holding facts."""
        trades = await self._one(tx, "SELECT COUNT(*) AS count FROM investment_trades WHERE char_id = ?", (char_id,))
        holdings = await self._one(
            tx,
            "SELECT COUNT(*) AS count, COALESCE(SUM(shares), 0) AS shares FROM stock_holdings WHERE char_id = ?",
            (char_id,),
        )
        bonds = await self._one(
            tx,
            "SELECT COUNT(*) AS count FROM savings_bonds WHERE char_id = ? AND status = 'matured'",
            (char_id,),
        )
        rent = await self._one(
            tx,
            "SELECT COALESCE(SUM(rental_income_cents), 0) AS income FROM investment_yearly_income WHERE char_id = ?",
            (char_id,),
        )
        return {
            "trade_count": int(trades["count"]),
            "holding_count": int(holdings["count"]),
            "share_count": int(holdings["shares"]),
            "matured_bonds": int(bonds["count"]),
            "rental_income_cents": int(rent["income"]),
        }

    async def education_rows(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Any]:
        """Read authoritative course and GPA records."""
        row = await self._one(
            tx,
            """SELECT COUNT(*) AS count,
                      SUM(CASE WHEN effort = 'hard' THEN 1 ELSE 0 END) AS hard_count,
                      COALESCE(MAX(gpa_after), 0) AS max_gpa
               FROM education_actions WHERE char_id = ?""",
            (char_id,),
        )
        return {
            "study_actions": int(row["count"] or 0),
            "hard_study_actions": int(row["hard_count"] or 0),
            "max_gpa": float(row["max_gpa"] or 0),
        }

    async def active_job(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Read a current job for career facts and salary summaries."""
        row = await self._one(tx, "SELECT * FROM jobs WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def work_action_count(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Count recorded work actions for a life."""
        row = await self._one(tx, "SELECT COUNT(*) AS count FROM career_actions WHERE char_id = ?", (char_id,))
        return int(row["count"])

    async def divorce_count(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Count completed divorces from the authoritative Stage 6 ledger."""
        row = await self._one(tx, "SELECT COUNT(*) AS count FROM divorce_records WHERE char_id = ?", (char_id,))
        return int(row["count"])

    async def marriage_count(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Count current plus archived marriages."""
        row = await self._one(
            tx,
            """SELECT (SELECT COUNT(*) FROM marriage_history WHERE char_id = ?) +
                      (SELECT COUNT(*) FROM marriages WHERE char_id = ?) AS count""",
            (char_id, char_id),
        )
        return int(row["count"])

    async def max_marriage_years(self, tx: aiosqlite.Connection, char_id: int, current_age: int) -> int:
        """Return the longest recorded or current marriage duration."""
        row = await self._one(
            tx,
            """SELECT COALESCE(MAX(duration), 0) AS years FROM (
                   SELECT MAX(0, end_age - start_age) AS duration FROM marriage_history WHERE char_id = ?
                   UNION ALL
                   SELECT MAX(0, ? - start_age) AS duration FROM marriages WHERE char_id = ?
               )""",
            (char_id, current_age, char_id),
        )
        return int(row["years"])

    async def child_count(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Count all children recorded for a character, living or deceased."""
        row = await self._one(tx, "SELECT COUNT(*) AS count FROM children WHERE char_id = ?", (char_id,))
        return int(row["count"])

    async def item_facts(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Any]:
        """Return active owned item IDs and the count of distinct live asset lots."""
        rows = await self._all(
            tx,
            "SELECT item_id, quantity FROM family_assets WHERE char_id = ? AND quantity > 0 AND is_liquidated = 0",
            (char_id,),
        )
        return {"item_rows": [dict(row) for row in rows], "asset_lots": len(rows)}

    async def rehab_used(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check whether the authoritative audit ledger records recovery treatment."""
        row = await self._one(
            tx,
            "SELECT 1 FROM audit_log WHERE char_id = ? AND action = 'gambling_rehab_used' LIMIT 1",
            (char_id,),
        )
        return row is not None

    async def stats_tracking(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, int]:
        """Read Stage 9 gambling totals and Stage 6 divorce count."""
        row = await self._one(tx, "SELECT * FROM stats_tracking WHERE char_id = ? LIMIT 1", (char_id,))
        if row is None:
            return {"total_gambled": 0, "total_gambling_net": 0, "divorces": 0}
        data = dict(row)
        return {
            "total_gambled": int(data.get("total_gambled", 0)),
            "total_gambling_net": int(data.get("total_gambling_net", 0)),
            "divorces": int(data.get("divorces", 0)),
        }

    async def insert_achievement(
        self, tx: aiosqlite.Connection, *, user_id: int, achievement_id: str, char_id: int, now: int
    ) -> bool:
        """Insert a first unlock only; the primary key prevents repeat awards."""
        await self.ensure_player(tx, user_id, now)
        cursor = await tx.execute(
            """INSERT OR IGNORE INTO achievements_unlocked(user_id, achievement_id, char_id, unlocked_at)
               VALUES (?, ?, ?, ?)""",
            (user_id, achievement_id, char_id, now),
        )
        return cursor.rowcount == 1

    async def user_achievements(self, tx: aiosqlite.Connection, user_id: int) -> list[dict[str, Any]]:
        """Load a player's earned achievement rows chronologically."""
        rows = await self._all(
            tx,
            """SELECT a.*, c.name AS character_name FROM achievements_unlocked AS a
               JOIN characters AS c ON c.char_id = a.char_id
               WHERE a.user_id = ? ORDER BY a.unlocked_at DESC, a.achievement_id""",
            (user_id,),
        )
        return [dict(row) for row in rows]

    async def character_achievement_rows(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Load achievements earned during a single life for its death summary."""
        rows = await self._all(
            tx,
            """SELECT achievement_id, unlocked_at FROM achievements_unlocked
               WHERE char_id = ? ORDER BY unlocked_at, achievement_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def add_player_legacy_points(self, tx: aiosqlite.Connection, user_id: int, points: int, now: int) -> None:
        """Add the exact cosmetic legacy score to a player account."""
        await self.ensure_player(tx, user_id, now)
        await tx.execute("UPDATE players SET legacy_points = legacy_points + ? WHERE user_id = ?", (points, user_id))

    async def increment_lives_lived(self, tx: aiosqlite.Connection, user_id: int, now: int) -> None:
        """Increment archived-life count once after the immutable archive insert."""
        await self.ensure_player(tx, user_id, now)
        await tx.execute("UPDATE players SET lives_lived = lives_lived + 1 WHERE user_id = ?", (user_id,))

    async def insert_past_life(self, tx: aiosqlite.Connection, summary: dict[str, Any]) -> bool:
        """Insert an immutable archive row without ever replacing an earlier summary."""
        cursor = await tx.execute(
            """INSERT OR IGNORE INTO past_lives
                   (char_id, user_id, death_age, death_cause, born_at, died_at, life_score, grade,
                    legacy_points, peak_net_worth_cents, final_net_worth_cents, gross_assets_cents,
                    debts_paid_cents, estate_tax_cents, estate_cents, unpaid_debt_cents,
                    abandoned, summary_json, archived_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                int(summary["char_id"]), int(summary["user_id"]), int(summary["death_age"]),
                str(summary["death_cause"]), int(summary["born_at"]), int(summary["died_at"]),
                float(summary["life_score"]), str(summary["grade"]), int(summary["legacy_points"]),
                int(summary["peak_net_worth_cents"]), int(summary["final_net_worth_cents"]),
                int(summary["gross_assets_cents"]), int(summary["debts_paid_cents"]),
                int(summary["estate_tax_cents"]), int(summary["estate_cents"]),
                int(summary["unpaid_debt_cents"]), int(bool(summary["abandoned"])),
                json.dumps(
                    summary["summary_json"],
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                    allow_nan=False,
                ),
                int(summary["archived_at"]),
            ),
        )
        return cursor.rowcount == 1

    async def past_life(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Load an archived life by its immutable character ID."""
        row = await self._one(tx, "SELECT * FROM past_lives WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def user_past_lives(self, tx: aiosqlite.Connection, user_id: int, limit: int = 50) -> list[dict[str, Any]]:
        """Load a user's most recent life archives."""
        rows = await self._all(
            tx,
            "SELECT * FROM past_lives WHERE user_id = ? ORDER BY past_life_id DESC LIMIT ?",
            (user_id, limit),
        )
        return [dict(row) for row in rows]

    async def recent_deaths(self, tx: aiosqlite.Connection, limit: int = 50) -> list[dict[str, Any]]:
        """Load the most recent natural/ordinary deaths, excluding voluntary retirement."""
        rows = await self._all(
            tx,
            """SELECT p.*, c.name FROM past_lives AS p
               JOIN characters AS c ON c.char_id = p.char_id
               JOIN players AS pl ON pl.user_id = p.user_id
               WHERE p.abandoned = 0 AND pl.leaderboard_opt_out = 0
               ORDER BY p.archived_at DESC, p.past_life_id DESC LIMIT ?""", 
            (limit,),
        )
        return [dict(row) for row in rows]

    async def settle_loan_balances(self, tx: aiosqlite.Connection, char_id: int, payment_cents: int) -> int:
        """Pay active loans in stable order and default terminal-life balances left unpaid."""
        remaining = max(0, int(payment_cents))
        rows = await self._all(
            tx,
            "SELECT loan_id, balance FROM loans WHERE char_id = ? AND status = 'active' ORDER BY loan_id",
            (char_id,),
        )
        paid = 0
        for row in rows:
            if remaining <= 0:
                break
            balance = max(0, int(row["balance"]))
            part = min(balance, remaining)
            new_balance = balance - part
            await tx.execute(
                "UPDATE loans SET balance = ?, status = ? WHERE loan_id = ? AND status = 'active'",
                (new_balance, "paid" if new_balance == 0 else "active", int(row["loan_id"])),
            )
            paid += part
            remaining -= part
        # A terminal life has no future income from which to collect any remainder.
        # Close unpaid loans as defaulted instead of leaving active debt attached to an archive.
        await tx.execute(
            "UPDATE loans SET status = 'defaulted' WHERE char_id = ? AND status = 'active'",
            (int(char_id),),
        )
        return paid

    async def close_pending_life_estates(self, tx: aiosqlite.Connection, user_id: int, now: int) -> int:
        """Close unclaimed inheritance prompts when a user elects to begin afresh."""
        cursor = await tx.execute(
            "UPDATE life_estates SET status = 'closed', resolved_at = ? WHERE user_id = ? AND status = 'pending'",
            (now, user_id),
        )
        return int(cursor.rowcount)

    async def guild_public_death_summaries(self, tx: aiosqlite.Connection, guild_id: int) -> bool:
        """Read the guild obituary setting; an unconfigured server defaults to public."""
        row = await self._one(
            tx,
            "SELECT public_death_summaries FROM guild_stage10_settings WHERE guild_id = ?",
            (guild_id,),
        )
        return True if row is None else bool(int(row["public_death_summaries"]))

    async def set_guild_public_death_summaries(
        self, tx: aiosqlite.Connection, *, guild_id: int, enabled: bool, user_id: int, now: int
    ) -> None:
        """Persist an administrator's guild-level obituary visibility choice."""
        await tx.execute(
            """INSERT INTO guild_stage10_settings(guild_id, public_death_summaries, updated_by, updated_at)
               VALUES (?, ?, ?, ?)
               ON CONFLICT(guild_id) DO UPDATE SET
                   public_death_summaries = excluded.public_death_summaries,
                   updated_by = excluded.updated_by,
                   updated_at = excluded.updated_at""",
            (guild_id, int(enabled), user_id, now),
        )

    async def insert_life_estate(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        user_id: int,
        estate_cents: int,
        nonce: str,
        eligible_heirs: list[dict[str, Any]],
        now: int,
    ) -> int:
        """Persist one durable owner-bound heir continuation choice."""
        cursor = await tx.execute(
            """INSERT INTO life_estates
                   (char_id, user_id, estate_cents, nonce, eligible_heirs_json, status, created_at)
               VALUES (?, ?, ?, ?, ?, 'pending', ?)""",
            (
                char_id, user_id, estate_cents, nonce,
                json.dumps(eligible_heirs, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False),
                now,
            ),
        )
        return int(cursor.lastrowid)

    async def pending_life_estate(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Load the newest unresolved heir choice for a single owner."""
        row = await self._one(
            tx,
            "SELECT * FROM life_estates WHERE user_id = ? AND status = 'pending' ORDER BY created_at DESC LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def load_life_estate(self, tx: aiosqlite.Connection, estate_id: int) -> Optional[dict[str, Any]]:
        """Load a continuation prompt and its owner/status for server-side validation."""
        row = await self._one(tx, "SELECT * FROM life_estates WHERE estate_id = ? LIMIT 1", (estate_id,))
        return dict(row) if row is not None else None

    async def resolve_life_estate(
        self,
        tx: aiosqlite.Connection,
        *,
        estate_id: int,
        user_id: int,
        nonce: str,
        selected_npc_id: Optional[int],
        now: int,
    ) -> bool:
        """Claim or close a pending inheritance choice exactly once."""
        status = "claimed" if selected_npc_id is not None else "closed"
        cursor = await tx.execute(
            """UPDATE life_estates SET status = ?, selected_npc_id = ?, resolved_at = ?
               WHERE estate_id = ? AND user_id = ? AND nonce = ? AND status = 'pending'""",
            (status, selected_npc_id, now, estate_id, user_id, nonce),
        )
        return cursor.rowcount == 1

    async def pending_retirement_prompt(
        self, tx: aiosqlite.Connection, user_id: int
    ) -> Optional[dict[str, Any]]:
        """Load an active retirement confirmation to prevent duplicate pending prompts."""
        row = await self._one(
            tx,
            "SELECT * FROM retirement_prompts WHERE user_id = ? AND status = 'pending' LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def insert_retirement_prompt(
        self, tx: aiosqlite.Connection, *, user_id: int, char_id: int, nonce: str, now: int, expires_at: int
    ) -> int:
        """Persist a one-time confirmation prompt before abandoning a life."""
        cursor = await tx.execute(
            """INSERT INTO retirement_prompts(user_id, char_id, nonce, created_at, expires_at)
               VALUES (?, ?, ?, ?, ?)""",
            (user_id, char_id, nonce, now, expires_at),
        )
        return int(cursor.lastrowid)

    async def load_retirement_prompt(self, tx: aiosqlite.Connection, prompt_id: int) -> Optional[dict[str, Any]]:
        """Load a retirement confirmation for owner, nonce, and expiry checks."""
        row = await self._one(tx, "SELECT * FROM retirement_prompts WHERE prompt_id = ? LIMIT 1", (prompt_id,))
        return dict(row) if row is not None else None

    async def resolve_retirement_prompt(
        self, tx: aiosqlite.Connection, *, prompt_id: int, user_id: int, nonce: str, status: str, now: int
    ) -> bool:
        """Resolve a pending retirement prompt once."""
        cursor = await tx.execute(
            """UPDATE retirement_prompts SET status = ?, resolved_at = ?
               WHERE prompt_id = ? AND user_id = ? AND nonce = ? AND status = 'pending'""",
            (status, now, prompt_id, user_id, nonce),
        )
        return cursor.rowcount == 1

    async def set_leaderboard_privacy(self, tx: aiosqlite.Connection, user_id: int, opt_out: bool, now: int) -> None:
        """Set both Stage 10 and Stage 11 representations of leaderboard visibility."""
        await self.ensure_player(tx, user_id, now)
        public = int(not opt_out)
        await tx.execute("UPDATE players SET leaderboard_opt_out = ? WHERE user_id = ?", (int(opt_out), user_id))
        await tx.execute(
            """INSERT INTO player_settings
                   (user_id, public_year_summaries, public_deaths, public_casino_results, public_leaderboards, updated_at)
               VALUES (?, 1, 1, 1, ?, ?)
               ON CONFLICT(user_id) DO UPDATE SET
                   public_leaderboards = excluded.public_leaderboards,
                   updated_at = excluded.updated_at""",
            (user_id, public, now),
        )

    async def record_guild_seen(self, tx: aiosqlite.Connection, guild_id: int, user_id: int, now: int) -> None:
        """Remember an actual guild interaction for no-members-intent filtering."""
        await self.ensure_player(tx, user_id, now)
        await tx.execute(
            """INSERT INTO guild_player_seen(guild_id, user_id, last_seen_at) VALUES (?, ?, ?)
               ON CONFLICT(guild_id, user_id) DO UPDATE SET last_seen_at = excluded.last_seen_at""",
            (guild_id, user_id, now),
        )

    async def seen_guild_users(self, tx: aiosqlite.Connection, guild_id: int) -> list[int]:
        """Return player IDs recently observed interacting in a guild."""
        rows = await self._all(
            tx,
            "SELECT user_id FROM guild_player_seen WHERE guild_id = ? ORDER BY last_seen_at DESC, user_id ASC",
            (guild_id,),
        )
        return [int(row["user_id"]) for row in rows]

    async def leaderboard_players(self, tx: aiosqlite.Connection) -> list[dict[str, Any]]:
        """Load all non-opted-out player IDs and their archived-life summaries."""
        rows = await self._all(
            tx,
            """SELECT user_id, lives_lived, legacy_points FROM players
               WHERE leaderboard_opt_out = 0 ORDER BY user_id""",
        )
        return [dict(row) for row in rows]

    async def leaderboard_characters(self, tx: aiosqlite.Connection) -> list[dict[str, Any]]:
        """Load all active characters, excluding archived raw JSON from leaderboard UI."""
        rows = await self._all(
            tx,
            "SELECT char_id, user_id, age, data_json FROM characters WHERE is_alive = 1 ORDER BY user_id, char_id",
        )
        return [dict(row) for row in rows]

    async def leaderboard_past_lives(self, tx: aiosqlite.Connection) -> list[dict[str, Any]]:
        """Load immutable summary metrics for all archived lives."""
        rows = await self._all(
            tx,
            """SELECT user_id, char_id, death_age, life_score, peak_net_worth_cents, final_net_worth_cents,
                      summary_json, abandoned FROM past_lives WHERE abandoned = 0 ORDER BY user_id, past_life_id""",
        )
        return [dict(row) for row in rows]

    async def set_current_marriage_end(
        self, tx: aiosqlite.Connection, char_id: int, age: int, now: int, reason: str
    ) -> Optional[dict[str, Any]]:
        """Archive then remove the active marriage for divorce or spouse death."""
        return await self.archive_marriage(
            tx, char_id=char_id, end_age=age, end_reason=reason, now=now
        )

    async def estate_heirs(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return living adult children eligible for a continuation choice."""
        rows = await self._all(
            tx,
            """SELECT n.npc_id, n.name, n.gender, n.age, n.health, n.smarts, n.looks,
                      n.country, n.wealth, c.char_id AS parent_char_id
               FROM children AS c JOIN npcs AS n ON n.npc_id = c.npc_id
               WHERE c.char_id = ? AND n.is_alive = 1 AND n.age >= 18
               ORDER BY n.npc_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def read_guild_privacy(self, tx: aiosqlite.Connection, user_ids: Sequence[int]) -> dict[int, bool]:
        """Return opt-out settings for a bounded set of accounts."""
        if not user_ids:
            return {}
        placeholders = ",".join("?" for _ in user_ids)
        rows = await self._all(
            tx,
            f"SELECT user_id, leaderboard_opt_out FROM players WHERE user_id IN ({placeholders})",
            tuple(user_ids),
        )
        return {int(row["user_id"]): bool(row["leaderboard_opt_out"]) for row in rows}

    async def latest_past_life(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return the immutable death archive associated with a character."""
        return await self.past_life(tx, char_id)
~~~~

## `core/migrations/011_repair_archived_life_summaries.sql`

~~~~sql
-- Stage 12: repair the nested JSON envelope written by the original archive repository.
-- Keep the immutable archive trigger disabled only inside this atomic one-time migration.
DROP TRIGGER IF EXISTS trg_past_lives_immutable_update;

UPDATE past_lives
SET summary_json = json_extract(summary_json, '$.summary_json')
WHERE json_valid(summary_json)
  AND json_type(summary_json, '$.summary_json') = 'object'
  AND json_type(summary_json, '$.name') IS NULL;

CREATE TRIGGER IF NOT EXISTS trg_past_lives_immutable_update
BEFORE UPDATE ON past_lives
BEGIN
    SELECT RAISE(ABORT, 'past_lives rows are immutable');
END;
~~~~

## `tests/test_full_lives.py`

~~~~python
"""Opt-in seeded service-layer integration run for 500 complete LIFELINE lives.

Run with ``LIFELINE_RUN_FULL_LIVES=1 pytest -q -s tests/test_full_lives.py``.
The full cohort takes several minutes because every simulated year goes through
LifeEngine's real SQLite transaction and all integrated domain services.
"""
from __future__ import annotations

import json
import os
from collections import Counter
from dataclasses import dataclass, replace
from statistics import median

import pytest

from core.careers import CareerService
from core.config import GameBalance
from core.education import EducationService
from core.errors import GameError
from core.family import can_date_ages
from core.life_engine import LifeEngine
from core.locks import UserLockRegistry
from core.models import Character, EducationLevel, JobAction, StudyEffort
from core.rng import RNG


LIFE_COUNT = 500
USER_ID_BASE = 930_000
SIMULATION_SEED = 20261001


class SimulationClock:
    """Mutable simulated real-time clock for cooldown and expiry services."""

    def __init__(self, value: int = 1_900_000_000) -> None:
        self.value = value

    def __call__(self) -> int:
        return self.value

    def advance(self, seconds: int = 1) -> None:
        self.value += int(seconds)


@dataclass(slots=True)
class RunCounters:
    """Only counters needed to verify that randomized routes really executed."""

    annual_steps: int = 0
    events_resolved: int = 0
    studies: int = 0
    college_enrollments: int = 0
    jobs_started: int = 0
    work_actions: int = 0
    dates: int = 0
    family_actions: int = 0
    crimes_attempted: int = 0
    trials_resolved: int = 0
    prison_actions: int = 0
    purchases: int = 0
    sales: int = 0
    trades: int = 0
    casino_plays: int = 0
    compulsions: int = 0
    stock_buys: int = 0
    stock_sells: int = 0
    bonds_bought: int = 0
    retirements: int = 0
    expected_rule_rejections: int = 0


async def _save_character(engine: LifeEngine, character: Character, **changes: object) -> Character:
    """Apply deterministic test-profile fields through the real CAS save path."""
    updated = replace(character, **changes, version=character.version + 1)
    async with engine.db.transaction() as tx:
        await engine._save_character(tx, updated, expected_version=character.version)
    return updated


def _assert_character_invariants(character: Character) -> None:
    """Check the monetary and stat bounds at every service-layer decision point."""
    for name in ("cash", "bank", "debt_total"):
        value = getattr(character, name)
        assert isinstance(value, int) and not isinstance(value, bool), (name, value)
        assert 0 <= value <= 9_000_000_000_000_000, (name, value)
    stats = character.stats.to_dict()
    for name, value in stats.items():
        if name == "credit_score":
            assert value is None or 300 <= int(value) <= 850
        else:
            assert 0 <= int(value) <= 100, (name, value)


async def _resolve_age_prompts(
    engine: LifeEngine,
    user_id: int,
    outcome,
    decision_rng: RNG,
    counters: RunCounters,
) -> None:
    """Resolve each persisted age prompt through its public engine service."""
    if outcome.pending_event is not None:
        choice = decision_rng.choice(outcome.pending_event.event.choices)
        await engine.events.resolve_choice(user_id, outcome.pending_event.nonce, choice.id)
        counters.events_resolved += 1
    if outcome.pending_trial is not None:
        await engine.crimes.resolve_trial(user_id, outcome.pending_trial.nonce, "public")
        counters.trials_resolved += 1
    if outcome.pending_tax is not None:
        await engine.crimes.resolve_tax_choice(user_id, outcome.pending_tax.nonce, "pay")
    if outcome.pending_compulsion is not None:
        prompt = outcome.pending_compulsion
        character = await engine.get_active_character(user_id)
        choice = "resist"
        if character.age >= engine.casino.gambling_age(character.country):
            choice = decision_rng.choice(("resist", "indulge"))
        await engine.casino.resolve_compulsion(
            user_id,
            int(prompt["compulsion_id"]),
            str(prompt["nonce"]),
            choice,
        )
        counters.compulsions += 1


async def _run_adult_decisions(
    engine: LifeEngine,
    education: EducationService,
    user_id: int,
    character: Character,
    index: int,
    decision_rng: RNG,
    clock: SimulationClock,
    counters: RunCounters,
    integration_users: set[int],
    integration_assets: dict[int, int],
) -> Character:
    """Make bounded, randomized decisions across the existing adult systems."""
    if character.in_prison:
        action = decision_rng.choice(("behave", "workout", "study", "escape", "gang"))
        try:
            result = await engine.crimes.prison_action(user_id, action)
        except GameError:
            counters.expected_rule_rejections += 1
        else:
            character = result.character
            counters.prison_actions += 1
        return character

    if character.school_program is not None and decision_rng.random() < 0.28:
        try:
            result = await education.study(user_id, decision_rng.choice(tuple(StudyEffort)))
        except GameError:
            counters.expected_rule_rejections += 1
        else:
            character = result.character
            counters.studies += 1

    if (
        character.age == 18
        and index % 4 == 2
        and character.education_level is EducationLevel.HIGH_SCHOOL
        and character.school_program is None
    ):
        try:
            character = await education.enroll(user_id, EducationLevel.BACHELOR, "computer science")
        except GameError:
            counters.expected_rule_rejections += 1
        else:
            counters.college_enrollments += 1

    job = await engine.db.fetchone("SELECT career_id FROM jobs WHERE char_id = ?", (character.char_id,))
    if job is None and 18 <= character.age <= 55 and not character.is_retired and decision_rng.random() < 0.64:
        eligible = engine.careers.eligible_careers(character)
        if eligible:
            career = decision_rng.choice(eligible)
            part_time = career.part_time_allowed and decision_rng.random() < 0.22
            try:
                await engine.careers.apply(user_id, career.id, part_time=part_time)
            except GameError:
                counters.expected_rule_rejections += 1
            else:
                counters.jobs_started += 1
                character = await engine.get_active_character(user_id)
                job = {"career_id": career.id}

    if job is not None and 18 <= character.age <= 60 and decision_rng.random() < 0.25:
        effort = decision_rng.choice((JobAction.WORK_HARD, JobAction.WORK_NORMAL, JobAction.WORK_SLACK))
        try:
            result = await engine.careers.work(user_id, effort)
        except GameError:
            counters.expected_rule_rejections += 1
        else:
            character = result.character
            counters.work_actions += 1

    if character.age == 8 and index % 3 == 0:
        try:
            await engine.family.find_friend(user_id)
        except GameError:
            counters.expected_rule_rejections += 1
        else:
            counters.family_actions += 1

    if character.age in {16, 18} and index % 3 == 0:
        try:
            search = await engine.family.find_dates(user_id)
            options = [
                person for person in search.candidates
                if can_date_ages(character.age, int(person["age"]))
            ]
            if options:
                selected = decision_rng.choice(options)
                await engine.family.choose_date(user_id, int(selected["npc_id"]), search.nonce)
                counters.dates += 1
                counters.family_actions += 1
        except GameError:
            counters.expected_rule_rejections += 1

    if character.age >= 18 and decision_rng.random() < 0.24:
        try:
            _, people = await engine.family.family(user_id)
            romance = next(
                (person for person in people if person["relationship_type"] in {"partner", "fiance"}),
                None,
            )
            if romance is not None and romance["relationship_type"] == "partner":
                if int(romance["relationship_score"]) < 72:
                    await engine.family.interact(
                        user_id,
                        int(romance["npc_id"]),
                        decision_rng.choice(("compliment", "spend_time")),
                    )
                    counters.family_actions += 1
                elif int(romance["relationship_since_age"]) < character.age:
                    proposal = await engine.family.propose(user_id, int(romance["npc_id"]))
                    counters.family_actions += 1
                    if proposal.accepted:
                        character = await engine.get_active_character(user_id)
                        try:
                            await engine.family.marry(user_id, "courthouse", prenup=decision_rng.random() < 0.5)
                        except GameError:
                            counters.expected_rule_rejections += 1
                        else:
                            counters.family_actions += 1
            elif romance is not None and romance["relationship_type"] == "fiance":
                try:
                    await engine.family.marry(user_id, "courthouse", prenup=decision_rng.random() < 0.5)
                except GameError:
                    counters.expected_rule_rejections += 1
                else:
                    counters.family_actions += 1
            else:
                marriage = await engine.db.fetchone("SELECT 1 FROM marriages WHERE char_id = ?", (character.char_id,))
                if marriage is not None and character.age <= 50 and decision_rng.random() < 0.05:
                    await engine.family.try_for_baby(user_id)
                    counters.family_actions += 1
        except GameError:
            counters.expected_rule_rejections += 1

    if index % 5 == 0 and character.age >= 20 and not character.in_prison and decision_rng.random() < 0.22:
        job = await engine.db.fetchone("SELECT career_id FROM jobs WHERE char_id = ?", (character.char_id,))
        eligible_crimes = [
            crime for crime in engine.crimes.crimes
            if crime.commit_enabled
            and crime.min_age <= character.age
            and (not crime.requires_job or job is not None)
        ]
        if eligible_crimes:
            crime = decision_rng.choice(eligible_crimes)
            try:
                preview = await engine.crimes.preview_crime(user_id, crime.id)
            except GameError:
                counters.expected_rule_rejections += 1
            else:
                if decision_rng.random() < 0.82:
                    attempt = await engine.crimes.confirm_crime(user_id, preview.nonce)
                    counters.crimes_attempted += 1
                    if attempt.trial is not None:
                        await engine.crimes.resolve_trial(user_id, attempt.trial.nonce, "public")
                        counters.trials_resolved += 1
                else:
                    await engine.crimes.cancel_preview(user_id, preview.nonce)

    if character.age >= 18 and decision_rng.random() < 0.025:
        item_id = decision_rng.choice(("phone", "guitar", "snack", "used_car"))
        try:
            quote = await engine.shop.quote_purchase(user_id, item_id)
            if quote.can_pay_cash:
                await engine.shop.purchase(
                    user_id,
                    item_id,
                    quote.quantity,
                    expected_version=quote.version,
                    expected_total=quote.total_price,
                    nonce=quote.nonce,
                )
                counters.purchases += 1
            elif quote.finance_type is not None and quote.balance >= quote.down_payment:
                await engine.shop.purchase(
                    user_id,
                    item_id,
                    quote.quantity,
                    expected_version=quote.version,
                    expected_total=quote.total_price,
                    nonce=quote.nonce,
                    payment_method="finance",
                    expected_down_payment=quote.down_payment,
                )
                counters.purchases += 1
        except GameError:
            counters.expected_rule_rejections += 1

    if character.age >= 18 and decision_rng.random() < 0.025:
        try:
            _, items = await engine.shop.inventory(user_id)
            sellable = [
                item for item in items
                if int(item["quantity"]) > 0 and not item["is_locked"] and not item["collateralized"]
                and item["item_id"] not in {"driver_license", "fishing_license", "hunting_license"}
            ]
            if sellable:
                item = decision_rng.choice(sellable)
                await engine.shop.sell(user_id, str(item["item_id"]), 1)
                counters.sales += 1
        except GameError:
            counters.expected_rule_rejections += 1

    if user_id in integration_users and character.age == 18:
        # The integration cohort has explicit test-only seed funds. This exercises
        # mortgage, stock, casino, and player-trade paths without biasing the
        # unseeded economic distribution reported below.
        try:
            quote = await engine.shop.quote_purchase(user_id, "trailer")
            if quote.finance_type is not None and quote.balance >= quote.down_payment:
                await engine.shop.purchase(
                    user_id,
                    quote.item_id,
                    quote.quantity,
                    expected_version=quote.version,
                    expected_total=quote.total_price,
                    nonce=quote.nonce,
                    payment_method="finance",
                    expected_down_payment=quote.down_payment,
                )
                counters.purchases += 1
            guitar = await engine.shop.quote_purchase(user_id, "guitar")
            receipt = await engine.shop.purchase(
                user_id,
                guitar.item_id,
                guitar.quantity,
                expected_version=guitar.version,
                expected_total=guitar.total_price,
                nonce=guitar.nonce,
            )
            integration_assets[user_id] = receipt.asset_id
            counters.purchases += 1

            quote_list = await engine.investing.market(user_id)
            listed = [quote for quote in quote_list if not quote.delisted]
            if listed:
                stock = min(listed, key=lambda quote: quote.price_cents)
                await engine.investing.buy(user_id, stock.symbol, 1)
                counters.stock_buys += 1
                clock.advance(61)
                await engine.investing.sell(user_id, stock.symbol, 1)
                counters.stock_sells += 1
            if index % 4 == 2:
                await engine.investing.bond_buy(user_id, 50_000)
                counters.bonds_bought += 1
        except GameError:
            counters.expected_rule_rejections += 1

    if character.age >= 21 and user_id in ADDICTION_PROFILE_USERS and decision_rng.random() < 0.35:
        current = await engine.get_active_character(user_id)
        if current.cash + current.bank >= 100 and not current.in_prison:
            clock.advance(4)
            game = decision_rng.choice(("slots", "coinflip", "roulette"))
            try:
                if game == "slots":
                    await engine.casino.play_slots(user_id, 100)
                elif game == "coinflip":
                    await engine.casino.play_coinflip(user_id, decision_rng.choice(("heads", "tails")), 100)
                else:
                    await engine.casino.play_roulette(user_id, decision_rng.choice(("red", "black", "odd", "even")), 100)
            except GameError:
                counters.expected_rule_rejections += 1
            else:
                counters.casino_plays += 1

    if character.age == 21 and user_id in integration_assets:
        current = await engine.get_active_character(user_id)
        if current.cash + current.bank >= 100 and not current.in_prison:
            clock.advance(4)
            try:
                receipt = await engine.casino.blackjack_start(user_id, 100)
                if receipt.status == "active" and receipt.session_id is not None and receipt.nonce is not None:
                    await engine.casino.blackjack_action(
                        user_id, receipt.session_id, receipt.nonce, "stand"
                    )
                counters.casino_plays += 1
            except GameError:
                counters.expected_rule_rejections += 1

    if USER_ID_BASE + index in RETIREMENT_PROFILE_USERS and character.age >= 40:
        prompt = await engine.death.begin_retirement(user_id)
        await engine.death.confirm_retirement(user_id, prompt.prompt_id, prompt.nonce)
        counters.retirements += 1
        return replace(character, is_alive=False, death_cause="Life abandoned", death_age=character.age)

    return await engine.get_active_character(user_id)


ADDICTION_PROFILE_USERS: set[int] = set()
RETIREMENT_PROFILE_USERS = {
    USER_ID_BASE + 24 + 25 * cohort_index for cohort_index in range(20)
}
ILLNESS_PROFILE_USERS = {
    USER_ID_BASE + index for index in (98, 198, 298, 398, 498)
}


@pytest.mark.asyncio
@pytest.mark.skipif(
    os.getenv("LIFELINE_RUN_FULL_LIVES") != "1",
    reason="500 complete lives are an opt-in, multi-minute integration harness",
)
async def test_500_fixed_seed_complete_lives(database):
    """Run 500 seeded end-to-end lives and assert persisted invariants and broad route coverage."""
    global ADDICTION_PROFILE_USERS
    clock = SimulationClock()
    locks = UserLockRegistry()
    engine = LifeEngine(
        database,
        RNG(SIMULATION_SEED),
        locks,
        clock=clock,
        event_chance=0.12,
    )
    education = EducationService(database, locks, clock=clock)
    decision_rng = RNG(SIMULATION_SEED ^ 0x5A17)
    await engine.investing.initialize_market()

    integration_users = {USER_ID_BASE + index for index in range(20)}
    addiction_users = {USER_ID_BASE + index for index in range(LIFE_COUNT) if index % 5 == 1}
    ADDICTION_PROFILE_USERS = addiction_users
    integration_assets: dict[int, int] = {}
    active_users = set(range(USER_ID_BASE, USER_ID_BASE + LIFE_COUNT))
    counters = RunCounters()
    illness_users = ILLNESS_PROFILE_USERS

    for index in range(LIFE_COUNT):
        user_id = USER_ID_BASE + index
        character = await engine.create_character(user_id, f"Simulated Life {index:03d}")
        if user_id in integration_users:
            character = await _save_character(engine, character, bank=5_000_000)
            await engine.shop.register_player(user_id, clock.value - 8 * 24 * 60 * 60)
        if user_id in illness_users:
            character = await engine.get_active_character(user_id)
            hidden = replace(character.hidden, genetic_health_mod=-20)
            await _save_character(engine, character, stats=replace(character.stats, health=0), hidden=hidden)

    pair_ids = [(USER_ID_BASE + index, USER_ID_BASE + index + 1) for index in range(0, 20, 2)]

    for _simulated_year in range(1, GameBalance.MAX_AGE + 1):
        clock.advance(3_600)
        for user_id in sorted(tuple(active_users)):
            character = await engine.get_active_character(user_id)
            index = user_id - USER_ID_BASE
            if user_id in addiction_users and character.age == 20:
                changed = replace(character.stats, addiction=65)
                character = await _save_character(engine, character, stats=changed)
            if user_id in addiction_users and character.age == 20 and character.bank + character.cash < 2_000_000:
                character = await _save_character(engine, character, bank=2_000_000)

            outcome = await engine.age_up(user_id)
            counters.annual_steps += 1
            _assert_character_invariants(outcome.character)
            await _resolve_age_prompts(engine, user_id, outcome, decision_rng, counters)
            if outcome.died:
                active_users.remove(user_id)
                continue

            character = await engine.get_active_character(user_id)
            character = await _run_adult_decisions(
                engine,
                education,
                user_id,
                character,
                index,
                decision_rng,
                clock,
                counters,
                integration_users,
                integration_assets,
            )
            _assert_character_invariants(character)
            if not character.is_alive:
                active_users.discard(user_id)

        if _simulated_year == 18:
            for sender_id, target_id in pair_ids:
                sender_asset = integration_assets.get(sender_id)
                target_asset = integration_assets.get(target_id)
                if sender_asset is None or target_asset is None:
                    continue
                try:
                    offer = await engine.shop.create_trade(
                        sender_id,
                        target_id,
                        offered_items={sender_asset: 1},
                        requested_items={target_asset: 1},
                    )
                    if (sender_id - USER_ID_BASE) % 4 == 0:
                        await engine.shop.accept_trade(offer.trade_id, target_id, offer.nonce)
                    else:
                        await engine.shop.cancel_trade(offer.trade_id, sender_id, offer.nonce)
                    counters.trades += 1
                except GameError:
                    counters.expected_rule_rejections += 1

        if not active_users:
            break

    assert not active_users, f"{len(active_users)} lives did not reach a terminal state by max age"

    # Durable cohort, item, loan, prompt, and SQLite invariants.
    archive_rows = await database.fetchall(
        "SELECT char_id, user_id, death_age, death_cause, final_net_worth_cents, summary_json, abandoned "
        "FROM past_lives ORDER BY user_id"
    )
    assert len(archive_rows) == LIFE_COUNT
    assert len({int(row["char_id"]) for row in archive_rows}) == LIFE_COUNT
    assert await database.fetchone("SELECT 1 FROM characters WHERE is_alive = 1") is None
    assert await database.fetchone("SELECT 1 FROM pending_events LIMIT 1") is None
    assert await database.fetchone("SELECT 1 FROM casino_compulsions WHERE status = 'pending' LIMIT 1") is None
    assert await database.fetchone("SELECT 1 FROM casino_sessions WHERE status = 'active' LIMIT 1") is None
    assert await database.fetchone("SELECT 1 FROM crime_trials LIMIT 1") is None
    assert await database.fetchone("SELECT 1 FROM crime_tax_prompts LIMIT 1") is None
    assert await database.fetchone("SELECT 1 FROM family_assets WHERE is_locked = 1 LIMIT 1") is None
    assert await database.fetchone("SELECT 1 FROM loans WHERE status = 'active' LIMIT 1") is None
    assert await database.fetchone(
        "SELECT char_id FROM past_lives GROUP BY char_id HAVING COUNT(*) != 1 LIMIT 1"
    ) is None
    assert await database.fetchone(
        "SELECT char_id, achievement_id FROM achievements_unlocked "
        "GROUP BY char_id, achievement_id HAVING COUNT(*) != 1 LIMIT 1"
    ) is None
    integrity = await database.fetchone("PRAGMA integrity_check")
    assert integrity is not None and integrity[0] == "ok"
    assert await database.fetchall("PRAGMA foreign_key_check") == []

    persisted = await database.fetchall("SELECT char_id, data_json FROM characters")
    assert len(persisted) == LIFE_COUNT
    for row in persisted:
        character = Character.from_dict(json.loads(row["data_json"]))
        _assert_character_invariants(character)

    death_causes = Counter(str(row["death_cause"]) for row in archive_rows)
    retired = sum(bool(row["abandoned"]) for row in archive_rows)
    summaries = [json.loads(row["summary_json"]) for row in archive_rows]
    assert all(
        "name" in summary and "debts_due_cents" in summary
        and "life_years" in summary and "summary_json" not in summary
        for summary in summaries
    )
    natural_summaries = [summary for summary in summaries if not summary["abandoned"]]
    unseeded = [
        summary for summary in natural_summaries
        if int(summary["user_id"]) not in integration_users | addiction_users
    ]
    final_worths = [int(summary["final_net_worth_cents"]) for summary in unseeded]
    millionaire_rate = (
        sum(value >= 100_000_000 for value in final_worths) / len(final_worths)
        if final_worths else 0.0
    )
    billionaire_rate = (
        sum(value >= 100_000_000_000 for value in final_worths) / len(final_worths)
        if final_worths else 0.0
    )
    bankrupt_triggered = sum(
        int(summary["debts_due_cents"]) > int(summary["gross_assets_cents"])
        or any(int(year["net_worth_cents"]) < 0 for year in summary["life_years"])
        for summary in unseeded
    )
    bankruptcy_trigger_rate = bankrupt_triggered / len(unseeded) if unseeded else 0.0
    crime_ages = [
        int(summary["death_age"]) for summary in natural_summaries
        if (int(summary["user_id"]) - USER_ID_BASE) % 5 == 0
    ]
    addiction_ages = [
        int(summary["death_age"]) for summary in natural_summaries
        if (int(summary["user_id"]) - USER_ID_BASE) % 5 == 1
    ]
    natural_ages = [int(summary["death_age"]) for summary in natural_summaries]
    promotion_rows = await database.fetchall(
        "SELECT char_id, MIN(age) AS first_promotion_age FROM life_logs "
        "WHERE text LIKE 'Promoted to %' GROUP BY char_id"
    )
    promotion_ages = [int(row["first_promotion_age"]) for row in promotion_rows]
    casino_rtp = await database.fetchall(
        "SELECT game, SUM(bet_cents) AS stake, SUM(payout_cents) AS payout, COUNT(*) AS hands "
        "FROM casino_plays WHERE status = 'settled' GROUP BY game ORDER BY game"
    )
    casino_summary = {
        str(row["game"]): {
            "hands": int(row["hands"]),
            "stake_cents": int(row["stake"] or 0),
            "payout_cents": int(row["payout"] or 0),
            "observed_rtp": round(int(row["payout"] or 0) / int(row["stake"] or 1), 4),
        }
        for row in casino_rtp
    }

    report = {
        "seed": SIMULATION_SEED,
        "lives": LIFE_COUNT,
        "annual_steps": counters.annual_steps,
        "terminal_causes": dict(sorted(death_causes.items())),
        "retirements": retired,
        "natural_lifespan_median": median(natural_ages),
        "crime_heavy_natural_lifespan_median": median(crime_ages) if crime_ages else None,
        "addiction_profile_natural_lifespan_median": median(addiction_ages) if addiction_ages else None,
        "unseeded_lives_for_finance_rates": len(unseeded),
        "unseeded_final_net_worth_median_cents": median(final_worths) if final_worths else None,
        "unseeded_millionaire_rate": round(millionaire_rate, 4),
        "unseeded_billionaire_rate": round(billionaire_rate, 4),
        "unseeded_existing_bankruptcy_trigger_rate": round(bankruptcy_trigger_rate, 4),
        "first_promotion_count": len(promotion_ages),
        "first_promotion_age_median": median(promotion_ages) if promotion_ages else None,
        "casino_by_game": casino_summary,
        "route_counters": {
            "events_resolved": counters.events_resolved,
            "studies": counters.studies,
            "college_enrollments": counters.college_enrollments,
            "jobs_started": counters.jobs_started,
            "work_actions": counters.work_actions,
            "dates": counters.dates,
            "family_actions": counters.family_actions,
            "crimes_attempted": counters.crimes_attempted,
            "trials_resolved": counters.trials_resolved,
            "prison_actions": counters.prison_actions,
            "purchases": counters.purchases,
            "sales": counters.sales,
            "trades": counters.trades,
            "casino_plays": counters.casino_plays,
            "compulsions": counters.compulsions,
            "stock_buys": counters.stock_buys,
            "stock_sells": counters.stock_sells,
            "bonds_bought": counters.bonds_bought,
            "retirements": counters.retirements,
            "expected_rule_rejections": counters.expected_rule_rejections,
        },
    }
    print("FULL_LIFE_SIMULATION_REPORT=" + json.dumps(report, sort_keys=True))

    assert counters.annual_steps >= LIFE_COUNT * 30
    assert counters.events_resolved > 0
    assert counters.studies > 0 and counters.college_enrollments > 0
    assert counters.jobs_started > 0 and counters.work_actions > 0
    assert counters.dates > 0 and counters.family_actions > 0
    assert counters.crimes_attempted > 0 and counters.trials_resolved > 0
    assert counters.prison_actions > 0
    assert counters.purchases > 0 and counters.sales > 0
    assert counters.trades >= 5
    assert counters.casino_plays > 0 and counters.compulsions > 0
    assert counters.stock_buys >= 5 and counters.stock_sells >= 5 and counters.bonds_bought > 0
    # One or more seeded retirement-profile lives may die naturally before age 40.
    # Require broad retirement-route coverage, then cross-check the exact persisted count.
    assert counters.retirements >= 15
    assert death_causes["illness"] >= len(illness_users)
    assert death_causes["Life abandoned"] == retired == counters.retirements
~~~~

## `tests/test_exploits.py`

~~~~python
"""Concurrency, stale-control, rollback, and economy-exploit regressions."""
from __future__ import annotations

import asyncio
from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from cogs.casino import BlackjackView, CompulsionView
from cogs.discobot import _ship_compatibility_score
from cogs.shop_views import ShopQuoteView, safe_label
from core.casino import CasinoService
from core.errors import FamilyRequirementError, GameError, StaleShopQuote, ValidationError
from core.life_engine import LifeEngine
from core.locks import UserLockRegistry
from core.models import Character
from core.rng import RNG
from core.views import EventChoiceView
from core.shop import ShopService
from core.embeds import safe_text


class NoNaturalShuffleRNG(RNG):
    """Shuffle a blackjack shoe so the opening deal is 2, 3, 4, 5 (no natural)."""

    def shuffle(self, values: list[str]) -> None:
        deal_order = ["2♠", "3♠", "4♠", "5♠"]
        for card in deal_order:
            values.remove(card)
        values.extend(reversed(deal_order))


class FakeInteraction:
    """Minimal interaction object for exercising component authorization offline."""

    def __init__(self, user_id: int, custom_id: str) -> None:
        self.user = SimpleNamespace(id=user_id)
        self.data = {"custom_id": custom_id}
        self.response = SimpleNamespace(send_message=AsyncMock())


async def _set_character(engine, user_id: int, **changes: object) -> Character:
    """Update a character through the engine's versioned transactional save."""
    character = await engine.get_active_character(user_id)
    updated = replace(character, **changes, version=character.version + 1)
    async with engine.db.transaction() as tx:
        await engine._save_character(tx, updated, expected_version=character.version)
    return updated


async def _adult(engine, user_id: int, *, cash: int = 1_000_000, bank: int = 0) -> Character:
    """Create an adult with deterministic funds for one exploit regression."""
    await engine.create_character(user_id, f"Exploit {user_id}")
    return await _set_character(engine, user_id, age=25, cash=cash, bank=bank)


async def _quote_and_buy(shop: ShopService, user_id: int, item_id: str):
    """Buy exactly the item covered by a persisted quote."""
    quote = await shop.quote_purchase(user_id, item_id)
    return await shop.purchase(
        user_id,
        item_id,
        quote.quantity,
        expected_version=quote.version,
        expected_total=quote.total_price,
        nonce=quote.nonce,
    )


@pytest.mark.asyncio
async def test_concurrent_age_requests_advance_exactly_one_year_each(life_engine, database):
    """Concurrent age requests serialize and each writes one distinct annual record."""
    await life_engine.create_character(92001, "Age Race")

    first, second = await asyncio.gather(
        life_engine.age_up(92001),
        life_engine.age_up(92001),
    )

    assert sorted((first.new_age, second.new_age)) == [1, 2]
    character = await life_engine.get_active_character(92001)
    assert character.age == 2
    metrics = await database.fetchall(
        "SELECT age FROM life_year_metrics WHERE char_id = ? ORDER BY age",
        (character.char_id,),
    )
    assert [int(row["age"]) for row in metrics] == [1, 2]


@pytest.mark.asyncio
async def test_concurrent_event_resolution_consumes_nonce_once(database, life_engine):
    """Two simultaneous clicks on one saved event produce one effect and one history row."""
    from core.life_engine import LifeEngine
    from core.locks import UserLockRegistry

    engine = LifeEngine(
        database,
        RNG(92002),
        UserLockRegistry(),
        clock=lambda: 1_800_000_000,
        event_chance=1.0,
    )
    await engine.create_character(92002, "Event Race")
    outcome = await engine.age_up(92002)
    prompt = outcome.pending_event
    assert prompt is not None
    choice_id = prompt.event.choices[0].id

    results = await asyncio.gather(
        engine.events.resolve_choice(92002, prompt.nonce, choice_id),
        engine.events.resolve_choice(92002, prompt.nonce, choice_id),
        return_exceptions=True,
    )

    assert sum(not isinstance(result, BaseException) for result in results) == 1
    assert sum(isinstance(result, GameError) for result in results) == 1
    rows = await database.fetchall(
        "SELECT event_key FROM character_events WHERE char_id = ?",
        (outcome.character.char_id,),
    )
    assert len(rows) == 1
    assert await database.fetchone(
        "SELECT 1 FROM pending_events WHERE char_id = ?",
        (outcome.character.char_id,),
    ) is None


@pytest.mark.asyncio
async def test_concurrent_trade_accept_and_cancel_have_one_terminal_winner(life_engine, database):
    """A real accept/cancel race cannot transfer cash twice or leave a pending trade."""
    shop = life_engine.shop
    sender_id, target_id = 92003, 92004
    await _adult(life_engine, sender_id, cash=10_000)
    await _adult(life_engine, target_id, cash=10_000)
    now = int(life_engine.clock())
    await shop.register_player(sender_id, now - 8 * 24 * 60 * 60)
    await shop.register_player(target_id, now - 8 * 24 * 60 * 60)
    offer = await shop.create_trade(
        sender_id,
        target_id,
        offered_items={},
        requested_items={},
        offer_cash=100,
    )

    accepted, cancelled = await asyncio.gather(
        shop.accept_trade(offer.trade_id, target_id, offer.nonce),
        shop.cancel_trade(offer.trade_id, sender_id, offer.nonce),
    )

    terminal = [result for result in (accepted, cancelled) if result.success]
    assert len(terminal) == 1
    row = await database.fetchone(
        "SELECT status FROM trades WHERE trade_id = ?",
        (offer.trade_id,),
    )
    assert row["status"] in {"accepted", "cancelled"}
    assert await database.fetchone(
        "SELECT 1 FROM trades WHERE trade_id = ? AND status = 'pending'",
        (offer.trade_id,),
    ) is None
    left = await life_engine.get_active_character(sender_id)
    right = await life_engine.get_active_character(target_id)
    if row["status"] == "accepted":
        assert left.cash == 9_895  # 100¢ offer plus 5¢ minimum trade tax
        assert right.cash == 10_100
    else:
        assert (left.cash, right.cash) == (10_000, 10_000)


@pytest.mark.asyncio
async def test_concurrent_blackjack_settlement_credits_one_payout(life_engine, database):
    """Parallel stand clicks consume a blackjack nonce and settle escrow exactly once."""
    user_id = 92005
    await _adult(life_engine, user_id, cash=500_000, bank=500_000)
    await _set_character(life_engine, user_id, age=21)
    casino = CasinoService(
        database,
        NoNaturalShuffleRNG(92005),
        life_engine.locks,
        clock=life_engine.clock,
    )
    starting = await life_engine.get_active_character(user_id)
    prompt = await casino.blackjack_start(user_id, 10_000)
    assert prompt.status == "active"
    assert prompt.session_id is not None and prompt.nonce is not None

    results = await asyncio.gather(
        casino.blackjack_action(user_id, prompt.session_id, prompt.nonce, "stand"),
        casino.blackjack_action(user_id, prompt.session_id, prompt.nonce, "stand"),
        return_exceptions=True,
    )

    settled = [result for result in results if not isinstance(result, BaseException)]
    rejected = [result for result in results if isinstance(result, BaseException)]
    assert len(settled) == 1
    assert len(rejected) == 1 and isinstance(rejected[0], GameError)
    play = await database.fetchone(
        "SELECT status, bet_cents, payout_cents FROM casino_plays WHERE char_id = ? AND game = 'blackjack'",
        (starting.char_id,),
    )
    assert play["status"] == "settled"
    assert int(play["bet_cents"]) == 10_000
    updated = await life_engine.get_active_character(user_id)
    assert updated.cash + updated.bank == starting.cash + starting.bank - 10_000 + int(play["payout_cents"])
    session = await database.fetchone(
        "SELECT status FROM casino_sessions WHERE char_id = ?",
        (starting.char_id,),
    )
    assert session["status"] == "settled"


@pytest.mark.asyncio
async def test_stale_shop_quote_is_rejected_after_character_version_changes(life_engine):
    """A price quote cannot spend against an outdated character snapshot."""
    user_id = 92006
    await _adult(life_engine, user_id, cash=1_000_000)
    shop = life_engine.shop
    quote = await shop.quote_purchase(user_id, "phone")
    await _set_character(life_engine, user_id, cash=1_000_001)

    with pytest.raises(StaleShopQuote):
        await shop.purchase(
            user_id,
            quote.item_id,
            quote.quantity,
            expected_version=quote.version,
            expected_total=quote.total_price,
            nonce=quote.nonce,
        )


@pytest.mark.asyncio
async def test_invalid_amounts_and_self_trading_are_rejected(life_engine):
    """Invalid cents, quantities, share counts, and self-trade attempts have no effect."""
    user_id = 92007
    await _adult(life_engine, user_id, cash=1_000_000, bank=1_000_000)

    with pytest.raises(ValidationError):
        await life_engine.casino.play_slots(user_id, 99)
    with pytest.raises(ValidationError):
        await life_engine.shop.sell(user_id, "phone", 0)
    with pytest.raises(ValidationError):
        await life_engine.investing.buy(user_id, "LIF", 0)
    with pytest.raises(ValidationError, match="yourself"):
        await life_engine.shop.create_trade(
            user_id,
            user_id,
            offered_items={},
            requested_items={},
            offer_cash=1,
        )
    saved = await life_engine.get_active_character(user_id)
    assert (saved.cash, saved.bank) == (1_000_000, 1_000_000)


@pytest.mark.asyncio
async def test_unsafe_age_gap_cannot_be_reintroduced_through_a_tampered_date_session(life_engine, database):
    """The service rechecks a date's age range rather than trusting its original menu."""
    user_id = 92008
    await life_engine.create_character(user_id, "Age Boundary")
    await _set_character(life_engine, user_id, age=17)
    search = await life_engine.family.find_dates(user_id)
    candidate = search.candidates[0]
    assert int(candidate["age"]) < 18
    await database.execute(
        "UPDATE npcs SET age = 18 WHERE npc_id = ?",
        (candidate["npc_id"],),
    )

    with pytest.raises(FamilyRequirementError, match="Dating age rules"):
        await life_engine.family.choose_date(user_id, int(candidate["npc_id"]), search.nonce)


@pytest.mark.asyncio
async def test_shop_buy_then_sell_realizes_catalogued_loss(life_engine):
    """Selling a newly purchased non-housing item returns the documented 85% value."""
    user_id = 92009
    await _adult(life_engine, user_id, cash=1_000_000)
    shop = life_engine.shop
    purchase = await _quote_and_buy(shop, user_id, "used_car")
    sale = await shop.sell(user_id, "used_car", 1)

    assert sale.payout == purchase.total_price * 85 // 100
    assert sale.payout < purchase.total_price


@pytest.mark.asyncio
async def test_shop_purchase_transaction_rolls_back_balance_and_asset(life_engine, database, monkeypatch):
    """An injected audit failure rolls back the debit and inventory insert together."""
    user_id = 92010
    await _adult(life_engine, user_id, cash=1_000_000)
    shop = life_engine.shop
    before = await life_engine.get_active_character(user_id)
    quote = await shop.quote_purchase(user_id, "phone")

    async def fail_audit(*args, **kwargs):
        raise RuntimeError("injected purchase audit failure")

    monkeypatch.setattr(shop.repository, "insert_audit", fail_audit)
    with pytest.raises(RuntimeError, match="injected purchase"):
        await shop.purchase(
            user_id,
            quote.item_id,
            quote.quantity,
            expected_version=quote.version,
            expected_total=quote.total_price,
            nonce=quote.nonce,
        )

    after = await life_engine.get_active_character(user_id)
    assert (after.cash, after.bank, after.version) == (before.cash, before.bank, before.version)
    assert await database.fetchone(
        "SELECT 1 FROM family_assets WHERE char_id = ? AND item_id = 'phone'",
        (before.char_id,),
    ) is None
    assert await database.fetchone(
        "SELECT 1 FROM audit_log WHERE action = 'shop_purchase' AND char_id = ?",
        (before.char_id,),
    ) is None


@pytest.mark.asyncio
async def test_casino_transaction_rolls_back_wager_debit_and_limits(life_engine, database, monkeypatch):
    """An injected casino-ledger failure rolls back balance, wager count, and play row."""
    user_id = 92011
    await _adult(life_engine, user_id, cash=500_000, bank=500_000)
    await _set_character(life_engine, user_id, age=21)
    casino = life_engine.casino
    before = await life_engine.get_active_character(user_id)

    async def fail_insert(*args, **kwargs):
        raise RuntimeError("injected casino ledger failure")

    monkeypatch.setattr(casino.repository, "insert_play", fail_insert)
    with pytest.raises(RuntimeError, match="injected casino"):
        await casino.play_slots(user_id, 10_000)

    after = await life_engine.get_active_character(user_id)
    assert (after.cash, after.bank, after.version) == (before.cash, before.bank, before.version)
    assert await database.fetchone(
        "SELECT 1 FROM casino_plays WHERE char_id = ?",
        (before.char_id,),
    ) is None
    assert await database.fetchone(
        "SELECT last_bet_at FROM casino_player_state WHERE user_id = ?",
        (user_id,),
    ) is None


@pytest.mark.asyncio
async def test_shop_component_checks_owner_nonce_and_used_state(life_engine):
    """An open Discord quote is bound to its owner and exact component nonce."""
    user_id = 92012
    await _adult(life_engine, user_id, cash=1_000_000)
    shop = life_engine.shop
    quote = await shop.quote_purchase(user_id, "phone")
    view = ShopQuoteView(user_id, quote, shop)

    other = FakeInteraction(user_id + 1, f"shop:cash:{quote.nonce}")
    assert not await view._authorize(other, "cash")
    other.response.send_message.assert_awaited_once()

    stale = FakeInteraction(user_id, f"shop:cash:{quote.nonce}-stale")
    assert not await view._authorize(stale, "cash")
    stale.response.send_message.assert_awaited_once()

    valid = FakeInteraction(user_id, f"shop:cash:{quote.nonce}")
    assert await view._authorize(valid, "cash")
    view._finish()
    assert all(item.disabled for item in view.children)
    used = FakeInteraction(user_id, f"shop:cash:{quote.nonce}")
    assert not await view._authorize(used, "cash")


def test_user_text_is_escaped_before_embed_or_catalog_rendering():
    """Mention tokens and markdown supplied as player text cannot ping or spoof formatting."""
    raw = "@everyone <@123456789> **spoofed**"
    assert "@everyone" not in safe_text(raw)
    assert "<@123456789>" not in safe_text(raw)
    assert "@everyone" not in safe_label(raw)
    assert "<@123456789>" not in safe_label(raw)


def test_social_pair_score_is_stable_symmetric_and_rng_wrapper_only():
    """The social ship score no longer mutates or depends on process-global randomness."""
    assert _ship_compatibility_score(92014, 92015) == _ship_compatibility_score(92015, 92014)
    assert 0 <= _ship_compatibility_score(92014, 92015) <= 100
    shared = RNG(92016)
    expected = shared.randint(1, 100)
    actual = RNG(92016).randint(1, 100)
    _ship_compatibility_score(92014, 92015)
    assert expected == actual


@pytest.mark.asyncio
async def test_event_and_blackjack_components_reject_nonowners(life_engine, database):
    """Event and blackjack controls reject another Discord user before service execution."""
    user_id = 92018
    engine = LifeEngine(
        database,
        RNG(92018),
        UserLockRegistry(),
        clock=life_engine.clock,
        event_chance=1.0,
    )
    await engine.create_character(user_id, "Component Owner")
    prompt = (await engine.age_up(user_id)).pending_event
    assert prompt is not None

    event_view = EventChoiceView(user_id, prompt, engine.events)
    event_intruder = FakeInteraction(user_id + 1, f"life:event:{prompt.nonce}:{prompt.event.choices[0].id}")
    assert not await event_view.interaction_check(event_intruder)
    event_intruder.response.send_message.assert_awaited_once()

    blackjack_view = BlackjackView(user_id, life_engine.casino, 1, "component-nonce")
    blackjack_intruder = FakeInteraction(user_id + 1, "bj:1:component-nonce:stand")
    await blackjack_view.handle_action(blackjack_intruder, "stand")
    blackjack_intruder.response.send_message.assert_awaited_once()


@pytest.mark.asyncio
async def test_compulsion_component_rejects_nonowner(life_engine):
    """The addiction prompt checks ownership before touching its nonce-backed service."""
    user_id = 92019
    view = CompulsionView(
        user_id,
        life_engine.casino,
        {"compulsion_id": 1, "nonce": "component-nonce"},
    )
    intruder = FakeInteraction(user_id + 1, "compulsion:1:component-nonce:resist")
    await view.resolve(intruder, "resist")
    intruder.response.send_message.assert_awaited_once()


@pytest.mark.asyncio
async def test_retirement_cannot_be_farmed_for_legacy_points(life_engine, database):
    """Repeated retire/start cycles archive records but award neither points nor lives-lived."""
    user_id = 92013
    for cycle in range(3):
        await life_engine.create_character(user_id, f"Retire cycle {cycle}")
        prompt = await life_engine.death.begin_retirement(user_id)
        result = await life_engine.death.confirm_retirement(
            user_id,
            prompt.prompt_id,
            prompt.nonce,
        )
        assert result.summary["abandoned"] is True
        assert result.summary["legacy_points"] == 0

    player = await database.fetchone(
        "SELECT lives_lived, legacy_points FROM players WHERE user_id = ?",
        (user_id,),
    )
    assert (int(player["lives_lived"]), int(player["legacy_points"])) == (0, 0)
    archives = await database.fetchone(
        "SELECT COUNT(*) AS n, SUM(abandoned) AS abandoned FROM past_lives WHERE user_id = ?",
        (user_id,),
    )
    assert (int(archives["n"]), int(archives["abandoned"])) == (3, 3)


def test_player_bankruptcy_farming_is_explicitly_unsupported():
    """The model has a reserved field but no player bankruptcy command or transition."""
    from core.life_engine import LifeEngine

    assert Character().bankrupt_until_age is None
    assert not callable(getattr(LifeEngine, "declare_bankruptcy", None))
    assert not callable(getattr(ShopService, "declare_bankruptcy", None))
~~~~

## `tests/test_measure_balance.py`

~~~~python
"""Deterministic checks for the headless Stage 12 balance measurement logic."""
from __future__ import annotations

from core.data_loader import DataLoader
from core.rng import RNG
from tools import measure_balance


class FailedButCaughtRNG(RNG):
    """Force an unsuccessful, caught assault followed by a public-defender conviction."""

    def __init__(self, seed: int | None = None) -> None:
        super().__init__(seed)
        self.rolls = iter((0.99, 0.0, 0.0))

    def random(self) -> float:
        return next(self.rolls)

    def randint(self, a: int, b: int) -> int:
        return a


def test_violent_crime_measurement_counts_conviction_after_failed_attempt(monkeypatch) -> None:
    """Caught failed attempts can still be convicted and must contribute sentence exposure."""
    assault = next(
        row for row in DataLoader().load_crimes()["crimes"]
        if row["id"] == "assault"
    )
    monkeypatch.setattr(
        measure_balance.DataLoader,
        "load_crimes",
        lambda self: {"crimes": [assault]},
    )
    monkeypatch.setattr(measure_balance, "RNG", FailedButCaughtRNG)

    result = measure_balance.violent_crime_ev(trials=1, seed=123)
    measured = result["crimes"]["assault"]

    assert measured["observed_success_pct"] == 0.0
    assert measured["observed_arrest_pct"] == 100.0
    assert measured["observed_conviction_pct"] == 100.0
    assert measured["direct_net_ev_cents_per_attempt"] == 0
    assert measured["observed_custody_years_per_attempt"] == 1.0
~~~~

## `tests/test_migrations.py`

~~~~python
"""Migration repeatability and Stage 10 schema/rollback checks."""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import aiosqlite
import pytest

from core.db import DatabaseManager


@pytest.mark.asyncio
async def test_initialize_is_idempotent(database):
    await database.initialize()
    await database.close()
    await database.initialize()
    versions = await database.fetchall("SELECT version FROM schema_version ORDER BY version")
    assert [row["version"] for row in versions] == list(range(1, 12))
    tables = {row["name"] for row in await database.fetchall(
        "SELECT name FROM sqlite_master WHERE type = 'table'"
    )}
    assert {
        "characters", "life_logs", "schema_version", "education_actions", "jobs",
        "career_history", "career_actions", "npcs", "relationships", "children",
        "yearly_counters", "dating_sessions", "dating_candidates", "marriages",
        "pregnancies", "adoptions", "family_assets", "alimony", "affairs",
        "divorce_records", "stats_tracking", "infidelity_prompts", "infidelity_choices",
        "players", "shop_quotes", "trades", "trade_items", "trade_daily_usage",
        "inventory_uses", "audit_log", "health_conditions", "casino_player_state",
        "casino_yearly_bets", "casino_plays", "casino_sessions", "casino_compulsions",
        "casino_yearly_tax", "market_state", "stock_market", "stock_history",
        "stock_holdings", "investment_trades", "savings_bonds", "investment_yearly_income",
        "achievements_unlocked", "life_year_metrics", "marriage_history", "past_lives",
        "life_estates", "retirement_prompts", "legacy_start_purchases", "guild_player_seen",
        "guild_stage10_settings", "player_bans", "player_settings",
    }.issubset(tables)
    family_asset_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(family_assets)")}
    loan_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(loans)")}
    shop_quote_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(shop_quotes)")}
    assert "is_locked" in family_asset_columns
    assert {"principal", "annual_rate", "term_years", "years_remaining", "collateral_item_uid"}.issubset(loan_columns)
    assert {"nonce", "total_price", "balance_cents", "character_version", "expires_at"}.issubset(shop_quote_columns)
    stats_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(stats_tracking)")}
    assert {"total_gambled", "total_gambling_net", "gambling_addiction_fraction"}.issubset(stats_columns)
    player_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(players)")}
    assert {"lives_lived", "legacy_points", "leaderboard_opt_out"}.issubset(player_columns)
    achievement_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(achievements_unlocked)")}
    assert {"user_id", "achievement_id", "char_id", "unlocked_at"}.issubset(achievement_columns)
    archive_triggers = {
        row["name"] for row in await database.fetchall(
            "SELECT name FROM sqlite_master WHERE type = 'trigger' AND tbl_name = 'past_lives'"
        )
    }
    assert {"trg_past_lives_immutable_update", "trg_past_lives_immutable_delete"}.issubset(archive_triggers)
    audit_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(audit_log)")}
    assert {"admin_id", "target_user_id"}.issubset(audit_columns)
    settings_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(player_settings)")}
    assert {
        "user_id", "public_year_summaries", "public_deaths",
        "public_casino_results", "public_leaderboards", "updated_at",
    }.issubset(settings_columns)


@pytest.mark.asyncio
async def test_stage12_migration_unwraps_legacy_archive_json_and_restores_immutability(tmp_path):
    """The repair unwraps old summaries once, records version 11, and restores the update guard."""
    db_path = tmp_path / "migration-011-archive-repair.sqlite3"
    old_summary = {"char_id": 41, "name": "Legacy Archive", "death_age": 73}
    old_envelope = json.dumps({"char_id": 41, "user_id": 42, "summary_json": old_summary})
    async with aiosqlite.connect(db_path) as db:
        await db.execute(
            "CREATE TABLE schema_version(version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)"
        )
        await db.execute("INSERT INTO schema_version(version, applied_at) VALUES (10, 0)")
        await db.execute(
            "CREATE TABLE past_lives(char_id INTEGER PRIMARY KEY, summary_json TEXT NOT NULL)"
        )
        await db.execute(
            """CREATE TRIGGER trg_past_lives_immutable_update BEFORE UPDATE ON past_lives
               BEGIN SELECT RAISE(ABORT, 'past_lives rows are immutable'); END"""
        )
        await db.execute(
            "INSERT INTO past_lives(char_id, summary_json) VALUES (?, ?)",
            (41, old_envelope),
        )
        await db.commit()

    database = DatabaseManager(str(db_path))
    await database.initialize()
    row = await database.fetchone("SELECT summary_json FROM past_lives WHERE char_id = ?", (41,))
    assert json.loads(row["summary_json"]) == old_summary
    versions = await database.fetchall("SELECT version FROM schema_version ORDER BY version")
    assert [int(item["version"]) for item in versions] == [10, 11]
    await database.close()

    with sqlite3.connect(db_path) as connection:
        with pytest.raises(sqlite3.IntegrityError, match="immutable"):
            connection.execute(
                "UPDATE past_lives SET summary_json = '{}' WHERE char_id = 41"
            )


@pytest.mark.asyncio
async def test_stage11_migration_rolls_back_all_schema_changes_on_failure(tmp_path):
    """A failure after migration 010 statements leaves no partial admin/privacy schema."""
    db_path = tmp_path / "migration-010-rollback.sqlite3"
    async with aiosqlite.connect(db_path) as db:
        await db.execute("PRAGMA foreign_keys = ON")
        await db.execute("CREATE TABLE schema_version(version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)")
        await db.execute("INSERT INTO schema_version(version, applied_at) VALUES (9, 0)")
        await db.execute("CREATE TABLE players(user_id INTEGER PRIMARY KEY, created_at INTEGER NOT NULL)")
        await db.execute(
            """CREATE TABLE audit_log(
                   audit_id INTEGER PRIMARY KEY, ts INTEGER NOT NULL, user_id INTEGER,
                   char_id INTEGER, action TEXT NOT NULL, amount INTEGER, details_json TEXT NOT NULL
               )"""
        )
        await db.commit()

    migration = Path(__file__).resolve().parents[1] / "core" / "migrations" / "010_stage11_admin_settings.sql"
    sql = migration.read_text(encoding="utf-8")
    script = (
        "BEGIN IMMEDIATE;\n"
        + sql
        + "\nINSERT INTO schema_version(version, applied_at) VALUES (10, 1);"
        + "\nINSERT INTO deliberately_missing_table(value) VALUES (1);\nCOMMIT;"
    )
    async with aiosqlite.connect(db_path) as db:
        await db.execute("PRAGMA foreign_keys = ON")
        with pytest.raises(sqlite3.OperationalError, match="no such table"):
            await db.executescript(script)
        await db.rollback()

    async with aiosqlite.connect(db_path) as db:
        audit_columns = {row[1] for row in await (await db.execute("PRAGMA table_info(audit_log)")).fetchall()}
        tables = {row[0] for row in await (await db.execute("SELECT name FROM sqlite_master WHERE type = 'table'")).fetchall()}
        version = await (await db.execute("SELECT MAX(version) FROM schema_version")).fetchone()
    assert audit_columns == {"audit_id", "ts", "user_id", "char_id", "action", "amount", "details_json"}
    assert not {"player_bans", "player_settings"}.intersection(tables)
    assert int(version[0]) == 9


@pytest.mark.asyncio
async def test_stage10_migration_rolls_back_all_schema_changes_on_failure(tmp_path):
    """A failure after migration 009 statements leaves no partial columns or tables."""
    db_path = tmp_path / "migration-009-rollback.sqlite3"
    async with aiosqlite.connect(db_path) as db:
        await db.execute("PRAGMA foreign_keys = ON")
        await db.execute("CREATE TABLE schema_version(version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)")
        await db.execute("INSERT INTO schema_version(version, applied_at) VALUES (8, 0)")
        await db.execute("CREATE TABLE players(user_id INTEGER PRIMARY KEY, created_at INTEGER NOT NULL)")
        await db.execute("CREATE TABLE characters(char_id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, born_at INTEGER NOT NULL)")
        await db.commit()

    migration = Path(__file__).resolve().parents[1] / "core" / "migrations" / "009_achievements_legacy.sql"
    sql = migration.read_text(encoding="utf-8")
    script = (
        "BEGIN IMMEDIATE;\n"
        + sql
        + "\nINSERT INTO schema_version(version, applied_at) VALUES (9, 1);"
        + "\nINSERT INTO deliberately_missing_table(value) VALUES (1);\nCOMMIT;"
    )
    async with aiosqlite.connect(db_path) as db:
        await db.execute("PRAGMA foreign_keys = ON")
        with pytest.raises(sqlite3.OperationalError, match="no such table"):
            await db.executescript(script)
        await db.rollback()

    async with aiosqlite.connect(db_path) as db:
        columns = await (await db.execute("PRAGMA table_info(players)")).fetchall()
        tables = await (await db.execute("SELECT name FROM sqlite_master WHERE type = 'table'")).fetchall()
        version = await (await db.execute("SELECT MAX(version) FROM schema_version")).fetchone()
    assert {row[1] for row in columns} == {"user_id", "created_at"}
    assert "achievements_unlocked" not in {row[0] for row in tables}
    assert int(version[0]) == 8
~~~~

## `tests/test_stage10.py`

~~~~python
"""Integration coverage for Stage 10 scoring, death, estates, achievements, and rankings."""
from __future__ import annotations

import json
from dataclasses import replace
from typing import Any

import aiosqlite
import pytest

from core.death import (
    calculate_estate_settlement,
    calculate_life_score,
    grade_for_life_score,
    legacy_points_for_score,
    select_epitaph,
)
from core.errors import InsufficientFunds, ValidationError
from core.leaderboard import LeaderboardService
from core.money import dollars_to_cents
from core.repositories.legacy import LegacyRepository
from core.rng import RNG
from core.life_engine import LifeEngine
from core.locks import UserLockRegistry
from cogs.legacy_views import EmbedPager, leaderboard_embed


async def _make_dead_life(
    engine: LifeEngine,
    user_id: int,
    *,
    age: int = 40,
    cash_cents: int = 0,
    bank_cents: int = 0,
    debt_cents: int = 0,
    price_index: float = 1.0,
    happiness: int = 70,
    cause: str = "natural causes",
    now: int = 1_800_000_000,
    guild_id: int | None = None,
) -> tuple[Any, Any]:
    """Create and atomically archive one persisted terminal character."""
    character = await engine.create_character(user_id, f"Life {user_id}")
    dead = replace(
        character,
        is_alive=False,
        age=age,
        cash=cash_cents,
        bank=bank_cents,
        debt_total=debt_cents,
        price_index=price_index,
        stats=replace(character.stats, happiness=happiness),
        death_cause=cause,
        death_age=age,
        died_at=now,
        last_age_at=now,
        version=character.version + 1,
    )
    async with engine.db.transaction() as tx:
        await engine._save_character(tx, dead, expected_version=character.version)
        result = await engine.death.handle_death(
            tx, dead, now=now, guild_id=guild_id
        )
    return dead, result


async def _insert_child(
    engine: LifeEngine,
    parent_char_id: int,
    *,
    name: str,
    age: int,
    health: int,
    smarts: int,
    looks: int,
    wealth_cents: int,
    gender: str = "female",
    country: str = "usa",
) -> int:
    """Insert one authoritative child NPC for estate-continuation tests."""
    async with engine.db.transaction() as tx:
        cursor = await tx.execute(
            """INSERT INTO npcs
                   (owner_char_id, name, gender, age, looks, smarts, health, wealth,
                    occupation, is_alive, country, annual_income, prefers_smarts)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Student', 1, ?, 0, 0)""",
            (parent_char_id, name, gender, age, looks, smarts, health, wealth_cents, country),
        )
        npc_id = int(cursor.lastrowid)
        await tx.execute(
            "INSERT INTO children(npc_id, char_id, custody, child_support) VALUES (?, ?, 'full', 0)",
            (npc_id, parent_char_id),
        )
    return npc_id


async def _set_character_age(engine: LifeEngine, user_id: int, age: int) -> Any:
    """Change an active character's authoritative persisted age for ranking checks."""
    character = await engine.get_active_character(user_id)
    updated = replace(character, age=age, version=character.version + 1)
    async with engine.db.transaction() as tx:
        await engine._save_character(tx, updated, expected_version=character.version)
    return updated


def test_life_score_examples_grade_boundaries_and_legacy_rounding():
    """The documented score components, grade boundaries, and points rule are stable."""
    maximum = calculate_life_score(
        age=120,
        average_happiness=100,
        final_health=100,
        education_level="doctorate",
        career_years=100,
        children=20,
        marriage_count=1,
        peak_net_worth_cents=dollars_to_cents(20_000_000),
        unsealed_convictions=0,
    )
    minimum = calculate_life_score(
        age=0,
        average_happiness=0,
        final_health=0,
        education_level="none",
        career_years=0,
        children=0,
        marriage_count=0,
        peak_net_worth_cents=0,
        unsealed_convictions=1,
    )
    assert maximum == 100.0
    assert minimum == 0.0
    assert [(score, grade_for_life_score(score)) for score in (0, 39.99, 40, 54.99, 55, 69.99, 70, 79.99, 80, 89.99, 90, 100)] == [
        (0, "F"), (39.99, "F"), (40, "D"), (54.99, "D"),
        (55, "C"), (69.99, "C"), (70, "B"), (79.99, "B"),
        (80, "A"), (89.99, "A"), (90, "S"), (100, "S"),
    ]
    assert legacy_points_for_score(99.99) == 9
    assert legacy_points_for_score(100) == 10


@pytest.mark.parametrize(
    ("gross", "debt", "price_index", "paid", "tax", "estate", "unpaid"),
    [
        (dollars_to_cents(5_500_000), dollars_to_cents(500_000), 1.0,
         dollars_to_cents(500_000), 0, dollars_to_cents(5_000_000), 0),
        (dollars_to_cents(10_000_000), dollars_to_cents(1_000_000), 1.0,
         dollars_to_cents(1_000_000), dollars_to_cents(1_600_000), dollars_to_cents(7_400_000), 0),
        (dollars_to_cents(100), dollars_to_cents(500), 1.0, dollars_to_cents(100), 0, 0, dollars_to_cents(400)),
        (0, dollars_to_cents(2_000_000), 10.0, 0, 0, 0, dollars_to_cents(2_000_000)),
    ],
)
def test_estate_settlement_pays_debt_before_tax_and_never_goes_negative(
    gross: int,
    debt: int,
    price_index: float,
    paid: int,
    tax: int,
    estate: int,
    unpaid: int,
):
    """Debt is paid before the indexed threshold tax and every remainder is nonnegative."""
    result = calculate_estate_settlement(
        gross_assets_cents=gross,
        debts_due_cents=debt,
        price_index=price_index,
    )
    assert result.debts_paid_cents == paid
    assert result.estate_tax_cents == tax
    assert result.estate_cents == estate
    assert result.unpaid_debt_cents == unpaid
    assert min(result.debts_paid_cents, result.estate_tax_cents, result.estate_cents, result.unpaid_debt_cents) >= 0
    assert result.estate_cents + result.estate_tax_cents <= gross - paid


@pytest.mark.asyncio
async def test_death_is_exactly_once_archived_immutable_and_closes_career(database, life_engine):
    """A terminal life archives once, preserves its score, and closes career rows as died."""
    character = await life_engine.create_character(51001, "Archived Life")
    async with database.transaction() as tx:
        await tx.execute(
            """INSERT INTO career_history(char_id, career_id, max_level, start_age)
               VALUES (?, 'teacher', 2, 20)""",
            (character.char_id,),
        )
        await tx.execute(
            """INSERT INTO jobs(char_id, career_id, level, performance, years_in_role,
                                years_in_career, salary, is_part_time, warnings)
               VALUES (?, 'teacher', 2, 60, 4, 10, 5_000_000, 0, 0)""",
            (character.char_id,),
        )
        await life_engine.legacy_repository.record_life_year(
            tx, character=replace(character, stats=replace(character.stats, happiness=80)),
            age=1, served_prison_year=False, now=1_800_000_001,
        )
        await life_engine.legacy_repository.record_life_year(
            tx, character=replace(character, stats=replace(character.stats, happiness=100)),
            age=2, served_prison_year=False, now=1_800_000_002,
        )
    dead = replace(
        character,
        is_alive=False,
        age=40,
        death_cause="illness",
        death_age=40,
        died_at=1_800_000_010,
        last_age_at=1_800_000_010,
        version=character.version + 1,
        stats=replace(character.stats, happiness=60),
    )
    async with database.transaction() as tx:
        await life_engine._save_character(tx, dead, expected_version=character.version)
        await life_engine.legacy_repository.record_life_year(
            tx, character=dead, age=40, served_prison_year=False, now=1_800_000_010
        )
        result = await life_engine.death.handle_death(tx, dead, now=1_800_000_010)
    assert result is not None
    assert result.summary["death_age"] == 40
    assert result.summary["career_years"] == 20
    assert result.summary["average_happiness"] == 80.0
    assert result.summary["grade"] == grade_for_life_score(result.summary["life_score"])
    assert result.summary["legacy_points"] == legacy_points_for_score(result.summary["life_score"])
    career = await database.fetchone(
        "SELECT end_age, end_reason FROM career_history WHERE char_id = ?",
        (character.char_id,),
    )
    assert dict(career) == {"end_age": 40, "end_reason": "died"}
    assert await database.fetchone("SELECT 1 FROM jobs WHERE char_id = ?", (character.char_id,)) is None

    async with database.transaction() as tx:
        assert await life_engine.death.handle_death(tx, dead, now=1_800_000_011) is None
    archive_count = await database.fetchone(
        "SELECT COUNT(*) AS n FROM past_lives WHERE char_id = ?", (character.char_id,)
    )
    assert int(archive_count["n"]) == 1
    archived_summary_row = await database.fetchone(
        "SELECT summary_json FROM past_lives WHERE char_id = ?", (character.char_id,)
    )
    archived_summary = json.loads(archived_summary_row["summary_json"])
    assert archived_summary["name"] == "Archived Life"
    assert archived_summary["death_age"] == 40
    assert archived_summary["debts_due_cents"] == 0
    assert archived_summary["life_years"]
    assert "summary_json" not in archived_summary
    player = await database.fetchone("SELECT lives_lived, legacy_points FROM players WHERE user_id = ?", (character.user_id,))
    assert int(player["lives_lived"]) == 1
    assert int(player["legacy_points"]) == result.summary["legacy_points"]

    with pytest.raises(aiosqlite.IntegrityError, match="immutable"):
        async with database.transaction() as tx:
            await tx.execute("UPDATE past_lives SET grade = 'S' WHERE char_id = ?", (character.char_id,))
    with pytest.raises(aiosqlite.IntegrityError, match="immutable"):
        async with database.transaction() as tx:
            await tx.execute("DELETE FROM past_lives WHERE char_id = ?", (character.char_id,))
    archived = await database.fetchone("SELECT grade FROM past_lives WHERE char_id = ?", (character.char_id,))
    assert archived["grade"] == result.summary["grade"]


@pytest.mark.asyncio
async def test_estate_lot_value_debt_first_tax_and_heir_split_and_copy(database, life_engine):
    """Death values each inventory lot once, pays debt before tax, and divides heirs fairly."""
    character = await life_engine.create_character(51002, "Estate Parent")
    character = replace(
        character,
        cash=dollars_to_cents(6_000_000),
        bank=0,
        debt_total=dollars_to_cents(1_000_000),
        price_index=1.25,
        version=character.version + 1,
    )
    async with database.transaction() as tx:
        await life_engine._save_character(tx, character, expected_version=character.version - 1)
        await tx.execute(
            """INSERT INTO family_assets
                   (char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at)
               VALUES (?, 'item', 'house', 10, ?, ?, 25, 1_800_000_001)""",
            (character.char_id, dollars_to_cents(200_000), dollars_to_cents(2_000_000)),
        )
    child_ids = [
        await _insert_child(
            life_engine, character.char_id, name="Avery", age=35, health=91,
            smarts=87, looks=73, wealth_cents=dollars_to_cents(250_000), gender="female", country="ca",
        ),
        await _insert_child(
            life_engine, character.char_id, name="Rowan", age=29, health=82,
            smarts=94, looks=68, wealth_cents=dollars_to_cents(150_000), gender="non_binary", country="in",
        ),
    ]
    dead = replace(
        character,
        is_alive=False,
        age=60,
        death_cause="natural causes",
        death_age=60,
        died_at=1_800_000_020,
        last_age_at=1_800_000_020,
        version=character.version + 1,
    )
    async with database.transaction() as tx:
        await life_engine._save_character(tx, dead, expected_version=character.version)
        result = await life_engine.death.handle_death(tx, dead, now=1_800_000_020)
    assert result is not None
    assert result.summary["gross_assets_cents"] == dollars_to_cents(8_000_000)
    assert result.summary["debts_paid_cents"] == dollars_to_cents(1_000_000)
    assert result.summary["estate_tax_threshold_cents"] == dollars_to_cents(6_250_000)
    assert result.summary["estate_tax_cents"] == dollars_to_cents(300_000)
    assert result.summary["estate_cents"] == dollars_to_cents(6_700_000)
    assert result.estate_id is not None and result.estate_nonce
    assert len(result.heirs) == 2
    assert [row["inheritance_cents"] for row in result.heirs] == [dollars_to_cents(3_350_000)] * 2
    assert sum(int(row["inheritance_cents"]) for row in result.heirs) == result.summary["estate_cents"]

    selected_id = child_ids[0]
    heir = await life_engine.death.choose_heir(
        character.user_id, result.estate_id, result.estate_nonce, selected_id,
        now=1_800_000_030,
    )
    assert heir is not None
    assert heir.name == "Avery"
    assert heir.age == 35
    assert heir.gender.value == "female"
    assert heir.country == "ca"
    assert heir.stats.health == 91
    assert heir.stats.smarts == 87
    assert heir.stats.looks == 73
    assert heir.cash == dollars_to_cents(3_350_000)
    assert heir.bank == 0 and heir.debt_total == 0
    assert heir.price_index == 1.25
    assert heir.parent_char_id == character.char_id
    assert heir.generation == character.generation + 1
    assert heir.is_alive
    active = await life_engine.get_active_character(character.user_id)
    assert active.char_id == heir.char_id
    assert active.cash >= 0 and active.bank >= 0 and active.debt_total >= 0
    estate = await database.fetchone("SELECT status, selected_npc_id FROM life_estates WHERE estate_id = ?", (result.estate_id,))
    assert estate["status"] == "claimed"
    assert int(estate["selected_npc_id"]) == selected_id


@pytest.mark.asyncio
async def test_zero_value_estate_still_offers_living_adult_heir(database, life_engine):
    """A living adult child can continue the family even when the inheritance is zero."""
    character = await life_engine.create_character(51012, "No Estate Parent")
    npc_id = await _insert_child(
        life_engine, character.char_id, name="Sam", age=22, health=76,
        smarts=81, looks=63, wealth_cents=0,
    )
    dead = replace(
        character,
        is_alive=False,
        age=50,
        death_cause="natural causes",
        death_age=50,
        died_at=1_800_000_025,
        last_age_at=1_800_000_025,
        version=character.version + 1,
    )
    async with database.transaction() as tx:
        await life_engine._save_character(tx, dead, expected_version=character.version)
        result = await life_engine.death.handle_death(tx, dead, now=1_800_000_025)
    assert result is not None and result.estate_id is not None
    assert result.summary["estate_cents"] == 0
    assert len(result.heirs) == 1
    assert int(result.heirs[0]["inheritance_cents"]) == 0
    heir = await life_engine.death.choose_heir(
        character.user_id, result.estate_id, result.estate_nonce or "", npc_id,
        now=1_800_000_026,
    )
    assert heir is not None
    assert heir.cash == 0 and heir.bank == 0 and heir.debt_total == 0
    assert heir.parent_char_id == character.char_id


@pytest.mark.asyncio
async def test_death_summary_visibility_obeys_guild_setting_and_player_opt_out(database, life_engine):
    """Public obituaries require both guild permission and the player's consent."""
    repository = LegacyRepository(database)
    async with database.transaction() as tx:
        await repository.set_guild_public_death_summaries(
            tx, guild_id=9002, enabled=True, user_id=51013, now=1_800_000_010
        )
    _, public_result = await _make_dead_life(
        life_engine, 51013, now=1_800_000_011, guild_id=9002
    )
    assert public_result is not None and public_result.public_summary is True
    async with database.transaction() as tx:
        await repository.set_leaderboard_privacy(
            tx, 51014, True, now=1_800_000_012
        )
    _, private_result = await _make_dead_life(
        life_engine, 51014, now=1_800_000_013, guild_id=9002
    )
    assert private_result is not None and private_result.public_summary is False


@pytest.mark.asyncio
async def test_death_transaction_rolls_back_every_write_and_pending_notice(database, life_engine, monkeypatch):
    """An injected mid-archive error rolls back death fields, archives, balances, and unlocks."""
    character = await life_engine.create_character(51003, "Rollback Life")
    dead = replace(
        character,
        is_alive=False,
        age=1,
        death_cause="natural causes",
        death_age=1,
        died_at=1_800_000_040,
        last_age_at=1_800_000_040,
        version=character.version + 1,
    )
    insert_past_life = life_engine.death.repository.insert_past_life

    async def insert_then_fail(tx: Any, summary: dict[str, Any]) -> bool:
        await insert_past_life(tx, summary)
        raise RuntimeError("forced failure after archive insert")

    monkeypatch.setattr(life_engine.death.repository, "insert_past_life", insert_then_fail)
    with pytest.raises(RuntimeError, match="forced failure"):
        async with database.transaction() as tx:
            await life_engine._save_character(tx, dead, expected_version=character.version)
            await life_engine.death.handle_death(tx, dead, now=1_800_000_040)
    persisted = await database.fetchone("SELECT is_alive, death_cause FROM characters WHERE char_id = ?", (character.char_id,))
    assert int(persisted["is_alive"]) == 1
    assert persisted["death_cause"] is None
    assert await database.fetchone("SELECT 1 FROM past_lives WHERE char_id = ?", (character.char_id,)) is None
    assert await database.fetchone("SELECT 1 FROM achievements_unlocked WHERE user_id = ?", (character.user_id,)) is None
    assert await database.fetchone(
        "SELECT 1 FROM players WHERE user_id = ?", (character.user_id,)
    ) is None
    assert life_engine.achievements.consume_notifications(character.user_id) == []


@pytest.mark.asyncio
async def test_achievement_unlocks_are_authoritative_and_idempotent(database, life_engine):
    """Unlocks derive from persisted character state; repeated checks cannot duplicate rows."""
    character = await life_engine.create_character(51004, "New Steps")
    initial = await life_engine.achievements.check_user(character.user_id, now=1_800_000_050)
    assert "first_steps" not in {row["id"] for row in initial}
    life_engine.achievements.consume_notifications(character.user_id)
    with pytest.raises(TypeError):
        await life_engine.achievements.check_user(character.user_id, age=100)  # type: ignore[call-arg]
    with pytest.raises(TypeError):
        await life_engine.achievements.check_user(character.user_id, achievement_id="jackpot")  # type: ignore[call-arg]

    aged = replace(character, age=1, version=character.version + 1)
    async with database.transaction() as tx:
        await life_engine._save_character(tx, aged, expected_version=character.version)
    unlocked = await life_engine.achievements.check_user(character.user_id, now=1_800_000_051)
    assert "first_steps" in {row["id"] for row in unlocked}
    assert "first_steps" in {row["id"] for row in life_engine.achievements.consume_notifications(character.user_id)}
    repeated = await life_engine.achievements.check_user(character.user_id, now=1_800_000_052)
    assert "first_steps" not in {row["id"] for row in repeated}
    rows = await database.fetchall(
        "SELECT achievement_id FROM achievements_unlocked WHERE user_id = ? AND achievement_id = 'first_steps'",
        (character.user_id,),
    )
    assert len(rows) == 1


@pytest.mark.asyncio
async def test_year_tick_step_15_records_happiness_and_unlocks_first_steps(life_engine):
    """An ordinary age tick runs the Stage 10 metric and achievement step atomically."""
    character = await life_engine.create_character(51005, "Yearly Check")
    outcome = await life_engine.age_up(character.user_id)
    assert outcome.character.age == 1
    assert "first_steps" in {row["id"] for row in outcome.unlocked_achievements}
    metrics = await life_engine.db.fetchall(
        "SELECT age, happiness FROM life_year_metrics WHERE char_id = ? ORDER BY age",
        (character.char_id,),
    )
    assert len(metrics) == 1
    assert int(metrics[0]["age"]) == 1
    assert int(metrics[0]["happiness"]) == outcome.character.stats.happiness
    assert "first_steps" in {row["id"] for row in life_engine.achievements.consume_notifications(character.user_id)}


@pytest.mark.asyncio
async def test_legacy_purchase_is_capped_to_two_and_changes_no_money(database, life_engine):
    """Two earned purchases add at most ten stat points and deduct exactly 100 cosmetic points."""
    control_engine = LifeEngine(
        database,
        RNG(seed=2026),
        UserLockRegistry(),
        clock=lambda: 1_800_000_000,
        event_chance=0.0,
    )
    baseline = await control_engine.create_character(51006, "Baseline")
    async with database.transaction() as tx:
        await life_engine.legacy_repository.ensure_player(tx, 51007, 1_800_000_000)
        await tx.execute("UPDATE players SET legacy_points = 200 WHERE user_id = ?", (51007,))
    boosted = await life_engine.create_character(
        51007, "Boosted", legacy_stat="health", legacy_purchases=2
    )
    assert boosted.stats.health == min(100, baseline.stats.health + 10)
    for key in ("happiness", "smarts", "looks", "fitness", "karma", "stress", "addiction", "fame"):
        assert getattr(boosted.stats, key) == getattr(baseline.stats, key)
    assert boosted.cash == baseline.cash == 0
    assert boosted.bank == baseline.bank == 0
    player = await database.fetchone("SELECT legacy_points FROM players WHERE user_id = ?", (51007,))
    assert int(player["legacy_points"]) == 100
    purchase = await database.fetchone(
        "SELECT stat_name, purchase_count, points_spent FROM legacy_start_purchases WHERE char_id = ?",
        (boosted.char_id,),
    )
    assert dict(purchase) == {"stat_name": "health", "purchase_count": 2, "points_spent": 100}
    with pytest.raises(ValidationError):
        await life_engine.create_character(51008, "Over the Cap", legacy_stat="health", legacy_purchases=3)
    async with database.transaction() as tx:
        await life_engine.legacy_repository.ensure_player(tx, 51009, 1_800_000_000)
        await tx.execute("UPDATE players SET legacy_points = 50 WHERE user_id = ?", (51009,))
    with pytest.raises(InsufficientFunds):
        await life_engine.create_character(51009, "Too Costly", legacy_stat="smarts", legacy_purchases=2)
    assert await database.fetchone("SELECT 1 FROM characters WHERE user_id = 51009") is None


@pytest.mark.asyncio
async def test_retirement_has_no_points_heir_or_debt_transfer(database, life_engine):
    """Confirmed abandonment archives once but awards neither legacy points nor inheritance."""
    character = await life_engine.create_character(51010, "Retired Life")
    updated = replace(
        character,
        age=45,
        cash=dollars_to_cents(100_000),
        debt_total=dollars_to_cents(500_000),
        version=character.version + 1,
    )
    async with database.transaction() as tx:
        await life_engine._save_character(tx, updated, expected_version=character.version)
    prompt = await life_engine.death.begin_retirement(character.user_id, now=1_800_000_100)
    result = await life_engine.death.confirm_retirement(
        character.user_id, prompt.prompt_id, prompt.nonce, now=1_800_000_101
    )
    assert result.summary["death_cause"] == "Life abandoned"
    assert result.summary["abandoned"] is True
    assert result.summary["legacy_points"] == 0
    assert result.summary["estate_cents"] == 0
    assert result.summary["debts_paid_cents"] == 0
    assert result.summary["unpaid_debt_cents"] == dollars_to_cents(500_000)
    assert await database.fetchone("SELECT 1 FROM life_estates WHERE user_id = ?", (character.user_id,)) is None
    player = await database.fetchone("SELECT lives_lived, legacy_points FROM players WHERE user_id = ?", (character.user_id,))
    assert int(player["lives_lived"]) == 0
    assert int(player["legacy_points"]) == 0
    with pytest.raises(ValidationError):
        await life_engine.death.confirm_retirement(
            character.user_id, prompt.prompt_id, prompt.nonce, now=1_800_000_102
        )
    await life_engine.create_character(character.user_id, "Another Abandoned Life")
    second_prompt = await life_engine.death.begin_retirement(
        character.user_id, now=1_800_000_200
    )
    await life_engine.death.confirm_retirement(
        character.user_id, second_prompt.prompt_id, second_prompt.nonce,
        now=1_800_000_201,
    )
    player = await database.fetchone("SELECT lives_lived, legacy_points FROM players WHERE user_id = ?", (character.user_id,))
    assert int(player["lives_lived"]) == 0
    assert int(player["legacy_points"]) == 0
    archives = await database.fetchone(
        "SELECT COUNT(*) AS n FROM past_lives WHERE user_id = ?", (character.user_id,)
    )
    assert int(archives["n"]) == 2


@pytest.mark.asyncio
async def test_leaderboard_ties_pagination_cache_expiry_privacy_and_server_fallback(database, life_engine):
    """Rankings tie by account ID, page after ten, expire at 60 seconds, and use seen guild users."""
    user_ids = list(range(51100, 51112))
    for user_id in user_ids:
        await life_engine.create_character(user_id, f"Rank {user_id}")
        async with database.transaction() as tx:
            await life_engine.legacy_repository.ensure_player(tx, user_id, 1_800_000_000)
    await _set_character_age(life_engine, user_ids[-1], 10)

    clock = [100.0]
    leaderboard = LeaderboardService(
        database,
        life_engine.achievements,
        life_engine.locks,
        clock=lambda: clock[0],
        cache_seconds=60,
    )
    first = await leaderboard.get_leaderboard(
        user_ids[0], metric="age", scope="global", period="current"
    )
    assert len(first.entries) == 12
    assert first.entries[0]["user_id"] == user_ids[-1]
    assert [row["user_id"] for row in first.entries[1:]] == user_ids[:-1]
    first_embed = leaderboard_embed(first, 0)
    second_embed = leaderboard_embed(first, 1)
    assert len((first_embed.description or "").splitlines()) == 10
    assert len((second_embed.description or "").splitlines()) == 2
    pager = EmbedPager(user_ids[0], [first_embed, second_embed])
    assert len(pager.embeds) == 2

    await _set_character_age(life_engine, user_ids[0], 99)
    clock[0] = 159.99
    cached = await leaderboard.get_leaderboard(
        user_ids[0], metric="age", scope="global", period="current"
    )
    assert cached.entries == first.entries
    clock[0] = 160.0
    refreshed = await leaderboard.get_leaderboard(
        user_ids[0], metric="age", scope="global", period="current"
    )
    assert refreshed.entries[0]["user_id"] == user_ids[0]

    await leaderboard.set_opt_out(user_ids[1], True, now=1_800_000_200)
    private_filtered = await leaderboard.get_leaderboard(
        user_ids[0], metric="age", scope="global", period="current"
    )
    assert user_ids[1] not in {row["user_id"] for row in private_filtered.entries}
    async with database.transaction() as tx:
        await LegacyRepository(database).record_guild_seen(tx, 9001, user_ids[2], 1_800_000_201)
    server = await leaderboard.get_leaderboard(
        user_ids[0], metric="age", scope="server", period="current", guild_id=9001
    )
    assert {row["user_id"] for row in server.entries} == {user_ids[0], user_ids[2]}


def test_epitaph_selection_is_deterministic_and_catalog_has_twenty_templates():
    """Epitaph choice is based on stable life facts and contains ample PG-13 variants."""
    from core.death import _EPITAPHS

    assert sum(len(templates) for templates in _EPITAPHS.values()) >= 20
    arguments = dict(
        char_id=75,
        age=24,
        cause="natural causes",
        education_level="none",
        children=0,
        marriage_years=0,
        career_count=0,
        conviction_count=0,
        sealed_convictions=0,
        net_worth_cents=0,
        hardship_recovered=False,
    )
    assert select_epitaph(**arguments) == select_epitaph(**arguments)
    assert select_epitaph(**{**arguments, "cause": "Life abandoned"}) in _EPITAPHS["abandoned"]
~~~~

## `tools/measure_balance.py`

~~~~python
"""Reproducible, headless Stage 12 mortality, casino RTP, and crime-EV measurements.

Run from the project root with ``python -m tools.measure_balance``. These runs
consume only deterministic game rules and do not connect to Discord or write a
player database. The 500-life full-engine distribution is reported by
``tests/test_full_lives.py`` instead.
"""
from __future__ import annotations

import argparse
import json
import math
from collections import Counter
from statistics import mean, median, pstdev
from typing import Any

from core.casino import CasinoService
from core.crime import (
    LAWYER_CONVICTION_CHANCES,
    CrimeDefinition,
    calculate_crime_catch_chance,
    calculate_crime_success_chance,
    clamp_chance,
)
from core.data_loader import DataLoader
from core.life_engine import roll_birth_attributes, simulate_year
from core.models import Character
from core.money import dollars_to_cents
from core.rng import RNG

MORTALITY_SEED = 20261002
CASINO_SEED = 20260930
CRIME_SEED = 20261008
BET_CENTS = 10_000
DEFAULT_MORTALITY_LIVES = 2_000
DEFAULT_CASINO_TRIALS = 1_000_000
DEFAULT_BLACKJACK_TRIALS = 250_000


def _percentile(sorted_values: list[int], fraction: float) -> int:
    """Return the observation at the rounded empirical quantile index used here."""
    return sorted_values[round((len(sorted_values) - 1) * fraction)]


def mortality_distribution(life_count: int, seed: int) -> dict[str, Any]:
    """Run the production pure yearly mortality function without other life systems."""
    if life_count <= 0:
        raise ValueError("life_count must be positive")
    rng = RNG(seed)
    ages: list[int] = []
    causes: Counter[str] = Counter()
    for index in range(life_count):
        stats, hidden, wealth_class = roll_birth_attributes(rng)
        character = Character(
            user_id=940_000 + index,
            name=f"Mortality {index:04d}",
            stats=stats,
            hidden=hidden,
            wealth_class=wealth_class,
        )
        while character.is_alive:
            character = simulate_year(character, rng, now=1_900_000_000).character
        ages.append(int(character.death_age or character.age))
        causes[str(character.death_cause)] += 1
    ordered = sorted(ages)
    return {
        "lives": life_count,
        "seed": seed,
        "mean_age": round(mean(ages), 2),
        "median_age": median(ages),
        "population_sd_age": round(pstdev(ages), 2),
        "p10_age": _percentile(ordered, 0.10),
        "p25_age": _percentile(ordered, 0.25),
        "p75_age": _percentile(ordered, 0.75),
        "p90_age": _percentile(ordered, 0.90),
        "min_age": min(ages),
        "max_age": max(ages),
        "under_18_deaths": sum(age < 18 for age in ages),
        "terminal_causes": dict(sorted(causes.items())),
        "scope": "Pure simulate_year mortality and stat drift only; no engine-year economy, crime, family, or archive writes.",
    }


def casino_monte_carlo(trials: int, blackjack_trials: int, seed: int) -> dict[str, Any]:
    """Measure gross casino return using production casino rules and fixed wagers."""
    if trials <= 0 or blackjack_trials <= 0:
        raise ValueError("Monte Carlo trial counts must be positive")
    output: dict[str, Any] = {"bet_cents_per_hand": BET_CENTS, "seed": seed, "games": {}}

    # This is the production weighted-reel spin and paytable, run without service writes.
    slot_service = CasinoService(None, RNG(seed), None)
    slot_payout = 0
    for _ in range(trials):
        _, gross = slot_service.spin_slots(BET_CENTS)
        slot_payout += gross
    output["games"]["slots"] = _rtp_record(trials, BET_CENTS, slot_payout)

    coin_rng = RNG(seed + 1)
    coin_wins = 0
    coin_payout = 0
    for _ in range(trials):
        if coin_rng.choice(("heads", "tails")) == "heads":
            coin_wins += 1
            coin_payout += BET_CENTS * 194 // 100
    output["games"]["coinflip_heads"] = {
        **_rtp_record(trials, BET_CENTS, coin_payout),
        "wins": coin_wins,
        "rule": "Fair heads/tails; a win returns 1.94x gross.",
    }

    roulette_specs = (
        ("roulette_red", "red", None, seed + 2),
        ("roulette_dozen_1", "dozen", 1, seed + 3),
        ("roulette_straight_0", "straight", 0, seed + 4),
    )
    for name, kind, number, roulette_seed in roulette_specs:
        roulette_rng = RNG(roulette_seed)
        total_payout = 0
        wins = 0
        for _ in range(trials):
            landed = roulette_rng.randint(0, 36)
            payout = CasinoService.roulette_payout(BET_CENTS, kind, number, landed)
            total_payout += payout
            wins += payout > 0
        output["games"][name] = {
            **_rtp_record(trials, BET_CENTS, total_payout),
            "wins": wins,
            "rule": "European single-zero wheel; production payout function.",
        }

    blackjack = CasinoService(None, RNG(seed + 5), None)
    blackjack_payout = 0
    blackjack_naturals = 0
    blackjack_pushes = 0
    for _ in range(blackjack_trials):
        shoe = blackjack._shuffled_shoe()
        player = [shoe.pop()]
        dealer = [shoe.pop()]
        player.append(shoe.pop())
        dealer.append(shoe.pop())
        player_natural = blackjack._is_natural(player)
        dealer_natural = blackjack._is_natural(dealer)
        if player_natural or dealer_natural:
            if player_natural and dealer_natural:
                gross = BET_CENTS
                blackjack_pushes += 1
            elif player_natural:
                gross = BET_CENTS + BET_CENTS * 3 // 2
                blackjack_naturals += 1
            else:
                gross = 0
        else:
            # Fixed, transparent player policy: hit below 17, then stand; never double.
            while blackjack._hand_total(player)[0] < 17:
                player.append(shoe.pop())
            player_total = blackjack._hand_total(player)[0]
            if player_total > 21:
                gross = 0
            else:
                while blackjack._dealer_hits(dealer):
                    dealer.append(shoe.pop())
                dealer_total = blackjack._hand_total(dealer)[0]
                if dealer_total > 21 or player_total > dealer_total:
                    gross = 2 * BET_CENTS
                elif player_total == dealer_total:
                    gross = BET_CENTS
                    blackjack_pushes += 1
                else:
                    gross = 0
        blackjack_payout += gross
    output["games"]["blackjack_hit_below_17_no_double"] = {
        **_rtp_record(blackjack_trials, BET_CENTS, blackjack_payout),
        "naturals_won": blackjack_naturals,
        "pushes": blackjack_pushes,
        "rule": "Six-deck production shoe and hand/dealer helpers; hit below 17, stand at 17+, no doubles or splits.",
    }

    # Lottery prizes are discrete in the production service; this is the exact catalog EV,
    # not a Monte Carlo estimate (one jackpot in ten million outcomes).
    expected_prize_cents = (
        1 * 5_000_000_000
        + 100 * 1_000_000
        + 10_000 * 10_000
        + 100_000 * 1_000
        + 1_000_000 * 250
    ) // 10_000_000
    output["lottery_ticket_exact"] = {
        "expected_prize_cents_at_price_index_1": expected_prize_cents,
        "ticket_cost_cents": 1_000,
        "gross_rtp": expected_prize_cents / 1_000,
        "net_ev_cents": expected_prize_cents - 1_000,
        "scope": "Exact probability-weighted prize; ticket use is not included in the casino Monte Carlo samples.",
    }
    return output


def _rtp_record(trials: int, bet_cents: int, payout_cents: int) -> dict[str, Any]:
    """Describe gross returns as aggregate credited payout divided by stake."""
    total_stake = trials * bet_cents
    return {
        "hands": trials,
        "stake_cents": total_stake,
        "gross_payout_cents": payout_cents,
        "observed_gross_rtp": round(payout_cents / total_stake, 6),
    }


def violent_crime_ev(trials: int, seed: int) -> dict[str, Any]:
    """Estimate direct proceeds for baseline adult stats using the abstract crime rules."""
    if trials <= 0:
        raise ValueError("trials must be positive")
    definitions = DataLoader().load_crimes()["crimes"]
    rng = RNG(seed)
    result: dict[str, Any] = {
        "trials_per_crime": trials,
        "seed": seed,
        "baseline": "Age-eligible adult; smarts 50, fitness 50, luck 0, notoriety 0, criminal record 0; caught cases choose free public counsel.",
        "scope": "Direct cash EV is dirty loot less the 50% dirty-cash fine when a successful, caught attempt is convicted; custody-year exposure is reported separately. Dollar EV excludes prison-time opportunity cost, lost work, future record/notoriety effects, laundering fees, taxes, and relationship effects.",
        "crimes": {},
    }
    for raw in definitions:
        crime = CrimeDefinition.from_dict(raw)
        if not crime.violence or not crime.commit_enabled:
            continue
        success_chance = calculate_crime_success_chance(
            float(crime.base_success or 0.0),
            smarts=50,
            fitness=50,
            luck=0,
            success_stat=crime.success_stat,
        )
        catch_chance = calculate_crime_catch_chance(
            float(crime.base_catch or 0.0), notoriety=0, criminal_record=0
        )
        failed_catch_chance = clamp_chance(catch_chance * 1.5)
        loot_min = dollars_to_cents(crime.loot_min_dollars)
        loot_max = dollars_to_cents(crime.loot_max_dollars)
        successes = arrests = convictions = gross_loot = fines = custody_years = 0
        for _ in range(trials):
            success = rng.random() * 100.0 < success_chance
            adjusted_catch = catch_chance if success else failed_catch_chance
            caught = rng.random() * 100.0 < adjusted_catch
            loot = rng.randint(loot_min, loot_max) if success else 0
            fine = 0
            if success:
                successes += 1
            if caught:
                arrests += 1
                if rng.random() * 100.0 < LAWYER_CONVICTION_CHANCES["public"]:
                    convictions += 1
                    if crime.sentence_max is None:
                        maximum_sentence = max(crime.sentence_min, 120 - 21)
                        base_sentence = rng.randint(crime.sentence_min, maximum_sentence)
                    elif crime.sentence_min == crime.sentence_max:
                        base_sentence = crime.sentence_min
                    else:
                        base_sentence = rng.randint(crime.sentence_min, int(crime.sentence_max))
                    custody_years += min(99, max(0, math.ceil(base_sentence)))
                    if success:
                        fine = (loot * 50 + 50) // 100
            gross_loot += loot
            fines += fine
        result["crimes"][crime.id] = {
            "success_chance_pct": success_chance,
            "caught_chance_if_success_pct": catch_chance,
            "caught_chance_if_failure_pct": failed_catch_chance,
            "observed_success_pct": round(successes / trials * 100, 3),
            "observed_arrest_pct": round(arrests / trials * 100, 3),
            "observed_conviction_pct": round(convictions / trials * 100, 3),
            "observed_custody_years_per_attempt": round(custody_years / trials, 4),
            "mean_custody_years_per_conviction": round(custody_years / convictions, 3) if convictions else 0.0,
            "gross_loot_ev_cents_per_attempt": round(gross_loot / trials),
            "fine_ev_cents_per_attempt": round(fines / trials),
            "direct_net_ev_cents_per_attempt": round((gross_loot - fines) / trials),
        }
    return result


def main() -> None:
    """Run the deterministic measurements and print one JSON record."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mortality-lives", type=int, default=DEFAULT_MORTALITY_LIVES)
    parser.add_argument("--casino-trials", type=int, default=DEFAULT_CASINO_TRIALS)
    parser.add_argument("--blackjack-trials", type=int, default=DEFAULT_BLACKJACK_TRIALS)
    parser.add_argument("--crime-trials", type=int, default=1_000_000)
    args = parser.parse_args()
    report = {
        "mortality_only": mortality_distribution(args.mortality_lives, MORTALITY_SEED),
        "casino_rtp": casino_monte_carlo(args.casino_trials, args.blackjack_trials, CASINO_SEED),
        "violent_crime_ev": violent_crime_ev(args.crime_trials, CRIME_SEED),
    }
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
~~~~

## `DESIGN_NOTES.md`

~~~~markdown
# LIFELINE design notes — Casino, Investing, and Final Verification

This stage is a fictional, in-game economy. It has no real-money deposits, withdrawal, or cash-out. Persistent currency and prices are integer cents; external Discord dollar inputs are converted to cents at the command boundary. User-facing casino and investment commands use one shared user lock plus SQLite `BEGIN IMMEDIATE` transactions.

## Casino payout conventions and exact mathematics

Unless stated otherwise, a casino `payout_cents` is the **gross amount credited**, including the returned stake. Net result is `payout - bet`. A losing wager returns zero. Charges are rounded up; winnings are rounded down to cents.

### Slots — theoretical return to player (RTP)

Each of three reels is independent and uses the same weighted symbol table:

| Symbol | Weight | Probability |
|---|---:|---:|
| Cherry | 50 | 0.50 |
| Lemon | 30 | 0.30 |
| Bell | 15 | 0.15 |
| Diamond | 5 | 0.05 |

A two-of-a-kind (exactly one pair) returns `1.00 × stake` gross (the stake only); a three-of-a-kind returns the following gross multiple:

| Three matching symbols | Gross return |
|---|---:|
| Cherry | `1.50 × stake` |
| Lemon | `3.00 × stake` |
| Bell | `6.00 × stake` |
| Diamond | `22.00 × stake` |
| No pair | `0` |

For symbol probability `p`, the probability of exactly one pair is `3p²(1-p)`. Across all four symbols these probabilities sum to `0.6285`; because each such result returns 1×, pair outcomes contribute `0.6285` to expected gross return per unit staked. Three-of-a-kind outcomes contribute:

`0.50³×1.50 + 0.30³×3 + 0.15³×6 + 0.05³×22`

`= 0.1875 + 0.081 + 0.02025 + 0.00275 = 0.2915`.

Therefore theoretical gross RTP is `0.6285 + 0.2915 = 0.9200`, exactly **92.00%** before cent rounding; theoretical net expected value is `-8.00%`. Three-of-a-kind cherry returns are rounded down for odd-cent wagers, so integer-cent implementation can be microscopically below the theoretical figure. The Monte Carlo acceptance test uses a $100 stake so every listed multiplier is exact in cents.

### Blackjack

The player and dealer use a freshly shuffled six-deck shoe for each hand. The dealer stands on soft 17. Natural blackjack is two cards totaling 21; it pays 3:2 profit (gross return `2.5×` the bet, including returned stake). A regular win pays `1:1` profit (gross `2×`); pushes return `1×`; losses/busts pay zero. Double adds a second equal wager and receives exactly one card before automatic settlement.

### European roulette

The wheel has 37 equally likely pockets, `0` through `36`; zero is green and loses all red/black/odd/even/dozen bets. The payout ratios below are profit odds, with gross returns including returned stake:

| Bet | Profit odds | Gross return on a win | Win probability |
|---|---:|---:|---:|
| Red / black / odd / even | 1:1 | `2×` | `18/37` |
| Dozen (1–12, 13–24, 25–36) | 2:1 | `3×` | `12/37` |
| Straight number (0–36) | 35:1 | `36×` | `1/37` |

Each listed bet has net expected value `-1/37` of stake (about `-2.7027%`).

### Coinflip

A winning chosen side returns `1.94×` gross, including stake; a loss returns zero. With a fair 50/50 outcome, expected gross return is `0.5×1.94 = 0.97×`, for net expected value `-3.00%`.

### Lottery ticket

The shop's $10 ticket is a one-use casino item; its face price is the wager and it is consumed at use. Prize credits do **not** refund the ticket price. Probabilities are implemented as disjoint integer ranges from one 10,000,000-outcome draw:

| Prize | Outcomes | Probability | Expected prize at index 1.0 |
|---|---:|---:|---:|
| $50,000,000 jackpot | 1 | 1 in 10,000,000 | $5.00 |
| $10,000 tier | 100 | 1 in 100,000 | $0.10 |
| $100 tier | 10,000 | 1 in 1,000 | $0.10 |
| $10 tier | 100,000 | 1 in 100 | $0.10 |
| $2.50 tier | 1,000,000 | 1 in 10 | $0.25 |
| No prize | 8,888,899 | remainder | $0.00 |

Expected gross prize is `$5.55 × price_index`; the ticket costs `$10.00 × price_index`, so expected net value is `-$4.45 × price_index` (negative EV). The jackpot and each smaller prize scale with the world's price index and are floored to integer cents.

### Gambling limits, addiction, and taxes

Casino wagers are available from age `max(18, gambling_ages[country])`, require an active, living, non-imprisoned character, and cannot exceed `min(cash + bank, $250,000 × price_index)`. A persistent per-Discord-user three-second cooldown applies across casino games and lives; each character may place at most 25 wagers per in-game year. Standard lives record that count in `yearly_counters` anchored to an owned NPC. Legacy lives without NPC rows use `casino_yearly_bets` instead, avoiding a fake family member/foreign-key violation.

Each wager adds `0.2` to a float remainder in `stats_tracking`; each complete point is applied to the integer addiction stat. At addiction 60+, the `health_conditions` record `gambling_addiction` is diagnosed/active and an annual 25% chance creates a persisted resist-or-indulge compulsion choice. The recovery-program shop item reduces addiction by 20; below 60 the condition enters remission. Unresolved choices can be reopened with `/casino compulsion` and block the next `/life age`.

At the next yearly tick, positive annual gambling net above 500,000 cents ($5,000) is taxed at 24%, rounded up. Settled `casino_plays` are used; refunded hands do not create taxable net. When available cash and bank cannot cover a tax, balances remain non-negative and the unpaid amount is added to `debt_total`.

## Investing model

`stocks.json` is schema-validated at startup and contains 15 fictional companies in tech, energy, health, finance, consumer, and crypto-like sectors. HyperCoin is the high-volatility crypto-like ticker. Unknown country keys use the validated minimum-age fallback of 18 from `gambling_ages.json`; these are game rules, not legal advice.

Every 10 minutes the global market applies the specified geometric Brownian motion:

`price_new = floor(price × exp((drift - 0.5 × volatility²) × (1/52) + volatility × sqrt(1/52) × Z))`, with `Z ~ N(0,1)` and a one-cent floor.

A UTC market day gets at most one global event: a 2% crash chance, otherwise a 3% boom chance. Crash drops are 15–40%; boom gains are 10–25%. After movement, a still-listed stock below $1 has a 0.05% per-tick chance to delist at zero cents. Existing holdings remain recorded and are worth zero. The ticker commits all prices, histories, event markers, and cursor changes in one transaction; it writes no more than six catch-up ticks, skips the rest rather than backfilling, and unique `(symbol, tick_no)` history keys make a repeated tick idempotent. The most recent 500 points per symbol are retained.

Stock buy/sell execution reads current price and writes cash, holdings, trade, and audit rows in the same transaction. Orders are whole shares, paid from bank only. Brokerage is 0.5%, rounded up, with a $1 minimum. Buy fees are included in total cost basis; sale fees reduce realized proceeds. Partial sales allocate fee-inclusive basis proportionally, with integer-cent floor and the remaining basis retained in the position. Stock trades are limited to 20 per rolling real-time hour per player; an opposite-direction order for the same ticker is blocked for 60 seconds. Realized net capital gains (after sale fee and cost basis, net of realized losses) are taxed at 15% on the next yearly tick.

Bonds are purchased from bank, compound at 3.5% annually with interest rounded down to cents, and release principal plus interest after five character-year ticks. They have no early-withdrawal command. A second owned housing item is treated as a rental (the designated home, or the oldest home if none is designated, remains the primary residence): each extra home has a 10% yearly vacancy chance, earns 6% of current value if rented, and incurs price-index-adjusted upkeep. Rental net and bond interest are passed into the existing yearly household-income integration.

## Persistence and recovery

Migration `008_casino_investing.sql` adds the casino/game ledgers, pending sessions, disease row, global market, positions, bond ledger, and yearly accounting. Every write is parameterized and transaction-owned by the service caller. Blackjack escrow records the exact cash/bank debit and a rotating nonce; startup recovery changes only still-active sessions to `refunded`, restores those exact amounts, and settles the linked play row in the same transaction. Re-running recovery cannot refund a terminal session twice. Interactive buttons are owner-checked, nonce-checked server-side, and replaced/disabled after use; inactivity auto-stands after two minutes.

## Stage 12 — final integration verification

Stage 12 adds verification and defect repair only; it does not add game behavior. The seeded 500-life harness exercises the existing year engine and services against SQLite, while exploit tests cover transactional rollback, concurrent request races, stale/unauthorized components, amount validation, relationship age rules, trade/purchase economics, text escaping, and abuse attempts. `tools/measure_balance.py` provides repeatable mortality-only, casino RTP, and violent-crime cash-EV estimates; see `VERIFICATION_REPORT.md` for exact seeds, sample sizes, measurements, run outcomes, and limits.

The archive regression was in `LegacyRepository.insert_past_life`: it serialized the complete archive record into the `summary_json` column instead of serializing the detailed summary object. New archives now store the detailed object directly. Migration `011_repair_archived_life_summaries.sql` unwraps previously written envelopes under the migration runner's `BEGIN IMMEDIATE` transaction and recreates the update-immutability trigger before commit. The migration regression checks both repaired JSON shape and the restored trigger. Archive payloads remain immutable after insertion.

Balance constants were reviewed but not changed. The repository does not define numerical acceptance bands for mortality, wealth, promotion timing, or crime EV beyond the existing casino RTP and crime-lawyer acceptance checks; results are reported as observed data rather than tuned to an invented target.
~~~~

## `VERIFICATION_REPORT.md`

~~~~markdown
# Stage 12 — Final Integration Verification

**Project:** LIFELINE, Python / `discord.py`  
**Report date:** 2026-10-01  
**Scope:** Verify the existing Stages 1–11 implementation, repair defects found, and document measured behavior. No new game features are introduced.

## Feature coverage

| Existing feature area | Slash commands | Verification coverage |
|---|---|---|
| Life creation, status, annual aging, events, death, and archive | `/life start`, `/life status`, `/life age`, `/life choice`, `/start`, `/lives list`, `/lives view`, `/graveyard`, `/inheritance`, `/retire_life` | `test_life_engine.py`, `test_events.py`, `test_stage10.py`, `test_full_lives.py`, `test_migrations.py` |
| Education and careers | `/education status`, `/education study`, `/education enroll`, `/career list`, `/career apply`, `/career status`, `/career history`, `/career work`, `/career quit`, `/career retire` | `test_education.py`, `test_careers.py`, `test_full_lives.py` |
| Family, dating, relationships, and privacy | `/family`, `/relationship list`, `/relationship interact`, `/relationship propose`, `/relationship marry`, `/relationship divorce`, `/relationship breakup`, `/relationship try_for_baby`, `/relationship adopt`, `/relationship temptation`, `/date find`, `/friends find`, `/settings privacy`, `/settings leaderboard`, `/leaderboard_privacy`, `/guild_death_summaries` | `test_family.py`, `test_exploits.py`, `test_full_lives.py`, Stage 8–10 cog-loading tests |
| Fictional crime, trials, and prison | `/crime list`, `/crime commit`, `/crime launder`, `/crime record`, `/prison status`, `/prison action` | `test_crime.py`, `test_exploits.py`, `test_full_lives.py`, `test_measure_balance.py` |
| Shop, inventory, secured purchases, and player trades | `/shop browse`, `/shop buy`, `/shop ring`, `/inventory view`, `/inventory sell`, `/inventory use`, `/trade offer`, `/trade list`, `/trade cancel` | `test_shop.py`, `test_exploits.py`, `test_full_lives.py` |
| Casino, blackjack escrow, addiction, and gambling tax | `/casino slots`, `/casino blackjack`, `/casino roulette`, `/casino coinflip`, `/casino compulsion` | `test_casino_stage9.py`, `test_exploits.py`, `test_full_lives.py`, `test_measure_balance.py` |
| Stocks, bonds, market events, and investment records | `/invest market`, `/invest buy`, `/invest sell`, `/invest portfolio`, `/invest history`, `/invest bonds buy` | `test_investing_stage9.py`, `test_full_lives.py` |
| Achievements, leaderboards, legacy points, archives, and estates | `/leaderboard`, `/achievements`, `/lives list`, `/lives view`, `/graveyard`, `/inheritance`, `/retire_life`, `/leaderboard_privacy` | `test_stage10.py`, `test_migrations.py`, `test_full_lives.py` |
| Owner administration and help | `/admin give_money`, `/admin set_stat`, `/admin kill`, `/admin reset_player`, `/admin ban`, `/admin unban`, `/admin market_event`, `/admin reload_data`, `/admin audit`, `/admin sync`, `/help` | Stage 7–10 cog-loading tests; transaction, validation, and authorization coverage in the unit/exploit suite |
| Lightweight social commands | `/coinflip`, `/roll`, `/bet`, `/8ball`, `/trivia`, `/rps`, `/slots`, `/random`, `/choose`, `/ship`, `/fact`, `/joke`, `/randomuser`, `/poll`, `/rate`, `/compliment`, `/roast`, `/hug` | Cog-loading coverage; escaping and deterministic `_ship_compatibility_score` regression in `test_exploits.py` |

The command names above were checked against the registered `discord.py` command groups and decorators. `/coinflip` and `/slots` are the lightweight social commands; `/casino coinflip` and `/casino slots` are the persistent in-game casino commands. Mutating Discord controls were reviewed for owner checks, component nonces, server-side one-use validation, and post-use disabling. Offline wrong-owner regressions cover event, shop, blackjack, and compulsion views; service-level stale/replay tests cover the underlying nonce checks.

## Defects found and corrected

1. **Archived summary JSON was wrapped in the archive record.** `LegacyRepository.insert_past_life` serialized its containing row-like record into `past_lives.summary_json`, so readers expecting fields such as `debts_due_cents` at the JSON top level failed. New rows now serialize the detailed summary object directly. Migration `011_repair_archived_life_summaries.sql` unwraps affected persisted envelopes within the migration runner's atomic transaction and restores the archive update-immutability trigger. Regression coverage verifies direct fields, repaired historical data, and immutability.
2. **The 500-life harness used inconsistent identifiers for test cohorts.** It compared a loop index with sets/dictionaries keyed by Discord user ID; an intermediate correction also checked membership in an initially empty asset dictionary before creating those assets. The final harness passes the explicit `integration_users` set and consistently uses `user_id`, then records assets after creation. The unseeded financial sample excludes seeded integration/addiction users and lives that actually retired.
3. **The violent-crime measurement undercounted convictions.** Its earlier estimator sampled conviction only for successful caught attempts, while production can convict a caught failed attempt too. Conviction is now sampled for every caught attempt; the 50% fine remains conditional on a successful attempt with loot. A deterministic regression test forces a failed-but-caught assault to be convicted and checks custody exposure.
4. **A stale cog-loader docstring was corrected.** `bot.py` now describes the loaded extensions accurately; behavior was not changed.
5. **The full-life retirement assertion assumed all 20 target candidates would survive to age 40.** One fixed-seed target died naturally at age 20, so the completed simulation failed only the brittle exact-count assertion. The harness now requires at least 15 retirement routes and verifies that the actual completion counter equals the archived `Life abandoned` count. The rerun passed with 19 completed retirements; this was a test expectation defect, not a retirement-service defect.

No `config.py` balance constants were changed. The repository has no stated numeric acceptance ranges for mortality, wealth, promotion timing, or crime EV; the report therefore records observations rather than inventing thresholds. Existing casino RTP and lawyer-conviction acceptance checks remain the applicable coded targets.

## Discord setup and README review

The README install and Discord guidance were checked against official Discord documentation: [OAuth2 scopes](https://discord.com/developers/docs/topics/oauth2), [Application Commands](https://discord.com/developers/docs/interactions/application-commands), [Getting Started / Installation](https://discord.com/developers/docs/quick-start/getting-started), and [Gateway intents](https://discord.com/developers/docs/topics/gateway):

- Guild installation uses the `bot` and `applications.commands` scopes. Discord includes `applications.commands` with the `bot` scope; listing both is explicit and valid.
- Application-command availability and bot channel permissions are distinct. The listed bot permissions—View Channels, Send Messages, Embed Links, and Add Reactions for `/poll`—match the current command behaviors; Administrator is not requested for the bot.
- The code uses `discord.Intents.default()` and does not enable Message Content, Server Members, or Presence privileged intents. The README notes the cache limitation for `/randomuser`.
- `/admin` uses Discord's Administrator command permission plus a server-side `OWNER_IDS` check. `/guild_death_summaries` requires the human's Manage Server permission. The development-guild sync and explicit `/admin sync` global publication instructions match `bot.py`.
- The command reference was checked against the actual cogs. No README edit was required. `requirements.txt` already pins all seven dependencies exactly; the final check results are recorded below.

A live Discord login, invite installation, permission exercise, and command sync were not run because this workspace has no bot token or test guild. The portal/invite guidance was reviewed, not exercised against a live application.

## Scope limits

- The 500-life run is deterministic and headless. Its decisions are randomized from fixed seeds, but it is one reproducible cohort, not an exhaustive state-space or user-strategy proof. The harness injects test-only funds for the integration cohort and elevated addiction for a targeted cohort; both are excluded from the unseeded economic rates. Completed retirements are also excluded; a retirement-profile life that dies naturally before its retirement decision remains in that sample. A separate five-life illness cohort is forced for route coverage and remains in the unseeded economic sample.
- The mortality-only measurement calls the production pure yearly simulation function and intentionally omits the integrated economy, crime, family, and archive writes. The full-life cohort separately exercises those services.
- The bankruptcy percentage is the rate of the existing debt/net-worth condition used for bankruptcy-achievement eligibility, not a player-declared bankruptcy event. There is no player bankruptcy action or cooldown to test; this absence is explicitly regression-checked.
- Violent-crime dollar EV is direct dirty loot less the modeled fine. Custody-year exposure is reported separately; the direct dollar EV does not price imprisonment, lost wages, future record/notoriety effects, laundering, tax, or relationship consequences.
- The blackjack RTP Monte Carlo uses one stated fixed policy (hit below 17, stand at 17+, no doubles/splits); it is not a result for every player strategy.
- A crime sentence, including a life sentence, is not a separate crime-death mechanic. Natural/health death and confirmed retirement are implemented. The diseases catalog is validated, but only gambling addiction is integrated with gameplay; `Lifestyle` has no player action or yearly subsystem.
- The bot's privileged intents remain disabled. As documented in the README, `/randomuser` can only choose from the guild members currently cached by Discord.py.
- Game content remains fictional and non-graphic; there is no self-harm mechanic. A static scan of Python and JSON game sources found no self-harm/suicide terms.
- No HTML, Jinja, web application, or website artifacts are part of this Python-only project.

## Stage 12 file inventory

Added: `core/migrations/011_repair_archived_life_summaries.sql`, `tests/test_full_lives.py`, `tests/test_measure_balance.py`, `tools/measure_balance.py`, `VERIFICATION_REPORT.md`, and `STAGE12_SOURCE_CONTENTS.md`. Updated: `core/repositories/legacy.py`, `tests/test_exploits.py`, `tests/test_migrations.py`, `tests/test_stage10.py`, `bot.py`, and `DESIGN_NOTES.md`. The source bundle contains full snapshots of all Stage 12 added/changed source and report files; `README.md` and `requirements.txt` are also included as audited, unchanged files.

## Run results

### Focused regression suite

`python -m pytest -q tests/test_exploits.py tests/test_measure_balance.py tests/test_migrations.py tests/test_stage10.py::test_death_is_exactly_once_archived_immutable_and_closes_career` → **23 passed, 4 warnings in 1.87s**. The four warnings are `DeprecationWarning`s emitted by the installed `discord/utils.py` when it passes `count` positionally to `re.sub`; they are not test failures.

### Completed balance CLI run

`python -m tools.measure_balance` completed successfully in **36.45s** using its default sample sizes. This is the actual corrected run (including conviction sampling after failed-but-caught crime attempts), not the earlier low-sample smoke run.

**Mortality-only:** 2,000 lives; seed `20261002`; mean age **78.05**, median **83**, population SD **15.74**; p10 **58**, p25 **71**, p75 **88**, p90 **92**; min **1**, max **111**; deaths before 18: **22**. Terminal causes: **1,590 natural causes**, **410 illness**. The observed mean is close to the configured `BASE_LIFESPAN_MEAN=78`; this sample is descriptive, not an acceptance test. The run uses only the production yearly mortality/stat-drift function, not the economy or integrated services.

**Casino gross RTP:** fixed `$100.00` wager per trial; casino seed `20260930`; RTP is aggregate gross payout divided by stake.

| Game / bet | Trials | Observed gross RTP |
|---|---:|---:|
| Slots | 1,000,000 | 91.9354% |
| Coinflip (heads) | 1,000,000 | 97.0830% |
| Roulette red | 1,000,000 | 97.2714% |
| Roulette first dozen | 1,000,000 | 97.6137% |
| Roulette straight 0 | 1,000,000 | 98.3988% |
| Blackjack, hit below 17 / stand at 17+, no double or split | 250,000 | 94.1286% |
| Lottery ticket, exact catalog EV (not Monte Carlo) | Exact | 55.50% gross RTP; `$4.45` expected net loss per `$10` ticket at price index 1 |

**Violent-crime direct cash EV:** 1,000,000 trials per crime; seed `20261008`; baseline age-eligible adult with smarts/fitness 50, luck/notoriety/record 0, and free public counsel when caught. Dollar EV is gross dirty loot minus modeled fine; prison time is shown separately, not monetized.

| Crime | Success chance (observed) | Arrests observed | Convictions observed | Gross loot EV / attempt | Fine EV / attempt | Direct net EV / attempt | Custody years / attempt |
|---|---:|---:|---:|---:|---:|---:|---:|
| Assault | 70.0% (69.918%) | 57.560% | 48.954% | `$0.00` | `$0.00` | `$0.00` | 0.9792 |
| Armed robbery | 40.0% (40.013%) | 71.426% | 60.731% | `$12,407.40` | `$2,897.25` | `$9,510.15` | 6.0731 |
| Bank heist | 15.0% (15.048%) | 92.934% | 78.943% | `$384,531.37` | `$114,029.76` | `$270,501.61` | 13.8097 |
| Murder | 60.0% (59.937%) | 77.770% | 66.088% | `$0.00` | `$0.00` | `$0.00` | 39.3382 |

The direct net-dollar EV of armed robbery and bank heist is positive under this narrow calculation; it does **not** price the substantial custody exposure, lost work, or long-term record/notoriety effects listed under Scope limits. These are measured observations, not a claim that the choices are risk-free or fully modeled. No balance constants were tuned because the repository defines no numeric acceptance bands for these rates.

### 500-life full-engine integration

`LIFELINE_RUN_FULL_LIVES=1 python -m pytest -q -s tests/test_full_lives.py` → **1 passed in 1262.71s (21:02)**. The first completed simulation attempt finished all 500 lives and passed its database/state invariants but failed one brittle harness assertion requiring exactly 20 retirement actions; one designated profile had died naturally at age 20. The harness was corrected to require at least 15 retirement completions and cross-check that exact result against archived `Life abandoned` records. The final fixed-seed rerun passed with 19 completed retirements and 19 matching abandoned archives.

| Full-life result | Observed |
|---|---:|
| Seed / completed lives / annual steps | `20261001` / 500 / 37,998 |
| Terminal causes | 383 natural causes; 98 illness; 19 `Life abandoned` |
| Non-retired death-age median (natural and illness combined) | 82 years (481 lives) |
| Crime-profile death-age median | 83 years (100 profiles) |
| Addiction-profile death-age median | 81 years (100 profiles) |
| Unseeded economic sample | 365 lives |
| Median final net worth in economic sample | `$806,993.72` |
| Millionaire rate / billionaire rate | 41.1% / 0.0% |
| Existing bankruptcy-achievement trigger rate | 0.0% |
| First promotions | 141 lives; median age 35 |

Integrated settled casino sample: slots 679 hands, 94.33% observed RTP; coinflip 1,332 hands, 96.75%; roulette 655 hands, 95.27%; blackjack 20 hands, 105.00%. These are small, randomized route-coverage samples; the larger Monte Carlo table above is the casino balance measurement.

**Route counters:** 3,898 events resolved; 1,762 studies; 117 college enrollments; 823 jobs started; 4,224 work actions; 310 dates; 1,391 family actions; 447 crimes attempted; 465 trials resolved; 3,418 prison actions; 643 purchases; 248 sales; 10 trades; 1,988 casino plays; 1,369 compulsions; 20 stock buys and 20 stock sells; 5 bonds bought; 19 retirements; 216 expected rule rejections. No unexpected exception escaped the simulation.

All 500 lives reached a terminal state and were archived. The run verified top-level archive fields (no nested `summary_json` envelope), integer money/stat bounds for every persisted character, no active characters, no pending events/compulsions/blackjack sessions/trials/tax prompts, no locked family assets or active loans, unique archive/achievement rows, `PRAGMA integrity_check = ok`, and an empty `PRAGMA foreign_key_check` result.

### Full suite and environment checks

- `python -m pytest -q` → **178 passed, 1 skipped, 188 warnings in 25.95s**. The skipped test is the opt-in 500-life test; it was run separately as listed above.
- The 188 warnings are `DeprecationWarning`s from the installed `discord/utils.py` call to `re.sub` with positional `count` (184 during cog-loading tests, 4 in escaping tests). They do not fail tests and did not require a dependency or behavior change.
- `python -m pip check` → **No broken requirements found**; `requirements.txt` has **7/7 exact pins**.
- `python -m compileall -q bot.py cogs core tests tools` → **passed**.
- The README and Discord portal/invite guidance were reviewed; no edit was needed. A live bot login, invite, permission exercise, and command sync were not run because there is no token/test guild in this workspace.

No `config.py` balance constants were changed: the observed mortality mean is close to the configured base mean, the high-volume casino observations are reported against the production rules, and no numeric acceptance bands are defined for wealth, promotion timing, or crime dollar EV. The positive direct cash EV observed for some crimes is disclosed above with its unpriced custody exposure; no unsupported balancing target was invented.
~~~~

## `README.md (audited; unchanged)`

~~~~markdown
# LIFELINE

LIFELINE is a Python-only, headless-engine-backed Discord life simulator. Slash commands guide a fictional character through school, work, relationships, a crime/prison loop, a shop, trades, casino games, investing, annual events, and an immutable life archive. Currency is stored as integer cents in SQLite. Casino and stock markets use fictional in-game currency only; there are no deposits, withdrawals, or real-money cash-outs.

## Requirements

- Python 3.10 or newer (Python 3.13 is supported by the pinned dependencies).
- A Discord application with a bot user and a server where you can install it.
- A Discord bot token. Keep it private; do not commit `.env`.

## Fresh install

From the project directory:

```bash
python3 --version
python3 -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
cp .env.example .env
```

Edit `.env` and set at least `DISCORD_TOKEN`. Set `OWNER_IDS` to a comma-separated list of Discord user IDs allowed to run `/admin` commands. For first-time command registration and development, set `DEV_GUILD_ID` to the server ID where the bot is installed. Start the bot with:

```bash
python bot.py
```

The database is created at `data/lifeline.db` by default. Override it with `DB_PATH`. `RNG_SEED` is optional and is intended for repeatable local/test runs, not production randomness. Logs use `LOG_LEVEL` (default `INFO`).

To obtain a Discord user ID for `OWNER_IDS` or `DEV_GUILD_ID`, enable Developer Mode in the Discord client, then right-click the user or server and choose **Copy User ID** or **Copy Server ID**.

## Discord Developer Portal and installation

1. In the [Discord Developer Portal](https://discord.com/developers/applications), create an application and open its **Bot** page. Use the bot token shown there as `DISCORD_TOKEN`; reset it immediately if it is exposed.
2. This bot uses application commands and the standard gateway intents. **Message Content, Server Members, and Presence privileged intents are not enabled or needed for the core LIFELINE command set.** Do not enable privileged intents unless you later add a feature that needs them.
3. On the app's **Installation** page, configure a **Guild Install** with the `bot` and `applications.commands` scopes. Discord currently includes `applications.commands` with the `bot` scope, but listing both makes the intended installation clear.
4. Grant only the bot permissions needed to answer interactions, render embeds, and add the numbered reactions used by `/poll`: **View Channels**, **Send Messages**, **Embed Links**, and **Add Reactions**. Do not grant Administrator. Server members need access to application commands in the channels where they use the bot. `/admin` is hidden from non-administrators in Discord and also checks `OWNER_IDS` server-side, so configured owners must have the **Administrator** user permission; the bot itself must not receive it. `/guild_death_summaries` is restricted to a human with **Manage Server**; this is a user permission, not a bot permission.
5. Install the bot through the generated Guild Install URL. Start it with `DEV_GUILD_ID` set; startup copies and syncs commands to that development guild. Once `/admin sync` is visible, an authorized `OWNER_IDS` user can publish the command tree globally with `/admin sync`. Startup deliberately does not sync globally when `DEV_GUILD_ID` is empty.

Official references: [Discord OAuth2 scopes](https://discord.com/developers/docs/topics/oauth2), [Application Commands](https://discord.com/developers/docs/interactions/application-commands), [Getting Started / Installation](https://discord.com/developers/docs/quick-start/getting-started), and [Gateway intents](https://discord.com/developers/docs/topics/gateway).

## Slash-command reference

### Life and education

- `/life start`, `/life status`, `/life age`, `/life choice`
- `/education status`, `/education study`, `/education enroll`
- `/career list`, `/career apply`, `/career status`, `/career history`, `/career work`, `/career quit`, `/career retire`

### Relationships, crime, and custody

- `/family`
- `/relationship list`, `/relationship interact`, `/relationship propose`, `/relationship marry`, `/relationship divorce`, `/relationship breakup`, `/relationship try_for_baby`, `/relationship adopt`, `/relationship temptation`
- `/date find`, `/friends find`
- `/crime list`, `/crime commit`, `/crime launder`, `/crime record`
- `/prison status`, `/prison action`

### Shop and economy

- `/shop browse`, `/shop buy`, `/shop ring`
- `/inventory view`, `/inventory sell`, `/inventory use`
- `/trade offer`, `/trade list`, `/trade cancel`
- `/casino slots`, `/casino blackjack`, `/casino roulette`, `/casino coinflip`, `/casino compulsion`
- `/invest market`, `/invest buy`, `/invest sell`, `/invest portfolio`, `/invest history`, `/invest bonds buy`

### Archives, settings, and administration

- `/start` — start a fresh life (legacy-compatible root command)
- `/leaderboard`, `/achievements`, `/lives list`, `/lives view`, `/graveyard`, `/inheritance`, `/retire_life`
- `/leaderboard_privacy`, `/settings privacy`, `/settings leaderboard`, `/guild_death_summaries`
- `/admin give_money`, `/admin set_stat`, `/admin kill`, `/admin reset_player`, `/admin ban`, `/admin unban`, `/admin market_event`, `/admin reload_data`, `/admin audit`, `/admin sync`
- `/help`

### Lightweight social commands

These are separate from the persistent LIFELINE economy: `/coinflip`, `/roll`, `/bet`, `/8ball`, `/trivia`, `/rps`, `/slots`, `/random`, `/choose`, `/ship`, `/fact`, `/joke`, `/randomuser`, `/poll`, `/rate`, `/compliment`, `/roast`, and `/hug`.

## Verification and known scope limits

Run the ordinary unit and integration suite with:

```bash
pytest -q
```

The 500-complete-life integration run is intentionally opt-in because it exercises tens of thousands of SQLite-backed yearly transactions:

```bash
LIFELINE_RUN_FULL_LIVES=1 pytest -q -s tests/test_full_lives.py
```

The headless engine has natural/health death and confirmed retirement paths, but there is no gameplay accident-death or crime-death route. A crime sentence, including a life sentence, is not a distinct crime-death mechanic. The diseases file is schema-validated; only the gambling-addiction condition is integrated with gameplay. `Lifestyle` is a model enum but has no player action or annual lifestyle system. Player bankruptcy is not an action or cooldown mechanic; the existing `bankrupt` achievement is a debt/net-worth condition, and stock delisting is a market event rather than player bankruptcy. `/randomuser` selects from Discord's currently cached guild members because this bot intentionally does not request the privileged Server Members intent; that cache may not contain every server member. These gaps are documented rather than filled with new features during final verification.

See `DESIGN_NOTES.md` and `VERIFICATION_REPORT.md` for system details, measured results, and limitations.
~~~~

## `requirements.txt (audited; unchanged)`

~~~~text
discord.py==2.7.1
aiosqlite==0.22.1
python-dotenv==1.2.4
PyYAML==6.0.3
pytest==9.0.3
pytest-asyncio==1.4.0
pytest-mock==3.16.0
~~~~

