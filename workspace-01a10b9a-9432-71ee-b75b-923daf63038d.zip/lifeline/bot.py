"""LIFELINE Discord bot entry point."""
from __future__ import annotations

import asyncio
import logging
import secrets
import time

import discord
from discord import app_commands
from discord.ext import commands

from core.achievements import AchievementService
from core.casino import CasinoService
from core.config import Config
from core.crime import CrimeService
from core.data_loader import DataLoader
from core.db import DatabaseManager
from core.errors import GameError
from core.economy import EconomyService
from core.repositories.admin import AdminRepository
from core.family import FamilyService
from core.investing import InvestingService
from core.locks import UserLockRegistry
from core.rng import RNG
from core.shop import ShopService

logging.basicConfig(
    level=getattr(logging, Config.from_env().log_level, logging.INFO),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("lifeline")


class LifelineBot(commands.Bot):
    """Main bot class, owning shared database, RNG, and action-lock services."""

    def __init__(self, config: Config | None = None):
        self.config = config or Config.from_env()
        intents = discord.Intents.default()
        # Default intents intentionally leave Message Content, Members, and Presence disabled.
        super().__init__(
            command_prefix=commands.when_mentioned_or("!"),
            intents=intents,
            help_command=None,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        self.db: DatabaseManager | None = None
        self.data_loader = DataLoader()
        self.family_service: FamilyService | None = None
        self.crime_service: CrimeService | None = None
        self.shop_service: ShopService | None = None
        self.casino_service: CasinoService | None = None
        self.investing_service: InvestingService | None = None
        self.economy_service: EconomyService | None = None
        self.health_service = None
        self.achievement_service: AchievementService | None = None
        self.rng: RNG = RNG(self.config.rng_seed)
        self.locks = UserLockRegistry()
        self.tree.on_error = self.on_app_command_error
        self.tree.interaction_check = self._tree_interaction_check

    async def setup_hook(self) -> None:
        """Validate data, initialize services/extensions, and sync only a dev guild automatically."""
        self.data_loader.load_all()
        self.db = DatabaseManager(self.config.db_path)
        await self.db.initialize()
        self.family_service = FamilyService(self.db, self.rng, self.locks)
        self.crime_service = CrimeService(
            self.db,
            self.rng,
            self.locks,
            family_service=self.family_service,
            data_loader=self.data_loader,
        )
        self.shop_service = ShopService(self.db, self.rng, self.locks, data_loader=self.data_loader)
        self.casino_service = CasinoService(self.db, self.rng, self.locks, data_loader=self.data_loader)
        recovered = await self.casino_service.recover_sessions()
        if recovered:
            logger.warning("Refunded %s unfinished blackjack session(s) at startup", recovered)
        self.investing_service = InvestingService(self.db, self.rng, self.locks, data_loader=self.data_loader)
        await self.investing_service.initialize_market()
        self.economy_service = EconomyService(self.db, self.rng, self.locks, data_loader=self.data_loader)
        # Catalog loading is validated at process startup, not deferred until a command.
        self.achievement_service = AchievementService(self.db, self.locks, data_loader=self.data_loader)
        await self._load_cogs()

        if self.config.dev_guild_id is not None:
            guild = discord.Object(id=self.config.dev_guild_id)
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
            logger.info("Synced application commands to development guild %s", guild.id)
        else:
            logger.info("Global command sync is disabled at startup; use /admin sync explicitly")

    async def _load_cogs(self) -> None:
        """Load the simulation, legacy, settings, admin, and help command extensions."""
        for extension in (
            "cogs.life",
            "cogs.health",
            "cogs.education",
            "cogs.career",
            "cogs.relationships",
            "cogs.crime",
            "cogs.prison",
            "cogs.shop",
            "cogs.casino",
            "cogs.invest",
            "cogs.economy",
            "cogs.discobot",
            "cogs.legacy",
            "cogs.settings",
            "cogs.admin",
            "cogs.help",
        ):
            await self.load_extension(extension)
            logger.info("Loaded extension %s", extension)

    async def _tree_interaction_check(self, interaction: discord.Interaction) -> bool:
        """Block active bans from game commands while keeping errors private and clear."""
        if interaction.type is discord.InteractionType.autocomplete or self.db is None:
            return True
        command = interaction.command
        if command is None:
            return True
        root = str(command.qualified_name).split(" ", 1)[0]
        if root in {"admin", "help", "settings"}:
            return True
        try:
            banned = await AdminRepository(self.db).is_banned(int(interaction.user.id))
        except Exception:
            logger.exception("Could not verify game-command ban for user %s", interaction.user.id)
            if not interaction.response.is_done():
                await interaction.response.send_message(
                    "The game could not verify your access right now. Please try again shortly.",
                    ephemeral=True,
                    allowed_mentions=discord.AllowedMentions.none(),
                )
            return False
        if not banned:
            return True
        if not interaction.response.is_done():
            await interaction.response.send_message(
                "Your account is currently banned from LIFELINE game commands. "
                "Contact a bot administrator if you believe this is an error.",
                ephemeral=True,
                allowed_mentions=discord.AllowedMentions.none(),
            )
        return False

    async def on_ready(self) -> None:
        if self.user is not None:
            logger.info("Logged in as %s (ID: %s)", self.user, self.user.id)
        logger.info("Connected to %s guilds", len(self.guilds))
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="lives unfold | /life",
            ),
            status=discord.Status.online,
        )

    async def on_app_command_completion(
        self, interaction: discord.Interaction, command: app_commands.Command
    ) -> None:
        """Record guild participation and deliver new authoritative unlock notices."""
        if self.db is None or self.achievement_service is None:
            return
        user_id = int(interaction.user.id)
        try:
            if interaction.guild_id is not None:
                from core.repositories.legacy import LegacyRepository
                async with self.db.transaction() as tx:
                    await LegacyRepository(self.db).record_guild_seen(
                        tx, int(interaction.guild_id), user_id, int(time.time())
                    )
            root = str(command.qualified_name).split()[0]
            relevant_roots = {
                "life", "start", "education", "career", "relationship", "relationships",
                "date", "friends", "family", "crime", "prison", "shop", "casino", "invest",
                "stocks", "bonds", "trade", "inventory", "bank", "loan", "finance", "economy", "health", "retire_life",
            }
            if root in relevant_roots:
                await self.achievement_service.check_user(
                    user_id, guild_id=interaction.guild_id
                )
            notices = self.achievement_service.consume_notifications(user_id)
            for start in range(0, len(notices), 5):
                group = notices[start:start + 5]
                lines = [
                    f"🏆 **{discord.utils.escape_markdown(str(item['name']))}** — "
                    f"{discord.utils.escape_mentions(str(item['description']))}"
                    for item in group
                ]
                embed = discord.Embed(
                    title="Achievement unlocked!" if len(group) == 1 else "Achievements unlocked!",
                    description="\n".join(lines),
                    color=discord.Color.gold(),
                )
                await interaction.followup.send(
                    embed=embed,
                    ephemeral=True,
                    allowed_mentions=discord.AllowedMentions.none(),
                )
        except Exception:
            logger.exception("Could not evaluate Stage 10 achievements for user %s", user_id)

    async def on_app_command_error(
        self,
        interaction: discord.Interaction,
        error: app_commands.AppCommandError,
    ) -> None:
        """Send safe user-facing errors and retain unexpected errors in logs."""
        if isinstance(error, app_commands.CommandOnCooldown):
            message = f"⏳ Try again in {error.retry_after:.1f} seconds."
        elif isinstance(error, (app_commands.CheckFailure, commands.CheckFailure)):
            message = "❌ You do not have permission to use this command."
        else:
            original = getattr(error, "original", error)
            if isinstance(original, GameError):
                message = original.message
            else:
                error_id = __import__("secrets").token_hex(4)
                logger.error(
                    "Unexpected application-command error (ID %s)",
                    error_id,
                    exc_info=(type(original), original, original.__traceback__),
                )
                message = f"An unexpected error occurred (ID: {error_id}). Please try again later."
        await self._send_error(interaction, message)

    @staticmethod
    async def _send_error(interaction: discord.Interaction, message: str) -> None:
        try:
            if interaction.response.is_done():
                await interaction.followup.send(message, ephemeral=True)
            else:
                await interaction.response.send_message(message, ephemeral=True)
        except discord.HTTPException:
            logger.exception("Could not send an application-command error response")

    async def close(self) -> None:
        logger.info("Shutting down LIFELINE")
        if self.db is not None:
            await self.db.close()
        await super().close()


async def main() -> None:
    config = Config.from_env()
    token = config.require_token()
    bot = LifelineBot(config)
    async with bot:
        await bot.start(token)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
