# LIFELINE source bundle

Generated: 2026-10-05

`LIFELINE_SOURCE_BUNDLE.zip` is a clean, current source archive. It includes the bot source,
migrations, data catalogs, tests, tools, README, design/verification notes, and current
balance-measurement JSON. Historical full-source stage dumps and exploratory cohort logs
remain in the workspace but are intentionally omitted from the distributable ZIP.

Excluded: credentials, `.env`, databases, caches, bytecode, build outputs, ZIP files, and
cohort log files. The safe `.env.example` template is included.

Indexed project files: **118** (plus one short `BUNDLE_README.txt` inside the ZIP).

## Included file index

- `.env.example`
- `BALANCE_TUNING_LOG.md`
- `DESIGN_NOTES.md`
- `LIFELINE_SOURCE_BUNDLE.md`
- `README.md`
- `VERIFICATION_REPORT.md`
- `balance_acceptance_metrics.json`
- `balance_baseline.json`
- `balance_mechanics.json`
- `bot.py`
- `cogs/__init__.py`
- `cogs/admin.py`
- `cogs/career.py`
- `cogs/casino.py`
- `cogs/crime.py`
- `cogs/crime_views.py`
- `cogs/discobot.py`
- `cogs/economy.py`
- `cogs/education.py`
- `cogs/health.py`
- `cogs/help.py`
- `cogs/invest.py`
- `cogs/legacy.py`
- `cogs/legacy_views.py`
- `cogs/life.py`
- `cogs/prison.py`
- `cogs/relationships.py`
- `cogs/settings.py`
- `cogs/shop.py`
- `cogs/shop_views.py`
- `core/__init__.py`
- `core/achievements.py`
- `core/admin.py`
- `core/careers.py`
- `core/casino.py`
- `core/config.py`
- `core/crime.py`
- `core/data_loader.py`
- `core/db.py`
- `core/death.py`
- `core/economy.py`
- `core/education.py`
- `core/embeds.py`
- `core/errors.py`
- `core/events.py`
- `core/family.py`
- `core/health.py`
- `core/investing.py`
- `core/leaderboard.py`
- `core/life_engine.py`
- `core/locks.py`
- `core/migrations/001_initial.sql`
- `core/migrations/002_life_events.sql`
- `core/migrations/003_education.sql`
- `core/migrations/004_careers.sql`
- `core/migrations/005_relationships_family.sql`
- `core/migrations/006_crime_prison.sql`
- `core/migrations/007_shop_inventory_trading.sql`
- `core/migrations/008_casino_investing.sql`
- `core/migrations/009_achievements_legacy.sql`
- `core/migrations/010_stage11_admin_settings.sql`
- `core/migrations/011_repair_archived_life_summaries.sql`
- `core/migrations/012_economy.sql`
- `core/migrations/013_health_system.sql`
- `core/models.py`
- `core/money.py`
- `core/repositories/__init__.py`
- `core/repositories/admin.py`
- `core/repositories/casino.py`
- `core/repositories/crime.py`
- `core/repositories/economy.py`
- `core/repositories/family.py`
- `core/repositories/health.py`
- `core/repositories/investing.py`
- `core/repositories/legacy.py`
- `core/repositories/settings.py`
- `core/repositories/shop.py`
- `core/rng.py`
- `core/shop.py`
- `core/validators.py`
- `core/views.py`
- `data/achievements.json`
- `data/careers.json`
- `data/countries.json`
- `data/crimes.json`
- `data/diseases.json`
- `data/events.json`
- `data/gambling_ages.json`
- `data/items.json`
- `data/majors.json`
- `data/names.json`
- `data/stocks.json`
- `requirements.txt`
- `tests/__init__.py`
- `tests/conftest.py`
- `tests/test_careers.py`
- `tests/test_casino_stage9.py`
- `tests/test_crime.py`
- `tests/test_economy.py`
- `tests/test_education.py`
- `tests/test_events.py`
- `tests/test_exploits.py`
- `tests/test_family.py`
- `tests/test_full_lives.py`
- `tests/test_health.py`
- `tests/test_investing_stage9.py`
- `tests/test_life_engine.py`
- `tests/test_measure_balance.py`
- `tests/test_migrations.py`
- `tests/test_money.py`
- `tests/test_shop.py`
- `tests/test_stage10.py`
- `tests/test_stage10_cog_loading.py`
- `tests/test_stage7_cog_loading.py`
- `tests/test_stage8_cog_loading.py`
- `tests/test_stage9_cog_loading.py`
- `tools/build_source_bundle.py`
- `tools/measure_balance.py`
