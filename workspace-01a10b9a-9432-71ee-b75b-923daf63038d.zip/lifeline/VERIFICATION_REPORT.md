# LIFELINE Repair & Verification Report

**Report date:** 2026-10-05  
**Project:** Existing Python / `discord.py` bot  
**Scope:** Repair the existing bot while preserving Stages 1–12, existing command names/behavior, lightweight social commands, and the Python-only project scope. No website files were added.

## Plan and implementation summary

1. Preserve existing command groups, social commands, persistence, and stage behavior; use new schema only in migrations 012+.
2. Complete the requested integer-cent economy and fictional health systems, with transactional repositories and service-layer validation.
3. Measure the balance using the seeded full-engine harness and the pure Monte Carlo/crime-EV tool; change only `GameBalance` constants for balance tuning.
4. Run focused and full tests, execute the default 500-life cohort, and update the design/verification/source-bundle documentation.

### Part A — Economy

Implemented progressive income/capital-gains taxes, inflation-indexed prices, annual living costs, housing and lifestyle choices, bank transfers and interest, strict amount parsing, six amortizing loan types, credit underwriting and repayment cascade, collections/eviction/repossession/default, and bankruptcy discharge/rebuild rules. Persistent money is integer cents. Charges/fees round up, payouts/salaries round down, money writes run inside SQLite transactions, and SQL is parameterized and repository-owned.

Commands added without renaming existing groups:

- `/bank status`, `/bank deposit`, `/bank withdraw`
- `/loan list`, `/loan apply`, `/loan pay`
- `/finance status`, `/finance bankruptcy`
- `/economy status`, `/economy lifestyle`, `/economy housing`

### Part B — Health

Implemented the 28-condition catalog, annual onset and untreated progression, condition-aware competing mortality, once-per-year care activities, doctor/hospital/therapy/surgery actions, one-year insurance and renewal, and owner-only health commands. Conditions and visits are stored through repositories; migration 013 preserves existing diagnosed-condition data. Health content is fictional, supportive, PG-13, and has no self-harm mechanic.

Commands: `/health status`, `/health doctor`, `/health hospital`, `/health therapy`, `/health activity`, `/health insurance`, and `/health surgery`; the existing surgery route now offers medical or plastic procedure choices. Top-level `/doctor`, `/hospital`, `/therapy`, and `/insurance` aliases call the same services without replacing the `/health` group.

## Defects found and fixes

1. **Disease onset multiplier was declared but unused.** Wired `HEALTH_DISEASE_ONSET_MULTIPLIER` into annual onset probability and added a regression proving the configured value changes incidence.
2. **Early integrated mortality was excessive in the first cohort.** With the multiplier at 0.25, a fixed-seed 50-life probe recorded 35 illness deaths and a 64.5-year median. The onset multiplier was tuned to 0.10; a following 50-life probe with the same 2% inflation setting recorded 16 illness deaths and a 77.5-year median. These pilot results are descriptive, not confidence intervals.
3. **The full-life harness sometimes attempted to indulge an addiction compulsion without enough funds.** It now checks available cash plus bank against the forced wager and resists if it is unaffordable.
4. **`YearOutcome.died` could be stale after death during a later annual service, notably prison-violence death.** The final `LifeEngine.age_up` result now reflects the committed character’s final alive/death fields. A regression verifies the outcome and archive agree.
5. **Inflation-path regression coverage.** The annual-settlement test derives expected inflation from the configured mean, standard deviation, and bounds, rather than assuming a fixed inflation outcome.
6. **Migration upgrade fixtures and cured-condition severity.** The migration fixtures include the pre-existing condition table; cured records retain valid severity 1 with `status='cured'` and inactive state. Upgrade coverage checks that existing diagnosed data survives migration 013.
7. **Care command discoverability and elective plastic surgery.** Preserved `/health surgery` as a leaf command with an optional procedure choice; added adult-only, non-insured plastic surgery using the existing visit ledger, plus top-level `/doctor`, `/hospital`, `/therapy`, and `/insurance` aliases. Tests cover command registration, choices, eligibility, costs, once-per-year limits, and rollback.

## Part C — Balance measurements

### Targets and config changes

The full-life acceptance bands exercised by `tests/test_full_lives.py` are explicit: normal-lifestyle median lifespan 75–85 years; heavy-crime and heavy-addiction medians each 45–65; normal lives reaching $1m net worth 8–20%; normal billionaire rate below 0.5%; natural bankruptcy filings 3–10%; college-graduate median final net worth 25,000,000–150,000,000¢ ($250,000–$1.5m); no-high-school median final net worth 0–15,000,000¢ ($0–$150,000); and average-performer time to first promotion 2–4 years. Exact outcomes and per-seed PASS/FAIL decisions for the current threshold appear in the final-pass section below.

Final-pass configuration changes are limited to the requested bankruptcy minimum and health-care feature; no other general balance values were tuned:

| Setting | Prior value | Current value | Rationale |
|---|---:|---:|---|
| `BANKRUPTCY_MIN_DISCHARGEABLE_DEBT_CENTS` | 181,144,692¢ | **181,200,000¢ ($1.812m)** | Retained the latest-directed $1.812m setting. The $1.20m request is unmet because the source diagnostic found $1.215m–$1.396m in standalone living-expense arrears; a historical eligibility-triggered filing policy produced 20%, but is not a natural player filing rate. |
| `HEALTH_DISEASE_ONSET_MULTIPLIER` | 0.09 before this pass | **0.09** | Retained with evidence: the historical 0.25→0.10 pilot reduced illness deaths (35→16) and increased median lifespan (64.5→77.5 years); both final-size 500-life `0.09` cohorts have normal/crime/addiction medians in range. `1.0` was not run and is not claimed to pass. |
| `HEALTH_PLASTIC_SURGERY_FEE_CENTS` | — | **2,000,000¢** | Adult-only, elective, non-insured base cost; indexed for country healthcare costs and inflation. |
| `HEALTH_PLASTIC_SURGERY_LOOKS_BONUS` | — | **5** | Deterministic appearance increase capped at the existing 100-point stat maximum. |

Current inflation remains a configured distribution: mean 2.8%, standard deviation 1.2%, bounded from −1% to 9%; wage-inflation pass-through is 0.8. The earlier fixed-0.5% description is stale and is not a current configuration claim. Casino payout rules were measured, not retuned.

To make the crime/addiction lifespan comparison a stronger stress test, I also increased only the harness profile intensity (not game behavior or `GameBalance`): crime-profile attempts are selected with probability 0.60 instead of 0.22; addiction profiles start at 90 instead of 65 and attempt a casino play with probability 0.80 instead of 0.35. The final cohort recorded 627 confirmed crime-profile attempts (about 6.27 per profile life) and 2,451 addiction-profile casino plays (about 24.51 per profile life). This improves exposure but does not turn the profile comparison into a randomized treatment study.

### Historical integrated 500-life cohort (pre no-forced-filing correction)

This historical run used the earlier harness helper that automatically submitted a filing whenever the character was eligible. It is retained for non-bankruptcy metrics and route coverage, but its filing count is not a natural player filing rate and is not final validation of the filing target.

Command: `LIFELINE_RUN_FULL_LIVES=1 python -m pytest -q -s tests/test_full_lives.py`  
Result: **2 passed in 1219.12s (20:19)** (the seeded cohort plus the quantile-summary regression); seed `20261001`; 500 complete lives; 34,942 annual steps.

| Lifespan group | N | Mean | Median | P10 | P25 | P75 | P90 | Min–max |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| All non-retired lives (includes illness and prison-violence deaths) | 481 | 71.06 | **77** | 47 | 61 | 84 | 90 | 1–101 |
| Crime stress profile | 100 | 74.91 | **80** | 53 | 64 | 85 | 91 | 29–99 |
| Addiction stress profile | 100 | 69.00 | **74** | 44 | 57 | 84 | 89 | 11–101 |

Terminal causes were 291 natural causes (58.2%), 189 illness (37.8%), 1 prison violence (0.2%), and 19 `Life abandoned` retirement-route exits (3.8%). The overall lifespan field is not a natural-cause-only estimate. The illness deaths include 59 generic `illness` outcomes and 130 named catalog-condition causes.

| Measure | Observed result |
|---|---:|
| Health-condition records | 1,188 total across 28 IDs; **2.376 records/life** on average |
| Unseeded financial sample | 365 lives |
| Final net worth mean / median | **$1,990,659.78 / $52,165.60**; mean is strongly skewed by the upper tail |
| Final net worth P10 / P25 | **−$416,596.65 / −$148,751.95** |
| Final net worth P75 / P90 | **$515,994.26 / $1,781,417.24** |
| Final net worth min / max | **−$784,299.11 / $202,361,898.18** |
| Millionaire / billionaire rate | **15.89% / 0%** |
| Existing insolvency-achievement trigger | **349/365 (95.62%)**; definition is any negative yearly net worth or debt due exceeding gross assets, not an actual bankruptcy filing |
| Bankruptcy filings exercised | **4**; intentional route-coverage filings among five seeded profiles, not a natural strategy/population rate |
| First-promotion age distribution | 158 promotions; mean **34.51**, median **31.5**, P10/P25 **21/24**, P75/P90 **43/54**, range **20–59** |
| Retirement route | 19 of 20 designated profiles; the harness requires at least 15 and passed |
| Loan activity | 9 applications; 371 annual payments |

Final catalog-condition record counts: anemia 33; anxiety disorder 30; arthritis 28; asthma 26; back pain 69; burnout 31; chronic pain 10; common cold 160; depressive episode 21; digestive sensitivity 41; eczema 51; food intolerance 19; gambling addiction 97; healing injury 49; hearing loss 18; heart condition 13; high blood pressure 42; influenza 85; memory changes 22; migraine 38; osteoporosis 18; post-viral fatigue 20; seasonal allergies 99; skin sensitivity 39; sleep disruption 57; thyroid condition 18; type 2 diabetes 30; vision condition 24.

The high insolvency-achievement trigger is not equivalent to bankruptcy incidence: it includes transient negative net worth and early collections and is not an actual filing counter. The historical 500-life harness automatically filed whenever its eligibility helper returned true; those filings are not evidence of ordinary player action. The final harness was corrected to audit eligibility only and never submit `/finance bankruptcy`. With no filing decision policy, actual bankruptcy incidence is action-dependent and cannot be tuned by the minimum threshold alone.

Historical 500-life route counters (before the no-forced-filing correction): 3,402 events; 1,809 studies; 119 college enrollments; 789 jobs started; 3,807 work actions; 307 dates; 1,195 family actions; 627 crimes attempted (all 627 from the crime stress profile); 537 trials; 4,258 prison actions; 341 purchases; 134 sales; 10 trades; 2,464 casino plays (2,451 in the addiction profile); 1,137 compulsions; 20 health activities; 3 doctor, 4 hospital, and 4 therapy visits; 20 insurance policies; 9 loan applications and 371 payments; 20 stock buys and sells; 5 bonds; 19 retirement routes; 4 eligibility-triggered bankruptcy filings; 215 expected-rule rejections.

Integrated casino samples are route-coverage samples, not the RTP estimate: slots 813 hands / 89.42%, coinflip 1,220 / 93.40%, roulette 785 / 97.07%, blackjack 17 / 76.47%. These small randomized samples are not useful RTP estimates.

### Mortality baseline and casino RTP

`python -m tools.measure_balance` completed in **48.98s**. Its mortality output is a **no-condition baseline** from `simulate_year`, not integrated health mortality. Seed `20261002`, 2,000 lives: mean age **78.05**, median **83**, population SD **15.74**; p10 **58**, p25 **71**, p75 **88**, p90 **92**; min **1**, max **111**; 22 deaths before age 18. Causes: 1,590 natural, 410 illness.

Casino Monte Carlo uses a fixed $100 stake per hand; seed `20260930`:

| Game / method | Trials | Observed gross RTP |
|---|---:|---:|
| Slots | 1,000,000 | **91.9354%** |
| Coinflip (heads) | 1,000,000 | **97.0830%** |
| European roulette red | 1,000,000 | **97.2714%** |
| European roulette first dozen | 1,000,000 | **97.6137%** |
| European roulette straight 0 | 1,000,000 | **98.3988%** |
| Blackjack, hit below 17 / stand at 17+, no doubles or splits | 250,000 | **94.1286%** |
| Lottery ticket, exact catalog EV | Exact | **55.50%** |

The configured game mathematics imply 92.00% slots, 97.00% coinflip, and 97.2973% for each European roulette bet before cent rounding; Monte Carlo values fluctuate, especially high-payout straight bets. Blackjack is conditional on the stated fixed policy. Lottery RTP is exact at price index 1.0.

### Violent-crime EV including custody proxy

Estimator: 1,000,000 trials per crime; seed `20261008`; baseline adult (smarts/fitness 50, zero luck/notoriety/record), public counsel on caught cases. Direct EV is gross dirty loot less the modeled fine. Custody EV is expected sentence years times **$52,000 per year**; it is an opportunity-cost proxy, not a direct game charge or an exact wage forecast.

| Crime | Direct net EV / attempt | Custody-cost EV / attempt | Net EV after custody / attempt |
|---|---:|---:|---:|
| Assault | $0.00 | $50,917.67 | **−$50,917.67** |
| Armed robbery | $9,510.15 | $315,802.66 | **−$306,292.51** |
| Bank heist | $270,501.61 | $718,103.36 | **−$447,601.75** |
| Murder | $0.00 | $2,045,588.69 | **−$2,045,588.69** |

The estimator samples conviction for every caught attempt, including unsuccessful-but-caught crimes; fines remain conditional on successful caught attempts with loot. Custody monetization does not include record/notoriety effects, future wages, family effects, or other non-cash consequences.

## Part D — Tests and validation

- `python -m pytest -q` → **218 passed, 1 skipped, 221 warnings in 35.92s**. The skipped test is the opt-in full-life cohort, run separately above. The warnings are the installed `discord.py` `DeprecationWarning` for a positional `count` argument to `re.sub`; they are not test failures.
- Focused health/economy/life/migration/cog/measurement run → **58 passed, 217 warnings in 9.50s**.
- Strengthened-profile smoke run (`LIFELINE_LIFE_COUNT=50`) → **2 passed in 137.08s**; 66 crime-profile attempts, 249 addiction-profile casino plays, and both retirement-profile routes completed.
- `python -m compileall -q bot.py cogs core tests tools` and imports of `bot`, `core.health`, `core.life_engine`, and `cogs.health` → passed.
- `python -m pip check` → **No broken requirements found**.
- The full-life run checked archive uniqueness and payload shape, no active lives/loans/pending interactions/locked family assets, non-negative bounded money/stats, `PRAGMA integrity_check = ok`, and no foreign-key violations.

## Parts D/E limitations and remaining verification

- The earlier full suite and 500-life cohort passed their historical checks, but that 500-life harness automatically filed whenever eligibility was met. It is not valid as a natural filing-rate measurement. The explicit acceptance bands and final no-forced-filing seed results are reported below; no threshold adjustment can create filings when no user decision is simulated.
- The final 500-life results are one reproducible seed, not a confidence interval or exhaustive strategy proof. Under the strengthened stress profiles, crime-profile median lifespan was 80 versus 77 overall despite 627 confirmed crime attempts; addiction-profile median was 74 versus 77 overall after 2,451 casino plays. The addiction stress cohort shows a three-year shorter median in this seed; the crime cohort still does not show a lifespan penalty. Profile membership is deterministic and not randomized/matched on starting health or lifespan traits, so neither difference is a causal estimate.
- Natural/health death and confirmed retirement are implemented. The existing criminal sentence system includes prison-violence risk; crime EV custody cost is an analysis proxy only.
- The historical numeric finance results depend on limited randomized decisions; its four bankruptcy filings were generated by the harness calling the real filing service whenever an eligibility check passed. The 95.92% insolvency-achievement trigger is not a filing rate. The final harness removes that automatic filing action.
- A live Discord login, guild invite, permission exercise, and command sync were not run because no bot token/test guild is available. Discord portal/invite guidance in the README was reviewed; `applications.commands` scope and selected bot permissions are distinct concerns.
- Lightweight social commands were left unchanged. No HTML/Jinja/web application or website artifacts were added. `LIFELINE_SOURCE_BUNDLE.md` is the current archive index; `LIFELINE_SOURCE_BUNDLE.zip` contains the clean source bundle. Historical `STAGE10_SOURCE_CONTENTS.md` and `STAGE12_SOURCE_CONTENTS.md` remain in the workspace but are excluded from the distributable ZIP.

## Final validation — 2026-10-05

### Scope and final settings

- Bankruptcy minimum: **181,200,000¢ ($1.812m)**. Retained exactly as most recently directed; no other general balance constant was tuned.
- Disease onset multiplier: **0.09** retained with the evidence and limitations in `DESIGN_NOTES.md`; `1.0` was not run and is not claimed to pass.
- Health feature: `/health surgery` remains a leaf command and now offers the optional `procedure` choice (`medical` or `plastic`). Plastic surgery is adult-only, blocked while imprisoned, non-insured, $20,000 base cost (country/indexed), adds up to five looks points capped at 100, and shares the annual surgery limit. Added top-level `/doctor`, `/hospital`, `/therapy`, and `/insurance` aliases without removing or renaming any health commands. No migration was needed; the existing visit ledger supports surgery records.
- Monetary charges remain integer cents, rounded upward, parameterized through repositories, and transactional. Plastic-surgery insufficient-funds and ledger-failure tests verify rollback.

### Bankruptcy policy and the no-forced-filings correction

The existing full-life helper used to call `file_bankruptcy()` automatically for every normal-profile life passing eligibility. Although it used the real service and did not inject debt or bypass gates, that action was still test-generated and violated the instruction not to force filings. The helper is now `_audit_bankruptcy_eligibility`: it records eligibility/source diagnostics only and never submits a filing. Earlier auto-file runs at $1.812m, $1.85m, and $1.90m are retained in the workspace as exploratory artifacts but are **not** accepted as natural filing-rate evidence and did not determine the final threshold.

At the requested $1.20m floor, the saved source-level diagnostic found 15 eligibility checks across 12 normal-profile lives. Every eligible balance was a standalone `living_expense` collection between 121,534,714¢ and 139,595,697¢; dischargeable loan balances and linked collection mirrors were zero; gross assets, annual surplus, and ten-year repayment capacity were zero. The old eligibility-triggered policy produced 12/60 (20%) filings, but that is a synthetic decision rate, not a natural player rate. Thus the $1.20m request remains **unmet**: it admits the diagnosed $1.215m–$1.396m unsecured arrears and failed the old 3–10% test under that action policy. The high $1.812m floor was chosen to make bankruptcy rare for ordinary players while preserving the strict insolvency, 2×-assets, liquid-funds/ten-year-surplus, two-year first-loan, secured-debt, and student-debt safeguards.

Under the corrected no-forced-action cohorts, actual filings were 0/60 in each 100-life seed and 0/300 in each final-size 500-life seed (0%, below the supplied 3–10% range). No threshold can make a life issue a user-facing filing command without modeling a player decision. The current threshold is therefore retained per direction, but the actual filing-rate target is marked FAIL in these no-action cohorts; that 0% is not an estimate of player filing propensity. We did not invent a decision probability or tune a cohort to force the target.

### 100-life no-forced-filing tuning cohorts (small-sample check)

Commands run: `LIFELINE_RUN_FULL_LIVES=1 LIFELINE_LIFE_COUNT=100 LIFELINE_SIMULATION_SEED=20261004 python -m pytest -q -s tests/test_full_lives.py` and `LIFELINE_RUN_FULL_LIVES=1 LIFELINE_LIFE_COUNT=100 LIFELINE_SIMULATION_SEED=20261005 python -m pytest -q -s tests/test_full_lives.py`. Both commands completed with one test passed; acceptance statuses are shown below and are independent of pytest's exit code.

| Acceptance target | Required range | Seed 20261004 (n=100) | Seed 20261005 (n=100) |
|---|---:|---:|---:|
| Normal median lifespan | 75–85 years | 82.5 — PASS | 80.5 — PASS |
| Heavy-crime median lifespan | 45–65 years | 48.5 — PASS | 66.5 — FAIL |
| Heavy-addiction median lifespan | 45–65 years | 46 — PASS | 52.5 — PASS |
| Normal lives reaching $1m peak net worth | 8–20% | 21.67% — FAIL | 20.00% — PASS |
| Normal lives reaching $1b peak net worth | <0.5% | 0% — PASS | 0% — PASS |
| Actual bankruptcy filing rate | 3–10% | 0/60 = 0% — FAIL | 0/60 = 0% — FAIL |
| College-graduate median final net worth | 25,000,000–150,000,000¢ | 98,031,477¢ — PASS | 79,170,182¢ — PASS |
| No-high-school median final net worth | 0–15,000,000¢ | No observations (n=0) — FAIL | No observations (n=0) — FAIL |
| Average-performer time to first promotion | 2–4 years | 3.5 — PASS | 3.0 — PASS |

The 100-life no-forced cohorts recorded 42 and 38 eligible-debt checks, respectively, but never called the filing service. The no-high-school subgroup contained zero lives in each smaller seed, so its median is not measurable there. General balance tuning was not reopened, per instruction.

### Final-size 500-life no-forced-filing validation

Commands run at the retained $1.812m floor: `LIFELINE_RUN_FULL_LIVES=1 LIFELINE_LIFE_COUNT=500 LIFELINE_SIMULATION_SEED=20261004 python -m pytest -q -s tests/test_full_lives.py` and `LIFELINE_RUN_FULL_LIVES=1 LIFELINE_LIFE_COUNT=500 LIFELINE_SIMULATION_SEED=20261005 python -m pytest -q -s tests/test_full_lives.py`. Each cohort completed with one pytest test passed. Acceptance outcomes:

| Acceptance target | Required range | Seed 20261004 (n=500) | Seed 20261005 (n=500) |
|---|---:|---:|---:|
| Normal median lifespan | 75–85 years | 79.0 — PASS | 79.5 — PASS |
| Heavy-crime median lifespan | 45–65 years | 58.0 — PASS | 53.0 — PASS |
| Heavy-addiction median lifespan | 45–65 years | 53.0 — PASS | 53.0 — PASS |
| Normal lives reaching $1m peak net worth | 8–20% | 20.33% — FAIL | 19.67% — PASS |
| Normal lives reaching $1b peak net worth | <0.5% | 0% — PASS | 0% — PASS |
| Actual bankruptcy filing rate | 3–10% | 0/300 = 0% — FAIL | 0/300 = 0% — FAIL |
| College-graduate median final net worth | 25,000,000–150,000,000¢ | 58,109,698.5¢ — PASS | 66,044,299¢ — PASS |
| No-high-school median final net worth | 0–15,000,000¢ | 0¢ (n=6) — PASS | 0¢ (n=7) — PASS |
| Average-performer time to first promotion | 2–4 years | 3 — PASS | 3 — PASS |

The final-size cohorts recorded 88 and 175 eligibility checks respectively, but no filing actions. Apart from the action-dependent 3–10% filing-rate target, seed 20261005 passes all nine criteria; seed 20261004 misses only the millionaire ceiling by 0.33 percentage points. Both final-size cohorts support retaining disease-onset multiplier `0.09` for the supplied lifespan bands.

### Verification results

| Check | Result | Status |
|---|---|---|
| `python -m pytest -q` | 228 passed, 1 skipped, 229 existing Discord deprecation warnings; 43.67s | PASS |
| Focused `tests/test_health.py tests/test_stage10_cog_loading.py` | 17 passed; plastic surgery, rollback, option choices, aliases, and exact command inventory covered | PASS |
| No-forced full-life seed 20261004, 100 lives | 1 pytest passed in 234.35s; small-sample statuses above | Harness PASS; target table includes FAILs |
| No-forced full-life seed 20261005, 100 lives | 1 pytest passed in 259.62s; small-sample statuses above | Harness PASS; target table includes FAILs |
| No-forced full-life seed 20261004, 500 lives | 1 pytest passed in 1075.47s; final-size statuses above | Harness PASS; filing-rate and millionaire targets FAIL |
| No-forced full-life seed 20261005, 500 lives | 1 pytest passed in 1060.14s; final-size statuses above | Harness PASS; filing-rate target FAIL |
| `python -m compileall -q bot.py cogs core tests tools` | Completed without syntax errors | PASS |
| `python tools/build_source_bundle.py` + `unzip -t` | 119 files; archive integrity passed; no logs, DBs, bytecode, or credentials included | PASS |
| Live Discord registration/sync | Not run; no token/test guild available | NOT RUN |

The earlier 500-life run and old candidate-threshold tables remain historical; the two additional final-size 500-life results above use the corrected no-forced-filing harness.
