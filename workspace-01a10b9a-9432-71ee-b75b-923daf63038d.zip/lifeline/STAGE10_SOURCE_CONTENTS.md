# Stage 10 source contents

End-of-stage contents for every file added or touched by the Stage 10 implementation and verification work. Each code block preserves the complete file text; the workspace files remain authoritative.

## `core/migrations/009_achievements_legacy.sql`

```sql
-- Stage 10: achievements, yearly life metrics, death archives, estates, and legacy.
ALTER TABLE players
    ADD COLUMN lives_lived INTEGER NOT NULL DEFAULT 0 CHECK (lives_lived >= 0);
ALTER TABLE players
    ADD COLUMN legacy_points INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players
    ADD COLUMN leaderboard_opt_out INTEGER NOT NULL DEFAULT 0 CHECK (leaderboard_opt_out IN (0, 1));
INSERT OR IGNORE INTO players(user_id, created_at)
    SELECT user_id, MIN(born_at) FROM characters GROUP BY user_id;

CREATE TABLE IF NOT EXISTS achievements_unlocked (
    user_id        INTEGER NOT NULL REFERENCES players(user_id) ON DELETE CASCADE,
    achievement_id TEXT NOT NULL,
    char_id        INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    unlocked_at    INTEGER NOT NULL CHECK (unlocked_at >= 0),
    PRIMARY KEY (user_id, achievement_id)
);
CREATE INDEX IF NOT EXISTS idx_achievements_character
    ON achievements_unlocked(char_id, unlocked_at DESC);

CREATE TABLE IF NOT EXISTS life_year_metrics (
    char_id               INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age                   INTEGER NOT NULL CHECK (age >= 0),
    happiness             INTEGER NOT NULL CHECK (happiness BETWEEN 0 AND 100),
    net_worth_cents       INTEGER NOT NULL,
    peak_net_worth_cents  INTEGER NOT NULL,
    served_prison_year    INTEGER NOT NULL DEFAULT 0 CHECK (served_prison_year IN (0, 1)),
    recorded_at           INTEGER NOT NULL CHECK (recorded_at >= 0),
    PRIMARY KEY (char_id, age)
);
CREATE INDEX IF NOT EXISTS idx_life_year_metrics_character_age
    ON life_year_metrics(char_id, age DESC);

CREATE TABLE IF NOT EXISTS marriage_history (
    marriage_history_id INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id             INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    spouse_npc_id       INTEGER,
    spouse_name         TEXT NOT NULL,
    start_age           INTEGER NOT NULL CHECK (start_age >= 0),
    end_age             INTEGER NOT NULL CHECK (end_age >= start_age),
    end_reason          TEXT NOT NULL CHECK (end_reason IN ('divorce', 'spouse_death', 'character_death', 'retirement')),
    created_at          INTEGER NOT NULL CHECK (created_at >= 0)
);
CREATE INDEX IF NOT EXISTS idx_marriage_history_character
    ON marriage_history(char_id, start_age, end_age);

CREATE TABLE IF NOT EXISTS past_lives (
    past_life_id             INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id                  INTEGER NOT NULL UNIQUE REFERENCES characters(char_id) ON DELETE RESTRICT,
    user_id                  INTEGER NOT NULL REFERENCES players(user_id) ON DELETE CASCADE,
    death_age                INTEGER NOT NULL CHECK (death_age >= 0),
    death_cause              TEXT NOT NULL,
    born_at                  INTEGER NOT NULL CHECK (born_at >= 0),
    died_at                  INTEGER NOT NULL CHECK (died_at >= 0),
    life_score               REAL NOT NULL,
    grade                    TEXT NOT NULL CHECK (grade IN ('S', 'A', 'B', 'C', 'D', 'F')),
    legacy_points            INTEGER NOT NULL,
    peak_net_worth_cents     INTEGER NOT NULL,
    final_net_worth_cents    INTEGER NOT NULL,
    gross_assets_cents       INTEGER NOT NULL CHECK (gross_assets_cents >= 0),
    debts_paid_cents         INTEGER NOT NULL CHECK (debts_paid_cents >= 0),
    estate_tax_cents         INTEGER NOT NULL CHECK (estate_tax_cents >= 0),
    estate_cents             INTEGER NOT NULL CHECK (estate_cents >= 0),
    unpaid_debt_cents        INTEGER NOT NULL CHECK (unpaid_debt_cents >= 0),
    abandoned                INTEGER NOT NULL DEFAULT 0 CHECK (abandoned IN (0, 1)),
    summary_json             TEXT NOT NULL,
    archived_at              INTEGER NOT NULL CHECK (archived_at >= 0)
);
CREATE INDEX IF NOT EXISTS idx_past_lives_user_archive
    ON past_lives(user_id, archived_at DESC, past_life_id DESC);
CREATE INDEX IF NOT EXISTS idx_past_lives_death
    ON past_lives(abandoned, archived_at DESC);
CREATE TRIGGER IF NOT EXISTS trg_past_lives_immutable_update
BEFORE UPDATE ON past_lives
BEGIN
    SELECT RAISE(ABORT, 'past_lives rows are immutable');
END;
CREATE TRIGGER IF NOT EXISTS trg_past_lives_immutable_delete
BEFORE DELETE ON past_lives
BEGIN
    SELECT RAISE(ABORT, 'past_lives rows are immutable');
END;

CREATE TABLE IF NOT EXISTS life_estates (
    estate_id           INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id             INTEGER NOT NULL UNIQUE REFERENCES past_lives(char_id) ON DELETE CASCADE,
    user_id             INTEGER NOT NULL REFERENCES players(user_id) ON DELETE CASCADE,
    estate_cents        INTEGER NOT NULL CHECK (estate_cents >= 0),
    nonce               TEXT NOT NULL UNIQUE,
    eligible_heirs_json TEXT NOT NULL,
    status              TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'claimed', 'closed')),
    selected_npc_id     INTEGER,
    created_at          INTEGER NOT NULL CHECK (created_at >= 0),
    resolved_at         INTEGER
);
CREATE INDEX IF NOT EXISTS idx_life_estates_user_status
    ON life_estates(user_id, status, created_at DESC);

CREATE TABLE IF NOT EXISTS retirement_prompts (
    prompt_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES players(user_id) ON DELETE CASCADE,
    char_id      INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    nonce        TEXT NOT NULL UNIQUE,
    status       TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'cancelled', 'expired')),
    created_at   INTEGER NOT NULL CHECK (created_at >= 0),
    expires_at   INTEGER NOT NULL CHECK (expires_at >= created_at),
    resolved_at  INTEGER
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_retirement_one_pending_per_user
    ON retirement_prompts(user_id) WHERE status = 'pending';

CREATE TABLE IF NOT EXISTS legacy_start_purchases (
    char_id        INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    user_id        INTEGER NOT NULL REFERENCES players(user_id) ON DELETE CASCADE,
    stat_name      TEXT NOT NULL CHECK (stat_name IN ('health', 'happiness', 'smarts', 'looks', 'fitness', 'karma')),
    purchase_count INTEGER NOT NULL CHECK (purchase_count BETWEEN 1 AND 2),
    points_spent   INTEGER NOT NULL CHECK (points_spent = purchase_count * 50),
    created_at     INTEGER NOT NULL CHECK (created_at >= 0)
);

CREATE TABLE IF NOT EXISTS guild_player_seen (
    guild_id      INTEGER NOT NULL CHECK (guild_id > 0),
    user_id       INTEGER NOT NULL REFERENCES players(user_id) ON DELETE CASCADE,
    last_seen_at  INTEGER NOT NULL CHECK (last_seen_at >= 0),
    PRIMARY KEY (guild_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_guild_player_seen_recent
    ON guild_player_seen(guild_id, last_seen_at DESC);

CREATE TABLE IF NOT EXISTS guild_stage10_settings (
    guild_id                INTEGER PRIMARY KEY CHECK (guild_id > 0),
    public_death_summaries  INTEGER NOT NULL DEFAULT 0 CHECK (public_death_summaries IN (0, 1)),
    updated_by              INTEGER NOT NULL CHECK (updated_by > 0),
    updated_at              INTEGER NOT NULL CHECK (updated_at >= 0)
);
```

## `data/achievements.json`

```json
{
  "schema_version": 1,
  "achievements": [
    {"id":"first_steps","name":"First Steps","description":"Reach your first birthday.","category":"longevity","rule":"age_at_least","threshold":1},
    {"id":"graduate","name":"Graduate","description":"Complete high school.","category":"education","rule":"education_at_least","threshold":"high_school"},
    {"id":"doctorate","name":"Doctorate","description":"Earn a doctorate.","category":"education","rule":"education_at_least","threshold":"doctorate"},
    {"id":"millionaire","name":"Millionaire","description":"Reach a lifetime net worth of $1 million.","category":"wealth","rule":"peak_net_worth_at_least","threshold":100000000},
    {"id":"billionaire","name":"Billionaire","description":"Reach a lifetime net worth of $1 billion.","category":"wealth","rule":"peak_net_worth_at_least","threshold":100000000000},
    {"id":"rags_to_riches","name":"Rags to Riches","description":"Be born poor and build a $10 million net worth.","category":"wealth","rule":"rags_to_riches","threshold":1000000000},
    {"id":"centenarian","name":"Centenarian","description":"Reach age 100.","category":"longevity","rule":"age_at_least","threshold":100},
    {"id":"married_50_years","name":"Married 50 Years","description":"Share at least fifty character-years of marriage.","category":"family","rule":"marriage_years_at_least","threshold":50},
    {"id":"big_family","name":"Big Family","description":"Raise or welcome five children.","category":"family","rule":"children_at_least","threshold":5},
    {"id":"jailbird","name":"Jailbird","description":"Serve at least one year in prison.","category":"crime","rule":"prison_years_at_least","threshold":1},
    {"id":"kingpin","name":"Kingpin","description":"Reach the highest criminal-career rank.","category":"crime","rule":"crime_level_at_least","threshold":5},
    {"id":"great_escape","name":"Great Escape","description":"Escape from prison.","category":"crime","rule":"escaped","threshold":1},
    {"id":"high_roller","name":"High Roller","description":"Place a casino wager of at least $100,000.","category":"wealth","rule":"max_bet_at_least","threshold":10000000},
    {"id":"jackpot","name":"Jackpot","description":"Win the lottery jackpot.","category":"wealth","rule":"jackpot","threshold":1},
    {"id":"bankrupt","name":"Bankrupt","description":"Finish a year with debts exceeding your assets.","category":"hardship","rule":"bankrupt","threshold":1},
    {"id":"serial_divorce","name":"Serial Divorcé","description":"Complete three divorces.","category":"family","rule":"divorces_at_least","threshold":3},
    {"id":"straight_a_student","name":"Straight-A Student","description":"Earn a recorded GPA of at least 3.8.","category":"education","rule":"gpa_at_least","threshold":3.8},
    {"id":"ceo","name":"CEO","description":"Reach the top level of a professional career.","category":"career","rule":"executive_role","threshold":1},
    {"id":"famous","name":"Famous","description":"Build fame to 80 or higher.","category":"career","rule":"fame_at_least","threshold":80},
    {"id":"lifelong_learner","name":"Lifelong Learner","description":"Complete twenty study actions.","category":"education","rule":"study_actions_at_least","threshold":20},
    {"id":"dynasty","name":"Dynasty","description":"Continue a family line into its fifth generation.","category":"family","rule":"generation_at_least","threshold":5},
    {"id":"died_young","name":"Died Young","description":"Complete a life before age 30.","category":"longevity","rule":"died_before_age","threshold":30},
    {"id":"clean_record_centenarian","name":"Clean Record Centenarian","description":"Reach 100 with no unsealed convictions.","category":"longevity","rule":"clean_centenarian","threshold":100},
    {"id":"early_bird","name":"Early Bird","description":"Reach age five.","category":"longevity","rule":"age_at_least","threshold":5},
    {"id":"coming_of_age","name":"Coming of Age","description":"Reach adulthood.","category":"longevity","rule":"age_at_least","threshold":18},
    {"id":"silver_years","name":"Silver Years","description":"Reach age 50.","category":"longevity","rule":"age_at_least","threshold":50},
    {"id":"three_quarters","name":"Three-Quarter Century","description":"Reach age 75.","category":"longevity","rule":"age_at_least","threshold":75},
    {"id":"primary_scholar","name":"Primary Scholar","description":"Complete primary education.","category":"education","rule":"education_at_least","threshold":"primary"},
    {"id":"bachelor_degree","name":"Bachelor's Degree","description":"Earn a bachelor's degree.","category":"education","rule":"education_at_least","threshold":"bachelor"},
    {"id":"masters_degree","name":"Master's Degree","description":"Earn a master's degree.","category":"education","rule":"education_at_least","threshold":"master"},
    {"id":"hard_studier","name":"Hard Studier","description":"Complete ten hard-study years.","category":"education","rule":"hard_study_actions_at_least","threshold":10},
    {"id":"honor_roll","name":"Honor Roll","description":"Reach a GPA of at least 3.5.","category":"education","rule":"gpa_at_least","threshold":3.5},
    {"id":"veteran_employee","name":"Veteran Employee","description":"Accumulate ten years in a career.","category":"career","rule":"career_years_at_least","threshold":10},
    {"id":"career_climber","name":"Career Climber","description":"Reach level two in a career.","category":"career","rule":"career_level_at_least","threshold":2},
    {"id":"career_legend","name":"Career Legend","description":"Reach the top level in a career.","category":"career","rule":"career_level_at_least","threshold":3},
    {"id":"career_hopper","name":"Career Hopper","description":"Build a history across three careers.","category":"career","rule":"career_count_at_least","threshold":3},
    {"id":"loyal_service","name":"Loyal Service","description":"Accumulate twenty years of employment.","category":"career","rule":"career_years_at_least","threshold":20},
    {"id":"entrepreneur","name":"Entrepreneur","description":"Own a business asset.","category":"wealth","rule":"business_asset","threshold":1},
    {"id":"homeowner","name":"Homeowner","description":"Own a home.","category":"wealth","rule":"homes_at_least","threshold":1},
    {"id":"property_mogul","name":"Property Mogul","description":"Own three homes at once.","category":"wealth","rule":"homes_at_least","threshold":3},
    {"id":"stock_owner","name":"Market Participant","description":"Own a listed or delisted share position.","category":"wealth","rule":"owns_stock","threshold":1},
    {"id":"market_regular","name":"Market Regular","description":"Complete twenty stock trades.","category":"wealth","rule":"stock_trades_at_least","threshold":20},
    {"id":"bond_maturity","name":"Patient Investor","description":"Hold a savings bond through maturity.","category":"wealth","rule":"matured_bond","threshold":1},
    {"id":"rental_income","name":"Landlord","description":"Record positive rental income.","category":"wealth","rule":"rental_income","threshold":1},
    {"id":"six_figure_fortune","name":"Six-Figure Fortune","description":"Reach a $10 million lifetime net worth.","category":"wealth","rule":"peak_net_worth_at_least","threshold":1000000000},
    {"id":"debt_free","name":"Debt Free","description":"End a life with no outstanding debt.","category":"hardship","rule":"debt_free","threshold":1},
    {"id":"first_child","name":"First Child","description":"Welcome a child into the family.","category":"family","rule":"children_at_least","threshold":1},
    {"id":"family_of_five","name":"Family of Five","description":"Welcome at least three children.","category":"family","rule":"children_at_least","threshold":3},
    {"id":"wedding_bells","name":"Wedding Bells","description":"Get married.","category":"family","rule":"marriages_at_least","threshold":1},
    {"id":"silver_anniversary","name":"Silver Anniversary","description":"Share at least twenty-five character-years of marriage.","category":"family","rule":"marriage_years_at_least","threshold":25},
    {"id":"prison_veteran","name":"Prison Veteran","description":"Serve five years in prison.","category":"crime","rule":"prison_years_at_least","threshold":5},
    {"id":"first_conviction","name":"First Conviction","description":"Receive an unsealed conviction.","category":"crime","rule":"convictions_at_least","threshold":1},
    {"id":"crime_boss","name":"Crime Boss","description":"Reach criminal-career level three.","category":"crime","rule":"crime_level_at_least","threshold":3},
    {"id":"clean_slate","name":"Clean Slate","description":"Finish with no unsealed convictions.","category":"crime","rule":"no_convictions","threshold":1},
    {"id":"third_generation","name":"Three Generations","description":"Live as a third-generation heir.","category":"family","rule":"generation_at_least","threshold":3},
    {"id":"life_completed","name":"Life Completed","description":"Archive a life through its natural end.","category":"completion","rule":"completed_life","threshold":1},
    {"id":"lucky_ticket","name":"Lucky Ticket","description":"Win any lottery prize.","category":"wealth","rule":"lottery_win","threshold":1},
    {"id":"blackjack_winner","name":"Blackjack Winner","description":"Win a settled blackjack hand.","category":"wealth","rule":"blackjack_wins_at_least","threshold":1},
    {"id":"casino_regular","name":"Casino Regular","description":"Complete twenty-five casino plays.","category":"wealth","rule":"casino_plays_at_least","threshold":25},
    {"id":"balanced_life","name":"Balanced Life","description":"Average at least 80 happiness across recorded years.","category":"longevity","rule":"average_happiness_at_least","threshold":80},
    {"id":"good_karma","name":"Good Karma","description":"Finish with karma of at least 80.","category":"hardship","rule":"karma_at_least","threshold":80},
    {"id":"recovery_journey","name":"Recovery Journey","description":"Use the gambling recovery program.","category":"recovery","rule":"rehab_used","threshold":1},
    {"id":"addiction_free","name":"Found Balance","description":"After gambling, bring addiction below ten.","category":"recovery","rule":"addiction_free_after_gambling","threshold":1},
    {"id":"curious_mind","name":"Curious Mind","description":"Complete five study actions.","category":"education","rule":"study_actions_at_least","threshold":5},
    {"id":"high_flyer","name":"High Flyer","description":"Hold a job paying at least $100,000 a year.","category":"career","rule":"salary_at_least","threshold":10000000},
    {"id":"family_provider","name":"Family Provider","description":"Raise at least two children.","category":"family","rule":"children_at_least","threshold":2},
    {"id":"asset_collector","name":"Asset Collector","description":"Own ten distinct item lots at once.","category":"wealth","rule":"asset_lots_at_least","threshold":10},
    {"id":"home_stretch","name":"Home Stretch","description":"Own two homes at once.","category":"wealth","rule":"homes_at_least","threshold":2},
    {"id":"executive_track","name":"Executive Track","description":"Reach a senior career level and lead by example.","category":"career","rule":"executive_role","threshold":1},
    {"id":"second_generation","name":"Family Continuity","description":"Continue a family as a second-generation heir.","category":"family","rule":"generation_at_least","threshold":2},
    {"id":"high_happiness","name":"Bright Outlook","description":"Reach happiness of at least 95.","category":"longevity","rule":"happiness_at_least","threshold":95},
    {"id":"fitness_goal","name":"Fit for Life","description":"Reach fitness of at least 90.","category":"longevity","rule":"fitness_at_least","threshold":90},
    {"id":"smarts_goal","name":"Sharp Mind","description":"Reach smarts of at least 90.","category":"education","rule":"smarts_at_least","threshold":90},
    {"id":"fame_builder","name":"Rising Star","description":"Build fame to at least 50.","category":"career","rule":"fame_at_least","threshold":50},
    {"id":"crime_survivor","name":"Second Chance","description":"Finish with no unsealed convictions after a criminal record was earned.","category":"recovery","rule":"crime_recovery","threshold":1},
    {"id":"study_streak","name":"Dedicated Student","description":"Complete ten study actions of any effort.","category":"education","rule":"study_actions_at_least","threshold":10},
    {"id":"marriage_count_two","name":"Love, Twice","description":"Have two recorded marriages.","category":"family","rule":"marriages_at_least","threshold":2},
    {"id":"three_careers","name":"Versatile Professional","description":"Reach level two in at least two distinct careers.","category":"career","rule":"multiple_careers_level_two","threshold":1},
    {"id":"gambling_volume","name":"Big Action","description":"Wager at least $1 million in total.","category":"wealth","rule":"total_gambled_at_least","threshold":100000000},
    {"id":"gambling_profit","name":"House Edge?","description":"Finish with positive net gambling results.","category":"wealth","rule":"gambling_net_positive","threshold":1},
    {"id":"financial_comeback","name":"Financial Comeback","description":"Recover from negative net worth to a positive lifetime peak.","category":"hardship","rule":"financial_comeback","threshold":1},
    {"id":"great_grand_life","name":"A Full Life","description":"Reach age 90.","category":"longevity","rule":"age_at_least","threshold":90}
  ]
}
```

## `core/data_loader.py`

```python
"""JSON game-data loading with schema validation and modification-time caching."""
from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any, Callable, Optional

from .validators import (
    validate_career_catalog,
    validate_crime_catalog,
    validate_event_catalog,
    validate_item_catalog,
    validate_stock_catalog,
    validate_gambling_ages,
    validate_achievement_catalog,
)


Validator = Callable[[Any], Any]


class DataLoader:
    """Load validated JSON files from the bot's ``data`` directory."""

    def __init__(self, data_dir: str | Path | None = None):
        self.data_dir = Path(data_dir) if data_dir is not None else Path(__file__).parent.parent / "data"
        self._cache: dict[str, tuple[int, Any]] = {}

    def load_json(self, filename: str, validator: Optional[Validator] = None) -> Any:
        """Read and validate a JSON file; cached copies are returned defensively."""
        if Path(filename).name != filename or not filename.endswith(".json"):
            raise ValueError("Game data filenames must be simple .json filenames")
        path = self.data_dir / filename
        try:
            modified_at = path.stat().st_mtime_ns
        except FileNotFoundError as exc:
            raise FileNotFoundError(f"Required game data file not found: {path}") from exc

        cached = self._cache.get(filename)
        if cached and cached[0] == modified_at:
            return copy.deepcopy(cached[1])

        try:
            with path.open("r", encoding="utf-8") as handle:
                document = json.load(handle)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON in {path} at line {exc.lineno}, column {exc.colno}: {exc.msg}") from exc

        validated = validator(document) if validator is not None else document
        self._cache[filename] = (modified_at, copy.deepcopy(validated))
        return copy.deepcopy(validated)

    def load_events(self) -> dict[str, Any]:
        """Load the validated life-event catalog."""
        return self.load_json("events.json", validate_event_catalog)

    def load_careers(self) -> dict[str, Any]:
        """Load the validated career catalog."""
        return self.load_json("careers.json", validate_career_catalog)

    def load_crimes(self) -> dict[str, Any]:
        """Load the fully validated crime and country-sentencing catalog."""
        return self.load_json("crimes.json", validate_crime_catalog)

    def load_items(self) -> dict[str, Any]:
        """Load the strictly validated Stage 8 shop and inventory catalog."""
        return self.load_json("items.json", validate_item_catalog)

    def load_stocks(self) -> dict[str, Any]:
        """Load the strictly validated Stage 9 global equity and crypto catalog."""
        return self.load_json("stocks.json", validate_stock_catalog)

    def load_achievements(self) -> dict[str, Any]:
        """Load the validated, finite Stage 10 achievement definitions."""
        return self.load_json("achievements.json", validate_achievement_catalog)

    def load_gambling_ages(self) -> dict[str, Any]:
        """Load country minimum ages with a validated age-18 fallback for unknown keys."""
        return self.load_json("gambling_ages.json", validate_gambling_ages)
```

## `core/validators.py`

```python
"""Strict validation for game data files loaded at runtime."""
from __future__ import annotations

import math
import re
from typing import Any


class DataValidationError(ValueError):
    """Raised when a bundled game-data document is malformed or unsafe."""


_EVENT_ID = re.compile(r"^[a-z][a-z0-9_]{0,39}$")
_ALLOWED_POLARITIES = {"positive", "negative", "neutral"}
_ALLOWED_WEALTH = {"poor", "working", "middle", "upper", "rich"}
_ALLOWED_STATS = {
    "health", "happiness", "smarts", "looks", "fitness", "karma",
    "stress", "addiction", "fame",
}


def _fail(path: str, message: str) -> None:
    raise DataValidationError(f"{path}: {message}")


def _string(value: Any, path: str, *, minimum: int, maximum: int) -> str:
    if not isinstance(value, str):
        _fail(path, "must be a string")
    clean = value.strip()
    if not minimum <= len(clean) <= maximum:
        _fail(path, f"length must be between {minimum} and {maximum}")
    if any(ord(char) < 32 or ord(char) == 127 for char in clean):
        _fail(path, "must not contain control characters")
    return clean


def _integer(value: Any, path: str, *, minimum: int, maximum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        _fail(path, "must be an integer")
    if not minimum <= value <= maximum:
        _fail(path, f"must be between {minimum} and {maximum}")
    return value


def validate_event_catalog(document: Any) -> dict[str, Any]:
    """Validate and return a version-1 life-event catalog.

    Expressions and executable conditions are intentionally unsupported: event
    effects are finite integer stat deltas, never ``eval``-ed code.
    """
    if not isinstance(document, dict):
        _fail("events", "document must be an object")
    if document.get("schema_version") != 1:
        _fail("schema_version", "only version 1 is supported")
    events = document.get("events")
    if not isinstance(events, list) or not 1 <= len(events) <= 500:
        _fail("events", "must contain between 1 and 500 event definitions")

    seen_event_ids: set[str] = set()
    for event_index, event in enumerate(events):
        path = f"events[{event_index}]"
        if not isinstance(event, dict):
            _fail(path, "must be an object")

        event_id = _string(event.get("id"), f"{path}.id", minimum=1, maximum=40)
        if not _EVENT_ID.fullmatch(event_id):
            _fail(f"{path}.id", "use lowercase letters, digits, and underscores")
        if event_id in seen_event_ids:
            _fail(f"{path}.id", "event IDs must be unique")
        seen_event_ids.add(event_id)

        _string(event.get("title"), f"{path}.title", minimum=1, maximum=100)
        _string(event.get("description"), f"{path}.description", minimum=1, maximum=1000)
        category = _string(event.get("category"), f"{path}.category", minimum=1, maximum=32)
        if not re.fullmatch(r"[a-z][a-z0-9_]*", category):
            _fail(f"{path}.category", "must be a lowercase category key")
        if event.get("polarity") not in _ALLOWED_POLARITIES:
            _fail(f"{path}.polarity", "must be positive, negative, or neutral")

        minimum_age = _integer(event.get("min_age"), f"{path}.min_age", minimum=0, maximum=120)
        maximum_age = _integer(event.get("max_age"), f"{path}.max_age", minimum=0, maximum=120)
        if minimum_age > maximum_age:
            _fail(path, "min_age cannot exceed max_age")

        weight = event.get("weight")
        if isinstance(weight, bool) or not isinstance(weight, (int, float)):
            _fail(f"{path}.weight", "must be a number")
        if not math.isfinite(float(weight)) or not 0 < float(weight) <= 1000:
            _fail(f"{path}.weight", "must be greater than 0 and at most 1000")

        repeatable = event.get("repeatable", False)
        if not isinstance(repeatable, bool):
            _fail(f"{path}.repeatable", "must be true or false")

        wealth_classes = event.get("wealth_classes", [])
        if not isinstance(wealth_classes, list) or any(
            not isinstance(value, str) or value not in _ALLOWED_WEALTH for value in wealth_classes
        ):
            _fail(f"{path}.wealth_classes", "must be a list of valid wealth-class keys")
        if len(set(wealth_classes)) != len(wealth_classes):
            _fail(f"{path}.wealth_classes", "values must be unique")

        countries = event.get("countries", [])
        if not isinstance(countries, list) or any(
            not isinstance(value, str) or not re.fullmatch(r"[a-z0-9_-]{2,40}", value)
            for value in countries
        ):
            _fail(f"{path}.countries", "must be a list of lowercase country/region keys")

        choices = event.get("choices")
        if not isinstance(choices, list) or not 2 <= len(choices) <= 4:
            _fail(f"{path}.choices", "must contain between 2 and 4 choices")
        seen_choice_ids: set[str] = set()
        for choice_index, choice in enumerate(choices):
            choice_path = f"{path}.choices[{choice_index}]"
            if not isinstance(choice, dict):
                _fail(choice_path, "must be an object")
            choice_id = _string(choice.get("id"), f"{choice_path}.id", minimum=1, maximum=32)
            if not _EVENT_ID.fullmatch(choice_id):
                _fail(f"{choice_path}.id", "use lowercase letters, digits, and underscores")
            if choice_id in seen_choice_ids:
                _fail(f"{choice_path}.id", "choice IDs must be unique within an event")
            seen_choice_ids.add(choice_id)
            _string(choice.get("label"), f"{choice_path}.label", minimum=1, maximum=80)
            description = choice.get("description", "")
            if description:
                _string(description, f"{choice_path}.description", minimum=1, maximum=250)

            effects = choice.get("effects", {})
            if not isinstance(effects, dict) or set(effects) - {"stats"}:
                _fail(f"{choice_path}.effects", "may contain only a stats object")
            stat_effects = effects.get("stats", {})
            if not isinstance(stat_effects, dict):
                _fail(f"{choice_path}.effects.stats", "must be an object")
            for stat_name, delta in stat_effects.items():
                if stat_name not in _ALLOWED_STATS:
                    _fail(f"{choice_path}.effects.stats.{stat_name}", "is not a mutable game stat")
                _integer(delta, f"{choice_path}.effects.stats.{stat_name}", minimum=-25, maximum=25)

    return document


def validate_career_catalog(document: Any) -> dict[str, Any]:
    """Validate a career catalog containing finite, positive integer-cent salaries."""
    if not isinstance(document, dict):
        _fail("careers", "document must be an object")
    if document.get("schema_version") != 1:
        _fail("schema_version", "only version 1 is supported")
    careers = document.get("careers")
    if not isinstance(careers, list) or not 1 <= len(careers) <= 100:
        _fail("careers", "must contain between 1 and 100 career definitions")

    allowed_education = {"none", "primary", "high_school", "bachelor", "master", "doctorate"}
    career_ids: set[str] = set()
    for index, career in enumerate(careers):
        path = f"careers[{index}]"
        if not isinstance(career, dict):
            _fail(path, "must be an object")
        career_id = _string(career.get("id"), f"{path}.id", minimum=1, maximum=40)
        if not _EVENT_ID.fullmatch(career_id):
            _fail(f"{path}.id", "use lowercase letters, digits, and underscores")
        if career_id in career_ids:
            _fail(f"{path}.id", "career IDs must be unique")
        career_ids.add(career_id)
        _string(career.get("name"), f"{path}.name", minimum=1, maximum=80)
        minimum_age = _integer(career.get("minimum_age"), f"{path}.minimum_age", minimum=14, maximum=80)
        retirement_age = _integer(career.get("retirement_age"), f"{path}.retirement_age", minimum=40, maximum=120)
        if retirement_age <= minimum_age:
            _fail(path, "retirement_age must be greater than minimum_age")
        if career.get("minimum_education") not in allowed_education:
            _fail(f"{path}.minimum_education", "must be a supported education level")
        _integer(career.get("minimum_smarts"), f"{path}.minimum_smarts", minimum=0, maximum=100)
        part_time_allowed = career.get("part_time_allowed", False)
        if not isinstance(part_time_allowed, bool):
            _fail(f"{path}.part_time_allowed", "must be true or false")
        multiplier = career.get("part_time_multiplier", 0.5)
        if isinstance(multiplier, bool) or not isinstance(multiplier, (int, float)):
            _fail(f"{path}.part_time_multiplier", "must be a number")
        if not math.isfinite(float(multiplier)) or not 0 < float(multiplier) <= 1:
            _fail(f"{path}.part_time_multiplier", "must be greater than 0 and at most 1")

        levels = career.get("levels")
        if not isinstance(levels, list) or not 2 <= len(levels) <= 8:
            _fail(f"{path}.levels", "must contain between 2 and 8 levels")
        for level_index, level in enumerate(levels):
            level_path = f"{path}.levels[{level_index}]"
            if not isinstance(level, dict):
                _fail(level_path, "must be an object")
            _string(level.get("title"), f"{level_path}.title", minimum=1, maximum=80)
            _integer(level.get("annual_salary"), f"{level_path}.annual_salary", minimum=1, maximum=10_000_000_000)
            _integer(level.get("promotion_years"), f"{level_path}.promotion_years", minimum=1, maximum=30)

    return document


def _validate_item_effects(value: Any, path: str, *, allow_flags: bool = False, allow_payout: bool = False) -> dict[str, Any]:
    """Validate a bounded, declarative item effect document."""
    if not isinstance(value, dict):
        _fail(path, "must be an object")
    allowed = {"stats"}
    if allow_flags:
        allowed.add("flags")
    if allow_payout:
        allowed.add("payout_range_cents")
    if set(value) - allowed:
        _fail(path, f"may contain only: {', '.join(sorted(allowed))}")
    stats = value.get("stats", {})
    if not isinstance(stats, dict):
        _fail(f"{path}.stats", "must be an object")
    for stat_name, delta in stats.items():
        if stat_name not in _ALLOWED_STATS:
            _fail(f"{path}.stats.{stat_name}", "is not a supported game stat")
        _integer(delta, f"{path}.stats.{stat_name}", minimum=-100, maximum=100)
    if allow_flags:
        flags = value.get("flags", {})
        if not isinstance(flags, dict) or set(flags) - {"has_license", "has_ged"}:
            _fail(f"{path}.flags", "may contain only supported character flags")
        for flag, enabled in flags.items():
            if not isinstance(enabled, bool):
                _fail(f"{path}.flags.{flag}", "must be true or false")
    if allow_payout and "payout_range_cents" in value:
        payout = value["payout_range_cents"]
        if not isinstance(payout, list) or len(payout) != 2:
            _fail(f"{path}.payout_range_cents", "must contain a minimum and maximum")
        minimum = _integer(payout[0], f"{path}.payout_range_cents[0]", minimum=0, maximum=9_000_000_000_000_000_000)
        maximum = _integer(payout[1], f"{path}.payout_range_cents[1]", minimum=minimum, maximum=9_000_000_000_000_000_000)
    return value


def validate_item_catalog(document: Any) -> dict[str, Any]:
    """Validate the full Stage 8 item catalog and its finite gameplay effects."""
    if not isinstance(document, dict):
        _fail("items", "document must be an object")
    if isinstance(document.get("schema_version"), bool) or document.get("schema_version") != 1:
        _fail("items.schema_version", "only version 1 is supported")
    if set(document) != {"schema_version", "items"}:
        _fail("items", "must contain exactly schema_version and items")
    items = document.get("items")
    if not isinstance(items, list) or not 60 <= len(items) <= 500:
        _fail("items", "must contain between 60 and 500 item definitions")
    categories = {
        "housing", "vehicle", "jewelry", "electronics", "health", "collectibles",
        "business", "pet", "weapon", "consumable", "license", "title", "leisure",
    }
    required = {
        "id", "name", "category", "base_price_cents", "min_age", "stackable",
        "max_quantity", "tradeable", "effects_on_buy", "effects_on_use", "yearly_effects",
        "yearly_upkeep_cents", "depreciation_rate_per_year", "market_volatility",
        "collateral_eligible", "consumable", "usable", "shop_available",
        "crime_event_only", "legal_countries",
    }
    seen: set[str] = set()
    for index, item in enumerate(items):
        path = f"items[{index}]"
        if not isinstance(item, dict):
            _fail(path, "must be an object")
        if set(item) != required:
            missing = required - set(item)
            extra = set(item) - required
            detail = []
            if missing:
                detail.append(f"missing {', '.join(sorted(missing))}")
            if extra:
                detail.append(f"unsupported {', '.join(sorted(extra))}")
            _fail(path, "; ".join(detail))
        item_id = _string(item.get("id"), f"{path}.id", minimum=1, maximum=40)
        if not _EVENT_ID.fullmatch(item_id) or item_id in seen:
            _fail(f"{path}.id", "must be unique and use lowercase letters, digits, and underscores")
        seen.add(item_id)
        _string(item.get("name"), f"{path}.name", minimum=1, maximum=80)
        if item.get("category") not in categories:
            _fail(f"{path}.category", "is not a supported shop category")
        _integer(item.get("base_price_cents"), f"{path}.base_price_cents", minimum=0, maximum=9_000_000_000_000_000_000)
        _integer(item.get("min_age"), f"{path}.min_age", minimum=0, maximum=120)
        stackable = item.get("stackable")
        if not isinstance(stackable, bool):
            _fail(f"{path}.stackable", "must be true or false")
        maximum = _integer(item.get("max_quantity"), f"{path}.max_quantity", minimum=1, maximum=999)
        if not stackable and maximum != 1:
            _fail(f"{path}.max_quantity", "non-stackable items must have max_quantity 1")
        for field in ("tradeable", "collateral_eligible", "consumable", "usable", "shop_available", "crime_event_only"):
            if not isinstance(item.get(field), bool):
                _fail(f"{path}.{field}", "must be true or false")
        if not isinstance(item.get("legal_countries"), list):
            _fail(f"{path}.legal_countries", "must be a list")
        legal_countries = item["legal_countries"]
        if any(
            not isinstance(country, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{1,39}", country)
            for country in legal_countries
        ):
            _fail(f"{path}.legal_countries", "must contain lowercase country codes")
        if len(set(legal_countries)) != len(legal_countries):
            _fail(f"{path}.legal_countries", "country codes must be unique")
        if item["crime_event_only"] and (item["shop_available"] or item["category"] != "weapon"):
            _fail(path, "crime-event-only items must be weapons and unavailable in /shop")
        if item["category"] == "weapon" and (not item["crime_event_only"] or not legal_countries or item["min_age"] < 18 or item["tradeable"]):
            _fail(path, "weapons must be nontradeable, crime-event-only, adult-gated items with country legality")
        if item["category"] in {"title", "license"} and item["tradeable"]:
            _fail(path, "titles and licenses cannot be traded")
        if item["category"] == "consumable" and not item["tradeable"]:
            _fail(path, "consumables must be tradeable")
        if item["base_price_cents"] == 0 and not (item["crime_event_only"] or not item["shop_available"]):
            _fail(f"{path}.base_price_cents", "zero-price items must be event-only or hidden")
        if item["collateral_eligible"] and item["category"] not in {"housing", "vehicle"}:
            _fail(f"{path}.collateral_eligible", "only housing and vehicles may secure loans")
        if item["category"] in {"housing", "vehicle"} and (not item["tradeable"] or not item["collateral_eligible"]):
            _fail(path, "housing and vehicles must be tradeable and collateral-eligible")
        if item["consumable"] and (not stackable or not item["usable"]):
            _fail(path, "consumables must be stackable and usable")
        _validate_item_effects(item["effects_on_buy"], f"{path}.effects_on_buy", allow_flags=True)
        _validate_item_effects(item["effects_on_use"], f"{path}.effects_on_use", allow_payout=True)
        yearly = item["yearly_effects"]
        if not isinstance(yearly, dict) or set(yearly) != {"stats", "income_cents"}:
            _fail(f"{path}.yearly_effects", "must contain stats and income_cents")
        _validate_item_effects({"stats": yearly["stats"]}, f"{path}.yearly_effects")
        _integer(yearly["income_cents"], f"{path}.yearly_effects.income_cents", minimum=0, maximum=9_000_000_000_000_000_000)
        _integer(item["yearly_upkeep_cents"], f"{path}.yearly_upkeep_cents", minimum=0, maximum=9_000_000_000_000_000_000)
        rate = item["depreciation_rate_per_year"]
        volatility = item["market_volatility"]
        for field, number in (("depreciation_rate_per_year", rate), ("market_volatility", volatility)):
            if isinstance(number, bool) or not isinstance(number, (int, float)) or not math.isfinite(float(number)):
                _fail(f"{path}.{field}", "must be a finite number")
        if not -0.95 <= float(rate) <= 0.95:
            _fail(f"{path}.depreciation_rate_per_year", "must be between -0.95 and 0.95")
        if not 0 <= float(volatility) <= 0.5:
            _fail(f"{path}.market_volatility", "must be between 0 and 0.5")
        if item["shop_available"] and item["crime_event_only"]:
            _fail(path, "crime-event-only items cannot be sold in /shop")
    return document


def validate_crime_catalog(document: Any) -> dict[str, Any]:
    """Validate the complete non-instructional crime catalog used at startup."""
    if not isinstance(document, dict):
        _fail("crimes", "document must be an object")
    if isinstance(document.get("schema_version"), bool) or document.get("schema_version") != 1:
        _fail("crimes.schema_version", "only version 1 is supported")
    allowed_top = {"schema_version", "crime_severity_mod", "crimes"}
    if set(document) != allowed_top:
        _fail("crimes", f"must contain exactly these keys: {', '.join(sorted(allowed_top))}")
    severity = document.get("crime_severity_mod")
    if not isinstance(severity, dict) or "default" not in severity:
        _fail("crimes.crime_severity_mod", "must be an object with a default modifier")
    for country, modifier in severity.items():
        _string(country, "crimes.crime_severity_mod key", minimum=2, maximum=40)
        if not re.fullmatch(r"[a-z][a-z0-9_]{1,39}", country):
            _fail("crimes.crime_severity_mod", "country keys must be lowercase codes")
        if isinstance(modifier, bool) or not isinstance(modifier, (int, float)):
            _fail(f"crimes.crime_severity_mod.{country}", "must be a number")
        if not math.isfinite(float(modifier)) or not 0.25 <= float(modifier) <= 3.0:
            _fail(f"crimes.crime_severity_mod.{country}", "must be between 0.25 and 3")
    crimes = document.get("crimes")
    if not isinstance(crimes, list) or len(crimes) < 14 or len(crimes) > 100:
        _fail("crimes", "must contain at least 14 and at most 100 crime definitions")
    seen: set[str] = set()
    has_event_only_tax = False
    for index, crime in enumerate(crimes):
        path = f"crimes[{index}]"
        if not isinstance(crime, dict):
            _fail(path, "must be an object")
        required_fields = {
            "id", "name", "description", "min_age", "base_success", "loot_min_dollars",
            "loot_max_dollars", "base_catch", "sentence_min", "sentence_max",
            "violence", "success_stat", "requires_job", "commit_enabled",
        }
        optional_fields = {
            "salary_loot_min_fraction", "salary_loot_max_fraction", "salary_loot_multiplier",
        }
        missing_fields = required_fields - set(crime)
        extra_fields = set(crime) - required_fields - optional_fields
        if missing_fields:
            _fail(path, f"missing required fields: {', '.join(sorted(missing_fields))}")
        if extra_fields:
            _fail(path, f"unsupported fields: {', '.join(sorted(extra_fields))}")
        crime_id = _string(crime.get("id"), f"{path}.id", minimum=1, maximum=40)
        if not _EVENT_ID.fullmatch(crime_id) or crime_id in seen:
            _fail(f"{path}.id", "must be unique and use lowercase letters, digits, and underscores")
        seen.add(crime_id)
        _string(crime.get("name"), f"{path}.name", minimum=1, maximum=80)
        _string(crime.get("description"), f"{path}.description", minimum=1, maximum=250)
        minimum_age = crime.get("min_age")
        if minimum_age is not None:
            _integer(minimum_age, f"{path}.min_age", minimum=0, maximum=120)
        enabled = crime.get("commit_enabled")
        if not isinstance(enabled, bool):
            _fail(f"{path}.commit_enabled", "must be true or false")
        for key in ("violence", "requires_job"):
            if not isinstance(crime.get(key), bool):
                _fail(f"{path}.{key}", "must be true or false")
        if crime.get("success_stat") not in {"none", "skill", "physical"}:
            _fail(f"{path}.success_stat", "must be none, skill, or physical")
        loot_min = _integer(crime.get("loot_min_dollars"), f"{path}.loot_min_dollars", minimum=0, maximum=10_000_000)
        loot_max = _integer(crime.get("loot_max_dollars"), f"{path}.loot_max_dollars", minimum=0, maximum=10_000_000)
        if loot_min > loot_max:
            _fail(path, "loot_min_dollars cannot exceed loot_max_dollars")
        sentence_min = _integer(crime.get("sentence_min"), f"{path}.sentence_min", minimum=0, maximum=120)
        sentence_max = crime.get("sentence_max")
        if sentence_max != "life":
            sentence_max = _integer(sentence_max, f"{path}.sentence_max", minimum=0, maximum=120)
            if sentence_min > sentence_max:
                _fail(path, "sentence_min cannot exceed sentence_max")
        if enabled:
            if minimum_age is None:
                _fail(f"{path}.min_age", "committable crimes require a minimum age")
            for key in ("base_success", "base_catch"):
                chance = crime.get(key)
                if isinstance(chance, bool) or not isinstance(chance, (int, float)):
                    _fail(f"{path}.{key}", "committable crimes require a numeric chance")
                if not math.isfinite(float(chance)) or not 0 <= float(chance) <= 100:
                    _fail(f"{path}.{key}", "must be between 0 and 100")
        else:
            if crime_id == "tax_evasion":
                has_event_only_tax = True
                if minimum_age != 18:
                    _fail(f"{path}.min_age", "tax_evasion is an adult-only event")
            if crime.get("base_success") is not None or crime.get("base_catch") is not None:
                _fail(path, "event-only crimes must not define commit chances")
        has_salary_range = "salary_loot_min_fraction" in crime or "salary_loot_max_fraction" in crime
        if "salary_loot_multiplier" in crime and not has_salary_range:
            _fail(path, "salary_loot_multiplier requires salary loot fractions")
        if crime["requires_job"] and not has_salary_range:
            _fail(path, "job-required crimes need salary loot fractions")
        if has_salary_range:
            for key in ("salary_loot_min_fraction", "salary_loot_max_fraction"):
                value = crime.get(key)
                if isinstance(value, bool) or not isinstance(value, (int, float)):
                    _fail(f"{path}.{key}", "must be a number")
                if not math.isfinite(float(value)) or not 0 <= float(value) <= 1:
                    _fail(f"{path}.{key}", "must be between 0 and 1")
            if crime["salary_loot_min_fraction"] > crime["salary_loot_max_fraction"]:
                _fail(path, "salary loot minimum fraction cannot exceed maximum fraction")
            _integer(crime.get("salary_loot_multiplier"), f"{path}.salary_loot_multiplier", minimum=1, maximum=10)
    if not has_event_only_tax:
        _fail("crimes", "must include event-only tax_evasion")
    return document


def validate_achievement_catalog(document: Any) -> dict[str, Any]:
    """Validate the finite, non-executable Stage 10 achievement catalog."""
    if not isinstance(document, dict) or set(document) != {"schema_version", "achievements"}:
        _fail("achievements", "must contain exactly schema_version and achievements")
    if isinstance(document.get("schema_version"), bool) or document.get("schema_version") != 1:
        _fail("achievements.schema_version", "only version 1 is supported")
    entries = document.get("achievements")
    if not isinstance(entries, list) or not 60 <= len(entries) <= 500:
        _fail("achievements", "must contain between 60 and 500 definitions")
    rules = {
        "age_at_least", "education_at_least", "peak_net_worth_at_least", "rags_to_riches",
        "marriage_years_at_least", "children_at_least", "prison_years_at_least",
        "convictions_at_least", "crime_level_at_least", "escaped", "max_bet_at_least", "jackpot", "bankrupt",
        "divorces_at_least", "gpa_at_least", "executive_role", "fame_at_least",
        "study_actions_at_least", "generation_at_least", "died_before_age",
        "clean_centenarian", "hard_study_actions_at_least", "career_years_at_least",
        "career_level_at_least", "career_count_at_least", "business_asset", "homes_at_least",
        "owns_stock", "stock_trades_at_least", "matured_bond", "rental_income",
        "debt_free", "marriages_at_least", "completed_life", "lottery_win",
        "blackjack_wins_at_least", "casino_plays_at_least", "average_happiness_at_least",
        "karma_at_least", "rehab_used", "addiction_free_after_gambling", "salary_at_least",
        "asset_lots_at_least", "happiness_at_least", "fitness_at_least", "smarts_at_least",
        "crime_recovery", "multiple_careers_level_two", "total_gambled_at_least",
        "gambling_net_positive", "financial_comeback", "no_convictions",
    }
    categories = {"longevity", "education", "wealth", "family", "crime", "hardship", "career", "recovery", "completion"}
    education_levels = {"none", "primary", "high_school", "bachelor", "master", "doctorate"}
    seen: set[str] = set()
    for index, entry in enumerate(entries):
        path = f"achievements[{index}]"
        required = {"id", "name", "description", "category", "rule", "threshold"}
        if not isinstance(entry, dict) or set(entry) != required:
            _fail(path, "must contain exactly id, name, description, category, rule, and threshold")
        identifier = _string(entry.get("id"), f"{path}.id", minimum=2, maximum=48)
        if not re.fullmatch(r"[a-z][a-z0-9_]{1,47}", identifier) or identifier in seen:
            _fail(f"{path}.id", "must be unique lowercase letters, digits, and underscores")
        seen.add(identifier)
        _string(entry.get("name"), f"{path}.name", minimum=1, maximum=80)
        _string(entry.get("description"), f"{path}.description", minimum=1, maximum=240)
        if entry.get("category") not in categories:
            _fail(f"{path}.category", "is not a supported achievement category")
        if entry.get("rule") not in rules:
            _fail(f"{path}.rule", "is not an implemented authoritative achievement rule")
        threshold = entry.get("threshold")
        if entry["rule"] == "education_at_least":
            if not isinstance(threshold, str) or threshold not in education_levels:
                _fail(f"{path}.threshold", "must be a supported education level")
        elif entry["rule"] == "gpa_at_least":
            if isinstance(threshold, bool) or not isinstance(threshold, (int, float)) or not math.isfinite(float(threshold)) or not 0 <= float(threshold) <= 4:
                _fail(f"{path}.threshold", "must be a finite GPA from 0 to 4")
        else:
            _integer(threshold, f"{path}.threshold", minimum=0, maximum=9_000_000_000_000_000_000)
    if len(seen) < 60:
        _fail("achievements", "must define at least 60 unique achievements")
    return document


def validate_gambling_ages(document: Any) -> dict[str, Any]:
    """Validate country-keyed fictional minimum ages and a safe fallback."""
    if not isinstance(document, dict) or set(document) != {"schema_version", "default_age", "countries"}:
        _fail("gambling_ages", "must contain exactly schema_version, default_age, and countries")
    if isinstance(document.get("schema_version"), bool) or document.get("schema_version") != 1:
        _fail("gambling_ages.schema_version", "only version 1 is supported")
    _integer(document.get("default_age"), "gambling_ages.default_age", minimum=18, maximum=25)
    countries = document.get("countries")
    if not isinstance(countries, dict) or not countries:
        _fail("gambling_ages.countries", "must be a non-empty country-to-age object")
    for country, age in countries.items():
        if not isinstance(country, str) or not re.fullmatch(r"[a-z][a-z0-9_]{1,39}", country):
            _fail("gambling_ages.countries", "keys must be lowercase country/region codes")
        _integer(age, f"gambling_ages.countries.{country}", minimum=18, maximum=25)
    return document


def validate_stock_catalog(document: Any) -> dict[str, Any]:
    """Validate at least twelve fictional public companies and their GBM inputs."""
    if not isinstance(document, dict) or set(document) != {"schema_version", "stocks"}:
        _fail("stocks", "must contain exactly schema_version and stocks")
    if isinstance(document.get("schema_version"), bool) or document.get("schema_version") != 1:
        _fail("stocks.schema_version", "only version 1 is supported")
    stocks = document.get("stocks")
    if not isinstance(stocks, list) or not 12 <= len(stocks) <= 500:
        _fail("stocks", "must contain between 12 and 500 definitions")
    required = {"symbol", "name", "sector", "initial_price_cents", "drift", "volatility"}
    allowed_sectors = {"tech", "energy", "health", "finance", "consumer", "crypto"}
    symbols: set[str] = set()
    sectors: set[str] = set()
    hypercoin_seen = False
    for index, stock in enumerate(stocks):
        path = f"stocks[{index}]"
        if not isinstance(stock, dict) or set(stock) != required:
            _fail(path, "must contain exactly symbol, name, sector, initial_price_cents, drift, and volatility")
        symbol = _string(stock.get("symbol"), f"{path}.symbol", minimum=1, maximum=8)
        if not re.fullmatch(r"[A-Z][A-Z0-9]{0,7}", symbol) or symbol in symbols:
            _fail(f"{path}.symbol", "must be unique uppercase letters/digits")
        symbols.add(symbol)
        _string(stock.get("name"), f"{path}.name", minimum=2, maximum=80)
        sector = stock.get("sector")
        if sector not in allowed_sectors:
            _fail(f"{path}.sector", "is not a supported fictional market sector")
        sectors.add(str(sector))
        _integer(stock.get("initial_price_cents"), f"{path}.initial_price_cents", minimum=1, maximum=9_000_000_000_000_000_000)
        for field in ("drift", "volatility"):
            value = stock.get(field)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(float(value)):
                _fail(f"{path}.{field}", "must be a finite number")
        if not -1.0 <= float(stock["drift"]) <= 1.0:
            _fail(f"{path}.drift", "must be between -1 and 1")
        if not 0.01 <= float(stock["volatility"]) <= 2.5:
            _fail(f"{path}.volatility", "must be between 0.01 and 2.5")
        if symbol == "HYPER":
            hypercoin_seen = True
            if stock["name"] != "HyperCoin" or sector != "crypto" or float(stock["volatility"]) < 1.0:
                _fail(path, "HYPER must be the high-volatility crypto-like HyperCoin")
    if not {"tech", "energy", "health", "finance", "consumer"}.issubset(sectors):
        _fail("stocks", "must cover tech, energy, health, finance, and consumer sectors")
    if not hypercoin_seen:
        _fail("stocks", "must include the HyperCoin symbol HYPER")
    return document
```

## `core/achievements.py`

```python
"""Authoritative Stage 10 achievement evaluation and idempotent unlocks."""
from __future__ import annotations

import json
import time
from typing import Any, Callable, Optional

import aiosqlite

from .data_loader import DataLoader
from .locks import UserLockRegistry
from .models import Character, EducationLevel
from .repositories.legacy import LegacyRepository

_EDUCATION_RANK = {
    EducationLevel.NONE.value: 0,
    EducationLevel.PRIMARY.value: 1,
    EducationLevel.HIGH_SCHOOL.value: 2,
    EducationLevel.BACHELOR.value: 3,
    EducationLevel.MASTER.value: 4,
    EducationLevel.DOCTORATE.value: 5,
}


class AchievementService:
    """Evaluate validated rules only from persisted game records and character state."""

    def __init__(
        self,
        db: Any,
        locks: Optional[UserLockRegistry] = None,
        *,
        clock: Callable[[], float] = time.time,
        data_loader: Optional[DataLoader] = None,
    ) -> None:
        self.db = db
        self.locks = locks or UserLockRegistry()
        self.clock = clock
        self.repository = LegacyRepository(db)
        loader = data_loader or DataLoader()
        self.definitions = tuple(loader.load_achievements()["achievements"])
        self.items = {str(row["id"]): dict(row) for row in loader.load_items()["items"]}
        self._pending_notifications: dict[int, list[dict[str, Any]]] = {}

    async def check_user(
        self, user_id: int, *, now: Optional[int] = None, guild_id: Optional[int] = None
    ) -> list[dict[str, Any]]:
        """Recompute all eligible unlocks from the user's authoritative database state."""
        timestamp = int(self.clock()) if now is None else int(now)
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                unlocked = await self.check_user_in_tx(
                    tx, user_id, now=timestamp, guild_id=guild_id
                )
        self.queue_notifications(user_id, unlocked)
        return unlocked

    async def check_user_in_tx(
        self,
        tx: aiosqlite.Connection,
        user_id: int,
        *,
        now: Optional[int] = None,
        guild_id: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """Unlock achievements inside an existing tick/action transaction, exactly once."""
        timestamp = int(self.clock()) if now is None else int(now)
        await self.repository.ensure_player(tx, user_id, timestamp)
        if guild_id is not None and guild_id > 0:
            await self.repository.record_guild_seen(tx, guild_id, user_id, timestamp)
        active = await self.repository.active_character(tx, user_id)
        if active is not None:
            character = Character.from_dict(json.loads(active["data_json"]))
            await self.repository.record_life_year(
                tx, character=character, age=character.age,
                served_prison_year=False, now=timestamp,
            )
        rows = await self.repository.user_character_rows(tx, user_id)
        rows.sort(key=lambda row: (not bool(row["is_alive"]), -int(row["char_id"])))
        unlocked: list[dict[str, Any]] = []
        for row in rows:
            character = Character.from_dict(json.loads(row["data_json"]))
            character.char_id = int(row["char_id"])
            character.user_id = int(row["user_id"])
            facts = await self._facts(tx, character)
            for definition in self.definitions:
                if not self._matches(definition, facts):
                    continue
                inserted = await self.repository.insert_achievement(
                    tx,
                    user_id=user_id,
                    achievement_id=str(definition["id"]),
                    char_id=character.char_id,
                    now=timestamp,
                )
                if inserted:
                    unlocked.append({**definition, "char_id": character.char_id})
        return unlocked

    def queue_notifications(self, user_id: int, achievements: list[dict[str, Any]] | tuple[dict[str, Any], ...]) -> None:
        """Queue committed unlocks for delivery by the next interaction response."""
        if achievements:
            self._pending_notifications.setdefault(int(user_id), []).extend(
                dict(row) for row in achievements
            )

    def consume_notifications(self, user_id: int) -> list[dict[str, Any]]:
        """Return and remove achievements waiting for the next interaction response."""
        return self._pending_notifications.pop(user_id, [])

    async def list_for_user(self, user_id: int, *, now: Optional[int] = None) -> list[dict[str, Any]]:
        """Return unlocked achievements with catalog descriptions and character names."""
        await self.check_user(user_id, now=now)
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                rows = await self.repository.user_achievements(tx, user_id)
        definitions = {str(row["id"]): row for row in self.definitions}
        result: list[dict[str, Any]] = []
        for row in rows:
            definition = definitions.get(str(row["achievement_id"]))
            if definition is not None:
                result.append({**definition, **row})
        return result

    async def _facts(self, tx: aiosqlite.Connection, character: Character) -> dict[str, Any]:
        """Derive one life's eligibility facts from persisted records, never caller input."""
        char_id = character.char_id
        economy = await self.repository.economy_snapshot(tx, char_id)
        metrics = await self.repository.life_year_metrics(tx, char_id)
        peak = max(
            [economy["net_worth_cents"]]
            + [int(row["peak_net_worth_cents"]) for row in metrics]
        )
        average_happiness = (
            sum(int(row["happiness"]) for row in metrics) / len(metrics) if metrics else float(character.stats.happiness)
        )
        min_historical_worth = min(
            [economy["net_worth_cents"]] + [int(row["net_worth_cents"]) for row in metrics]
        )
        children = await self.repository.child_count(tx, char_id)
        marriage_count = await self.repository.marriage_count(tx, char_id)
        marriage_years = await self.repository.max_marriage_years(tx, char_id, character.age)
        divorces = await self.repository.divorce_count(tx, char_id)
        education = await self.repository.education_rows(tx, char_id)
        education_rank = _EDUCATION_RANK.get(character.education_level.value, 0)
        max_gpa = max(float(character.gpa or 0.0), float(education["max_gpa"]))
        careers = await self.repository.career_history(tx, char_id)
        job = await self.repository.active_job(tx, char_id)
        career_level = max(
            [int(row["max_level"]) for row in careers]
            + ([int(job["level"])] if job is not None else [0])
        )
        career_count = len(careers)
        career_years = 0
        for history in careers:
            if history["end_age"] is not None:
                career_years += max(0, int(history["end_age"]) - int(history["start_age"]))
            elif job is not None:
                career_years += max(0, int(job["years_in_career"]))
        if job is not None and not careers:
            career_years += max(0, int(job["years_in_career"]))
        level_two_careers = sum(1 for row in careers if int(row["max_level"]) >= 2)
        crime = await self.repository.crime_summary(tx, char_id)
        tracking = await self.repository.stats_tracking(tx, char_id)
        casino_rows = await self.repository.casino_rows(tx, char_id)
        settled_casino: list[dict[str, Any]] = []
        max_bet = 0
        jackpot = False
        lottery_win = False
        blackjack_wins = 0
        for row in casino_rows:
            if str(row["status"]) != "settled":
                continue
            settled_casino.append(row)
            max_bet = max(max_bet, int(row["bet_cents"]))
            try:
                outcome = json.loads(str(row["outcome_json"]))
            except (TypeError, json.JSONDecodeError):
                outcome = {}
            if str(row["game"]) == "lottery":
                if outcome.get("tier") == "jackpot":
                    jackpot = True
                if int(row["payout_cents"] or 0) > 0:
                    lottery_win = True
            if str(row["game"]) == "blackjack":
                result = str(outcome.get("result", "")).lower()
                if result in {"player wins", "natural blackjack pays 3:2"} or "natural blackjack" in result:
                    blackjack_wins += 1
        investment = await self.repository.investment_rows(tx, char_id)
        item_facts = await self.repository.item_facts(tx, char_id)
        item_ids = [str(row["item_id"]) for row in item_facts["item_rows"]]
        categories = {
            self.items[item_id]["category"]
            for item_id in item_ids if item_id in self.items
        }
        home_count = sum(
            1 for row in item_facts["item_rows"]
            if row["item_id"] in self.items and self.items[str(row["item_id"])]["category"] == "housing"
        )
        profiles = crime["profile"]
        past = await self.repository.past_life(tx, char_id)
        completed_naturally = (past is not None and not bool(past["abandoned"])) or (
            not character.is_alive and character.death_cause != "Life abandoned"
        )
        bankrupted = economy["debts_cents"] > economy["gross_assets_cents"] or min_historical_worth < 0
        clean_record = int(crime["convictions"]) == 0
        return {
            "age": character.age,
            "death_age": character.death_age,
            "is_alive": character.is_alive,
            "natural_death": (past is not None and not bool(past["abandoned"])) or (
                not character.is_alive and character.death_cause != "Life abandoned"
            ),
            "education_rank": education_rank,
            "education_level": character.education_level.value,
            "peak_net_worth_cents": peak,
            "net_worth_cents": economy["net_worth_cents"],
            "born_poor": character.wealth_class.lower() == "poor",
            "children": children,
            "marriage_count": marriage_count,
            "marriage_years": marriage_years,
            "prison_years": int(crime["years_in_prison"]),
            "crime_level": max(0, int(profiles.get("career_level", 0))),
            "escaped": crime["escaped"],
            "convictions": int(crime["convictions"]),
            "sealed_convictions": int(crime["sealed_convictions"]),
            "successes": int(crime["successes"]),
            "max_bet_cents": max_bet,
            "jackpot": jackpot,
            "bankrupt": bankrupted,
            "divorces": divorces,
            "max_gpa": max_gpa,
            "career_level": career_level,
            "executive_role": career_level >= 3,
            "career_count": career_count,
            "career_years": career_years,
            "level_two_careers": level_two_careers,
            "fame": character.stats.fame,
            "study_actions": int(education["study_actions"]),
            "hard_study_actions": int(education["hard_study_actions"]),
            "generation": character.generation,
            "clean_centenarian": character.age >= 100 and clean_record,
            "business_asset": "business" in categories,
            "homes": home_count,
            "owns_stock": int(investment["share_count"]) > 0 or any(
                str(row["item_id"]).startswith("stock_") for row in item_facts["item_rows"]
            ),
            "stock_trades": int(investment["trade_count"]),
            "matured_bond": int(investment["matured_bonds"]) > 0,
            "rental_income": int(investment["rental_income_cents"]) > 0,
            "debt_free": economy["debts_cents"] == 0,
            "completed_life": completed_naturally,
            "lottery_win": lottery_win,
            "blackjack_wins": blackjack_wins,
            "casino_plays": len(settled_casino),
            "average_happiness": average_happiness,
            "karma": character.stats.karma,
            "rehab_used": await self.repository.rehab_used(tx, char_id),
            "addiction_free_after_gambling": character.stats.addiction < 10 and tracking["total_gambled"] > 0,
            "salary_cents": int(job["salary"]) if job is not None else 0,
            "asset_lots": int(item_facts["asset_lots"]),
            "happiness": character.stats.happiness,
            "fitness": character.stats.fitness,
            "smarts": character.stats.smarts,
            "crime_recovery": int(crime["sealed_convictions"]) > 0 and clean_record,
            "total_gambled": int(tracking["total_gambled"]),
            "gambling_net": int(tracking["total_gambling_net"]),
            "financial_comeback": min_historical_worth < 0 and peak > 0,
            "no_convictions": clean_record,
        }

    @staticmethod
    def _matches(definition: dict[str, Any], facts: dict[str, Any]) -> bool:
        """Evaluate one validated rule against server-derived life facts."""
        rule = str(definition["rule"])
        target = definition["threshold"]
        if rule == "age_at_least":
            return facts["age"] >= target
        if rule == "education_at_least":
            return facts["education_rank"] >= _EDUCATION_RANK[str(target)]
        if rule == "peak_net_worth_at_least":
            return facts["peak_net_worth_cents"] >= target
        if rule == "rags_to_riches":
            return facts["born_poor"] and facts["peak_net_worth_cents"] >= target
        if rule == "marriage_years_at_least":
            return facts["marriage_years"] >= target
        if rule == "children_at_least":
            return facts["children"] >= target
        if rule == "prison_years_at_least":
            return facts["prison_years"] >= target
        if rule == "convictions_at_least":
            return facts["convictions"] >= target
        if rule == "crime_level_at_least":
            return facts["crime_level"] >= target
        if rule == "escaped":
            return bool(facts["escaped"])
        if rule == "max_bet_at_least":
            return facts["max_bet_cents"] >= target
        if rule == "jackpot":
            return bool(facts["jackpot"])
        if rule == "bankrupt":
            return bool(facts["bankrupt"])
        if rule == "divorces_at_least":
            return facts["divorces"] >= target
        if rule == "gpa_at_least":
            return facts["max_gpa"] >= float(target)
        if rule == "executive_role":
            return bool(facts["executive_role"])
        if rule == "fame_at_least":
            return facts["fame"] >= target
        if rule == "study_actions_at_least":
            return facts["study_actions"] >= target
        if rule == "generation_at_least":
            return facts["generation"] >= target
        if rule == "died_before_age":
            return bool(
                facts["natural_death"] and facts["death_age"] is not None
                and not facts["is_alive"] and int(facts["death_age"]) < target
            )
        if rule == "clean_centenarian":
            return bool(facts["clean_centenarian"])
        if rule == "hard_study_actions_at_least":
            return facts["hard_study_actions"] >= target
        if rule == "career_years_at_least":
            return facts["career_years"] >= target
        if rule == "career_level_at_least":
            return facts["career_level"] >= target
        if rule == "career_count_at_least":
            return facts["career_count"] >= target
        if rule == "business_asset":
            return bool(facts["business_asset"])
        if rule == "homes_at_least":
            return facts["homes"] >= target
        if rule == "owns_stock":
            return bool(facts["owns_stock"])
        if rule == "stock_trades_at_least":
            return facts["stock_trades"] >= target
        if rule == "matured_bond":
            return bool(facts["matured_bond"])
        if rule == "rental_income":
            return bool(facts["rental_income"])
        if rule == "debt_free":
            return bool(facts["debt_free"])
        if rule == "marriages_at_least":
            return facts["marriage_count"] >= target
        if rule == "completed_life":
            return bool(facts["completed_life"])
        if rule == "lottery_win":
            return bool(facts["lottery_win"])
        if rule == "blackjack_wins_at_least":
            return facts["blackjack_wins"] >= target
        if rule == "casino_plays_at_least":
            return facts["casino_plays"] >= target
        if rule == "average_happiness_at_least":
            return facts["average_happiness"] >= target
        if rule == "karma_at_least":
            return facts["karma"] >= target
        if rule == "rehab_used":
            return bool(facts["rehab_used"])
        if rule == "addiction_free_after_gambling":
            return bool(facts["addiction_free_after_gambling"])
        if rule == "salary_at_least":
            return facts["salary_cents"] >= target
        if rule == "asset_lots_at_least":
            return facts["asset_lots"] >= target
        if rule == "happiness_at_least":
            return facts["happiness"] >= target
        if rule == "fitness_at_least":
            return facts["fitness"] >= target
        if rule == "smarts_at_least":
            return facts["smarts"] >= target
        if rule == "crime_recovery":
            return bool(facts["crime_recovery"])
        if rule == "multiple_careers_level_two":
            return facts["level_two_careers"] >= 2
        if rule == "total_gambled_at_least":
            return facts["total_gambled"] >= target
        if rule == "gambling_net_positive":
            return facts["gambling_net"] > 0
        if rule == "financial_comeback":
            return bool(facts["financial_comeback"])
        if rule == "no_convictions":
            return bool(facts["no_convictions"])
        raise ValueError(f"Achievement rule was not implemented: {rule}")
```

## `core/death.py`

```python
"""Exactly-once death archiving, life scoring, epitaphs, and estate settlement."""
from __future__ import annotations

import hashlib
import json
import math
import secrets
import time
from dataclasses import dataclass, replace
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_HALF_UP
from typing import Any, Callable, Optional

import aiosqlite

from .achievements import AchievementService
from .errors import CharacterAlreadyExists, CharacterDead, CharacterNotFound, ConcurrentUpdate, ValidationError
from .family import FamilyService
from .crime import CrimeService
from .casino import CasinoService
from .locks import UserLockRegistry
from .models import Character, EducationLevel, Gender, Stats
from .money import dollars_to_cents, format_cents, scale_cents
from .repositories.legacy import LegacyRepository


GRADE_CUTOFFS: tuple[tuple[float, str], ...] = (
    (90.0, "S"),
    (80.0, "A"),
    (70.0, "B"),
    (55.0, "C"),
    (40.0, "D"),
    (0.0, "F"),
)
_EDUCATION_RANK = {
    EducationLevel.NONE.value: 0,
    EducationLevel.PRIMARY.value: 1,
    EducationLevel.HIGH_SCHOOL.value: 2,
    EducationLevel.BACHELOR.value: 3,
    EducationLevel.MASTER.value: 4,
    EducationLevel.DOCTORATE.value: 5,
}

# Templates are selected by ordered, objective conditions and a stable character-ID index.
_EPITAPHS: dict[str, tuple[str, ...]] = {
    "abandoned": (
        "Their chapter ended by choice, with room for a new beginning.",
        "They closed this chapter and carried their story forward.",
        "A life set aside is still a story worth remembering.",
    ),
    "century": (
        "A century of stories ended; the stories remain.",
        "One hundred years, countless small kindnesses, and a life well remembered.",
        "They crossed a century with curiosity and heart.",
        "The years were many; the memories are more.",
    ),
    "family": (
        "Their family carries forward the warmth they gave.",
        "A generous home was built around them.",
        "They left a family tree full of new branches.",
        "Love was the inheritance they gave first.",
    ),
    "long_marriage": (
        "A long partnership made a home of the passing years.",
        "They shared the ordinary days, and made them matter.",
        "Two lives walked side by side for many seasons.",
    ),
    "education": (
        "They kept asking questions, and kept finding new doors.",
        "Learning was a lifelong companion.",
        "Their curiosity outlived every lesson.",
    ),
    "career": (
        "Their steady work helped shape the lives around them.",
        "They built a vocation with patience and care.",
        "Their craft was remembered by those who learned from them.",
    ),
    "crime_recovery": (
        "Their hardest chapter did not define the whole story.",
        "They found a steadier path, one choice at a time.",
        "A second chance became part of their legacy.",
    ),
    "crime": (
        "Their life held difficult choices and hard-won lessons.",
        "The record remembers the deeds; the people remember the person.",
        "Their story was more complicated than any single chapter.",
    ),
    "illness": (
        "Remembered for more than the illness that ended their life.",
        "Care and compassion stayed with them through difficult days.",
        "Their life was larger than its final challenge.",
    ),
    "hardship": (
        "They met lean years with grit and kept looking ahead.",
        "Setbacks were chapters, not the whole book.",
        "They found strength in beginning again.",
    ),
    "wealth": (
        "They made something lasting from what they were given.",
        "Their success was measured in more than money.",
        "They built a life with purpose and room to share.",
    ),
    "long_life": (
        "A long life, remembered in many small moments.",
        "They stayed curious through many changing seasons.",
        "The years were full of stories worth retelling.",
    ),
    "young": (
        "Their story was brief, but their place in it was lasting.",
        "A life is not measured only by the number of years.",
        "They were loved, and they will be remembered.",
    ),
    "general": (
        "Their story lives on in the people they touched.",
        "Remembered with warmth, laughter, and care.",
        "A life of many chapters, held close by those who knew them.",
        "They made a difference in ways both large and quiet.",
        "Their name remains in the stories shared by friends and family.",
    ),
}


@dataclass(frozen=True, slots=True)
class EstateSettlement:
    """Integer-cent estate result after debt payment and estate tax."""

    gross_assets_cents: int
    debts_due_cents: int
    debts_paid_cents: int
    unpaid_debt_cents: int
    taxable_threshold_cents: int
    estate_tax_cents: int
    estate_cents: int


@dataclass(frozen=True, slots=True)
class DeathResult:
    """Archived death summary and optional owner-bound heir menu payload."""

    summary: dict[str, Any]
    estate_id: Optional[int]
    estate_nonce: Optional[str]
    heirs: tuple[dict[str, Any], ...]
    public_summary: bool
    unlocked_achievements: tuple[dict[str, Any], ...] = ()


@dataclass(frozen=True, slots=True)
class RetirementPrompt:
    """One-time owner-bound retirement confirmation details."""

    prompt_id: int
    nonce: str
    expires_at: int


@dataclass(frozen=True, slots=True)
class RetirementResult:
    """Result of an accepted retirement confirmation."""

    summary: dict[str, Any]
    public_summary: bool = False


def calculate_life_score(
    *,
    age: int,
    average_happiness: float,
    final_health: int,
    education_level: str,
    career_years: int,
    children: int,
    marriage_count: int,
    peak_net_worth_cents: int,
    unsealed_convictions: int,
) -> float:
    """Score a life from 0–100 using fixed, documented and reproducible components.

    Components (maximum points): longevity ``age × 0.30`` capped at 30;
    lifetime average happiness ``× 0.15`` (15); final health ``× 0.10`` (10);
    education rank ``× 2`` (10); career tenure ``years ÷ 5`` capped at 10;
    family ``2`` per child capped at 6 plus 4 for any marriage (10); peak
    net worth ``$1M`` per point capped at 10; and 5 for a clean conviction
    record. The result is rounded half-up to two decimal places.
    """
    if age < 0 or career_years < 0 or children < 0 or marriage_count < 0 or peak_net_worth_cents < 0:
        raise ValueError("life-score inputs cannot be negative")
    if not 0 <= average_happiness <= 100 or not 0 <= final_health <= 100:
        raise ValueError("happiness and health must be between 0 and 100")
    rank = _EDUCATION_RANK.get(str(education_level), 0)
    wealth_millions = Decimal(max(0, int(peak_net_worth_cents))) / Decimal(dollars_to_cents(1_000_000))
    components = (
        min(30.0, float(age) * 0.30)
        + float(average_happiness) * 0.15
        + float(final_health) * 0.10
        + rank * 2.0
        + min(10.0, float(career_years) / 5.0)
        + min(6.0, float(children) * 2.0)
        + (4.0 if marriage_count > 0 else 0.0)
        + float(min(Decimal("10"), wealth_millions))
        + (5.0 if unsealed_convictions == 0 else 0.0)
    )
    return float(Decimal(str(max(0.0, min(100.0, components)))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def grade_for_life_score(score: float) -> str:
    """Map a score to documented cutoffs: S 90+, A 80+, B 70+, C 55+, D 40+, F below."""
    if not math.isfinite(float(score)) or not 0 <= float(score) <= 100:
        raise ValueError("life score must be finite and between 0 and 100")
    for cutoff, grade in GRADE_CUTOFFS:
        if float(score) >= cutoff:
            return grade
    return "F"


def legacy_points_for_score(score: float) -> int:
    """Grant cosmetic legacy points as floor(life_score / 10)."""
    if not math.isfinite(float(score)) or not 0 <= float(score) <= 100:
        raise ValueError("life score must be finite and between 0 and 100")
    return math.floor(float(score) / 10.0)


def calculate_estate_settlement(
    *, gross_assets_cents: int, debts_due_cents: int, price_index: float
) -> EstateSettlement:
    """Pay liabilities first, then tax 40% of remaining assets above $5M × price index.

    Tax rounds upward to a whole cent. All input and output balances are never
    negative, and all monetary values are integer cents.
    """
    for name, value in (("gross_assets_cents", gross_assets_cents), ("debts_due_cents", debts_due_cents)):
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(f"{name} must be non-negative integer cents")
    try:
        index = Decimal(str(price_index))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError("price_index must be a finite positive number") from exc
    if not index.is_finite() or index <= 0:
        raise ValueError("price_index must be a finite positive number")
    paid = min(gross_assets_cents, debts_due_cents)
    unpaid = debts_due_cents - paid
    after_debt = gross_assets_cents - paid
    threshold = scale_cents(dollars_to_cents(5_000_000), index)
    taxable = max(0, after_debt - threshold)
    tax = int((Decimal(taxable) * Decimal("0.40")).quantize(Decimal("1"), rounding=ROUND_CEILING))
    tax = min(after_debt, max(0, tax))
    return EstateSettlement(
        gross_assets_cents=gross_assets_cents,
        debts_due_cents=debts_due_cents,
        debts_paid_cents=paid,
        unpaid_debt_cents=unpaid,
        taxable_threshold_cents=threshold,
        estate_tax_cents=tax,
        estate_cents=max(0, after_debt - tax),
    )


def select_epitaph(
    *,
    char_id: int,
    age: int,
    cause: str,
    education_level: str,
    children: int,
    marriage_years: int,
    career_count: int,
    conviction_count: int,
    sealed_convictions: int,
    net_worth_cents: int,
    hardship_recovered: bool,
) -> str:
    """Choose from 40+ respectful epitaphs using ordered facts and a stable ID index.

    The priority is century, family, long marriage, education, career, crime
    recovery, criminal record, illness, hardship, wealth, long life, young death,
    then general. No random source or command-supplied trigger is used.
    """
    if cause.strip().lower() == "life abandoned":
        theme = "abandoned"
    elif age >= 100:
        theme = "century"
    elif children >= 5:
        theme = "family"
    elif marriage_years >= 50:
        theme = "long_marriage"
    elif _EDUCATION_RANK.get(str(education_level), 0) >= 4:
        theme = "education"
    elif career_count >= 2:
        theme = "career"
    elif hardship_recovered:
        theme = "crime_recovery"
    elif conviction_count > 0 or sealed_convictions > 0:
        theme = "crime"
    elif "ill" in cause.lower() or "disease" in cause.lower():
        theme = "illness"
    elif net_worth_cents < 0:
        theme = "hardship"
    elif net_worth_cents >= dollars_to_cents(1_000_000):
        theme = "wealth"
    elif age >= 80:
        theme = "long_life"
    elif age < 30:
        theme = "young"
    else:
        theme = "general"
    templates = _EPITAPHS[theme]
    return templates[abs(int(char_id)) % len(templates)]


class DeathService:
    """Apply death and retirement exactly once inside a caller-owned transaction."""

    def __init__(
        self,
        db: Any,
        locks: Optional[UserLockRegistry] = None,
        *,
        clock: Callable[[], float] = time.time,
        repository: Optional[LegacyRepository] = None,
        achievements: Optional[AchievementService] = None,
        family_service: Optional[FamilyService] = None,
        crime_service: Optional[CrimeService] = None,
        casino_service: Optional[CasinoService] = None,
    ) -> None:
        self.db = db
        self.locks = locks or UserLockRegistry()
        self.clock = clock
        self.repository = repository or LegacyRepository(db)
        self.achievements = achievements or AchievementService(db, self.locks, clock=clock)
        self.family_service = family_service
        self.crime_service = crime_service
        self.casino_service = casino_service

    async def handle_death(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        now: Optional[int] = None,
        guild_id: Optional[int] = None,
    ) -> Optional[DeathResult]:
        """Archive a naturally ended life once; duplicate calls are safe no-ops."""
        timestamp = int(self.clock()) if now is None else int(now)
        if character.is_alive:
            raise ValidationError("Death can only be archived after the character has ended.")
        existing = await self.repository.past_life(tx, character.char_id)
        if existing is not None:
            return None
        record = await self.repository.character_record(tx, character.char_id)
        if record is None or int(record["user_id"]) != character.user_id:
            raise CharacterNotFound("The life to archive could not be found.")
        stored = Character.from_dict(json.loads(record["data_json"]))
        if stored.is_alive:
            raise ConcurrentUpdate("The saved character has not yet entered its terminal state.")
        character = stored
        await self.repository.ensure_player(tx, character.user_id, timestamp)
        # Evaluate death-age and completion achievements from the persisted terminal character
        # before its active career and marriage rows are closed. The caller queues notices only
        # after its transaction commits.
        unlocked = await self.achievements.check_user_in_tx(
            tx, character.user_id, now=timestamp
        )
        abandoned = character.death_cause == "Life abandoned"
        await self.repository.close_open_career(
            tx, character.char_id, character.age, "retired" if abandoned else "died"
        )
        await self.repository.archive_marriage(
            tx, char_id=character.char_id, end_age=character.age,
            end_reason="retirement" if abandoned else "character_death", now=timestamp,
        )
        result = await self._archive(
            tx, character, now=timestamp, guild_id=guild_id, abandoned=abandoned
        )
        if result is None:
            return None
        return replace(result, unlocked_achievements=tuple(unlocked))

    async def _archive(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        now: int,
        guild_id: Optional[int],
        abandoned: bool,
    ) -> Optional[DeathResult]:
        """Build and insert the immutable life summary, settle assets, and offer heirs."""
        char_id = character.char_id
        user_id = character.user_id
        existing = await self.repository.past_life(tx, char_id)
        if existing is not None:
            return None
        careers = await self.repository.career_history(tx, char_id)
        marriages = await self.repository.marriage_history(tx, char_id)
        current_marriage = await self.repository.current_marriage(tx, char_id)
        children = await self.repository.children(tx, char_id)
        logs = await self.repository.top_life_logs(tx, char_id, 10)
        metrics = await self.repository.life_year_metrics(tx, char_id)
        crime = await self.repository.crime_summary(tx, char_id)
        tracking = await self.repository.stats_tracking(tx, char_id)
        economy = await self.repository.economy_snapshot(tx, char_id)
        peak_net_worth = max(
            [economy["net_worth_cents"]]
            + [int(row["peak_net_worth_cents"]) for row in metrics]
        )
        average_happiness = (
            sum(int(row["happiness"]) for row in metrics) / len(metrics)
            if metrics else float(character.stats.happiness)
        )
        prison_years = int(crime["years_in_prison"])
        career_years = sum(
            max(0, (int(row["end_age"]) if row["end_age"] is not None else character.age) - int(row["start_age"]))
            for row in careers
        )
        child_count = len(children)
        marriage_count = len(marriages) + int(current_marriage is not None)
        marriage_years = await self.repository.max_marriage_years(tx, char_id, character.age)
        settlement = calculate_estate_settlement(
            gross_assets_cents=economy["gross_assets_cents"],
            debts_due_cents=economy["debts_cents"],
            price_index=max(0.000001, float(character.price_index)),
        )
        if abandoned:
            estate_tax = 0
            estate_cents = 0
            debts_paid = 0
            unpaid_debt = economy["debts_cents"]
        else:
            settlement_paid = await self.repository.settle_loan_balances(
                tx, char_id, settlement.debts_paid_cents
            )
            debts_paid = settlement.debts_paid_cents
            # Loan subledger rows are retired in stable order; remaining debt is not passed to an heir.
            estate_tax = settlement.estate_tax_cents
            estate_cents = settlement.estate_cents
            unpaid_debt = settlement.unpaid_debt_cents
            if settlement_paid > debts_paid:
                raise AssertionError("loan payment cannot exceed estate debt payment")
        final_worth = economy["net_worth_cents"]
        score = calculate_life_score(
            age=character.age,
            average_happiness=average_happiness,
            final_health=character.stats.health,
            education_level=character.education_level.value,
            career_years=career_years,
            children=child_count,
            marriage_count=marriage_count,
            peak_net_worth_cents=max(0, peak_net_worth),
            unsealed_convictions=int(crime["convictions"]),
        )
        grade = grade_for_life_score(score)
        points = 0 if abandoned else legacy_points_for_score(score)
        has_recovered = int(crime["sealed_convictions"]) > 0 and int(crime["convictions"]) == 0
        epitaph = select_epitaph(
            char_id=char_id,
            age=character.age,
            cause=character.death_cause or ("Life abandoned" if abandoned else "natural causes"),
            education_level=character.education_level.value,
            children=child_count,
            marriage_years=marriage_years,
            career_count=len(careers),
            conviction_count=int(crime["convictions"]),
            sealed_convictions=int(crime["sealed_convictions"]),
            net_worth_cents=final_worth,
            hardship_recovered=has_recovered,
        )
        earned = await self.repository.character_achievement_rows(tx, char_id)
        public_summary = False
        if guild_id is not None and not abandoned:
            guild_enabled = await self.repository.guild_public_death_summaries(tx, guild_id)
            player = await self.repository.player_row(tx, user_id)
            public_summary = guild_enabled and not bool(player and player.get("leaderboard_opt_out"))
        summary: dict[str, Any] = {
            "char_id": char_id,
            "user_id": user_id,
            "name": character.name,
            "gender": character.gender.value,
            "country": character.country,
            "generation": character.generation,
            "parent_char_id": character.parent_char_id,
            "death_age": character.age,
            "death_cause": "Life abandoned" if abandoned else (character.death_cause or "natural causes"),
            "born_at": character.born_at,
            "died_at": character.died_at or now,
            "years_lived": character.age,
            "epitaph": epitaph,
            "education": {
                "level": character.education_level.value,
                "gpa": character.gpa,
                "major": character.major,
            },
            "careers": careers,
            "career_years": career_years,
            "peak_net_worth_cents": peak_net_worth,
            "final_net_worth_cents": final_worth,
            "gross_assets_cents": economy["gross_assets_cents"],
            "debts_due_cents": economy["debts_cents"],
            "debts_paid_cents": debts_paid,
            "estate_tax_cents": estate_tax,
            "estate_tax_rate": 0.40,
            "estate_tax_threshold_cents": settlement.taxable_threshold_cents,
            "estate_cents": estate_cents,
            "unpaid_debt_cents": unpaid_debt,
            "price_index": character.price_index,
            "marriages": marriages,
            "marriage_count": marriage_count,
            "marriage_years": marriage_years,
            "current_marriage": current_marriage,
            "children": children,
            "child_count": child_count,
            "crime": {
                "attempts": crime["attempts"],
                "successes": crime["successes"],
                "convictions": crime["convictions"],
                "sealed_convictions": crime["sealed_convictions"],
                "years_in_prison": prison_years,
                "escaped": crime["escaped"],
                "career_level": int(crime["profile"].get("career_level", 0)),
            },
            "gambling": {
                "total_gambled_cents": tracking["total_gambled"],
                "net_cents": tracking["total_gambling_net"],
            },
            "fame": character.stats.fame,
            "average_happiness": round(average_happiness, 2),
            "life_years": metrics,
            "life_log_top": logs,
            "achievements": earned,
            "life_score": score,
            "grade": grade,
            "legacy_points": points,
            "abandoned": abandoned,
            "public_summary": public_summary,
            "archived_at": now,
        }
        inserted = await self.repository.insert_past_life(
            tx,
            {
                "char_id": char_id,
                "user_id": user_id,
                "death_age": character.age,
                "death_cause": summary["death_cause"],
                "born_at": character.born_at,
                "died_at": int(summary["died_at"]),
                "life_score": score,
                "grade": grade,
                "legacy_points": points,
                "peak_net_worth_cents": peak_net_worth,
                "final_net_worth_cents": final_worth,
                "gross_assets_cents": economy["gross_assets_cents"],
                "debts_paid_cents": debts_paid,
                "estate_tax_cents": estate_tax,
                "estate_cents": estate_cents,
                "unpaid_debt_cents": unpaid_debt,
                "abandoned": abandoned,
                "summary_json": summary,
                "archived_at": now,
            },
        )
        if not inserted:
            return None  # A competing/replayed invocation already archived this character.
        if not abandoned:
            await self.repository.increment_lives_lived(tx, user_id, now)
        if points:
            await self.repository.add_player_legacy_points(tx, user_id, points, now)
        heirs: list[dict[str, Any]] = []
        estate_id: Optional[int] = None
        estate_nonce: Optional[str] = None
        if not abandoned:
            eligible = await self.repository.estate_heirs(tx, char_id)
            heirs = self._split_inheritance(eligible, estate_cents)
            if heirs:
                estate_nonce = secrets.token_urlsafe(18)
                estate_id = await self.repository.insert_life_estate(
                    tx,
                    char_id=char_id,
                    user_id=user_id,
                    estate_cents=estate_cents,
                    nonce=estate_nonce,
                    eligible_heirs=heirs,
                    now=now,
                )
        return DeathResult(
            summary=summary,
            estate_id=estate_id,
            estate_nonce=estate_nonce,
            heirs=tuple(heirs),
            public_summary=public_summary,
        )

    @staticmethod
    def _split_inheritance(heirs: list[dict[str, Any]], estate_cents: int) -> list[dict[str, Any]]:
        """Split cents evenly by eligible child ID, assigning remainder cents stably."""
        if not heirs or estate_cents < 0:
            return []
        ordered = sorted(heirs, key=lambda row: int(row["npc_id"]))
        base, remainder = divmod(int(estate_cents), len(ordered))
        return [
            {**row, "inheritance_cents": base + int(index < remainder)}
            for index, row in enumerate(ordered)
        ]

    async def begin_retirement(self, user_id: int, *, now: Optional[int] = None) -> RetirementPrompt:
        """Create a 60-second owner-bound confirmation prompt for abandoning a life."""
        timestamp = int(self.clock()) if now is None else int(now)
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                await self.repository.ensure_player(tx, user_id, timestamp)
                active = await self.repository.active_character(tx, user_id)
                if active is None:
                    raise CharacterNotFound("You need an active life before you can retire it.")
                character = Character.from_dict(json.loads(active["data_json"]))
                if self.crime_service is not None:
                    await self.crime_service.ensure_no_pending_decision(tx, character.char_id)
                if self.casino_service is not None:
                    await self.casino_service.require_no_active_hand(tx, character.char_id)
                    await self.casino_service.require_no_pending_compulsion(tx, character.char_id)
                if await self.repository.has_pending_event(tx, character.char_id):
                    raise ValidationError("Resolve your pending life event before retiring.")
                pending = await self.repository.pending_retirement_prompt(tx, user_id)
                if pending is not None and int(pending["expires_at"]) >= timestamp:
                    raise ValidationError("A retirement confirmation is already open. Use it or wait for it to expire.")
                if pending is not None:
                    await self.repository.resolve_retirement_prompt(
                        tx, prompt_id=int(pending["prompt_id"]), user_id=user_id,
                        nonce=str(pending["nonce"]), status="expired", now=timestamp,
                    )
                nonce = secrets.token_urlsafe(18)
                prompt_id = await self.repository.insert_retirement_prompt(
                    tx, user_id=user_id, char_id=character.char_id, nonce=nonce,
                    now=timestamp, expires_at=timestamp + 60,
                )
                return RetirementPrompt(prompt_id=prompt_id, nonce=nonce, expires_at=timestamp + 60)

    async def confirm_retirement(
        self,
        user_id: int,
        prompt_id: int,
        nonce: str,
        *,
        guild_id: Optional[int] = None,
        now: Optional[int] = None,
    ) -> RetirementResult:
        """Confirm retirement once, archive the life with no points or heir transfer."""
        timestamp = int(self.clock()) if now is None else int(now)
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                prompt = await self.repository.load_retirement_prompt(tx, prompt_id)
                if (
                    prompt is None
                    or int(prompt["user_id"]) != user_id
                    or str(prompt["nonce"]) != nonce
                    or str(prompt["status"]) != "pending"
                ):
                    raise ValidationError("This retirement confirmation is no longer valid.")
                if int(prompt["expires_at"]) < timestamp:
                    await self.repository.resolve_retirement_prompt(
                        tx, prompt_id=prompt_id, user_id=user_id, nonce=nonce,
                        status="expired", now=timestamp,
                    )
                    raise ValidationError("This retirement confirmation expired. Run `/retire_life` again.")
                active = await self.repository.active_character(tx, user_id)
                if active is None or int(active["char_id"]) != int(prompt["char_id"]):
                    raise CharacterDead("Your active life changed; this retirement prompt is stale.")
                character = Character.from_dict(json.loads(active["data_json"]))
                if await self.repository.past_life(tx, character.char_id) is not None:
                    raise CharacterDead("This life has already been archived.")
                await self.repository.resolve_retirement_prompt(
                    tx, prompt_id=prompt_id, user_id=user_id, nonce=nonce,
                    status="confirmed", now=timestamp,
                )
                retired = replace(
                    character,
                    is_alive=False,
                    death_cause="Life abandoned",
                    death_age=character.age,
                    died_at=timestamp,
                    last_age_at=timestamp,
                    version=character.version + 1,
                )
                await self.repository.save_death_character(
                    tx, retired, expected_version=int(active["version"])
                )
                await self.repository.insert_life_log(
                    tx, char_id=retired.char_id, age=retired.age,
                    category="retirement", text="Life abandoned by player.",
                    importance=4, created_at=timestamp,
                )
                await self.repository.record_life_year(
                    tx, character=retired, age=retired.age, served_prison_year=False, now=timestamp
                )
                result = await self.handle_death(tx, retired, now=timestamp, guild_id=guild_id)
                if result is None:
                    raise CharacterDead("This life has already been archived.")
                retirement_result = RetirementResult(summary=result.summary, public_summary=False)
            self.achievements.queue_notifications(user_id, result.unlocked_achievements)
            return retirement_result

    async def cancel_retirement(
        self, user_id: int, prompt_id: int, nonce: str, *, now: Optional[int] = None
    ) -> bool:
        """Cancel an owner-bound pending retirement prompt once."""
        timestamp = int(self.clock()) if now is None else int(now)
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                prompt = await self.repository.load_retirement_prompt(tx, prompt_id)
                if prompt is None or int(prompt["user_id"]) != user_id or str(prompt["nonce"]) != nonce:
                    return False
                return await self.repository.resolve_retirement_prompt(
                    tx, prompt_id=prompt_id, user_id=user_id, nonce=nonce,
                    status="cancelled", now=timestamp,
                )

    async def choose_heir(
        self,
        user_id: int,
        estate_id: int,
        nonce: str,
        selected_npc_id: Optional[int],
        *,
        now: Optional[int] = None,
    ) -> Optional[Character]:
        """Claim an eligible adult child as heir, or close the prompt to start fresh."""
        timestamp = int(self.clock()) if now is None else int(now)
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                estate = await self.repository.load_life_estate(tx, estate_id)
                if (
                    estate is None
                    or int(estate["user_id"]) != user_id
                    or str(estate["nonce"]) != nonce
                    or str(estate["status"]) != "pending"
                ):
                    raise ValidationError("This inheritance menu has already been used or is not yours.")
                if await self.repository.active_character(tx, user_id) is not None:
                    raise CharacterAlreadyExists("An active life already exists for your account.")
                eligible = json.loads(str(estate["eligible_heirs_json"]))
                if selected_npc_id is None:
                    if not await self.repository.resolve_life_estate(
                        tx, estate_id=estate_id, user_id=user_id, nonce=nonce,
                        selected_npc_id=None, now=timestamp,
                    ):
                        raise ValidationError("This inheritance menu has already been used.")
                    return None
                selected = next((row for row in eligible if int(row["npc_id"]) == selected_npc_id), None)
                if selected is None:
                    raise ValidationError("That child is not an eligible heir.")
                current_heirs = await self.repository.estate_heirs(tx, int(estate["char_id"]))
                still_eligible = next(
                    (row for row in current_heirs if int(row["npc_id"]) == selected_npc_id), None
                )
                if still_eligible is None:
                    raise ValidationError("That child is no longer a living adult heir.")
                parent_row = await self.repository.character_record(tx, int(estate["char_id"]))
                past = await self.repository.past_life(tx, int(estate["char_id"]))
                if parent_row is None or past is None:
                    raise ValidationError("The archived parent life could not be found.")
                parent = Character.from_dict(json.loads(parent_row["data_json"]))
                share = max(0, int(selected.get("inheritance_cents", 0)))
                heir = Character(
                    user_id=user_id,
                    is_alive=True,
                    name=str(still_eligible["name"]),
                    gender=Gender(str(still_eligible["gender"])),
                    country=str(still_eligible["country"]),
                    wealth_class=self._wealth_class(int(still_eligible["wealth"])),
                    age=int(still_eligible["age"]),
                    stats=Stats(
                        health=max(0, min(100, int(still_eligible["health"]))),
                        happiness=70,
                        smarts=max(0, min(100, int(still_eligible["smarts"]))),
                        looks=max(0, min(100, int(still_eligible["looks"]))),
                        fitness=40,
                        karma=50,
                        stress=10,
                        addiction=0,
                        fame=0,
                    ),
                    cash=share,
                    bank=0,
                    debt_total=0,
                    price_index=float(parent.price_index),
                    parent_char_id=parent.char_id,
                    generation=parent.generation + 1,
                    last_age_at=timestamp,
                    born_at=timestamp,
                )
                char_id = await self.repository.save_heir_character(tx, heir)
                heir.char_id = char_id
                await self.repository.refresh_character_json(tx, heir)
                if self.family_service is not None:
                    await self.family_service.initialize_family(tx, heir)
                if self.crime_service is not None:
                    await self.crime_service.initialize_character(tx, heir)
                if not await self.repository.resolve_life_estate(
                    tx, estate_id=estate_id, user_id=user_id, nonce=nonce,
                    selected_npc_id=selected_npc_id, now=timestamp,
                ):
                    raise ValidationError("This inheritance menu has already been used.")
                await self.repository.insert_life_log(
                    tx, char_id=heir.char_id, age=heir.age,
                    category="family", text="Continued the family as an heir.",
                    importance=4, created_at=timestamp,
                )
                unlocked = await self.achievements.check_user_in_tx(
                    tx, user_id, now=timestamp
                )
            self.achievements.queue_notifications(user_id, unlocked)
            return heir

    @staticmethod
    def _wealth_class(wealth_cents: int) -> str:
        """Map recorded NPC cents to the five established starting wealth labels."""
        thresholds = (
            (dollars_to_cents(15_000), "poor"),
            (dollars_to_cents(80_000), "working"),
            (dollars_to_cents(600_000), "middle"),
            (dollars_to_cents(5_000_000), "upper"),
        )
        for cutoff, label in thresholds:
            if wealth_cents < cutoff:
                return label
        return "rich"
```

## `core/leaderboard.py`

```python
"""Privacy-aware, deterministic Stage 10 leaderboards with a short cache."""
from __future__ import annotations

import copy
import json
import time
from dataclasses import dataclass
from typing import Any, Callable, Optional

from .achievements import AchievementService
from .death import calculate_life_score
from .errors import ValidationError
from .locks import UserLockRegistry
from .models import Character
from .repositories.legacy import LegacyRepository

METRICS: dict[str, str] = {
    "net_worth": "Net Worth",
    "life_score": "Life Score",
    "age": "Age",
    "fame": "Fame",
    "lives": "Lives",
    "gambling": "Total Wagered",
    "crime": "Successful Crimes",
}
SCOPES = {"server", "global"}
PERIODS = {"current", "all_time"}


@dataclass(frozen=True, slots=True)
class LeaderboardResult:
    """One ranked and privacy-filtered leaderboard snapshot."""

    metric: str
    scope: str
    period: str
    guild_id: Optional[int]
    entries: tuple[dict[str, Any], ...]
    created_at: float
    expires_at: float


class LeaderboardService:
    """Build owner-independent rankings with deterministic ties and a 60-second cache."""

    def __init__(
        self,
        db: Any,
        achievements: AchievementService,
        locks: Optional[UserLockRegistry] = None,
        *,
        clock: Callable[[], float] = time.monotonic,
        cache_seconds: int = 60,
    ) -> None:
        self.db = db
        self.achievements = achievements
        self.locks = locks or UserLockRegistry()
        self.clock = clock
        self.cache_seconds = int(cache_seconds)
        self.repository = LegacyRepository(db)
        self._cache: dict[tuple[Optional[int], str, str, str], tuple[float, tuple[dict[str, Any], ...]]] = {}

    async def get_leaderboard(
        self,
        actor_id: int,
        *,
        metric: str,
        scope: str = "server",
        period: str = "current",
        guild_id: Optional[int] = None,
    ) -> LeaderboardResult:
        """Return a cached or freshly computed ranking for one public scope."""
        if isinstance(actor_id, bool) or not isinstance(actor_id, int) or actor_id <= 0:
            raise ValidationError("A valid Discord account is required.")
        if metric not in METRICS:
            raise ValidationError("Choose a supported leaderboard category.")
        if scope not in SCOPES:
            raise ValidationError("Leaderboard scope must be server or global.")
        if period not in PERIODS:
            raise ValidationError("Leaderboard period must be current or all_time.")
        if scope == "server" and (guild_id is None or guild_id <= 0):
            raise ValidationError("Server leaderboards are only available inside a server.")
        key = (guild_id if scope == "server" else None, metric, scope, period)
        timestamp = float(self.clock())
        cached = self._cache.get(key)
        if cached is not None and timestamp < cached[0]:
            expires_at, entries = cached
            return LeaderboardResult(
                metric, scope, period, guild_id if scope == "server" else None,
                copy.deepcopy(entries), expires_at - self.cache_seconds, expires_at,
            )
        async with self.locks.hold(actor_id):
            async with self.db.transaction() as tx:
                if scope == "server":
                    await self.repository.record_guild_seen(tx, int(guild_id), actor_id, int(time.time()))
                users = await self.repository.leaderboard_players(tx)
                visible_ids = {int(row["user_id"]) for row in users}
                if scope == "server":
                    seen_ids = set(await self.repository.seen_guild_users(tx, int(guild_id)))
                    visible_ids.intersection_update(seen_ids)
                active_rows = await self.repository.leaderboard_characters(tx)
                active_by_user = {
                    int(row["user_id"]): row for row in active_rows
                    if int(row["user_id"]) in visible_ids
                }
                past_rows = await self.repository.leaderboard_past_lives(tx)
                past_by_user: dict[int, list[dict[str, Any]]] = {}
                for row in past_rows:
                    user_id = int(row["user_id"])
                    if user_id in visible_ids:
                        past_by_user.setdefault(user_id, []).append(dict(row))
                player_by_id = {int(row["user_id"]): dict(row) for row in users}
                result: list[dict[str, Any]] = []
                for user_id in sorted(visible_ids):
                    active_row = active_by_user.get(user_id)
                    past = past_by_user.get(user_id, [])
                    current = await self._current_facts(tx, active_row) if active_row is not None else None
                    if period == "current":
                        if current is None:
                            continue
                        value = self._metric_value(metric, current, [], player_by_id[user_id], all_time=False)
                    else:
                        value = self._metric_value(metric, current, past, player_by_id[user_id], all_time=True)
                    result.append({"user_id": user_id, "value": value})
                result.sort(key=lambda item: (-float(item["value"]), int(item["user_id"])))
                frozen_entries = tuple(
                    {"rank": index + 1, "user_id": int(item["user_id"]), "value": item["value"]}
                    for index, item in enumerate(result)
                )
        expires_at = timestamp + self.cache_seconds
        self._cache[key] = (expires_at, frozen_entries)
        return LeaderboardResult(
            metric, scope, period, guild_id if scope == "server" else None,
            copy.deepcopy(frozen_entries), timestamp, expires_at,
        )

    async def set_opt_out(self, user_id: int, opt_out: bool, *, now: Optional[int] = None) -> None:
        """Set the user's public ranking/profile visibility preference."""
        timestamp = int(time.time()) if now is None else int(now)
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                await self.repository.set_leaderboard_privacy(tx, user_id, bool(opt_out), timestamp)
        self._cache.clear()

    async def is_opted_out(self, user_id: int) -> bool:
        """Return whether another user's achievements and life summaries are private."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                row = await self.repository.player_row(tx, user_id)
        return bool(row and row.get("leaderboard_opt_out"))

    def clear_cache(self) -> None:
        """Clear all leaderboard snapshots after a privacy or data change."""
        self._cache.clear()

    async def _current_facts(self, tx: Any, row: dict[str, Any]) -> dict[str, Any]:
        """Calculate metrics for one active character from persisted state."""
        character = Character.from_dict(json.loads(str(row["data_json"])))
        character.char_id = int(row["char_id"])
        character.user_id = int(row["user_id"])
        facts = await self.achievements._facts(tx, character)
        score = calculate_life_score(
            age=character.age,
            average_happiness=float(facts["average_happiness"]),
            final_health=character.stats.health,
            education_level=character.education_level.value,
            career_years=int(facts["career_years"]),
            children=int(facts["children"]),
            marriage_count=int(facts["marriage_count"]),
            peak_net_worth_cents=max(0, int(facts["peak_net_worth_cents"])),
            unsealed_convictions=int(facts["convictions"]),
        )
        tracking = await self.repository.stats_tracking(tx, character.char_id)
        return {
            "net_worth": int(facts["net_worth_cents"]),
            "peak_net_worth": int(facts["peak_net_worth_cents"]),
            "life_score": score,
            "age": int(character.age),
            "fame": int(character.stats.fame),
            "lives": int(character.generation),
            "gambling": int(tracking["total_gambled"]),
            "crime": int(facts["successes"]),
            "generation": int(character.generation),
        }

    @staticmethod
    def _metric_value(
        metric: str,
        current: Optional[dict[str, Any]],
        past_rows: list[dict[str, Any]],
        player: dict[str, Any],
        *,
        all_time: bool,
    ) -> int | float:
        """Combine current and archived life facts according to the chosen period."""
        if not all_time:
            return 0 if current is None else current[metric]
        summaries: list[dict[str, Any]] = []
        for row in past_rows:
            try:
                summaries.append(json.loads(str(row["summary_json"])))
            except (TypeError, json.JSONDecodeError):
                summaries.append({})
        if metric == "net_worth":
            values = [int(row.get("peak_net_worth_cents", 0)) for row in summaries]
            if current is not None:
                values.append(int(current["peak_net_worth"]))
            return max(values, default=0)
        if metric == "life_score":
            values = [float(row.get("life_score", 0.0)) for row in summaries]
            if current is not None:
                values.append(float(current["life_score"]))
            return max(values, default=0.0)
        if metric == "age":
            values = [int(row.get("death_age", 0)) for row in summaries]
            if current is not None:
                values.append(int(current["age"]))
            return max(values, default=0)
        if metric == "fame":
            values = [int(row.get("fame", 0)) for row in summaries]
            if current is not None:
                values.append(int(current["fame"]))
            return max(values, default=0)
        if metric == "lives":
            return int(player.get("lives_lived", 0)) + int(current is not None)
        if metric == "gambling":
            archived = sum(int(row.get("gambling", {}).get("total_gambled_cents", 0)) for row in summaries)
            return archived + (int(current["gambling"]) if current is not None else 0)
        if metric == "crime":
            archived = sum(int(row.get("crime", {}).get("successes", 0)) for row in summaries)
            return archived + (int(current["crime"]) if current is not None else 0)
        raise ValidationError("Choose a supported leaderboard category.")
```

## `core/repositories/legacy.py`

```python
"""Parameterized persistence for Stage 10 achievements, death, estates, and legacy."""
from __future__ import annotations

import json
from typing import Any, Optional, Sequence

import aiosqlite

from ..models import Character


class LegacyRepository:
    """Own all Stage 10 SQL; callers provide an already-open write transaction."""

    def __init__(self, db: Any) -> None:
        self.db = db

    @staticmethod
    async def _one(tx: aiosqlite.Connection, sql: str, params: tuple[Any, ...] = ()) -> Any:
        """Fetch one row from a caller-owned transaction."""
        cursor = await tx.execute(sql, params)
        return await cursor.fetchone()

    @staticmethod
    async def _all(tx: aiosqlite.Connection, sql: str, params: tuple[Any, ...] = ()) -> list[Any]:
        """Fetch all rows from a caller-owned transaction."""
        cursor = await tx.execute(sql, params)
        return await cursor.fetchall()

    async def has_pending_event(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Return whether a life has an unresolved choice event."""
        row = await self._one(tx, "SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1", (char_id,))
        return row is not None

    async def ensure_player(self, tx: aiosqlite.Connection, user_id: int, now: int) -> None:
        """Create the account row needed by achievements and legacy balances."""
        await tx.execute(
            "INSERT OR IGNORE INTO players(user_id, created_at) VALUES (?, ?)",
            (user_id, now),
        )

    async def player_row(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Return a player's privacy, life-count, and legacy-point state."""
        row = await self._one(tx, "SELECT * FROM players WHERE user_id = ? LIMIT 1", (user_id,))
        return dict(row) if row is not None else None

    async def spend_legacy_points(
        self,
        tx: aiosqlite.Connection,
        *,
        user_id: int,
        char_id: int,
        stat_name: str,
        purchase_count: int,
        now: int,
    ) -> int:
        """Spend 50 cosmetic points per starting-stat purchase, up to two."""
        await self.ensure_player(tx, user_id, now)
        cost = purchase_count * 50
        cursor = await tx.execute(
            "UPDATE players SET legacy_points = legacy_points - ? WHERE user_id = ? AND legacy_points >= ?",
            (cost, user_id, cost),
        )
        if cursor.rowcount != 1:
            raise ValueError("not enough legacy points")
        await tx.execute(
            """INSERT INTO legacy_start_purchases
                   (char_id, user_id, stat_name, purchase_count, points_spent, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (char_id, user_id, stat_name, purchase_count, cost, now),
        )
        return cost

    async def audit_legacy_purchase(
        self,
        tx: aiosqlite.Connection,
        *,
        user_id: int,
        char_id: int,
        stat_name: str,
        purchase_count: int,
        now: int,
    ) -> None:
        """Record cosmetic starting-stat spending in the transaction audit log."""
        await tx.execute(
            """INSERT INTO audit_log(ts, user_id, char_id, action, amount, details_json)
               VALUES (?, ?, ?, 'legacy_start_purchase', ?, ?)""",
            (
                now, user_id, char_id, purchase_count * 50,
                json.dumps({"stat": stat_name, "purchases": purchase_count}, separators=(",", ":")),
            ),
        )

    async def active_character(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Return the user's current active character row."""
        row = await self._one(
            tx,
            "SELECT char_id, user_id, is_alive, age, data_json, version FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def character_record(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Load a character whether alive or archived."""
        row = await self._one(tx, "SELECT * FROM characters WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def user_character_rows(self, tx: aiosqlite.Connection, user_id: int) -> list[dict[str, Any]]:
        """Load every persisted life for one player in stable order."""
        rows = await self._all(
            tx,
            "SELECT * FROM characters WHERE user_id = ? ORDER BY char_id ASC",
            (user_id,),
        )
        return [dict(row) for row in rows]

    async def save_heir_character(self, tx: aiosqlite.Connection, character: Character) -> int:
        """Insert one new heir life with its authoritative serialized attributes."""
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        hidden_json = json.dumps(
            {
                "genetic_health_mod": character.hidden.genetic_health_mod,
                "lifespan_mod": character.hidden.lifespan_mod,
                "luck": character.hidden.luck,
                "temperament": character.hidden.temperament,
            },
            separators=(",", ":"),
            allow_nan=False,
        )
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """INSERT INTO characters
                   (user_id, is_alive, name, gender, country, wealth_class, age,
                    stats_json, hidden_json, version, last_age_at, born_at,
                    died_at, death_cause, death_age, data_json)
               VALUES (?, 1, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, NULL, NULL, NULL, ?)""",
            (
                character.user_id, character.name, character.gender.value, character.country,
                character.wealth_class, character.age, stats_json, hidden_json,
                character.last_age_at, character.born_at, data_json,
            ),
        )
        return int(cursor.lastrowid)

    async def refresh_character_json(self, tx: aiosqlite.Connection, character: Character) -> None:
        """Update a newly assigned character ID inside its serialized snapshot."""
        await tx.execute(
            "UPDATE characters SET data_json = ? WHERE char_id = ?",
            (
                json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False),
                character.char_id,
            ),
        )

    async def save_death_character(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
    ) -> None:
        """Persist the terminal character state once, using the life version as a guard."""
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        hidden_json = json.dumps(
            {
                "genetic_health_mod": character.hidden.genetic_health_mod,
                "lifespan_mod": character.hidden.lifespan_mod,
                "luck": character.hidden.luck,
                "temperament": character.hidden.temperament,
            },
            separators=(",", ":"),
            allow_nan=False,
        )
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET is_alive = 0, age = ?, stats_json = ?, hidden_json = ?,
                   version = ?, last_age_at = ?, died_at = ?, death_cause = ?, death_age = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (
                character.age, stats_json, hidden_json, character.version, character.last_age_at,
                character.died_at, character.death_cause, character.death_age, data_json,
                character.char_id, expected_version,
            ),
        )
        if cursor.rowcount != 1:
            from ..errors import ConcurrentUpdate
            raise ConcurrentUpdate("This life has already ended or changed.")

    async def economy_snapshot(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, int]:
        """Compute liquid and recorded asset values without trusting command arguments."""
        record = await self._one(tx, "SELECT data_json FROM characters WHERE char_id = ?", (char_id,))
        if record is None:
            raise ValueError("character not found")
        data = json.loads(record["data_json"])
        cash = max(0, int(data.get("cash", 0)))
        bank = max(0, int(data.get("bank", 0)))
        debt = max(0, int(data.get("debt_total", 0)))
        item_row = await self._one(
            tx,
            """SELECT COALESCE(SUM(current_value), 0) AS value
               FROM family_assets WHERE char_id = ? AND kind = 'item' AND quantity > 0 AND is_liquidated = 0""", 
            (char_id,),
        )
        stock_row = await self._one(
            tx,
            """SELECT COALESCE(SUM(h.shares * CASE WHEN m.is_delisted = 1 OR m.price_cents < 1
                                                     THEN 0 ELSE m.price_cents END), 0) AS value
               FROM stock_holdings AS h LEFT JOIN stock_market AS m ON m.symbol = h.symbol
               WHERE h.char_id = ?""",
            (char_id,),
        )
        bond_row = await self._one(
            tx,
            "SELECT COALESCE(SUM(balance_cents), 0) AS value FROM savings_bonds WHERE char_id = ? AND status = 'locked'",
            (char_id,),
        )
        loan_row = await self._one(
            tx,
            "SELECT COALESCE(SUM(balance), 0) AS value FROM loans WHERE char_id = ? AND status = 'active'",
            (char_id,),
        )
        items = max(0, int(item_row["value"]))
        stocks = max(0, int(stock_row["value"]))
        bonds = max(0, int(bond_row["value"]))
        liabilities = max(debt, max(0, int(loan_row["value"])))
        gross = cash + bank + items + stocks + bonds
        return {
            "cash_cents": cash,
            "bank_cents": bank,
            "item_assets_cents": items,
            "stock_assets_cents": stocks,
            "bond_assets_cents": bonds,
            "gross_assets_cents": gross,
            "debts_cents": liabilities,
            "net_worth_cents": gross - liabilities,
        }

    async def record_life_year(
        self,
        tx: aiosqlite.Connection,
        *,
        character: Character,
        age: int,
        served_prison_year: bool,
        now: int,
    ) -> dict[str, int]:
        """Record annual happiness and the high-water net worth for one age."""
        economy = await self.economy_snapshot(tx, character.char_id)
        prior = await self._one(
            tx,
            "SELECT COALESCE(MAX(peak_net_worth_cents), 0) AS peak FROM life_year_metrics WHERE char_id = ?",
            (character.char_id,),
        )
        peak = max(int(prior["peak"]), economy["net_worth_cents"])
        await tx.execute(
            """INSERT INTO life_year_metrics
                   (char_id, age, happiness, net_worth_cents, peak_net_worth_cents, served_prison_year, recorded_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(char_id, age) DO UPDATE SET
                   net_worth_cents = excluded.net_worth_cents,
                   peak_net_worth_cents = MAX(life_year_metrics.peak_net_worth_cents, excluded.peak_net_worth_cents),
                   served_prison_year = MAX(life_year_metrics.served_prison_year, excluded.served_prison_year)""",
            (
                character.char_id, age, max(0, min(100, int(character.stats.happiness))),
                economy["net_worth_cents"], peak, int(served_prison_year), now,
            ),
        )
        economy["peak_net_worth_cents"] = peak
        return economy

    async def life_year_metrics(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Read yearly happiness, wealth, and prison-time observations chronologically."""
        rows = await self._all(
            tx,
            "SELECT * FROM life_year_metrics WHERE char_id = ? ORDER BY age ASC",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def ensure_player_for_character(self, tx: aiosqlite.Connection, char_id: int, now: int) -> int:
        """Ensure the player row exists for a character and return its Discord ID."""
        row = await self._one(tx, "SELECT user_id FROM characters WHERE char_id = ?", (char_id,))
        if row is None:
            raise ValueError("character not found")
        user_id = int(row["user_id"])
        await self.ensure_player(tx, user_id, now)
        return user_id

    async def close_open_career(self, tx: aiosqlite.Connection, char_id: int, age: int, reason: str) -> None:
        """Close any still-open career history and remove the active job row."""
        await tx.execute(
            "UPDATE career_history SET end_age = ?, end_reason = ? WHERE char_id = ? AND end_age IS NULL",
            (age, reason, char_id),
        )
        await tx.execute("DELETE FROM jobs WHERE char_id = ?", (char_id,))

    async def archive_marriage(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        end_age: int,
        end_reason: str,
        now: int,
    ) -> Optional[dict[str, Any]]:
        """Move a current marriage into durable history before its live row is removed."""
        row = await self._one(
            tx,
            """SELECT m.*, n.name AS spouse_name FROM marriages AS m
               JOIN npcs AS n ON n.npc_id = m.spouse_npc_id WHERE m.char_id = ? LIMIT 1""",
            (char_id,),
        )
        if row is None:
            return None
        result = dict(row)
        final_age = max(int(result["start_age"]), int(end_age))
        await tx.execute(
            """INSERT INTO marriage_history
                   (char_id, spouse_npc_id, spouse_name, start_age, end_age, end_reason, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                char_id, int(result["spouse_npc_id"]), str(result["spouse_name"]),
                int(result["start_age"]), final_age, end_reason, now,
            ),
        )
        await tx.execute("DELETE FROM marriages WHERE char_id = ?", (char_id,))
        return result

    async def children(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Load all children and their live NPC attributes for summaries and inheritance."""
        rows = await self._all(
            tx,
            """SELECT n.*, c.custody, c.child_support, c.other_parent_npc_id
               FROM children AS c JOIN npcs AS n ON n.npc_id = c.npc_id
               WHERE c.char_id = ? ORDER BY n.npc_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def insert_life_log(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        age: int,
        category: str,
        text: str,
        importance: int,
        created_at: int,
    ) -> None:
        """Insert one sanitized-by-caller life moment using parameterized SQL."""
        await tx.execute(
            """INSERT INTO life_logs(char_id, age, category, text, importance, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (char_id, age, category, text, importance, created_at),
        )

    async def top_life_logs(self, tx: aiosqlite.Connection, char_id: int, limit: int = 10) -> list[dict[str, Any]]:
        """Load the most important life moments with deterministic age/ID ordering."""
        rows = await self._all(
            tx,
            """SELECT age, category, text, importance FROM life_logs WHERE char_id = ?
               ORDER BY importance DESC, age ASC, id ASC LIMIT ?""",
            (char_id, limit),
        )
        return [dict(row) for row in rows]

    async def career_history(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Load recorded careers and maximum levels for a life."""
        rows = await self._all(
            tx,
            "SELECT * FROM career_history WHERE char_id = ? ORDER BY start_age, id",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def marriage_history(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Load ended marriages in chronological order."""
        rows = await self._all(
            tx,
            "SELECT * FROM marriage_history WHERE char_id = ? ORDER BY start_age, marriage_history_id",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def current_marriage(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Load a current spouse and marriage start age."""
        row = await self._one(
            tx,
            """SELECT m.*, n.name AS spouse_name, n.is_alive AS spouse_alive
               FROM marriages AS m JOIN npcs AS n ON n.npc_id = m.spouse_npc_id
               WHERE m.char_id = ? LIMIT 1""",
            (char_id,),
        )
        return dict(row) if row is not None else None

    async def crime_summary(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Any]:
        """Aggregate attempts, convictions, successful escapes, and served years."""
        attempts = await self._one(
            tx,
            """SELECT COUNT(*) AS attempts,
                      SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) AS successes,
                      SUM(CASE WHEN case_status = 'convicted' AND record_sealed = 0 THEN 1 ELSE 0 END) AS convictions,
                      SUM(CASE WHEN record_sealed = 1 THEN 1 ELSE 0 END) AS sealed
               FROM crime_attempts WHERE char_id = ?""",
            (char_id,),
        )
        profile = await self._one(tx, "SELECT * FROM crime_profiles WHERE char_id = ?", (char_id,))
        served = await self._one(
            tx,
            "SELECT COALESCE(SUM(served_prison_year), 0) AS years FROM life_year_metrics WHERE char_id = ?",
            (char_id,),
        )
        escaped_log = await self._one(
            tx,
            "SELECT 1 FROM life_logs WHERE char_id = ? AND category = 'prison' AND lower(text) LIKE '%escaped%' LIMIT 1",
            (char_id,),
        )
        return {
            "attempts": int(attempts["attempts"] or 0),
            "successes": int(attempts["successes"] or 0),
            "convictions": int(attempts["convictions"] or 0),
            "sealed_convictions": int(attempts["sealed"] or 0),
            "profile": dict(profile) if profile is not None else {},
            "years_in_prison": int(served["years"] or 0),
            "escaped": bool(escaped_log) or bool(profile and int(profile["escaped"])),
        }

    async def casino_rows(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Load settled casino outcomes for authoritative achievement checks."""
        rows = await self._all(
            tx,
            "SELECT game, bet_cents, payout_cents, net_cents, status, outcome_json FROM casino_plays WHERE char_id = ? ORDER BY play_id",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def investment_rows(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Any]:
        """Return stock trade, bond maturity, rental, and current holding facts."""
        trades = await self._one(tx, "SELECT COUNT(*) AS count FROM investment_trades WHERE char_id = ?", (char_id,))
        holdings = await self._one(
            tx,
            "SELECT COUNT(*) AS count, COALESCE(SUM(shares), 0) AS shares FROM stock_holdings WHERE char_id = ?",
            (char_id,),
        )
        bonds = await self._one(
            tx,
            "SELECT COUNT(*) AS count FROM savings_bonds WHERE char_id = ? AND status = 'matured'",
            (char_id,),
        )
        rent = await self._one(
            tx,
            "SELECT COALESCE(SUM(rental_income_cents), 0) AS income FROM investment_yearly_income WHERE char_id = ?",
            (char_id,),
        )
        return {
            "trade_count": int(trades["count"]),
            "holding_count": int(holdings["count"]),
            "share_count": int(holdings["shares"]),
            "matured_bonds": int(bonds["count"]),
            "rental_income_cents": int(rent["income"]),
        }

    async def education_rows(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Any]:
        """Read authoritative course and GPA records."""
        row = await self._one(
            tx,
            """SELECT COUNT(*) AS count,
                      SUM(CASE WHEN effort = 'hard' THEN 1 ELSE 0 END) AS hard_count,
                      COALESCE(MAX(gpa_after), 0) AS max_gpa
               FROM education_actions WHERE char_id = ?""",
            (char_id,),
        )
        return {
            "study_actions": int(row["count"] or 0),
            "hard_study_actions": int(row["hard_count"] or 0),
            "max_gpa": float(row["max_gpa"] or 0),
        }

    async def active_job(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Read a current job for career facts and salary summaries."""
        row = await self._one(tx, "SELECT * FROM jobs WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def work_action_count(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Count recorded work actions for a life."""
        row = await self._one(tx, "SELECT COUNT(*) AS count FROM career_actions WHERE char_id = ?", (char_id,))
        return int(row["count"])

    async def divorce_count(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Count completed divorces from the authoritative Stage 6 ledger."""
        row = await self._one(tx, "SELECT COUNT(*) AS count FROM divorce_records WHERE char_id = ?", (char_id,))
        return int(row["count"])

    async def marriage_count(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Count current plus archived marriages."""
        row = await self._one(
            tx,
            """SELECT (SELECT COUNT(*) FROM marriage_history WHERE char_id = ?) +
                      (SELECT COUNT(*) FROM marriages WHERE char_id = ?) AS count""",
            (char_id, char_id),
        )
        return int(row["count"])

    async def max_marriage_years(self, tx: aiosqlite.Connection, char_id: int, current_age: int) -> int:
        """Return the longest recorded or current marriage duration."""
        row = await self._one(
            tx,
            """SELECT COALESCE(MAX(duration), 0) AS years FROM (
                   SELECT MAX(0, end_age - start_age) AS duration FROM marriage_history WHERE char_id = ?
                   UNION ALL
                   SELECT MAX(0, ? - start_age) AS duration FROM marriages WHERE char_id = ?
               )""",
            (char_id, current_age, char_id),
        )
        return int(row["years"])

    async def child_count(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Count all children recorded for a character, living or deceased."""
        row = await self._one(tx, "SELECT COUNT(*) AS count FROM children WHERE char_id = ?", (char_id,))
        return int(row["count"])

    async def item_facts(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Any]:
        """Return active owned item IDs and the count of distinct live asset lots."""
        rows = await self._all(
            tx,
            "SELECT item_id, quantity FROM family_assets WHERE char_id = ? AND quantity > 0 AND is_liquidated = 0",
            (char_id,),
        )
        return {"item_rows": [dict(row) for row in rows], "asset_lots": len(rows)}

    async def rehab_used(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check whether the authoritative audit ledger records recovery treatment."""
        row = await self._one(
            tx,
            "SELECT 1 FROM audit_log WHERE char_id = ? AND action = 'gambling_rehab_used' LIMIT 1",
            (char_id,),
        )
        return row is not None

    async def stats_tracking(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, int]:
        """Read Stage 9 gambling totals and Stage 6 divorce count."""
        row = await self._one(tx, "SELECT * FROM stats_tracking WHERE char_id = ? LIMIT 1", (char_id,))
        if row is None:
            return {"total_gambled": 0, "total_gambling_net": 0, "divorces": 0}
        data = dict(row)
        return {
            "total_gambled": int(data.get("total_gambled", 0)),
            "total_gambling_net": int(data.get("total_gambling_net", 0)),
            "divorces": int(data.get("divorces", 0)),
        }

    async def insert_achievement(
        self, tx: aiosqlite.Connection, *, user_id: int, achievement_id: str, char_id: int, now: int
    ) -> bool:
        """Insert a first unlock only; the primary key prevents repeat awards."""
        await self.ensure_player(tx, user_id, now)
        cursor = await tx.execute(
            """INSERT OR IGNORE INTO achievements_unlocked(user_id, achievement_id, char_id, unlocked_at)
               VALUES (?, ?, ?, ?)""",
            (user_id, achievement_id, char_id, now),
        )
        return cursor.rowcount == 1

    async def user_achievements(self, tx: aiosqlite.Connection, user_id: int) -> list[dict[str, Any]]:
        """Load a player's earned achievement rows chronologically."""
        rows = await self._all(
            tx,
            """SELECT a.*, c.name AS character_name FROM achievements_unlocked AS a
               JOIN characters AS c ON c.char_id = a.char_id
               WHERE a.user_id = ? ORDER BY a.unlocked_at DESC, a.achievement_id""",
            (user_id,),
        )
        return [dict(row) for row in rows]

    async def character_achievement_rows(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Load achievements earned during a single life for its death summary."""
        rows = await self._all(
            tx,
            """SELECT achievement_id, unlocked_at FROM achievements_unlocked
               WHERE char_id = ? ORDER BY unlocked_at, achievement_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def add_player_legacy_points(self, tx: aiosqlite.Connection, user_id: int, points: int, now: int) -> None:
        """Add the exact cosmetic legacy score to a player account."""
        await self.ensure_player(tx, user_id, now)
        await tx.execute("UPDATE players SET legacy_points = legacy_points + ? WHERE user_id = ?", (points, user_id))

    async def increment_lives_lived(self, tx: aiosqlite.Connection, user_id: int, now: int) -> None:
        """Increment archived-life count once after the immutable archive insert."""
        await self.ensure_player(tx, user_id, now)
        await tx.execute("UPDATE players SET lives_lived = lives_lived + 1 WHERE user_id = ?", (user_id,))

    async def insert_past_life(self, tx: aiosqlite.Connection, summary: dict[str, Any]) -> bool:
        """Insert an immutable archive row without ever replacing an earlier summary."""
        cursor = await tx.execute(
            """INSERT OR IGNORE INTO past_lives
                   (char_id, user_id, death_age, death_cause, born_at, died_at, life_score, grade,
                    legacy_points, peak_net_worth_cents, final_net_worth_cents, gross_assets_cents,
                    debts_paid_cents, estate_tax_cents, estate_cents, unpaid_debt_cents,
                    abandoned, summary_json, archived_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                int(summary["char_id"]), int(summary["user_id"]), int(summary["death_age"]),
                str(summary["death_cause"]), int(summary["born_at"]), int(summary["died_at"]),
                float(summary["life_score"]), str(summary["grade"]), int(summary["legacy_points"]),
                int(summary["peak_net_worth_cents"]), int(summary["final_net_worth_cents"]),
                int(summary["gross_assets_cents"]), int(summary["debts_paid_cents"]),
                int(summary["estate_tax_cents"]), int(summary["estate_cents"]),
                int(summary["unpaid_debt_cents"]), int(bool(summary["abandoned"])),
                json.dumps(summary, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False),
                int(summary["archived_at"]),
            ),
        )
        return cursor.rowcount == 1

    async def past_life(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Load an archived life by its immutable character ID."""
        row = await self._one(tx, "SELECT * FROM past_lives WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def user_past_lives(self, tx: aiosqlite.Connection, user_id: int, limit: int = 50) -> list[dict[str, Any]]:
        """Load a user's most recent life archives."""
        rows = await self._all(
            tx,
            "SELECT * FROM past_lives WHERE user_id = ? ORDER BY past_life_id DESC LIMIT ?",
            (user_id, limit),
        )
        return [dict(row) for row in rows]

    async def recent_deaths(self, tx: aiosqlite.Connection, limit: int = 50) -> list[dict[str, Any]]:
        """Load the most recent natural/ordinary deaths, excluding voluntary retirement."""
        rows = await self._all(
            tx,
            """SELECT p.*, c.name FROM past_lives AS p
               JOIN characters AS c ON c.char_id = p.char_id
               JOIN players AS pl ON pl.user_id = p.user_id
               WHERE p.abandoned = 0 AND pl.leaderboard_opt_out = 0
               ORDER BY p.archived_at DESC, p.past_life_id DESC LIMIT ?""", 
            (limit,),
        )
        return [dict(row) for row in rows]

    async def settle_loan_balances(self, tx: aiosqlite.Connection, char_id: int, payment_cents: int) -> int:
        """Apply debt settlement to active loan balances in stable order."""
        remaining = max(0, int(payment_cents))
        rows = await self._all(
            tx,
            "SELECT loan_id, balance FROM loans WHERE char_id = ? AND status = 'active' ORDER BY loan_id",
            (char_id,),
        )
        paid = 0
        for row in rows:
            if remaining <= 0:
                break
            balance = max(0, int(row["balance"]))
            part = min(balance, remaining)
            new_balance = balance - part
            await tx.execute(
                "UPDATE loans SET balance = ?, status = ? WHERE loan_id = ? AND status = 'active'",
                (new_balance, "paid" if new_balance == 0 else "active", int(row["loan_id"])),
            )
            paid += part
            remaining -= part
        return paid

    async def close_pending_life_estates(self, tx: aiosqlite.Connection, user_id: int, now: int) -> int:
        """Close unclaimed inheritance prompts when a user elects to begin afresh."""
        cursor = await tx.execute(
            "UPDATE life_estates SET status = 'closed', resolved_at = ? WHERE user_id = ? AND status = 'pending'",
            (now, user_id),
        )
        return int(cursor.rowcount)

    async def guild_public_death_summaries(self, tx: aiosqlite.Connection, guild_id: int) -> bool:
        """Read whether a guild has explicitly enabled public death summaries."""
        row = await self._one(
            tx,
            "SELECT public_death_summaries FROM guild_stage10_settings WHERE guild_id = ?",
            (guild_id,),
        )
        return bool(row and int(row["public_death_summaries"]))

    async def set_guild_public_death_summaries(
        self, tx: aiosqlite.Connection, *, guild_id: int, enabled: bool, user_id: int, now: int
    ) -> None:
        """Persist an administrator's guild-level obituary visibility choice."""
        await tx.execute(
            """INSERT INTO guild_stage10_settings(guild_id, public_death_summaries, updated_by, updated_at)
               VALUES (?, ?, ?, ?)
               ON CONFLICT(guild_id) DO UPDATE SET
                   public_death_summaries = excluded.public_death_summaries,
                   updated_by = excluded.updated_by,
                   updated_at = excluded.updated_at""",
            (guild_id, int(enabled), user_id, now),
        )

    async def insert_life_estate(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        user_id: int,
        estate_cents: int,
        nonce: str,
        eligible_heirs: list[dict[str, Any]],
        now: int,
    ) -> int:
        """Persist one durable owner-bound heir continuation choice."""
        cursor = await tx.execute(
            """INSERT INTO life_estates
                   (char_id, user_id, estate_cents, nonce, eligible_heirs_json, status, created_at)
               VALUES (?, ?, ?, ?, ?, 'pending', ?)""",
            (
                char_id, user_id, estate_cents, nonce,
                json.dumps(eligible_heirs, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False),
                now,
            ),
        )
        return int(cursor.lastrowid)

    async def pending_life_estate(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Load the newest unresolved heir choice for a single owner."""
        row = await self._one(
            tx,
            "SELECT * FROM life_estates WHERE user_id = ? AND status = 'pending' ORDER BY created_at DESC LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def load_life_estate(self, tx: aiosqlite.Connection, estate_id: int) -> Optional[dict[str, Any]]:
        """Load a continuation prompt and its owner/status for server-side validation."""
        row = await self._one(tx, "SELECT * FROM life_estates WHERE estate_id = ? LIMIT 1", (estate_id,))
        return dict(row) if row is not None else None

    async def resolve_life_estate(
        self,
        tx: aiosqlite.Connection,
        *,
        estate_id: int,
        user_id: int,
        nonce: str,
        selected_npc_id: Optional[int],
        now: int,
    ) -> bool:
        """Claim or close a pending inheritance choice exactly once."""
        status = "claimed" if selected_npc_id is not None else "closed"
        cursor = await tx.execute(
            """UPDATE life_estates SET status = ?, selected_npc_id = ?, resolved_at = ?
               WHERE estate_id = ? AND user_id = ? AND nonce = ? AND status = 'pending'""",
            (status, selected_npc_id, now, estate_id, user_id, nonce),
        )
        return cursor.rowcount == 1

    async def pending_retirement_prompt(
        self, tx: aiosqlite.Connection, user_id: int
    ) -> Optional[dict[str, Any]]:
        """Load an active retirement confirmation to prevent duplicate pending prompts."""
        row = await self._one(
            tx,
            "SELECT * FROM retirement_prompts WHERE user_id = ? AND status = 'pending' LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def insert_retirement_prompt(
        self, tx: aiosqlite.Connection, *, user_id: int, char_id: int, nonce: str, now: int, expires_at: int
    ) -> int:
        """Persist a one-time confirmation prompt before abandoning a life."""
        cursor = await tx.execute(
            """INSERT INTO retirement_prompts(user_id, char_id, nonce, created_at, expires_at)
               VALUES (?, ?, ?, ?, ?)""",
            (user_id, char_id, nonce, now, expires_at),
        )
        return int(cursor.lastrowid)

    async def load_retirement_prompt(self, tx: aiosqlite.Connection, prompt_id: int) -> Optional[dict[str, Any]]:
        """Load a retirement confirmation for owner, nonce, and expiry checks."""
        row = await self._one(tx, "SELECT * FROM retirement_prompts WHERE prompt_id = ? LIMIT 1", (prompt_id,))
        return dict(row) if row is not None else None

    async def resolve_retirement_prompt(
        self, tx: aiosqlite.Connection, *, prompt_id: int, user_id: int, nonce: str, status: str, now: int
    ) -> bool:
        """Resolve a pending retirement prompt once."""
        cursor = await tx.execute(
            """UPDATE retirement_prompts SET status = ?, resolved_at = ?
               WHERE prompt_id = ? AND user_id = ? AND nonce = ? AND status = 'pending'""",
            (status, now, prompt_id, user_id, nonce),
        )
        return cursor.rowcount == 1

    async def set_leaderboard_privacy(self, tx: aiosqlite.Connection, user_id: int, opt_out: bool, now: int) -> None:
        """Set the per-account public-leaderboard opt-out setting."""
        await self.ensure_player(tx, user_id, now)
        await tx.execute("UPDATE players SET leaderboard_opt_out = ? WHERE user_id = ?", (int(opt_out), user_id))

    async def record_guild_seen(self, tx: aiosqlite.Connection, guild_id: int, user_id: int, now: int) -> None:
        """Remember an actual guild interaction for no-members-intent filtering."""
        await self.ensure_player(tx, user_id, now)
        await tx.execute(
            """INSERT INTO guild_player_seen(guild_id, user_id, last_seen_at) VALUES (?, ?, ?)
               ON CONFLICT(guild_id, user_id) DO UPDATE SET last_seen_at = excluded.last_seen_at""",
            (guild_id, user_id, now),
        )

    async def seen_guild_users(self, tx: aiosqlite.Connection, guild_id: int) -> list[int]:
        """Return player IDs recently observed interacting in a guild."""
        rows = await self._all(
            tx,
            "SELECT user_id FROM guild_player_seen WHERE guild_id = ? ORDER BY last_seen_at DESC, user_id ASC",
            (guild_id,),
        )
        return [int(row["user_id"]) for row in rows]

    async def leaderboard_players(self, tx: aiosqlite.Connection) -> list[dict[str, Any]]:
        """Load all non-opted-out player IDs and their archived-life summaries."""
        rows = await self._all(
            tx,
            """SELECT user_id, lives_lived, legacy_points FROM players
               WHERE leaderboard_opt_out = 0 ORDER BY user_id""",
        )
        return [dict(row) for row in rows]

    async def leaderboard_characters(self, tx: aiosqlite.Connection) -> list[dict[str, Any]]:
        """Load all active characters, excluding archived raw JSON from leaderboard UI."""
        rows = await self._all(
            tx,
            "SELECT char_id, user_id, age, data_json FROM characters WHERE is_alive = 1 ORDER BY user_id, char_id",
        )
        return [dict(row) for row in rows]

    async def leaderboard_past_lives(self, tx: aiosqlite.Connection) -> list[dict[str, Any]]:
        """Load immutable summary metrics for all archived lives."""
        rows = await self._all(
            tx,
            """SELECT user_id, char_id, death_age, life_score, peak_net_worth_cents, final_net_worth_cents,
                      summary_json, abandoned FROM past_lives WHERE abandoned = 0 ORDER BY user_id, past_life_id""",
        )
        return [dict(row) for row in rows]

    async def set_current_marriage_end(
        self, tx: aiosqlite.Connection, char_id: int, age: int, now: int, reason: str
    ) -> Optional[dict[str, Any]]:
        """Archive then remove the active marriage for divorce or spouse death."""
        return await self.archive_marriage(
            tx, char_id=char_id, end_age=age, end_reason=reason, now=now
        )

    async def estate_heirs(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return living adult children eligible for a continuation choice."""
        rows = await self._all(
            tx,
            """SELECT n.npc_id, n.name, n.gender, n.age, n.health, n.smarts, n.looks,
                      n.country, n.wealth, c.char_id AS parent_char_id
               FROM children AS c JOIN npcs AS n ON n.npc_id = c.npc_id
               WHERE c.char_id = ? AND n.is_alive = 1 AND n.age >= 18
               ORDER BY n.npc_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def read_guild_privacy(self, tx: aiosqlite.Connection, user_ids: Sequence[int]) -> dict[int, bool]:
        """Return opt-out settings for a bounded set of accounts."""
        if not user_ids:
            return {}
        placeholders = ",".join("?" for _ in user_ids)
        rows = await self._all(
            tx,
            f"SELECT user_id, leaderboard_opt_out FROM players WHERE user_id IN ({placeholders})",
            tuple(user_ids),
        )
        return {int(row["user_id"]): bool(row["leaderboard_opt_out"]) for row in rows}

    async def latest_past_life(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return the immutable death archive associated with a character."""
        return await self.past_life(tx, char_id)
```

## `core/life_engine.py`

```python
"""Birth creation, stat rolls, and one-year life simulation."""
from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass, replace
from typing import Any, Callable, Optional

import aiosqlite

from .achievements import AchievementService
from .careers import CareerService
from .death import DeathResult, DeathService
from .casino import CasinoService
from .investing import InvestingService
from .crime import CrimeService, TaxEvasionPrompt, TrialPrompt
from .config import GameBalance
from .education import advance_school_year
from .family import FamilyService
from .errors import (
    CharacterAlreadyExists,
    CharacterDead,
    CharacterNotFound,
    ConcurrentUpdate,
    InsufficientFunds,
    PendingEventExists,
    ValidationError,
)
from .events import EventEngine, EventPrompt
from .locks import UserLockRegistry
from .models import Character, Gender, HiddenTraits, LifeStage, Stats
from .repositories.legacy import LegacyRepository
from .rng import RNG
from .shop import ShopService

logger = logging.getLogger("lifeline.life")
_NAME_RE = re.compile(r"[^\x00-\x1f\x7f]+")


@dataclass(frozen=True, slots=True)
class YearOutcome:
    """Result of applying one simulated year to a character."""

    character: Character
    previous_age: int
    new_age: int
    died: bool
    death_cause: Optional[str]
    stat_changes: dict[str, int]
    previous_stage: LifeStage
    new_stage: LifeStage
    log_messages: tuple[str, ...]
    pending_event: Optional[EventPrompt] = None
    pending_trial: Optional[TrialPrompt] = None
    pending_tax: Optional[TaxEvasionPrompt] = None
    pending_compulsion: Optional[dict[str, Any]] = None
    unlocked_achievements: tuple[dict[str, Any], ...] = ()
    death_summary: Optional[dict[str, Any]] = None
    death_estate_id: Optional[int] = None
    death_estate_nonce: Optional[str] = None
    death_heirs: tuple[dict[str, Any], ...] = ()
    death_public_summary: bool = False


def _clamp_stat(value: int | float) -> int:
    return max(GameBalance.STAT_MIN, min(GameBalance.STAT_MAX, int(round(value))))


def _random_stat(rng: RNG, mean: float, stddev: float) -> int:
    return _clamp_stat(rng.gauss(mean, stddev))


def roll_birth_attributes(rng: RNG) -> tuple[Stats, HiddenTraits, str]:
    """Roll reproducible starting stats, hidden traits, and household wealth class."""
    hidden = HiddenTraits(
        genetic_health_mod=rng.randint(-10, 10),
        lifespan_mod=rng.randint(*GameBalance.LIFESPAN_MOD_RANGE),
        luck=rng.randint(-5, 5),
        temperament=rng.weighted_choice(
            ("calm", "neutral", "volatile"),
            (0.25, 0.55, 0.20),
        ),
    )
    wealth_class = rng.weighted_choice(
        tuple(GameBalance.WEALTH_CLASSES),
        tuple(GameBalance.WEALTH_CLASSES.values()),
    )
    stats = Stats(
        health=_clamp_stat(
            _random_stat(rng, GameBalance.HEALTH_INIT_MEAN, GameBalance.HEALTH_INIT_STDDEV)
            + hidden.genetic_health_mod
        ),
        happiness=_random_stat(rng, GameBalance.HAPPINESS_INIT_MEAN, GameBalance.HAPPINESS_INIT_STDDEV),
        smarts=_random_stat(rng, GameBalance.SMARTS_INIT_MEAN, GameBalance.SMARTS_INIT_STDDEV),
        looks=_random_stat(rng, GameBalance.LOOKS_INIT_MEAN, GameBalance.LOOKS_INIT_STDDEV),
        fitness=_random_stat(rng, GameBalance.FITNESS_INIT_MEAN, GameBalance.FITNESS_INIT_STDDEV),
        karma=_clamp_stat(50 + rng.randint(-10, 10)),
        stress=GameBalance.BASE_STRESS,
        addiction=0,
        fame=0,
        credit_score=None,
    ).clamp_all()
    return stats, hidden, wealth_class


def simulate_year(character: Character, rng: RNG, *, now: Optional[int] = None) -> YearOutcome:
    """Purely calculate one year's aging effects without writing to a database.

    Each call advances exactly one year. Stats remain within 0–100 and a character
    is guaranteed to die no later than ``GameBalance.MAX_AGE``.
    """
    if not character.is_alive:
        raise CharacterDead()
    if character.age < 0:
        raise ValidationError("Character age cannot be negative.")
    if character.age >= GameBalance.MAX_AGE:
        raise CharacterDead("This life has reached the maximum age and has ended.")

    old_age = character.age
    new_age = old_age + 1
    old_stage = character.life_stage
    stats = replace(character.stats)
    before = stats.to_dict()

    # Health varies slightly year to year; age and inherited resilience shape the drift.
    health_delta = rng.randint(-1, 1)
    if new_age >= 50:
        health_delta -= 1
    if new_age >= 70:
        health_delta -= 1
    if character.hidden.genetic_health_mod >= 7 and new_age < 70:
        health_delta += 1
    elif character.hidden.genetic_health_mod <= -7:
        health_delta -= 1
    stats.health = _clamp_stat(stats.health + health_delta)

    # Happiness trends gently toward the game's neutral point; stress recovers naturally.
    target = GameBalance.HAPPINESS_DRIFT_TARGET
    if stats.happiness < target:
        stats.happiness += GameBalance.HAPPINESS_DRIFT_RATE
    elif stats.happiness > target:
        stats.happiness -= GameBalance.HAPPINESS_DRIFT_RATE
    stats.stress = max(0, stats.stress - GameBalance.STRESS_DECAY_PER_YEAR)

    # Childhood and young adulthood build learning and fitness; aging slowly reduces fitness.
    if 6 <= new_age <= 29 and rng.random() < 0.55:
        stats.smarts += 1
    if new_age <= 25 and rng.random() < 0.35:
        stats.fitness += 1
    elif new_age >= 40:
        stats.fitness -= 1
    if new_age >= 70:
        stats.fitness -= 1
    if new_age >= 35 and new_age % 5 == 0:
        stats.looks -= 1

    stats = stats.clamp_all()
    death_cause: Optional[str] = None

    # A low-health character is at higher risk. The hazard rises after expected lifespan.
    expected_lifespan = (
        GameBalance.BASE_LIFESPAN_MEAN
        + character.hidden.lifespan_mod
        + round(character.hidden.genetic_health_mod * 0.25)
    )
    age_hazard = 0.001 + max(0, new_age - 55) * 0.00035
    lifespan_hazard = max(0, new_age - expected_lifespan) * 0.018
    health_multiplier = max(0.55, min(1.8, 1.0 + (50 - stats.health) * 0.012))
    mortality_chance = min(0.95, (age_hazard + lifespan_hazard) * health_multiplier)
    if stats.health <= 0:
        death_cause = "illness"
    elif new_age >= GameBalance.MAX_AGE or rng.random() < mortality_chance:
        death_cause = "natural causes"

    timestamp = int(time.time()) if now is None else int(now)
    updated = replace(
        character,
        age=new_age,
        stats=stats,
        is_alive=death_cause is None,
        died_at=timestamp if death_cause else None,
        death_cause=death_cause,
        death_age=new_age if death_cause else None,
        last_age_at=timestamp,
    )
    new_stage = updated.life_stage
    changes = {
        key: int(stats.to_dict()[key] - before[key])
        for key in stats.to_dict()
        if stats.to_dict()[key] != before[key]
    }

    messages = [f"{updated.name or 'Your character'} turned {new_age}."]
    if new_stage != old_stage:
        messages.append(f"Entered the {new_stage.value.replace('_', ' ')} stage of life.")
    if death_cause:
        messages.append(f"Life ended at age {new_age} from {death_cause}.")

    return YearOutcome(
        character=updated,
        previous_age=old_age,
        new_age=new_age,
        died=death_cause is not None,
        death_cause=death_cause,
        stat_changes=changes,
        previous_stage=old_stage,
        new_stage=new_stage,
        log_messages=tuple(messages),
    )


class LifeEngine:
    """Persistence-backed API for creating, viewing, and aging a user's life."""

    def __init__(
        self,
        db: Any,
        rng: RNG,
        locks: Optional[UserLockRegistry] = None,
        clock: Callable[[], float] = time.time,
        event_engine: Optional[EventEngine] = None,
        event_chance: Optional[float] = None,
        career_service: Optional[CareerService] = None,
        family_service: Optional[FamilyService] = None,
        crime_service: Optional[CrimeService] = None,
        shop_service: Optional[ShopService] = None,
        casino_service: Optional[CasinoService] = None,
        investing_service: Optional[InvestingService] = None,
        achievement_service: Optional[AchievementService] = None,
        death_service: Optional[DeathService] = None,
    ) -> None:
        self.db = db
        self.rng = rng
        self.locks = locks or UserLockRegistry()
        self.clock = clock
        self.events = event_engine or EventEngine(
            db,
            rng,
            self.locks,
            event_chance=event_chance,
        )
        self.careers = career_service or CareerService(db, rng, self.locks, clock=clock)
        self.family = family_service or FamilyService(db, rng, self.locks, clock=clock)
        self.crimes = crime_service or CrimeService(
            db, rng, self.locks, family_service=self.family, clock=clock
        )
        self.shop = shop_service or ShopService(db, rng, self.locks, clock=clock)
        self.casino = casino_service or CasinoService(db, rng, self.locks, clock=clock)
        self.investing = investing_service or InvestingService(db, rng, self.locks, clock=clock)
        self.legacy_repository = LegacyRepository(db)
        self.achievements = achievement_service or AchievementService(db, self.locks, clock=clock)
        self.death = death_service or DeathService(
            db, self.locks, clock=clock, achievements=self.achievements,
            family_service=self.family, crime_service=self.crimes, casino_service=self.casino,
        )

    async def create_character(
        self,
        user_id: int,
        name: str,
        *,
        gender: Gender | str = Gender.MALE,
        country: str = "usa",
        parent_char_id: Optional[int] = None,
        legacy_stat: Optional[str] = None,
        legacy_purchases: int = 0,
    ) -> Character:
        """Create one active life for a Discord user, starting at age zero."""
        if not isinstance(user_id, int) or user_id <= 0:
            raise ValidationError("A valid Discord user ID is required.")
        clean_name = self._validate_name(name)
        clean_country = self._validate_country(country)
        try:
            clean_gender = gender if isinstance(gender, Gender) else Gender(str(gender).lower())
        except ValueError as exc:
            raise ValidationError("Choose male, female, or non-binary.") from exc
        allowed_legacy_stats = {"health", "happiness", "smarts", "looks", "fitness", "karma"}
        if isinstance(legacy_purchases, bool) or legacy_purchases not in (0, 1, 2):
            raise ValidationError("Legacy purchases must be zero, one, or two.")
        if legacy_purchases == 0 and legacy_stat is not None:
            raise ValidationError("Choose a legacy stat only when spending legacy points.")
        if legacy_purchases > 0 and legacy_stat not in allowed_legacy_stats:
            raise ValidationError("Choose a valid starting stat for your legacy purchase.")

        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                cursor = await tx.execute(
                    "SELECT char_id FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
                    (user_id,),
                )
                if await cursor.fetchone():
                    raise CharacterAlreadyExists()
                now = int(self.clock())
                if legacy_purchases:
                    await self.legacy_repository.ensure_player(tx, user_id, now)
                await self.legacy_repository.close_pending_life_estates(tx, user_id, now)

                generation = 1
                if parent_char_id is not None:
                    cursor = await tx.execute(
                        "SELECT data_json FROM characters WHERE char_id = ?",
                        (parent_char_id,),
                    )
                    parent_row = await cursor.fetchone()
                    if parent_row is None:
                        raise ValidationError("The selected parent life could not be found.")
                    parent = Character.from_dict(json.loads(parent_row["data_json"]))
                    generation = parent.generation + 1

                stats, hidden, wealth_class = roll_birth_attributes(self.rng)
                character = Character(
                    user_id=user_id,
                    name=clean_name,
                    gender=clean_gender,
                    country=clean_country,
                    wealth_class=wealth_class,
                    age=0,
                    stats=stats,
                    hidden=hidden,
                    cash=0,
                    bank=0,
                    debt_total=0,
                    parent_char_id=parent_char_id,
                    generation=generation,
                    last_age_at=now,
                    born_at=now,
                )
                cursor = await tx.execute(
                    """INSERT INTO characters (
                           user_id, is_alive, name, gender, country, wealth_class, age,
                           stats_json, hidden_json, version, last_age_at, born_at,
                           died_at, death_cause, death_age, data_json
                       ) VALUES (?, 1, ?, ?, ?, ?, 0, ?, ?, 0, ?, ?, NULL, NULL, NULL, ?)""",
                    self._row_values(character),
                )
                char_id = int(cursor.lastrowid)
                character = replace(character, char_id=char_id)
                await self._refresh_data_json(tx, character)
                if legacy_purchases:
                    try:
                        await self.legacy_repository.spend_legacy_points(
                            tx, user_id=user_id, char_id=char_id, stat_name=str(legacy_stat),
                            purchase_count=legacy_purchases, now=now,
                        )
                    except ValueError as exc:
                        raise InsufficientFunds("You do not have enough legacy points for that starting-stat purchase.") from exc
                    boosted = replace(character.stats)
                    setattr(boosted, str(legacy_stat), min(100, getattr(boosted, str(legacy_stat)) + 5 * legacy_purchases))
                    character = replace(character, stats=boosted.clamp_all())
                    await self._refresh_data_json(tx, character)
                    await self.legacy_repository.audit_legacy_purchase(
                        tx, user_id=user_id, char_id=char_id, stat_name=str(legacy_stat),
                        purchase_count=legacy_purchases, now=now,
                    )
                await self.family.initialize_family(tx, character)
                await self.crimes.initialize_character(tx, character)
                await self._insert_log(
                    tx,
                    character,
                    age=0,
                    category="birth",
                    text=f"{clean_name} was born into a {wealth_class} household.",
                    importance=3,
                    created_at=now,
                )
                return character

    async def get_active_character(self, user_id: int) -> Character:
        """Return a user's active character or raise ``CharacterNotFound``."""
        row = await self.db.fetchone(
            "SELECT data_json FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        if row is None:
            latest = await self.db.fetchone(
                "SELECT data_json FROM characters WHERE user_id = ? ORDER BY char_id DESC LIMIT 1",
                (user_id,),
            )
            if latest is not None:
                raise CharacterDead()
            raise CharacterNotFound()
        return Character.from_dict(json.loads(row["data_json"]))

    async def age_up(self, user_id: int, *, guild_id: Optional[int] = None) -> YearOutcome:
        """Advance a year and run Stage 10 metrics, achievements, and death in the tick transaction."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                cursor = await tx.execute(
                    "SELECT data_json, version FROM characters "
                    "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
                    (user_id,),
                )
                row = await cursor.fetchone()
                if row is None:
                    # Distinguish a completed life from a user who never started.
                    cursor = await tx.execute(
                        "SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,)
                    )
                    if await cursor.fetchone():
                        raise CharacterDead()
                    raise CharacterNotFound()

                character = Character.from_dict(json.loads(row["data_json"]))
                # A pending choice must be resolved before the next simulated year.
                cursor = await tx.execute(
                    "SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1",
                    (character.char_id,),
                )
                if await cursor.fetchone():
                    raise PendingEventExists()
                await self.crimes.ensure_no_pending_decision(tx, character.char_id)
                await self.casino.require_no_active_hand(tx, character.char_id)
                await self.casino.require_no_pending_compulsion(tx, character.char_id)

                # Keep the database version authoritative if a caller's JSON was stale.
                character.version = int(row["version"])
                timestamp = int(self.clock())
                outcome = simulate_year(character, self.rng, now=timestamp)
                school_progress = advance_school_year(outcome.character)
                career_progress = await self.careers.advance_year(
                    tx,
                    school_progress.character,
                    previous_age=outcome.previous_age,
                    now=timestamp,
                )
                shop_progress = await self.shop.advance_year(
                    tx,
                    career_progress.character,
                    now=timestamp,
                )
                casino_progress = await self.casino.advance_year(
                    tx,
                    shop_progress.character,
                    previous_age=outcome.previous_age,
                    now=timestamp,
                )
                investment_progress = await self.investing.advance_year(
                    tx,
                    casino_progress.character,
                    previous_age=outcome.previous_age,
                    now=timestamp,
                    housing_upkeep_paid=shop_progress.character.is_alive and not shop_progress.character.in_prison,
                )
                career_income = max(0, career_progress.character.cash - school_progress.character.cash)
                personal_income = career_income + shop_progress.business_income + investment_progress.income_cents
                family_progress = await self.family.advance_year(
                    tx,
                    investment_progress.character,
                    previous_age=outcome.previous_age,
                    personal_income=personal_income,
                    now=timestamp,
                )
                crime_progress = await self.crimes.advance_year(
                    tx,
                    family_progress.character,
                    previous_age=outcome.previous_age,
                    personal_income=personal_income,
                    household_income=family_progress.household_income,
                    tax_assessed=family_progress.tax_assessed,
                    tax_paid=family_progress.tax_paid,
                    now=timestamp,
                )
                updated = replace(crime_progress.character, version=character.version + 1)
                all_messages = (
                    outcome.log_messages
                    + school_progress.messages
                    + career_progress.messages
                    + shop_progress.messages
                    + casino_progress.messages
                    + investment_progress.messages
                    + family_progress.messages
                    + crime_progress.messages
                )
                outcome = replace(outcome, character=updated, log_messages=all_messages)
                await self._save_character(tx, updated, expected_version=character.version)

                for message in outcome.log_messages:
                    if message.startswith("Life ended at age"):
                        category, importance = "death", 5
                    elif message in school_progress.messages:
                        category, importance = "education", 3
                    elif message in career_progress.messages:
                        category, importance = "career", 2
                    elif message in shop_progress.messages:
                        category, importance = "economy", 2
                    elif message in casino_progress.messages:
                        category, importance = "casino", 2
                    elif message in investment_progress.messages:
                        category, importance = "investing", 2
                    elif message in family_progress.messages:
                        category, importance = "family", 2
                    elif message in crime_progress.messages:
                        category, importance = ("prison" if "prison" in message.lower() else "crime"), 3
                    else:
                        category = "aging"
                        importance = 3 if "stage of life" in message else 1
                    await self._insert_log(
                        tx,
                        updated,
                        age=updated.age,
                        category=category,
                        text=message,
                        importance=importance,
                        created_at=timestamp,
                    )

                pending_event = None
                has_stage7_prompt = crime_progress.pending_trial is not None or crime_progress.pending_tax is not None
                if (updated.is_alive and not updated.in_prison and not has_stage7_prompt
                        and casino_progress.compulsion is None):
                    pending_event = await self.events.maybe_create_pending(
                        tx,
                        updated,
                        now=timestamp,
                    )
                    if pending_event is not None:
                        await self._insert_log(
                            tx,
                            updated,
                            age=updated.age,
                            category="event",
                            text=f"A choice event began: {pending_event.event.title}.",
                            importance=2,
                            created_at=timestamp,
                        )

                # Stage 10 step 15: record the annual observation, unlock from authoritative
                # records, then archive a death before this BEGIN IMMEDIATE transaction commits.
                await self.legacy_repository.record_life_year(
                    tx,
                    character=updated,
                    age=updated.age,
                    served_prison_year=character.in_prison,
                    now=timestamp,
                )
                unlocked = await self.achievements.check_user_in_tx(
                    tx, user_id, now=timestamp, guild_id=guild_id
                )
                death_result: Optional[DeathResult] = None
                if not updated.is_alive:
                    death_result = await self.death.handle_death(
                        tx, updated, now=timestamp, guild_id=guild_id
                    )

                newly_unlocked = {str(row["id"]): row for row in unlocked}
                if death_result is not None:
                    newly_unlocked.update(
                        (str(row["id"]), row)
                        for row in death_result.unlocked_achievements
                    )
                committed_unlocks = tuple(newly_unlocked.values())
                result = replace(
                    outcome,
                    character=updated,
                    pending_event=pending_event,
                    pending_trial=crime_progress.pending_trial,
                    pending_tax=crime_progress.pending_tax,
                    pending_compulsion=casino_progress.compulsion,
                    unlocked_achievements=committed_unlocks,
                    death_summary=death_result.summary if death_result is not None else None,
                    death_estate_id=death_result.estate_id if death_result is not None else None,
                    death_estate_nonce=death_result.estate_nonce if death_result is not None else None,
                    death_heirs=death_result.heirs if death_result is not None else (),
                    death_public_summary=death_result.public_summary if death_result is not None else False,
                )
            self.achievements.queue_notifications(user_id, committed_unlocks)
            return result

    @staticmethod
    def _validate_name(name: str) -> str:
        if not isinstance(name, str):
            raise ValidationError("Enter a character name.")
        clean = " ".join(name.split()).strip()
        if not clean or len(clean) > 32 or not _NAME_RE.fullmatch(clean):
            raise ValidationError("Name must be 1–32 characters and contain no control characters.")
        return clean

    @staticmethod
    def _validate_country(country: str) -> str:
        if not isinstance(country, str):
            raise ValidationError("Enter a country or region code.")
        clean = " ".join(country.split()).strip().lower()
        if not clean or len(clean) > 40 or not _NAME_RE.fullmatch(clean):
            raise ValidationError("Country or region must be 1–40 characters.")
        return clean

    @staticmethod
    def _row_values(character: Character) -> tuple[Any, ...]:
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        hidden_json = json.dumps({
            "genetic_health_mod": character.hidden.genetic_health_mod,
            "lifespan_mod": character.hidden.lifespan_mod,
            "luck": character.hidden.luck,
            "temperament": character.hidden.temperament,
        }, separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        return (
            character.user_id,
            character.name,
            character.gender.value,
            character.country,
            character.wealth_class,
            stats_json,
            hidden_json,
            character.last_age_at,
            character.born_at,
            data_json,
        )

    async def _refresh_data_json(self, tx: aiosqlite.Connection, character: Character) -> None:
        """Persist a newly assigned ID to the JSON snapshot."""
        await tx.execute(
            "UPDATE characters SET data_json = ? WHERE char_id = ?",
            (json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False), character.char_id),
        )

    async def _save_character(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        expected_version: int,
    ) -> None:
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        hidden_json = json.dumps({
            "genetic_health_mod": character.hidden.genetic_health_mod,
            "lifespan_mod": character.hidden.lifespan_mod,
            "luck": character.hidden.luck,
            "temperament": character.hidden.temperament,
        }, separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET
                   is_alive = ?, name = ?, gender = ?, country = ?, wealth_class = ?, age = ?,
                   stats_json = ?, hidden_json = ?, version = ?, last_age_at = ?,
                   died_at = ?, death_cause = ?, death_age = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (
                int(character.is_alive), character.name, character.gender.value,
                character.country, character.wealth_class, character.age,
                stats_json, hidden_json, character.version, character.last_age_at,
                character.died_at, character.death_cause, character.death_age,
                data_json, character.char_id, expected_version,
            ),
        )
        if cursor.rowcount != 1:
            raise ConcurrentUpdate()

    @staticmethod
    async def _insert_log(
        tx: aiosqlite.Connection,
        character: Character,
        *,
        age: int,
        category: str,
        text: str,
        importance: int,
        created_at: int,
    ) -> None:
        await tx.execute(
            """INSERT INTO life_logs (char_id, age, category, text, importance, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (character.char_id, age, category, text, importance, created_at),
        )
```

## `core/views.py`

```python
"""Reusable owner-checked Discord views for life-event choices."""
from __future__ import annotations

import logging
from typing import Any, Optional

import discord

from .achievements import AchievementService
from .errors import GameError
from .events import EventEngine, EventPrompt, EventResolution

logger = logging.getLogger("lifeline.views")


class OwnedView(discord.ui.View):
    """A view restricted to its owner and disabled after timeout."""

    def __init__(self, owner_id: int, nonce: str, *, timeout: float = 180.0):
        super().__init__(timeout=timeout)
        self.owner_id = int(owner_id)
        self.nonce = nonce
        self._bound_message: Optional[Any] = None

    def bind_message(self, message: Any) -> None:
        """Keep a reference so timeout can disable the visible controls."""
        self._bound_message = message

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                "Only the player who received this event can choose an option.",
                ephemeral=True,
            )
            return False
        return True

    async def on_timeout(self) -> None:
        for item in self.children:
            if hasattr(item, "disabled"):
                item.disabled = True
        if self._bound_message is not None:
            try:
                await self._bound_message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Could not disable timed-out event controls", exc_info=True)


class EventChoiceView(OwnedView):
    """Buttons for resolving one database-backed pending event."""

    def __init__(
        self,
        owner_id: int,
        prompt: EventPrompt,
        event_engine: EventEngine,
        *,
        achievement_service: Optional[AchievementService] = None,
        timeout: float = 180.0,
    ):
        super().__init__(owner_id, prompt.nonce, timeout=timeout)
        self.prompt = prompt
        self.event_engine = event_engine
        self.achievement_service = achievement_service
        for index, choice in enumerate(prompt.event.choices):
            self.add_item(_EventChoiceButton(choice, index, prompt.nonce))

    async def resolve(self, interaction: discord.Interaction, choice_id: str) -> None:
        try:
            result = await self.event_engine.resolve_choice(
                interaction.user.id,
                self.nonce,
                choice_id,
            )
        except GameError as exc:
            await interaction.response.send_message(exc.message, ephemeral=True)
            return

        for item in self.children:
            if hasattr(item, "disabled"):
                item.disabled = True
        embed = _resolution_embed(result)
        await interaction.response.edit_message(embed=embed, view=None)
        self.stop()
        if self.achievement_service is not None:
            try:
                await self.achievement_service.check_user(
                    interaction.user.id, guild_id=interaction.guild_id
                )
                notices = self.achievement_service.consume_notifications(interaction.user.id)
                if notices:
                    lines = [
                        f"🏆 **{discord.utils.escape_markdown(discord.utils.escape_mentions(str(row['name'])))}**"
                        for row in notices[:5]
                    ]
                    if len(notices) > 5:
                        lines.append(f"…and {len(notices) - 5} more achievement(s)")
                    notice = discord.Embed(
                        title="Achievement unlocked!" if len(notices) == 1 else "Achievements unlocked!",
                        description="\n".join(lines), color=discord.Color.gold(),
                    )
                    await interaction.followup.send(
                        embed=notice, ephemeral=True,
                        allowed_mentions=discord.AllowedMentions.none(),
                    )
            except Exception:
                logger.exception("Could not check event-choice achievements for user %s", interaction.user.id)


class _EventChoiceButton(discord.ui.Button[EventChoiceView]):
    def __init__(self, choice: Any, index: int, nonce: str):
        super().__init__(
            label=choice.label,
            style=discord.ButtonStyle.primary if index == 0 else discord.ButtonStyle.secondary,
            custom_id=f"life:event:{nonce}:{choice.id}",
            row=index // 2,
        )
        self.choice_id = choice.id

    async def callback(self, interaction: discord.Interaction) -> None:
        view = self.view
        if isinstance(view, EventChoiceView):
            await view.resolve(interaction, self.choice_id)


def event_embed(prompt: EventPrompt, *, lead: Optional[str] = None) -> discord.Embed:
    """Render an event and its choices into a Discord-friendly embed."""
    polarity_colors = {
        "positive": discord.Color.green(),
        "negative": discord.Color.orange(),
        "neutral": discord.Color.blurple(),
    }
    description = prompt.event.description
    if lead:
        description = f"{lead}\n\n{description}"
    embed = discord.Embed(
        title=f"✨ {prompt.event.title}",
        description=description,
        color=polarity_colors[prompt.event.polarity.value],
    )
    for index, choice in enumerate(prompt.event.choices, start=1):
        value = choice.description or "Select this option to continue."
        embed.add_field(name=f"{index}. {choice.label}", value=value, inline=False)
    embed.set_footer(text=f"Age {prompt.age} · Choose an option; unresolved events are saved")
    return embed


def _resolution_embed(result: EventResolution) -> discord.Embed:
    changes = []
    for stat, delta in result.stat_changes.items():
        name = stat.replace("_", " ").title()
        changes.append(f"{name} {'+' if delta > 0 else ''}{delta}")
    description = f"You chose **{result.choice.label}**.\n\n{result.choice.description}"
    description += "\n\n**Stat changes:** " + (" · ".join(changes) if changes else "No stat changes.")
    embed = discord.Embed(
        title=f"Event resolved · {result.event.title}",
        description=description,
        color=discord.Color.green(),
    )
    embed.set_footer(text=f"{result.character.name} · Age {result.character.age}")
    return embed
```

## `cogs/legacy.py`

```python
"""Stage 10 slash commands for legacy, achievements, leaderboards, and retirement."""
from __future__ import annotations

import json
import time
from typing import Any, Optional

import discord
from discord import app_commands
from discord.ext import commands

from core.achievements import AchievementService
from core.death import DeathService
from core.errors import GameError, ValidationError
from core.leaderboard import LeaderboardService, METRICS
from core.money import format_cents
from core.life_engine import LifeEngine
from core.locks import UserLockRegistry
from core.models import Character
from core.repositories.legacy import LegacyRepository
from core.rng import RNG
from cogs.legacy_views import (
    EmbedPager,
    HeirSelectView,
    RetirementConfirmView,
    death_summary_embed,
    leaderboard_embed,
)

_METRIC_CHOICES = [
    app_commands.Choice(name=label, value=key) for key, label in METRICS.items()
]
_SCOPE_CHOICES = [
    app_commands.Choice(name="Server", value="server"),
    app_commands.Choice(name="Global", value="global"),
]
_PERIOD_CHOICES = [
    app_commands.Choice(name="Current life", value="current"),
    app_commands.Choice(name="All time", value="all_time"),
]
_LEGACY_STAT_CHOICES = [
    app_commands.Choice(name="Health", value="health"),
    app_commands.Choice(name="Happiness", value="happiness"),
    app_commands.Choice(name="Smarts", value="smarts"),
    app_commands.Choice(name="Looks", value="looks"),
    app_commands.Choice(name="Fitness", value="fitness"),
    app_commands.Choice(name="Karma", value="karma"),
]
_PURCHASE_CHOICES = [
    app_commands.Choice(name="No purchase", value=0),
    app_commands.Choice(name="One purchase · 50 points · +5", value=1),
    app_commands.Choice(name="Two purchases · 100 points · +10", value=2),
]


def _safe(value: Any, limit: int = 160) -> str:
    """Escape markdown and mention syntax for all stored/user-facing text."""
    return discord.utils.escape_mentions(discord.utils.escape_markdown(str(value)))[:limit]


def _pages(title: str, entries: list[str], *, color: discord.Color) -> list[discord.Embed]:
    """Create pages with ten entries each, respecting Discord description limits."""
    if not entries:
        return [discord.Embed(title=title, description="No records to display yet.", color=color)]
    result: list[discord.Embed] = []
    for start in range(0, len(entries), 10):
        group = entries[start:start + 10]
        embed = discord.Embed(title=title, description="\n".join(group), color=color)
        embed.set_footer(text=f"Page {start // 10 + 1} of {(len(entries) + 9) // 10}")
        result.append(embed)
    return result


class LegacyCog(commands.Cog):
    """Player-facing Stage 10 commands; all persistence stays in services/repositories."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.db = bot.db
        self.locks: UserLockRegistry = getattr(bot, "locks", UserLockRegistry())
        self.achievements: AchievementService = getattr(bot, "achievement_service", None) or AchievementService(
            self.db, self.locks
        )
        self.leaderboards = LeaderboardService(self.db, self.achievements, self.locks)
        self.engine: LifeEngine = getattr(bot, "life_engine", None) or LifeEngine(
            self.db,
            getattr(bot, "rng", RNG()),
            self.locks,
            family_service=getattr(bot, "family_service", None),
            crime_service=getattr(bot, "crime_service", None),
            shop_service=getattr(bot, "shop_service", None),
            casino_service=getattr(bot, "casino_service", None),
            investing_service=getattr(bot, "investing_service", None),
            achievement_service=self.achievements,
        )
        self.death: DeathService = self.engine.death
        self.repository = LegacyRepository(self.db)

    @app_commands.command(name="leaderboard", description="Rank players by a life, wealth, fame, or activity metric")
    @app_commands.describe(
        metric="What to rank players by",
        scope="Rank players seen in this server or across the bot",
        period="Compare current lives or each player's all-time record",
    )
    @app_commands.choices(metric=_METRIC_CHOICES, scope=_SCOPE_CHOICES, period=_PERIOD_CHOICES)
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def leaderboard(
        self,
        interaction: discord.Interaction,
        metric: str,
        scope: str = "server",
        period: str = "current",
    ) -> None:
        """Display the requested leaderboard in owner-controlled pages of ten."""
        await interaction.response.defer(thinking=True, ephemeral=False)
        result = await self.leaderboards.get_leaderboard(
            interaction.user.id,
            metric=metric,
            scope=scope,
            period=period,
            guild_id=interaction.guild_id,
        )
        pages = [leaderboard_embed(result, page) for page in range(max(1, (len(result.entries) + 9) // 10))]
        view = EmbedPager(interaction.user.id, pages)
        message = await interaction.followup.send(
            embed=pages[0], view=view, wait=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        view.bind_message(message)

    @app_commands.command(name="achievements", description="View earned achievements for yourself or another player")
    @app_commands.describe(user="Optional player whose public achievements you want to view")
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def achievements(
        self,
        interaction: discord.Interaction,
        user: Optional[discord.User] = None,
    ) -> None:
        """List catalog achievements earned from authoritative game records."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        target = user or interaction.user
        if int(target.id) != int(interaction.user.id) and await self.leaderboards.is_opted_out(int(target.id)):
            raise ValidationError("That player's public profile is private.")
        rows = await self.achievements.list_for_user(int(target.id))
        if not rows:
            await interaction.followup.send(
                f"{_safe(getattr(target, 'display_name', target.name), 80)} has no unlocked achievements yet.",
                ephemeral=True,
                allowed_mentions=discord.AllowedMentions.none(),
            )
            return
        descriptions = [
            f"🏆 **{_safe(row['name'], 80)}** · {_safe(row['description'], 170)}\n"
            f"_{_safe(row['category'].title(), 30)} · {_safe(row.get('character_name', 'Life'), 48)}_"
            for row in rows
        ]
        pages = _pages(
            f"{_safe(getattr(target, 'display_name', target.name), 80)} · Achievements ({len(rows)})",
            descriptions,
            color=discord.Color.gold(),
        )
        view = EmbedPager(interaction.user.id, pages)
        message = await interaction.followup.send(
            embed=pages[0], view=view, ephemeral=True, wait=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        view.bind_message(message)

    lives = app_commands.Group(name="lives", description="Review your immutable life archive")

    @lives.command(name="list", description="List your most recent archived lives")
    @app_commands.checks.cooldown(1, 4.0, key=lambda interaction: interaction.user.id)
    async def lives_list(self, interaction: discord.Interaction) -> None:
        """List archived lives newest-first; view numbers use the same ordering."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        async with self.locks.hold(interaction.user.id):
            async with self.db.transaction() as tx:
                rows = await self.repository.user_past_lives(tx, interaction.user.id, 100)
        descriptions = [
            f"**Life {index}.** Age {int(row['death_age'])} · Grade **{_safe(row['grade'], 1)}** · "
            f"Score {float(row['life_score']):.2f} · Legacy points {int(row['legacy_points'])}\n"
            f"Cause: {_safe(row['death_cause'], 90)} · Estate: {format_cents(int(row['estate_cents']))}"
            for index, row in enumerate(rows, start=1)
        ]
        pages = _pages("Your archived lives · newest first", descriptions, color=discord.Color.dark_grey())
        view = EmbedPager(interaction.user.id, pages)
        message = await interaction.followup.send(
            embed=pages[0], view=view, ephemeral=True, wait=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        view.bind_message(message)

    @lives.command(name="view", description="Open one archived life (1 is the most recent)")
    @app_commands.describe(number="Archive position, where 1 is your most recent life")
    @app_commands.checks.cooldown(1, 4.0, key=lambda interaction: interaction.user.id)
    async def lives_view(
        self,
        interaction: discord.Interaction,
        number: app_commands.Range[int, 1, 1000],
    ) -> None:
        """Render one immutable past-life summary without exposing another player."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        async with self.locks.hold(interaction.user.id):
            async with self.db.transaction() as tx:
                rows = await self.repository.user_past_lives(tx, interaction.user.id, int(number))
        if len(rows) < number:
            raise ValidationError("That archive position does not exist. Use `/lives list` to review your lives.")
        row = rows[number - 1]
        summary = json.loads(str(row["summary_json"]))
        definitions = {str(item["id"]): str(item["name"]) for item in self.achievements.definitions}
        avatar = getattr(getattr(interaction.user, "display_avatar", None), "url", None)
        embed = death_summary_embed(summary, avatar_url=avatar, achievement_names=definitions)
        embed.title = f"Archived life · {number}"
        await interaction.followup.send(
            embed=embed, ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @app_commands.command(name="graveyard", description="Browse recent public life archives")
    @app_commands.describe(scope="Show deaths from this server or across the bot")
    @app_commands.choices(scope=_SCOPE_CHOICES)
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def graveyard(self, interaction: discord.Interaction, scope: str = "global") -> None:
        """Browse recent naturally completed lives, excluding opted-out accounts."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        if scope not in {"server", "global"}:
            raise ValidationError("Graveyard scope must be server or global.")
        if scope == "server" and interaction.guild_id is None:
            raise ValidationError("A server graveyard is only available inside a server.")
        async with self.locks.hold(interaction.user.id):
            async with self.db.transaction() as tx:
                rows = await self.repository.recent_deaths(tx, 100)
                if scope == "server":
                    seen = set(await self.repository.seen_guild_users(tx, int(interaction.guild_id)))
                    rows = [row for row in rows if int(row["user_id"]) in seen]
        descriptions = [
            f"**{_safe(row['name'], 70)}** · Age {int(row['death_age'])} · Grade **{_safe(row['grade'], 1)}**\n"
            f"{_safe(row['death_cause'], 90)} · {_safe(row.get('summary_json') and json.loads(row['summary_json']).get('epitaph', ''), 150)}"
            for row in rows
        ]
        pages = _pages("Recent lives remembered", descriptions, color=discord.Color.dark_grey())
        view = EmbedPager(interaction.user.id, pages)
        message = await interaction.followup.send(
            embed=pages[0], view=view, ephemeral=True, wait=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        view.bind_message(message)

    @app_commands.command(name="inheritance", description="Reopen a pending heir choice after a death")
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def inheritance(self, interaction: discord.Interaction) -> None:
        """Reopen a still-pending owner/nonce-bound estate selection."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        async with self.locks.hold(interaction.user.id):
            async with self.db.transaction() as tx:
                estate = await self.repository.pending_life_estate(tx, interaction.user.id)
        if estate is None:
            raise ValidationError("You have no pending inheritance choice. Use `/start` for a fresh life.")
        heirs = json.loads(str(estate["eligible_heirs_json"]))
        view = HeirSelectView(
            interaction.user.id, int(estate["estate_id"]), str(estate["nonce"]),
            heirs, self.death,
        )
        embed = discord.Embed(
            title="Continue the family line?",
            description=(
                "Choose one of your living adult children. The after-tax estate is split across "
                "all eligible adult children. You can also close the estate and start fresh."
            ),
            color=discord.Color.gold(),
        )
        message = await interaction.followup.send(
            embed=embed, view=view, ephemeral=True, wait=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        view.bind_message(message)

    @app_commands.command(name="retire_life", description="Abandon your current life after confirmation")
    @app_commands.checks.cooldown(1, 10.0, key=lambda interaction: interaction.user.id)
    async def retire_life(self, interaction: discord.Interaction) -> None:
        """Open an owner- and nonce-bound confirmation; no legacy or heir reward is granted."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        prompt = await self.death.begin_retirement(interaction.user.id)
        definitions = {str(item["id"]): str(item["name"]) for item in self.achievements.definitions}
        avatar = getattr(getattr(interaction.user, "display_avatar", None), "url", None)
        view = RetirementConfirmView(
            interaction.user.id, prompt, self.death,
            achievement_names=definitions, avatar_url=avatar,
        )
        embed = discord.Embed(
            title="Confirm life abandonment",
            description=(
                "Retiring ends this life permanently. It will be archived as **Life abandoned**; "
                "you receive no legacy points, no heir continuation, and no debt is transferred. "
                "This confirmation expires in one minute."
            ),
            color=discord.Color.orange(),
        )
        message = await interaction.followup.send(embed=embed, view=view, ephemeral=True, wait=True)
        view.bind_message(message)

    @app_commands.command(name="start", description="Begin a fresh life, optionally spending cosmetic legacy points")
    @app_commands.describe(
        name="Your character's name",
        gender="Character gender",
        country="Country or region code, such as usa or in",
        legacy_stat="Optional starting stat to improve with earned legacy points",
        purchases="Spend 50 points per +5, up to two purchases in this life",
    )
    @app_commands.choices(
        gender=[
            app_commands.Choice(name="Male", value="male"),
            app_commands.Choice(name="Female", value="female"),
            app_commands.Choice(name="Non-binary", value="non_binary"),
        ],
        legacy_stat=_LEGACY_STAT_CHOICES,
        purchases=_PURCHASE_CHOICES,
    )
    @app_commands.checks.cooldown(1, 8.0, key=lambda interaction: interaction.user.id)
    async def start(
        self,
        interaction: discord.Interaction,
        name: str,
        gender: str = "male",
        country: str = "usa",
        legacy_stat: Optional[str] = None,
        purchases: int = 0,
    ) -> None:
        """Start a new life; legacy spending changes only one capped starting stat."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        character = await self.engine.create_character(
            interaction.user.id,
            name,
            gender=gender,
            country=country,
            legacy_stat=legacy_stat,
            legacy_purchases=purchases,
        )
        from cogs.life import _character_embed
        embed = _character_embed(character)
        if purchases:
            embed.description = (
                f"Spent **{purchases * 50} legacy points** on +{5 * purchases} {legacy_stat}. "
                "No money bonus was applied.\n\n" + (embed.description or "")
            )
        embed.set_footer(text=f"Generation {character.generation} · Legacy is cosmetic only")
        await interaction.followup.send(
            embed=embed, ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @app_commands.command(name="leaderboard_privacy", description="Opt out of public leaderboards and public profile summaries")
    @app_commands.describe(opt_out="Hide your account from public ranking, achievement, and graveyard views")
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def leaderboard_privacy(self, interaction: discord.Interaction, opt_out: bool) -> None:
        """Set the simple per-player public-profile visibility flag."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        await self.leaderboards.set_opt_out(interaction.user.id, opt_out)
        status = "hidden" if opt_out else "visible"
        await interaction.followup.send(
            f"Your public leaderboard/profile preference is now **{status}**.",
            ephemeral=True,
        )

    @app_commands.command(name="guild_death_summaries", description="Choose whether death summaries may post publicly in this server")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.describe(public="Allow public death summaries in the channel where `/life age` is used")
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def guild_death_summaries(self, interaction: discord.Interaction, public: bool) -> None:
        """Set a guild-level public obituary option; account privacy opt-out still wins."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        if interaction.guild_id is None:
            raise ValidationError("This setting is only available in a server.")
        async with self.locks.hold(interaction.user.id):
            async with self.db.transaction() as tx:
                await self.repository.set_guild_public_death_summaries(
                    tx,
                    guild_id=int(interaction.guild_id),
                    enabled=public,
                    user_id=interaction.user.id,
                    now=int(time.time()),
                )
        state = "enabled" if public else "disabled"
        await interaction.followup.send(
            f"Public death summaries are now **{state}** for this server. A player's privacy opt-out always takes priority.",
            ephemeral=True,
        )


async def setup(bot: commands.Bot) -> None:
    """Load the Stage 10 command cog."""
    await bot.add_cog(LegacyCog(bot))
```

## `cogs/legacy_views.py`

```python
"""Owner-checked, nonce-protected Stage 10 Discord views and summary rendering."""
from __future__ import annotations

import logging
import secrets
from datetime import datetime, timezone
from typing import Any, Optional, Sequence

import discord

from core.achievements import AchievementService
from core.death import DeathService, RetirementPrompt
from core.errors import GameError
from core.leaderboard import LeaderboardResult, METRICS
from core.money import format_cents

logger = logging.getLogger("lifeline.legacy.views")


def _safe_text(value: Any, limit: int = 180) -> str:
    """Escape markdown and mention syntax before placing stored text in an embed."""
    text = discord.utils.escape_mentions(discord.utils.escape_markdown(str(value)))
    return text[:limit]


async def check_and_notify_achievements(
    interaction: discord.Interaction,
    service: Optional[AchievementService],
    user_id: int,
) -> None:
    """Recheck after a component action and send a compact unlock embed if needed."""
    if service is None:
        return
    try:
        await service.check_user(int(user_id), guild_id=interaction.guild_id)
        notices = service.consume_notifications(int(user_id))
        if not notices:
            return
        lines = [
            f"🏆 **{_safe_text(row.get('name', 'Achievement'), 80)}** — "
            f"{_safe_text(row.get('description', ''), 180)}"
            for row in notices[:5]
        ]
        if len(notices) > 5:
            lines.append(f"…and {len(notices) - 5} more achievement(s)")
        embed = discord.Embed(
            title="Achievement unlocked!" if len(notices) == 1 else "Achievements unlocked!",
            description="\n".join(lines),
            color=discord.Color.gold(),
        )
        await interaction.followup.send(
            embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none()
        )
    except Exception:
        logger.exception("Could not award component-triggered achievements for user %s", user_id)


def _calendar_year(timestamp: Any) -> str:
    """Format a persisted Unix timestamp as a UTC calendar year, failing closed."""
    try:
        return str(datetime.fromtimestamp(int(timestamp), tz=timezone.utc).year)
    except (OverflowError, OSError, TypeError, ValueError):
        return "unknown"


def death_summary_embed(
    summary: dict[str, Any],
    *,
    avatar_url: Optional[str] = None,
    achievement_names: Optional[dict[str, str]] = None,
) -> discord.Embed:
    """Render the archived life portrait, milestones, estate, and grade into an embed."""
    name = _safe_text(summary.get("name", "Unknown life"), 80)
    age = int(summary.get("death_age", 0))
    cause = _safe_text(summary.get("death_cause", "unknown causes"), 160)
    epitaph = _safe_text(summary.get("epitaph", "Their story lives on in those they touched."), 300)
    embed = discord.Embed(
        title="A life remembered",
        description=f"*{epitaph}*",
        color=discord.Color.dark_grey(),
    )
    if avatar_url:
        embed.set_author(name=f"{name} · Age {age}", icon_url=avatar_url)
    else:
        embed.set_author(name=f"{name} · Age {age}")
    years = f"{_calendar_year(summary.get('born_at'))}–{_calendar_year(summary.get('died_at'))}"
    embed.add_field(
        name="Years and cause",
        value=f"{years} · Age {age} · {cause}\nGeneration {int(summary.get('generation', 1))}",
        inline=True,
    )
    embed.add_field(
        name="Life score",
        value=f"**{float(summary.get('life_score', 0.0)):.2f}/100 · Grade {summary.get('grade', 'F')}**\n"
              f"Legacy points earned: {int(summary.get('legacy_points', 0))}",
        inline=True,
    )
    education = summary.get("education") or {}
    education_text = str(education.get("level", "none")).replace("_", " ").title()
    if education.get("major"):
        education_text += f" · {_safe_text(education['major'], 70)}"
    if education.get("gpa") is not None:
        education_text += f" · GPA {float(education['gpa']):.2f}"
    careers = summary.get("careers") or []
    career_lines = [
        f"{_safe_text(str(row.get('career_id', 'career')).replace('_', ' ').title(), 60)} "
        f"(level {int(row.get('max_level', 0))}, ages {int(row.get('start_age', 0))}–"
        f"{int(row.get('end_age') if row.get('end_age') is not None else age)})"
        for row in careers[:5]
    ]
    if len(careers) > 5:
        career_lines.append(f"…and {len(careers) - 5} more career(s)")
    embed.add_field(
        name="Education and careers",
        value=f"Education: {education_text}\n" + ("\n".join(career_lines) or "No recorded career history."),
        inline=False,
    )
    peak = int(summary.get("peak_net_worth_cents", 0))
    final = int(summary.get("final_net_worth_cents", 0))
    assets = int(summary.get("gross_assets_cents", 0))
    debt_paid = int(summary.get("debts_paid_cents", 0))
    tax = int(summary.get("estate_tax_cents", 0))
    estate = int(summary.get("estate_cents", 0))
    embed.add_field(
        name="Financial life",
        value=(
            f"Peak net worth: {format_cents(peak)}\nFinal net worth: {format_cents(final)}\n"
            f"Gross estate: {format_cents(assets)} · Debts paid: {format_cents(debt_paid)}\n"
            f"Estate tax: {format_cents(tax)} · Remaining estate: {format_cents(estate)}"
        ),
        inline=True,
    )
    children = summary.get("children") or []
    marriages = summary.get("marriages") or []
    names = [
        _safe_text(row.get("name", "Child"), 48)
        for row in children[:6]
    ]
    if len(children) > 6:
        names.append(f"…and {len(children) - 6} more")
    family_text = (
        f"Marriages: {int(summary.get('marriage_count', len(marriages)))} · "
        f"Longest: {int(summary.get('marriage_years', 0))} years\n"
        f"Children: {int(summary.get('child_count', len(children)))}"
    )
    if names:
        family_text += "\n" + ", ".join(names)
    embed.add_field(name="Family", value=family_text, inline=True)
    crime = summary.get("crime") or {}
    embed.add_field(
        name="Crime and prison",
        value=(
            f"Attempts: {int(crime.get('attempts', 0))} · Successful: {int(crime.get('successes', 0))}\n"
            f"Unsealed convictions: {int(crime.get('convictions', 0))} · Sealed: {int(crime.get('sealed_convictions', 0))}\n"
            f"Years served: {int(crime.get('years_in_prison', 0))} · Escaped: {'Yes' if crime.get('escaped') else 'No'}"
        ),
        inline=False,
    )
    logs = summary.get("life_log_top") or []
    for page_start in range(0, min(len(logs), 10), 5):
        page = logs[page_start:page_start + 5]
        value = "\n".join(
            f"**Age {int(row.get('age', 0))} · {int(row.get('importance', 1))}/5** — "
            f"{_safe_text(row.get('text', ''), 150)}"
            for row in page
        )
        embed.add_field(name=f"Important moments · {page_start + 1}–{page_start + len(page)}", value=value or "None", inline=False)
    earned = summary.get("achievements") or []
    labels = achievement_names or {}
    award_names = [
        _safe_text(labels.get(str(row.get("achievement_id", "")), str(row.get("achievement_id", "")).replace("_", " ").title()), 64)
        for row in earned
    ]
    if len(award_names) > 16:
        award_names = award_names[:16] + [f"…and {len(earned) - 16} more"]
    embed.add_field(
        name=f"Achievements earned this life · {len(earned)}",
        value=", ".join(award_names) if award_names else "No achievements were recorded during this life.",
        inline=False,
    )
    embed.set_footer(text=f"Life #{int(summary.get('char_id', 0))} · Average yearly happiness {float(summary.get('average_happiness', 0.0)):.1f}/100")
    return embed


def leaderboard_embed(result: LeaderboardResult, page: int, page_size: int = 10) -> discord.Embed:
    """Render one deterministic page of ten leaderboard entries."""
    start = page * page_size
    entries = result.entries[start:start + page_size]
    label = METRICS[result.metric]
    lines: list[str] = []
    for row in entries:
        value = row["value"]
        if result.metric == "net_worth":
            rendered = format_cents(int(value))
        elif result.metric == "life_score":
            rendered = f"{float(value):.2f}"
        elif result.metric == "gambling":
            rendered = format_cents(int(value))
        else:
            rendered = f"{int(value):,}"
        lines.append(f"**{int(row['rank']):>3}.** Player `{int(row['user_id'])}` — **{rendered}**")
    scope_text = "this server" if result.scope == "server" else "global"
    period_text = "current life" if result.period == "current" else "all-time"
    embed = discord.Embed(
        title=f"{label} leaderboard",
        description="\n".join(lines) if lines else "No eligible players are recorded for this ranking yet.",
        color=discord.Color.blurple(),
    )
    embed.set_footer(text=f"{scope_text.title()} · {period_text.title()} · Sorted by score, then account ID")
    return embed


class EmbedPager(discord.ui.View):
    """Owner-only, nonce-protected pager for read-only leaderboard/archive pages."""

    def __init__(self, owner_id: int, embeds: Sequence[discord.Embed], *, timeout: float = 180.0) -> None:
        super().__init__(timeout=timeout)
        self.owner_id = int(owner_id)
        self.nonce = secrets.token_urlsafe(10)
        self.embeds = tuple(embeds) or (discord.Embed(description="No results."),)
        self.page = 0
        self._message: Optional[discord.Message] = None
        previous = discord.ui.Button(
            label="Previous", style=discord.ButtonStyle.secondary,
            custom_id=f"legacy-page:{self.nonce}:previous", row=0,
        )
        next_page = discord.ui.Button(
            label="Next", style=discord.ButtonStyle.primary,
            custom_id=f"legacy-page:{self.nonce}:next", row=0,
        )
        previous.callback = self.previous
        next_page.callback = self.next
        self.add_item(previous)
        self.add_item(next_page)
        self._sync_buttons()

    def bind_message(self, message: discord.Message) -> None:
        """Remember the sent message for timeout control removal."""
        self._message = message

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        """Require the owning player and a custom ID bearing this view's nonce."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Only the player who opened these pages can navigate them.", ephemeral=True)
            return False
        custom_id = (interaction.data or {}).get("custom_id", "")
        if not str(custom_id).startswith(f"legacy-page:{self.nonce}:"):
            await interaction.response.send_message("This page control is stale. Reopen the command.", ephemeral=True)
            return False
        return True

    async def previous(self, interaction: discord.Interaction) -> None:
        """Show the preceding page and disable unavailable controls."""
        self.page = max(0, self.page - 1)
        self._sync_buttons()
        await interaction.response.edit_message(embed=self.embeds[self.page], view=self)

    async def next(self, interaction: discord.Interaction) -> None:
        """Show the following page and disable unavailable controls."""
        self.page = min(len(self.embeds) - 1, self.page + 1)
        self._sync_buttons()
        await interaction.response.edit_message(embed=self.embeds[self.page], view=self)

    def _sync_buttons(self) -> None:
        """Disable navigation at page boundaries."""
        for child in self.children:
            if isinstance(child, discord.ui.Button):
                child.disabled = (
                    (child.label == "Previous" and self.page == 0)
                    or (child.label == "Next" and self.page >= len(self.embeds) - 1)
                )

    async def on_timeout(self) -> None:
        """Disable controls when the page interaction expires."""
        self.disable_all_items()
        if self._message is not None:
            try:
                await self._message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Could not disable a timed-out Stage 10 pager", exc_info=True)


class HeirSelectView(discord.ui.View):
    """Owner-checked paginated heir selection with a fresh-life escape option."""

    def __init__(
        self,
        owner_id: int,
        estate_id: int,
        nonce: str,
        heirs: Sequence[dict[str, Any]],
        service: DeathService,
        *,
        page: int = 0,
        timeout: float = 600.0,
    ) -> None:
        super().__init__(timeout=timeout)
        self.owner_id = int(owner_id)
        self.estate_id = int(estate_id)
        self.nonce = nonce
        self.heirs = tuple(sorted((dict(row) for row in heirs), key=lambda row: int(row["npc_id"])))
        self.service = service
        self.page = max(0, page)
        self._used = False
        self._message: Optional[discord.Message] = None
        self._render_select()
        previous = discord.ui.Button(
            label="Previous heirs", style=discord.ButtonStyle.secondary,
            custom_id=f"estate:{self.nonce}:previous", row=1,
            disabled=self.page == 0,
        )
        next_page = discord.ui.Button(
            label="More heirs", style=discord.ButtonStyle.secondary,
            custom_id=f"estate:{self.nonce}:next", row=1,
            disabled=(self.page + 1) * 25 >= len(self.heirs),
        )
        fresh = discord.ui.Button(
            label="Start a fresh life", style=discord.ButtonStyle.danger,
            custom_id=f"estate:{self.nonce}:fresh", row=1,
        )
        previous.callback = self.previous
        next_page.callback = self.next
        fresh.callback = self.start_fresh
        self.add_item(previous)
        self.add_item(next_page)
        self.add_item(fresh)

    def bind_message(self, message: discord.Message) -> None:
        """Remember the message so controls are disabled after timeout."""
        self._message = message

    def _render_select(self) -> None:
        """Render one page of up to 25 eligible heirs."""
        start = self.page * 25
        page_rows = self.heirs[start:start + 25]
        options = [
            discord.SelectOption(
                label=_safe_text(row.get("name", "Heir"), 100),
                value=str(int(row["npc_id"])),
                description=_safe_text(
                    f"Age {int(row['age'])} · inherits {format_cents(int(row.get('inheritance_cents', 0)))}",
                    100,
                ),
            )
            for row in page_rows
        ]
        select = discord.ui.Select(
            placeholder="Choose a living adult child to continue the family",
            min_values=1,
            max_values=1,
            options=options,
            custom_id=f"estate:{self.nonce}:select:{self.page}",
            row=0,
        )
        select.callback = self.choose
        self.add_item(select)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        """Require the estate owner, current nonce, and an unused selection."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This inheritance choice belongs to another player.", ephemeral=True)
            return False
        custom_id = (interaction.data or {}).get("custom_id", "")
        if self._used or not str(custom_id).startswith(f"estate:{self.nonce}:"):
            await interaction.response.send_message("This inheritance choice is stale or already used.", ephemeral=True)
            return False
        return True

    async def choose(self, interaction: discord.Interaction) -> None:
        """Validate and continue as the selected child in one transaction."""
        try:
            selected_id = int((interaction.data or {}).get("values", ["0"])[0])
            heir = await self.service.choose_heir(
                self.owner_id, self.estate_id, self.nonce, selected_id
            )
        except (ValueError, GameError) as exc:
            message = exc.message if isinstance(exc, GameError) else "That heir selection is invalid."
            await interaction.response.send_message(message, ephemeral=True)
            return
        self._finish()
        name = _safe_text(heir.name if heir is not None else "your heir", 80)
        age = heir.age if heir is not None else 0
        await interaction.response.edit_message(
            content=f"The family continues with **{name}**, age {age}. Inheritance was split among eligible adult children.",
            embed=None,
            view=self,
        )
        await self._send_unlock_notices(interaction)

    async def start_fresh(self, interaction: discord.Interaction) -> None:
        """Close the pending estate without transferring money so `/start` can begin fresh."""
        try:
            await self.service.choose_heir(self.owner_id, self.estate_id, self.nonce, None)
        except GameError as exc:
            await interaction.response.send_message(exc.message, ephemeral=True)
            return
        self._finish()
        await interaction.response.edit_message(
            content="Inheritance declined. Use `/start` to begin a fresh life; no estate was transferred.",
            embed=None,
            view=self,
        )

    async def previous(self, interaction: discord.Interaction) -> None:
        """Display the prior page of eligible heirs."""
        if self.page <= 0:
            await interaction.response.send_message("There are no earlier heirs.", ephemeral=True)
            return
        self.page -= 1
        self._rebuild()
        await interaction.response.edit_message(view=self)

    async def next(self, interaction: discord.Interaction) -> None:
        """Display the next page of eligible heirs."""
        if (self.page + 1) * 25 >= len(self.heirs):
            await interaction.response.send_message("There are no more heirs.", ephemeral=True)
            return
        self.page += 1
        self._rebuild()
        await interaction.response.edit_message(view=self)

    def _rebuild(self) -> None:
        """Recreate the select menu and synchronize paging buttons."""
        self.clear_items()
        self._render_select()
        previous = discord.ui.Button(
            label="Previous heirs", style=discord.ButtonStyle.secondary,
            custom_id=f"estate:{self.nonce}:previous", row=1, disabled=self.page == 0,
        )
        next_page = discord.ui.Button(
            label="More heirs", style=discord.ButtonStyle.secondary,
            custom_id=f"estate:{self.nonce}:next", row=1,
            disabled=(self.page + 1) * 25 >= len(self.heirs),
        )
        fresh = discord.ui.Button(
            label="Start a fresh life", style=discord.ButtonStyle.danger,
            custom_id=f"estate:{self.nonce}:fresh", row=1,
        )
        previous.callback = self.previous
        next_page.callback = self.next
        fresh.callback = self.start_fresh
        self.add_item(previous)
        self.add_item(next_page)
        self.add_item(fresh)

    def _finish(self) -> None:
        """Disable this one-use inheritance menu."""
        self._used = True
        self.disable_all_items()
        self.stop()

    async def _send_unlock_notices(self, interaction: discord.Interaction) -> None:
        """Send congratulatory embeds for achievements unlocked with the new heir."""
        notices = self.service.achievements.consume_notifications(self.owner_id)
        if not notices:
            return
        names = ", ".join(_safe_text(row["name"], 70) for row in notices[:5])
        embed = discord.Embed(title="Achievement unlocked!", description=names, color=discord.Color.gold())
        await interaction.followup.send(embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    async def on_timeout(self) -> None:
        """Disable the visible inheritance controls after ten minutes."""
        self.disable_all_items()
        if self._message is not None:
            try:
                await self._message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Could not disable expired heir controls", exc_info=True)


class RetirementConfirmView(discord.ui.View):
    """Owner-only confirmation controls for one retirement prompt."""

    def __init__(
        self,
        owner_id: int,
        prompt: RetirementPrompt,
        service: DeathService,
        *,
        achievement_names: Optional[dict[str, str]] = None,
        avatar_url: Optional[str] = None,
    ) -> None:
        super().__init__(timeout=max(30, prompt.expires_at - __import__("time").time()))
        self.owner_id = int(owner_id)
        self.prompt = prompt
        self.service = service
        self.achievement_names = achievement_names or {}
        self.avatar_url = avatar_url
        self._used = False
        self._message: Optional[discord.Message] = None
        confirm = discord.ui.Button(
            label="Confirm retirement", style=discord.ButtonStyle.danger,
            custom_id=f"retire:{prompt.nonce}:confirm",
        )
        cancel = discord.ui.Button(
            label="Keep living", style=discord.ButtonStyle.secondary,
            custom_id=f"retire:{prompt.nonce}:cancel",
        )
        confirm.callback = self.confirm
        cancel.callback = self.cancel
        self.add_item(confirm)
        self.add_item(cancel)

    def bind_message(self, message: discord.Message) -> None:
        """Remember the confirmation message for timeout cleanup."""
        self._message = message

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        """Authorize only the owner and the custom IDs carrying the saved nonce."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Only the player who opened this confirmation can respond.", ephemeral=True)
            return False
        custom_id = (interaction.data or {}).get("custom_id", "")
        if self._used or not str(custom_id).startswith(f"retire:{self.prompt.nonce}:"):
            await interaction.response.send_message("This retirement confirmation is stale or already used.", ephemeral=True)
            return False
        return True

    async def confirm(self, interaction: discord.Interaction) -> None:
        """Confirm retirement and render its no-legacy, no-heir archive."""
        try:
            result = await self.service.confirm_retirement(
                self.owner_id, self.prompt.prompt_id, self.prompt.nonce,
                guild_id=interaction.guild_id,
            )
        except GameError as exc:
            self._finish()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
            return
        self._finish()
        embed = death_summary_embed(
            result.summary, avatar_url=self.avatar_url,
            achievement_names=self.achievement_names,
        )
        embed.set_footer(text="Life abandoned · no legacy points or heir continuation awarded")
        await interaction.response.edit_message(content=None, embed=embed, view=self)
        await self._send_unlock_notices(interaction)

    async def cancel(self, interaction: discord.Interaction) -> None:
        """Cancel the one-time retirement prompt without changing life state."""
        await self.service.cancel_retirement(
            self.owner_id, self.prompt.prompt_id, self.prompt.nonce
        )
        self._finish()
        await interaction.response.edit_message(
            content="Retirement cancelled. Your life remains active.", embed=None, view=self
        )

    def _finish(self) -> None:
        """Disable both controls after a terminal confirmation result."""
        self._used = True
        self.disable_all_items()
        self.stop()

    async def _send_unlock_notices(self, interaction: discord.Interaction) -> None:
        """Send any achievements earned before retirement without granting points."""
        notices = self.service.achievements.consume_notifications(self.owner_id)
        if not notices:
            return
        embed = discord.Embed(
            title="Achievement unlocked!",
            description="\n".join(f"🏆 **{_safe_text(row['name'], 80)}**" for row in notices[:5]),
            color=discord.Color.gold(),
        )
        await interaction.followup.send(embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    async def on_timeout(self) -> None:
        """Expire the stored confirmation and disable its visible buttons."""
        if not self._used:
            try:
                await self.service.cancel_retirement(
                    self.owner_id, self.prompt.prompt_id, self.prompt.nonce
                )
            except Exception:
                logger.debug("Could not mark a timed-out retirement prompt", exc_info=True)
        self.disable_all_items()
        if self._message is not None:
            try:
                await self._message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Could not disable expired retirement controls", exc_info=True)
```

## `cogs/life.py`

```python
"""Slash commands for starting and advancing a LIFELINE character."""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from core.events import EventPrompt
from core.life_engine import LifeEngine, YearOutcome
from core.models import Character
from core.money import format_cents
from core.views import EventChoiceView, event_embed
from cogs.casino import CompulsionView
from cogs.crime_views import TaxChoiceView, TrialView, tax_prompt_embed, trial_embed
from cogs.legacy_views import HeirSelectView, death_summary_embed


STAT_ORDER = (
    ("health", "❤️ Health"),
    ("happiness", "😊 Happiness"),
    ("smarts", "🧠 Smarts"),
    ("looks", "✨ Looks"),
    ("fitness", "💪 Fitness"),
    ("karma", "🍀 Karma"),
)


def _stat_bar(value: int) -> str:
    filled = max(0, min(10, round(value / 10)))
    return f"{'🟩' * filled}{'⬛' * (10 - filled)} **{value}/100**"


def _character_embed(character: Character) -> discord.Embed:
    status = "Alive" if character.is_alive else f"Deceased at age {character.death_age}"
    embed = discord.Embed(
        title=f"{character.name} · Age {character.age}",
        description=(
            f"**Life stage:** {character.life_stage.value.replace('_', ' ').title()}\n"
            f"**Status:** {status}\n"
            f"**Background:** {character.wealth_class.title()} household · {character.country.upper()}"
        ),
        color=discord.Color.green() if character.is_alive else discord.Color.dark_grey(),
    )
    embed.add_field(
        name="Core stats",
        value="\n".join(f"{label}  {_stat_bar(getattr(character.stats, key))}" for key, label in STAT_ORDER),
        inline=False,
    )
    education = character.education_level.value.replace("_", " ").title()
    if character.current_school:
        education += f" · {character.current_school} ({character.school_years_left} year(s) left)"
    embed.add_field(name="Education", value=education, inline=False)
    embed.set_footer(text=f"Generation {character.generation} · Life #{character.char_id}")
    return embed


def _outcome_description(outcome: YearOutcome) -> str:
    parts = list(outcome.log_messages)
    if outcome.stat_changes:
        changes = []
        label_map = dict(STAT_ORDER)
        for key, delta in outcome.stat_changes.items():
            label = label_map.get(key, key.replace("_", " ").title())
            changes.append(f"{label} {'+' if delta > 0 else ''}{delta}")
        parts.append("**Stat changes:** " + " · ".join(changes))
    if outcome.died:
        parts.append("Start a new life with `/life start` when you're ready.")
    return "\n".join(parts)


class LifeCog(commands.Cog):
    """Birth, status, and age-advance commands."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.engine = LifeEngine(
            bot.db,
            bot.rng,
            getattr(bot, "locks", None),
            family_service=getattr(bot, "family_service", None),
            crime_service=getattr(bot, "crime_service", None),
            shop_service=getattr(bot, "shop_service", None),
            casino_service=getattr(bot, "casino_service", None),
            investing_service=getattr(bot, "investing_service", None),
            achievement_service=getattr(bot, "achievement_service", None),
        )
        bot.life_engine = self.engine

    life = app_commands.Group(name="life", description="Create and guide your life simulation")

    @life.command(name="start", description="Begin a new life at birth")
    @app_commands.describe(
        name="Your character's name",
        gender="Character gender",
        country="Country or region code, such as usa or in",
    )
    @app_commands.choices(gender=[
        app_commands.Choice(name="Male", value="male"),
        app_commands.Choice(name="Female", value="female"),
        app_commands.Choice(name="Non-binary", value="non_binary"),
    ])
    async def start_life(
        self,
        interaction: discord.Interaction,
        name: str,
        gender: str = "male",
        country: str = "usa",
    ) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        character = await self.engine.create_character(
            interaction.user.id,
            name,
            gender=gender,
            country=country,
        )
        embed = _character_embed(character)
        embed.description = (
            "A new story begins. Your choices will shape the life ahead.\n\n"
            + (embed.description or "")
        )
        await interaction.followup.send(embed=embed, ephemeral=True)

    @life.command(name="status", description="View your current life and stats")
    async def life_status(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        character = await self.engine.get_active_character(interaction.user.id)
        await interaction.followup.send(embed=_character_embed(character), ephemeral=True)

    @life.command(name="age", description="Advance your life by one year")
    @app_commands.checks.cooldown(1, 8.0, key=lambda interaction: interaction.user.id)
    async def age_up(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        outcome = await self.engine.age_up(interaction.user.id, guild_id=interaction.guild_id)
        if outcome.died and outcome.death_summary is not None:
            achievement_names = {
                str(row["id"]): str(row["name"]) for row in self.engine.achievements.definitions
            }
            avatar_url = getattr(getattr(interaction.user, "display_avatar", None), "url", None)
            embed = death_summary_embed(
                outcome.death_summary,
                avatar_url=avatar_url,
                achievement_names=achievement_names,
            )
            if outcome.death_public_summary and interaction.channel is not None:
                try:
                    await interaction.channel.send(
                        embed=embed,
                        allowed_mentions=discord.AllowedMentions.none(),
                    )
                    await interaction.followup.send("The death summary was posted in this channel.", ephemeral=True)
                except discord.HTTPException:
                    await interaction.followup.send(
                        embed=embed, ephemeral=True,
                        allowed_mentions=discord.AllowedMentions.none(),
                    )
            else:
                await interaction.followup.send(
                    embed=embed, ephemeral=True,
                    allowed_mentions=discord.AllowedMentions.none(),
                )
            if outcome.death_estate_id is not None and outcome.death_estate_nonce is not None and outcome.death_heirs:
                view = HeirSelectView(
                    interaction.user.id,
                    outcome.death_estate_id,
                    outcome.death_estate_nonce,
                    outcome.death_heirs,
                    self.engine.death,
                )
                prompt = discord.Embed(
                    title="Continue the family line?",
                    description=(
                        "Choose one of your living adult children. The after-tax estate is split across "
                        "all eligible adult children; your heir begins at their current age with their own stats. "
                        "You can also close the estate and start fresh."
                    ),
                    color=discord.Color.gold(),
                )
                message = await interaction.followup.send(
                    embed=prompt, view=view, ephemeral=True, wait=True,
                    allowed_mentions=discord.AllowedMentions.none(),
                )
                view.bind_message(message)
            return
        if outcome.pending_event is not None:
            prompt: EventPrompt = outcome.pending_event
            view = EventChoiceView(
                interaction.user.id, prompt, self.engine.events,
                achievement_service=self.engine.achievements,
            )
            message = await interaction.followup.send(
                embed=event_embed(prompt, lead=_outcome_description(outcome)),
                view=view,
                ephemeral=True,
                wait=True,
            )
            view.bind_message(message)
            return

        if outcome.pending_trial is not None:
            view = TrialView(
                interaction.user.id, outcome.pending_trial, self.engine.crimes,
                self.engine.achievements,
            )
            embed = trial_embed(outcome.pending_trial)
            embed.description = f"{_outcome_description(outcome)}\n\n{embed.description or ''}"
            message = await interaction.followup.send(embed=embed, view=view, ephemeral=True, wait=True)
            view.bind_message(message)
            return

        if outcome.pending_tax is not None:
            view = TaxChoiceView(
                interaction.user.id, outcome.pending_tax, self.engine.crimes,
                self.engine.achievements,
            )
            embed = tax_prompt_embed(outcome.pending_tax)
            embed.description = f"{_outcome_description(outcome)}\n\n{embed.description or ''}"
            message = await interaction.followup.send(embed=embed, view=view, ephemeral=True, wait=True)
            view.bind_message(message)
            return

        if outcome.pending_compulsion is not None:
            prompt = outcome.pending_compulsion
            view = CompulsionView(
                interaction.user.id, self.engine.casino, prompt, self.engine.achievements
            )
            amount = int(prompt["forced_bet_cents"])
            embed = discord.Embed(
                title="Gambling compulsion",
                description=(
                    f"{_outcome_description(outcome)}\n\n"
                    f"Your character is experiencing a gambling compulsion. Resist, or indulge in a forced wager of {format_cents(amount)}."
                ),
                color=discord.Color.orange(),
            )
            message = await interaction.followup.send(embed=embed, view=view, ephemeral=True, wait=True)
            view.bind_message(message)
            return

        embed = _character_embed(outcome.character)
        embed.description = _outcome_description(outcome)
        if outcome.died:
            embed.color = discord.Color.dark_grey()
        elif outcome.new_stage != outcome.previous_stage:
            embed.color = discord.Color.gold()
        await interaction.followup.send(embed=embed, ephemeral=True)

    @life.command(name="choice", description="Reopen your unresolved life-event choice")
    async def resume_choice(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        prompt = await self.engine.events.get_pending_event(interaction.user.id)
        view = EventChoiceView(
            interaction.user.id, prompt, self.engine.events,
            achievement_service=self.engine.achievements,
        )
        message = await interaction.followup.send(
            embed=event_embed(prompt, lead="Your unresolved life event is saved."),
            view=view,
            ephemeral=True,
            wait=True,
        )
        view.bind_message(message)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(LifeCog(bot))
```

## `cogs/crime.py`

```python
"""Discord slash commands for crime, risk previews, trials, tax choices, and laundering."""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from core.crime import CrimeDefinition, CrimeRecord, CrimeService
from core.money import format_cents
from cogs.crime_views import (
    CrimeConfirmationView,
    TaxChoiceView,
    TrialView,
    crime_preview_embed,
    tax_prompt_embed,
    trial_embed,
)


CRIME_CHOICES = [
    app_commands.Choice(name="Shoplift", value="shoplift"),
    app_commands.Choice(name="Pickpocket", value="pickpocket"),
    app_commands.Choice(name="Vandalism", value="vandalism"),
    app_commands.Choice(name="Car Break-in", value="car_break_in"),
    app_commands.Choice(name="Burglary", value="burglary"),
    app_commands.Choice(name="Grand Theft Auto", value="grand_theft_auto"),
    app_commands.Choice(name="Drug Dealing", value="drug_dealing"),
    app_commands.Choice(name="Fraud / Scam", value="fraud_scam"),
    app_commands.Choice(name="Embezzlement", value="embezzlement"),
    app_commands.Choice(name="Assault", value="assault"),
    app_commands.Choice(name="Armed Robbery", value="armed_robbery"),
    app_commands.Choice(name="Bank Heist", value="bank_heist"),
    app_commands.Choice(name="Murder", value="murder"),
    app_commands.Choice(name="Tax Evasion (event only)", value="tax_evasion"),
]


def _safe(value: str) -> str:
    """Escape Discord markdown and mention syntax in character or catalog text."""
    return discord.utils.escape_mentions(discord.utils.escape_markdown(str(value)))


def _crime_list_embed(crimes: tuple[CrimeDefinition, ...]) -> discord.Embed:
    """List validated crime definitions and age gates without real-world advice."""
    embed = discord.Embed(
        title="Fictional crime catalog",
        description="All outcomes are abstract game rolls. Crime flavor intentionally includes no real-world instructions.",
        color=discord.Color.dark_red(),
    )
    for crime in crimes:
        if crime.commit_enabled:
            risk = f"Base success {crime.base_success:.0f}% · base arrest {crime.base_catch:.0f}%"
            if crime.requires_job:
                risk += " · active job required"
            if crime.violence:
                risk += " · violent offense"
        else:
            risk = "Event-only; cannot be committed with this command."
        embed.add_field(
            name=f"{_safe(crime.name)} · age {crime.min_age}+",
            value=f"{_safe(crime.description)}\n{risk}",
            inline=False,
        )
    embed.set_footer(text="/crime commit previews current risk before an attempt · two attempts per in-game year")
    return embed


def _record_embed(record: CrimeRecord) -> discord.Embed:
    """Render the player-owned criminal record and recent case history."""
    character = record.character
    embed = discord.Embed(
        title=f"Crime record · {_safe(character.name)}",
        description=(
            f"**Criminal record:** {character.criminal_record}\n"
            f"**Notoriety:** {character.notoriety}/100\n"
            f"**Criminal career:** {_safe(record.career_rank or 'Not established')}"
            f" · {record.career_years} paid year(s)\n"
            f"**Unlaundered proceeds:** {format_cents(record.dirty_cash)}\n"
            f"**Tax exposed to audit:** {format_cents(record.evaded_tax)}"
        ),
        color=discord.Color.dark_red(),
    )
    if record.attempts:
        for attempt in record.attempts[:8]:
            status = str(attempt["case_status"]).replace("_", " ").title()
            crime_name = str(attempt["crime_id"]).replace("_", " ").title()
            result = "caught" if bool(attempt["caught"]) else ("success" if bool(attempt["success"]) else "failed")
            value = f"Age {int(attempt['age'])} · {result} · {status} · {format_cents(int(attempt['loot']))} proceeds"
            if int(attempt["sentence_years"]):
                value += f" · sentence {int(attempt['sentence_years'])} year(s)"
            embed.add_field(name=_safe(crime_name), value=value, inline=False)
    else:
        embed.add_field(name="History", value="No recorded attempts yet.", inline=False)
    if record.trial is not None:
        embed.add_field(name="Pending decision", value="A court case is waiting for a lawyer choice below.", inline=False)
    elif record.tax_prompt is not None:
        embed.add_field(name="Pending decision", value="A tax choice is waiting below.", inline=False)
    elif record.preview is not None:
        embed.add_field(name="Pending decision", value="A crime risk preview is ready to confirm or cancel below.", inline=False)
    embed.set_footer(text="A criminal record lowers future job-offer odds; the post-release penalty fades over time.")
    return embed


class CrimeCog(commands.Cog):
    """Owner-safe player commands for Stage 7 crime and court rules."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        service = getattr(bot, "crime_service", None)
        if service is None:
            service = CrimeService(bot.db, bot.rng, getattr(bot, "locks", None))
        self.service: CrimeService = service
        self.achievement_service = getattr(bot, "achievement_service", None)

    crime = app_commands.Group(name="crime", description="View abstract crime risks and court outcomes")

    @crime.command(name="list", description="Browse fictional crime options and age gates")
    @app_commands.checks.cooldown(1, 8.0, key=lambda interaction: interaction.user.id)
    async def list_crimes(self, interaction: discord.Interaction) -> None:
        crimes = await self.service.list_crimes(interaction.user.id)
        await interaction.response.send_message(embed=_crime_list_embed(crimes), ephemeral=True)

    @crime.command(name="commit", description="Preview risk and choose whether to attempt a fictional crime")
    @app_commands.describe(crime_id="The fictional offense to preview")
    @app_commands.choices(crime_id=CRIME_CHOICES)
    @app_commands.checks.cooldown(1, 10.0, key=lambda interaction: interaction.user.id)
    async def commit(self, interaction: discord.Interaction, crime_id: str) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        preview = await self.service.preview_crime(interaction.user.id, crime_id)
        view = CrimeConfirmationView(interaction.user.id, preview, self.service, self.achievement_service)
        message = await interaction.followup.send(
            embed=crime_preview_embed(preview), view=view, ephemeral=True, wait=True
        )
        view.bind_message(message)

    @crime.command(name="launder", description="Move available dirty cash to your bank after a 25% fee")
    @app_commands.describe(amount="Whole-dollar amount of dirty cash to launder")
    @app_commands.checks.cooldown(1, 10.0, key=lambda interaction: interaction.user.id)
    async def launder(self, interaction: discord.Interaction, amount: app_commands.Range[int, 1, 1_000_000_000]) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await self.service.launder(interaction.user.id, amount)
        cap_message = (
            "Front-business access removes the ordinary annual cap."
            if result.annual_limit == 0
            else f"Annual cap without a front business: {format_cents(result.annual_limit)} gross."
        )
        embed = discord.Embed(
            title="Laundering complete",
            description=(
                f"Gross removed from dirty cash: **{format_cents(result.gross_amount)}**\n"
                f"Fee (25%): **{format_cents(result.fee_amount)}**\n"
                f"Added to bank: **{format_cents(result.net_amount)}**\n\n{cap_message}"
            ),
            color=discord.Color.gold(),
        )
        await interaction.followup.send(embed=embed, ephemeral=True)

    @crime.command(name="record", description="View your criminal record and resume a pending decision")
    @app_commands.checks.cooldown(1, 8.0, key=lambda interaction: interaction.user.id)
    async def record(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        record = await self.service.crime_record(interaction.user.id)
        view: discord.ui.View | None = None
        embed = _record_embed(record)
        if record.trial is not None:
            view = TrialView(interaction.user.id, record.trial, self.service, self.achievement_service)
            embed = trial_embed(record.trial)
            embed.add_field(
                name="Record summary",
                value=(
                    f"Criminal record: {record.character.criminal_record} · "
                    f"Notoriety: {record.character.notoriety}/100 · Dirty cash: {format_cents(record.dirty_cash)}"
                ),
                inline=False,
            )
        elif record.tax_prompt is not None:
            view = TaxChoiceView(interaction.user.id, record.tax_prompt, self.service, self.achievement_service)
            embed = tax_prompt_embed(record.tax_prompt)
        elif record.preview is not None:
            view = CrimeConfirmationView(interaction.user.id, record.preview, self.service, self.achievement_service)
            embed = crime_preview_embed(record.preview)
        message = await interaction.followup.send(embed=embed, view=view, ephemeral=True, wait=True)
        if view is not None and hasattr(view, "bind_message"):
            view.bind_message(message)


async def setup(bot: commands.Bot) -> None:
    """Register the crime slash-command cog."""
    await bot.add_cog(CrimeCog(bot))
```

## `cogs/crime_views.py`

```python
"""Owner-checked, nonce-protected interactive crime, court, and tax views."""
from __future__ import annotations

import time
from typing import Optional

import discord

from core.crime import (
    CrimeAttemptOutcome,
    CrimePreview,
    CrimeService,
    LAWYER_CONVICTION_CHANCES,
    TaxEvasionPrompt,
    TrialPrompt,
    TrialResolution,
)
from core.errors import GameError
from core.money import format_cents
from core.views import OwnedView
from core.achievements import AchievementService
from cogs.legacy_views import check_and_notify_achievements


class CrimeConfirmationView(OwnedView):
    """Risk disclosure with one-use confirm and cancel controls."""

    def __init__(
        self,
        owner_id: int,
        preview: CrimePreview,
        service: CrimeService,
        achievement_service: Optional[AchievementService] = None,
    ) -> None:
        super().__init__(owner_id, preview.nonce, timeout=max(30, preview.expires_at - time.time()))
        self.preview = preview
        self.service = service
        self.achievement_service = achievement_service
        self.add_item(_CrimeConfirmButton(preview.nonce))
        self.add_item(_CrimeCancelButton(preview.nonce))

    async def confirm(self, interaction: discord.Interaction) -> None:
        try:
            result = await self.service.confirm_crime(interaction.user.id, self.nonce)
        except GameError as exc:
            self._disable_all()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
            self.stop()
            return
        self._disable_all()
        embed = attempt_embed(result)
        if result.trial is not None:
            trial_view = TrialView(
                interaction.user.id, result.trial, self.service, self.achievement_service
            )
            trial_view.bind_message(interaction.message)
            await interaction.response.edit_message(embed=embed, view=trial_view)
        else:
            await interaction.response.edit_message(embed=embed, view=self)
        self.stop()
        await check_and_notify_achievements(
            interaction, self.achievement_service, interaction.user.id
        )

    async def cancel(self, interaction: discord.Interaction) -> None:
        try:
            await self.service.cancel_preview(interaction.user.id, self.nonce)
        except GameError as exc:
            self._disable_all()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
            self.stop()
            return
        self._disable_all()
        await interaction.response.edit_message(
            content="Crime confirmation cancelled. No attempt was made.", embed=None, view=self
        )
        self.stop()

    def _disable_all(self) -> None:
        for child in self.children:
            if hasattr(child, "disabled"):
                child.disabled = True


class _CrimeConfirmButton(discord.ui.Button[CrimeConfirmationView]):
    def __init__(self, nonce: str) -> None:
        super().__init__(
            label="Confirm attempt",
            style=discord.ButtonStyle.danger,
            custom_id=f"crime:confirm:{nonce}",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        if isinstance(self.view, CrimeConfirmationView):
            await self.view.confirm(interaction)


class _CrimeCancelButton(discord.ui.Button[CrimeConfirmationView]):
    def __init__(self, nonce: str) -> None:
        super().__init__(
            label="Cancel",
            style=discord.ButtonStyle.secondary,
            custom_id=f"crime:cancel:{nonce}",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        if isinstance(self.view, CrimeConfirmationView):
            await self.view.cancel(interaction)


class TrialView(OwnedView):
    """Three lawyer choices bound to a single owner and persistent court nonce."""

    def __init__(
        self,
        owner_id: int,
        prompt: TrialPrompt,
        service: CrimeService,
        achievement_service: Optional[AchievementService] = None,
    ) -> None:
        super().__init__(owner_id, prompt.nonce, timeout=300)
        self.prompt = prompt
        self.service = service
        self.achievement_service = achievement_service
        for tier, label, style in (
            ("public", "Public defender · free", discord.ButtonStyle.secondary),
            ("standard", "Standard · $10,000", discord.ButtonStyle.primary),
            ("elite", "Elite · $100,000 × index", discord.ButtonStyle.success),
        ):
            self.add_item(_LawyerButton(tier, label, style, prompt.nonce))

    async def resolve(self, interaction: discord.Interaction, tier: str) -> None:
        try:
            result = await self.service.resolve_trial(interaction.user.id, self.nonce, tier)
        except GameError as exc:
            self._disable_all()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
            self.stop()
            return
        self._disable_all()
        await interaction.response.edit_message(embed=trial_resolution_embed(result), view=self)
        self.stop()
        await check_and_notify_achievements(
            interaction, self.achievement_service, interaction.user.id
        )

    def _disable_all(self) -> None:
        for child in self.children:
            if hasattr(child, "disabled"):
                child.disabled = True


class _LawyerButton(discord.ui.Button[TrialView]):
    def __init__(self, tier: str, label: str, style: discord.ButtonStyle, nonce: str) -> None:
        super().__init__(label=label, style=style, custom_id=f"crime:lawyer:{tier}:{nonce}")
        self.tier = tier

    async def callback(self, interaction: discord.Interaction) -> None:
        if isinstance(self.view, TrialView):
            await self.view.resolve(interaction, self.tier)


class TaxChoiceView(OwnedView):
    """One-use owner-only annual income-tax decision."""

    def __init__(
        self,
        owner_id: int,
        prompt: TaxEvasionPrompt,
        service: CrimeService,
        achievement_service: Optional[AchievementService] = None,
    ) -> None:
        super().__init__(owner_id, prompt.nonce, timeout=300)
        self.prompt = prompt
        self.service = service
        self.achievement_service = achievement_service
        for choice, label, style in (
            ("pay", "Pay tax", discord.ButtonStyle.success),
            ("evade_50", "Skip 50%", discord.ButtonStyle.secondary),
            ("evade_75", "Skip 75%", discord.ButtonStyle.primary),
            ("evade_100", "Skip 100%", discord.ButtonStyle.danger),
        ):
            self.add_item(_TaxButton(choice, label, style, prompt.nonce))

    async def resolve(self, interaction: discord.Interaction, choice: str) -> None:
        try:
            result = await self.service.resolve_tax_choice(interaction.user.id, self.nonce, choice)
        except GameError as exc:
            self._disable_all()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
            self.stop()
            return
        self._disable_all()
        embed = discord.Embed(
            title="Tax decision recorded",
            description=result.message,
            color=discord.Color.orange() if result.evaded_amount else discord.Color.green(),
        )
        embed.add_field(name="Tax assessed", value=format_cents(result.tax_due), inline=True)
        embed.add_field(name="Deferred to audit risk", value=format_cents(result.evaded_amount), inline=True)
        await interaction.response.edit_message(embed=embed, view=self)
        self.stop()
        await check_and_notify_achievements(
            interaction, self.achievement_service, interaction.user.id
        )

    def _disable_all(self) -> None:
        for child in self.children:
            if hasattr(child, "disabled"):
                child.disabled = True


class _TaxButton(discord.ui.Button[TaxChoiceView]):
    def __init__(self, choice: str, label: str, style: discord.ButtonStyle, nonce: str) -> None:
        super().__init__(label=label, style=style, custom_id=f"crime:tax:{choice}:{nonce}")
        self.choice = choice

    async def callback(self, interaction: discord.Interaction) -> None:
        if isinstance(self.view, TaxChoiceView):
            await self.view.resolve(interaction, self.choice)


def crime_preview_embed(preview: CrimePreview) -> discord.Embed:
    """Display both success and arrest risks before a player confirms."""
    embed = discord.Embed(
        title=f"Crime risk · {preview.crime_name}",
        description=(
            f"{preview.description}\n\n"
            f"**Success chance:** {preview.success_chance:.1f}%\n"
            f"**Arrest chance if successful:** {preview.catch_chance:.1f}%\n"
            f"**Arrest chance if it fails:** {preview.failed_catch_chance:.1f}%\n"
            f"**Possible proceeds:** {format_cents(preview.loot_min)}–{format_cents(preview.loot_max)} (dirty cash)"
        ),
        color=discord.Color.orange(),
    )
    embed.set_footer(text=f"Age {preview.age} · Confirmation expires in about 5 minutes · Maximum two attempts per year")
    return embed


def attempt_embed(result: CrimeAttemptOutcome) -> discord.Embed:
    """Render a neutral fictional outcome without procedural crime details."""
    if result.caught:
        color = discord.Color.red()
    elif result.success:
        color = discord.Color.gold()
    else:
        color = discord.Color.blurple()
    embed = discord.Embed(title=f"Crime outcome · {result.crime_name}", description=result.message, color=color)
    embed.add_field(name="Success roll", value=f"{result.success_chance:.1f}%", inline=True)
    embed.add_field(name="Arrest roll", value=f"{result.catch_chance:.1f}%", inline=True)
    if result.loot:
        embed.add_field(name="Dirty cash", value=format_cents(result.loot), inline=False)
    if result.trial is not None:
        embed.add_field(name="Public defender", value="85% conviction chance · free", inline=False)
        embed.add_field(name="Standard lawyer", value="65% conviction chance · $10,000", inline=False)
        embed.add_field(name="Elite lawyer", value="40% conviction chance · $100,000 × price index", inline=False)
        embed.set_footer(text="Choose counsel below to resolve the pending trial.")
    return embed


def trial_embed(prompt: TrialPrompt) -> discord.Embed:
    """Show available lawyer tiers and the case awaiting a verdict roll."""
    embed = discord.Embed(
        title=f"Trial · {prompt.crime_name}",
        description=(
            "Choose counsel. The displayed percentage is the chance of conviction; "
            "a lower tier costs more but does not guarantee an outcome."
        ),
        color=discord.Color.dark_red(),
    )
    for tier, chance, cost in (
        ("Public defender", LAWYER_CONVICTION_CHANCES["public"], "Free"),
        ("Standard lawyer", LAWYER_CONVICTION_CHANCES["standard"], "$10,000"),
        ("Elite lawyer", LAWYER_CONVICTION_CHANCES["elite"], "$100,000 × price index"),
    ):
        embed.add_field(name=tier, value=f"Conviction chance: {chance:.0f}% · Cost: {cost}", inline=False)
    embed.set_footer(text=f"Case source: {prompt.source.replace('_', ' ')} · Buttons are owner-only and one-use")
    return embed


def trial_resolution_embed(result: TrialResolution) -> discord.Embed:
    """Render a resolved verdict from a ``TrialResolution`` result."""
    return discord.Embed(
        title=f"Trial resolved · {result.crime_name}",
        description=result.message,
        color=discord.Color.red() if result.convicted else discord.Color.green(),
    )


def tax_prompt_embed(prompt: TaxEvasionPrompt) -> discord.Embed:
    """Describe the high-earner tax choice without real-world evasion advice."""
    embed = discord.Embed(
        title="Annual tax choice",
        description=(
            f"Tax assessed: **{format_cents(prompt.tax_due)}**. Choose to pay or defer 50%, 75%, or 100%. "
            "Any skipped amount can trigger a future in-game audit, back taxes, and a sentence."
        ),
        color=discord.Color.orange(),
    )
    embed.set_footer(text="Fictional game decision · Resolve before advancing another year")
    return embed
```

## `cogs/casino.py`

```python
"""Stage 9 /casino commands and owner/nonce-protected game controls."""
from __future__ import annotations

import logging
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from core.achievements import AchievementService
from core.casino import CasinoReceipt, CasinoService
from core.errors import GameError
from core.investing import InvestingService
from core.money import dollars_to_cents, format_cents
from cogs.legacy_views import check_and_notify_achievements

logger = logging.getLogger("lifeline.casino.cog")


class _BlackjackButton(discord.ui.Button["BlackjackView"]):
    """One dynamically nonce-stamped blackjack action."""

    def __init__(self, label: str, action: str, session_id: int, nonce: str, *, disabled: bool = False) -> None:
        styles = {"hit": discord.ButtonStyle.primary, "stand": discord.ButtonStyle.secondary, "double": discord.ButtonStyle.success}
        super().__init__(
            label=label,
            style=styles[action],
            custom_id=f"bj:{session_id}:{nonce}:{action}",
            disabled=disabled,
        )
        self.action = action

    async def callback(self, interaction: discord.Interaction) -> None:
        if self.view is None:
            return
        await self.view.handle_action(interaction, self.action)


class BlackjackView(discord.ui.View):
    """Ephemeral Hit/Stand/Double controls bound to the initiating player and nonce."""

    def __init__(
        self,
        owner_id: int,
        service: CasinoService,
        session_id: int,
        nonce: str,
        *,
        can_double: bool = True,
        achievement_service: Optional[AchievementService] = None,
    ) -> None:
        super().__init__(timeout=120.0)
        self.owner_id = owner_id
        self.service = service
        self.achievement_service = achievement_service
        self.session_id = session_id
        self.nonce = nonce
        self.message: Optional[discord.Message] = None
        self.add_item(_BlackjackButton("Hit", "hit", session_id, nonce))
        self.add_item(_BlackjackButton("Stand", "stand", session_id, nonce))
        self.add_item(_BlackjackButton("Double", "double", session_id, nonce, disabled=not can_double))

    def bind_message(self, message: discord.Message) -> None:
        """Keep the ephemeral message reference for the two-minute auto-stand."""
        self.message = message

    def _disable(self) -> None:
        """Disable consumed controls before this view is replaced or expires."""
        for child in self.children:
            if isinstance(child, discord.ui.Button):
                child.disabled = True
        self.stop()

    async def handle_action(self, interaction: discord.Interaction, action: str) -> None:
        """Owner-check, defer the component interaction, and call the nonce-guarded service."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This blackjack hand belongs to another player.", ephemeral=True)
            return
        await interaction.response.defer()
        try:
            receipt = await self.service.blackjack_action(
                interaction.user.id, self.session_id, self.nonce, action
            )
        except GameError as exc:
            await interaction.followup.send(exc.message, ephemeral=True)
            return
        except Exception:
            logger.exception("Blackjack button action failed for session %s", self.session_id)
            await interaction.followup.send("The hand could not be updated. Please try again.", ephemeral=True)
            return
        self._disable()
        next_view: Optional[BlackjackView] = None
        if receipt.status == "active" and receipt.session_id is not None and receipt.nonce is not None:
            cards = receipt.outcome.get("player", [])
            next_view = BlackjackView(
                self.owner_id, self.service, receipt.session_id, receipt.nonce,
                can_double=len(cards) == 2,
                achievement_service=self.achievement_service,
            )
        try:
            message = await interaction.edit_original_response(content=None, embed=_receipt_embed(receipt), view=next_view)
            if next_view is not None:
                next_view.bind_message(message)
        except discord.HTTPException:
            logger.exception("Could not refresh blackjack hand %s", self.session_id)
        await check_and_notify_achievements(
            interaction, self.achievement_service, interaction.user.id
        )

    async def on_timeout(self) -> None:
        """Auto-stand after two minutes, settle once, and remove the expired controls."""
        try:
            receipt = await self.service.blackjack_action(
                self.owner_id, self.session_id, self.nonce, "stand", auto_stand=True
            )
            self._disable()
            if self.message is not None:
                await self.message.edit(content=None, embed=_receipt_embed(receipt), view=None)
        except GameError:
            self._disable()
            if self.message is not None:
                try:
                    await self.message.edit(view=None)
                except discord.HTTPException:
                    logger.info("Timed-out blackjack message %s was already unavailable", self.session_id)
        except Exception:
            logger.exception("Blackjack timeout settlement failed for session %s", self.session_id)
            self._disable()
            if self.message is not None:
                try:
                    await self.message.edit(view=None)
                except discord.HTTPException:
                    logger.info("Could not remove expired blackjack controls for %s", self.session_id)


class _CompulsionButton(discord.ui.Button["CompulsionView"]):
    """One owner-bound addiction-event choice with a persistent nonce."""

    def __init__(self, label: str, choice: str, compulsion_id: int, nonce: str, *, style: discord.ButtonStyle) -> None:
        super().__init__(
            label=label,
            style=style,
            custom_id=f"compulsion:{compulsion_id}:{nonce}:{choice}",
        )
        self.choice = choice

    async def callback(self, interaction: discord.Interaction) -> None:
        if self.view is not None:
            await self.view.resolve(interaction, self.choice)


class CompulsionView(discord.ui.View):
    """Resist/indulge gambling-addiction event controls."""

    def __init__(
        self,
        owner_id: int,
        service: CasinoService,
        prompt: dict[str, object],
        achievement_service: Optional[AchievementService] = None,
    ) -> None:
        super().__init__(timeout=300.0)
        self.owner_id = owner_id
        self.service = service
        self.achievement_service = achievement_service
        self.compulsion_id = int(prompt["compulsion_id"])
        self.nonce = str(prompt["nonce"])
        self.message: Optional[discord.Message] = None
        self.add_item(_CompulsionButton("Resist", "resist", self.compulsion_id, self.nonce, style=discord.ButtonStyle.success))
        self.add_item(_CompulsionButton("Indulge · place forced bet", "indulge", self.compulsion_id, self.nonce, style=discord.ButtonStyle.danger))

    def bind_message(self, message: discord.Message) -> None:
        """Bind the prompt message for timeout cleanup."""
        self.message = message

    async def resolve(self, interaction: discord.Interaction, choice: str) -> None:
        """Owner-check and atomically consume the compulsion prompt."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This choice belongs to another player.", ephemeral=True)
            return
        await interaction.response.defer()
        try:
            result = await self.service.resolve_compulsion(
                interaction.user.id, self.compulsion_id, self.nonce, choice
            )
        except GameError as exc:
            await interaction.followup.send(exc.message, ephemeral=True)
            return
        except Exception:
            logger.exception("Gambling compulsion resolution failed for %s", self.compulsion_id)
            await interaction.followup.send("The choice could not be saved. Please try again.", ephemeral=True)
            return
        for child in self.children:
            if isinstance(child, discord.ui.Button):
                child.disabled = True
        self.stop()
        await interaction.edit_original_response(content=result.message, embed=None, view=None)
        await check_and_notify_achievements(
            interaction, self.achievement_service, interaction.user.id
        )

    async def on_timeout(self) -> None:
        """Default an unattended addiction prompt to resisting, without placing a bet."""
        try:
            await self.service.resolve_compulsion(
                self.owner_id, self.compulsion_id, self.nonce, "resist"
            )
        except GameError:
            logger.info("Compulsion choice %s was already resolved or expired", self.compulsion_id)
        except Exception:
            logger.exception("Compulsion timeout resolution failed for %s", self.compulsion_id)
        for child in self.children:
            if isinstance(child, discord.ui.Button):
                child.disabled = True
        self.stop()
        if self.message is not None:
            try:
                await self.message.edit(view=None)
            except discord.HTTPException:
                logger.info("Compulsion message %s was already unavailable", self.compulsion_id)


def _receipt_embed(receipt: CasinoReceipt) -> discord.Embed:
    """Create a compact casino outcome embed from a service receipt."""
    color = discord.Color.gold() if receipt.status == "active" else (discord.Color.green() if (receipt.net_cents or 0) > 0 else discord.Color.blurple())
    embed = discord.Embed(title=f"{receipt.game.title()}", description=receipt.message, color=color)
    if receipt.status == "settled" and receipt.payout_cents is not None:
        embed.add_field(name="Wager", value=format_cents(receipt.bet_cents), inline=True)
        embed.add_field(name="Gross return", value=format_cents(receipt.payout_cents), inline=True)
        embed.add_field(name="Net", value=format_cents(receipt.net_cents or 0, include_plus=True), inline=True)
    return embed


class CasinoCog(commands.Cog):
    """Casino slash-command group with server-validated age, funds, and cooldown gates."""

    casino = app_commands.Group(name="casino", description="Play fictional, in-game casino games")

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        service = getattr(bot, "casino_service", None)
        if service is None:
            service = CasinoService(bot.db, bot.rng, getattr(bot, "locks", None))
            bot.casino_service = service
        self.service: CasinoService = service
        self.achievement_service = getattr(bot, "achievement_service", None)
        investing = getattr(bot, "investing_service", None)
        if investing is None:
            investing = InvestingService(bot.db, bot.rng, getattr(bot, "locks", None))
            bot.investing_service = investing
        self.investing_service: InvestingService = investing

    @casino.command(name="slots", description="Spin three weighted reels at a documented 92% RTP")
    @app_commands.describe(bet="Wager in dollars, from $1 up to your balance/price-index cap")
    async def slots(self, interaction: discord.Interaction, bet: float) -> None:
        """Run a weighted three-reel slot spin."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        receipt = await self.service.play_slots(interaction.user.id, dollars_to_cents(bet))
        await interaction.followup.send(embed=_receipt_embed(receipt), ephemeral=True)

    @casino.command(name="blackjack", description="Start an interactive six-deck blackjack hand")
    @app_commands.describe(bet="Wager in dollars; Hit, Stand, or Double within two minutes")
    async def blackjack(self, interaction: discord.Interaction, bet: float) -> None:
        """Start a hand and attach owner-checked Hit/Stand/Double buttons."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        receipt = await self.service.blackjack_start(interaction.user.id, dollars_to_cents(bet))
        view: Optional[BlackjackView] = None
        if receipt.status == "active" and receipt.session_id is not None and receipt.nonce is not None:
            cards = receipt.outcome.get("player", [])
            view = BlackjackView(
                interaction.user.id, self.service, receipt.session_id, receipt.nonce,
                can_double=len(cards) == 2, achievement_service=self.achievement_service,
            )
        message = await interaction.followup.send(embed=_receipt_embed(receipt), view=view, ephemeral=True, wait=True)
        if view is not None:
            view.bind_message(message)

    @casino.command(name="roulette", description="Play European single-zero roulette")
    @app_commands.describe(
        bet_type="Outside bet, dozen, or straight-up number",
        bet="Wager in dollars",
        number="For dozen use 1–3; for straight use 0–36; omit otherwise",
    )
    @app_commands.choices(bet_type=[
        app_commands.Choice(name="Red", value="red"),
        app_commands.Choice(name="Black", value="black"),
        app_commands.Choice(name="Odd", value="odd"),
        app_commands.Choice(name="Even", value="even"),
        app_commands.Choice(name="Dozen", value="dozen"),
        app_commands.Choice(name="Straight number", value="straight"),
    ])
    async def roulette(
        self,
        interaction: discord.Interaction,
        bet_type: str,
        bet: float,
        number: Optional[int] = None,
    ) -> None:
        """Spin a single-zero wheel and settle one selected roulette wager."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        receipt = await self.service.play_roulette(
            interaction.user.id, bet_type, dollars_to_cents(bet), number
        )
        await interaction.followup.send(embed=_receipt_embed(receipt), ephemeral=True)

    @casino.command(name="coinflip", description="Bet heads or tails; a win returns 1.94 times the wager")
    @app_commands.describe(side="Choose heads or tails", bet="Wager in dollars")
    @app_commands.choices(side=[
        app_commands.Choice(name="Heads", value="heads"),
        app_commands.Choice(name="Tails", value="tails"),
    ])
    async def coinflip(self, interaction: discord.Interaction, side: str, bet: float) -> None:
        """Settle a 1.94x-gross coinflip wager."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        receipt = await self.service.play_coinflip(interaction.user.id, side, dollars_to_cents(bet))
        await interaction.followup.send(embed=_receipt_embed(receipt), ephemeral=True)

    @casino.command(name="compulsion", description="Reopen a pending gambling-addiction choice")
    async def resume_compulsion(self, interaction: discord.Interaction) -> None:
        """Reopen a persisted resist/indulge prompt after a reconnect."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        prompt = await self.service.get_pending_compulsion(interaction.user.id)
        view = CompulsionView(
            interaction.user.id, self.service, prompt, self.achievement_service
        )
        amount = int(prompt["forced_bet_cents"])
        message = await interaction.followup.send(
            f"Gambling compulsion: resist, or indulge in a forced wager of {format_cents(amount)}.",
            view=view, ephemeral=True, wait=True,
        )
        view.bind_message(message)


async def setup(bot: commands.Bot) -> None:
    """Register the Stage 9 casino command group."""
    await bot.add_cog(CasinoCog(bot))
```

## `cogs/shop.py`

```python
"""Slash commands for the Stage 8 shop, inventory, and player trade system."""
from __future__ import annotations

import logging
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands, tasks

from core.errors import GameError
from core.family import FamilyService, RING_CATALOG
from core.money import format_cents
from core.shop import ShopService
from cogs.shop_views import (
    ShopBrowseView,
    ShopQuoteView,
    TradeBuilderView,
    quote_embed,
)

logger = logging.getLogger("lifeline.shop.cog")
SHOP_CATEGORIES = (
    "housing", "vehicle", "jewelry", "electronics", "health", "collectibles",
    "business", "pet", "consumable", "license", "title", "leisure",
)
RING_CHOICES = [
    app_commands.Choice(name=f"{item['name']} · {format_cents(int(item['price']))}", value=item_id)
    for item_id, item in RING_CATALOG.items()
]


def safe_text(value: str, limit: int = 150) -> str:
    """Escape markdown and mention syntax before adding content to Discord embeds."""
    result = discord.utils.escape_mentions(discord.utils.escape_markdown(str(value)))
    return result[:limit]


async def shop_item_autocomplete(
    interaction: discord.Interaction,
    current: str,
) -> list[app_commands.Choice[str]]:
    """Suggest shop-visible item IDs by a case-insensitive name prefix."""
    service = getattr(interaction.client, "shop_service", None)
    if service is None:
        return []
    query = current.strip().lower()
    return [
        app_commands.Choice(name=f"{item['name']} · {item['category']}", value=item_id)
        for item_id, item in list(service.items.items())[:]
        if item["shop_available"] and (query in item["name"].lower() or query in item_id)
    ][:25]


async def inventory_item_autocomplete(
    interaction: discord.Interaction,
    current: str,
) -> list[app_commands.Choice[str]]:
    """Suggest item IDs currently held by the caller's active life."""
    service = getattr(interaction.client, "shop_service", None)
    if service is None:
        return []
    try:
        _, items = await service.inventory(interaction.user.id)
    except GameError:
        return []
    query = current.strip().lower()
    results: list[app_commands.Choice[str]] = []
    seen: set[str] = set()
    for row in items:
        item_id = str(row["item_id"])
        if item_id in seen or (query not in str(row["name"]).lower() and query not in item_id):
            continue
        seen.add(item_id)
        results.append(app_commands.Choice(name=f"{row['name']} ×{row['quantity']}", value=item_id))
    return results[:25]


class ShopCog(commands.Cog):
    """Shop, inventory, trade commands, and a robust trade-expiry background task."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        service = getattr(bot, "shop_service", None)
        if service is None:
            service = ShopService(bot.db, bot.rng, getattr(bot, "locks", None))
            bot.shop_service = service
        self.service: ShopService = service
        self.achievement_service = getattr(bot, "achievement_service", None)
        relationships = getattr(bot, "family_service", None)
        if relationships is None:
            relationships = FamilyService(bot.db, bot.rng, getattr(bot, "locks", None))
            bot.family_service = relationships
        self.relationship_service: FamilyService = relationships

    async def cog_load(self) -> None:
        """Start the ten-minute-trade reaper once this extension is loaded."""
        self.expire_trades.start()

    def cog_unload(self) -> None:
        """Stop the periodic expiry task when the extension unloads."""
        self.expire_trades.cancel()

    @tasks.loop(seconds=30.0)
    async def expire_trades(self) -> None:
        """Expire pending offers, logging any error so the loop survives failures."""
        try:
            expired = await self.service.expire_pending()
            if expired:
                logger.info("Expired %s player trade offer(s)", expired)
        except Exception:
            logger.exception("Trade-expiry task failed; it will retry on the next loop")

    @expire_trades.before_loop
    async def before_expire_trades(self) -> None:
        """Wait until the bot is connected before running background database work."""
        await self.bot.wait_until_ready()

    shop = app_commands.Group(name="shop", description="Browse and purchase items")
    inventory_group = app_commands.Group(name="inventory", description="Review and manage your items")
    trade = app_commands.Group(name="trade", description="Offer items and cash to another player")

    @shop.command(name="browse", description="Browse the paginated item shop")
    @app_commands.describe(category="Optional catalog category to browse")
    @app_commands.choices(category=[app_commands.Choice(name=value.title(), value=value) for value in SHOP_CATEGORIES])
    @app_commands.checks.cooldown(1, 4.0, key=lambda interaction: interaction.user.id)
    async def browse_shop(self, interaction: discord.Interaction, category: Optional[str] = None) -> None:
        """Render a paginated shop browser with age-gated purchase quotes."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        items = await self.service.browse(interaction.user.id, category)
        view = ShopBrowseView(
            interaction.user.id, self.service, items, category, self.achievement_service
        )
        message = await interaction.followup.send(embed=view.make_embed(), view=view, ephemeral=True, wait=True)
        view.bind_message(message)

    @shop.command(name="buy", description="Get a versioned purchase quote for an item")
    @app_commands.describe(item="Item catalog entry", quantity="Number to purchase for stackable items")
    @app_commands.autocomplete(item=shop_item_autocomplete)
    @app_commands.checks.cooldown(1, 4.0, key=lambda interaction: interaction.user.id)
    async def buy_item(self, interaction: discord.Interaction, item: str, quantity: int = 1) -> None:
        """Show a price, remaining balance, and cash or financing confirmation."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        quote = await self.service.quote_purchase(interaction.user.id, item, quantity)
        view = ShopQuoteView(interaction.user.id, quote, self.service, self.achievement_service)
        message = await interaction.followup.send(embed=quote_embed(quote), view=view, ephemeral=True, wait=True)
        view.bind_message(message)

    @shop.command(name="ring", description="Buy an engagement ring for your next proposal")
    @app_commands.describe(ring="Ring item to purchase")
    @app_commands.choices(ring=RING_CHOICES)
    @app_commands.checks.cooldown(1, 3.0, key=lambda interaction: interaction.user.id)
    async def buy_ring(self, interaction: discord.Interaction, ring: str) -> None:
        """Preserve relationship-ring purchases under the unified shop command group."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        cost, bonus = await self.relationship_service.buy_ring(interaction.user.id, ring)
        item = RING_CATALOG[ring]
        await interaction.followup.send(
            f"Purchased **{safe_text(item['name'])}** for {format_cents(cost)}. It gives +{bonus}% proposal acceptance.",
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @inventory_group.command(name="view", description="View your inventory and current item values")
    @app_commands.checks.cooldown(1, 4.0, key=lambda interaction: interaction.user.id)
    async def inventory_status(self, interaction: discord.Interaction) -> None:
        """Show current holdings, locks, collateral, and liquid balances."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        character, items = await self.service.inventory(interaction.user.id)
        embed = discord.Embed(title=f"{safe_text(character.name)} · Inventory", color=discord.Color.blurple())
        embed.description = (
            f"Cash: {format_cents(character.cash)} · Bank: {format_cents(character.bank)}\n"
            f"Life age: {character.age}"
        )
        if not items:
            embed.add_field(name="Items", value="Your inventory is empty.", inline=False)
        else:
            lines: list[str] = []
            for row in items[:25]:
                flags = []
                if row["is_locked"]:
                    flags.append("locked in trade")
                if row["collateralized"]:
                    flags.append("loan collateral")
                line = (
                    f"`#{row['asset_id']}` **{safe_text(row['name'], 100)}** ×{row['quantity']} — "
                    f"{format_cents(int(row['current_value']))}"
                )
                if flags:
                    line += " · " + ", ".join(flags)
                lines.append(line)
            embed.add_field(name="Items", value="\n".join(lines), inline=False)
            if len(items) > 25:
                embed.set_footer(text=f"Showing the first 25 of {len(items)} item lots")
        await interaction.followup.send(embed=embed, ephemeral=True)

    @inventory_group.command(name="sell", description="Sell unlocked items at current market value")
    @app_commands.describe(item="Item catalog entry in your inventory", quantity="Number of copies to sell")
    @app_commands.autocomplete(item=inventory_item_autocomplete)
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def sell_item(self, interaction: discord.Interaction, item: str, quantity: int = 1) -> None:
        """Sell at 85% of current value, or 94% for housing, never shop price."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        receipt = await self.service.sell(interaction.user.id, item, quantity)
        await interaction.followup.send(
            f"Sold {receipt.quantity} × **{safe_text(receipt.item_name)}** for "
            f"{format_cents(receipt.payout)}. Remaining liquid balance: {format_cents(receipt.remaining_balance)}.",
            ephemeral=True,
        )

    @inventory_group.command(name="use", description="Use an eligible item from your inventory")
    @app_commands.describe(item="Item catalog entry in your inventory")
    @app_commands.autocomplete(item=inventory_item_autocomplete)
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def use_item(self, interaction: discord.Interaction, item: str) -> None:
        """Apply item effects, consuming a consumable or recording a reusable use."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        if item.lower().strip() == "lottery_ticket":
            casino = getattr(self.bot, "casino_service", None)
            if casino is None:
                raise RuntimeError("Casino service is unavailable.")
            receipt = await casino.use_lottery_ticket(interaction.user.id)
            await interaction.followup.send(receipt.message, ephemeral=True)
            return
        if item.lower().strip() == "gambling_rehab":
            casino = getattr(self.bot, "casino_service", None)
            if casino is None:
                raise RuntimeError("Casino service is unavailable.")
            before, after = await casino.use_rehab(interaction.user.id)
            await interaction.followup.send(
                f"Recovery treatment used. Gambling addiction reduced from {before} to {after}.",
                ephemeral=True,
            )
            return
        receipt = await self.service.use(interaction.user.id, item)
        stats = receipt.stats
        await interaction.followup.send(
            f"Used **{safe_text(receipt.item_name)}**. Remaining in selected stack: {receipt.quantity_remaining}. "
            f"Lottery payout: {format_cents(receipt.payout)}.\n"
            f"Health {stats.health} · Happiness {stats.happiness} · Fitness {stats.fitness} · Stress {stats.stress}.",
            ephemeral=True,
        )

    @trade.command(name="offer", description="Build and send a trade offer to another player")
    @app_commands.describe(target="The other player to trade with")
    @app_commands.checks.cooldown(1, 8.0, key=lambda interaction: interaction.user.id)
    async def offer_trade(self, interaction: discord.Interaction, target: discord.User) -> None:
        """Open paginated item selectors and a cash-entry modal for a trade."""
        if target.id == interaction.user.id:
            await interaction.response.send_message("You cannot trade with yourself.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True, thinking=True)
        initiator_created = int(interaction.user.created_at.timestamp())
        target_created = int(target.created_at.timestamp())
        await self.service.register_player(interaction.user.id, initiator_created)
        await self.service.register_player(target.id, target_created)
        offered, requested = await self.service.trade_candidates(interaction.user.id, target.id)
        view = TradeBuilderView(
            interaction.user.id, target.id, self.service, offered, requested,
            self.achievement_service,
        )
        message = await interaction.followup.send(embed=view.make_embed(), view=view, ephemeral=True, wait=True)
        view.bind_message(message)

    @trade.command(name="list", description="View your recent incoming and outgoing trades")
    @app_commands.checks.cooldown(1, 4.0, key=lambda interaction: interaction.user.id)
    async def list_trades(self, interaction: discord.Interaction) -> None:
        """Display the caller's recent trade status and any failure reason."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        character, rows = await self.service.trade_history(interaction.user.id)
        embed = discord.Embed(title=f"Recent trades · {safe_text(character.name)}", color=discord.Color.blurple())
        if not rows:
            embed.description = "No trade offers yet."
        else:
            lines = []
            for row in rows[:15]:
                side = "out" if int(row["from_user_id"]) == interaction.user.id else "in"
                line = (
                    f"**#{row['trade_id']}** · {side} · {safe_text(str(row['status']).title())} · "
                    f"offer {format_cents(int(row['offer_cash']))} / request {format_cents(int(row['request_cash']))}"
                )
                if row["outcome_message"]:
                    line += f"\n└ {safe_text(str(row['outcome_message']), 140)}"
                lines.append(line)
            embed.description = "\n".join(lines)
        await interaction.followup.send(embed=embed, ephemeral=True)

    @trade.command(name="cancel", description="Cancel one of your pending outgoing trades")
    @app_commands.describe(trade_id="Trade number shown by /trade list")
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def cancel_trade(self, interaction: discord.Interaction, trade_id: app_commands.Range[int, 1]) -> None:
        """Cancel an offer by ID and unlock its items."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await self.service.cancel_trade(int(trade_id), interaction.user.id)
        await interaction.followup.send(result.message, ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    """Register Stage 8 groups and start the persistent expiry worker."""
    await bot.add_cog(ShopCog(bot))
```

## `cogs/shop_views.py`

```python
"""Owner-bound Discord UI for shop quotes and player trade offers."""
from __future__ import annotations

import logging
import secrets
from typing import Any, Optional

import discord

from core.achievements import AchievementService
from core.errors import GameError
from core.money import format_cents, parse_cents
from core.shop import ShopQuote, ShopService, TradeReceipt, TradeResult
from cogs.legacy_views import check_and_notify_achievements

logger = logging.getLogger("lifeline.shop.views")


def safe_label(text: str, limit: int = 100) -> str:
    """Escape markdown and mentions before rendering catalog or player text."""
    escaped = discord.utils.escape_mentions(discord.utils.escape_markdown(str(text)))
    return escaped[:limit]


def quote_embed(quote: ShopQuote) -> discord.Embed:
    """Build a confirmation embed containing the quoted amount and resulting balance."""
    embed = discord.Embed(title=f"Confirm {safe_label(quote.item_name, 200)}", color=discord.Color.gold())
    embed.add_field(name="Quantity", value=str(quote.quantity), inline=True)
    embed.add_field(name="Unit price", value=format_cents(quote.unit_price), inline=True)
    embed.add_field(name="Total", value=format_cents(quote.total_price), inline=True)
    cash_remaining = quote.balance - quote.total_price
    embed.add_field(
        name="After cash purchase",
        value=format_cents(cash_remaining) if cash_remaining >= 0 else f"Need {format_cents(-cash_remaining)} more",
        inline=False,
    )
    if quote.finance_type is not None:
        finance_remaining = quote.balance - quote.down_payment
        embed.add_field(name="Financing", value=quote.finance_type.title(), inline=True)
        embed.add_field(name="Down payment", value=format_cents(quote.down_payment), inline=True)
        embed.add_field(name="Loan principal", value=format_cents(quote.loan_principal), inline=True)
        embed.add_field(name="Term", value=f"{quote.loan_term_years} in-game years", inline=True)
        embed.add_field(
            name="After down payment",
            value=format_cents(finance_remaining) if finance_remaining >= 0 else f"Need {format_cents(-finance_remaining)} more",
            inline=True,
        )
    embed.set_footer(text="This quote expires in 2 minutes. Any balance or price change requires a retry.")
    return embed


class ShopQuoteView(discord.ui.View):
    """Single-use, owner-only confirmation for one persisted shop quote."""

    def __init__(
        self,
        owner_id: int,
        quote: ShopQuote,
        service: ShopService,
        achievement_service: Optional[AchievementService] = None,
    ) -> None:
        super().__init__(timeout=120)
        self.owner_id = owner_id
        self.quote = quote
        self.service = service
        self.achievement_service = achievement_service
        self._used = False
        self._bound_message: Optional[discord.Message] = None
        cash = discord.ui.Button(
            label="Confirm cash purchase",
            style=discord.ButtonStyle.success,
            custom_id=f"shop:cash:{quote.nonce}",
            disabled=not quote.can_pay_cash,
            row=0,
        )
        cash.callback = self.confirm_cash
        self.add_item(cash)
        if quote.finance_type is not None:
            finance = discord.ui.Button(
                label=f"Finance · {format_cents(quote.down_payment)} down",
                style=discord.ButtonStyle.primary,
                custom_id=f"shop:finance:{quote.nonce}",
                disabled=quote.balance < quote.down_payment,
                row=0,
            )
            finance.callback = self.confirm_finance
            self.add_item(finance)
        cancel = discord.ui.Button(
            label="Cancel",
            style=discord.ButtonStyle.secondary,
            custom_id=f"shop:cancel:{quote.nonce}",
            row=1,
        )
        cancel.callback = self.cancel
        self.add_item(cancel)

    def bind_message(self, message: discord.Message) -> None:
        """Remember the sent quote message so its controls can be disabled on timeout."""
        self._bound_message = message

    async def confirm_cash(self, interaction: discord.Interaction) -> None:
        """Validate ownership and the stored quote nonce, then purchase for cash."""
        if not await self._authorize(interaction, "cash"):
            return
        await self._complete_purchase(interaction, "cash")

    async def confirm_finance(self, interaction: discord.Interaction) -> None:
        """Validate ownership and the stored quote nonce, then use secured financing."""
        if not await self._authorize(interaction, "finance"):
            return
        await self._complete_purchase(interaction, "finance")

    async def cancel(self, interaction: discord.Interaction) -> None:
        """Close the quote without changing the character's balances or items."""
        if not await self._authorize(interaction, "cancel"):
            return
        self._finish()
        await interaction.response.edit_message(content="Purchase cancelled.", embed=None, view=self)

    async def _authorize(self, interaction: discord.Interaction, action: str) -> bool:
        """Require the quote owner, matching custom-ID nonce, and unused view."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This shop confirmation belongs to another player.", ephemeral=True)
            return False
        expected = f"shop:{action}:{self.quote.nonce}"
        if self._used or not interaction.data or interaction.data.get("custom_id") != expected:
            await interaction.response.send_message("This shop button is stale. Request a new quote.", ephemeral=True)
            return False
        return True

    async def _complete_purchase(self, interaction: discord.Interaction, method: str) -> None:
        """Execute the purchase once and remove active controls on every result."""
        try:
            receipt = await self.service.purchase(
                self.owner_id,
                self.quote.item_id,
                self.quote.quantity,
                expected_version=self.quote.version,
                expected_total=self.quote.total_price,
                nonce=self.quote.nonce,
                payment_method=method,
                expected_down_payment=self.quote.down_payment if method == "finance" else None,
            )
            self._finish()
            embed = discord.Embed(title="Purchase complete", color=discord.Color.green())
            embed.description = (
                f"Bought **{receipt.quantity} × {safe_label(receipt.item_name, 150)}** for "
                f"{format_cents(receipt.total_price)}.\n"
                f"Paid now: {format_cents(receipt.paid_now)} · Remaining liquid balance: "
                f"{format_cents(receipt.remaining_balance)}."
            )
            if receipt.loan_principal:
                embed.add_field(name="Secured loan", value=format_cents(receipt.loan_principal), inline=False)
            await interaction.response.edit_message(content=None, embed=embed, view=self)
            await check_and_notify_achievements(
                interaction, self.achievement_service, interaction.user.id
            )
        except GameError as exc:
            self._finish()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
        except Exception:
            logger.exception("Unexpected error while confirming a shop quote")
            self._finish()
            await interaction.response.edit_message(
                content="The purchase could not be completed. Request a new quote and retry.", embed=None, view=self
            )

    def _finish(self) -> None:
        """Disable and stop this one-use view."""
        self._used = True
        self.disable_all_items()
        self.stop()

    async def on_timeout(self) -> None:
        """Disable expired shop controls if the message is still editable."""
        self._finish()
        if self._bound_message is not None:
            try:
                await self._bound_message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Timed-out shop quote message could not be edited", exc_info=True)


class ShopItemSelect(discord.ui.Select):
    """Select one paginated catalog entry, then request quantity when stackable."""

    def __init__(self, parent: "ShopBrowseView") -> None:
        self.parent_view = parent
        start = parent.page_index * parent.page_size
        page = parent.items[start:start + parent.page_size]
        options = [
            discord.SelectOption(
                label=safe_label(str(item["name"]), 100),
                value=str(item["id"]),
                description=f"{format_cents(int(item['price_cents']))} · age {item['min_age']}+",
            )
            for item in page
        ]
        super().__init__(
            placeholder="Choose an item to buy",
            min_values=1,
            max_values=1,
            options=options,
            custom_id=f"shop-browse:{parent.nonce}:select:{parent.page_index}",
            row=0,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        """Authorize the browser owner and create a quote or quantity prompt."""
        if not await self.parent_view._authorize(interaction, self.custom_id):
            return
        item = self.parent_view.service.get_item(self.values[0])
        if item is None:
            await interaction.response.send_message("That catalog entry is no longer available.", ephemeral=True)
            return
        if item["stackable"]:
            await interaction.response.send_modal(
                QuantityModal(self.parent_view.owner_id, self.parent_view.service, str(item["id"]), self.parent_view.nonce)
            )
            return
        try:
            quote = await self.parent_view.service.quote_purchase(self.parent_view.owner_id, str(item["id"]), 1)
            quote_view = ShopQuoteView(
                self.parent_view.owner_id, quote, self.parent_view.service,
                self.parent_view.achievement_service,
            )
            await interaction.response.send_message(embed=quote_embed(quote), view=quote_view, ephemeral=True)
            quote_view.bind_message(await interaction.original_response())
        except GameError as exc:
            await interaction.response.send_message(exc.message, ephemeral=True)


class ShopBrowseView(discord.ui.View):
    """Owner-only paginated shop browser with a quantity-select purchase flow."""

    page_size = 8

    def __init__(
        self,
        owner_id: int,
        service: ShopService,
        items: list[dict[str, Any]],
        category: Optional[str] = None,
        achievement_service: Optional[AchievementService] = None,
    ) -> None:
        super().__init__(timeout=180)
        self.owner_id = owner_id
        self.service = service
        self.achievement_service = achievement_service
        self.items = items
        self.category = category
        self.page_index = 0
        self.nonce = secrets.token_urlsafe(12)
        self._closed = False
        self._bound_message: Optional[discord.Message] = None
        self._refresh_items()

    def bind_message(self, message: discord.Message) -> None:
        """Remember the browser message for timeout cleanup."""
        self._bound_message = message

    def make_embed(self) -> discord.Embed:
        """Render the current page with local-price-index-adjusted prices."""
        embed = discord.Embed(
            title=f"Shop · {self.category.title() if self.category else 'All categories'}",
            color=discord.Color.blurple(),
        )
        start = self.page_index * self.page_size
        page = self.items[start:start + self.page_size]
        lines = [
            f"**{safe_label(str(item['name']), 100)}** — {format_cents(int(item['price_cents']))} · age {item['min_age']}+"
            for item in page
        ]
        embed.description = "\n".join(lines) if lines else "No items are available in this category."
        page_count = max(1, (len(self.items) + self.page_size - 1) // self.page_size)
        embed.set_footer(text=f"Page {self.page_index + 1}/{page_count} · Prices include your character's price index")
        return embed

    def _refresh_items(self) -> None:
        """Recreate page controls with unique session-scoped custom IDs."""
        self.clear_items()
        if self.items:
            self.add_item(ShopItemSelect(self))
        page_count = max(1, (len(self.items) + self.page_size - 1) // self.page_size)
        if page_count > 1:
            previous = discord.ui.Button(
                label="Previous", style=discord.ButtonStyle.secondary,
                custom_id=f"shop-browse:{self.nonce}:previous:{self.page_index}", row=1,
                disabled=self.page_index <= 0,
            )
            previous.callback = self.previous
            self.add_item(previous)
            following = discord.ui.Button(
                label="Next", style=discord.ButtonStyle.secondary,
                custom_id=f"shop-browse:{self.nonce}:next:{self.page_index}", row=1,
                disabled=self.page_index >= page_count - 1,
            )
            following.callback = self.next
            self.add_item(following)
        close = discord.ui.Button(
            label="Close", style=discord.ButtonStyle.danger,
            custom_id=f"shop-browse:{self.nonce}:close:{self.page_index}", row=1,
        )
        close.callback = self.close
        self.add_item(close)

    async def previous(self, interaction: discord.Interaction) -> None:
        """Move to the previous catalog page after owner/nonce validation."""
        if not await self._authorize(interaction, interaction.data.get("custom_id") if interaction.data else None):
            return
        self.page_index = max(0, self.page_index - 1)
        self._refresh_items()
        await interaction.response.edit_message(embed=self.make_embed(), view=self)

    async def next(self, interaction: discord.Interaction) -> None:
        """Move to the next catalog page after owner/nonce validation."""
        if not await self._authorize(interaction, interaction.data.get("custom_id") if interaction.data else None):
            return
        page_count = max(1, (len(self.items) + self.page_size - 1) // self.page_size)
        self.page_index = min(page_count - 1, self.page_index + 1)
        self._refresh_items()
        await interaction.response.edit_message(embed=self.make_embed(), view=self)

    async def close(self, interaction: discord.Interaction) -> None:
        """Close the browser and disable its controls."""
        if not await self._authorize(interaction, interaction.data.get("custom_id") if interaction.data else None):
            return
        self._closed = True
        self.disable_all_items()
        self.stop()
        await interaction.response.edit_message(content="Shop closed.", embed=None, view=self)

    async def _authorize(self, interaction: discord.Interaction, custom_id: Optional[str]) -> bool:
        """Require the owner and this browser's session nonce in the component ID."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This shop view belongs to another player.", ephemeral=True)
            return False
        if self._closed or not custom_id or not custom_id.startswith(f"shop-browse:{self.nonce}:"):
            await interaction.response.send_message("This shop view is stale. Open `/shop browse` again.", ephemeral=True)
            return False
        return True

    async def on_timeout(self) -> None:
        """Disable expired browse controls."""
        self.disable_all_items()
        self.stop()
        if self._bound_message is not None:
            try:
                await self._bound_message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Timed-out shop browser could not be edited", exc_info=True)


class QuantityModal(discord.ui.Modal, title="Choose a quantity"):
    """Owner-bound modal for stackable shop items."""

    quantity = discord.ui.TextInput(
        label="Quantity",
        placeholder="1",
        min_length=1,
        max_length=3,
        required=True,
    )

    def __init__(self, owner_id: int, service: ShopService, item_id: str, session_nonce: str) -> None:
        super().__init__(timeout=120, custom_id=f"quantity:{session_nonce}:{item_id}")
        self.owner_id = owner_id
        self.service = service
        self.item_id = item_id
        self.session_nonce = session_nonce

    async def on_submit(self, interaction: discord.Interaction) -> None:
        """Create a persisted quote only after validating the submitting owner and quantity."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This quantity form belongs to another player.", ephemeral=True)
            return
        expected_custom_id = f"quantity:{self.session_nonce}:{self.item_id}"
        if not interaction.data or interaction.data.get("custom_id") != expected_custom_id:
            await interaction.response.send_message("This quantity form is stale. Reopen the shop.", ephemeral=True)
            return
        try:
            amount = int(str(self.quantity.value).strip())
            quote = await self.service.quote_purchase(self.owner_id, self.item_id, amount)
            quote_view = ShopQuoteView(self.owner_id, quote, self.service, self.achievement_service)
            await interaction.response.send_message(embed=quote_embed(quote), view=quote_view, ephemeral=True)
            quote_view.bind_message(await interaction.original_response())
        except (ValueError, GameError) as exc:
            message = exc.message if isinstance(exc, GameError) else "Enter a whole-number quantity."
            await interaction.response.send_message(message, ephemeral=True)


class TradeBuilderView(discord.ui.View):
    """Owner-only trade composer with paginated item selectors and a cash modal."""

    def __init__(
        self,
        owner_id: int,
        target_id: int,
        service: ShopService,
        offered: list[dict[str, Any]],
        requested: list[dict[str, Any]],
        achievement_service: Optional[AchievementService] = None,
    ) -> None:
        super().__init__(timeout=240)
        self.owner_id = owner_id
        self.target_id = target_id
        self.service = service
        self.achievement_service = achievement_service
        self.offered_rows = offered
        self.requested_rows = requested
        self.selected_offer: set[int] = set()
        self.selected_request: set[int] = set()
        self.nonce = secrets.token_urlsafe(12)
        self._closed = False
        self._bound_message: Optional[discord.Message] = None
        self._add_controls()

    def bind_message(self, message: discord.Message) -> None:
        """Remember the builder's ephemeral message for timeout cleanup."""
        self._bound_message = message

    def make_embed(self) -> discord.Embed:
        """Summarize chosen item lots without exposing unescaped user-provided text."""
        offer_lines = self._selected_lines(self.offered_rows, self.selected_offer)
        request_lines = self._selected_lines(self.requested_rows, self.selected_request)
        embed = discord.Embed(title="Build a player trade", color=discord.Color.blurple())
        embed.description = (
            f"Choose unlocked, tradeable items for both sides, then enter cash amounts.\n"
            f"**Your items:** {', '.join(offer_lines) if offer_lines else 'None'}\n"
            f"**Requested items:** {', '.join(request_lines) if request_lines else 'None'}\n"
            "Cash is not escrowed; each side must have enough cash plus a 5% tax when accepted."
        )
        embed.set_footer(text="Trade proposals expire after 10 minutes · maximum 5 offers per player per UTC day")
        return embed

    def _add_controls(self) -> None:
        """Recreate composer buttons with a per-view nonce in each custom ID."""
        self.clear_items()
        offered = discord.ui.Button(
            label="Choose your items", style=discord.ButtonStyle.primary,
            custom_id=f"trade-build:{self.nonce}:offer", row=0,
        )
        offered.callback = self.choose_offered
        self.add_item(offered)
        requested = discord.ui.Button(
            label="Choose requested items", style=discord.ButtonStyle.primary,
            custom_id=f"trade-build:{self.nonce}:request", row=0,
        )
        requested.callback = self.choose_requested
        self.add_item(requested)
        send = discord.ui.Button(
            label="Enter cash and create offer", style=discord.ButtonStyle.success,
            custom_id=f"trade-build:{self.nonce}:cash", row=1,
        )
        send.callback = self.send_offer
        self.add_item(send)
        cancel = discord.ui.Button(
            label="Close", style=discord.ButtonStyle.secondary,
            custom_id=f"trade-build:{self.nonce}:close", row=1,
        )
        cancel.callback = self.close
        self.add_item(cancel)

    async def choose_offered(self, interaction: discord.Interaction) -> None:
        """Open a paginated selector for the initiator's eligible items."""
        if not await self._authorize(interaction):
            return
        picker = TradeItemPickerView(self, "offer")
        await interaction.response.edit_message(embed=picker.make_embed(), view=picker)

    async def choose_requested(self, interaction: discord.Interaction) -> None:
        """Open a paginated selector for the target's eligible items."""
        if not await self._authorize(interaction):
            return
        picker = TradeItemPickerView(self, "request")
        await interaction.response.edit_message(embed=picker.make_embed(), view=picker)

    async def send_offer(self, interaction: discord.Interaction) -> None:
        """Open the cash modal; the trade is created only on modal submission."""
        if not await self._authorize(interaction):
            return
        await interaction.response.send_modal(TradeCashModal(self))

    async def close(self, interaction: discord.Interaction) -> None:
        """Close the trade builder without reserving any items."""
        if not await self._authorize(interaction):
            return
        self._closed = True
        self.disable_all_items()
        self.stop()
        await interaction.response.edit_message(content="Trade builder closed.", embed=None, view=self)

    async def _authorize(self, interaction: discord.Interaction) -> bool:
        """Require the initiating owner and this builder's component nonce."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This trade builder belongs to another player.", ephemeral=True)
            return False
        custom_id = interaction.data.get("custom_id") if interaction.data else ""
        if self._closed or not str(custom_id).startswith(f"trade-build:{self.nonce}:"):
            await interaction.response.send_message("This trade builder is stale. Start `/trade offer` again.", ephemeral=True)
            return False
        return True

    @staticmethod
    def _selected_lines(rows: list[dict[str, Any]], selected: set[int]) -> list[str]:
        """Format selected item names and quantities for the current offer summary."""
        lines: list[str] = []
        for row in rows:
            if int(row["asset_id"]) in selected:
                lines.append(f"{int(row['quantity'])}× {safe_label(str(row['name']), 60)}")
        return lines

    async def on_timeout(self) -> None:
        """Disable an idle trade builder."""
        self._closed = True
        self.disable_all_items()
        self.stop()
        if self._bound_message is not None:
            try:
                await self._bound_message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Timed-out trade builder could not be edited", exc_info=True)


class TradeItemSelect(discord.ui.Select):
    """Multi-select one page of items while preserving choices on other pages."""

    def __init__(self, picker: "TradeItemPickerView") -> None:
        self.picker = picker
        rows = picker.page_rows()
        options = [
            discord.SelectOption(
                label=safe_label(f"{row['quantity']}× {row['name']}", 100),
                value=str(row["asset_id"]),
                description=f"Current value {format_cents(int(row['current_value']))} · lot #{row['asset_id']}",
                default=int(row["asset_id"]) in picker.selected_set,
            )
            for row in rows
        ]
        super().__init__(
            placeholder="Select item lots on this page",
            min_values=0,
            max_values=max(1, len(options)),
            options=options,
            custom_id=f"trade-picker:{picker.builder.nonce}:{picker.side}:{picker.page_index}",
            row=0,
            disabled=not options,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        """Update page selections after verifying the owner and component nonce."""
        if not await self.picker.authorize(interaction, self.custom_id):
            return
        current_ids = {int(row["asset_id"]) for row in self.picker.page_rows()}
        selection = self.picker.selected_set
        selection.difference_update(current_ids)
        selection.update(int(value) for value in self.values)
        await interaction.response.edit_message(embed=self.picker.make_embed(), view=self.picker)


class TradeItemPickerView(discord.ui.View):
    """Paginated owner-only selector that supports inventories over Discord's 25-option limit."""

    page_size = 25

    def __init__(self, builder: TradeBuilderView, side: str) -> None:
        super().__init__(timeout=240)
        self.builder = builder
        self.side = side
        self.owner_id = builder.owner_id
        self.page_index = 0
        self._closed = False
        self._refresh()

    @property
    def rows(self) -> list[dict[str, Any]]:
        """Return the side's current selectable item rows."""
        return self.builder.offered_rows if self.side == "offer" else self.builder.requested_rows

    @property
    def selected_set(self) -> set[int]:
        """Return the builder's persistent item selections for this side."""
        return self.builder.selected_offer if self.side == "offer" else self.builder.selected_request

    def page_rows(self) -> list[dict[str, Any]]:
        """Return rows on the currently selected page."""
        start = self.page_index * self.page_size
        return self.rows[start:start + self.page_size]

    def make_embed(self) -> discord.Embed:
        """Describe the current item page and selections retained across pages."""
        embed = discord.Embed(
            title="Choose offered item lots" if self.side == "offer" else "Choose requested item lots",
            color=discord.Color.blurple(),
        )
        selected_count = len(self.selected_set)
        if not self.rows:
            embed.description = "No unlocked, tradeable items are available on this side."
        else:
            page_count = max(1, (len(self.rows) + self.page_size - 1) // self.page_size)
            names = [safe_label(str(row["name"]), 80) for row in self.page_rows()]
            embed.description = f"Page {self.page_index + 1}/{page_count}: " + ", ".join(names)
        embed.set_footer(text=f"{selected_count} lot(s) selected. Revisit a page to change its selection.")
        return embed

    def _refresh(self) -> None:
        """Rebuild selector and page controls."""
        self.clear_items()
        if self.page_rows():
            self.add_item(TradeItemSelect(self))
        page_count = max(1, (len(self.rows) + self.page_size - 1) // self.page_size)
        if page_count > 1:
            previous = discord.ui.Button(
                label="Previous", style=discord.ButtonStyle.secondary,
                custom_id=f"trade-picker:{self.builder.nonce}:{self.side}:previous:{self.page_index}",
                row=1, disabled=self.page_index <= 0,
            )
            previous.callback = self.previous
            self.add_item(previous)
            following = discord.ui.Button(
                label="Next", style=discord.ButtonStyle.secondary,
                custom_id=f"trade-picker:{self.builder.nonce}:{self.side}:next:{self.page_index}",
                row=1, disabled=self.page_index >= page_count - 1,
            )
            following.callback = self.next
            self.add_item(following)
        done = discord.ui.Button(
            label="Done", style=discord.ButtonStyle.success,
            custom_id=f"trade-picker:{self.builder.nonce}:{self.side}:done:{self.page_index}", row=1,
        )
        done.callback = self.done
        self.add_item(done)

    async def previous(self, interaction: discord.Interaction) -> None:
        """Move to the previous selection page."""
        if not await self.authorize(interaction, interaction.data.get("custom_id") if interaction.data else None):
            return
        self.page_index = max(0, self.page_index - 1)
        self._refresh()
        await interaction.response.edit_message(embed=self.make_embed(), view=self)

    async def next(self, interaction: discord.Interaction) -> None:
        """Move to the next selection page."""
        if not await self.authorize(interaction, interaction.data.get("custom_id") if interaction.data else None):
            return
        page_count = max(1, (len(self.rows) + self.page_size - 1) // self.page_size)
        self.page_index = min(page_count - 1, self.page_index + 1)
        self._refresh()
        await interaction.response.edit_message(embed=self.make_embed(), view=self)

    async def done(self, interaction: discord.Interaction) -> None:
        """Return to the trade builder with selections intact."""
        if not await self.authorize(interaction, interaction.data.get("custom_id") if interaction.data else None):
            return
        self._closed = True
        self.stop()
        self.builder._add_controls()
        await interaction.response.edit_message(embed=self.builder.make_embed(), view=self.builder)

    async def authorize(self, interaction: discord.Interaction, custom_id: Optional[str]) -> bool:
        """Verify selector ownership and a current-side selector nonce."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This item selector belongs to another player.", ephemeral=True)
            return False
        expected_prefix = f"trade-picker:{self.builder.nonce}:{self.side}:"
        if self._closed or not custom_id or not custom_id.startswith(expected_prefix):
            await interaction.response.send_message("This item selector is stale. Reopen the trade builder.", ephemeral=True)
            return False
        return True


class TradeCashModal(discord.ui.Modal, title="Cash terms"):
    """Cash-entry form that creates the trade proposal on submit."""

    offer_cash = discord.ui.TextInput(
        label="Cash you offer (dollars)", placeholder="0.00", default="0.00", max_length=24, required=True
    )
    request_cash = discord.ui.TextInput(
        label="Cash you request (dollars)", placeholder="0.00", default="0.00", max_length=24, required=True
    )

    def __init__(self, builder: TradeBuilderView) -> None:
        super().__init__(timeout=180, custom_id=f"trade-cash:{builder.nonce}")
        self.builder = builder

    async def on_submit(self, interaction: discord.Interaction) -> None:
        """Validate author and money inputs, persist the offer, and DM its target."""
        if interaction.user.id != self.builder.owner_id:
            await interaction.response.send_message("This cash form belongs to another player.", ephemeral=True)
            return
        if not interaction.data or interaction.data.get("custom_id") != f"trade-cash:{self.builder.nonce}":
            await interaction.response.send_message("This cash form is stale. Reopen `/trade offer`.", ephemeral=True)
            return
        try:
            offer_amount = parse_cents(str(self.offer_cash.value))
            request_amount = parse_cents(str(self.request_cash.value))
            offer_map = {
                int(row["asset_id"]): int(row["quantity"])
                for row in self.builder.offered_rows if int(row["asset_id"]) in self.builder.selected_offer
            }
            request_map = {
                int(row["asset_id"]): int(row["quantity"])
                for row in self.builder.requested_rows if int(row["asset_id"]) in self.builder.selected_request
            }
            if not any(offer_map.values()) and not any(request_map.values()) and offer_amount == 0 and request_amount == 0:
                raise ValueError("A trade must contain at least one item or a nonzero cash amount.")
            await interaction.response.defer(ephemeral=True, thinking=True)
            receipt = await self.builder.service.create_trade(
                self.builder.owner_id,
                self.builder.target_id,
                offered_items=offer_map,
                requested_items=request_map,
                offer_cash=offer_amount,
                request_cash=request_amount,
            )
            target_view = TradeTargetView(
                self.builder.target_id, receipt, self.builder.service,
                self.builder.achievement_service,
            )
            try:
                target = await interaction.client.fetch_user(self.builder.target_id)
                target_embed = trade_offer_embed(receipt, self.builder.service, interaction.user)
                dm_message = await target.send(
                    embed=target_embed,
                    view=target_view,
                    allowed_mentions=discord.AllowedMentions.none(),
                )
                target_view.bind_message(dm_message)
            except discord.HTTPException:
                await self.builder.service.cancel_trade(receipt.trade_id, self.builder.owner_id, receipt.nonce)
                await interaction.followup.send(
                    "The target could not receive a trade DM, so the offer was cancelled and your items were unlocked.",
                    ephemeral=True,
                )
                return
            creator_view = TradeCreatorView(self.builder.owner_id, receipt, self.builder.service)
            creator_message = await interaction.followup.send(
                f"Trade **#{receipt.trade_id}** sent. Your offered items are locked until it is resolved or expires.",
                view=creator_view,
                ephemeral=True,
                wait=True,
            )
            creator_view.bind_message(creator_message)
            self.builder._closed = True
            self.builder.disable_all_items()
            self.builder.stop()
            if self.builder._bound_message is not None:
                try:
                    await self.builder._bound_message.edit(
                        content=f"Trade **#{receipt.trade_id}** sent; this builder is closed.",
                        embed=None,
                        view=self.builder,
                    )
                except discord.HTTPException:
                    logger.debug("Closed trade builder could not be refreshed", exc_info=True)
        except (ValueError, GameError) as exc:
            message = exc.message if isinstance(exc, GameError) else str(exc)
            if interaction.response.is_done():
                await interaction.followup.send(message, ephemeral=True)
            else:
                await interaction.response.send_message(message, ephemeral=True)
        except Exception:
            logger.exception("Unexpected error creating a player trade")
            if interaction.response.is_done():
                await interaction.followup.send("The trade could not be created. Please retry.", ephemeral=True)
            else:
                await interaction.response.send_message("The trade could not be created. Please retry.", ephemeral=True)


def trade_offer_embed(receipt: TradeReceipt, service: ShopService, initiator: Any) -> discord.Embed:
    """Format trade terms for the target without rendering untrusted mentions."""
    embed = discord.Embed(title=f"Trade Offer #{receipt.trade_id}", color=discord.Color.gold())
    embed.description = (
        f"From **{safe_label(getattr(initiator, 'display_name', getattr(initiator, 'name', 'Player')), 100)}**\n"
        f"Expires in 10 minutes. Cash is not escrowed; accepted cash transfers incur a 5% tax."
    )
    embed.add_field(name="They offer cash", value=format_cents(receipt.offer_cash), inline=True)
    embed.add_field(name="They request cash", value=format_cents(receipt.request_cash), inline=True)
    offer = [f"{quantity}× {safe_label(service.items[item_id]['name'], 80)}" for item_id, quantity in receipt.offer_items]
    request = [f"{quantity}× {safe_label(service.items[item_id]['name'], 80)}" for item_id, quantity in receipt.request_items]
    embed.add_field(name="Items offered to you", value="\n".join(offer) if offer else "None", inline=False)
    embed.add_field(name="Items requested from you", value="\n".join(request) if request else "None", inline=False)
    if receipt.imbalance_flag:
        embed.add_field(name="Value review", value="This offer was flagged for a large value imbalance.", inline=False)
    return embed


class TradeTargetView(discord.ui.View):
    """Nonce-bound Accept/Decline controls visible only to the target account."""

    def __init__(
        self,
        owner_id: int,
        receipt: TradeReceipt,
        service: ShopService,
        achievement_service: Optional[AchievementService] = None,
    ) -> None:
        super().__init__(timeout=600)
        self.owner_id = owner_id
        self.receipt = receipt
        self.service = service
        self.achievement_service = achievement_service
        self._used = False
        self._bound_message: Optional[discord.Message] = None
        accept = discord.ui.Button(
            label="Accept", style=discord.ButtonStyle.success,
            custom_id=f"trade-target:accept:{receipt.trade_id}:{receipt.nonce}", row=0,
        )
        accept.callback = self.accept
        self.add_item(accept)
        decline = discord.ui.Button(
            label="Decline", style=discord.ButtonStyle.danger,
            custom_id=f"trade-target:decline:{receipt.trade_id}:{receipt.nonce}", row=0,
        )
        decline.callback = self.decline
        self.add_item(decline)

    def bind_message(self, message: discord.Message) -> None:
        """Remember the target DM for expiry cleanup."""
        self._bound_message = message

    async def accept(self, interaction: discord.Interaction) -> None:
        """Revalidate and atomically accept the exact offer nonce."""
        if not await self._authorize(interaction, "accept"):
            return
        try:
            result = await self.service.accept_trade(self.receipt.trade_id, self.owner_id, self.receipt.nonce)
            self._finish()
            await interaction.response.edit_message(content=result.message, embed=None, view=self)
            await check_and_notify_achievements(
                interaction, self.achievement_service, interaction.user.id
            )
            other_user_id = int(self.receipt.from_user_id)
            if self.achievement_service is not None and other_user_id != interaction.user.id:
                try:
                    await self.achievement_service.check_user(
                        other_user_id, guild_id=interaction.guild_id
                    )
                except Exception:
                    logger.exception("Could not check trade achievements for user %s", other_user_id)
        except GameError as exc:
            self._finish()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
        except Exception:
            logger.exception("Unexpected error accepting trade %s", self.receipt.trade_id)
            self._finish()
            await interaction.response.edit_message(content="The trade could not be accepted. Check `/trade list`.", embed=None, view=self)

    async def decline(self, interaction: discord.Interaction) -> None:
        """Decline the target's offer and atomically release offered items."""
        if not await self._authorize(interaction, "decline"):
            return
        try:
            result = await self.service.decline_trade(self.receipt.trade_id, self.owner_id, self.receipt.nonce)
            self._finish()
            await interaction.response.edit_message(content=result.message, embed=None, view=self)
        except GameError as exc:
            self._finish()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)

    async def _authorize(self, interaction: discord.Interaction, action: str) -> bool:
        """Check target user, unused view, and the custom-ID trade nonce."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Only the target player can use these trade buttons.", ephemeral=True)
            return False
        expected = f"trade-target:{action}:{self.receipt.trade_id}:{self.receipt.nonce}"
        if self._used or not interaction.data or interaction.data.get("custom_id") != expected:
            await interaction.response.send_message("This trade button is stale or already used.", ephemeral=True)
            return False
        return True

    def _finish(self) -> None:
        """Disable both terminal controls after one target response."""
        self._used = True
        self.disable_all_items()
        self.stop()

    async def on_timeout(self) -> None:
        """Disable expired DM buttons; database expiry is handled by the cog task."""
        self._finish()
        if self._bound_message is not None:
            try:
                await self._bound_message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Timed-out trade DM could not be edited", exc_info=True)


class TradeCreatorView(discord.ui.View):
    """Nonce-bound cancel control for the player who opened the offer."""

    def __init__(self, owner_id: int, receipt: TradeReceipt, service: ShopService) -> None:
        super().__init__(timeout=600)
        self.owner_id = owner_id
        self.receipt = receipt
        self.service = service
        self._used = False
        self._bound_message: Optional[discord.Message] = None
        cancel = discord.ui.Button(
            label="Cancel offer", style=discord.ButtonStyle.danger,
            custom_id=f"trade-creator:cancel:{receipt.trade_id}:{receipt.nonce}",
        )
        cancel.callback = self.cancel
        self.add_item(cancel)

    def bind_message(self, message: discord.Message) -> None:
        """Remember the initiator's ephemeral offer message for timeout cleanup."""
        self._bound_message = message

    async def cancel(self, interaction: discord.Interaction) -> None:
        """Cancel the pending offer and unlock offered item lots."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Only the offerer can cancel this trade.", ephemeral=True)
            return
        expected = f"trade-creator:cancel:{self.receipt.trade_id}:{self.receipt.nonce}"
        if self._used or not interaction.data or interaction.data.get("custom_id") != expected:
            await interaction.response.send_message("This trade button is stale or already used.", ephemeral=True)
            return
        try:
            result = await self.service.cancel_trade(self.receipt.trade_id, self.owner_id, self.receipt.nonce)
            self._used = True
            self.disable_all_items()
            self.stop()
            await interaction.response.edit_message(content=result.message, view=self)
        except GameError as exc:
            self._used = True
            self.disable_all_items()
            self.stop()
            await interaction.response.edit_message(content=exc.message, view=self)

    async def on_timeout(self) -> None:
        """Disable the initiator's controls when their local view expires."""
        self._used = True
        self.disable_all_items()
        self.stop()
        if self._bound_message is not None:
            try:
                await self._bound_message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Timed-out trade creator view could not be edited", exc_info=True)

```

## `cogs/relationships.py`

```python
"""Discord slash commands and nonce-protected menus for Stage 6 relationships."""
from __future__ import annotations

from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from core.achievements import AchievementService
from core.errors import GameError, ValidationError
from core.family import (
    WEDDING_TIERS,
    DateOutcome,
    DateSearch,
    FamilyService,
    InfidelityPrompt,
    InteractionOutcome,
    ProposalOutcome,
)
from core.money import format_cents
from core.views import OwnedView
from cogs.legacy_views import check_and_notify_achievements


ACTION_CHOICES = [
    app_commands.Choice(name="Spend time", value="spend_time"),
    app_commands.Choice(name="Give a gift", value="gift"),
    app_commands.Choice(name="Compliment", value="compliment"),
    app_commands.Choice(name="Argue", value="argue"),
    app_commands.Choice(name="Ask for money (parents only)", value="ask_for_money"),
    app_commands.Choice(name="Insult", value="insult"),
]
WEDDING_CHOICES = [
    app_commands.Choice(name="Courthouse · $100", value="courthouse"),
    app_commands.Choice(name="Intimate · $2,500", value="intimate"),
    app_commands.Choice(name="Traditional · $25,000", value="traditional"),
    app_commands.Choice(name="Lavish · $80,000 × price index", value="lavish"),
]
def _safe(value: object) -> str:
    """Escape user-facing names and suppress every Discord mention."""
    text = discord.utils.escape_markdown(str(value))
    return discord.utils.escape_mentions(text)


def _person_label(person: dict[str, object]) -> str:
    """Build a compact, escaped person label for family embeds."""
    name = _safe(person.get("name", "Unknown"))
    relation = _safe(person.get("relationship_type", "relative")).title()
    score = int(person.get("relationship_score", 0))
    alive = "Alive" if bool(person.get("is_alive", True)) else f"Died at age {person.get('death_age', '?')}"
    age = int(person.get("age", 0))
    return f"**{name}** · {relation} · age {age} · relationship {score}/100 · {alive}"


def _roster_embed(title: str, character: object, people: list[dict[str, object]]) -> discord.Embed:
    """Render a character's connected NPCs without exposing raw markdown or mentions."""
    name = _safe(getattr(character, "name", "Life"))
    age = int(getattr(character, "age", 0))
    embed = discord.Embed(
        title=f"{title} · {name}",
        description=f"Age {age} · {len(people)} connected person(s)",
        color=discord.Color.blurple(),
    )
    if not people:
        embed.add_field(name="Family and relationships", value="No people are recorded yet.", inline=False)
    for person in people[:20]:
        relation = str(person.get("relationship_type", "relative")).replace("_", " ").title()
        score = int(person.get("relationship_score", 0))
        value = _person_label(person)
        if person.get("custody"):
            value += f"\nCustody: {_safe(person['custody'])}"
        if int(person.get("child_support", 0) or 0) > 0:
            value += f" · Annual support: {format_cents(int(person['child_support']))}"
        embed.add_field(name=f"{relation} · {score}/100", value=value[:1024], inline=False)
    if len(people) > 20:
        embed.set_footer(text=f"Showing 20 of {len(people)} people")
    return embed


def _date_embed(search: DateSearch) -> discord.Embed:
    """Show all three date candidates as selectable profile cards."""
    embed = discord.Embed(
        title="Meet someone new",
        description="Choose one candidate below. Dating age rules are checked again when you select.",
        color=discord.Color.magenta(),
    )
    for index, person in enumerate(search.candidates, start=1):
        embed.add_field(
            name=f"Candidate {index} · {_safe(person['name'])}",
            value=(
                f"Age {person['age']} · {_safe(person['occupation'])}\n"
                f"Looks {person['looks']}/100 · Smarts {person['smarts']}/100 · "
                f"Health {person['health']}/100\n"
                f"Wealth: {format_cents(int(person['wealth']))}"
            ),
            inline=False,
        )
    embed.set_footer(text="This private selection expires in 15 minutes")
    return embed


def _date_outcome_embed(outcome: DateOutcome) -> discord.Embed:
    """Render a date result while retaining the calculated chance for feedback."""
    person = outcome.npc
    if outcome.accepted:
        title = f"A new relationship with {_safe(person['name'])}!"
        description = f"They agreed to date you. Your relationship score is 60/100."
        color = discord.Color.green()
    else:
        title = "The date didn't work out"
        description = f"{_safe(person['name'])} declined this time. You can meet new people with `/date find`."
        color = discord.Color.orange()
    embed = discord.Embed(title=title, description=description, color=color)
    embed.set_footer(text=f"Success chance: {outcome.success_chance:.1f}%")
    return embed


def _interaction_embed(outcome: InteractionOutcome) -> discord.Embed:
    """Render the score and money effect of one person-to-person action."""
    embed = discord.Embed(
        title=f"Relationship · {_safe(outcome.person_name)}",
        description=_safe(outcome.message),
        color=discord.Color.green() if outcome.score_after >= outcome.score_before else discord.Color.orange(),
    )
    embed.add_field(
        name="Relationship score",
        value=f"{outcome.score_before}/100 → {outcome.score_after}/100",
        inline=True,
    )
    if outcome.money_delta:
        embed.add_field(name="Money change", value=format_cents(outcome.money_delta), inline=True)
    embed.set_footer(text="Three interactions per person per in-game year")
    return embed


def _proposal_embed(outcome: ProposalOutcome) -> discord.Embed:
    """Render a proposal result."""
    result = "accepted" if outcome.accepted else "declined"
    return discord.Embed(
        title="💍 Proposal " + result,
        description=(
            f"{_safe(outcome.person_name)} {result} your proposal.\n"
            f"Acceptance chance: {outcome.chance}% · Ring bonus: +{outcome.ring_bonus}%"
        ),
        color=discord.Color.green() if outcome.accepted else discord.Color.orange(),
    )


class DateCandidateSelect(discord.ui.Select["DateSearchView"]):
    """A select menu whose custom ID and server-side nonce protect date options."""

    def __init__(self, search: DateSearch):
        options = [
            discord.SelectOption(
                label=f"{_safe(person['name'])} · age {person['age']}"[:100],
                description=f"{_safe(person['occupation'])} · looks {person['looks']} · smarts {person['smarts']}"[:100],
                value=str(person["npc_id"]),
            )
            for person in search.candidates
        ]
        super().__init__(
            placeholder="Choose a date",
            min_values=1,
            max_values=1,
            options=options,
            custom_id=f"lifeline:date:{search.nonce}",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        """Resolve one candidate and disable the menu after the one-use session."""
        view = self.view
        if not isinstance(view, DateSearchView):
            return
        try:
            await interaction.response.defer()
            outcome = await view.service.choose_date(interaction.user.id, int(self.values[0]), view.nonce)
            if interaction.message is not None:
                await interaction.message.edit(embed=_date_outcome_embed(outcome), view=None)
            view.stop()
            await check_and_notify_achievements(
                interaction, view.achievement_service, interaction.user.id
            )
        except GameError as exc:
            await interaction.followup.send(exc.message, ephemeral=True)
        except (ValueError, TypeError):
            await interaction.followup.send("That date selection is invalid.", ephemeral=True)


class DateSearchView(OwnedView):
    """Owner-checked select menu backed by a database nonce and expiry."""

    def __init__(
        self,
        owner_id: int,
        search: DateSearch,
        service: FamilyService,
        achievement_service: Optional[AchievementService] = None,
    ):
        super().__init__(owner_id, search.nonce, timeout=180.0)
        self.service = service
        self.achievement_service = achievement_service
        self.add_item(DateCandidateSelect(search))


class InfidelityChoiceView(OwnedView):
    """Owner-checked cheat-or-not choice with a persistent one-use nonce."""

    def __init__(
        self,
        owner_id: int,
        prompt: InfidelityPrompt,
        service: FamilyService,
        achievement_service: Optional[AchievementService] = None,
    ):
        super().__init__(owner_id, prompt.nonce, timeout=180.0)
        self.service = service
        self.achievement_service = achievement_service
        self.spouse_name = prompt.spouse_name
        self.add_item(InfidelityChoiceButton("Cheat", True, prompt.nonce))
        self.add_item(InfidelityChoiceButton("Stay faithful", False, prompt.nonce))

    async def resolve_choice(self, interaction: discord.Interaction, cheat: bool) -> None:
        """Resolve the selected temptation and remove controls after use."""
        try:
            await interaction.response.defer()
            message = await self.service.resolve_infidelity_choice(interaction.user.id, self.nonce, cheat)
            embed = discord.Embed(
                title="Relationship choice",
                description=_safe(message),
                color=discord.Color.orange() if cheat else discord.Color.green(),
            )
            if interaction.message is not None:
                await interaction.message.edit(embed=embed, view=None)
            self.stop()
            await check_and_notify_achievements(
                interaction, self.achievement_service, interaction.user.id
            )
        except GameError as exc:
            await interaction.followup.send(exc.message, ephemeral=True)


class InfidelityChoiceButton(discord.ui.Button[InfidelityChoiceView]):
    """One nonce-tagged infidelity option."""

    def __init__(self, label: str, cheat: bool, nonce: str):
        super().__init__(
            label=label,
            style=discord.ButtonStyle.danger if cheat else discord.ButtonStyle.success,
            custom_id=f"lifeline:temptation:{nonce}:{'cheat' if cheat else 'faithful'}",
        )
        self.cheat = cheat

    async def callback(self, interaction: discord.Interaction) -> None:
        """Delegate after the base view confirms component ownership."""
        if isinstance(self.view, InfidelityChoiceView):
            await self.view.resolve_choice(interaction, self.cheat)


class RelationshipsCog(commands.Cog):
    """Family, relationship, dating, friendship, and ring-shop slash commands."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.service = getattr(bot, "family_service", None) or FamilyService(
            bot.db, bot.rng, getattr(bot, "locks", None)
        )
        self.achievement_service = getattr(bot, "achievement_service", None)

    relationship = app_commands.Group(name="relationship", description="Manage friends, romance, and family")
    date = app_commands.Group(name="date", description="Meet age-appropriate dating candidates")
    friends = app_commands.Group(name="friends", description="Meet and manage friends")

    @app_commands.command(name="family", description="View your parents, siblings, partner, and children")
    @app_commands.checks.cooldown(1, 3.0)
    async def family_command(self, interaction: discord.Interaction) -> None:
        """Show the full current family and relationship roster."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        character, people = await self.service.family(interaction.user.id)
        await interaction.followup.send(
            embed=_roster_embed("Family", character, people),
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @relationship.command(name="list", description="List people and relationship scores")
    @app_commands.checks.cooldown(1, 3.0)
    async def relationship_list(self, interaction: discord.Interaction) -> None:
        """List all relatives, friends, partners, former partners, and children."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        character, people = await self.service.relationship_list(interaction.user.id)
        await interaction.followup.send(
            embed=_roster_embed("Relationships", character, people),
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @relationship.command(name="interact", description="Interact with one person up to three times per year")
    @app_commands.describe(
        person="A relative, friend, partner, or other listed NPC",
        action="Choose how to interact",
        gift_dollars="Gift amount in whole dollars (required for the gift action)",
    )
    @app_commands.choices(action=ACTION_CHOICES)
    @app_commands.checks.cooldown(1, 3.0)
    async def interact(
        self,
        interaction: discord.Interaction,
        person: str,
        action: str,
        gift_dollars: Optional[int] = None,
    ) -> None:
        """Apply a selected action to an autocomplete-selected person."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        npc_id = self._person_id(person)
        outcome = await self.service.interact(interaction.user.id, npc_id, action, gift_dollars)
        await interaction.followup.send(
            embed=_interaction_embed(outcome),
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @interact.autocomplete("person")
    async def interaction_person_autocomplete(
        self,
        interaction: discord.Interaction,
        current: str,
    ) -> list[app_commands.Choice[str]]:
        """Offer living connected NPCs with their relationship types."""
        return await self._autocomplete(interaction, current)

    @relationship.command(name="propose", description="Propose after a year together with a strong partner score")
    @app_commands.describe(person="Your current partner; optional owned rings boost acceptance")
    @app_commands.checks.cooldown(1, 3.0)
    async def propose(self, interaction: discord.Interaction, person: str) -> None:
        """Propose to an eligible partner."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        outcome = await self.service.propose(interaction.user.id, self._person_id(person))
        await interaction.followup.send(
            embed=_proposal_embed(outcome),
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @propose.autocomplete("person")
    async def propose_person_autocomplete(
        self,
        interaction: discord.Interaction,
        current: str,
    ) -> list[app_commands.Choice[str]]:
        """Autocomplete connected living NPCs for a proposal."""
        return await self._autocomplete(interaction, current, types={"partner"})

    @relationship.command(name="marry", description="Hold a wedding with your fiance")
    @app_commands.describe(wedding="Wedding size", prenup="Protect premarital cash, bank, and property in divorce")
    @app_commands.choices(wedding=WEDDING_CHOICES)
    @app_commands.checks.cooldown(1, 3.0)
    async def marry(self, interaction: discord.Interaction, wedding: str = "courthouse", prenup: bool = False) -> None:
        """Complete a wedding at the chosen indexed cost and optionally record a prenup."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await self.service.marry(interaction.user.id, wedding, prenup)
        embed = discord.Embed(
            title="💒 Wedding complete",
            description=(
                f"You married **{_safe(result.person_name)}**.\n"
                f"Wedding cost: {format_cents(result.wedding_cost)}\n"
                f"Prenup: {'signed' if result.prenup else 'not signed'}\n"
                f"Spouse annual income: {format_cents(result.annual_income)}"
            ),
            color=discord.Color.gold(),
        )
        await interaction.followup.send(embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @relationship.command(name="divorce", description="End a marriage and settle assets, custody, and support")
    @app_commands.checks.cooldown(1, 3.0)
    async def divorce(self, interaction: discord.Interaction) -> None:
        """Run a transactional divorce with asset division, legal fees, and custody."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        outcome = await self.service.divorce(interaction.user.id)
        embed = discord.Embed(
            title="Divorce finalized",
            description=(
                f"{_safe(outcome.spouse_name)} is now your ex-spouse.\n"
                f"Eligible marital assets: {format_cents(outcome.marital_assets)}\n"
                f"Spouse share: {format_cents(outcome.spouse_share)}\n"
                f"Lawyer fees: {format_cents(outcome.lawyer_fee)}\n"
                f"Children affected: {outcome.children}"
            ),
            color=discord.Color.orange(),
        )
        if outcome.alimony_annual:
            embed.add_field(
                name="Alimony",
                value=(
                    f"{format_cents(outcome.alimony_annual)} per year for "
                    f"{outcome.alimony_years:g} year(s)"
                ),
                inline=False,
            )
        await interaction.followup.send(embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @relationship.command(name="breakup", description="End a dating or engagement relationship")
    @app_commands.describe(person="Your current partner or fiance")
    @app_commands.checks.cooldown(1, 3.0)
    async def breakup(self, interaction: discord.Interaction, person: str) -> None:
        """Break up with an autocomplete-selected partner or fiance."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        message = await self.service.breakup(interaction.user.id, self._person_id(person))
        await interaction.followup.send(_safe(message), ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @breakup.autocomplete("person")
    async def breakup_person_autocomplete(
        self,
        interaction: discord.Interaction,
        current: str,
    ) -> list[app_commands.Choice[str]]:
        """Autocomplete living partners and fiances for breakup."""
        return await self._autocomplete(interaction, current, types={"partner", "fiance"})

    @relationship.command(name="try_for_baby", description="Try for a baby with your partner or spouse")
    @app_commands.checks.cooldown(1, 3.0)
    async def try_for_baby(self, interaction: discord.Interaction) -> None:
        """Use the age-based fertility curve to start a one-year pregnancy."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        success, chance = await self.service.try_for_baby(interaction.user.id)
        message = (
            f"Pregnancy started. The baby is due after your next `/life age`. Chance was {chance * 100:.1f}%."
            if success
            else f"No pregnancy this year. Estimated chance was {chance * 100:.1f}%; you may try again next year."
        )
        await interaction.followup.send(_safe(message), ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @relationship.command(name="adopt", description="Begin a paid adoption with a one-year wait")
    @app_commands.checks.cooldown(1, 3.0)
    async def adopt(self, interaction: discord.Interaction) -> None:
        """Pay the indexed adoption fee and schedule the child's arrival next year."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        cost = await self.service.adopt(interaction.user.id)
        await interaction.followup.send(
            f"Adoption started. The child will join after your next `/life age`. Cost: {format_cents(cost)}.",
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @relationship.command(name="temptation", description="Choose whether to cheat or stay faithful")
    @app_commands.checks.cooldown(1, 3.0)
    async def temptation(self, interaction: discord.Interaction) -> None:
        """Create a one-use infidelity choice event for a married character."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        prompt = await self.service.start_infidelity_choice(interaction.user.id)
        embed = discord.Embed(
            title="A moment of temptation",
            description=f"Your spouse **{_safe(prompt.spouse_name)}** is not here. What do you do?\n\n"
                        "If you cheat, there is a 35% discovery chance each year.",
            color=discord.Color.orange(),
        )
        view = InfidelityChoiceView(
            interaction.user.id, prompt, self.service, self.achievement_service
        )
        message = await interaction.followup.send(
            embed=embed,
            view=view,
            ephemeral=True,
            wait=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        view.bind_message(message)

    @date.command(name="find", description="Find three age-appropriate dating candidates")
    @app_commands.checks.cooldown(1, 3.0)
    async def date_find(self, interaction: discord.Interaction) -> None:
        """Generate three NPC candidates and present an owner-only select menu."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        search = await self.service.find_dates(interaction.user.id)
        view = DateSearchView(
            interaction.user.id, search, self.service, self.achievement_service
        )
        message = await interaction.followup.send(
            embed=_date_embed(search),
            view=view,
            ephemeral=True,
            wait=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        view.bind_message(message)

    @friends.command(name="find", description="Meet an age-appropriate friend")
    @app_commands.checks.cooldown(1, 3.0)
    async def friend_find(self, interaction: discord.Interaction) -> None:
        """Generate one age-appropriate friend NPC."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        person = await self.service.find_friend(interaction.user.id)
        embed = discord.Embed(
            title=f"You met {_safe(person['name'])}!",
            description=(
                f"Age {person['age']} · {_safe(person['occupation'])}\n"
                f"Relationship score: {person['relationship_score']}/100"
            ),
            color=discord.Color.green(),
        )
        await interaction.followup.send(embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @staticmethod
    def _person_id(value: str) -> int:
        """Parse the opaque NPC ID supplied by autocomplete without accepting names."""
        try:
            npc_id = int(value)
        except (TypeError, ValueError) as exc:
            raise ValidationError("Select a person from the autocomplete list.") from exc
        if npc_id <= 0:
            raise ValidationError("Select a person from the autocomplete list.")
        return npc_id

    async def _autocomplete(
        self,
        interaction: discord.Interaction,
        current: str,
        *,
        types: Optional[set[str]] = None,
    ) -> list[app_commands.Choice[str]]:
        """Create escaped Discord choices from the current life's people."""
        people = await self.service.autocomplete_people(interaction.user.id, current)
        if types is not None:
            people = [person for person in people if str(person["relationship_type"]) in types]
        return [
            app_commands.Choice(
                name=f"{_safe(person['name'])} · {_safe(person['relationship_type'])} · age {person['age']}"[:100],
                value=str(person["npc_id"]),
            )
            for person in people[:25]
        ]


async def setup(bot: commands.Bot) -> None:
    """Load the Stage 6 command cog."""
    await bot.add_cog(RelationshipsCog(bot))
```

## `cogs/invest.py`

```python
"""Stage 9 /invest commands and a resilient ten-minute global market ticker."""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands, tasks

from core.investing import InvestingService, StockQuote
from core.money import dollars_to_cents, format_cents
from cogs.legacy_views import check_and_notify_achievements

logger = logging.getLogger("lifeline.investing.cog")


async def stock_autocomplete(
    interaction: discord.Interaction,
    current: str,
) -> list[app_commands.Choice[str]]:
    """Suggest fictional ticker symbols and company names from the validated catalog."""
    service = getattr(interaction.client, "investing_service", None)
    if service is None:
        return []
    return [
        app_commands.Choice(name=f"{symbol} · {name}", value=symbol)
        for symbol, name in service.symbol_options(current)
    ][:25]


def _market_description(rows: list[StockQuote]) -> str:
    """Render the market's change and sparkline as compact plain text."""
    if not rows:
        return "No stocks are currently listed."
    lines: list[str] = []
    for row in rows:
        name = discord.utils.escape_markdown(discord.utils.escape_mentions(row.name))[:55]
        if row.delisted:
            lines.append(f"`{row.symbol:<6}` **{name}** · DELISTED · {row.sparkline}")
        else:
            sign = "+" if row.change_cents > 0 else ""
            lines.append(
                f"`{row.symbol:<6}` **{name}** · {format_cents(row.price_cents)} "
                f"({sign}{row.change_percent:.2f}% / {format_cents(row.change_cents)}) · `{row.sparkline}`"
            )
    return "\n".join(lines)


class InvestingCog(commands.Cog):
    """Investment commands plus a transactional, idempotent global ticker loop."""

    invest = app_commands.Group(name="invest", description="Trade stocks, review a portfolio, or buy bonds")
    bonds = app_commands.Group(name="bonds", description="Buy five-year fixed-return savings bonds", parent=invest)

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        service = getattr(bot, "investing_service", None)
        if service is None:
            service = InvestingService(bot.db, bot.rng, getattr(bot, "locks", None))
            bot.investing_service = service
        self.service: InvestingService = service
        self.achievement_service = getattr(bot, "achievement_service", None)

    async def cog_load(self) -> None:
        """Ensure market seed state and start the ten-minute tick task."""
        await self.service.initialize_market()
        if not self.market_tick.is_running():
            self.market_tick.start()

    def cog_unload(self) -> None:
        """Cancel the market task when its extension is unloaded."""
        self.market_tick.cancel()

    @tasks.loop(minutes=10.0)
    async def market_tick(self) -> None:
        """Run a global tick; catch/log transactional failures so the loop survives."""
        try:
            result = await self.service.tick_global()
            if result.ticks:
                logger.info(
                    "Market advanced %s tick(s) through tick %s; events=%s",
                    result.ticks, result.last_tick_no, result.events or "none",
                )
        except Exception:
            logger.exception("Global stock ticker transaction failed; database changes rolled back; retrying next cycle")

    @market_tick.before_loop
    async def before_market_tick(self) -> None:
        """Wait until Discord startup is complete before the first market tick."""
        await self.bot.wait_until_ready()

    @market_tick.error
    async def market_tick_error(self, error: Exception) -> None:
        """Log unexpected loop-level errors and restart a stopped ticker after a short delay."""
        logger.error("Global stock ticker stopped unexpectedly", exc_info=(type(error), error, error.__traceback__))
        asyncio.create_task(self._restart_market_tick())

    async def _restart_market_tick(self) -> None:
        """Restart the market loop after the current task has fully unwound."""
        await asyncio.sleep(2.0)
        if not self.market_tick.is_running():
            try:
                self.market_tick.start()
                logger.warning("Global stock ticker restarted")
            except RuntimeError:
                logger.exception("Could not restart the stock ticker")

    @invest.command(name="market", description="View fictional tickers, 24-hour changes, and sparklines")
    @app_commands.checks.cooldown(1, 2.0, key=lambda interaction: interaction.user.id)
    async def market(self, interaction: discord.Interaction) -> None:
        """Show the current market snapshot and each company's 24-hour movement."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        rows = await self.service.market(interaction.user.id)
        embed = discord.Embed(
            title="Global Stock Market",
            description=_market_description(rows),
            color=discord.Color.blurple(),
        )
        embed.set_footer(text="Fictional market · prices update globally every 10 minutes · not real financial advice")
        await interaction.followup.send(embed=embed, ephemeral=True)

    @invest.command(name="buy", description="Buy whole shares from your bank at the current price")
    @app_commands.describe(
        symbol="Ticker to buy; use autocomplete",
        amount="Number of whole shares to buy (bank balance only; 0.5% fee, $1 minimum)",
    )
    @app_commands.autocomplete(symbol=stock_autocomplete)
    @app_commands.checks.cooldown(1, 1.0, key=lambda interaction: interaction.user.id)
    async def buy(self, interaction: discord.Interaction, symbol: str, amount: app_commands.Range[int, 1, 1_000_000_000]) -> None:
        """Buy shares at the transaction-time market price with anti-churn checks."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        receipt = await self.service.buy(interaction.user.id, symbol, int(amount))
        await interaction.followup.send(receipt.message, ephemeral=True)
        await check_and_notify_achievements(
            interaction, self.achievement_service, interaction.user.id
        )

    @invest.command(name="sell", description="Sell whole shares or your entire position")
    @app_commands.describe(
        symbol="Ticker to sell; use autocomplete",
        shares="Positive whole share count or `all`",
    )
    @app_commands.autocomplete(symbol=stock_autocomplete)
    @app_commands.checks.cooldown(1, 1.0, key=lambda interaction: interaction.user.id)
    async def sell(self, interaction: discord.Interaction, symbol: str, shares: str) -> None:
        """Sell shares at the transaction-time market price and record realized gains."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        receipt = await self.service.sell(interaction.user.id, symbol, shares)
        await interaction.followup.send(receipt.message, ephemeral=True)
        await check_and_notify_achievements(
            interaction, self.achievement_service, interaction.user.id
        )

    @invest.command(name="portfolio", description="View stock holdings, cost basis, bonds, and value")
    @app_commands.checks.cooldown(1, 2.0, key=lambda interaction: interaction.user.id)
    async def portfolio(self, interaction: discord.Interaction) -> None:
        """Display fee-inclusive cost basis, unrealized gains, and locked bonds."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        holdings, bonds, bank = await self.service.portfolio(interaction.user.id)
        embed = discord.Embed(title="Investment Portfolio", color=discord.Color.green())
        embed.description = f"Bank balance: {format_cents(bank)}"
        if holdings:
            lines = []
            for row in holdings:
                symbol = str(row["symbol"])
                company = discord.utils.escape_markdown(str(row["company_name"] or symbol))[:55]
                worthless = bool(row["is_delisted"])
                market_value = int(row["market_value_cents"])
                gain = int(row["unrealized_gain_cents"])
                flag = " · DELISTED / worthless" if worthless else ""
                lines.append(
                    f"**{symbol}** · {company} · {int(row['shares']):,} share(s) · "
                    f"basis {format_cents(int(row['cost_basis_cents']))} · value {format_cents(market_value)} · "
                    f"P/L {format_cents(gain, include_plus=True)}{flag}"
                )
            embed.add_field(name="Stocks", value="\n".join(lines[:25]), inline=False)
        else:
            embed.add_field(name="Stocks", value="No stock holdings yet.", inline=False)
        if bonds:
            bond_lines = [
                f"Bond #{row['bond_id']} · balance {format_cents(int(row['balance_cents']))} · "
                f"matures age {row['maturity_age']} · 3.5% fixed"
                for row in bonds[:20]
            ]
            embed.add_field(name="Locked bonds", value="\n".join(bond_lines), inline=False)
        else:
            embed.add_field(name="Locked bonds", value="No active bonds.", inline=False)
        await interaction.followup.send(embed=embed, ephemeral=True)

    @invest.command(name="history", description="View a ticker's recent prices and your executions")
    @app_commands.describe(symbol="Ticker to review; use autocomplete")
    @app_commands.autocomplete(symbol=stock_autocomplete)
    @app_commands.checks.cooldown(1, 2.0, key=lambda interaction: interaction.user.id)
    async def history(self, interaction: discord.Interaction, symbol: str) -> None:
        """Display recent prices, event markers, and the player's stock trades."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        stock, history, trades = await self.service.trade_history(interaction.user.id, symbol)
        lines = [
            f"`{datetime.fromtimestamp(int(row['recorded_at']), tz=timezone.utc).strftime('%b %d %H:%M UTC')}` · "
            f"{format_cents(int(row['price_cents']))} · {row['event_type']}"
            for row in history[-15:]
        ]
        if trades:
            lines.append("\n**Your executions**")
            lines.extend(
                f"{str(row['side']).upper()} {int(row['shares'])} @ {format_cents(int(row['price_cents']))} · "
                f"fee {format_cents(int(row['fee_cents']))} · realized {format_cents(int(row['realized_gain_cents']), include_plus=True)}"
                for row in trades
            )
        embed = discord.Embed(
            title=f"{str(stock['symbol'])} · {discord.utils.escape_markdown(str(stock['company_name']))}",
            description="\n".join(lines) if lines else "No price ticks recorded yet.",
            color=discord.Color.blurple(),
        )
        status = "DELISTED / worthless" if bool(stock["is_delisted"]) else f"Current: {format_cents(int(stock['price_cents']))}"
        embed.set_footer(text=f"{stock['sector'].title()} · {status} · oldest rows trimmed after 500 ticks")
        await interaction.followup.send(embed=embed, ephemeral=True)

    @bonds.command(name="buy", description="Buy a five-year locked bond earning 3.5% fixed annually")
    @app_commands.describe(amount="Principal in dollars; paid from your bank balance only")
    @app_commands.checks.cooldown(1, 2.0, key=lambda interaction: interaction.user.id)
    async def buy_bond(self, interaction: discord.Interaction, amount: float) -> None:
        """Buy a five-character-year savings bond."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        receipt = await self.service.bond_buy(interaction.user.id, dollars_to_cents(amount))
        await interaction.followup.send(receipt.message, ephemeral=True)
        await check_and_notify_achievements(
            interaction, self.achievement_service, interaction.user.id
        )


async def setup(bot: commands.Bot) -> None:
    """Register investment commands and start the global ticker."""
    await bot.add_cog(InvestingCog(bot))
```

## `bot.py`

```python
"""LIFELINE Discord bot entry point."""
from __future__ import annotations

import asyncio
import logging
import secrets
import time

import discord
from discord import app_commands
from discord.ext import commands

from core.achievements import AchievementService
from core.casino import CasinoService
from core.config import Config
from core.crime import CrimeService
from core.db import DatabaseManager
from core.errors import GameError
from core.family import FamilyService
from core.investing import InvestingService
from core.locks import UserLockRegistry
from core.rng import RNG
from core.shop import ShopService

logging.basicConfig(
    level=getattr(logging, Config.from_env().log_level, logging.INFO),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("lifeline")


class LifelineBot(commands.Bot):
    """Main bot class, owning shared database, RNG, and action-lock services."""

    def __init__(self, config: Config | None = None):
        self.config = config or Config.from_env()
        intents = discord.Intents.default()
        # The entertainment cog includes a small message listener; it needs the
        # privileged Message Content intent enabled in the Discord developer portal.
        intents.message_content = True
        super().__init__(
            command_prefix=commands.when_mentioned_or("!"),
            intents=intents,
            help_command=None,
            allowed_mentions=discord.AllowedMentions(
                everyone=False,
                users=True,
                roles=False,
                replied_user=False,
            ),
        )
        self.db: DatabaseManager | None = None
        self.family_service: FamilyService | None = None
        self.crime_service: CrimeService | None = None
        self.shop_service: ShopService | None = None
        self.casino_service: CasinoService | None = None
        self.investing_service: InvestingService | None = None
        self.achievement_service: AchievementService | None = None
        self.rng: RNG = RNG(self.config.rng_seed)
        self.locks = UserLockRegistry()
        self.tree.on_error = self.on_app_command_error

    async def setup_hook(self) -> None:
        """Initialize shared services, extensions, and application commands."""
        self.db = DatabaseManager(self.config.db_path)
        await self.db.initialize()
        self.family_service = FamilyService(self.db, self.rng, self.locks)
        self.crime_service = CrimeService(
            self.db,
            self.rng,
            self.locks,
            family_service=self.family_service,
        )
        self.shop_service = ShopService(self.db, self.rng, self.locks)
        self.casino_service = CasinoService(self.db, self.rng, self.locks)
        recovered = await self.casino_service.recover_sessions()
        if recovered:
            logger.warning("Refunded %s unfinished blackjack session(s) at startup", recovered)
        self.investing_service = InvestingService(self.db, self.rng, self.locks)
        await self.investing_service.initialize_market()
        # Catalog loading is validated at process startup, not deferred until a command.
        self.achievement_service = AchievementService(self.db, self.locks)
        await self._load_cogs()

        if self.config.dev_guild_id is not None:
            guild = discord.Object(id=self.config.dev_guild_id)
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
            logger.info("Synced application commands to development guild %s", guild.id)
        else:
            await self.tree.sync()
            logger.info("Synced application commands globally")

    async def _load_cogs(self) -> None:
        """Load Stage 1–10 simulation, casino, investing, shop, and legacy extensions."""
        for extension in (
            "cogs.life",
            "cogs.education",
            "cogs.career",
            "cogs.relationships",
            "cogs.crime",
            "cogs.prison",
            "cogs.shop",
            "cogs.casino",
            "cogs.invest",
            "cogs.discobot",
            "cogs.legacy",
        ):
            await self.load_extension(extension)
            logger.info("Loaded extension %s", extension)

    async def on_ready(self) -> None:
        if self.user is not None:
            logger.info("Logged in as %s (ID: %s)", self.user, self.user.id)
        logger.info("Connected to %s guilds", len(self.guilds))
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="lives unfold | /life",
            ),
            status=discord.Status.online,
        )

    async def on_app_command_completion(
        self, interaction: discord.Interaction, command: app_commands.Command
    ) -> None:
        """Record guild participation and deliver new authoritative unlock notices."""
        if self.db is None or self.achievement_service is None:
            return
        user_id = int(interaction.user.id)
        try:
            if interaction.guild_id is not None:
                from core.repositories.legacy import LegacyRepository
                async with self.db.transaction() as tx:
                    await LegacyRepository(self.db).record_guild_seen(
                        tx, int(interaction.guild_id), user_id, int(time.time())
                    )
            root = str(command.qualified_name).split()[0]
            relevant_roots = {
                "life", "start", "education", "career", "relationship", "relationships",
                "date", "friends", "family", "crime", "prison", "shop", "casino", "invest",
                "stocks", "bonds", "trade", "inventory", "retire_life",
            }
            if root in relevant_roots:
                await self.achievement_service.check_user(
                    user_id, guild_id=interaction.guild_id
                )
            notices = self.achievement_service.consume_notifications(user_id)
            for start in range(0, len(notices), 5):
                group = notices[start:start + 5]
                lines = [
                    f"🏆 **{discord.utils.escape_markdown(str(item['name']))}** — "
                    f"{discord.utils.escape_mentions(str(item['description']))}"
                    for item in group
                ]
                embed = discord.Embed(
                    title="Achievement unlocked!" if len(group) == 1 else "Achievements unlocked!",
                    description="\n".join(lines),
                    color=discord.Color.gold(),
                )
                await interaction.followup.send(
                    embed=embed,
                    ephemeral=True,
                    allowed_mentions=discord.AllowedMentions.none(),
                )
        except Exception:
            logger.exception("Could not evaluate Stage 10 achievements for user %s", user_id)

    async def on_app_command_error(
        self,
        interaction: discord.Interaction,
        error: app_commands.AppCommandError,
    ) -> None:
        """Send safe user-facing errors and retain unexpected errors in logs."""
        if isinstance(error, app_commands.CommandOnCooldown):
            message = f"⏳ Try again in {error.retry_after:.1f} seconds."
        elif isinstance(error, (app_commands.CheckFailure, commands.CheckFailure)):
            message = "❌ You do not have permission to use this command."
        else:
            original = getattr(error, "original", error)
            if isinstance(original, GameError):
                message = original.message
            else:
                error_id = __import__("secrets").token_hex(4)
                logger.error(
                    "Unexpected application-command error (ID %s)",
                    error_id,
                    exc_info=(type(original), original, original.__traceback__),
                )
                message = f"An unexpected error occurred (ID: {error_id}). Please try again later."
        await self._send_error(interaction, message)

    @staticmethod
    async def _send_error(interaction: discord.Interaction, message: str) -> None:
        try:
            if interaction.response.is_done():
                await interaction.followup.send(message, ephemeral=True)
            else:
                await interaction.response.send_message(message, ephemeral=True)
        except discord.HTTPException:
            logger.exception("Could not send an application-command error response")

    async def close(self) -> None:
        logger.info("Shutting down LIFELINE")
        if self.db is not None:
            await self.db.close()
        await super().close()


async def main() -> None:
    config = Config.from_env()
    token = config.require_token()
    bot = LifelineBot(config)
    async with bot:
        await bot.start(token)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
```

## `tests/test_migrations.py`

```python
"""Migration repeatability and Stage 10 schema/rollback checks."""
from __future__ import annotations

import sqlite3
from pathlib import Path

import aiosqlite
import pytest


@pytest.mark.asyncio
async def test_initialize_is_idempotent(database):
    await database.initialize()
    await database.close()
    await database.initialize()
    versions = await database.fetchall("SELECT version FROM schema_version ORDER BY version")
    assert [row["version"] for row in versions] == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    tables = {row["name"] for row in await database.fetchall(
        "SELECT name FROM sqlite_master WHERE type = 'table'"
    )}
    assert {
        "characters", "life_logs", "schema_version", "education_actions", "jobs",
        "career_history", "career_actions", "npcs", "relationships", "children",
        "yearly_counters", "dating_sessions", "dating_candidates", "marriages",
        "pregnancies", "adoptions", "family_assets", "alimony", "affairs",
        "divorce_records", "stats_tracking", "infidelity_prompts", "infidelity_choices",
        "players", "shop_quotes", "trades", "trade_items", "trade_daily_usage",
        "inventory_uses", "audit_log", "health_conditions", "casino_player_state",
        "casino_yearly_bets", "casino_plays", "casino_sessions", "casino_compulsions",
        "casino_yearly_tax", "market_state", "stock_market", "stock_history",
        "stock_holdings", "investment_trades", "savings_bonds", "investment_yearly_income",
        "achievements_unlocked", "life_year_metrics", "marriage_history", "past_lives",
        "life_estates", "retirement_prompts", "legacy_start_purchases", "guild_player_seen",
        "guild_stage10_settings",
    }.issubset(tables)
    family_asset_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(family_assets)")}
    loan_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(loans)")}
    shop_quote_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(shop_quotes)")}
    assert "is_locked" in family_asset_columns
    assert {"principal", "annual_rate", "term_years", "years_remaining", "collateral_item_uid"}.issubset(loan_columns)
    assert {"nonce", "total_price", "balance_cents", "character_version", "expires_at"}.issubset(shop_quote_columns)
    stats_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(stats_tracking)")}
    assert {"total_gambled", "total_gambling_net", "gambling_addiction_fraction"}.issubset(stats_columns)
    player_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(players)")}
    assert {"lives_lived", "legacy_points", "leaderboard_opt_out"}.issubset(player_columns)
    achievement_columns = {row["name"] for row in await database.fetchall("PRAGMA table_info(achievements_unlocked)")}
    assert {"user_id", "achievement_id", "char_id", "unlocked_at"}.issubset(achievement_columns)
    archive_triggers = {
        row["name"] for row in await database.fetchall(
            "SELECT name FROM sqlite_master WHERE type = 'trigger' AND tbl_name = 'past_lives'"
        )
    }
    assert {"trg_past_lives_immutable_update", "trg_past_lives_immutable_delete"}.issubset(archive_triggers)


@pytest.mark.asyncio
async def test_stage10_migration_rolls_back_all_schema_changes_on_failure(tmp_path):
    """A failure after migration 009 statements leaves no partial columns or tables."""
    db_path = tmp_path / "migration-009-rollback.sqlite3"
    async with aiosqlite.connect(db_path) as db:
        await db.execute("PRAGMA foreign_keys = ON")
        await db.execute("CREATE TABLE schema_version(version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)")
        await db.execute("INSERT INTO schema_version(version, applied_at) VALUES (8, 0)")
        await db.execute("CREATE TABLE players(user_id INTEGER PRIMARY KEY, created_at INTEGER NOT NULL)")
        await db.execute("CREATE TABLE characters(char_id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, born_at INTEGER NOT NULL)")
        await db.commit()

    migration = Path(__file__).resolve().parents[1] / "core" / "migrations" / "009_achievements_legacy.sql"
    sql = migration.read_text(encoding="utf-8")
    script = (
        "BEGIN IMMEDIATE;\n"
        + sql
        + "\nINSERT INTO schema_version(version, applied_at) VALUES (9, 1);"
        + "\nINSERT INTO deliberately_missing_table(value) VALUES (1);\nCOMMIT;"
    )
    async with aiosqlite.connect(db_path) as db:
        await db.execute("PRAGMA foreign_keys = ON")
        with pytest.raises(sqlite3.OperationalError, match="no such table"):
            await db.executescript(script)
        await db.rollback()

    async with aiosqlite.connect(db_path) as db:
        columns = await (await db.execute("PRAGMA table_info(players)")).fetchall()
        tables = await (await db.execute("SELECT name FROM sqlite_master WHERE type = 'table'")).fetchall()
        version = await (await db.execute("SELECT MAX(version) FROM schema_version")).fetchone()
    assert {row[1] for row in columns} == {"user_id", "created_at"}
    assert "achievements_unlocked" not in {row[0] for row in tables}
    assert int(version[0]) == 8
```

## `tests/test_stage10.py`

```python
"""Integration coverage for Stage 10 scoring, death, estates, achievements, and rankings."""
from __future__ import annotations

from dataclasses import replace
from typing import Any

import aiosqlite
import pytest

from core.death import (
    calculate_estate_settlement,
    calculate_life_score,
    grade_for_life_score,
    legacy_points_for_score,
    select_epitaph,
)
from core.errors import InsufficientFunds, ValidationError
from core.leaderboard import LeaderboardService
from core.money import dollars_to_cents
from core.repositories.legacy import LegacyRepository
from core.rng import RNG
from core.life_engine import LifeEngine
from core.locks import UserLockRegistry
from cogs.legacy_views import EmbedPager, leaderboard_embed


async def _make_dead_life(
    engine: LifeEngine,
    user_id: int,
    *,
    age: int = 40,
    cash_cents: int = 0,
    bank_cents: int = 0,
    debt_cents: int = 0,
    price_index: float = 1.0,
    happiness: int = 70,
    cause: str = "natural causes",
    now: int = 1_800_000_000,
    guild_id: int | None = None,
) -> tuple[Any, Any]:
    """Create and atomically archive one persisted terminal character."""
    character = await engine.create_character(user_id, f"Life {user_id}")
    dead = replace(
        character,
        is_alive=False,
        age=age,
        cash=cash_cents,
        bank=bank_cents,
        debt_total=debt_cents,
        price_index=price_index,
        stats=replace(character.stats, happiness=happiness),
        death_cause=cause,
        death_age=age,
        died_at=now,
        last_age_at=now,
        version=character.version + 1,
    )
    async with engine.db.transaction() as tx:
        await engine._save_character(tx, dead, expected_version=character.version)
        result = await engine.death.handle_death(
            tx, dead, now=now, guild_id=guild_id
        )
    return dead, result


async def _insert_child(
    engine: LifeEngine,
    parent_char_id: int,
    *,
    name: str,
    age: int,
    health: int,
    smarts: int,
    looks: int,
    wealth_cents: int,
    gender: str = "female",
    country: str = "usa",
) -> int:
    """Insert one authoritative child NPC for estate-continuation tests."""
    async with engine.db.transaction() as tx:
        cursor = await tx.execute(
            """INSERT INTO npcs
                   (owner_char_id, name, gender, age, looks, smarts, health, wealth,
                    occupation, is_alive, country, annual_income, prefers_smarts)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Student', 1, ?, 0, 0)""",
            (parent_char_id, name, gender, age, looks, smarts, health, wealth_cents, country),
        )
        npc_id = int(cursor.lastrowid)
        await tx.execute(
            "INSERT INTO children(npc_id, char_id, custody, child_support) VALUES (?, ?, 'full', 0)",
            (npc_id, parent_char_id),
        )
    return npc_id


async def _set_character_age(engine: LifeEngine, user_id: int, age: int) -> Any:
    """Change an active character's authoritative persisted age for ranking checks."""
    character = await engine.get_active_character(user_id)
    updated = replace(character, age=age, version=character.version + 1)
    async with engine.db.transaction() as tx:
        await engine._save_character(tx, updated, expected_version=character.version)
    return updated


def test_life_score_examples_grade_boundaries_and_legacy_rounding():
    """The documented score components, grade boundaries, and points rule are stable."""
    maximum = calculate_life_score(
        age=120,
        average_happiness=100,
        final_health=100,
        education_level="doctorate",
        career_years=100,
        children=20,
        marriage_count=1,
        peak_net_worth_cents=dollars_to_cents(20_000_000),
        unsealed_convictions=0,
    )
    minimum = calculate_life_score(
        age=0,
        average_happiness=0,
        final_health=0,
        education_level="none",
        career_years=0,
        children=0,
        marriage_count=0,
        peak_net_worth_cents=0,
        unsealed_convictions=1,
    )
    assert maximum == 100.0
    assert minimum == 0.0
    assert [(score, grade_for_life_score(score)) for score in (0, 39.99, 40, 54.99, 55, 69.99, 70, 79.99, 80, 89.99, 90, 100)] == [
        (0, "F"), (39.99, "F"), (40, "D"), (54.99, "D"),
        (55, "C"), (69.99, "C"), (70, "B"), (79.99, "B"),
        (80, "A"), (89.99, "A"), (90, "S"), (100, "S"),
    ]
    assert legacy_points_for_score(99.99) == 9
    assert legacy_points_for_score(100) == 10


@pytest.mark.parametrize(
    ("gross", "debt", "price_index", "paid", "tax", "estate", "unpaid"),
    [
        (dollars_to_cents(5_500_000), dollars_to_cents(500_000), 1.0,
         dollars_to_cents(500_000), 0, dollars_to_cents(5_000_000), 0),
        (dollars_to_cents(10_000_000), dollars_to_cents(1_000_000), 1.0,
         dollars_to_cents(1_000_000), dollars_to_cents(1_600_000), dollars_to_cents(7_400_000), 0),
        (dollars_to_cents(100), dollars_to_cents(500), 1.0, dollars_to_cents(100), 0, 0, dollars_to_cents(400)),
        (0, dollars_to_cents(2_000_000), 10.0, 0, 0, 0, dollars_to_cents(2_000_000)),
    ],
)
def test_estate_settlement_pays_debt_before_tax_and_never_goes_negative(
    gross: int,
    debt: int,
    price_index: float,
    paid: int,
    tax: int,
    estate: int,
    unpaid: int,
):
    """Debt is paid before the indexed threshold tax and every remainder is nonnegative."""
    result = calculate_estate_settlement(
        gross_assets_cents=gross,
        debts_due_cents=debt,
        price_index=price_index,
    )
    assert result.debts_paid_cents == paid
    assert result.estate_tax_cents == tax
    assert result.estate_cents == estate
    assert result.unpaid_debt_cents == unpaid
    assert min(result.debts_paid_cents, result.estate_tax_cents, result.estate_cents, result.unpaid_debt_cents) >= 0
    assert result.estate_cents + result.estate_tax_cents <= gross - paid


@pytest.mark.asyncio
async def test_death_is_exactly_once_archived_immutable_and_closes_career(database, life_engine):
    """A terminal life archives once, preserves its score, and closes career rows as died."""
    character = await life_engine.create_character(51001, "Archived Life")
    async with database.transaction() as tx:
        await tx.execute(
            """INSERT INTO career_history(char_id, career_id, max_level, start_age)
               VALUES (?, 'teacher', 2, 20)""",
            (character.char_id,),
        )
        await tx.execute(
            """INSERT INTO jobs(char_id, career_id, level, performance, years_in_role,
                                years_in_career, salary, is_part_time, warnings)
               VALUES (?, 'teacher', 2, 60, 4, 10, 5_000_000, 0, 0)""",
            (character.char_id,),
        )
        await life_engine.legacy_repository.record_life_year(
            tx, character=replace(character, stats=replace(character.stats, happiness=80)),
            age=1, served_prison_year=False, now=1_800_000_001,
        )
        await life_engine.legacy_repository.record_life_year(
            tx, character=replace(character, stats=replace(character.stats, happiness=100)),
            age=2, served_prison_year=False, now=1_800_000_002,
        )
    dead = replace(
        character,
        is_alive=False,
        age=40,
        death_cause="illness",
        death_age=40,
        died_at=1_800_000_010,
        last_age_at=1_800_000_010,
        version=character.version + 1,
        stats=replace(character.stats, happiness=60),
    )
    async with database.transaction() as tx:
        await life_engine._save_character(tx, dead, expected_version=character.version)
        await life_engine.legacy_repository.record_life_year(
            tx, character=dead, age=40, served_prison_year=False, now=1_800_000_010
        )
        result = await life_engine.death.handle_death(tx, dead, now=1_800_000_010)
    assert result is not None
    assert result.summary["death_age"] == 40
    assert result.summary["career_years"] == 20
    assert result.summary["average_happiness"] == 80.0
    assert result.summary["grade"] == grade_for_life_score(result.summary["life_score"])
    assert result.summary["legacy_points"] == legacy_points_for_score(result.summary["life_score"])
    career = await database.fetchone(
        "SELECT end_age, end_reason FROM career_history WHERE char_id = ?",
        (character.char_id,),
    )
    assert dict(career) == {"end_age": 40, "end_reason": "died"}
    assert await database.fetchone("SELECT 1 FROM jobs WHERE char_id = ?", (character.char_id,)) is None

    async with database.transaction() as tx:
        assert await life_engine.death.handle_death(tx, dead, now=1_800_000_011) is None
    archive_count = await database.fetchone(
        "SELECT COUNT(*) AS n FROM past_lives WHERE char_id = ?", (character.char_id,)
    )
    assert int(archive_count["n"]) == 1
    player = await database.fetchone("SELECT lives_lived, legacy_points FROM players WHERE user_id = ?", (character.user_id,))
    assert int(player["lives_lived"]) == 1
    assert int(player["legacy_points"]) == result.summary["legacy_points"]

    with pytest.raises(aiosqlite.IntegrityError, match="immutable"):
        async with database.transaction() as tx:
            await tx.execute("UPDATE past_lives SET grade = 'S' WHERE char_id = ?", (character.char_id,))
    with pytest.raises(aiosqlite.IntegrityError, match="immutable"):
        async with database.transaction() as tx:
            await tx.execute("DELETE FROM past_lives WHERE char_id = ?", (character.char_id,))
    archived = await database.fetchone("SELECT grade FROM past_lives WHERE char_id = ?", (character.char_id,))
    assert archived["grade"] == result.summary["grade"]


@pytest.mark.asyncio
async def test_estate_lot_value_debt_first_tax_and_heir_split_and_copy(database, life_engine):
    """Death values each inventory lot once, pays debt before tax, and divides heirs fairly."""
    character = await life_engine.create_character(51002, "Estate Parent")
    character = replace(
        character,
        cash=dollars_to_cents(6_000_000),
        bank=0,
        debt_total=dollars_to_cents(1_000_000),
        price_index=1.25,
        version=character.version + 1,
    )
    async with database.transaction() as tx:
        await life_engine._save_character(tx, character, expected_version=character.version - 1)
        await tx.execute(
            """INSERT INTO family_assets
                   (char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at)
               VALUES (?, 'item', 'house', 10, ?, ?, 25, 1_800_000_001)""",
            (character.char_id, dollars_to_cents(200_000), dollars_to_cents(2_000_000)),
        )
    child_ids = [
        await _insert_child(
            life_engine, character.char_id, name="Avery", age=35, health=91,
            smarts=87, looks=73, wealth_cents=dollars_to_cents(250_000), gender="female", country="ca",
        ),
        await _insert_child(
            life_engine, character.char_id, name="Rowan", age=29, health=82,
            smarts=94, looks=68, wealth_cents=dollars_to_cents(150_000), gender="non_binary", country="in",
        ),
    ]
    dead = replace(
        character,
        is_alive=False,
        age=60,
        death_cause="natural causes",
        death_age=60,
        died_at=1_800_000_020,
        last_age_at=1_800_000_020,
        version=character.version + 1,
    )
    async with database.transaction() as tx:
        await life_engine._save_character(tx, dead, expected_version=character.version)
        result = await life_engine.death.handle_death(tx, dead, now=1_800_000_020)
    assert result is not None
    assert result.summary["gross_assets_cents"] == dollars_to_cents(8_000_000)
    assert result.summary["debts_paid_cents"] == dollars_to_cents(1_000_000)
    assert result.summary["estate_tax_threshold_cents"] == dollars_to_cents(6_250_000)
    assert result.summary["estate_tax_cents"] == dollars_to_cents(300_000)
    assert result.summary["estate_cents"] == dollars_to_cents(6_700_000)
    assert result.estate_id is not None and result.estate_nonce
    assert len(result.heirs) == 2
    assert [row["inheritance_cents"] for row in result.heirs] == [dollars_to_cents(3_350_000)] * 2
    assert sum(int(row["inheritance_cents"]) for row in result.heirs) == result.summary["estate_cents"]

    selected_id = child_ids[0]
    heir = await life_engine.death.choose_heir(
        character.user_id, result.estate_id, result.estate_nonce, selected_id,
        now=1_800_000_030,
    )
    assert heir is not None
    assert heir.name == "Avery"
    assert heir.age == 35
    assert heir.gender.value == "female"
    assert heir.country == "ca"
    assert heir.stats.health == 91
    assert heir.stats.smarts == 87
    assert heir.stats.looks == 73
    assert heir.cash == dollars_to_cents(3_350_000)
    assert heir.bank == 0 and heir.debt_total == 0
    assert heir.price_index == 1.25
    assert heir.parent_char_id == character.char_id
    assert heir.generation == character.generation + 1
    assert heir.is_alive
    active = await life_engine.get_active_character(character.user_id)
    assert active.char_id == heir.char_id
    assert active.cash >= 0 and active.bank >= 0 and active.debt_total >= 0
    estate = await database.fetchone("SELECT status, selected_npc_id FROM life_estates WHERE estate_id = ?", (result.estate_id,))
    assert estate["status"] == "claimed"
    assert int(estate["selected_npc_id"]) == selected_id


@pytest.mark.asyncio
async def test_zero_value_estate_still_offers_living_adult_heir(database, life_engine):
    """A living adult child can continue the family even when the inheritance is zero."""
    character = await life_engine.create_character(51012, "No Estate Parent")
    npc_id = await _insert_child(
        life_engine, character.char_id, name="Sam", age=22, health=76,
        smarts=81, looks=63, wealth_cents=0,
    )
    dead = replace(
        character,
        is_alive=False,
        age=50,
        death_cause="natural causes",
        death_age=50,
        died_at=1_800_000_025,
        last_age_at=1_800_000_025,
        version=character.version + 1,
    )
    async with database.transaction() as tx:
        await life_engine._save_character(tx, dead, expected_version=character.version)
        result = await life_engine.death.handle_death(tx, dead, now=1_800_000_025)
    assert result is not None and result.estate_id is not None
    assert result.summary["estate_cents"] == 0
    assert len(result.heirs) == 1
    assert int(result.heirs[0]["inheritance_cents"]) == 0
    heir = await life_engine.death.choose_heir(
        character.user_id, result.estate_id, result.estate_nonce or "", npc_id,
        now=1_800_000_026,
    )
    assert heir is not None
    assert heir.cash == 0 and heir.bank == 0 and heir.debt_total == 0
    assert heir.parent_char_id == character.char_id


@pytest.mark.asyncio
async def test_death_summary_visibility_obeys_guild_setting_and_player_opt_out(database, life_engine):
    """Public obituaries require both guild permission and the player's consent."""
    repository = LegacyRepository(database)
    async with database.transaction() as tx:
        await repository.set_guild_public_death_summaries(
            tx, guild_id=9002, enabled=True, user_id=51013, now=1_800_000_010
        )
    _, public_result = await _make_dead_life(
        life_engine, 51013, now=1_800_000_011, guild_id=9002
    )
    assert public_result is not None and public_result.public_summary is True
    async with database.transaction() as tx:
        await repository.set_leaderboard_privacy(
            tx, 51014, True, now=1_800_000_012
        )
    _, private_result = await _make_dead_life(
        life_engine, 51014, now=1_800_000_013, guild_id=9002
    )
    assert private_result is not None and private_result.public_summary is False


@pytest.mark.asyncio
async def test_death_transaction_rolls_back_every_write_and_pending_notice(database, life_engine, monkeypatch):
    """An injected mid-archive error rolls back death fields, archives, balances, and unlocks."""
    character = await life_engine.create_character(51003, "Rollback Life")
    dead = replace(
        character,
        is_alive=False,
        age=1,
        death_cause="natural causes",
        death_age=1,
        died_at=1_800_000_040,
        last_age_at=1_800_000_040,
        version=character.version + 1,
    )
    insert_past_life = life_engine.death.repository.insert_past_life

    async def insert_then_fail(tx: Any, summary: dict[str, Any]) -> bool:
        await insert_past_life(tx, summary)
        raise RuntimeError("forced failure after archive insert")

    monkeypatch.setattr(life_engine.death.repository, "insert_past_life", insert_then_fail)
    with pytest.raises(RuntimeError, match="forced failure"):
        async with database.transaction() as tx:
            await life_engine._save_character(tx, dead, expected_version=character.version)
            await life_engine.death.handle_death(tx, dead, now=1_800_000_040)
    persisted = await database.fetchone("SELECT is_alive, death_cause FROM characters WHERE char_id = ?", (character.char_id,))
    assert int(persisted["is_alive"]) == 1
    assert persisted["death_cause"] is None
    assert await database.fetchone("SELECT 1 FROM past_lives WHERE char_id = ?", (character.char_id,)) is None
    assert await database.fetchone("SELECT 1 FROM achievements_unlocked WHERE user_id = ?", (character.user_id,)) is None
    assert await database.fetchone(
        "SELECT 1 FROM players WHERE user_id = ?", (character.user_id,)
    ) is None
    assert life_engine.achievements.consume_notifications(character.user_id) == []


@pytest.mark.asyncio
async def test_achievement_unlocks_are_authoritative_and_idempotent(database, life_engine):
    """Unlocks derive from persisted character state; repeated checks cannot duplicate rows."""
    character = await life_engine.create_character(51004, "New Steps")
    initial = await life_engine.achievements.check_user(character.user_id, now=1_800_000_050)
    assert "first_steps" not in {row["id"] for row in initial}
    life_engine.achievements.consume_notifications(character.user_id)
    with pytest.raises(TypeError):
        await life_engine.achievements.check_user(character.user_id, age=100)  # type: ignore[call-arg]
    with pytest.raises(TypeError):
        await life_engine.achievements.check_user(character.user_id, achievement_id="jackpot")  # type: ignore[call-arg]

    aged = replace(character, age=1, version=character.version + 1)
    async with database.transaction() as tx:
        await life_engine._save_character(tx, aged, expected_version=character.version)
    unlocked = await life_engine.achievements.check_user(character.user_id, now=1_800_000_051)
    assert "first_steps" in {row["id"] for row in unlocked}
    assert "first_steps" in {row["id"] for row in life_engine.achievements.consume_notifications(character.user_id)}
    repeated = await life_engine.achievements.check_user(character.user_id, now=1_800_000_052)
    assert "first_steps" not in {row["id"] for row in repeated}
    rows = await database.fetchall(
        "SELECT achievement_id FROM achievements_unlocked WHERE user_id = ? AND achievement_id = 'first_steps'",
        (character.user_id,),
    )
    assert len(rows) == 1


@pytest.mark.asyncio
async def test_year_tick_step_15_records_happiness_and_unlocks_first_steps(life_engine):
    """An ordinary age tick runs the Stage 10 metric and achievement step atomically."""
    character = await life_engine.create_character(51005, "Yearly Check")
    outcome = await life_engine.age_up(character.user_id)
    assert outcome.character.age == 1
    assert "first_steps" in {row["id"] for row in outcome.unlocked_achievements}
    metrics = await life_engine.db.fetchall(
        "SELECT age, happiness FROM life_year_metrics WHERE char_id = ? ORDER BY age",
        (character.char_id,),
    )
    assert len(metrics) == 1
    assert int(metrics[0]["age"]) == 1
    assert int(metrics[0]["happiness"]) == outcome.character.stats.happiness
    assert "first_steps" in {row["id"] for row in life_engine.achievements.consume_notifications(character.user_id)}


@pytest.mark.asyncio
async def test_legacy_purchase_is_capped_to_two_and_changes_no_money(database, life_engine):
    """Two earned purchases add at most ten stat points and deduct exactly 100 cosmetic points."""
    control_engine = LifeEngine(
        database,
        RNG(seed=2026),
        UserLockRegistry(),
        clock=lambda: 1_800_000_000,
        event_chance=0.0,
    )
    baseline = await control_engine.create_character(51006, "Baseline")
    async with database.transaction() as tx:
        await life_engine.legacy_repository.ensure_player(tx, 51007, 1_800_000_000)
        await tx.execute("UPDATE players SET legacy_points = 200 WHERE user_id = ?", (51007,))
    boosted = await life_engine.create_character(
        51007, "Boosted", legacy_stat="health", legacy_purchases=2
    )
    assert boosted.stats.health == min(100, baseline.stats.health + 10)
    for key in ("happiness", "smarts", "looks", "fitness", "karma", "stress", "addiction", "fame"):
        assert getattr(boosted.stats, key) == getattr(baseline.stats, key)
    assert boosted.cash == baseline.cash == 0
    assert boosted.bank == baseline.bank == 0
    player = await database.fetchone("SELECT legacy_points FROM players WHERE user_id = ?", (51007,))
    assert int(player["legacy_points"]) == 100
    purchase = await database.fetchone(
        "SELECT stat_name, purchase_count, points_spent FROM legacy_start_purchases WHERE char_id = ?",
        (boosted.char_id,),
    )
    assert dict(purchase) == {"stat_name": "health", "purchase_count": 2, "points_spent": 100}
    with pytest.raises(ValidationError):
        await life_engine.create_character(51008, "Over the Cap", legacy_stat="health", legacy_purchases=3)
    async with database.transaction() as tx:
        await life_engine.legacy_repository.ensure_player(tx, 51009, 1_800_000_000)
        await tx.execute("UPDATE players SET legacy_points = 50 WHERE user_id = ?", (51009,))
    with pytest.raises(InsufficientFunds):
        await life_engine.create_character(51009, "Too Costly", legacy_stat="smarts", legacy_purchases=2)
    assert await database.fetchone("SELECT 1 FROM characters WHERE user_id = 51009") is None


@pytest.mark.asyncio
async def test_retirement_has_no_points_heir_or_debt_transfer(database, life_engine):
    """Confirmed abandonment archives once but awards neither legacy points nor inheritance."""
    character = await life_engine.create_character(51010, "Retired Life")
    updated = replace(
        character,
        age=45,
        cash=dollars_to_cents(100_000),
        debt_total=dollars_to_cents(500_000),
        version=character.version + 1,
    )
    async with database.transaction() as tx:
        await life_engine._save_character(tx, updated, expected_version=character.version)
    prompt = await life_engine.death.begin_retirement(character.user_id, now=1_800_000_100)
    result = await life_engine.death.confirm_retirement(
        character.user_id, prompt.prompt_id, prompt.nonce, now=1_800_000_101
    )
    assert result.summary["death_cause"] == "Life abandoned"
    assert result.summary["abandoned"] is True
    assert result.summary["legacy_points"] == 0
    assert result.summary["estate_cents"] == 0
    assert result.summary["debts_paid_cents"] == 0
    assert result.summary["unpaid_debt_cents"] == dollars_to_cents(500_000)
    assert await database.fetchone("SELECT 1 FROM life_estates WHERE user_id = ?", (character.user_id,)) is None
    player = await database.fetchone("SELECT lives_lived, legacy_points FROM players WHERE user_id = ?", (character.user_id,))
    assert int(player["lives_lived"]) == 0
    assert int(player["legacy_points"]) == 0
    with pytest.raises(ValidationError):
        await life_engine.death.confirm_retirement(
            character.user_id, prompt.prompt_id, prompt.nonce, now=1_800_000_102
        )
    await life_engine.create_character(character.user_id, "Another Abandoned Life")
    second_prompt = await life_engine.death.begin_retirement(
        character.user_id, now=1_800_000_200
    )
    await life_engine.death.confirm_retirement(
        character.user_id, second_prompt.prompt_id, second_prompt.nonce,
        now=1_800_000_201,
    )
    player = await database.fetchone("SELECT lives_lived, legacy_points FROM players WHERE user_id = ?", (character.user_id,))
    assert int(player["lives_lived"]) == 0
    assert int(player["legacy_points"]) == 0
    archives = await database.fetchone(
        "SELECT COUNT(*) AS n FROM past_lives WHERE user_id = ?", (character.user_id,)
    )
    assert int(archives["n"]) == 2


@pytest.mark.asyncio
async def test_leaderboard_ties_pagination_cache_expiry_privacy_and_server_fallback(database, life_engine):
    """Rankings tie by account ID, page after ten, expire at 60 seconds, and use seen guild users."""
    user_ids = list(range(51100, 51112))
    for user_id in user_ids:
        await life_engine.create_character(user_id, f"Rank {user_id}")
        async with database.transaction() as tx:
            await life_engine.legacy_repository.ensure_player(tx, user_id, 1_800_000_000)
    await _set_character_age(life_engine, user_ids[-1], 10)

    clock = [100.0]
    leaderboard = LeaderboardService(
        database,
        life_engine.achievements,
        life_engine.locks,
        clock=lambda: clock[0],
        cache_seconds=60,
    )
    first = await leaderboard.get_leaderboard(
        user_ids[0], metric="age", scope="global", period="current"
    )
    assert len(first.entries) == 12
    assert first.entries[0]["user_id"] == user_ids[-1]
    assert [row["user_id"] for row in first.entries[1:]] == user_ids[:-1]
    first_embed = leaderboard_embed(first, 0)
    second_embed = leaderboard_embed(first, 1)
    assert len((first_embed.description or "").splitlines()) == 10
    assert len((second_embed.description or "").splitlines()) == 2
    pager = EmbedPager(user_ids[0], [first_embed, second_embed])
    assert len(pager.embeds) == 2

    await _set_character_age(life_engine, user_ids[0], 99)
    clock[0] = 159.99
    cached = await leaderboard.get_leaderboard(
        user_ids[0], metric="age", scope="global", period="current"
    )
    assert cached.entries == first.entries
    clock[0] = 160.0
    refreshed = await leaderboard.get_leaderboard(
        user_ids[0], metric="age", scope="global", period="current"
    )
    assert refreshed.entries[0]["user_id"] == user_ids[0]

    await leaderboard.set_opt_out(user_ids[1], True, now=1_800_000_200)
    private_filtered = await leaderboard.get_leaderboard(
        user_ids[0], metric="age", scope="global", period="current"
    )
    assert user_ids[1] not in {row["user_id"] for row in private_filtered.entries}
    async with database.transaction() as tx:
        await LegacyRepository(database).record_guild_seen(tx, 9001, user_ids[2], 1_800_000_201)
    server = await leaderboard.get_leaderboard(
        user_ids[0], metric="age", scope="server", period="current", guild_id=9001
    )
    assert {row["user_id"] for row in server.entries} == {user_ids[0], user_ids[2]}


def test_epitaph_selection_is_deterministic_and_catalog_has_twenty_templates():
    """Epitaph choice is based on stable life facts and contains ample PG-13 variants."""
    from core.death import _EPITAPHS

    assert sum(len(templates) for templates in _EPITAPHS.values()) >= 20
    arguments = dict(
        char_id=75,
        age=24,
        cause="natural causes",
        education_level="none",
        children=0,
        marriage_years=0,
        career_count=0,
        conviction_count=0,
        sealed_convictions=0,
        net_worth_cents=0,
        hardship_recovered=False,
    )
    assert select_epitaph(**arguments) == select_epitaph(**arguments)
    assert select_epitaph(**{**arguments, "cause": "Life abandoned"}) in _EPITAPHS["abandoned"]
```

## `tests/test_stage10_cog_loading.py`

```python
"""Discord.py registration smoke tests for the Stage 10 command surface."""
from __future__ import annotations

import discord
import pytest
from discord.ext import commands

from core.achievements import AchievementService
from core.casino import CasinoService
from core.crime import CrimeService
from core.family import FamilyService
from core.investing import InvestingService
from core.locks import UserLockRegistry
from core.rng import RNG
from core.shop import ShopService


@pytest.mark.asyncio
async def test_stage10_extensions_register_all_legacy_commands(database):
    """Load all Stage 1–10 cogs with no privileged member intent and inspect commands."""
    bot = commands.Bot(command_prefix="!", intents=discord.Intents.none())
    bot.db = database
    bot.rng = RNG(seed=1010)
    bot.locks = UserLockRegistry()
    bot.achievement_service = AchievementService(database, bot.locks, clock=lambda: 1_800_000_000)
    assert len(bot.achievement_service.definitions) >= 60
    achievement_names = {row["name"] for row in bot.achievement_service.definitions}
    assert {
        "First Steps", "Graduate", "Doctorate", "Millionaire", "Billionaire",
        "Rags to Riches", "Centenarian", "Married 50 Years", "Big Family", "Jailbird",
        "Kingpin", "Great Escape", "High Roller", "Jackpot", "Bankrupt", "Serial Divorcé",
        "Straight-A Student", "CEO", "Famous", "Lifelong Learner", "Dynasty", "Died Young",
        "Clean Record Centenarian",
    }.issubset(achievement_names)
    assert {
        "education", "career", "family", "wealth", "hardship", "recovery",
        "crime", "longevity", "completion",
    }.issubset({row["category"] for row in bot.achievement_service.definitions})
    bot.family_service = FamilyService(database, bot.rng, bot.locks)
    bot.crime_service = CrimeService(
        database, bot.rng, bot.locks, family_service=bot.family_service
    )
    bot.shop_service = ShopService(database, bot.rng, bot.locks)
    bot.casino_service = CasinoService(database, bot.rng, bot.locks, clock=lambda: 1_800_000_000)
    bot.investing_service = InvestingService(database, bot.rng, bot.locks, clock=lambda: 1_800_000_000)

    async def ready() -> None:
        """Satisfy background-loop setup without connecting to Discord."""
        return None

    bot.wait_until_ready = ready
    await bot.investing_service.initialize_market()
    extensions = (
        "cogs.life",
        "cogs.education",
        "cogs.career",
        "cogs.relationships",
        "cogs.crime",
        "cogs.prison",
        "cogs.shop",
        "cogs.casino",
        "cogs.invest",
        "cogs.discobot",
        "cogs.legacy",
    )
    try:
        for extension in extensions:
            await bot.load_extension(extension)
        commands_by_name = {command.name: command for command in bot.tree.get_commands()}
        assert {
            "life", "start", "leaderboard", "achievements", "lives", "graveyard",
            "inheritance", "retire_life", "leaderboard_privacy", "guild_death_summaries",
            "family", "relationship", "date", "friends", "crime", "shop", "casino", "invest",
        }.issubset(commands_by_name)
        assert {command.name for command in commands_by_name["life"].commands} == {
            "start", "status", "age", "choice"
        }
        assert {command.name for command in commands_by_name["lives"].commands} == {"list", "view"}
        assert {command.name for command in commands_by_name["casino"].commands} == {
            "slots", "blackjack", "roulette", "coinflip", "compulsion"
        }
        assert {command.name for command in commands_by_name["invest"].commands} == {
            "market", "buy", "sell", "portfolio", "history", "bonds"
        }
        assert commands_by_name["leaderboard"].description
        assert commands_by_name["achievements"].description
    finally:
        await bot.close()
```
