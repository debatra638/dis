"""Reproducible, headless Stage 12 mortality, casino RTP, and crime-EV measurements.

Run from the project root with ``python -m tools.measure_balance``. These runs
consume only deterministic game rules and do not connect to Discord or write a
player database. The 500-life full-engine distribution is reported by
``tests/test_full_lives.py`` instead.
"""
from __future__ import annotations

import argparse
import json
import math
from collections import Counter
from functools import lru_cache
from itertools import product
from statistics import mean, median, pstdev
from typing import Any

from core.casino import CasinoService, SLOT_SYMBOLS, SLOT_WEIGHTS
from core.config import GameBalance
from core.crime import (
    LAWYER_CONVICTION_CHANCES,
    CrimeDefinition,
    calculate_crime_catch_chance,
    calculate_crime_success_chance,
    clamp_chance,
)
from core.data_loader import DataLoader
from core.life_engine import roll_birth_attributes, simulate_year
from core.models import Character
from core.money import dollars_to_cents
from core.rng import RNG

MORTALITY_SEED = 20261002
CASINO_SEED = 20260930
CRIME_SEED = 20261008
BET_CENTS = 10_000
DEFAULT_MORTALITY_LIVES = 2_000
DEFAULT_CASINO_TRIALS = 1_000_000
DEFAULT_BLACKJACK_TRIALS = 250_000


def _percentile(sorted_values: list[int], fraction: float) -> int:
    """Return the observation at the rounded empirical quantile index used here."""
    return sorted_values[round((len(sorted_values) - 1) * fraction)]


def mortality_distribution(life_count: int, seed: int) -> dict[str, Any]:
    """Run the no-condition baseline using the pure aging helper for comparison."""
    if life_count <= 0:
        raise ValueError("life_count must be positive")
    rng = RNG(seed)
    ages: list[int] = []
    causes: Counter[str] = Counter()
    for index in range(life_count):
        stats, hidden, wealth_class = roll_birth_attributes(rng)
        character = Character(
            user_id=940_000 + index,
            name=f"Mortality {index:04d}",
            stats=stats,
            hidden=hidden,
            wealth_class=wealth_class,
        )
        while character.is_alive:
            character = simulate_year(character, rng, now=1_900_000_000).character
        ages.append(int(character.death_age or character.age))
        causes[str(character.death_cause)] += 1
    ordered = sorted(ages)
    return {
        "lives": life_count,
        "seed": seed,
        "mean_age": round(mean(ages), 2),
        "median_age": median(ages),
        "population_sd_age": round(pstdev(ages), 2),
        "p10_age": _percentile(ordered, 0.10),
        "p25_age": _percentile(ordered, 0.25),
        "p75_age": _percentile(ordered, 0.75),
        "p90_age": _percentile(ordered, 0.90),
        "min_age": min(ages),
        "max_age": max(ages),
        "under_18_deaths": sum(age < 18 for age in ages),
        "terminal_causes": dict(sorted(causes.items())),
        "scope": "No-condition baseline from the standalone simulate_year helper; integrated disease incidence, care, and competing mortality are measured separately in tests/test_full_lives.py.",
    }


def exact_blackjack_hit_below_17_rtp() -> float:
    """Return exact six-deck gross RTP for hit-below-17, stand-at-17, no-double play.

    The expectation enumerates all possible four-card initial deals and uses cached
    finite-shoe recurrences for the player's fixed policy and the dealer's stand-on-17
    rule. Payouts are measured in wager units, with a 3:2 natural-blackjack profit.
    """
    initial_shoe = (24,) * 9 + (96,)
    card_values = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

    def add_card(total: int, soft: bool, card_index: int) -> tuple[int, bool]:
        """Add one rank value while tracking a usable ace as eleven when possible."""
        value = card_values[card_index]
        if value == 1:
            if total + 11 <= 21:
                total += 11
                soft = True
            else:
                total += 1
        else:
            total += value
        if total > 21 and soft:
            total -= 10
            soft = False
        return total, soft

    @lru_cache(maxsize=None)
    def dealer_return(
        remaining: tuple[int, ...], player_total: int, dealer_total: int, dealer_soft: bool
    ) -> float:
        """Return exact expected gross payout after the player stands."""
        if dealer_total > 21:
            return 2.0
        if dealer_total >= 17:
            if player_total > dealer_total:
                return 2.0
            return 1.0 if player_total == dealer_total else 0.0
        cards_remaining = sum(remaining)
        expected = 0.0
        for card_index, count in enumerate(remaining):
            if count:
                next_remaining = list(remaining)
                next_remaining[card_index] -= 1
                next_total, next_soft = add_card(dealer_total, dealer_soft, card_index)
                expected += (count / cards_remaining) * dealer_return(
                    tuple(next_remaining), player_total, next_total, next_soft
                )
        return expected

    @lru_cache(maxsize=None)
    def player_return(
        remaining: tuple[int, ...],
        player_total: int,
        player_soft: bool,
        dealer_total: int,
        dealer_soft: bool,
    ) -> float:
        """Return exact expected gross payout under the fixed player policy."""
        if player_total > 21:
            return 0.0
        if player_total >= 17:
            return dealer_return(remaining, player_total, dealer_total, dealer_soft)
        cards_remaining = sum(remaining)
        expected = 0.0
        for card_index, count in enumerate(remaining):
            if count:
                next_remaining = list(remaining)
                next_remaining[card_index] -= 1
                next_total, next_soft = add_card(player_total, player_soft, card_index)
                expected += (count / cards_remaining) * player_return(
                    tuple(next_remaining), next_total, next_soft, dealer_total, dealer_soft
                )
        return expected

    @lru_cache(maxsize=None)
    def initial_deal_return(
        position: int,
        remaining: tuple[int, ...],
        player_total: int,
        player_soft: bool,
        dealer_total: int,
        dealer_soft: bool,
        player_natural: bool,
        dealer_natural: bool,
    ) -> float:
        """Enumerate a random player/dealer/player/dealer initial deal without replacement."""
        if position == 4:
            if player_natural or dealer_natural:
                if player_natural and dealer_natural:
                    return 1.0
                return 2.5 if player_natural else 0.0
            return player_return(
                remaining, player_total, player_soft, dealer_total, dealer_soft
            )

        cards_remaining = sum(remaining)
        expected = 0.0
        for card_index, count in enumerate(remaining):
            if not count:
                continue
            next_remaining = list(remaining)
            next_remaining[card_index] -= 1
            if position in {0, 2}:
                next_player_total, next_player_soft = add_card(
                    player_total, player_soft, card_index
                )
                next_player_natural = position == 2 and next_player_total == 21
                next_dealer_total = dealer_total
                next_dealer_soft = dealer_soft
                next_dealer_natural = dealer_natural
            else:
                next_player_total = player_total
                next_player_soft = player_soft
                next_player_natural = player_natural
                next_dealer_total, next_dealer_soft = add_card(
                    dealer_total, dealer_soft, card_index
                )
                next_dealer_natural = position == 3 and next_dealer_total == 21
            expected += (count / cards_remaining) * initial_deal_return(
                position + 1,
                tuple(next_remaining),
                next_player_total,
                next_player_soft,
                next_dealer_total,
                next_dealer_soft,
                next_player_natural,
                next_dealer_natural,
            )
        return expected

    return initial_deal_return(0, initial_shoe, 0, False, 0, False, False, False)


def casino_monte_carlo(trials: int, blackjack_trials: int, seed: int) -> dict[str, Any]:
    """Measure gross casino return using production casino rules and fixed wagers."""
    if trials <= 0 or blackjack_trials <= 0:
        raise ValueError("Monte Carlo trial counts must be positive")
    output: dict[str, Any] = {"bet_cents_per_hand": BET_CENTS, "seed": seed, "games": {}}

    # This is the production weighted-reel spin and paytable, run without service writes.
    slot_service = CasinoService(None, RNG(seed), None)
    slot_payout = 0
    for _ in range(trials):
        _, gross = slot_service.spin_slots(BET_CENTS)
        slot_payout += gross
    slot_weights = dict(zip(SLOT_SYMBOLS, SLOT_WEIGHTS))
    slot_weighted_payout = sum(
        CasinoService.slot_payout(symbols, BET_CENTS)
        * math.prod(slot_weights[symbol] for symbol in symbols)
        for symbols in product(slot_weights, repeat=3)
    )
    exact_slot_rtp = slot_weighted_payout / (100**3 * BET_CENTS)
    output["games"]["slots"] = {
        **_rtp_record(trials, BET_CENTS, slot_payout),
        "exact_gross_rtp": round(exact_slot_rtp, 6),
    }

    coin_rng = RNG(seed + 1)
    coin_wins = 0
    coin_payout = 0
    for _ in range(trials):
        if coin_rng.choice(("heads", "tails")) == "heads":
            coin_wins += 1
            coin_payout += BET_CENTS * 194 // 100
    output["games"]["coinflip_heads"] = {
        **_rtp_record(trials, BET_CENTS, coin_payout),
        "exact_gross_rtp": 0.97,
        "wins": coin_wins,
        "rule": "Fair heads/tails; a win returns 1.94x gross.",
    }

    roulette_specs = (
        ("roulette_red", "red", None, seed + 2),
        ("roulette_dozen_1", "dozen", 1, seed + 3),
        ("roulette_straight_0", "straight", 0, seed + 4),
    )
    for name, kind, number, roulette_seed in roulette_specs:
        roulette_rng = RNG(roulette_seed)
        total_payout = 0
        wins = 0
        for _ in range(trials):
            landed = roulette_rng.randint(0, 36)
            payout = CasinoService.roulette_payout(BET_CENTS, kind, number, landed)
            total_payout += payout
            wins += payout > 0
        exact_payout = sum(
            CasinoService.roulette_payout(BET_CENTS, kind, number, landed)
            for landed in range(37)
        )
        output["games"][name] = {
            **_rtp_record(trials, BET_CENTS, total_payout),
            "exact_gross_rtp": round(exact_payout / (37 * BET_CENTS), 6),
            "wins": wins,
            "rule": "European single-zero wheel; production payout function.",
        }

    blackjack = CasinoService(None, RNG(seed + 5), None)
    blackjack_payout = 0
    blackjack_naturals = 0
    blackjack_pushes = 0
    for _ in range(blackjack_trials):
        shoe = blackjack._shuffled_shoe()
        player = [shoe.pop()]
        dealer = [shoe.pop()]
        player.append(shoe.pop())
        dealer.append(shoe.pop())
        player_natural = blackjack._is_natural(player)
        dealer_natural = blackjack._is_natural(dealer)
        if player_natural or dealer_natural:
            if player_natural and dealer_natural:
                gross = BET_CENTS
                blackjack_pushes += 1
            elif player_natural:
                gross = BET_CENTS + BET_CENTS * 3 // 2
                blackjack_naturals += 1
            else:
                gross = 0
        else:
            # Fixed, transparent player policy: hit below 17, then stand; never double.
            while blackjack._hand_total(player)[0] < 17:
                player.append(shoe.pop())
            player_total = blackjack._hand_total(player)[0]
            if player_total > 21:
                gross = 0
            else:
                while blackjack._dealer_hits(dealer):
                    dealer.append(shoe.pop())
                dealer_total = blackjack._hand_total(dealer)[0]
                if dealer_total > 21 or player_total > dealer_total:
                    gross = 2 * BET_CENTS
                elif player_total == dealer_total:
                    gross = BET_CENTS
                    blackjack_pushes += 1
                else:
                    gross = 0
        blackjack_payout += gross
    output["games"]["blackjack_hit_below_17_no_double"] = {
        **_rtp_record(blackjack_trials, BET_CENTS, blackjack_payout),
        "exact_gross_rtp": round(exact_blackjack_hit_below_17_rtp(), 6),
        "naturals_won": blackjack_naturals,
        "pushes": blackjack_pushes,
        "rule": "Exact finite six-deck expectation and Monte Carlo use hit below 17, stand at 17+, no doubles or splits; dealer stands on 17 and naturals pay 3:2 profit.",
    }

    # Lottery prizes are discrete in the production service; use its exact prize EV,
    # including the configured jackpot, rather than sampling a one-in-ten-million event.
    expected_prize_cents = (
        1 * GameBalance.CASINO_LOTTERY_JACKPOT_CENTS
        + 100 * 1_000_000
        + 10_000 * 10_000
        + 100_000 * 1_000
        + 1_000_000 * 250
    ) // 10_000_000
    output["lottery_ticket_exact"] = {
        "expected_prize_cents_at_price_index_1": expected_prize_cents,
        "ticket_cost_cents": 1_000,
        "gross_rtp": expected_prize_cents / 1_000,
        "net_ev_cents": expected_prize_cents - 1_000,
        "scope": "Exact probability-weighted prize; ticket use is not included in the casino Monte Carlo samples.",
    }
    return output


def _rtp_record(trials: int, bet_cents: int, payout_cents: int) -> dict[str, Any]:
    """Describe gross returns as aggregate credited payout divided by stake."""
    total_stake = trials * bet_cents
    return {
        "hands": trials,
        "stake_cents": total_stake,
        "gross_payout_cents": payout_cents,
        "observed_gross_rtp": round(payout_cents / total_stake, 6),
    }


def crime_expected_values(trials: int, seed: int) -> dict[str, Any]:
    """Measure per-attempt crime value after custody, wages, and a record-linked job-search loss."""
    if trials <= 0:
        raise ValueError("trials must be positive")
    definitions = DataLoader().load_crimes()["crimes"]
    country_doc = DataLoader().load_crimes()
    sentencing_scale = float(country_doc["crime_severity_mod"].get("usa", country_doc["crime_severity_mod"]["default"]))
    rng = RNG(seed)
    hiring_penalty = GameBalance.CRIME_RECORD_HIRING_PENALTY_PERCENT / 100.0
    record_cost_per_conviction = round(
        GameBalance.CRIME_RECORD_EV_BASE_ANNUAL_WAGE_CENTS
        * GameBalance.CRIME_RECORD_EV_JOB_SEARCH_CHANCE
        * hiring_penalty
    )
    result: dict[str, Any] = {
        "trials_per_crime": trials,
        "seed": seed,
        "baseline": "Age 21, USA sentencing scale, smarts 50, fitness 50, luck 0, no prior record; caught cases choose the public defender.",
        "scope": (
            "EV per attempt subtracts expected fines, prison-time value, wages not earned while incarcerated, "
            "and one record-linked job-search opportunity (20 percentage-point hiring penalty × 10% chance "
            "of a search × $25,000 annual wage = $500 per conviction). The live hiring system also applies "
            "ongoing record and release penalties; this one-attempt EV does not project a full lifetime."
        ),
        "prison_time_cost_cents_per_year": GameBalance.CRIME_PRISON_TIME_COST_PER_YEAR_CENTS,
        "lost_wages_cents_per_prison_year": GameBalance.CRIME_LOST_WAGES_PER_PRISON_YEAR_CENTS,
        "record_effect_cents_per_conviction": record_cost_per_conviction,
        "crimes": {},
    }
    for raw in definitions:
        crime = CrimeDefinition.from_dict(raw)
        if not crime.commit_enabled:
            continue
        success_chance = calculate_crime_success_chance(
            float(crime.base_success or 0.0),
            smarts=50,
            fitness=50,
            luck=0,
            success_stat=crime.success_stat,
        )
        catch_chance = calculate_crime_catch_chance(
            float(crime.base_catch or 0.0), notoriety=0, criminal_record=0
        )
        failed_catch_chance = clamp_chance(
            catch_chance * GameBalance.CRIME_FAILED_ATTEMPT_CATCH_MULTIPLIER
        )
        loot_min = dollars_to_cents(crime.loot_min_dollars)
        loot_max = dollars_to_cents(crime.loot_max_dollars)
        successes = arrests = convictions = gross_loot = fines = custody_years = 0
        for _ in range(trials):
            success = rng.random() * 100.0 < success_chance
            adjusted_catch = catch_chance if success else failed_catch_chance
            caught = rng.random() * 100.0 < adjusted_catch
            loot = rng.randint(loot_min, loot_max) if success else 0
            if success:
                successes += 1
            gross_loot += loot
            if not caught:
                continue
            arrests += 1
            if rng.random() * 100.0 >= LAWYER_CONVICTION_CHANCES["public"]:
                continue
            convictions += 1
            if crime.sentence_max is None:
                maximum_sentence = max(crime.sentence_min, 120 - 21)
                base_sentence = rng.randint(crime.sentence_min, maximum_sentence)
                life_sentence = base_sentence >= max(1, 120 - 21)
            elif crime.sentence_min == crime.sentence_max:
                base_sentence = crime.sentence_min
                life_sentence = False
            else:
                base_sentence = rng.randint(crime.sentence_min, int(crime.sentence_max))
                life_sentence = False
            sentence_years = 0 if base_sentence == 0 else max(1, math.ceil(base_sentence * sentencing_scale))
            sentence_years = min(sentence_years, max(0, 120 - 21))
            if life_sentence:
                sentence_years = max(1, 120 - 21)
            custody_years += sentence_years
            if success and loot > 0:
                fine = (
                    loot * GameBalance.CRIME_FINE_ON_CAUGHT_LOOT_PERCENT + 99
                ) // 100
                fines += fine

        prison_time_cost = custody_years * GameBalance.CRIME_PRISON_TIME_COST_PER_YEAR_CENTS
        lost_wages = custody_years * GameBalance.CRIME_LOST_WAGES_PER_PRISON_YEAR_CENTS
        record_cost = convictions * record_cost_per_conviction
        total_cost = prison_time_cost + lost_wages + record_cost
        direct_net = gross_loot - fines
        net_after_all_costs = direct_net - total_cost
        crime_class = "violent" if crime.violence else ("petty_benchmark" if crime.id == "shoplift" else "nonviolent")
        result["crimes"][crime.id] = {
            "class": crime_class,
            "success_chance_pct": success_chance,
            "caught_chance_if_success_pct": catch_chance,
            "caught_chance_if_failure_pct": failed_catch_chance,
            "observed_success_pct": round(successes / trials * 100, 3),
            "observed_arrest_pct": round(arrests / trials * 100, 3),
            "observed_conviction_pct": round(convictions / trials * 100, 3),
            "observed_custody_years_per_attempt": round(custody_years / trials, 4),
            "gross_loot_ev_cents_per_attempt": round(gross_loot / trials),
            "fine_ev_cents_per_attempt": round(fines / trials),
            "prison_time_cost_ev_cents_per_attempt": round(prison_time_cost / trials),
            "lost_wages_ev_cents_per_attempt": round(lost_wages / trials),
            "record_effect_ev_cents_per_attempt": round(record_cost / trials),
            "direct_net_ev_cents_per_attempt": round(direct_net / trials),
            "net_ev_after_all_costs_cents_per_attempt": round(net_after_all_costs / trials),
        }

    violent_records = [
        record for record in result["crimes"].values() if record["class"] == "violent"
    ]
    result["violent_crime_acceptance"] = {
        "status": "PASS" if violent_records and all(
            int(record["net_ev_after_all_costs_cents_per_attempt"]) < 0
            for record in violent_records
        ) else "FAIL",
        "per_crime_net_ev_cents": {
            crime_id: int(record["net_ev_after_all_costs_cents_per_attempt"])
            for crime_id, record in result["crimes"].items()
            if record["class"] == "violent"
        },
    }
    petty = result["crimes"].get("shoplift")
    petty_ev = int(petty["net_ev_after_all_costs_cents_per_attempt"]) if petty else None
    result["petty_crime_acceptance"] = {
        "benchmark": "shoplift",
        "measured_net_ev_cents_per_attempt": petty_ev,
        "target": "slightly positive (0 to $100 per attempt)",
        "status": "PASS" if petty_ev is not None and 0 < petty_ev < 10_000 else "FAIL",
    }
    return result

def main() -> None:
    """Run the deterministic measurements and print one JSON record."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mortality-lives", type=int, default=DEFAULT_MORTALITY_LIVES)
    parser.add_argument("--casino-trials", type=int, default=DEFAULT_CASINO_TRIALS)
    parser.add_argument("--blackjack-trials", type=int, default=DEFAULT_BLACKJACK_TRIALS)
    parser.add_argument("--crime-trials", type=int, default=1_000_000)
    args = parser.parse_args()
    report = {
        "mortality_only": mortality_distribution(args.mortality_lives, MORTALITY_SEED),
        "casino_rtp": casino_monte_carlo(args.casino_trials, args.blackjack_trials, CASINO_SEED),
        "crime_expected_values": crime_expected_values(args.crime_trials, CRIME_SEED),
    }
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
