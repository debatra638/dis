"""Build a clean, current LIFELINE source archive and its file index."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT / "LIFELINE_SOURCE_BUNDLE.zip"
MANIFEST = ROOT / "LIFELINE_SOURCE_BUNDLE.md"
BUNDLE_README = "BUNDLE_README.txt"

ROOT_FILES = (
    ".env.example",
    "README.md",
    "DESIGN_NOTES.md",
    "VERIFICATION_REPORT.md",
    "BALANCE_TUNING_LOG.md",
    "LIFELINE_SOURCE_BUNDLE.md",
    "requirements.txt",
    "bot.py",
    "balance_acceptance_metrics.json",
    "balance_baseline.json",
    "balance_mechanics.json",
)
SOURCE_DIRS = ("cogs", "core", "data", "tests", "tools")
SOURCE_SUFFIXES = {".py", ".sql", ".json"}
EXCLUDED_PARTS = {
    ".git", ".venv", ".pytest_cache", ".ruff_cache", "__pycache__", "node_modules",
    "build", "dist", "coverage", "target", "out",
}


def _project_files() -> list[Path]:
    """Return the sorted source/document/measurement files for the distributable archive."""
    selected: set[Path] = set()
    for name in ROOT_FILES:
        path = ROOT / name
        if path.is_file() and name != "LIFELINE_SOURCE_BUNDLE.md":
            selected.add(path)
    for directory in SOURCE_DIRS:
        base = ROOT / directory
        if not base.is_dir():
            continue
        for path in base.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in SOURCE_SUFFIXES:
                continue
            relative_parts = path.relative_to(ROOT).parts
            if any(part in EXCLUDED_PARTS for part in relative_parts):
                continue
            selected.add(path)
    return sorted(selected, key=lambda path: path.relative_to(ROOT).as_posix())


def _manifest_text(paths: list[Path], created: str) -> str:
    """Render a human-readable index of the archive's project files."""
    names = [path.relative_to(ROOT).as_posix() for path in paths]
    names.append("LIFELINE_SOURCE_BUNDLE.md")
    names = sorted(set(names))
    lines = [
        "# LIFELINE source bundle",
        "",
        f"Generated: {created}",
        "",
        "`LIFELINE_SOURCE_BUNDLE.zip` is a clean, current source archive. It includes the bot source,",
        "migrations, data catalogs, tests, tools, README, design/verification notes, and current",
        "balance-measurement JSON. Historical full-source stage dumps and exploratory cohort logs",
        "remain in the workspace but are intentionally omitted from the distributable ZIP.",
        "",
        "Excluded: credentials, `.env`, databases, caches, bytecode, build outputs, ZIP files, and",
        "cohort log files. The safe `.env.example` template is included.",
        "",
        f"Indexed project files: **{len(names)}** (plus one short `{BUNDLE_README}` inside the ZIP).",
        "",
        "## Included file index",
        "",
        *[f"- `{name}`" for name in names],
        "",
    ]
    return "\n".join(lines)


def build_source_bundle() -> tuple[int, int]:
    """Write the index and ZIP, excluding generated data and machine-local artifacts."""
    created = datetime.now().astimezone().date().isoformat()
    project_files = _project_files()
    MANIFEST.write_text(_manifest_text(project_files, created), encoding="utf-8")
    project_files.append(MANIFEST)
    project_files.sort(key=lambda path: path.relative_to(ROOT).as_posix())

    readme = (
        "LIFELINE current source bundle\n"
        f"Generated {created}. See LIFELINE_SOURCE_BUNDLE.md for the complete index.\n"
        "Secrets, databases, generated logs, caches, and historical source dumps are excluded.\n"
    )
    with ZipFile(ARCHIVE, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
        archive.writestr(BUNDLE_README, readme)
        for path in project_files:
            archive.write(path, arcname=path.relative_to(ROOT).as_posix())
    return len(project_files) + 1, ARCHIVE.stat().st_size


if __name__ == "__main__":
    count, size = build_source_bundle()
    print(f"Built {ARCHIVE.name}: {count} files, {size:,} bytes")
