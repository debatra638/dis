# LIFELINE balance tuning and acceptance log

Last updated: 2026-10-05 (Asia/Kolkata)

## Current configuration

| Setting | Current value |
|---|---:|
| Career base salary multiplier | `0.83` |
| Degree salary multiplier | `0.71` |
| Career promotion growth multiplier | `0.05` |
| Inheritance base multiplier | `0.09` |
| Base lifespan mean | `78` years |
| Bankruptcy minimum dischargeable debt | `181,200,000` cents ($1,812,000.00) |
| Bankruptcy repayment-capacity horizon | `10` years |
| Base annual living cost | `1,200,000` cents |
| Second income-tax bracket | `35%` |
| Prison-violence fatality chance | `0.09` |

The current threshold remains the user's requested `181,200,000` cents ($1.812m). The $1.20m source diagnostic on seed `20261001` found 15 eligibility checks across 12 normal-profile lives; every candidate balance was a standalone `living_expense` collection (`121,534,714`–`139,595,697` cents), with no dischargeable loan balance, linked mirror, assets, annual surplus, or ten-year repayment capacity. Earlier cohort runs automatically called `file_bankruptcy` whenever a life passed eligibility; this is not a natural player filing rate and conflicts with the no-forced-filings constraint. The current full-life harness has been changed to audit eligibility only and never submit a filing. As a result, the 3–10% actual-filing target cannot be established from an actionless cohort; the current no-forced seed results and explicit PASS/FAIL table are recorded in the final audit section below. The $1.2m request remains unmet: it would admit the diagnosed $1.215m–$1.396m living-expense arrears under the existing policy floor. The high $1.812m minimum keeps bankruptcy rare for ordinary accounts while preserving the ten-year after-tax-surplus test, two-year first-loan age, asset multiple, secured-debt protections, and student-debt exclusion.

## Historical tuning iterations (eligibility-triggered filing policy)

These earlier runs used unmodified life assets and debt, but the harness auto-filed when an account was eligible. They are retained as historical route-policy/eligibility evidence only; they are not accepted as natural filing incidence and do not supersede the no-forced-filing results in the final audit below. Cohort logs named in the last column are retained in the workspace.

| Iteration | Before → after | Before result → after result | Decision / evidence |
|---|---|---|---|
| Bankruptcy threshold exploration | $1.78m → $1.80m; seed `20261003`, 100 lives | Natural filing stayed `7/60 = 11.67%` (FAIL) at both settings; other eight targets passed. | Threshold alone did not solve the bankruptcy target. Logs: `balance_cohort_salary083_degree068_bankruptcy178m_seed20261003_100.log`, `balance_cohort_salary083_degree068_bankruptcy180m_seed20261003_100.log`. |
| Temporary $1.85m / five-year experiment | Minimum $1.80m → $1.85m; repayment horizon temporarily changed 10 → 5 years | Seed `20261003`: bankruptcy `10.00%`; other cohort targets passed at degree multiplier `0.68`. | Not accepted because five years violated the specified affordability policy. Boundary tests were moved to $184,999,999 and $185,000,000; exact-threshold five-year loan payment is 51,320,850 cents. The ten-year horizon and report wording were subsequently restored. |
| Living-cost/tax experiment | Living cost $12,000 → $10,000 per year and second bracket 35% → 40% (temporary) | Seed `20261003`: bankruptcy `0%` (FAIL), heavy-crime median `70` (FAIL); normal lifespan `80`, heavy-addiction lifespan `53.5`, millionaire rate `20%`, college median `88,904,642.5` cents, no-high-school median `0`, promotion `3` years. | Reverted both constants; the run missed two required targets. Log: `balance_cohort_living100_tax40_salary083_degree068_bankruptcy180m_seed20261003_100.log`. |
| Restore policy horizon | Repayment horizon 5 → 10 years | Restored the required ten-year affordability calculation and all policy/report wording. | This is the accepted policy. Current report identifies ten years and excludes non-dischargeable student debt. |
| Degree salary trial | `0.68` → `0.69`, with salary base `0.83`, inheritance `0.10`, minimum $1.85m and ten-year horizon | Seed `20261001`: college median `-25,909,579` cents (FAIL), bankruptcy `10%`, millionaires `20%`. Seed `20261003`: college median `38,343,240.5` cents (PASS), bankruptcy `5%`, millionaires `20%`. | Rejected because the fixed seed missed the college-wealth target. Logs: `balance_cohort_salary083_degree069_bankruptcy185m_seed20261001_100.log` and `...seed20261003_100.log`. |
| Degree salary trial | `0.69` → `0.70` | Seed `20261001`: college median `70,804,384` cents; bankruptcy `10%`; millionaire rate `20%` (all targets passed). Seed `20261003`: college median `34,132,559` cents; bankruptcy `3.33%`; millionaire rate `21.67%` (FAIL). | Improved graduate wealth, but the alternate-seed millionaire rate exceeded its ceiling. Logs: `balance_cohort_salary083_degree070_bankruptcy185m_seed20261001_100.log` and `...seed20261003_100.log`. |
| Salary-base experiment | `0.83` → `0.82`, degree `0.70`, inheritance `0.10` | Seed `20261001`: college median `17,426,542.5` cents (FAIL), bankruptcy `6.67%`, millionaires `20%`. Seed `20261003`: college median `9,747,733.5` cents (FAIL), bankruptcy `10%`, millionaires `20%`. | Reverted to `0.83`; both seeds missed college wealth. Logs: `balance_cohort_salary082_degree070_bankruptcy185m_seed20261001_100.log` and `...seed20261003_100.log`. |
| Inheritance trial | `0.10` → `0.09`, degree `0.70`, salary base `0.83` | Seed `20261001`: college median `39,161,379` cents, bankruptcy `8.33%`, millionaires `20%` (PASS). Seed `20261003`: college median `21,125,996` cents (FAIL), bankruptcy `6.67%`, millionaires `18.33%`. | Kept inheritance at `0.09`; increased the degree multiplier one further step to resolve the alternate-seed college miss. Logs: `balance_cohort_salary083_degree070_inheritance009_bankruptcy185m_seed20261001_100.log` and `...seed20261003_100.log`. |
| Final degree salary adjustment | `0.70` → `0.71`, inheritance `0.09`, salary base `0.83` | Both 100-life seeds passed every supplied cohort target; see final acceptance table below. | Accepted. Logs: `balance_cohort_salary083_degree071_inheritance009_bankruptcy185m_seed20261001_100.log` and `...seed20261003_100.log`. |
| Minimum-threshold refinement | $1.85m → $1.84m → $1.835m; all other accepted constants unchanged | Seed `20261001`: bankruptcy `10.00%` → `10.00%` → `10.00%`; seed `20261003`: `6.67%` → `6.67%`; 500-life: `9.33%` → `9.33%`. All other targets remained PASS. | $1.835m was the lowest fully validated threshold before the current trial; boundary was $183,499,999 / $183,500,000 cents. Logs: `balance_cohort_salary083_degree071_inheritance009_bankruptcy184m_seed20261001_100.log`, `...bankruptcy1835m_seed20261001_100.log`, `...bankruptcy1835m_seed20261003_100.log`, and `...bankruptcy1835m_seed20261001_500.log`. |
| Lower-threshold refinement | $1.835m → $1.830m; all other balance constants unchanged | 100-life seed `20261001`: bankruptcy `10.00%`; alternate seed `20261003`: `6.67%`; 500-life: `9.33%`. All other targets PASS across all three cohorts. | Passed all three cohorts at this step; the subsequent refinement is $1.820m. Boundary: $182,999,999 / $183,000,000 cents. Logs: `balance_cohort_salary083_degree071_inheritance009_bankruptcy1830m_seed20261001_100.log`, `...bankruptcy1830m_seed20261003_100.log`, and `...bankruptcy1830m_seed20261001_500.log`. |
| Lower-threshold refinement | $1.830m → $1.820m; all other balance constants unchanged | 100-life seed `20261001`: bankruptcy `10.00%`; alternate seed `20261003`: `6.67%`; 500-life: `9.33%`. All other targets PASS across all three cohorts. | Passed all three cohorts at this step; the later fine step is $1.812m. Boundary was $181,999,999 / $182,000,000 cents. Logs: `balance_cohort_salary083_degree071_inheritance009_bankruptcy182m_seed20261001_100.log`, `...bankruptcy182m_seed20261003_100.log`, and `...bankruptcy182m_seed20261001_500.log`. |
| Threshold-floor trial | $1.820m → $1.810m; other constants unchanged | Fixed 100-life seed `20261001`: bankruptcy `10.00%` → `11.67%` (7/60, FAIL); the other eight targets remained in range. | Rejected; restored $1.820m. One newly eligible candidate had `181,105,429` cents in dischargeable debt; this pushed filings from 6/60 to 7/60. No alternate seed or 500-life run because the primary cohort failed. Log: `balance_cohort_salary083_degree071_inheritance009_bankruptcy181m_seed20261001_100.log`. |
| Earlier fine threshold step | $1.820m → $1.812m; all other balance constants unchanged | Seed `20261001`: bankruptcy `10.00%`; seed `20261003`: `6.67%`; 500-life: `9.33%`. All other targets PASS. | Passed at the time; later cent-level investigation lowered the minimum. Historical logs: `balance_cohort_salary083_degree071_inheritance009_bankruptcy1812m_seed20261001_100.log`, `...bankruptcy1812m_seed20261003_100.log`, and `...bankruptcy1812m_seed20261001_500.log`. |
| Source diagnosis at requested minimum | $1.812m → $1.200m for fixed-seed source instrumentation; no other balance settings changed | Bankruptcy `20.00%` (12/60 normal lives); other eight targets PASS. There were 15 eligible checks, with dischargeable debt ranging from `121,534,714` to `139,595,697` cents. | Every candidate dollar was an open standalone `living_expense` collection; eligible loan balances and linked mirrors were zero. Gross assets, annual surplus, and repayment capacity were all zero. This is genuine unaffordable unsecured arrears, not secured-debt or linked-mirror miscounting. Diagnostic log: `balance_cohort_bankruptcy120m_source_diagnostics_seed20261001_100.log`. |
| Lower-bound candidate trial | $1,812,000 → $1,811,054.30 (`181,200,000` → `181,105,430` cents); other constants unchanged | Fixed seed `20261001`: bankruptcy `11.67%` (7/60, FAIL); the other eight targets PASS. The lowest eligible candidate in this run was `181,144,691` cents. | Rejected; no alternate-seed or 500-life run because the primary cohort failed. Log: `balance_cohort_bankruptcy181105430_seed20261001_100.log`. |
| Cent-level minimum candidate | $1,811,054.30 → $1,811,446.92 (`181,105,430` → `181,144,692` cents) | Seed `20261001`: bankruptcy `10.00%`; seed `20261003`: `6.67%`; 500-life seed `20261001`: `9.33%`. Every other target PASS in all three cohorts. | Accepted. Minimum equality is eligible; the exact next-lower value is tested separately below. Logs: `balance_cohort_bankruptcy181144692_seed20261001_100.log`, `...seed20261003_100.log`, and `...seed20261001_500.log`. |
| One-cent-lower boundary check | $1,811,446.92 → $1,811,446.91 (`181,144,692` → `181,144,691` cents) | Fixed seed `20261001`: bankruptcy `11.67%` (7/60, FAIL); the other eight targets PASS. | Confirms `181,144,692` cents is the lowest passing threshold for the required fixed-seed target. No alternate-seed or 500-life run because this immediately lower primary cohort failed. Log: `balance_cohort_bankruptcy181144691_seed20261001_100.log`. |
| Pay raise at requested minimum | Salary base `0.83` → `0.835`, minimum held at $1.20m | Fixed seed `20261001`: bankruptcy `20.00%` → `21.67%`; millionaire rate `18.33%` → `21.67%`. Other seven cohort targets passed. | Rejected: missed bankruptcy and millionaire limits. No second seed or 500-life run because the primary 100-life cohort failed. Reverted salary to `0.83`. Log: `balance_cohort_salary0835_degree071_inheritance009_bankruptcy120m_seed20261001_100.log`. |
| Promotion salary-growth trial at requested minimum | `CAREER_PROMOTION_GROWTH_MULTIPLIER` `0.05` → `0.055`; minimum held at $1.20m | Fixed seed `20261001`: bankruptcy `20.00%` → `21.67%`; millionaire rate `18.33%` → `21.67%`. Other seven cohort targets passed. | Rejected: missed bankruptcy and millionaire limits. No second seed or 500-life run because the primary 100-life cohort failed. Restored promotion-growth multiplier `0.05`. Log: `balance_cohort_salary083_degree071_promotiongrowth055_inheritance009_bankruptcy120m_seed20261001_100.log`. |
| Degree salary trial at requested minimum | `CAREER_DEGREE_SALARY_MULTIPLIER` `0.71` → `0.715`; minimum held at $1.20m | Fixed seed `20261001`: bankruptcy `20.00%` → `15.00%` (9/60); millionaire rate `18.33%` → `21.67%`. Other seven cohort targets passed. | Rejected: bankruptcy remained outside 3–10%, and millionaire ceiling failed. No alternate seed or 500-life run because the primary 100-life cohort failed. Restored degree multiplier `0.71`. Log: `balance_cohort_salary083_degree0715_inheritance009_bankruptcy120m_seed20261001_100.log`. |
| Lifespan mean trial at requested minimum | `BASE_LIFESPAN_MEAN` `78` → `79`; minimum held at $1.20m, salary base `0.83` | Fixed seed `20261001`: bankruptcy `20.00%` → `21.67%`; normal median lifespan remained `75.5` years. The other eight cohort targets remained in range. | Rejected: bankruptcy missed the 3–10% target. No alternate-seed or 500-life run because the primary 100-life cohort failed. Restored lifespan mean `78`. Log: `balance_cohort_salary083_degree071_inheritance009_lifespan079_bankruptcy120m_seed20261001_100.log`. |
| Lifespan mean trial at requested minimum | `BASE_LIFESPAN_MEAN` `78` → `77`; minimum held at $1.20m, salary base `0.83` | Fixed seed `20261001`: bankruptcy stayed `20.00%` (12/60); normal median lifespan changed `75.5` → `78.5` years. The other eight cohort targets remained in range. | Rejected: bankruptcy remained outside 3–10%. No alternate-seed or 500-life run because the primary 100-life cohort failed. Restored lifespan mean `78`. Log: `balance_cohort_salary083_degree071_inheritance009_lifespan077_bankruptcy120m_seed20261001_100.log`. |

## Follow-up: testing the originally requested $1.20m minimum

To check whether the explicit $1,200,000 minimum could be retained without relaxing the bankruptcy-rate target, I restored it while keeping the accepted salary, degree, inheritance, and ten-year repayment settings. The fixed 100-life seed was `20261001` (60 normal lives). Before tuning the threshold further, I added repository-backed diagnostics and regressions for mortgage/auto balances and linked collection mirrors. Source reporting showed the $1.20m eligible debt came only from standalone living-expense arrears; because those candidates were assetless with zero modeled surplus, no eligibility-logic correction was justified. After the earlier $1.812m validation, cent-level cohort runs established the lowest passing minimum at $1,811,446.92; the adjacent lower cent fails. The live code uses `181,144,692` cents.

| Trial | Threshold / other change | Natural bankruptcy rate | Other target result | Outcome |
|---|---|---:|---|---|
| Requested minimum | $1.20m; base living cost $12,000/year | 20.00% (12/60) | Other 8 cohort targets PASS | FAIL |
| Modest pay trial | $1.20m; salary base `0.83` → `0.835` | 21.67% (13/60; worsened from 20.00%) | Millionaire rate also failed at 21.67%; normal lifespan 76.5, heavy-crime 54, heavy-addiction 52.5, college median 70,001,317.5 cents, no-HS median 0, billionaires 0, promotion 3; all these targets PASS | REJECTED: bankruptcy and millionaire targets failed. No alternate-seed or 500-life run; restored salary base `0.83`. |
| Promotion pay-growth trial | $1.20m; promotion-growth multiplier `0.05` → `0.055` | 21.67% (13/60; worsened from 20.00%) | Millionaire rate also failed at 21.67%; normal lifespan 80, heavy-crime 60, heavy-addiction 52, college median 54,436,890.5 cents, no-HS median 0, billionaires 0, promotion 3; all these targets PASS | REJECTED: bankruptcy and millionaire targets failed. No alternate-seed or 500-life run; restored promotion-growth multiplier `0.05`. |
| Degree-pay trial | $1.20m; degree multiplier `0.71` → `0.715` | 15.00% (9/60) | Millionaire rate failed at 21.67%; normal lifespan 75, heavy-crime 54, heavy-addiction 52.5, college median 33,110,411.5 cents, no-HS median 0, billionaires 0, promotion 3; all other targets PASS | REJECTED: bankruptcy and millionaire targets failed. No alternate-seed or 500-life run; restored degree multiplier `0.71`. |
| Degree-pay trial | $1.20m; degree multiplier `0.71` → `0.715` | 15.00% (9/60) | Millionaire rate failed at 21.67%; normal lifespan 75, heavy-crime 54, heavy-addiction 52.5, college median 33,110,411.5 cents, no-HS median 0, billionaires 0, promotion 3; all other targets PASS | REJECTED: bankruptcy and millionaire targets failed. No alternate-seed or 500-life run; restored degree multiplier `0.71`. |
| One-year lifespan increase | $1.20m; `BASE_LIFESPAN_MEAN` `78` → `79` | 21.67% (13/60; worsened from 20.00%) | Normal median lifespan 75.5 years; heavy-crime 58.5, heavy-addiction 53.5, millionaire rate 18.33%, billionaire rate 0%, college median 56,486,390 cents, no-HS median 0, promotion 3; all eight non-bankruptcy targets PASS | REJECTED: bankruptcy target failed. No alternate-seed or 500-life run; restored lifespan mean `78`. |
| One-year lifespan decrease | $1.20m; `BASE_LIFESPAN_MEAN` `78` → `77` | 20.00% (12/60; unchanged) | Normal median lifespan 78.5 years; heavy-crime 58.5, heavy-addiction 53.5, millionaire rate 18.33%, billionaire rate 0%, college median 40,890,437.5 cents, no-HS median 0, promotion 3; all eight non-bankruptcy targets PASS | REJECTED: bankruptcy target remained out of range. No alternate-seed or 500-life run; restored lifespan mean `78`. |
| Cost-only trial | $1.20m; base living cost reduced to $11,000/year | 16.67% (10/60) | Other targets PASS; heavy-crime median 46.5 years | FAIL |
| Threshold step | $1.65m; living cost restored to $12,000/year | 15.00% (9/60) | Other 8 targets PASS | FAIL |
| Threshold step | $1.75m | 11.67% (7/60) | Other 8 targets PASS | FAIL |
| Threshold step | $1.80m | 11.67% (7/60) | Other 8 targets PASS | FAIL |
| Threshold comparison | $1.85m | 10.00% (6/60) | Other 8 targets PASS; alternate 100-life seed and 500-life cohort also pass | PASS |
| Threshold step | $1.84m | 10.00% (6/60) | Alternate seed: 6.67%; 500-life: 9.33%; other targets PASS | PASS |
| Threshold step | $1.835m | 10.00% (6/60) | Alternate seed: 6.67%; 500-life: 9.33%; other targets PASS | PASS |
| Threshold step | $1.830m | 10.00% (6/60) | Alternate seed: 6.67%; 500-life: 9.33%; other targets PASS | PASS |
| Threshold-floor trial | $1.810m | 11.67% (7/60) | Other 8 targets PASS | FAIL |
| Threshold step | $1.820m | 10.00% (6/60) | Alternate seed: 6.67%; 500-life: 9.33%; other targets PASS | PASS |
| Final lowest fully validated setting | $1,811,446.92 (`181,144,692` cents) | 10.00% (6/60) | Alternate seed: 6.67%; 500-life: 9.33%; other targets PASS | PASS |
| One cent lower | $1,811,446.91 (`181,144,691` cents) | 11.67% (7/60) | Other 8 targets PASS | FAIL |

Logs: `balance_cohort_salary083_degree071_inheritance009_bankruptcy120m_seed20261001_100.log`, `balance_cohort_salary0835_degree071_inheritance009_bankruptcy120m_seed20261001_100.log`, `balance_cohort_salary083_degree071_promotiongrowth055_inheritance009_bankruptcy120m_seed20261001_100.log`, `balance_cohort_salary083_degree0715_inheritance009_bankruptcy120m_seed20261001_100.log`, `balance_cohort_salary083_degree071_inheritance009_lifespan079_bankruptcy120m_seed20261001_100.log`, `balance_cohort_salary083_degree071_inheritance009_lifespan077_bankruptcy120m_seed20261001_100.log`, `balance_cohort_salary083_degree071_inheritance009_living110_bankruptcy120m_seed20261001_100.log`, `balance_cohort_salary083_degree071_inheritance009_bankruptcy165m_seed20261001_100.log`, `balance_cohort_salary083_degree071_inheritance009_bankruptcy175m_seed20261001_100.log`, `balance_cohort_salary083_degree071_inheritance009_bankruptcy180m_seed20261001_100.log`, `balance_cohort_salary083_degree071_inheritance009_bankruptcy184m_seed20261001_100.log`, `balance_cohort_salary083_degree071_inheritance009_bankruptcy184m_seed20261003_100.log`, `balance_cohort_salary083_degree071_inheritance009_bankruptcy184m_seed20261001_500.log`, `balance_cohort_salary083_degree071_inheritance009_bankruptcy1835m_seed20261001_100.log`, `balance_cohort_salary083_degree071_inheritance009_bankruptcy1835m_seed20261003_100.log`, `balance_cohort_salary083_degree071_inheritance009_bankruptcy1835m_seed20261001_500.log`, `balance_cohort_salary083_degree071_inheritance009_bankruptcy1830m_seed20261001_100.log`, `balance_cohort_salary083_degree071_inheritance009_bankruptcy1830m_seed20261003_100.log`, `balance_cohort_salary083_degree071_inheritance009_bankruptcy1830m_seed20261001_500.log`, `balance_cohort_salary083_degree071_inheritance009_bankruptcy182m_seed20261001_100.log`, `balance_cohort_salary083_degree071_inheritance009_bankruptcy182m_seed20261003_100.log`, `balance_cohort_salary083_degree071_inheritance009_bankruptcy182m_seed20261001_500.log`, `balance_cohort_salary083_degree071_inheritance009_bankruptcy181m_seed20261001_100.log`, `balance_cohort_salary083_degree071_inheritance009_bankruptcy1812m_seed20261001_100.log`, `balance_cohort_salary083_degree071_inheritance009_bankruptcy1812m_seed20261003_100.log`, and `balance_cohort_salary083_degree071_inheritance009_bankruptcy1812m_seed20261001_500.log`, `balance_cohort_bankruptcy120m_source_diagnostics_seed20261001_100.log`, `balance_cohort_bankruptcy181105430_seed20261001_100.log`, `balance_cohort_bankruptcy181144692_seed20261001_100.log`, `balance_cohort_bankruptcy181144692_seed20261003_100.log`, `balance_cohort_bankruptcy181144692_seed20261001_500.log`, and `balance_cohort_bankruptcy181144691_seed20261001_100.log`.

Under the historical eligibility-triggered auto-file policy, the requested $1.20m floor admitted genuine living-expense arrears and produced 20% filings; this is a synthetic action-policy rate, not natural player incidence. The historical minimum that passed the three old cohorts was $1,811,446.92, with one cent lower failing one fixed seed. That boundary is superseded by the current $1.812m user-directed setting and is not current natural-rate evidence.

## Follow-up audit of the historical 70% filing run

The 70% bankruptcy / 28.33% millionaire / 157,598,288-cent college-median / 74.5-year normal-lifespan figures are from `balance_cohort_salarycompress.log`. That report predates the stricter policy gate: its `natural_bankruptcy_definition` only required an adult, not imprisoned, outside cooldown, with liabilities exceeding gross assets, and it has no `bankruptcy_policy` assessment object. It is not comparable to the later acceptance runs.

The current implementation was checked against the requested policy:

- `EconomyRepository.bankruptcy_debt_facts` counts only personal, payday, and loan-shark active/defaulted loan balances plus standalone open collections (`loan_id IS NULL`). Student, mortgage, and auto loans are excluded; linked collection mirrors are not double-counted.
- `EconomyService._bankruptcy_eligibility` requires dischargeable debt strictly above 2× gross assets, checks liquid cash/bank against the debt, and blocks filing when liquid funds plus ten years of after-tax surplus after living and housing costs can repay it.
- The first-loan age check remains `BANKRUPTCY_MIN_FIRST_LOAN_AGE_YEARS = 2`.
- The full-life harness invokes the real filing service only after `assessment.eligible` is true; the service rechecks eligibility transactionally. There are no forced filings.
- Economy regressions cover student-debt exclusion, mortgage/auto balance and linked-mirror exclusion/survival, linked unsecured-mirror non-duplication, first-loan age, the 2× asset rule, exact minimum boundary, ten-year after-tax repayment-capacity blocking, discharge, and cooldown. The full suite passed on the final configuration.

Under the historical eligibility-triggered auto-file policy at the requested $1.20m minimum, the measured action-policy rate is 20.00%, not 70.00%. The source diagnostic shows eligible candidates had only standalone open `living_expense` collections (no dischargeable loan principal or linked collection mirrors); each had zero gross assets and zero ten-year repayment capacity. This supports the existing policy gates rather than indicating a secured-debt accounting bug. The historical 500-life run at $1,811,446.92 recorded 9.33% auto-filings; this is not an estimate of natural player action. Its other 500-life measurements and the previous career-pay trials remain historical context, not current final-pass results.

## Follow-up: small career-pay trim trial

At the user's request, tested small reductions from the accepted salary base `0.83`, holding the other accepted settings fixed. Both trials used 100 lives, seed `20261001` (60 normal lives). No second seed or 500-life run was started for a trial that failed on the primary 100-life cohort.

| Change | Normal lifespan | Heavy crime / addiction lifespan | Bankruptcy | Millionaires | College median (cents) | No-high-school median | Promotion | Result |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| Accepted baseline: salary `0.83` | 75.5 | 58.5 / 53.5 | 10.00% (6/60) | 18.33% | 50,889,308 | 0 | 3 years | All targets PASS |
| Trial: `0.83` → `0.82` | 76.5 | 48.5 / 52.5 | 13.33% (8/60) | 20.00% | 21,615,361 (FAIL) | 0 | 3 years | FAIL: bankruptcy and college wealth |
| Trial: `0.83` → `0.825` | 77.5 | 63.5 / 53.5 | 15.00% (9/60) | 20.00% | 58,803,731.5 | 0 | 3 years | FAIL: bankruptcy |

The salary base was restored to `0.83`. Logs: `balance_cohort_salary082_degree071_inheritance009_bankruptcy185m_seed20261001_100.log` and `balance_cohort_salary0825_degree071_inheritance009_bankruptcy185m_seed20261001_100.log`. Because each trial missed a required 100-life target, the already-validated `0.83` setting remains the accepted configuration; no further salary, investment-return, or lifespan change is warranted from these results.

## Cohort acceptance results

All values are measured; no out-of-range measurement is marked PASS. Rates use normal-profile lives only (60 normal lives in each 100-life cohort, 300 in the 500-life cohort). College and no-high-school wealth values are final net worth in cents.

| Target | Required range | 100 lives, seed `20261001` | 100 lives, seed `20261003` | 500 lives, seed `20261001` | Status |
|---|---:|---:|---:|---:|---|
| Normal median lifespan | 75–85 years | 75.5 | 79.5 | 78.0 | PASS |
| Heavy-crime median lifespan | 45–65 years | 58.5 | 51.0 | 55.0 | PASS |
| Heavy-addiction median lifespan | 45–65 years | 53.5 | 52.5 | 52.0 | PASS |
| Natural bankruptcy filings | 3–10% | 10.00% (6/60) | 6.67% (4/60) | 9.33% (28/300) | PASS |
| Normal millionaire rate | 8–20% | 18.33% (11/60) | 20.00% (12/60) | 18.67% (56/300) | PASS |
| Normal billionaire rate | <0.5% | 0.00% | 0.00% | 0.00% (0/300) | PASS |
| College-graduate median final net worth | 25,000,000–150,000,000 cents | 50,889,308 | 73,333,890 | 70,007,687.5 | PASS |
| No-high-school median final net worth | 0–15,000,000 cents | 0 | 0 | 0 | PASS |
| Average-performer time to first promotion | 2–4 years | 3 | 3 | 3 | PASS |

The final 500-life run used 300 normal, 100 heavy-crime, and 100 heavy-addiction profiles. Full report: `balance_cohort_bankruptcy181144692_seed20261001_500.log`. The matching accepted 100-life runs are `balance_cohort_bankruptcy181144692_seed20261001_100.log` and `...seed20261003_100.log`; the immediate lower boundary run is `balance_cohort_bankruptcy181144691_seed20261001_100.log`.

## Casino RTP and crime expected value

Casino measurement: one million trials per sampled game, 250,000 blackjack hands, seed `20260930`; exact payout expectations are reported separately from Monte Carlo observations. The roulette unit test evaluates every roulette bet class.

| Game / policy | Exact gross RTP | Observed gross RTP | Target | Status |
|---|---:|---:|---:|---|
| Slots | 92.0000% | 91.9354% | 90–97% | PASS |
| Coinflip (heads) | 97.0000% | 97.0830% | 90–97% | PASS |
| Roulette (red, dozen, straight; all bet classes) | 96.3243% | 96.2987%, 96.6376%, 97.4148% | 90–97% exact | PASS |
| Blackjack, hit below 17 / stand at 17 / no double or split; dealer stands on 17 | 94.3244% | 94.1286% | 90–97% | PASS |
| Lottery ticket | 95.5000% | Exact probability-weighted value | 90–97% | PASS |

The roulette straight-bet Monte Carlo sample is above 97%, but its exact payout RTP is 96.3243%; the requirement is based on exact RTP. Blackjack is player-choice-dependent, so the exact figure is for the explicitly stated baseline policy using finite six-deck enumeration. Full metrics: `balance_acceptance_metrics.json`.

Crime EV includes expected fines, custody time, lost wages, and a record-linked job-search cost. Values are cents per attempt.

| Crime | Net EV per attempt | Status |
|---|---:|---|
| Assault | -5,111,807 cents | PASS (negative) |
| Armed robbery | -30,682,489 cents | PASS (negative) |
| Bank heist | -45,176,387 cents | PASS (negative) |
| Murder | -205,059,051 cents | PASS (negative) |
| Shoplifting benchmark | +1,386 cents ($13.86) | PASS ($0–$100) |

## Test and validation record

- Targeted economy tests after the bankruptcy regressions: **30 passed**; syntax compilation passed.
- Historical auto-file cohort validation at `181,144,692` cents: both 100-life seeds (`20261001`, `20261003`) and the 500-life seed (`20261001`) passed all nine cohort targets under the earlier deterministic eligibility-triggered filing policy. These are not current natural-filing evidence. The 500-life cohort completed in 1,614.24s; full reports are retained under `balance_cohort_bankruptcy181144692_*.log`.
- Historical adjacent lower-boundary test at `181,144,691` cents: fixed 100-life seed `20261001` measured 7/60 auto-filings (11.67%, FAIL); the other eight targets passed under that same synthetic policy.
- Prior full suite before the final health/command changes: **225 passed, 1 skipped in 40.86s**. Current full-suite results are listed in the final-pass section below.
- Follow-up cross-check against the saved measurements (2026-10-04): exact RTPs are slots 92.00%, coinflip 97.00%, roulette 96.3243% for each listed bet, blackjack 94.3244%, and lottery 95.50%; all are within 90–97%. Violent-crime EVs remain negative after modeled costs, and shoplifting is +1,386¢ ($13.86) per attempt. These were read from `balance_acceptance_metrics.json`; no casino, crime, inflation, lifespan, salary, or promotion constants were changed in the bankruptcy-threshold search.

## Bankruptcy source and minimum audit

The fixed-seed $1.20m diagnostic (`20261001`, 100 total lives / 60 normal lives) recorded 15 eligible checks across 12 distinct normal-profile filers. All reported dischargeable debt was from standalone `living_expense` collections, ranging from `121,534,714` to `139,595,697` cents (median `126,610,435` cents; mean `127,520,588.73` cents). At these checks, dischargeable loan balances were zero, linked collection mirrors were zero, and gross assets, annual surplus, and the ten-year repayment capacity were each zero.

| Debt / eligibility component | Diagnostic measurement at $1.20m | Treatment / result |
|---|---:|---|
| Personal, payday, and loan-shark balances | 0 cents across eligible checks | Normally dischargeable, but none were present in this cohort's candidate debt. |
| Standalone `living_expense` collections | 121,534,714–139,595,697 cents | Counted as unsecured dischargeable debt; this was the entire candidate total. |
| Linked collection mirrors | 0 cents across eligible checks | Excluded from the eligibility sum to avoid double-counting the underlying loan. |
| Student, mortgage, and auto balances | Excluded by the repository query | Not dischargeable; mortgage/auto-only and linked-mirror regressions now verify they do not qualify or get discharged. |
| Gross assets / annual surplus / ten-year repayment capacity | 0 / 0 / 0 cents | Candidates satisfy the insolvency and inability-to-pay checks rather than bypassing them. |

Historically, under the old eligibility-triggered auto-file policy, the fixed 100-life primary seed passed at `181,144,692` cents (6/60 filings, 10.00%) and failed one cent lower at `181,144,691` cents (7/60, 11.67%). Those values are not accepted as natural filing-rate evidence after the no-forced-filing correction.

## Final validation — 2026-10-05 (current)

The code retains `BANKRUPTCY_MIN_DISCHARGEABLE_DEBT_CENTS = 181_200_000` per the latest direction. The `$1.2m` request remains unmet: the source diagnosis found only standalone living-expense collections of `121,534,714`–`139,595,697` cents, no dischargeable loan balances or linked mirrors, and zero gross assets, annual surplus, and ten-year repayment capacity. Under the old automatic-file policy those accounts led to 12/60 (20%) filings, but that was a synthetic choice policy. Current cohorts audit eligibility and never call `file_bankruptcy`; they record zero actual filings, so the 3–10% filing target is FAIL and cannot be tuned by changing the threshold without a specified player-decision model.

The 100-life tuning checks were run on seeds `20261004` and `20261005` at the current `$1.812m` floor. Their small-sample acceptance values and target statuses are:

| Target | Range | Seed 20261004 | Status | Seed 20261005 | Status |
|---|---:|---:|---:|---:|---:|
| Normal median lifespan | 75–85 years | 82.5 | PASS | 80.5 | PASS |
| Heavy-crime median lifespan | 45–65 years | 48.5 | PASS | 66.5 | FAIL |
| Heavy-addiction median lifespan | 45–65 years | 46 | PASS | 52.5 | PASS |
| Millionaire rate | 8–20% | 21.67% | FAIL | 20.00% | PASS |
| Billionaire rate | <0.5% | 0% | PASS | 0% | PASS |
| Actual bankruptcy filings | 3–10% | 0/60 = 0% | FAIL | 0/60 = 0% | FAIL |
| College median final net worth | 25,000,000–150,000,000¢ | 98,031,477¢ | PASS | 79,170,182¢ | PASS |
| No-high-school median final net worth | 0–15,000,000¢ | No observations (n=0) | FAIL | No observations (n=0) | FAIL |
| Years to first promotion | 2–4 years | 3.5 | PASS | 3.0 | PASS |

Each 100-life no-forced run completed with `1 passed` at the pytest level (234.35s and 259.62s); the acceptance flags above are separate. The current helper recorded 42 and 38 eligible-debt checks but did not file. Earlier 181.2/185/190 auto-file experiment logs are retained for audit only and are excluded from current validation.

Final-size cohorts were then run at 500 lives per seed (300 normal, 100 heavy-crime, 100 heavy-addiction): `20261004` completed in 1075.47s and `20261005` in 1060.14s. Both completed with one pytest test passed. Acceptance results:

| Target | Range | Seed 20261004 | Status | Seed 20261005 | Status |
|---|---:|---:|---:|---:|---:|
| Normal median lifespan | 75–85 years | 79.0 | PASS | 79.5 | PASS |
| Heavy-crime median lifespan | 45–65 years | 58.0 | PASS | 53.0 | PASS |
| Heavy-addiction median lifespan | 45–65 years | 53.0 | PASS | 53.0 | PASS |
| Millionaire rate | 8–20% | 20.33% | FAIL | 19.67% | PASS |
| Billionaire rate | <0.5% | 0% | PASS | 0% | PASS |
| Actual bankruptcy filings | 3–10% | 0/300 = 0% | FAIL | 0/300 = 0% | FAIL |
| College median final net worth | 25,000,000–150,000,000¢ | 58,109,698.5¢ | PASS | 66,044,299¢ | PASS |
| No-high-school median final net worth | 0–15,000,000¢ | 0¢ (n=6) | PASS | 0¢ (n=7) | PASS |
| Years to first promotion | 2–4 years | 3 | PASS | 3 | PASS |

These final-size cohorts recorded 88 and 175 eligible-debt checks and still submitted zero filings. Apart from the action-dependent filing-rate target, seed `20261005` passes all targets; seed `20261004` misses the millionaire ceiling by 0.33 percentage points. No general balance tuning was reopened.

The disease onset multiplier stays at `0.09`: historical probes at `0.25` versus `0.10` recorded 35 versus 16 illness deaths and medians 64.5 versus 77.5 years; both final-size `0.09` cohorts have normal/crime/addiction medians inside their bands. `1.0` was not tested. The health feature and command-alias tests passed in the full suite.

Final software tests: **228 passed, 1 skipped, 229 Discord deprecation warnings in 43.67s** (`python -m pytest -q`). The skip is the opt-in cohort, executed separately at 100 and 500 lives for seeds `20261004` and `20261005`. No live Discord sync was run.
