"""Stage 10 slash commands for legacy, achievements, leaderboards, and retirement."""
from __future__ import annotations

import json
import time
from typing import Any, Optional

import discord
from discord import app_commands
from discord.ext import commands

from core.achievements import AchievementService
from core.embeds import safe_text as escape_user_text
from core.death import DeathService
from core.errors import GameError, ValidationError
from core.leaderboard import LeaderboardService, METRICS
from core.money import format_cents
from core.life_engine import LifeEngine
from core.locks import UserLockRegistry
from core.models import Character
from core.repositories.legacy import LegacyRepository
from core.rng import RNG
from cogs.legacy_views import (
    EmbedPager,
    HeirSelectView,
    RetirementConfirmView,
    death_summary_embed,
    leaderboard_embed,
)

_METRIC_CHOICES = [
    app_commands.Choice(name=label, value=key) for key, label in METRICS.items()
]
_SCOPE_CHOICES = [
    app_commands.Choice(name="Server", value="server"),
    app_commands.Choice(name="Global", value="global"),
]
_PERIOD_CHOICES = [
    app_commands.Choice(name="Current life", value="current"),
    app_commands.Choice(name="All time", value="all_time"),
]
_LEGACY_STAT_CHOICES = [
    app_commands.Choice(name="Health", value="health"),
    app_commands.Choice(name="Happiness", value="happiness"),
    app_commands.Choice(name="Smarts", value="smarts"),
    app_commands.Choice(name="Looks", value="looks"),
    app_commands.Choice(name="Fitness", value="fitness"),
    app_commands.Choice(name="Karma", value="karma"),
]
_PURCHASE_CHOICES = [
    app_commands.Choice(name="No purchase", value=0),
    app_commands.Choice(name="One purchase · 50 points · +5", value=1),
    app_commands.Choice(name="Two purchases · 100 points · +10", value=2),
]


def _safe(value: Any, limit: int = 160) -> str:
    """Escape markdown and mention syntax for all stored/user-facing text."""
    return escape_user_text(value, limit)


def _pages(title: str, entries: list[str], *, color: discord.Color) -> list[discord.Embed]:
    """Create pages with ten entries each, respecting Discord description limits."""
    if not entries:
        return [discord.Embed(title=title, description="No records to display yet.", color=color)]
    result: list[discord.Embed] = []
    for start in range(0, len(entries), 10):
        group = entries[start:start + 10]
        embed = discord.Embed(title=title, description="\n".join(group), color=color)
        embed.set_footer(text=f"Page {start // 10 + 1} of {(len(entries) + 9) // 10}")
        result.append(embed)
    return result


class LegacyCog(commands.Cog):
    """Player-facing Stage 10 commands; all persistence stays in services/repositories."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.db = bot.db
        self.locks: UserLockRegistry = getattr(bot, "locks", UserLockRegistry())
        self.achievements: AchievementService = getattr(bot, "achievement_service", None) or AchievementService(
            self.db, self.locks
        )
        self.leaderboards = LeaderboardService(self.db, self.achievements, self.locks)
        self.engine: LifeEngine = getattr(bot, "life_engine", None) or LifeEngine(
            self.db,
            getattr(bot, "rng", RNG()),
            self.locks,
            family_service=getattr(bot, "family_service", None),
            crime_service=getattr(bot, "crime_service", None),
            shop_service=getattr(bot, "shop_service", None),
            casino_service=getattr(bot, "casino_service", None),
            investing_service=getattr(bot, "investing_service", None),
            economy_service=getattr(bot, "economy_service", None),
            achievement_service=self.achievements,
            data_loader=getattr(bot, "data_loader", None),
        )
        self.death: DeathService = self.engine.death
        self.repository = LegacyRepository(self.db)

    @app_commands.command(name="leaderboard", description="Rank players by a life, wealth, fame, or activity metric")
    @app_commands.describe(
        metric="What to rank players by",
        scope="Rank players seen in this server or across the bot",
        period="Compare current lives or each player's all-time record",
    )
    @app_commands.choices(metric=_METRIC_CHOICES, scope=_SCOPE_CHOICES, period=_PERIOD_CHOICES)
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def leaderboard(
        self,
        interaction: discord.Interaction,
        metric: str,
        scope: str = "server",
        period: str = "current",
    ) -> None:
        """Display the requested leaderboard in owner-controlled pages of ten."""
        await interaction.response.defer(thinking=True, ephemeral=False)
        result = await self.leaderboards.get_leaderboard(
            interaction.user.id,
            metric=metric,
            scope=scope,
            period=period,
            guild_id=interaction.guild_id,
        )
        pages = [leaderboard_embed(result, page) for page in range(max(1, (len(result.entries) + 9) // 10))]
        view = EmbedPager(interaction.user.id, pages)
        message = await interaction.followup.send(
            embed=pages[0], view=view, wait=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        view.bind_message(message)

    @app_commands.command(name="achievements", description="View earned achievements for yourself or another player")
    @app_commands.describe(user="Optional player whose public achievements you want to view")
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def achievements(
        self,
        interaction: discord.Interaction,
        user: Optional[discord.User] = None,
    ) -> None:
        """List catalog achievements earned from authoritative game records."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        target = user or interaction.user
        if int(target.id) != int(interaction.user.id) and await self.leaderboards.is_opted_out(int(target.id)):
            raise ValidationError("That player's public profile is private.")
        rows = await self.achievements.list_for_user(int(target.id))
        if not rows:
            await interaction.followup.send(
                f"{_safe(getattr(target, 'display_name', target.name), 80)} has no unlocked achievements yet.",
                ephemeral=True,
                allowed_mentions=discord.AllowedMentions.none(),
            )
            return
        descriptions = [
            f"🏆 **{_safe(row['name'], 80)}** · {_safe(row['description'], 170)}\n"
            f"_{_safe(row['category'].title(), 30)} · {_safe(row.get('character_name', 'Life'), 48)}_"
            for row in rows
        ]
        pages = _pages(
            f"{_safe(getattr(target, 'display_name', target.name), 80)} · Achievements ({len(rows)})",
            descriptions,
            color=discord.Color.gold(),
        )
        view = EmbedPager(interaction.user.id, pages)
        message = await interaction.followup.send(
            embed=pages[0], view=view, ephemeral=True, wait=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        view.bind_message(message)

    lives = app_commands.Group(name="lives", description="Review your immutable life archive")

    @lives.command(name="list", description="List your most recent archived lives")
    @app_commands.checks.cooldown(1, 4.0, key=lambda interaction: interaction.user.id)
    async def lives_list(self, interaction: discord.Interaction) -> None:
        """List archived lives newest-first; view numbers use the same ordering."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        async with self.locks.hold(interaction.user.id):
            async with self.db.transaction() as tx:
                rows = await self.repository.user_past_lives(tx, interaction.user.id, 100)
        descriptions = [
            f"**Life {index}.** Age {int(row['death_age'])} · Grade **{_safe(row['grade'], 1)}** · "
            f"Score {float(row['life_score']):.2f} · Legacy points {int(row['legacy_points'])}\n"
            f"Cause: {_safe(row['death_cause'], 90)} · Estate: {format_cents(int(row['estate_cents']))}"
            for index, row in enumerate(rows, start=1)
        ]
        pages = _pages("Your archived lives · newest first", descriptions, color=discord.Color.dark_grey())
        view = EmbedPager(interaction.user.id, pages)
        message = await interaction.followup.send(
            embed=pages[0], view=view, ephemeral=True, wait=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        view.bind_message(message)

    @lives.command(name="view", description="Open one archived life (1 is the most recent)")
    @app_commands.describe(number="Archive position, where 1 is your most recent life")
    @app_commands.checks.cooldown(1, 4.0, key=lambda interaction: interaction.user.id)
    async def lives_view(
        self,
        interaction: discord.Interaction,
        number: app_commands.Range[int, 1, 1000],
    ) -> None:
        """Render one immutable past-life summary without exposing another player."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        async with self.locks.hold(interaction.user.id):
            async with self.db.transaction() as tx:
                rows = await self.repository.user_past_lives(tx, interaction.user.id, int(number))
        if len(rows) < number:
            raise ValidationError("That archive position does not exist. Use `/lives list` to review your lives.")
        row = rows[number - 1]
        summary = json.loads(str(row["summary_json"]))
        definitions = {str(item["id"]): str(item["name"]) for item in self.achievements.definitions}
        avatar = getattr(getattr(interaction.user, "display_avatar", None), "url", None)
        embed = death_summary_embed(summary, avatar_url=avatar, achievement_names=definitions)
        embed.title = f"Archived life · {number}"
        await interaction.followup.send(
            embed=embed, ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @app_commands.command(name="graveyard", description="Browse recent public life archives")
    @app_commands.describe(scope="Show deaths from this server or across the bot")
    @app_commands.choices(scope=_SCOPE_CHOICES)
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def graveyard(self, interaction: discord.Interaction, scope: str = "global") -> None:
        """Browse recent naturally completed lives, excluding opted-out accounts."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        if scope not in {"server", "global"}:
            raise ValidationError("Graveyard scope must be server or global.")
        if scope == "server" and interaction.guild_id is None:
            raise ValidationError("A server graveyard is only available inside a server.")
        async with self.locks.hold(interaction.user.id):
            async with self.db.transaction() as tx:
                rows = await self.repository.recent_deaths(tx, 100)
                if scope == "server":
                    seen = set(await self.repository.seen_guild_users(tx, int(interaction.guild_id)))
                    rows = [row for row in rows if int(row["user_id"]) in seen]
        descriptions = [
            f"**{_safe(row['name'], 70)}** · Age {int(row['death_age'])} · Grade **{_safe(row['grade'], 1)}**\n"
            f"{_safe(row['death_cause'], 90)} · {_safe(row.get('summary_json') and json.loads(row['summary_json']).get('epitaph', ''), 150)}"
            for row in rows
        ]
        pages = _pages("Recent lives remembered", descriptions, color=discord.Color.dark_grey())
        view = EmbedPager(interaction.user.id, pages)
        message = await interaction.followup.send(
            embed=pages[0], view=view, ephemeral=True, wait=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        view.bind_message(message)

    @app_commands.command(name="inheritance", description="Reopen a pending heir choice after a death")
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def inheritance(self, interaction: discord.Interaction) -> None:
        """Reopen a still-pending owner/nonce-bound estate selection."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        async with self.locks.hold(interaction.user.id):
            async with self.db.transaction() as tx:
                estate = await self.repository.pending_life_estate(tx, interaction.user.id)
        if estate is None:
            raise ValidationError("You have no pending inheritance choice. Use `/start` for a fresh life.")
        heirs = json.loads(str(estate["eligible_heirs_json"]))
        view = HeirSelectView(
            interaction.user.id, int(estate["estate_id"]), str(estate["nonce"]),
            heirs, self.death,
        )
        embed = discord.Embed(
            title="Continue the family line?",
            description=(
                "Choose one of your living adult children. The after-tax estate is split across "
                "all eligible adult children. You can also close the estate and start fresh."
            ),
            color=discord.Color.gold(),
        )
        message = await interaction.followup.send(
            embed=embed, view=view, ephemeral=True, wait=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        view.bind_message(message)

    @app_commands.command(name="retire_life", description="Abandon your current life after confirmation")
    @app_commands.checks.cooldown(1, 10.0, key=lambda interaction: interaction.user.id)
    async def retire_life(self, interaction: discord.Interaction) -> None:
        """Open an owner- and nonce-bound confirmation; no legacy or heir reward is granted."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        prompt = await self.death.begin_retirement(interaction.user.id)
        definitions = {str(item["id"]): str(item["name"]) for item in self.achievements.definitions}
        avatar = getattr(getattr(interaction.user, "display_avatar", None), "url", None)
        view = RetirementConfirmView(
            interaction.user.id, prompt, self.death,
            achievement_names=definitions, avatar_url=avatar,
        )
        embed = discord.Embed(
            title="Confirm life abandonment",
            description=(
                "Retiring ends this life permanently. It will be archived as **Life abandoned**; "
                "you receive no legacy points, no heir continuation, and no debt is transferred. "
                "This confirmation expires in one minute."
            ),
            color=discord.Color.orange(),
        )
        message = await interaction.followup.send(embed=embed, view=view, ephemeral=True, wait=True)
        view.bind_message(message)

    @app_commands.command(name="start", description="Begin a fresh life, optionally spending cosmetic legacy points")
    @app_commands.describe(
        name="Your character's name",
        gender="Character gender",
        country="Country or region code, such as usa or in",
        legacy_stat="Optional starting stat to improve with earned legacy points",
        purchases="Spend 50 points per +5, up to two purchases in this life",
    )
    @app_commands.choices(
        gender=[
            app_commands.Choice(name="Male", value="male"),
            app_commands.Choice(name="Female", value="female"),
            app_commands.Choice(name="Non-binary", value="non_binary"),
        ],
        legacy_stat=_LEGACY_STAT_CHOICES,
        purchases=_PURCHASE_CHOICES,
    )
    @app_commands.checks.cooldown(1, 8.0, key=lambda interaction: interaction.user.id)
    async def start(
        self,
        interaction: discord.Interaction,
        name: str,
        gender: str = "male",
        country: str = "usa",
        legacy_stat: Optional[str] = None,
        purchases: int = 0,
    ) -> None:
        """Start a new life; legacy spending changes only one capped starting stat."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        character = await self.engine.create_character(
            interaction.user.id,
            name,
            gender=gender,
            country=country,
            legacy_stat=legacy_stat,
            legacy_purchases=purchases,
        )
        from cogs.life import _character_embed
        embed = _character_embed(character)
        if purchases:
            embed.description = (
                f"Spent **{purchases * 50} legacy points** on +{5 * purchases} {legacy_stat}. "
                "No money bonus was applied.\n\n" + (embed.description or "")
            )
        embed.set_footer(text=f"Generation {character.generation} · Legacy is cosmetic only")
        await interaction.followup.send(
            embed=embed, ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @app_commands.command(name="leaderboard_privacy", description="Opt out of public leaderboards and public profile summaries")
    @app_commands.describe(opt_out="Hide your account from public ranking, achievement, and graveyard views")
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def leaderboard_privacy(self, interaction: discord.Interaction, opt_out: bool) -> None:
        """Set the simple per-player public-profile visibility flag."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        await self.leaderboards.set_opt_out(interaction.user.id, opt_out)
        status = "hidden" if opt_out else "visible"
        await interaction.followup.send(
            f"Your public leaderboard/profile preference is now **{status}**.",
            ephemeral=True,
        )

    @app_commands.command(name="guild_death_summaries", description="Choose whether death summaries may post publicly in this server")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.describe(public="Allow public death summaries in the channel where `/life age` is used")
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def guild_death_summaries(self, interaction: discord.Interaction, public: bool) -> None:
        """Set a guild-level public obituary option; account privacy opt-out still wins."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        if interaction.guild_id is None:
            raise ValidationError("This setting is only available in a server.")
        async with self.locks.hold(interaction.user.id):
            async with self.db.transaction() as tx:
                await self.repository.set_guild_public_death_summaries(
                    tx,
                    guild_id=int(interaction.guild_id),
                    enabled=public,
                    user_id=interaction.user.id,
                    now=int(time.time()),
                )
        state = "enabled" if public else "disabled"
        await interaction.followup.send(
            f"Public death summaries are now **{state}** for this server. A player's privacy opt-out always takes priority.",
            ephemeral=True,
        )


async def setup(bot: commands.Bot) -> None:
    """Load the Stage 10 command cog."""
    await bot.add_cog(LegacyCog(bot))
