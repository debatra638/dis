"""Slash commands for school status, studying, and higher-education enrollment."""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from core.education import EducationService, StudyResult
from core.models import Character
from core.embeds import safe_text


EDUCATION_LABELS = {
    "none": "No completed schooling",
    "primary": "Primary school",
    "high_school": "High school diploma",
    "bachelor": "Bachelor's degree",
    "master": "Master's degree",
    "doctorate": "Doctorate",
}


def _education_embed(character: Character) -> discord.Embed:
    completed = EDUCATION_LABELS[character.education_level.value]
    current = "Not currently enrolled"
    if character.current_school and character.school_program:
        current = (
            f"{character.current_school} · {character.school_program.value.replace('_', ' ').title()}\n"
            f"{character.school_years_left} year(s) remaining"
        )
    gpa = "Not recorded" if character.gpa is None else f"{character.gpa:.2f} / 4.00"
    embed = discord.Embed(
        title=f"Education · {safe_text(character.name, 80)}",
        description=f"Age {character.age} · Life #{character.char_id}",
        color=discord.Color.blurple(),
    )
    embed.add_field(name="Highest completed", value=completed, inline=True)
    embed.add_field(name="Current program", value=current, inline=True)
    embed.add_field(name="GPA", value=gpa, inline=True)
    if character.major:
        embed.add_field(name="Major", value=character.major, inline=True)
    embed.set_footer(text="Use /education study once per in-game year while enrolled")
    return embed


def _study_embed(result: StudyResult) -> discord.Embed:
    changes = []
    for stat, delta in result.stat_changes.items():
        changes.append(f"{stat.title()} {'+' if delta > 0 else ''}{delta}")
    embed = discord.Embed(
        title="📚 Study session complete",
        description=(
            f"**Effort:** {result.effort.value.title()}\n"
            f"**GPA:** {result.gpa_before:.2f} → {result.gpa_after:.2f}\n"
            f"**School:** {result.character.current_school}"
        ),
        color=discord.Color.green() if result.effort.value != "slack" else discord.Color.gold(),
    )
    embed.add_field(name="Stat effects", value=" · ".join(changes) if changes else "No stat changes", inline=False)
    embed.set_footer(text=f"Age {result.character.age} · One study action per year")
    return embed


class EducationCog(commands.Cog):
    """Education actions attached to the persistent life character."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.service = EducationService(bot.db, getattr(bot, "locks", None))

    education = app_commands.Group(name="education", description="Manage school and higher education")

    @education.command(name="status", description="View school progress, degree, and GPA")
    async def education_status(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        character = await self.service.status(interaction.user.id)
        await interaction.followup.send(embed=_education_embed(character), ephemeral=True)

    @education.command(name="study", description="Study once this in-game year")
    @app_commands.describe(effort="Choose how much effort to put into studying")
    @app_commands.choices(effort=[
        app_commands.Choice(name="Hard — better GPA, more stress", value="hard"),
        app_commands.Choice(name="Normal — balanced progress", value="normal"),
        app_commands.Choice(name="Slack — relax, but risk GPA", value="slack"),
    ])
    async def study(self, interaction: discord.Interaction, effort: str = "normal") -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await self.service.study(interaction.user.id, effort)
        await interaction.followup.send(embed=_study_embed(result), ephemeral=True)

    async def major_autocomplete(
        self, interaction: discord.Interaction, current: str
    ) -> list[app_commands.Choice[str]]:
        """Suggest mapped study fields while still accepting a valid custom major."""
        loader = getattr(self.bot, "data_loader", None)
        if loader is None:
            return []
        catalog = loader.load_majors()
        query = current.casefold().strip()
        matches = [
            row for row in catalog.get("majors", [])
            if not query or query in str(row.get("id", "")).casefold() or query in str(row.get("name", "")).casefold()
        ]
        return [
            app_commands.Choice(name=str(row["name"])[:100], value=str(row["name"])[:100])
            for row in matches[:25]
        ]

    @education.command(name="enroll", description="Enroll in an eligible college degree program")
    @app_commands.describe(program="Degree program", major="Field of study; choose a mapped major or enter your own (2–40 characters)")
    @app_commands.autocomplete(major=major_autocomplete)
    @app_commands.choices(program=[
        app_commands.Choice(name="Bachelor's degree", value="bachelor"),
        app_commands.Choice(name="Master's degree", value="master"),
        app_commands.Choice(name="Doctorate", value="doctorate"),
    ])
    async def enroll(
        self,
        interaction: discord.Interaction,
        program: str,
        major: str,
    ) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        character = await self.service.enroll(interaction.user.id, program, major)
        embed = _education_embed(character)
        embed.description = f"Enrolled successfully. Your degree journey begins.\n\n{embed.description}"
        await interaction.followup.send(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(EducationCog(bot))
