"""Discord slash commands for crime, risk previews, trials, tax choices, and laundering."""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from core.crime import CrimeDefinition, CrimeRecord, CrimeService
from core.embeds import safe_text as escape_user_text
from core.money import format_cents
from cogs.crime_views import (
    CrimeConfirmationView,
    TaxChoiceView,
    TrialView,
    crime_preview_embed,
    tax_prompt_embed,
    trial_embed,
)


CRIME_CHOICES = [
    app_commands.Choice(name="Shoplift", value="shoplift"),
    app_commands.Choice(name="Pickpocket", value="pickpocket"),
    app_commands.Choice(name="Vandalism", value="vandalism"),
    app_commands.Choice(name="Car Break-in", value="car_break_in"),
    app_commands.Choice(name="Burglary", value="burglary"),
    app_commands.Choice(name="Grand Theft Auto", value="grand_theft_auto"),
    app_commands.Choice(name="Drug Dealing", value="drug_dealing"),
    app_commands.Choice(name="Fraud / Scam", value="fraud_scam"),
    app_commands.Choice(name="Embezzlement", value="embezzlement"),
    app_commands.Choice(name="Assault", value="assault"),
    app_commands.Choice(name="Armed Robbery", value="armed_robbery"),
    app_commands.Choice(name="Bank Heist", value="bank_heist"),
    app_commands.Choice(name="Murder", value="murder"),
    app_commands.Choice(name="Tax Evasion (event only)", value="tax_evasion"),
]


def _safe(value: str) -> str:
    """Escape Discord markdown and mention syntax in character or catalog text."""
    return escape_user_text(value)


def _crime_list_embed(crimes: tuple[CrimeDefinition, ...]) -> discord.Embed:
    """List validated crime definitions and age gates without real-world advice."""
    embed = discord.Embed(
        title="Fictional crime catalog",
        description="All outcomes are abstract game rolls. Crime flavor intentionally includes no real-world instructions.",
        color=discord.Color.dark_red(),
    )
    for crime in crimes:
        if crime.commit_enabled:
            risk = f"Base success {crime.base_success:.0f}% · base arrest {crime.base_catch:.0f}%"
            if crime.requires_job:
                risk += " · active job required"
            if crime.violence:
                risk += " · violent offense"
        else:
            risk = "Event-only; cannot be committed with this command."
        embed.add_field(
            name=f"{_safe(crime.name)} · age {crime.min_age}+",
            value=f"{_safe(crime.description)}\n{risk}",
            inline=False,
        )
    embed.set_footer(text="/crime commit previews current risk before an attempt · two attempts per in-game year")
    return embed


def _record_embed(record: CrimeRecord) -> discord.Embed:
    """Render the player-owned criminal record and recent case history."""
    character = record.character
    embed = discord.Embed(
        title=f"Crime record · {_safe(character.name)}",
        description=(
            f"**Criminal record:** {character.criminal_record}\n"
            f"**Notoriety:** {character.notoriety}/100\n"
            f"**Criminal career:** {_safe(record.career_rank or 'Not established')}"
            f" · {record.career_years} paid year(s)\n"
            f"**Unlaundered proceeds:** {format_cents(record.dirty_cash)}\n"
            f"**Tax exposed to audit:** {format_cents(record.evaded_tax)}"
        ),
        color=discord.Color.dark_red(),
    )
    if record.attempts:
        for attempt in record.attempts[:8]:
            status = str(attempt["case_status"]).replace("_", " ").title()
            crime_name = str(attempt["crime_id"]).replace("_", " ").title()
            result = "caught" if bool(attempt["caught"]) else ("success" if bool(attempt["success"]) else "failed")
            value = f"Age {int(attempt['age'])} · {result} · {status} · {format_cents(int(attempt['loot']))} proceeds"
            if int(attempt["sentence_years"]):
                value += f" · sentence {int(attempt['sentence_years'])} year(s)"
            embed.add_field(name=_safe(crime_name), value=value, inline=False)
    else:
        embed.add_field(name="History", value="No recorded attempts yet.", inline=False)
    if record.trial is not None:
        embed.add_field(name="Pending decision", value="A court case is waiting for a lawyer choice below.", inline=False)
    elif record.tax_prompt is not None:
        embed.add_field(name="Pending decision", value="A tax choice is waiting below.", inline=False)
    elif record.preview is not None:
        embed.add_field(name="Pending decision", value="A crime risk preview is ready to confirm or cancel below.", inline=False)
    embed.set_footer(text="A criminal record lowers future job-offer odds; the post-release penalty fades over time.")
    return embed


class CrimeCog(commands.Cog):
    """Owner-safe player commands for Stage 7 crime and court rules."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        service = getattr(bot, "crime_service", None)
        if service is None:
            service = CrimeService(bot.db, bot.rng, getattr(bot, "locks", None))
        self.service: CrimeService = service
        self.achievement_service = getattr(bot, "achievement_service", None)

    crime = app_commands.Group(name="crime", description="View abstract crime risks and court outcomes")

    @crime.command(name="list", description="Browse fictional crime options and age gates")
    @app_commands.checks.cooldown(1, 8.0, key=lambda interaction: interaction.user.id)
    async def list_crimes(self, interaction: discord.Interaction) -> None:
        crimes = await self.service.list_crimes(interaction.user.id)
        await interaction.response.send_message(embed=_crime_list_embed(crimes), ephemeral=True)

    @crime.command(name="commit", description="Preview risk and choose whether to attempt a fictional crime")
    @app_commands.describe(crime_id="The fictional offense to preview")
    @app_commands.choices(crime_id=CRIME_CHOICES)
    @app_commands.checks.cooldown(1, 10.0, key=lambda interaction: interaction.user.id)
    async def commit(self, interaction: discord.Interaction, crime_id: str) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        preview = await self.service.preview_crime(interaction.user.id, crime_id)
        view = CrimeConfirmationView(interaction.user.id, preview, self.service, self.achievement_service)
        message = await interaction.followup.send(
            embed=crime_preview_embed(preview), view=view, ephemeral=True, wait=True
        )
        view.bind_message(message)

    @crime.command(name="launder", description="Move available dirty cash to your bank after a 25% fee")
    @app_commands.describe(amount="Whole-dollar amount of dirty cash to launder")
    @app_commands.checks.cooldown(1, 10.0, key=lambda interaction: interaction.user.id)
    async def launder(self, interaction: discord.Interaction, amount: app_commands.Range[int, 1, 1_000_000_000]) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await self.service.launder(interaction.user.id, amount)
        cap_message = (
            "Front-business access removes the ordinary annual cap."
            if result.annual_limit == 0
            else f"Annual cap without a front business: {format_cents(result.annual_limit)} gross."
        )
        embed = discord.Embed(
            title="Laundering complete",
            description=(
                f"Gross removed from dirty cash: **{format_cents(result.gross_amount)}**\n"
                f"Fee (25%): **{format_cents(result.fee_amount)}**\n"
                f"Added to bank: **{format_cents(result.net_amount)}**\n\n{cap_message}"
            ),
            color=discord.Color.gold(),
        )
        await interaction.followup.send(embed=embed, ephemeral=True)

    @crime.command(name="record", description="View your criminal record and resume a pending decision")
    @app_commands.checks.cooldown(1, 8.0, key=lambda interaction: interaction.user.id)
    async def record(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        record = await self.service.crime_record(interaction.user.id)
        view: discord.ui.View | None = None
        embed = _record_embed(record)
        if record.trial is not None:
            view = TrialView(interaction.user.id, record.trial, self.service, self.achievement_service)
            embed = trial_embed(record.trial)
            embed.add_field(
                name="Record summary",
                value=(
                    f"Criminal record: {record.character.criminal_record} · "
                    f"Notoriety: {record.character.notoriety}/100 · Dirty cash: {format_cents(record.dirty_cash)}"
                ),
                inline=False,
            )
        elif record.tax_prompt is not None:
            view = TaxChoiceView(interaction.user.id, record.tax_prompt, self.service, self.achievement_service)
            embed = tax_prompt_embed(record.tax_prompt)
        elif record.preview is not None:
            view = CrimeConfirmationView(interaction.user.id, record.preview, self.service, self.achievement_service)
            embed = crime_preview_embed(record.preview)
        message = await interaction.followup.send(embed=embed, view=view, ephemeral=True, wait=True)
        if view is not None and hasattr(view, "bind_message"):
            view.bind_message(message)


async def setup(bot: commands.Bot) -> None:
    """Register the crime slash-command cog."""
    await bot.add_cog(CrimeCog(bot))
