"""Dynamic categorized slash-command help with nonce-rotated private pagination."""
from __future__ import annotations

import secrets
import logging
from typing import Any, Iterable

import discord
from discord import app_commands
from discord.ext import commands

from core.embeds import EmbedColors

logger = logging.getLogger("lifeline.cogs.help")

CATEGORIES: tuple[str, ...] = (
    "Life", "Education", "Career", "Finance", "Health", "Relationships",
    "Crime", "Shop and Inventory", "Trade", "Casino", "Invest", "Social", "Settings",
)
_CATEGORY_ROOTS: dict[str, set[str]] = {
    "Life": {"life", "start"},
    "Education": {"education"},
    "Career": {"career"},
    "Finance": {"leaderboard", "achievements", "lives", "graveyard", "inheritance", "retire_life",
                "bank", "loan", "finance", "economy"},
    "Health": {"life", "health"},
    "Relationships": {"family", "relationship", "date", "friends"},
    "Crime": {"crime", "prison"},
    "Shop and Inventory": {"shop", "inventory"},
    "Trade": {"trade"},
    "Casino": {"casino"},
    "Invest": {"invest", "stocks", "bonds"},
    "Social": {"coinflip", "roll", "bet", "8ball", "trivia", "rps", "slots", "random", "choose", "ship", "fact", "poll", "hug", "roast"},
    "Settings": {"settings", "admin", "help", "leaderboard_privacy", "guild_death_summaries"},
}
_TUTORIAL = (
    "**Quick tutorial**\n"
    "1. Start with `/life start` and choose a character name, gender, and country.\n"
    "2. Use `/life status` to review your character, then `/life age` to advance exactly one in-game year.\n"
    "3. If a choice event appears, select an option or reopen it later with `/life choice`; unresolved decisions block another year.\n"
    "**Common traps:** stats are bounded; money is fictional cents; annual bills, medical care, loans, taxes, and investing can reduce wealth; activity and preventive care can help; casino games have negative expected value and no cash-out; risky crime choices can lead to fines or custody."
)


def _flatten_commands(commands_list: Iterable[Any]) -> list[app_commands.Command[Any, ..., Any]]:
    """Flatten application groups so every callable slash command can be documented."""
    found: list[app_commands.Command[Any, ..., Any]] = []
    for command in commands_list:
        children = getattr(command, "commands", None)
        if children:
            found.extend(_flatten_commands(children))
        elif isinstance(command, app_commands.Command):
            found.append(command)
    return found


def _category_for(command: app_commands.Command[Any, ..., Any]) -> str:
    """Choose the first matching help category, with a safe Social fallback."""
    root = str(command.qualified_name).split(" ", 1)[0]
    for category in CATEGORIES:
        if root in _CATEGORY_ROOTS[category]:
            return category
    return "Social"


def _command_entry(command: app_commands.Command[Any, ..., Any]) -> str:
    """Document exact slash syntax, every option, and its registered description."""
    syntax = f"/{command.qualified_name}"
    parameters = list(command.parameters)
    for parameter in parameters:
        token = f"<{parameter.name}>" if parameter.required else f"[{parameter.name}]"
        syntax += f" {token}"
    description = discord.utils.escape_markdown(str(command.description or "No description provided."))
    lines = [f"**`{syntax}`** — {description}"]
    for parameter in parameters:
        detail = discord.utils.escape_markdown(str(parameter.description or "Option"))
        lines.append(f"• `{parameter.name}`: {detail}")
    return "\n".join(lines)


def build_help_pages(bot: commands.Bot) -> dict[str, list[list[str]]]:
    """Build categories from the registered command tree instead of a stale manual list."""
    entries: dict[str, list[str]] = {category: [] for category in CATEGORIES}
    registered = _flatten_commands(bot.tree.get_commands())
    for command in sorted(registered, key=lambda item: item.qualified_name):
        category = _category_for(command)
        entry = _command_entry(command)
        if entry not in entries[category]:
            entries[category].append(entry)
        # /life status is also relevant to the Health overview, without removing it from Life.
        if category == "Life" and command.qualified_name == "life status":
            entries["Health"].append(entry)
    result: dict[str, list[list[str]]] = {}
    for category, category_entries in entries.items():
        groups = [category_entries[start:start + 4] for start in range(0, len(category_entries), 4)]
        result[category] = groups or [[]]
    return result


class HelpView(discord.ui.View):
    """Owner-bound help pagination; each select/button is disabled and nonce-rotated after use."""

    def __init__(
        self,
        owner_id: int,
        pages: dict[str, list[list[str]]],
        *,
        category: str = "Life",
        page: int = 0,
        timeout: float = 180.0,
    ) -> None:
        super().__init__(timeout=timeout)
        self.owner_id = int(owner_id)
        self.pages = pages
        self.category = category if category in CATEGORIES else "Life"
        self.page = max(0, min(int(page), len(self.pages[self.category]) - 1))
        self.nonce = secrets.token_urlsafe(8)
        self.message: discord.Message | None = None
        self.add_item(_HelpCategorySelect(self))
        previous = discord.ui.Button(
            label="Previous", style=discord.ButtonStyle.secondary,
            custom_id=f"help:{self.nonce}:previous", disabled=self.page <= 0,
        )
        next_button = discord.ui.Button(
            label="Next", style=discord.ButtonStyle.primary,
            custom_id=f"help:{self.nonce}:next",
            disabled=self.page >= len(self.pages[self.category]) - 1,
        )
        previous.callback = self._previous  # type: ignore[method-assign]
        next_button.callback = self._next  # type: ignore[method-assign]
        self.add_item(previous)
        self.add_item(next_button)

    def bind_message(self, message: discord.Message) -> None:
        """Bind the private response so timeout can disable its controls."""
        self.message = message

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        """Validate owner, view nonce, and command/category server state."""
        if int(interaction.user.id) != self.owner_id:
            await interaction.response.send_message("Only the player who opened this help page can navigate it.", ephemeral=True)
            return False
        custom_id = str((interaction.data or {}).get("custom_id", ""))
        if not custom_id.startswith(f"help:{self.nonce}:"):
            await interaction.response.send_message("This help control is stale. Run `/help` again.", ephemeral=True)
            return False
        return True

    async def _previous(self, interaction: discord.Interaction) -> None:
        await self._move(interaction, -1)

    async def _next(self, interaction: discord.Interaction) -> None:
        await self._move(interaction, 1)

    async def _move(self, interaction: discord.Interaction, delta: int) -> None:
        if not await self.interaction_check(interaction):
            return
        candidate = self.page + int(delta)
        if not 0 <= candidate < len(self.pages[self.category]):
            await interaction.response.send_message("That help page is outside the available range.", ephemeral=True)
            return
        await self._replace(interaction, self.category, candidate)

    async def select_category(self, interaction: discord.Interaction, value: str) -> None:
        """Validate the category against the fixed help list and rotate the view nonce."""
        if not await self.interaction_check(interaction):
            return
        if value not in CATEGORIES or value not in self.pages:
            await interaction.response.send_message("Choose one of the listed help categories.", ephemeral=True)
            return
        await self._replace(interaction, value, 0)

    async def _replace(self, interaction: discord.Interaction, category: str, page: int) -> None:
        """Disable the consumed view and replace it with fresh nonce-protected controls."""
        for child in self.children:
            if hasattr(child, "disabled"):
                child.disabled = True
        self.stop()
        replacement = HelpView(self.owner_id, self.pages, category=category, page=page)
        await interaction.response.edit_message(embed=replacement.make_embed(), view=replacement)
        replacement.bind_message(interaction.message)

    def make_embed(self) -> discord.Embed:
        """Render the current page with a tutorial on the first Life page."""
        content = self.pages[self.category][self.page]
        description = "\n\n".join(content) if content else "No commands are registered in this category yet."
        if self.category == "Life" and self.page == 0:
            description = f"{_TUTORIAL}\n\n{description}"
        embed = discord.Embed(
            title=f"LIFELINE Help · {self.category}",
            description=description[:3900],
            color=EmbedColors.HELP,
        )
        embed.set_footer(
            text=f"Page {self.page + 1} of {len(self.pages[self.category])} · Select a category to browse"
        )
        return embed

    async def on_timeout(self) -> None:
        """Disable controls after the private help session expires."""
        for child in self.children:
            if hasattr(child, "disabled"):
                child.disabled = True
        if self.message is not None:
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Help view message was unavailable at timeout", exc_info=True)


class _HelpCategorySelect(discord.ui.Select[HelpView]):
    """Fixed menu listing all user-requested help categories."""

    def __init__(self, view: HelpView) -> None:
        options = [
            discord.SelectOption(label=category, value=category, default=category == view.category)
            for category in CATEGORIES
        ]
        super().__init__(
            placeholder="Choose a help category",
            min_values=1,
            max_values=1,
            options=options,
            custom_id=f"help:{view.nonce}:category",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        if self.view is not None:
            await self.view.select_category(interaction, self.values[0])


class HelpCog(commands.Cog):
    """Offer live, tree-derived command syntax instead of a duplicated help registry."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @app_commands.command(name="help", description="Browse categorized LIFELINE commands and quick-start tips")
    @app_commands.describe(category="Optional starting category; use the menu to browse")
    @app_commands.choices(category=[app_commands.Choice(name=name, value=name) for name in CATEGORIES])
    async def help(
        self,
        interaction: discord.Interaction,
        category: str | None = None,
    ) -> None:
        """Show current registered commands, syntax, option descriptions, and tutorial tips."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        pages = build_help_pages(self.bot)
        selected = category if category in CATEGORIES else "Life"
        view = HelpView(int(interaction.user.id), pages, category=selected)
        message = await interaction.followup.send(
            embed=view.make_embed(),
            view=view,
            ephemeral=True,
            wait=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        view.bind_message(message)


async def setup(bot: commands.Bot) -> None:
    """Register `/help` after the rest of the command tree has been loaded."""
    await bot.add_cog(HelpCog(bot))
