"""Slash commands for starting and advancing a LIFELINE character."""
from __future__ import annotations

import logging
import discord
from discord import app_commands
from discord.ext import commands

from core.events import EventPrompt
from core.embeds import EmbedColors, apply_life_footer, life_embed, safe_text
from core.repositories.settings import PlayerSettings, SettingsRepository
from core.life_engine import LifeEngine, YearOutcome
from core.models import Character
from core.money import format_cents
from core.views import EventChoiceView, event_embed
from cogs.casino import CompulsionView
from cogs.crime_views import TaxChoiceView, TrialView, tax_prompt_embed, trial_embed
from cogs.legacy_views import HeirSelectView, death_summary_embed

logger = logging.getLogger("lifeline.cogs.life")


STAT_ORDER = (
    ("health", "❤️ Health"),
    ("happiness", "😊 Happiness"),
    ("smarts", "🧠 Smarts"),
    ("looks", "✨ Looks"),
    ("fitness", "💪 Fitness"),
    ("karma", "🍀 Karma"),
)


def _stat_bar(value: int) -> str:
    filled = max(0, min(10, round(value / 10)))
    return f"{'🟩' * filled}{'⬛' * (10 - filled)} **{value}/100**"


def _character_embed(character: Character) -> discord.Embed:
    status = "Alive" if character.is_alive else f"Deceased at age {character.death_age}"
    embed = discord.Embed(
        title=f"{safe_text(character.name, 80)} · Age {character.age}",
        description=(
            f"**Life stage:** {character.life_stage.value.replace('_', ' ').title()}\n"
            f"**Status:** {status}\n"
            f"**Background:** {character.wealth_class.title()} household · {safe_text(character.country.upper(), 60)}"
        ),
        color=EmbedColors.LIFE if character.is_alive else EmbedColors.PRIVATE,
    )
    embed.add_field(
        name="Core stats",
        value="\n".join(f"{label}  {_stat_bar(getattr(character.stats, key))}" for key, label in STAT_ORDER),
        inline=False,
    )
    education = character.education_level.value.replace("_", " ").title()
    if character.current_school:
        education += f" · {character.current_school} ({character.school_years_left} year(s) left)"
    embed.add_field(name="Education", value=education, inline=False)
    if character.generation > 1:
        embed.add_field(name="Generation", value=str(character.generation), inline=True)
    apply_life_footer(embed, character.age, character.life_stage, character.char_id)
    return embed


def _outcome_description(outcome: YearOutcome) -> str:
    """Render year logs while escaping the character name embedded in generated text."""
    raw_name = outcome.character.name
    escaped_name = safe_text(raw_name, 80)
    parts = [message.replace(raw_name, escaped_name) if raw_name else message for message in outcome.log_messages]
    if outcome.stat_changes:
        changes = []
        label_map = dict(STAT_ORDER)
        for key, delta in outcome.stat_changes.items():
            label = label_map.get(key, key.replace("_", " ").title())
            changes.append(f"{label} {'+' if delta > 0 else ''}{delta}")
        parts.append("**Stat changes:** " + " · ".join(changes))
    if outcome.died:
        parts.append("Start a new life with `/life start` when you're ready.")
    return "\n".join(parts)


class LifeCog(commands.Cog):
    """Birth, status, and age-advance commands."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.engine = LifeEngine(
            bot.db,
            bot.rng,
            getattr(bot, "locks", None),
            family_service=getattr(bot, "family_service", None),
            crime_service=getattr(bot, "crime_service", None),
            shop_service=getattr(bot, "shop_service", None),
            casino_service=getattr(bot, "casino_service", None),
            investing_service=getattr(bot, "investing_service", None),
            economy_service=getattr(bot, "economy_service", None),
            achievement_service=getattr(bot, "achievement_service", None),
            data_loader=getattr(bot, "data_loader", None),
        )
        bot.life_engine = self.engine
        bot.health_service = self.engine.health

    life = app_commands.Group(name="life", description="Create and guide your life simulation")

    async def country_autocomplete(
        self, interaction: discord.Interaction, current: str
    ) -> list[app_commands.Choice[str]]:
        """Suggest country identifiers from the validated generation catalog."""
        loader = getattr(self.bot, "data_loader", None)
        catalog = loader.load_countries() if loader is not None else self.engine.data_loader.load_countries()
        query = current.casefold().strip()
        matches = [
            row for row in catalog.get("countries", [])
            if not query or query in str(row.get("id", "")).casefold() or query in str(row.get("name", "")).casefold()
        ]
        return [
            app_commands.Choice(name=f"{row['name']} ({row['id']})"[:100], value=str(row["id"]))
            for row in matches[:25]
        ]

    async def name_autocomplete(
        self, interaction: discord.Interaction, current: str
    ) -> list[app_commands.Choice[str]]:
        """Suggest sample regional names without limiting free-form character names."""
        loader = getattr(self.bot, "data_loader", None)
        catalog = loader.load_names() if loader is not None else self.engine.data_loader.load_names()
        suggestions: list[str] = []
        for pool in catalog.get("defaults", {}).values():
            suggestions.extend(str(name) for name in pool)
        for country in catalog.get("countries", {}).values():
            if isinstance(country, dict):
                for pool in country.values():
                    if isinstance(pool, list):
                        suggestions.extend(str(name) for name in pool)
        query = current.casefold().strip()
        unique = sorted({name for name in suggestions if not query or query in name.casefold()})
        return [app_commands.Choice(name=name[:100], value=name) for name in unique[:25]]

    @life.command(name="start", description="Begin a new life at birth")
    @app_commands.describe(
        name="Your character's name",
        gender="Character gender",
        country="Country or region code, such as usa or in",
    )
    @app_commands.autocomplete(name=name_autocomplete, country=country_autocomplete)
    @app_commands.choices(gender=[
        app_commands.Choice(name="Male", value="male"),
        app_commands.Choice(name="Female", value="female"),
        app_commands.Choice(name="Non-binary", value="non_binary"),
    ])
    async def start_life(
        self,
        interaction: discord.Interaction,
        name: str,
        gender: str = "male",
        country: str = "usa",
    ) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        character = await self.engine.create_character(
            interaction.user.id,
            name,
            gender=gender,
            country=country,
        )
        embed = _character_embed(character)
        embed.description = (
            "A new story begins. Your choices will shape the life ahead.\n\n"
            + (embed.description or "")
        )
        await interaction.followup.send(embed=embed, ephemeral=True)

    @life.command(name="status", description="View your current life and stats")
    async def life_status(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        character = await self.engine.get_active_character(interaction.user.id)
        await interaction.followup.send(embed=_character_embed(character), ephemeral=True)

    @life.command(name="age", description="Advance your life by one year")
    @app_commands.checks.cooldown(1, 8.0, key=lambda interaction: interaction.user.id)
    async def age_up(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        settings = await self._get_user_settings(int(interaction.user.id))
        outcome = await self.engine.age_up(interaction.user.id, guild_id=interaction.guild_id)
        if outcome.died and outcome.death_summary is not None:
            achievement_names = {
                str(row["id"]): str(row["name"]) for row in self.engine.achievements.definitions
            }
            avatar_url = getattr(getattr(interaction.user, "display_avatar", None), "url", None)
            embed = death_summary_embed(
                outcome.death_summary,
                avatar_url=avatar_url,
                achievement_names=achievement_names,
            )
            if outcome.death_public_summary and interaction.channel is not None:
                try:
                    await interaction.channel.send(
                        embed=embed,
                        allowed_mentions=discord.AllowedMentions.none(),
                    )
                    await interaction.followup.send("The death summary was posted in this channel.", ephemeral=True)
                except discord.HTTPException:
                    await interaction.followup.send(
                        embed=embed, ephemeral=True,
                        allowed_mentions=discord.AllowedMentions.none(),
                    )
            else:
                await interaction.followup.send(
                    embed=embed, ephemeral=True,
                    allowed_mentions=discord.AllowedMentions.none(),
                )
            if outcome.death_estate_id is not None and outcome.death_estate_nonce is not None and outcome.death_heirs:
                view = HeirSelectView(
                    interaction.user.id,
                    outcome.death_estate_id,
                    outcome.death_estate_nonce,
                    outcome.death_heirs,
                    self.engine.death,
                )
                prompt = discord.Embed(
                    title="Continue the family line?",
                    description=(
                        "Choose one of your living adult children. The after-tax estate is split across "
                        "all eligible adult children; your heir begins at their current age with their own stats. "
                        "You can also close the estate and start fresh."
                    ),
                    color=discord.Color.gold(),
                )
                message = await interaction.followup.send(
                    embed=prompt, view=view, ephemeral=True, wait=True,
                    allowed_mentions=discord.AllowedMentions.none(),
                )
                view.bind_message(message)
            return
        if outcome.pending_event is not None:
            prompt: EventPrompt = outcome.pending_event
            view = EventChoiceView(
                interaction.user.id, prompt, self.engine.events,
                achievement_service=self.engine.achievements,
            )
            message = await interaction.followup.send(
                embed=event_embed(prompt, lead=_outcome_description(outcome)),
                view=view,
                ephemeral=True,
                wait=True,
            )
            view.bind_message(message)
            await self._post_public_year_summary(interaction, outcome, settings, waiting_for_choice=True)
            return

        if outcome.pending_trial is not None:
            view = TrialView(
                interaction.user.id, outcome.pending_trial, self.engine.crimes,
                self.engine.achievements,
            )
            embed = trial_embed(outcome.pending_trial)
            embed.description = f"{_outcome_description(outcome)}\n\n{embed.description or ''}"
            message = await interaction.followup.send(embed=embed, view=view, ephemeral=True, wait=True)
            view.bind_message(message)
            await self._post_public_year_summary(interaction, outcome, settings, waiting_for_choice=True)
            return

        if outcome.pending_tax is not None:
            view = TaxChoiceView(
                interaction.user.id, outcome.pending_tax, self.engine.crimes,
                self.engine.achievements,
            )
            embed = tax_prompt_embed(outcome.pending_tax)
            embed.description = f"{_outcome_description(outcome)}\n\n{embed.description or ''}"
            message = await interaction.followup.send(embed=embed, view=view, ephemeral=True, wait=True)
            view.bind_message(message)
            await self._post_public_year_summary(interaction, outcome, settings, waiting_for_choice=True)
            return

        if outcome.pending_compulsion is not None:
            prompt = outcome.pending_compulsion
            view = CompulsionView(
                interaction.user.id, self.engine.casino, prompt, self.engine.achievements
            )
            amount = int(prompt["forced_bet_cents"])
            embed = discord.Embed(
                title="Gambling compulsion",
                description=(
                    f"{_outcome_description(outcome)}\n\n"
                    f"Your character is experiencing a gambling compulsion. Resist, or indulge in a forced wager of {format_cents(amount)}."
                ),
                color=discord.Color.orange(),
            )
            message = await interaction.followup.send(embed=embed, view=view, ephemeral=True, wait=True)
            view.bind_message(message)
            await self._post_public_year_summary(interaction, outcome, settings, waiting_for_choice=True)
            return

        embed = _character_embed(outcome.character)
        embed.description = _outcome_description(outcome)
        if outcome.died:
            embed.color = discord.Color.dark_grey()
        elif outcome.new_stage != outcome.previous_stage:
            embed.color = discord.Color.gold()
        await interaction.followup.send(embed=embed, ephemeral=True)
        await self._post_public_year_summary(interaction, outcome, settings, waiting_for_choice=False)

    async def _get_user_settings(self, user_id: int) -> PlayerSettings:
        """Read a player's privacy settings without exposing them in another profile."""
        async with self.engine.locks.hold(user_id):
            async with self.engine.db.transaction() as tx:
                return await SettingsRepository(self.engine.db).get(tx, user_id)

    async def _post_public_year_summary(
        self,
        interaction: discord.Interaction,
        outcome: YearOutcome,
        settings: PlayerSettings,
        *,
        waiting_for_choice: bool,
    ) -> None:
        """Post only a short, non-financial year recap when the player allows it."""
        if not getattr(settings, "public_year_summaries", False):
            return
        if interaction.guild_id is None or interaction.channel is None or outcome.died:
            return
        name = safe_text(outcome.character.name)
        detail = (
            "A new year began; an interactive choice is waiting in a private message."
            if waiting_for_choice else "A new year began in this life."
        )
        embed = life_embed(
            title="Life year summary",
            description=f"**{name}** reached age {outcome.new_age}. {detail}",
            age=outcome.new_age,
            stage=outcome.new_stage,
            life_id=outcome.character.char_id,
            color=EmbedColors.NEUTRAL,
        )
        try:
            await interaction.channel.send(
                embed=embed,
                allowed_mentions=discord.AllowedMentions.none(),
            )
        except discord.HTTPException:
            logger.info("Public year summary could not be posted for user %s", interaction.user.id, exc_info=True)

    @life.command(name="choice", description="Reopen your unresolved life-event choice")
    async def resume_choice(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        prompt = await self.engine.events.get_pending_event(interaction.user.id)
        view = EventChoiceView(
            interaction.user.id, prompt, self.engine.events,
            achievement_service=self.engine.achievements,
        )
        message = await interaction.followup.send(
            embed=event_embed(prompt, lead="Your unresolved life event is saved."),
            view=view,
            ephemeral=True,
            wait=True,
        )
        view.bind_message(message)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(LifeCog(bot))
