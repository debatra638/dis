"""Stage 9 /invest commands and a resilient ten-minute global market ticker."""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands, tasks

from core.embeds import safe_text as escape_user_text
from core.investing import InvestingService, StockQuote
from core.money import dollars_to_cents, format_cents
from cogs.legacy_views import check_and_notify_achievements

logger = logging.getLogger("lifeline.investing.cog")


async def stock_autocomplete(
    interaction: discord.Interaction,
    current: str,
) -> list[app_commands.Choice[str]]:
    """Suggest fictional ticker symbols and company names from the validated catalog."""
    service = getattr(interaction.client, "investing_service", None)
    if service is None:
        return []
    return [
        app_commands.Choice(name=f"{symbol} · {name}", value=symbol)
        for symbol, name in service.symbol_options(current)
    ][:25]


def _market_description(rows: list[StockQuote]) -> str:
    """Render the market's change and sparkline as compact plain text."""
    if not rows:
        return "No stocks are currently listed."
    lines: list[str] = []
    for row in rows:
        name = escape_user_text(row.name, 55)
        if row.delisted:
            lines.append(f"`{row.symbol:<6}` **{name}** · DELISTED · {row.sparkline}")
        else:
            sign = "+" if row.change_cents > 0 else ""
            lines.append(
                f"`{row.symbol:<6}` **{name}** · {format_cents(row.price_cents)} "
                f"({sign}{row.change_percent:.2f}% / {format_cents(row.change_cents)}) · `{row.sparkline}`"
            )
    return "\n".join(lines)


class InvestingCog(commands.Cog):
    """Investment commands plus a transactional, idempotent global ticker loop."""

    invest = app_commands.Group(name="invest", description="Trade stocks, review a portfolio, or buy bonds")
    bonds = app_commands.Group(name="bonds", description="Buy five-year fixed-return savings bonds", parent=invest)

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        service = getattr(bot, "investing_service", None)
        if service is None:
            service = InvestingService(bot.db, bot.rng, getattr(bot, "locks", None))
            bot.investing_service = service
        self.service: InvestingService = service
        self.achievement_service = getattr(bot, "achievement_service", None)

    async def cog_load(self) -> None:
        """Ensure market seed state and start the ten-minute tick task."""
        await self.service.initialize_market()
        if not self.market_tick.is_running():
            self.market_tick.start()

    def cog_unload(self) -> None:
        """Cancel the market task when its extension is unloaded."""
        self.market_tick.cancel()

    @tasks.loop(minutes=10.0)
    async def market_tick(self) -> None:
        """Run a global tick; catch/log transactional failures so the loop survives."""
        try:
            result = await self.service.tick_global()
            if result.ticks:
                logger.info(
                    "Market advanced %s tick(s) through tick %s; events=%s",
                    result.ticks, result.last_tick_no, result.events or "none",
                )
        except Exception:
            logger.exception("Global stock ticker transaction failed; database changes rolled back; retrying next cycle")

    @market_tick.before_loop
    async def before_market_tick(self) -> None:
        """Wait until Discord startup is complete before the first market tick."""
        await self.bot.wait_until_ready()

    @market_tick.error
    async def market_tick_error(self, error: Exception) -> None:
        """Log unexpected loop-level errors and restart a stopped ticker after a short delay."""
        logger.error("Global stock ticker stopped unexpectedly", exc_info=(type(error), error, error.__traceback__))
        asyncio.create_task(self._restart_market_tick())

    async def _restart_market_tick(self) -> None:
        """Restart the market loop after the current task has fully unwound."""
        await asyncio.sleep(2.0)
        if not self.market_tick.is_running():
            try:
                self.market_tick.start()
                logger.warning("Global stock ticker restarted")
            except RuntimeError:
                logger.exception("Could not restart the stock ticker")

    @invest.command(name="market", description="View fictional tickers, 24-hour changes, and sparklines")
    @app_commands.checks.cooldown(1, 2.0, key=lambda interaction: interaction.user.id)
    async def market(self, interaction: discord.Interaction) -> None:
        """Show the current market snapshot and each company's 24-hour movement."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        rows = await self.service.market(interaction.user.id)
        embed = discord.Embed(
            title="Global Stock Market",
            description=_market_description(rows),
            color=discord.Color.blurple(),
        )
        embed.set_footer(text="Fictional market · prices update globally every 10 minutes · not real financial advice")
        await interaction.followup.send(embed=embed, ephemeral=True)

    @invest.command(name="buy", description="Buy whole shares from your bank at the current price")
    @app_commands.describe(
        symbol="Ticker to buy; use autocomplete",
        amount="Number of whole shares to buy (bank balance only; 0.5% fee, $1 minimum)",
    )
    @app_commands.autocomplete(symbol=stock_autocomplete)
    @app_commands.checks.cooldown(1, 1.0, key=lambda interaction: interaction.user.id)
    async def buy(self, interaction: discord.Interaction, symbol: str, amount: app_commands.Range[int, 1, 1_000_000_000]) -> None:
        """Buy shares at the transaction-time market price with anti-churn checks."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        receipt = await self.service.buy(interaction.user.id, symbol, int(amount))
        await interaction.followup.send(receipt.message, ephemeral=True)
        await check_and_notify_achievements(
            interaction, self.achievement_service, interaction.user.id
        )

    @invest.command(name="sell", description="Sell whole shares or your entire position")
    @app_commands.describe(
        symbol="Ticker to sell; use autocomplete",
        shares="Positive whole share count or `all`",
    )
    @app_commands.autocomplete(symbol=stock_autocomplete)
    @app_commands.checks.cooldown(1, 1.0, key=lambda interaction: interaction.user.id)
    async def sell(self, interaction: discord.Interaction, symbol: str, shares: str) -> None:
        """Sell shares at the transaction-time market price and record realized gains."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        receipt = await self.service.sell(interaction.user.id, symbol, shares)
        await interaction.followup.send(receipt.message, ephemeral=True)
        await check_and_notify_achievements(
            interaction, self.achievement_service, interaction.user.id
        )

    @invest.command(name="portfolio", description="View stock holdings, cost basis, bonds, and value")
    @app_commands.checks.cooldown(1, 2.0, key=lambda interaction: interaction.user.id)
    async def portfolio(self, interaction: discord.Interaction) -> None:
        """Display fee-inclusive cost basis, unrealized gains, and locked bonds."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        holdings, bonds, bank = await self.service.portfolio(interaction.user.id)
        embed = discord.Embed(title="Investment Portfolio", color=discord.Color.green())
        embed.description = f"Bank balance: {format_cents(bank)}"
        if holdings:
            lines = []
            for row in holdings:
                symbol = str(row["symbol"])
                company = escape_user_text(row["company_name"] or symbol, 55)
                worthless = bool(row["is_delisted"])
                market_value = int(row["market_value_cents"])
                gain = int(row["unrealized_gain_cents"])
                flag = " · DELISTED / worthless" if worthless else ""
                lines.append(
                    f"**{symbol}** · {company} · {int(row['shares']):,} share(s) · "
                    f"basis {format_cents(int(row['cost_basis_cents']))} · value {format_cents(market_value)} · "
                    f"P/L {format_cents(gain, include_plus=True)}{flag}"
                )
            embed.add_field(name="Stocks", value="\n".join(lines[:25]), inline=False)
        else:
            embed.add_field(name="Stocks", value="No stock holdings yet.", inline=False)
        if bonds:
            bond_lines = [
                f"Bond #{row['bond_id']} · balance {format_cents(int(row['balance_cents']))} · "
                f"matures age {row['maturity_age']} · 3.5% fixed"
                for row in bonds[:20]
            ]
            embed.add_field(name="Locked bonds", value="\n".join(bond_lines), inline=False)
        else:
            embed.add_field(name="Locked bonds", value="No active bonds.", inline=False)
        await interaction.followup.send(embed=embed, ephemeral=True)

    @invest.command(name="history", description="View a ticker's recent prices and your executions")
    @app_commands.describe(symbol="Ticker to review; use autocomplete")
    @app_commands.autocomplete(symbol=stock_autocomplete)
    @app_commands.checks.cooldown(1, 2.0, key=lambda interaction: interaction.user.id)
    async def history(self, interaction: discord.Interaction, symbol: str) -> None:
        """Display recent prices, event markers, and the player's stock trades."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        stock, history, trades = await self.service.trade_history(interaction.user.id, symbol)
        lines = [
            f"`{datetime.fromtimestamp(int(row['recorded_at']), tz=timezone.utc).strftime('%b %d %H:%M UTC')}` · "
            f"{format_cents(int(row['price_cents']))} · {row['event_type']}"
            for row in history[-15:]
        ]
        if trades:
            lines.append("\n**Your executions**")
            lines.extend(
                f"{str(row['side']).upper()} {int(row['shares'])} @ {format_cents(int(row['price_cents']))} · "
                f"fee {format_cents(int(row['fee_cents']))} · realized {format_cents(int(row['realized_gain_cents']), include_plus=True)}"
                for row in trades
            )
        embed = discord.Embed(
            title=f"{str(stock['symbol'])} · {discord.utils.escape_markdown(str(stock['company_name']))}",
            description="\n".join(lines) if lines else "No price ticks recorded yet.",
            color=discord.Color.blurple(),
        )
        status = "DELISTED / worthless" if bool(stock["is_delisted"]) else f"Current: {format_cents(int(stock['price_cents']))}"
        embed.set_footer(text=f"{stock['sector'].title()} · {status} · oldest rows trimmed after 500 ticks")
        await interaction.followup.send(embed=embed, ephemeral=True)

    @bonds.command(name="buy", description="Buy a five-year locked bond earning 3.5% fixed annually")
    @app_commands.describe(amount="Principal in dollars; paid from your bank balance only")
    @app_commands.checks.cooldown(1, 2.0, key=lambda interaction: interaction.user.id)
    async def buy_bond(self, interaction: discord.Interaction, amount: float) -> None:
        """Buy a five-character-year savings bond."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        receipt = await self.service.bond_buy(interaction.user.id, dollars_to_cents(amount))
        await interaction.followup.send(receipt.message, ephemeral=True)
        await check_and_notify_achievements(
            interaction, self.achievement_service, interaction.user.id
        )


async def setup(bot: commands.Bot) -> None:
    """Register investment commands and start the global ticker."""
    await bot.add_cog(InvestingCog(bot))
