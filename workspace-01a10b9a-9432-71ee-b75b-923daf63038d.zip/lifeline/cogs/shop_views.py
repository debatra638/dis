"""Owner-bound Discord UI for shop quotes and player trade offers."""
from __future__ import annotations

import logging
import secrets
from typing import Any, Optional

import discord

from core.achievements import AchievementService
from core.embeds import safe_text
from core.errors import GameError
from core.money import format_cents, parse_cents
from core.shop import ShopQuote, ShopService, TradeReceipt, TradeResult
from core.views import LifelineView, allow_unbanned_user
from cogs.legacy_views import check_and_notify_achievements

logger = logging.getLogger("lifeline.shop.views")


def safe_label(text: str, limit: int = 100) -> str:
    """Escape markdown and all Discord mention tokens before rendering text."""
    return safe_text(text, limit)


def quote_embed(quote: ShopQuote) -> discord.Embed:
    """Build a confirmation embed containing the quoted amount and resulting balance."""
    embed = discord.Embed(title=f"Confirm {safe_label(quote.item_name, 200)}", color=discord.Color.gold())
    embed.add_field(name="Quantity", value=str(quote.quantity), inline=True)
    embed.add_field(name="Unit price", value=format_cents(quote.unit_price), inline=True)
    embed.add_field(name="Total", value=format_cents(quote.total_price), inline=True)
    cash_remaining = quote.balance - quote.total_price
    embed.add_field(
        name="After cash purchase",
        value=format_cents(cash_remaining) if cash_remaining >= 0 else f"Need {format_cents(-cash_remaining)} more",
        inline=False,
    )
    if quote.finance_type is not None:
        finance_remaining = quote.balance - quote.down_payment
        embed.add_field(name="Financing", value=quote.finance_type.title(), inline=True)
        embed.add_field(name="Down payment", value=format_cents(quote.down_payment), inline=True)
        embed.add_field(name="Loan principal", value=format_cents(quote.loan_principal), inline=True)
        embed.add_field(name="Term", value=f"{quote.loan_term_years} in-game years", inline=True)
        embed.add_field(
            name="After down payment",
            value=format_cents(finance_remaining) if finance_remaining >= 0 else f"Need {format_cents(-finance_remaining)} more",
            inline=True,
        )
    embed.set_footer(text="This quote expires in 2 minutes. Any balance or price change requires a retry.")
    return embed


class ShopQuoteView(LifelineView):
    """Single-use, owner-only confirmation for one persisted shop quote."""

    def __init__(
        self,
        owner_id: int,
        quote: ShopQuote,
        service: ShopService,
        achievement_service: Optional[AchievementService] = None,
    ) -> None:
        super().__init__(timeout=120)
        self.owner_id = owner_id
        self.quote = quote
        self.service = service
        self.achievement_service = achievement_service
        self._used = False
        self._bound_message: Optional[discord.Message] = None
        cash = discord.ui.Button(
            label="Confirm cash purchase",
            style=discord.ButtonStyle.success,
            custom_id=f"shop:cash:{quote.nonce}",
            disabled=not quote.can_pay_cash,
            row=0,
        )
        cash.callback = self.confirm_cash
        self.add_item(cash)
        if quote.finance_type is not None:
            finance = discord.ui.Button(
                label=f"Finance · {format_cents(quote.down_payment)} down",
                style=discord.ButtonStyle.primary,
                custom_id=f"shop:finance:{quote.nonce}",
                disabled=quote.balance < quote.down_payment,
                row=0,
            )
            finance.callback = self.confirm_finance
            self.add_item(finance)
        cancel = discord.ui.Button(
            label="Cancel",
            style=discord.ButtonStyle.secondary,
            custom_id=f"shop:cancel:{quote.nonce}",
            row=1,
        )
        cancel.callback = self.cancel
        self.add_item(cancel)

    def bind_message(self, message: discord.Message) -> None:
        """Remember the sent quote message so its controls can be disabled on timeout."""
        self._bound_message = message

    async def confirm_cash(self, interaction: discord.Interaction) -> None:
        """Validate ownership and the stored quote nonce, then purchase for cash."""
        if not await self._authorize(interaction, "cash"):
            return
        await self._complete_purchase(interaction, "cash")

    async def confirm_finance(self, interaction: discord.Interaction) -> None:
        """Validate ownership and the stored quote nonce, then use secured financing."""
        if not await self._authorize(interaction, "finance"):
            return
        await self._complete_purchase(interaction, "finance")

    async def cancel(self, interaction: discord.Interaction) -> None:
        """Close the quote without changing the character's balances or items."""
        if not await self._authorize(interaction, "cancel"):
            return
        self._finish()
        await interaction.response.edit_message(content="Purchase cancelled.", embed=None, view=self)

    async def _authorize(self, interaction: discord.Interaction, action: str) -> bool:
        """Require the quote owner, matching custom-ID nonce, and unused view."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This shop confirmation belongs to another player.", ephemeral=True)
            return False
        if not await allow_unbanned_user(interaction, self.service.db):
            return False
        expected = f"shop:{action}:{self.quote.nonce}"
        if self._used or not interaction.data or interaction.data.get("custom_id") != expected:
            await interaction.response.send_message("This shop button is stale. Request a new quote.", ephemeral=True)
            return False
        return True

    async def _complete_purchase(self, interaction: discord.Interaction, method: str) -> None:
        """Execute the purchase once and remove active controls on every result."""
        try:
            receipt = await self.service.purchase(
                self.owner_id,
                self.quote.item_id,
                self.quote.quantity,
                expected_version=self.quote.version,
                expected_total=self.quote.total_price,
                nonce=self.quote.nonce,
                payment_method=method,
                expected_down_payment=self.quote.down_payment if method == "finance" else None,
            )
            self._finish()
            embed = discord.Embed(title="Purchase complete", color=discord.Color.green())
            embed.description = (
                f"Bought **{receipt.quantity} × {safe_label(receipt.item_name, 150)}** for "
                f"{format_cents(receipt.total_price)}.\n"
                f"Paid now: {format_cents(receipt.paid_now)} · Remaining liquid balance: "
                f"{format_cents(receipt.remaining_balance)}."
            )
            if receipt.loan_principal:
                embed.add_field(name="Secured loan", value=format_cents(receipt.loan_principal), inline=False)
            await interaction.response.edit_message(content=None, embed=embed, view=self)
            await check_and_notify_achievements(
                interaction, self.achievement_service, interaction.user.id
            )
        except GameError as exc:
            self._finish()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
        except Exception:
            logger.exception("Unexpected error while confirming a shop quote")
            self._finish()
            await interaction.response.edit_message(
                content="The purchase could not be completed. Request a new quote and retry.", embed=None, view=self
            )

    def _finish(self) -> None:
        """Disable and stop this one-use view."""
        self._used = True
        self.disable_all_items()
        self.stop()

    async def on_timeout(self) -> None:
        """Disable expired shop controls if the message is still editable."""
        self._finish()
        if self._bound_message is not None:
            try:
                await self._bound_message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Timed-out shop quote message could not be edited", exc_info=True)


class ShopItemSelect(discord.ui.Select):
    """Select one paginated catalog entry, then request quantity when stackable."""

    def __init__(self, parent: "ShopBrowseView") -> None:
        self.parent_view = parent
        start = parent.page_index * parent.page_size
        page = parent.items[start:start + parent.page_size]
        options = [
            discord.SelectOption(
                label=safe_label(str(item["name"]), 100),
                value=str(item["id"]),
                description=f"{format_cents(int(item['price_cents']))} · age {item['min_age']}+",
            )
            for item in page
        ]
        super().__init__(
            placeholder="Choose an item to buy",
            min_values=1,
            max_values=1,
            options=options,
            custom_id=f"shop-browse:{parent.nonce}:select:{parent.page_index}",
            row=0,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        """Authorize the browser owner and create a quote or quantity prompt."""
        if not await self.parent_view._authorize(interaction, self.custom_id):
            return
        item = self.parent_view.service.get_item(self.values[0])
        if item is None:
            await interaction.response.send_message("That catalog entry is no longer available.", ephemeral=True)
            return
        if item["stackable"]:
            await interaction.response.send_modal(
                QuantityModal(self.parent_view.owner_id, self.parent_view.service, str(item["id"]), self.parent_view.nonce)
            )
            return
        try:
            quote = await self.parent_view.service.quote_purchase(self.parent_view.owner_id, str(item["id"]), 1)
            quote_view = ShopQuoteView(
                self.parent_view.owner_id, quote, self.parent_view.service,
                self.parent_view.achievement_service,
            )
            await interaction.response.send_message(embed=quote_embed(quote), view=quote_view, ephemeral=True)
            quote_view.bind_message(await interaction.original_response())
        except GameError as exc:
            await interaction.response.send_message(exc.message, ephemeral=True)


class ShopBrowseView(LifelineView):
    """Owner-only paginated shop browser with a quantity-select purchase flow."""

    page_size = 8

    def __init__(
        self,
        owner_id: int,
        service: ShopService,
        items: list[dict[str, Any]],
        category: Optional[str] = None,
        achievement_service: Optional[AchievementService] = None,
    ) -> None:
        super().__init__(timeout=180)
        self.owner_id = owner_id
        self.service = service
        self.achievement_service = achievement_service
        self.items = items
        self.category = category
        self.page_index = 0
        self.nonce = secrets.token_urlsafe(12)
        self._closed = False
        self._bound_message: Optional[discord.Message] = None
        self._refresh_items()

    def bind_message(self, message: discord.Message) -> None:
        """Remember the browser message for timeout cleanup."""
        self._bound_message = message

    def make_embed(self) -> discord.Embed:
        """Render the current page with local-price-index-adjusted prices."""
        embed = discord.Embed(
            title=f"Shop · {self.category.title() if self.category else 'All categories'}",
            color=discord.Color.blurple(),
        )
        start = self.page_index * self.page_size
        page = self.items[start:start + self.page_size]
        lines = [
            f"**{safe_label(str(item['name']), 100)}** — {format_cents(int(item['price_cents']))} · age {item['min_age']}+"
            for item in page
        ]
        embed.description = "\n".join(lines) if lines else "No items are available in this category."
        page_count = max(1, (len(self.items) + self.page_size - 1) // self.page_size)
        embed.set_footer(text=f"Page {self.page_index + 1}/{page_count} · Prices include your character's price index")
        return embed

    def _refresh_items(self) -> None:
        """Recreate page controls with unique session-scoped custom IDs."""
        self.clear_items()
        if self.items:
            self.add_item(ShopItemSelect(self))
        page_count = max(1, (len(self.items) + self.page_size - 1) // self.page_size)
        if page_count > 1:
            previous = discord.ui.Button(
                label="Previous", style=discord.ButtonStyle.secondary,
                custom_id=f"shop-browse:{self.nonce}:previous:{self.page_index}", row=1,
                disabled=self.page_index <= 0,
            )
            previous.callback = self.previous
            self.add_item(previous)
            following = discord.ui.Button(
                label="Next", style=discord.ButtonStyle.secondary,
                custom_id=f"shop-browse:{self.nonce}:next:{self.page_index}", row=1,
                disabled=self.page_index >= page_count - 1,
            )
            following.callback = self.next
            self.add_item(following)
        close = discord.ui.Button(
            label="Close", style=discord.ButtonStyle.danger,
            custom_id=f"shop-browse:{self.nonce}:close:{self.page_index}", row=1,
        )
        close.callback = self.close
        self.add_item(close)

    async def previous(self, interaction: discord.Interaction) -> None:
        """Move to the previous catalog page after owner/nonce validation."""
        if not await self._authorize(interaction, interaction.data.get("custom_id") if interaction.data else None):
            return
        self.page_index = max(0, self.page_index - 1)
        self._refresh_items()
        await interaction.response.edit_message(embed=self.make_embed(), view=self)

    async def next(self, interaction: discord.Interaction) -> None:
        """Move to the next catalog page after owner/nonce validation."""
        if not await self._authorize(interaction, interaction.data.get("custom_id") if interaction.data else None):
            return
        page_count = max(1, (len(self.items) + self.page_size - 1) // self.page_size)
        self.page_index = min(page_count - 1, self.page_index + 1)
        self._refresh_items()
        await interaction.response.edit_message(embed=self.make_embed(), view=self)

    async def close(self, interaction: discord.Interaction) -> None:
        """Close the browser and disable its controls."""
        if not await self._authorize(interaction, interaction.data.get("custom_id") if interaction.data else None):
            return
        self._closed = True
        self.disable_all_items()
        self.stop()
        await interaction.response.edit_message(content="Shop closed.", embed=None, view=self)

    async def _authorize(self, interaction: discord.Interaction, custom_id: Optional[str]) -> bool:
        """Require the owner and this browser's session nonce in the component ID."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This shop view belongs to another player.", ephemeral=True)
            return False
        if not await allow_unbanned_user(interaction, self.service.db):
            return False
        if self._closed or not custom_id or not custom_id.startswith(f"shop-browse:{self.nonce}:"):
            await interaction.response.send_message("This shop view is stale. Open `/shop browse` again.", ephemeral=True)
            return False
        return True

    async def on_timeout(self) -> None:
        """Disable expired browse controls."""
        self.disable_all_items()
        self.stop()
        if self._bound_message is not None:
            try:
                await self._bound_message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Timed-out shop browser could not be edited", exc_info=True)


class QuantityModal(discord.ui.Modal, title="Choose a quantity"):
    """Owner-bound modal for stackable shop items."""

    quantity = discord.ui.TextInput(
        label="Quantity",
        placeholder="1",
        min_length=1,
        max_length=3,
        required=True,
    )

    def __init__(self, owner_id: int, service: ShopService, item_id: str, session_nonce: str) -> None:
        super().__init__(timeout=120, custom_id=f"quantity:{session_nonce}:{item_id}")
        self.owner_id = owner_id
        self.service = service
        self.item_id = item_id
        self.session_nonce = session_nonce

    async def on_submit(self, interaction: discord.Interaction) -> None:
        """Create a persisted quote only after validating the submitting owner and quantity."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This quantity form belongs to another player.", ephemeral=True)
            return
        expected_custom_id = f"quantity:{self.session_nonce}:{self.item_id}"
        if not interaction.data or interaction.data.get("custom_id") != expected_custom_id:
            await interaction.response.send_message("This quantity form is stale. Reopen the shop.", ephemeral=True)
            return
        if not await allow_unbanned_user(interaction, self.service.db):
            return
        try:
            amount = int(str(self.quantity.value).strip())
            quote = await self.service.quote_purchase(self.owner_id, self.item_id, amount)
            quote_view = ShopQuoteView(self.owner_id, quote, self.service, self.achievement_service)
            await interaction.response.send_message(embed=quote_embed(quote), view=quote_view, ephemeral=True)
            quote_view.bind_message(await interaction.original_response())
        except (ValueError, GameError) as exc:
            message = exc.message if isinstance(exc, GameError) else "Enter a whole-number quantity."
            await interaction.response.send_message(message, ephemeral=True)


class TradeBuilderView(LifelineView):
    """Owner-only trade composer with paginated item selectors and a cash modal."""

    def __init__(
        self,
        owner_id: int,
        target_id: int,
        service: ShopService,
        offered: list[dict[str, Any]],
        requested: list[dict[str, Any]],
        achievement_service: Optional[AchievementService] = None,
    ) -> None:
        super().__init__(timeout=240)
        self.owner_id = owner_id
        self.target_id = target_id
        self.service = service
        self.achievement_service = achievement_service
        self.offered_rows = offered
        self.requested_rows = requested
        self.selected_offer: set[int] = set()
        self.selected_request: set[int] = set()
        self.nonce = secrets.token_urlsafe(12)
        self._closed = False
        self._bound_message: Optional[discord.Message] = None
        self._add_controls()

    def bind_message(self, message: discord.Message) -> None:
        """Remember the builder's ephemeral message for timeout cleanup."""
        self._bound_message = message

    def make_embed(self) -> discord.Embed:
        """Summarize chosen item lots without exposing unescaped user-provided text."""
        offer_lines = self._selected_lines(self.offered_rows, self.selected_offer)
        request_lines = self._selected_lines(self.requested_rows, self.selected_request)
        embed = discord.Embed(title="Build a player trade", color=discord.Color.blurple())
        embed.description = (
            f"Choose unlocked, tradeable items for both sides, then enter cash amounts.\n"
            f"**Your items:** {', '.join(offer_lines) if offer_lines else 'None'}\n"
            f"**Requested items:** {', '.join(request_lines) if request_lines else 'None'}\n"
            "Cash is not escrowed; each side must have enough cash plus a 5% tax when accepted."
        )
        embed.set_footer(text="Trade proposals expire after 10 minutes · maximum 5 offers per player per UTC day")
        return embed

    def _add_controls(self) -> None:
        """Recreate composer buttons with a per-view nonce in each custom ID."""
        self.clear_items()
        offered = discord.ui.Button(
            label="Choose your items", style=discord.ButtonStyle.primary,
            custom_id=f"trade-build:{self.nonce}:offer", row=0,
        )
        offered.callback = self.choose_offered
        self.add_item(offered)
        requested = discord.ui.Button(
            label="Choose requested items", style=discord.ButtonStyle.primary,
            custom_id=f"trade-build:{self.nonce}:request", row=0,
        )
        requested.callback = self.choose_requested
        self.add_item(requested)
        send = discord.ui.Button(
            label="Enter cash and create offer", style=discord.ButtonStyle.success,
            custom_id=f"trade-build:{self.nonce}:cash", row=1,
        )
        send.callback = self.send_offer
        self.add_item(send)
        cancel = discord.ui.Button(
            label="Close", style=discord.ButtonStyle.secondary,
            custom_id=f"trade-build:{self.nonce}:close", row=1,
        )
        cancel.callback = self.close
        self.add_item(cancel)

    async def choose_offered(self, interaction: discord.Interaction) -> None:
        """Open a paginated selector for the initiator's eligible items."""
        if not await self._authorize(interaction):
            return
        picker = TradeItemPickerView(self, "offer")
        await interaction.response.edit_message(embed=picker.make_embed(), view=picker)

    async def choose_requested(self, interaction: discord.Interaction) -> None:
        """Open a paginated selector for the target's eligible items."""
        if not await self._authorize(interaction):
            return
        picker = TradeItemPickerView(self, "request")
        await interaction.response.edit_message(embed=picker.make_embed(), view=picker)

    async def send_offer(self, interaction: discord.Interaction) -> None:
        """Open the cash modal; the trade is created only on modal submission."""
        if not await self._authorize(interaction):
            return
        await interaction.response.send_modal(TradeCashModal(self))

    async def close(self, interaction: discord.Interaction) -> None:
        """Close the trade builder without reserving any items."""
        if not await self._authorize(interaction):
            return
        self._closed = True
        self.disable_all_items()
        self.stop()
        await interaction.response.edit_message(content="Trade builder closed.", embed=None, view=self)

    async def _authorize(self, interaction: discord.Interaction) -> bool:
        """Require the initiating owner and this builder's component nonce."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This trade builder belongs to another player.", ephemeral=True)
            return False
        if not await allow_unbanned_user(interaction, self.service.db):
            return False
        custom_id = interaction.data.get("custom_id") if interaction.data else ""
        if self._closed or not str(custom_id).startswith(f"trade-build:{self.nonce}:"):
            await interaction.response.send_message("This trade builder is stale. Start `/trade offer` again.", ephemeral=True)
            return False
        return True

    @staticmethod
    def _selected_lines(rows: list[dict[str, Any]], selected: set[int]) -> list[str]:
        """Format selected item names and quantities for the current offer summary."""
        lines: list[str] = []
        for row in rows:
            if int(row["asset_id"]) in selected:
                lines.append(f"{int(row['quantity'])}× {safe_label(str(row['name']), 60)}")
        return lines

    async def on_timeout(self) -> None:
        """Disable an idle trade builder."""
        self._closed = True
        self.disable_all_items()
        self.stop()
        if self._bound_message is not None:
            try:
                await self._bound_message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Timed-out trade builder could not be edited", exc_info=True)


class TradeItemSelect(discord.ui.Select):
    """Multi-select one page of items while preserving choices on other pages."""

    def __init__(self, picker: "TradeItemPickerView") -> None:
        self.picker = picker
        rows = picker.page_rows()
        options = [
            discord.SelectOption(
                label=safe_label(f"{row['quantity']}× {row['name']}", 100),
                value=str(row["asset_id"]),
                description=f"Current value {format_cents(int(row['current_value']))} · lot #{row['asset_id']}",
                default=int(row["asset_id"]) in picker.selected_set,
            )
            for row in rows
        ]
        super().__init__(
            placeholder="Select item lots on this page",
            min_values=0,
            max_values=max(1, len(options)),
            options=options,
            custom_id=f"trade-picker:{picker.builder.nonce}:{picker.side}:{picker.page_index}",
            row=0,
            disabled=not options,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        """Update page selections after verifying the owner and component nonce."""
        if not await self.picker.authorize(interaction, self.custom_id):
            return
        current_ids = {int(row["asset_id"]) for row in self.picker.page_rows()}
        selection = self.picker.selected_set
        selection.difference_update(current_ids)
        selection.update(int(value) for value in self.values)
        await interaction.response.edit_message(embed=self.picker.make_embed(), view=self.picker)


class TradeItemPickerView(LifelineView):
    """Paginated owner-only selector that supports inventories over Discord's 25-option limit."""

    page_size = 25

    def __init__(self, builder: TradeBuilderView, side: str) -> None:
        super().__init__(timeout=240)
        self.builder = builder
        self.side = side
        self.owner_id = builder.owner_id
        self.page_index = 0
        self._closed = False
        self._refresh()

    @property
    def rows(self) -> list[dict[str, Any]]:
        """Return the side's current selectable item rows."""
        return self.builder.offered_rows if self.side == "offer" else self.builder.requested_rows

    @property
    def selected_set(self) -> set[int]:
        """Return the builder's persistent item selections for this side."""
        return self.builder.selected_offer if self.side == "offer" else self.builder.selected_request

    def page_rows(self) -> list[dict[str, Any]]:
        """Return rows on the currently selected page."""
        start = self.page_index * self.page_size
        return self.rows[start:start + self.page_size]

    def make_embed(self) -> discord.Embed:
        """Describe the current item page and selections retained across pages."""
        embed = discord.Embed(
            title="Choose offered item lots" if self.side == "offer" else "Choose requested item lots",
            color=discord.Color.blurple(),
        )
        selected_count = len(self.selected_set)
        if not self.rows:
            embed.description = "No unlocked, tradeable items are available on this side."
        else:
            page_count = max(1, (len(self.rows) + self.page_size - 1) // self.page_size)
            names = [safe_label(str(row["name"]), 80) for row in self.page_rows()]
            embed.description = f"Page {self.page_index + 1}/{page_count}: " + ", ".join(names)
        embed.set_footer(text=f"{selected_count} lot(s) selected. Revisit a page to change its selection.")
        return embed

    def _refresh(self) -> None:
        """Rebuild selector and page controls."""
        self.clear_items()
        if self.page_rows():
            self.add_item(TradeItemSelect(self))
        page_count = max(1, (len(self.rows) + self.page_size - 1) // self.page_size)
        if page_count > 1:
            previous = discord.ui.Button(
                label="Previous", style=discord.ButtonStyle.secondary,
                custom_id=f"trade-picker:{self.builder.nonce}:{self.side}:previous:{self.page_index}",
                row=1, disabled=self.page_index <= 0,
            )
            previous.callback = self.previous
            self.add_item(previous)
            following = discord.ui.Button(
                label="Next", style=discord.ButtonStyle.secondary,
                custom_id=f"trade-picker:{self.builder.nonce}:{self.side}:next:{self.page_index}",
                row=1, disabled=self.page_index >= page_count - 1,
            )
            following.callback = self.next
            self.add_item(following)
        done = discord.ui.Button(
            label="Done", style=discord.ButtonStyle.success,
            custom_id=f"trade-picker:{self.builder.nonce}:{self.side}:done:{self.page_index}", row=1,
        )
        done.callback = self.done
        self.add_item(done)

    async def previous(self, interaction: discord.Interaction) -> None:
        """Move to the previous selection page."""
        if not await self.authorize(interaction, interaction.data.get("custom_id") if interaction.data else None):
            return
        self.page_index = max(0, self.page_index - 1)
        self._refresh()
        await interaction.response.edit_message(embed=self.make_embed(), view=self)

    async def next(self, interaction: discord.Interaction) -> None:
        """Move to the next selection page."""
        if not await self.authorize(interaction, interaction.data.get("custom_id") if interaction.data else None):
            return
        page_count = max(1, (len(self.rows) + self.page_size - 1) // self.page_size)
        self.page_index = min(page_count - 1, self.page_index + 1)
        self._refresh()
        await interaction.response.edit_message(embed=self.make_embed(), view=self)

    async def done(self, interaction: discord.Interaction) -> None:
        """Return to the trade builder with selections intact."""
        if not await self.authorize(interaction, interaction.data.get("custom_id") if interaction.data else None):
            return
        self._closed = True
        self.stop()
        self.builder._add_controls()
        await interaction.response.edit_message(embed=self.builder.make_embed(), view=self.builder)

    async def authorize(self, interaction: discord.Interaction, custom_id: Optional[str]) -> bool:
        """Verify selector ownership and a current-side selector nonce."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This item selector belongs to another player.", ephemeral=True)
            return False
        if not await allow_unbanned_user(interaction, self.builder.service.db):
            return False
        expected_prefix = f"trade-picker:{self.builder.nonce}:{self.side}:"
        if self._closed or not custom_id or not custom_id.startswith(expected_prefix):
            await interaction.response.send_message("This item selector is stale. Reopen the trade builder.", ephemeral=True)
            return False
        return True


class TradeCashModal(discord.ui.Modal, title="Cash terms"):
    """Cash-entry form that creates the trade proposal on submit."""

    offer_cash = discord.ui.TextInput(
        label="Cash you offer (dollars)", placeholder="0.00", default="0.00", max_length=24, required=True
    )
    request_cash = discord.ui.TextInput(
        label="Cash you request (dollars)", placeholder="0.00", default="0.00", max_length=24, required=True
    )

    def __init__(self, builder: TradeBuilderView) -> None:
        super().__init__(timeout=180, custom_id=f"trade-cash:{builder.nonce}")
        self.builder = builder

    async def on_submit(self, interaction: discord.Interaction) -> None:
        """Validate author and money inputs, persist the offer, and DM its target."""
        if interaction.user.id != self.builder.owner_id:
            await interaction.response.send_message("This cash form belongs to another player.", ephemeral=True)
            return
        if not interaction.data or interaction.data.get("custom_id") != f"trade-cash:{self.builder.nonce}":
            await interaction.response.send_message("This cash form is stale. Reopen `/trade offer`.", ephemeral=True)
            return
        if not await allow_unbanned_user(interaction, self.builder.service.db):
            return
        try:
            offer_amount = parse_cents(str(self.offer_cash.value))
            request_amount = parse_cents(str(self.request_cash.value))
            offer_map = {
                int(row["asset_id"]): int(row["quantity"])
                for row in self.builder.offered_rows if int(row["asset_id"]) in self.builder.selected_offer
            }
            request_map = {
                int(row["asset_id"]): int(row["quantity"])
                for row in self.builder.requested_rows if int(row["asset_id"]) in self.builder.selected_request
            }
            if not any(offer_map.values()) and not any(request_map.values()) and offer_amount == 0 and request_amount == 0:
                raise ValueError("A trade must contain at least one item or a nonzero cash amount.")
            await interaction.response.defer(ephemeral=True, thinking=True)
            receipt = await self.builder.service.create_trade(
                self.builder.owner_id,
                self.builder.target_id,
                offered_items=offer_map,
                requested_items=request_map,
                offer_cash=offer_amount,
                request_cash=request_amount,
            )
            target_view = TradeTargetView(
                self.builder.target_id, receipt, self.builder.service,
                self.builder.achievement_service,
            )
            try:
                target = await interaction.client.fetch_user(self.builder.target_id)
                target_embed = trade_offer_embed(receipt, self.builder.service, interaction.user)
                dm_message = await target.send(
                    embed=target_embed,
                    view=target_view,
                    allowed_mentions=discord.AllowedMentions.none(),
                )
                target_view.bind_message(dm_message)
            except discord.HTTPException:
                await self.builder.service.cancel_trade(receipt.trade_id, self.builder.owner_id, receipt.nonce)
                await interaction.followup.send(
                    "The target could not receive a trade DM, so the offer was cancelled and your items were unlocked.",
                    ephemeral=True,
                )
                return
            creator_view = TradeCreatorView(self.builder.owner_id, receipt, self.builder.service)
            creator_message = await interaction.followup.send(
                f"Trade **#{receipt.trade_id}** sent. Your offered items are locked until it is resolved or expires.",
                view=creator_view,
                ephemeral=True,
                wait=True,
            )
            creator_view.bind_message(creator_message)
            self.builder._closed = True
            self.builder.disable_all_items()
            self.builder.stop()
            if self.builder._bound_message is not None:
                try:
                    await self.builder._bound_message.edit(
                        content=f"Trade **#{receipt.trade_id}** sent; this builder is closed.",
                        embed=None,
                        view=self.builder,
                    )
                except discord.HTTPException:
                    logger.debug("Closed trade builder could not be refreshed", exc_info=True)
        except (ValueError, GameError) as exc:
            message = exc.message if isinstance(exc, GameError) else str(exc)
            if interaction.response.is_done():
                await interaction.followup.send(message, ephemeral=True)
            else:
                await interaction.response.send_message(message, ephemeral=True)
        except Exception:
            logger.exception("Unexpected error creating a player trade")
            if interaction.response.is_done():
                await interaction.followup.send("The trade could not be created. Please retry.", ephemeral=True)
            else:
                await interaction.response.send_message("The trade could not be created. Please retry.", ephemeral=True)


def trade_offer_embed(receipt: TradeReceipt, service: ShopService, initiator: Any) -> discord.Embed:
    """Format trade terms for the target without rendering untrusted mentions."""
    embed = discord.Embed(title=f"Trade Offer #{receipt.trade_id}", color=discord.Color.gold())
    embed.description = (
        f"From **{safe_label(getattr(initiator, 'display_name', getattr(initiator, 'name', 'Player')), 100)}**\n"
        f"Expires in 10 minutes. Cash is not escrowed; accepted cash transfers incur a 5% tax."
    )
    embed.add_field(name="They offer cash", value=format_cents(receipt.offer_cash), inline=True)
    embed.add_field(name="They request cash", value=format_cents(receipt.request_cash), inline=True)
    offer = [f"{quantity}× {safe_label(service.items[item_id]['name'], 80)}" for item_id, quantity in receipt.offer_items]
    request = [f"{quantity}× {safe_label(service.items[item_id]['name'], 80)}" for item_id, quantity in receipt.request_items]
    embed.add_field(name="Items offered to you", value="\n".join(offer) if offer else "None", inline=False)
    embed.add_field(name="Items requested from you", value="\n".join(request) if request else "None", inline=False)
    if receipt.imbalance_flag:
        embed.add_field(name="Value review", value="This offer was flagged for a large value imbalance.", inline=False)
    return embed


class TradeTargetView(LifelineView):
    """Nonce-bound Accept/Decline controls visible only to the target account."""

    def __init__(
        self,
        owner_id: int,
        receipt: TradeReceipt,
        service: ShopService,
        achievement_service: Optional[AchievementService] = None,
    ) -> None:
        super().__init__(timeout=600)
        self.owner_id = owner_id
        self.receipt = receipt
        self.service = service
        self.achievement_service = achievement_service
        self._used = False
        self._bound_message: Optional[discord.Message] = None
        accept = discord.ui.Button(
            label="Accept", style=discord.ButtonStyle.success,
            custom_id=f"trade-target:accept:{receipt.trade_id}:{receipt.nonce}", row=0,
        )
        accept.callback = self.accept
        self.add_item(accept)
        decline = discord.ui.Button(
            label="Decline", style=discord.ButtonStyle.danger,
            custom_id=f"trade-target:decline:{receipt.trade_id}:{receipt.nonce}", row=0,
        )
        decline.callback = self.decline
        self.add_item(decline)

    def bind_message(self, message: discord.Message) -> None:
        """Remember the target DM for expiry cleanup."""
        self._bound_message = message

    async def accept(self, interaction: discord.Interaction) -> None:
        """Revalidate and atomically accept the exact offer nonce."""
        if not await self._authorize(interaction, "accept"):
            return
        try:
            result = await self.service.accept_trade(self.receipt.trade_id, self.owner_id, self.receipt.nonce)
            self._finish()
            await interaction.response.edit_message(content=result.message, embed=None, view=self)
            await check_and_notify_achievements(
                interaction, self.achievement_service, interaction.user.id
            )
            other_user_id = int(self.receipt.from_user_id)
            if self.achievement_service is not None and other_user_id != interaction.user.id:
                try:
                    await self.achievement_service.check_user(
                        other_user_id, guild_id=interaction.guild_id
                    )
                except Exception:
                    logger.exception("Could not check trade achievements for user %s", other_user_id)
        except GameError as exc:
            self._finish()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
        except Exception:
            logger.exception("Unexpected error accepting trade %s", self.receipt.trade_id)
            self._finish()
            await interaction.response.edit_message(content="The trade could not be accepted. Check `/trade list`.", embed=None, view=self)

    async def decline(self, interaction: discord.Interaction) -> None:
        """Decline the target's offer and atomically release offered items."""
        if not await self._authorize(interaction, "decline"):
            return
        try:
            result = await self.service.decline_trade(self.receipt.trade_id, self.owner_id, self.receipt.nonce)
            self._finish()
            await interaction.response.edit_message(content=result.message, embed=None, view=self)
        except GameError as exc:
            self._finish()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)

    async def _authorize(self, interaction: discord.Interaction, action: str) -> bool:
        """Check target user, unused view, and the custom-ID trade nonce."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Only the target player can use these trade buttons.", ephemeral=True)
            return False
        if not await allow_unbanned_user(interaction, self.service.db):
            return False
        expected = f"trade-target:{action}:{self.receipt.trade_id}:{self.receipt.nonce}"
        if self._used or not interaction.data or interaction.data.get("custom_id") != expected:
            await interaction.response.send_message("This trade button is stale or already used.", ephemeral=True)
            return False
        return True

    def _finish(self) -> None:
        """Disable both terminal controls after one target response."""
        self._used = True
        self.disable_all_items()
        self.stop()

    async def on_timeout(self) -> None:
        """Disable expired DM buttons; database expiry is handled by the cog task."""
        self._finish()
        if self._bound_message is not None:
            try:
                await self._bound_message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Timed-out trade DM could not be edited", exc_info=True)


class TradeCreatorView(LifelineView):
    """Nonce-bound cancel control for the player who opened the offer."""

    def __init__(self, owner_id: int, receipt: TradeReceipt, service: ShopService) -> None:
        super().__init__(timeout=600)
        self.owner_id = owner_id
        self.receipt = receipt
        self.service = service
        self._used = False
        self._bound_message: Optional[discord.Message] = None
        cancel = discord.ui.Button(
            label="Cancel offer", style=discord.ButtonStyle.danger,
            custom_id=f"trade-creator:cancel:{receipt.trade_id}:{receipt.nonce}",
        )
        cancel.callback = self.cancel
        self.add_item(cancel)

    def bind_message(self, message: discord.Message) -> None:
        """Remember the initiator's ephemeral offer message for timeout cleanup."""
        self._bound_message = message

    async def cancel(self, interaction: discord.Interaction) -> None:
        """Cancel the pending offer and unlock offered item lots."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Only the offerer can cancel this trade.", ephemeral=True)
            return
        if not await allow_unbanned_user(interaction, self.service.db):
            return
        expected = f"trade-creator:cancel:{self.receipt.trade_id}:{self.receipt.nonce}"
        if self._used or not interaction.data or interaction.data.get("custom_id") != expected:
            await interaction.response.send_message("This trade button is stale or already used.", ephemeral=True)
            return
        try:
            result = await self.service.cancel_trade(self.receipt.trade_id, self.owner_id, self.receipt.nonce)
            self._used = True
            self.disable_all_items()
            self.stop()
            await interaction.response.edit_message(content=result.message, view=self)
        except GameError as exc:
            self._used = True
            self.disable_all_items()
            self.stop()
            await interaction.response.edit_message(content=exc.message, view=self)

    async def on_timeout(self) -> None:
        """Disable the initiator's controls when their local view expires."""
        self._used = True
        self.disable_all_items()
        self.stop()
        if self._bound_message is not None:
            try:
                await self._bound_message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Timed-out trade creator view could not be edited", exc_info=True)

