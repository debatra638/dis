"""Discord slash commands for prison status and once-yearly prison choices."""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from core.crime import CrimeService
from core.embeds import safe_text as escape_user_text
from core.money import format_cents


PRISON_ACTIONS = [
    app_commands.Choice(name="Behave", value="behave"),
    app_commands.Choice(name="Workout", value="workout"),
    app_commands.Choice(name="Study", value="study"),
    app_commands.Choice(name="Riot", value="riot"),
    app_commands.Choice(name="Escape", value="escape"),
    app_commands.Choice(name="Gang protection", value="gang"),
]


def _safe(value: str) -> str:
    """Escape character-controlled text and mentions before adding it to an embed."""
    return escape_user_text(value)


class PrisonCog(commands.Cog):
    """Prison status and abstract once-per-year custody actions."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        service = getattr(bot, "crime_service", None)
        if service is None:
            service = CrimeService(bot.db, bot.rng, getattr(bot, "locks", None))
        self.service: CrimeService = service

    prison = app_commands.Group(name="prison", description="View custody status and choose a prison action")

    @prison.command(name="status", description="View your current prison sentence and conditions")
    @app_commands.checks.cooldown(1, 8.0, key=lambda interaction: interaction.user.id)
    async def status(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await self.service.prison_status(interaction.user.id)
        character = result.character
        if not result.in_prison:
            description = (
                f"**Status:** Not incarcerated\n"
                f"**Criminal career:** {_safe(result.career_rank or 'Not established')}\n"
                f"**Notoriety:** {character.notoriety}/100\n"
                f"**Criminal record:** {character.criminal_record}"
            )
            if result.escaped:
                description += "\n**Escape status:** At large; annual re-arrest roll is 30%."
            embed = discord.Embed(title=f"Prison status · {_safe(character.name)}", description=description, color=discord.Color.green())
            embed.set_footer(text="Use /crime record to review your history or resume a saved decision.")
            await interaction.followup.send(embed=embed, ephemeral=True)
            return

        sentence = f"{result.years_left} year(s) remaining"
        if result.juvenile_release_age is not None:
            sentence += f" · juvenile release at age {result.juvenile_release_age}"
        embed = discord.Embed(
            title=f"Prison status · {_safe(character.name)}",
            description=(
                f"**Sentence:** {sentence}\n"
                f"**Career rank:** {_safe(result.career_rank or 'Not established')} · {result.career_years} paid year(s)\n"
                f"**Dirty proceeds:** {format_cents(result.dirty_cash)}\n"
                f"**Gang protection:** {'Active' if result.gang_protected else 'None'}\n"
                f"**GED credential:** {'Yes' if character.has_ged else 'No'}\n\n"
                "No wages or ordinary bills are processed while incarcerated; only affordable loan payments are attempted. "
                "Use `/prison action` once this in-game year."
            ),
            color=discord.Color.dark_grey(),
        )
        embed.set_footer(text="Actions are abstract, once-per-year game choices; no real-world instructions are provided.")
        await interaction.followup.send(embed=embed, ephemeral=True)

    @prison.command(name="action", description="Take one prison action for this in-game year")
    @app_commands.describe(action="Choose one prison action; each character gets one per year")
    @app_commands.choices(action=PRISON_ACTIONS)
    @app_commands.checks.cooldown(1, 10.0, key=lambda interaction: interaction.user.id)
    async def action(self, interaction: discord.Interaction, action: str) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await self.service.prison_action(interaction.user.id, action)
        embed = discord.Embed(
            title=f"Prison action · {result.action.replace('_', ' ').title()}",
            description=result.message,
            color=discord.Color.blurple(),
        )
        embed.add_field(name="Age", value=str(result.character.age), inline=True)
        embed.add_field(
            name="Status",
            value=(
                f"Released · record {result.character.criminal_record}"
                if not result.character.in_prison
                else f"{result.character.prison_years_left} year(s) remaining"
            ),
            inline=True,
        )
        await interaction.followup.send(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    """Register the prison slash-command cog."""
    await bot.add_cog(PrisonCog(bot))
