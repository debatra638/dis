"""Owner-checked, nonce-protected Stage 10 Discord views and summary rendering."""
from __future__ import annotations

import logging
import secrets
from datetime import datetime, timezone
from typing import Any, Optional, Sequence

import discord

from core.achievements import AchievementService
from core.death import DeathService, RetirementPrompt
from core.embeds import safe_text
from core.errors import GameError
from core.leaderboard import LeaderboardResult, METRICS
from core.money import format_cents
from core.views import LifelineView, allow_unbanned_user

logger = logging.getLogger("lifeline.legacy.views")


def _safe_text(value: Any, limit: int = 180) -> str:
    """Escape markdown and all Discord mention tokens before placing text in an embed."""
    return safe_text(value, limit)


async def check_and_notify_achievements(
    interaction: discord.Interaction,
    service: Optional[AchievementService],
    user_id: int,
) -> None:
    """Recheck after a component action and send a compact unlock embed if needed."""
    if service is None:
        return
    try:
        await service.check_user(int(user_id), guild_id=interaction.guild_id)
        notices = service.consume_notifications(int(user_id))
        if not notices:
            return
        lines = [
            f"🏆 **{_safe_text(row.get('name', 'Achievement'), 80)}** — "
            f"{_safe_text(row.get('description', ''), 180)}"
            for row in notices[:5]
        ]
        if len(notices) > 5:
            lines.append(f"…and {len(notices) - 5} more achievement(s)")
        embed = discord.Embed(
            title="Achievement unlocked!" if len(notices) == 1 else "Achievements unlocked!",
            description="\n".join(lines),
            color=discord.Color.gold(),
        )
        await interaction.followup.send(
            embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none()
        )
    except Exception:
        logger.exception("Could not award component-triggered achievements for user %s", user_id)


def _calendar_year(timestamp: Any) -> str:
    """Format a persisted Unix timestamp as a UTC calendar year, failing closed."""
    try:
        return str(datetime.fromtimestamp(int(timestamp), tz=timezone.utc).year)
    except (OverflowError, OSError, TypeError, ValueError):
        return "unknown"


def death_summary_embed(
    summary: dict[str, Any],
    *,
    avatar_url: Optional[str] = None,
    achievement_names: Optional[dict[str, str]] = None,
) -> discord.Embed:
    """Render the archived life portrait, milestones, estate, and grade into an embed."""
    name = _safe_text(summary.get("name", "Unknown life"), 80)
    age = int(summary.get("death_age", 0))
    cause = _safe_text(summary.get("death_cause", "unknown causes"), 160)
    epitaph = _safe_text(summary.get("epitaph", "Their story lives on in those they touched."), 300)
    embed = discord.Embed(
        title="A life remembered",
        description=f"*{epitaph}*",
        color=discord.Color.dark_grey(),
    )
    if avatar_url:
        embed.set_author(name=f"{name} · Age {age}", icon_url=avatar_url)
    else:
        embed.set_author(name=f"{name} · Age {age}")
    years = f"{_calendar_year(summary.get('born_at'))}–{_calendar_year(summary.get('died_at'))}"
    embed.add_field(
        name="Years and cause",
        value=f"{years} · Age {age} · {cause}\nGeneration {int(summary.get('generation', 1))}",
        inline=True,
    )
    embed.add_field(
        name="Life score",
        value=f"**{float(summary.get('life_score', 0.0)):.2f}/100 · Grade {summary.get('grade', 'F')}**\n"
              f"Legacy points earned: {int(summary.get('legacy_points', 0))}",
        inline=True,
    )
    education = summary.get("education") or {}
    education_text = str(education.get("level", "none")).replace("_", " ").title()
    if education.get("major"):
        education_text += f" · {_safe_text(education['major'], 70)}"
    if education.get("gpa") is not None:
        education_text += f" · GPA {float(education['gpa']):.2f}"
    careers = summary.get("careers") or []
    career_lines = [
        f"{_safe_text(str(row.get('career_id', 'career')).replace('_', ' ').title(), 60)} "
        f"(level {int(row.get('max_level', 0))}, ages {int(row.get('start_age', 0))}–"
        f"{int(row.get('end_age') if row.get('end_age') is not None else age)})"
        for row in careers[:5]
    ]
    if len(careers) > 5:
        career_lines.append(f"…and {len(careers) - 5} more career(s)")
    embed.add_field(
        name="Education and careers",
        value=f"Education: {education_text}\n" + ("\n".join(career_lines) or "No recorded career history."),
        inline=False,
    )
    peak = int(summary.get("peak_net_worth_cents", 0))
    final = int(summary.get("final_net_worth_cents", 0))
    assets = int(summary.get("gross_assets_cents", 0))
    debt_paid = int(summary.get("debts_paid_cents", 0))
    tax = int(summary.get("estate_tax_cents", 0))
    estate = int(summary.get("estate_cents", 0))
    embed.add_field(
        name="Financial life",
        value=(
            f"Peak net worth: {format_cents(peak)}\nFinal net worth: {format_cents(final)}\n"
            f"Gross estate: {format_cents(assets)} · Debts paid: {format_cents(debt_paid)}\n"
            f"Estate tax: {format_cents(tax)} · Remaining estate: {format_cents(estate)}"
        ),
        inline=True,
    )
    children = summary.get("children") or []
    marriages = summary.get("marriages") or []
    names = [
        _safe_text(row.get("name", "Child"), 48)
        for row in children[:6]
    ]
    if len(children) > 6:
        names.append(f"…and {len(children) - 6} more")
    family_text = (
        f"Marriages: {int(summary.get('marriage_count', len(marriages)))} · "
        f"Longest: {int(summary.get('marriage_years', 0))} years\n"
        f"Children: {int(summary.get('child_count', len(children)))}"
    )
    if names:
        family_text += "\n" + ", ".join(names)
    embed.add_field(name="Family", value=family_text, inline=True)
    crime = summary.get("crime") or {}
    embed.add_field(
        name="Crime and prison",
        value=(
            f"Attempts: {int(crime.get('attempts', 0))} · Successful: {int(crime.get('successes', 0))}\n"
            f"Unsealed convictions: {int(crime.get('convictions', 0))} · Sealed: {int(crime.get('sealed_convictions', 0))}\n"
            f"Years served: {int(crime.get('years_in_prison', 0))} · Escaped: {'Yes' if crime.get('escaped') else 'No'}"
        ),
        inline=False,
    )
    logs = summary.get("life_log_top") or []
    for page_start in range(0, min(len(logs), 10), 5):
        page = logs[page_start:page_start + 5]
        value = "\n".join(
            f"**Age {int(row.get('age', 0))} · {int(row.get('importance', 1))}/5** — "
            f"{_safe_text(row.get('text', ''), 150)}"
            for row in page
        )
        embed.add_field(name=f"Important moments · {page_start + 1}–{page_start + len(page)}", value=value or "None", inline=False)
    earned = summary.get("achievements") or []
    labels = achievement_names or {}
    award_names = [
        _safe_text(labels.get(str(row.get("achievement_id", "")), str(row.get("achievement_id", "")).replace("_", " ").title()), 64)
        for row in earned
    ]
    if len(award_names) > 16:
        award_names = award_names[:16] + [f"…and {len(earned) - 16} more"]
    embed.add_field(
        name=f"Achievements earned this life · {len(earned)}",
        value=", ".join(award_names) if award_names else "No achievements were recorded during this life.",
        inline=False,
    )
    embed.set_footer(text=f"Life #{int(summary.get('char_id', 0))} · Average yearly happiness {float(summary.get('average_happiness', 0.0)):.1f}/100")
    return embed


def leaderboard_embed(result: LeaderboardResult, page: int, page_size: int = 10) -> discord.Embed:
    """Render one deterministic page of ten leaderboard entries."""
    start = page * page_size
    entries = result.entries[start:start + page_size]
    label = METRICS[result.metric]
    lines: list[str] = []
    for row in entries:
        value = row["value"]
        if result.metric == "net_worth":
            rendered = format_cents(int(value))
        elif result.metric == "life_score":
            rendered = f"{float(value):.2f}"
        elif result.metric == "gambling":
            rendered = format_cents(int(value))
        else:
            rendered = f"{int(value):,}"
        lines.append(f"**{int(row['rank']):>3}.** Player `{int(row['user_id'])}` — **{rendered}**")
    scope_text = "this server" if result.scope == "server" else "global"
    period_text = "current life" if result.period == "current" else "all-time"
    embed = discord.Embed(
        title=f"{label} leaderboard",
        description="\n".join(lines) if lines else "No eligible players are recorded for this ranking yet.",
        color=discord.Color.blurple(),
    )
    embed.set_footer(text=f"{scope_text.title()} · {period_text.title()} · Sorted by score, then account ID")
    return embed


class EmbedPager(LifelineView):
    """Owner-only, nonce-protected pager for read-only leaderboard/archive pages."""

    def __init__(self, owner_id: int, embeds: Sequence[discord.Embed], *, timeout: float = 180.0) -> None:
        super().__init__(timeout=timeout)
        self.owner_id = int(owner_id)
        self.nonce = secrets.token_urlsafe(10)
        self.embeds = tuple(embeds) or (discord.Embed(description="No results."),)
        self.page = 0
        self._message: Optional[discord.Message] = None
        previous = discord.ui.Button(
            label="Previous", style=discord.ButtonStyle.secondary,
            custom_id=f"legacy-page:{self.nonce}:previous", row=0,
        )
        next_page = discord.ui.Button(
            label="Next", style=discord.ButtonStyle.primary,
            custom_id=f"legacy-page:{self.nonce}:next", row=0,
        )
        previous.callback = self.previous
        next_page.callback = self.next
        self.add_item(previous)
        self.add_item(next_page)
        self._sync_buttons()

    def bind_message(self, message: discord.Message) -> None:
        """Remember the sent message for timeout control removal."""
        self._message = message

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        """Require the owning player and a custom ID bearing this view's nonce."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Only the player who opened these pages can navigate them.", ephemeral=True)
            return False
        custom_id = (interaction.data or {}).get("custom_id", "")
        if not str(custom_id).startswith(f"legacy-page:{self.nonce}:"):
            await interaction.response.send_message("This page control is stale. Reopen the command.", ephemeral=True)
            return False
        return True

    async def previous(self, interaction: discord.Interaction) -> None:
        """Show the preceding page and disable unavailable controls."""
        self.page = max(0, self.page - 1)
        self._sync_buttons()
        await interaction.response.edit_message(embed=self.embeds[self.page], view=self)

    async def next(self, interaction: discord.Interaction) -> None:
        """Show the following page and disable unavailable controls."""
        self.page = min(len(self.embeds) - 1, self.page + 1)
        self._sync_buttons()
        await interaction.response.edit_message(embed=self.embeds[self.page], view=self)

    def _sync_buttons(self) -> None:
        """Disable navigation at page boundaries."""
        for child in self.children:
            if isinstance(child, discord.ui.Button):
                child.disabled = (
                    (child.label == "Previous" and self.page == 0)
                    or (child.label == "Next" and self.page >= len(self.embeds) - 1)
                )

    async def on_timeout(self) -> None:
        """Disable controls when the page interaction expires."""
        self.disable_all_items()
        if self._message is not None:
            try:
                await self._message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Could not disable a timed-out Stage 10 pager", exc_info=True)


class HeirSelectView(LifelineView):
    """Owner-checked paginated heir selection with a fresh-life escape option."""

    def __init__(
        self,
        owner_id: int,
        estate_id: int,
        nonce: str,
        heirs: Sequence[dict[str, Any]],
        service: DeathService,
        *,
        page: int = 0,
        timeout: float = 600.0,
    ) -> None:
        super().__init__(timeout=timeout)
        self.owner_id = int(owner_id)
        self.estate_id = int(estate_id)
        self.nonce = nonce
        self.heirs = tuple(sorted((dict(row) for row in heirs), key=lambda row: int(row["npc_id"])))
        self.service = service
        self.page = max(0, page)
        self._used = False
        self._message: Optional[discord.Message] = None
        self._render_select()
        previous = discord.ui.Button(
            label="Previous heirs", style=discord.ButtonStyle.secondary,
            custom_id=f"estate:{self.nonce}:previous", row=1,
            disabled=self.page == 0,
        )
        next_page = discord.ui.Button(
            label="More heirs", style=discord.ButtonStyle.secondary,
            custom_id=f"estate:{self.nonce}:next", row=1,
            disabled=(self.page + 1) * 25 >= len(self.heirs),
        )
        fresh = discord.ui.Button(
            label="Start a fresh life", style=discord.ButtonStyle.danger,
            custom_id=f"estate:{self.nonce}:fresh", row=1,
        )
        previous.callback = self.previous
        next_page.callback = self.next
        fresh.callback = self.start_fresh
        self.add_item(previous)
        self.add_item(next_page)
        self.add_item(fresh)

    def bind_message(self, message: discord.Message) -> None:
        """Remember the message so controls are disabled after timeout."""
        self._message = message

    def _render_select(self) -> None:
        """Render one page of up to 25 eligible heirs."""
        start = self.page * 25
        page_rows = self.heirs[start:start + 25]
        options = [
            discord.SelectOption(
                label=_safe_text(row.get("name", "Heir"), 100),
                value=str(int(row["npc_id"])),
                description=_safe_text(
                    f"Age {int(row['age'])} · inherits {format_cents(int(row.get('inheritance_cents', 0)))}",
                    100,
                ),
            )
            for row in page_rows
        ]
        select = discord.ui.Select(
            placeholder="Choose a living adult child to continue the family",
            min_values=1,
            max_values=1,
            options=options,
            custom_id=f"estate:{self.nonce}:select:{self.page}",
            row=0,
        )
        select.callback = self.choose
        self.add_item(select)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        """Require the estate owner, current nonce, and an unused selection."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This inheritance choice belongs to another player.", ephemeral=True)
            return False
        custom_id = (interaction.data or {}).get("custom_id", "")
        if self._used or not str(custom_id).startswith(f"estate:{self.nonce}:"):
            await interaction.response.send_message("This inheritance choice is stale or already used.", ephemeral=True)
            return False
        return await allow_unbanned_user(interaction, self.service.db)

    async def choose(self, interaction: discord.Interaction) -> None:
        """Validate and continue as the selected child in one transaction."""
        try:
            selected_id = int((interaction.data or {}).get("values", ["0"])[0])
            heir = await self.service.choose_heir(
                self.owner_id, self.estate_id, self.nonce, selected_id
            )
        except (ValueError, GameError) as exc:
            message = exc.message if isinstance(exc, GameError) else "That heir selection is invalid."
            await interaction.response.send_message(message, ephemeral=True)
            return
        self._finish()
        name = _safe_text(heir.name if heir is not None else "your heir", 80)
        age = heir.age if heir is not None else 0
        await interaction.response.edit_message(
            content=f"The family continues with **{name}**, age {age}. Inheritance was split among eligible adult children.",
            embed=None,
            view=self,
        )
        await self._send_unlock_notices(interaction)

    async def start_fresh(self, interaction: discord.Interaction) -> None:
        """Close the pending estate without transferring money so `/start` can begin fresh."""
        try:
            await self.service.choose_heir(self.owner_id, self.estate_id, self.nonce, None)
        except GameError as exc:
            await interaction.response.send_message(exc.message, ephemeral=True)
            return
        self._finish()
        await interaction.response.edit_message(
            content="Inheritance declined. Use `/start` to begin a fresh life; no estate was transferred.",
            embed=None,
            view=self,
        )

    async def previous(self, interaction: discord.Interaction) -> None:
        """Display the prior page of eligible heirs."""
        if self.page <= 0:
            await interaction.response.send_message("There are no earlier heirs.", ephemeral=True)
            return
        self.page -= 1
        self._rebuild()
        await interaction.response.edit_message(view=self)

    async def next(self, interaction: discord.Interaction) -> None:
        """Display the next page of eligible heirs."""
        if (self.page + 1) * 25 >= len(self.heirs):
            await interaction.response.send_message("There are no more heirs.", ephemeral=True)
            return
        self.page += 1
        self._rebuild()
        await interaction.response.edit_message(view=self)

    def _rebuild(self) -> None:
        """Recreate the select menu and synchronize paging buttons."""
        self.clear_items()
        self._render_select()
        previous = discord.ui.Button(
            label="Previous heirs", style=discord.ButtonStyle.secondary,
            custom_id=f"estate:{self.nonce}:previous", row=1, disabled=self.page == 0,
        )
        next_page = discord.ui.Button(
            label="More heirs", style=discord.ButtonStyle.secondary,
            custom_id=f"estate:{self.nonce}:next", row=1,
            disabled=(self.page + 1) * 25 >= len(self.heirs),
        )
        fresh = discord.ui.Button(
            label="Start a fresh life", style=discord.ButtonStyle.danger,
            custom_id=f"estate:{self.nonce}:fresh", row=1,
        )
        previous.callback = self.previous
        next_page.callback = self.next
        fresh.callback = self.start_fresh
        self.add_item(previous)
        self.add_item(next_page)
        self.add_item(fresh)

    def _finish(self) -> None:
        """Disable this one-use inheritance menu."""
        self._used = True
        self.disable_all_items()
        self.stop()

    async def _send_unlock_notices(self, interaction: discord.Interaction) -> None:
        """Send congratulatory embeds for achievements unlocked with the new heir."""
        notices = self.service.achievements.consume_notifications(self.owner_id)
        if not notices:
            return
        names = ", ".join(_safe_text(row["name"], 70) for row in notices[:5])
        embed = discord.Embed(title="Achievement unlocked!", description=names, color=discord.Color.gold())
        await interaction.followup.send(embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    async def on_timeout(self) -> None:
        """Disable the visible inheritance controls after ten minutes."""
        self.disable_all_items()
        if self._message is not None:
            try:
                await self._message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Could not disable expired heir controls", exc_info=True)


class RetirementConfirmView(LifelineView):
    """Owner-only confirmation controls for one retirement prompt."""

    def __init__(
        self,
        owner_id: int,
        prompt: RetirementPrompt,
        service: DeathService,
        *,
        achievement_names: Optional[dict[str, str]] = None,
        avatar_url: Optional[str] = None,
    ) -> None:
        super().__init__(timeout=max(30, prompt.expires_at - __import__("time").time()))
        self.owner_id = int(owner_id)
        self.prompt = prompt
        self.service = service
        self.achievement_names = achievement_names or {}
        self.avatar_url = avatar_url
        self._used = False
        self._message: Optional[discord.Message] = None
        confirm = discord.ui.Button(
            label="Confirm retirement", style=discord.ButtonStyle.danger,
            custom_id=f"retire:{prompt.nonce}:confirm",
        )
        cancel = discord.ui.Button(
            label="Keep living", style=discord.ButtonStyle.secondary,
            custom_id=f"retire:{prompt.nonce}:cancel",
        )
        confirm.callback = self.confirm
        cancel.callback = self.cancel
        self.add_item(confirm)
        self.add_item(cancel)

    def bind_message(self, message: discord.Message) -> None:
        """Remember the confirmation message for timeout cleanup."""
        self._message = message

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        """Authorize only the owner and the custom IDs carrying the saved nonce."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Only the player who opened this confirmation can respond.", ephemeral=True)
            return False
        custom_id = (interaction.data or {}).get("custom_id", "")
        if self._used or not str(custom_id).startswith(f"retire:{self.prompt.nonce}:"):
            await interaction.response.send_message("This retirement confirmation is stale or already used.", ephemeral=True)
            return False
        return await allow_unbanned_user(interaction, self.service.db)

    async def confirm(self, interaction: discord.Interaction) -> None:
        """Confirm retirement and render its no-legacy, no-heir archive."""
        try:
            result = await self.service.confirm_retirement(
                self.owner_id, self.prompt.prompt_id, self.prompt.nonce,
                guild_id=interaction.guild_id,
            )
        except GameError as exc:
            self._finish()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
            return
        self._finish()
        embed = death_summary_embed(
            result.summary, avatar_url=self.avatar_url,
            achievement_names=self.achievement_names,
        )
        embed.set_footer(text="Life abandoned · no legacy points or heir continuation awarded")
        await interaction.response.edit_message(content=None, embed=embed, view=self)
        await self._send_unlock_notices(interaction)

    async def cancel(self, interaction: discord.Interaction) -> None:
        """Cancel the one-time retirement prompt without changing life state."""
        await self.service.cancel_retirement(
            self.owner_id, self.prompt.prompt_id, self.prompt.nonce
        )
        self._finish()
        await interaction.response.edit_message(
            content="Retirement cancelled. Your life remains active.", embed=None, view=self
        )

    def _finish(self) -> None:
        """Disable both controls after a terminal confirmation result."""
        self._used = True
        self.disable_all_items()
        self.stop()

    async def _send_unlock_notices(self, interaction: discord.Interaction) -> None:
        """Send any achievements earned before retirement without granting points."""
        notices = self.service.achievements.consume_notifications(self.owner_id)
        if not notices:
            return
        embed = discord.Embed(
            title="Achievement unlocked!",
            description="\n".join(f"🏆 **{_safe_text(row['name'], 80)}**" for row in notices[:5]),
            color=discord.Color.gold(),
        )
        await interaction.followup.send(embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    async def on_timeout(self) -> None:
        """Expire the stored confirmation and disable its visible buttons."""
        if not self._used:
            try:
                await self.service.cancel_retirement(
                    self.owner_id, self.prompt.prompt_id, self.prompt.nonce
                )
            except Exception:
                logger.debug("Could not mark a timed-out retirement prompt", exc_info=True)
        self.disable_all_items()
        if self._message is not None:
            try:
                await self._message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Could not disable expired retirement controls", exc_info=True)
