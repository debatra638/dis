"""Stage 9 /casino commands and owner/nonce-protected game controls."""
from __future__ import annotations

import logging
import json
from typing import Any, Optional

import discord
from discord import app_commands
from discord.ext import commands

from core.achievements import AchievementService
from core.casino import CasinoReceipt, CasinoService
from core.embeds import EmbedColors, safe_text as escape_user_text
from core.errors import GameError
from core.investing import InvestingService
from core.money import dollars_to_cents, format_cents
from core.repositories.settings import SettingsRepository
from core.views import allow_unbanned_user
from cogs.legacy_views import check_and_notify_achievements

logger = logging.getLogger("lifeline.casino.cog")


class _BlackjackButton(discord.ui.Button["BlackjackView"]):
    """One dynamically nonce-stamped blackjack action."""

    def __init__(self, label: str, action: str, session_id: int, nonce: str, *, disabled: bool = False) -> None:
        styles = {"hit": discord.ButtonStyle.primary, "stand": discord.ButtonStyle.secondary, "double": discord.ButtonStyle.success}
        super().__init__(
            label=label,
            style=styles[action],
            custom_id=f"bj:{session_id}:{nonce}:{action}",
            disabled=disabled,
        )
        self.action = action

    async def callback(self, interaction: discord.Interaction) -> None:
        if self.view is None:
            return
        await self.view.handle_action(interaction, self.action)


class BlackjackView(discord.ui.View):
    """Ephemeral Hit/Stand/Double controls bound to the initiating player and nonce."""

    def __init__(
        self,
        owner_id: int,
        service: CasinoService,
        session_id: int,
        nonce: str,
        *,
        can_double: bool = True,
        achievement_service: Optional[AchievementService] = None,
    ) -> None:
        super().__init__(timeout=120.0)
        self.owner_id = owner_id
        self.service = service
        self.achievement_service = achievement_service
        self.session_id = session_id
        self.nonce = nonce
        self.message: Optional[discord.Message] = None
        self.add_item(_BlackjackButton("Hit", "hit", session_id, nonce))
        self.add_item(_BlackjackButton("Stand", "stand", session_id, nonce))
        self.add_item(_BlackjackButton("Double", "double", session_id, nonce, disabled=not can_double))

    def bind_message(self, message: discord.Message) -> None:
        """Keep the ephemeral message reference for the two-minute auto-stand."""
        self.message = message

    def _disable(self) -> None:
        """Disable consumed controls before this view is replaced or expires."""
        for child in self.children:
            if isinstance(child, discord.ui.Button):
                child.disabled = True
        self.stop()

    async def handle_action(self, interaction: discord.Interaction, action: str) -> None:
        """Owner-check, defer the component interaction, and call the nonce-guarded service."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                "This blackjack hand belongs to another player.", ephemeral=True,
                allowed_mentions=discord.AllowedMentions.none(),
            )
            return
        if not await allow_unbanned_user(interaction, self.service.db):
            return
        await interaction.response.defer()
        try:
            receipt = await self.service.blackjack_action(
                interaction.user.id, self.session_id, self.nonce, action
            )
        except GameError as exc:
            await interaction.followup.send(exc.message, ephemeral=True)
            return
        except Exception:
            logger.exception("Blackjack button action failed for session %s", self.session_id)
            await interaction.followup.send("The hand could not be updated. Please try again.", ephemeral=True)
            return
        self._disable()
        next_view: Optional[BlackjackView] = None
        if receipt.status == "active" and receipt.session_id is not None and receipt.nonce is not None:
            cards = receipt.outcome.get("player", [])
            next_view = BlackjackView(
                self.owner_id, self.service, receipt.session_id, receipt.nonce,
                can_double=len(cards) == 2,
                achievement_service=self.achievement_service,
            )
        try:
            message = await interaction.edit_original_response(content=None, embed=_receipt_embed(receipt), view=next_view)
            if next_view is not None:
                next_view.bind_message(message)
        except discord.HTTPException:
            logger.exception("Could not refresh blackjack hand %s", self.session_id)
        if receipt.status == "settled":
            await _post_public_receipt(interaction.channel, interaction.user, self.service, receipt)
        await check_and_notify_achievements(
            interaction, self.achievement_service, interaction.user.id
        )

    async def on_timeout(self) -> None:
        """Auto-stand after two minutes, settle once, and remove the expired controls."""
        try:
            receipt = await self.service.blackjack_action(
                self.owner_id, self.session_id, self.nonce, "stand", auto_stand=True
            )
            self._disable()
            if self.message is not None:
                await self.message.edit(content=None, embed=_receipt_embed(receipt), view=None)
                if receipt.status == "settled":
                    await _post_public_receipt(
                        self.message.channel, discord.Object(id=self.owner_id), self.service, receipt
                    )
        except GameError:
            self._disable()
            if self.message is not None:
                try:
                    await self.message.edit(view=None)
                except discord.HTTPException:
                    logger.info("Timed-out blackjack message %s was already unavailable", self.session_id)
        except Exception:
            logger.exception("Blackjack timeout settlement failed for session %s", self.session_id)
            self._disable()
            if self.message is not None:
                try:
                    await self.message.edit(view=None)
                except discord.HTTPException:
                    logger.info("Could not remove expired blackjack controls for %s", self.session_id)


class _CompulsionButton(discord.ui.Button["CompulsionView"]):
    """One owner-bound addiction-event choice with a persistent nonce."""

    def __init__(self, label: str, choice: str, compulsion_id: int, nonce: str, *, style: discord.ButtonStyle) -> None:
        super().__init__(
            label=label,
            style=style,
            custom_id=f"compulsion:{compulsion_id}:{nonce}:{choice}",
        )
        self.choice = choice

    async def callback(self, interaction: discord.Interaction) -> None:
        if self.view is not None:
            await self.view.resolve(interaction, self.choice)


class CompulsionView(discord.ui.View):
    """Resist/indulge gambling-addiction event controls."""

    def __init__(
        self,
        owner_id: int,
        service: CasinoService,
        prompt: dict[str, object],
        achievement_service: Optional[AchievementService] = None,
    ) -> None:
        super().__init__(timeout=300.0)
        self.owner_id = owner_id
        self.service = service
        self.achievement_service = achievement_service
        self.compulsion_id = int(prompt["compulsion_id"])
        self.nonce = str(prompt["nonce"])
        self.message: Optional[discord.Message] = None
        self.add_item(_CompulsionButton("Resist", "resist", self.compulsion_id, self.nonce, style=discord.ButtonStyle.success))
        self.add_item(_CompulsionButton("Indulge · place forced bet", "indulge", self.compulsion_id, self.nonce, style=discord.ButtonStyle.danger))

    def bind_message(self, message: discord.Message) -> None:
        """Bind the prompt message for timeout cleanup."""
        self.message = message

    async def resolve(self, interaction: discord.Interaction, choice: str) -> None:
        """Owner-check and atomically consume the compulsion prompt."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                "This choice belongs to another player.", ephemeral=True,
                allowed_mentions=discord.AllowedMentions.none(),
            )
            return
        if not await allow_unbanned_user(interaction, self.service.db):
            return
        await interaction.response.defer()
        try:
            result = await self.service.resolve_compulsion(
                interaction.user.id, self.compulsion_id, self.nonce, choice
            )
        except GameError as exc:
            await interaction.followup.send(exc.message, ephemeral=True)
            return
        except Exception:
            logger.exception("Gambling compulsion resolution failed for %s", self.compulsion_id)
            await interaction.followup.send("The choice could not be saved. Please try again.", ephemeral=True)
            return
        for child in self.children:
            if isinstance(child, discord.ui.Button):
                child.disabled = True
        self.stop()
        await interaction.edit_original_response(content=result.message, embed=None, view=None)
        if result.receipt is not None:
            await _post_public_receipt(interaction.channel, interaction.user, self.service, result.receipt)
        await check_and_notify_achievements(
            interaction, self.achievement_service, interaction.user.id
        )

    async def on_timeout(self) -> None:
        """Default an unattended addiction prompt to resisting, without placing a bet."""
        try:
            await self.service.resolve_compulsion(
                self.owner_id, self.compulsion_id, self.nonce, "resist"
            )
        except GameError:
            logger.info("Compulsion choice %s was already resolved or expired", self.compulsion_id)
        except Exception:
            logger.exception("Compulsion timeout resolution failed for %s", self.compulsion_id)
        for child in self.children:
            if isinstance(child, discord.ui.Button):
                child.disabled = True
        self.stop()
        if self.message is not None:
            try:
                await self.message.edit(view=None)
            except discord.HTTPException:
                logger.info("Compulsion message %s was already unavailable", self.compulsion_id)


def _receipt_embed(receipt: CasinoReceipt) -> discord.Embed:
    """Create a compact private casino outcome embed from a service receipt."""
    color = discord.Color.gold() if receipt.status == "active" else (discord.Color.green() if (receipt.net_cents or 0) > 0 else discord.Color.blurple())
    embed = discord.Embed(title=f"{receipt.game.title()}", description=receipt.message, color=color)
    if receipt.status == "settled" and receipt.payout_cents is not None:
        embed.add_field(name="Wager", value=format_cents(receipt.bet_cents), inline=True)
        embed.add_field(name="Gross return", value=format_cents(receipt.payout_cents), inline=True)
        embed.add_field(name="Net", value=format_cents(receipt.net_cents or 0, include_plus=True), inline=True)
    return embed


def _public_receipt_embed(user: discord.abc.User, receipt: CasinoReceipt) -> discord.Embed:
    """Build a small public receipt containing only the settled wager and result."""
    display_name = escape_user_text(getattr(user, "display_name", getattr(user, "name", "Player")))
    result = discord.Embed(
        title=f"{display_name} · {receipt.game.title()} result",
        description="A fictional in-game casino result was posted according to the player's privacy setting.",
        color=EmbedColors.POSITIVE if (receipt.net_cents or 0) > 0 else EmbedColors.NEUTRAL,
    )
    if receipt.payout_cents is not None:
        result.add_field(name="Wager", value=format_cents(receipt.bet_cents), inline=True)
        result.add_field(name="Gross return", value=format_cents(receipt.payout_cents), inline=True)
        result.add_field(name="Net", value=format_cents(receipt.net_cents or 0, include_plus=True), inline=True)
    result.set_footer(text="In-game currency only · No real-money gambling or cash-out")
    return result


async def _public_result_allowed(service: CasinoService, user_id: int) -> bool:
    """Fail closed when a privacy preference cannot be checked."""
    try:
        async with service.db.transaction() as tx:
            settings = await SettingsRepository(service.db).get(tx, int(user_id))
        return bool(settings.public_casino_results)
    except Exception:
        logger.exception("Could not read casino privacy setting for user %s", user_id)
        return False


async def _post_public_receipt(
    channel: discord.abc.Messageable | None,
    user: discord.abc.User,
    service: CasinoService,
    receipt: CasinoReceipt,
) -> None:
    """Post one privacy-approved settled receipt; all failures leave the private result intact."""
    if (
        channel is None or receipt.status != "settled"
        or not await _public_result_allowed(service, int(user.id))
    ):
        return
    try:
        await channel.send(
            embed=_public_receipt_embed(user, receipt),
            allowed_mentions=discord.AllowedMentions.none(),
        )
    except discord.HTTPException:
        logger.info("Public casino result could not be posted for user %s", user.id, exc_info=True)


class CasinoCog(commands.Cog):
    """Casino slash-command group with server-validated age, funds, and cooldown gates."""

    casino = app_commands.Group(name="casino", description="Play fictional, in-game casino games")

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        service = getattr(bot, "casino_service", None)
        if service is None:
            service = CasinoService(bot.db, bot.rng, getattr(bot, "locks", None))
            bot.casino_service = service
        self.service: CasinoService = service
        self.achievement_service = getattr(bot, "achievement_service", None)
        investing = getattr(bot, "investing_service", None)
        if investing is None:
            investing = InvestingService(bot.db, bot.rng, getattr(bot, "locks", None))
            bot.investing_service = investing
        self.investing_service: InvestingService = investing

    @casino.command(name="slots", description="Spin three weighted reels at a documented 92% RTP")
    @app_commands.describe(bet="Wager in dollars, from $1 up to your balance/price-index cap")
    async def slots(self, interaction: discord.Interaction, bet: float) -> None:
        """Run a weighted three-reel slot spin."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        receipt = await self.service.play_slots(interaction.user.id, dollars_to_cents(bet))
        await interaction.followup.send(embed=_receipt_embed(receipt), ephemeral=True)
        await _post_public_receipt(interaction.channel, interaction.user, self.service, receipt)

    @casino.command(name="blackjack", description="Start an interactive six-deck blackjack hand")
    @app_commands.describe(bet="Wager in dollars; Hit, Stand, or Double within two minutes")
    async def blackjack(self, interaction: discord.Interaction, bet: float) -> None:
        """Start a hand and attach owner-checked Hit/Stand/Double buttons."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        receipt = await self.service.blackjack_start(interaction.user.id, dollars_to_cents(bet))
        view: Optional[BlackjackView] = None
        if receipt.status == "active" and receipt.session_id is not None and receipt.nonce is not None:
            cards = receipt.outcome.get("player", [])
            view = BlackjackView(
                interaction.user.id, self.service, receipt.session_id, receipt.nonce,
                can_double=len(cards) == 2, achievement_service=self.achievement_service,
            )
        message = await interaction.followup.send(embed=_receipt_embed(receipt), view=view, ephemeral=True, wait=True)
        if view is not None:
            view.bind_message(message)
        await _post_public_receipt(interaction.channel, interaction.user, self.service, receipt)

    @casino.command(name="roulette", description="Play European single-zero roulette")
    @app_commands.describe(
        bet_type="Outside bet, dozen, or straight-up number",
        bet="Wager in dollars",
        number="For dozen use 1–3; for straight use 0–36; omit otherwise",
    )
    @app_commands.choices(bet_type=[
        app_commands.Choice(name="Red", value="red"),
        app_commands.Choice(name="Black", value="black"),
        app_commands.Choice(name="Odd", value="odd"),
        app_commands.Choice(name="Even", value="even"),
        app_commands.Choice(name="Dozen", value="dozen"),
        app_commands.Choice(name="Straight number", value="straight"),
    ])
    async def roulette(
        self,
        interaction: discord.Interaction,
        bet_type: str,
        bet: float,
        number: Optional[int] = None,
    ) -> None:
        """Spin a single-zero wheel and settle one selected roulette wager."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        receipt = await self.service.play_roulette(
            interaction.user.id, bet_type, dollars_to_cents(bet), number
        )
        await interaction.followup.send(embed=_receipt_embed(receipt), ephemeral=True)
        await _post_public_receipt(interaction.channel, interaction.user, self.service, receipt)

    @casino.command(name="coinflip", description="Bet heads or tails; a win returns 1.94 times the wager")
    @app_commands.describe(side="Choose heads or tails", bet="Wager in dollars")
    @app_commands.choices(side=[
        app_commands.Choice(name="Heads", value="heads"),
        app_commands.Choice(name="Tails", value="tails"),
    ])
    async def coinflip(self, interaction: discord.Interaction, side: str, bet: float) -> None:
        """Settle a 1.94x-gross coinflip wager."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        receipt = await self.service.play_coinflip(interaction.user.id, side, dollars_to_cents(bet))
        await interaction.followup.send(embed=_receipt_embed(receipt), ephemeral=True)
        await _post_public_receipt(interaction.channel, interaction.user, self.service, receipt)

    @casino.command(name="compulsion", description="Reopen a pending gambling-addiction choice")
    async def resume_compulsion(self, interaction: discord.Interaction) -> None:
        """Reopen a persisted resist/indulge prompt after a reconnect."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        prompt = await self.service.get_pending_compulsion(interaction.user.id)
        view = CompulsionView(
            interaction.user.id, self.service, prompt, self.achievement_service
        )
        amount = int(prompt["forced_bet_cents"])
        message = await interaction.followup.send(
            f"Gambling compulsion: resist, or indulge in a forced wager of {format_cents(amount)}.",
            view=view, ephemeral=True, wait=True,
        )
        view.bind_message(message)


async def setup(bot: commands.Bot) -> None:
    """Register the Stage 9 casino command group."""
    await bot.add_cog(CasinoCog(bot))
