"""Player privacy and leaderboard preference slash commands."""
from __future__ import annotations

import time

import discord
from discord import app_commands
from discord.ext import commands

from core.embeds import EmbedColors
from core.errors import ValidationError
from core.locks import UserLockRegistry
from core.repositories.settings import PlayerSettings, SettingsRepository


def _visibility(value: bool) -> str:
    """Render a boolean public preference without ambiguous wording."""
    return "Public" if value else "Private"


def _settings_embed(settings: PlayerSettings) -> discord.Embed:
    """Build a consistent private summary of one player's public-output settings."""
    embed = discord.Embed(
        title="Your privacy settings",
        description="Choose which game summaries may be posted publicly. Error messages and private details remain ephemeral.",
        color=EmbedColors.SETTINGS,
    )
    embed.add_field(name="Year summaries", value=_visibility(settings.public_year_summaries), inline=True)
    embed.add_field(name="Death summaries", value=_visibility(settings.public_deaths), inline=True)
    embed.add_field(name="Casino results", value=_visibility(settings.public_casino_results), inline=True)
    embed.add_field(name="Leaderboards", value=_visibility(settings.public_leaderboards), inline=True)
    embed.set_footer(text="Public result settings default to Public; you can change them at any time.")
    return embed


class SettingsCog(commands.Cog):
    """Persist individual privacy choices and expose only private confirmation replies."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.db = bot.db
        self.locks: UserLockRegistry = getattr(bot, "locks", UserLockRegistry())
        self.repository = SettingsRepository(self.db)
        self.clock = getattr(bot, "clock", time.time)

    settings = app_commands.Group(
        name="settings",
        description="Manage public game-result and leaderboard visibility",
    )

    @settings.command(name="privacy", description="Choose which year, death, and casino summaries may be public")
    @app_commands.describe(
        year_summaries="Publicly post a brief life-year summary after /life age",
        deaths="Allow a death summary to be posted in servers that permit it",
        casino_results="Publicly post a short casino receipt after a settled game",
    )
    async def privacy(
        self,
        interaction: discord.Interaction,
        year_summaries: bool | None = None,
        deaths: bool | None = None,
        casino_results: bool | None = None,
    ) -> None:
        """Update any supplied summary-visibility toggles; omitted choices stay unchanged."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        if year_summaries is None and deaths is None and casino_results is None:
            current = await self._get_settings(interaction.user.id)
            await interaction.followup.send(embed=_settings_embed(current), ephemeral=True)
            return
        async with self.locks.hold(int(interaction.user.id)):
            async with self.db.transaction() as tx:
                updated = await self.repository.update_privacy(
                    tx,
                    user_id=int(interaction.user.id),
                    now=int(self.clock()),
                    public_year_summaries=year_summaries,
                    public_deaths=deaths,
                    public_casino_results=casino_results,
                )
        await interaction.followup.send(embed=_settings_embed(updated), ephemeral=True)

    @settings.command(name="leaderboard", description="Opt in or out of public leaderboard rankings")
    @app_commands.describe(public="True to appear in leaderboards, false to opt out")
    async def leaderboard(self, interaction: discord.Interaction, public: bool) -> None:
        """Set public leaderboard visibility and synchronize legacy privacy records."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        async with self.locks.hold(int(interaction.user.id)):
            async with self.db.transaction() as tx:
                updated = await self.repository.set_leaderboard(
                    tx, user_id=int(interaction.user.id), public=bool(public), now=int(self.clock())
                )
        if hasattr(self.bot, "leaderboards"):
            self.bot.leaderboards.clear_cache()
        await interaction.followup.send(embed=_settings_embed(updated), ephemeral=True)

    async def _get_settings(self, user_id: int) -> PlayerSettings:
        """Read one player's preferences inside a short transaction."""
        async with self.locks.hold(int(user_id)):
            async with self.db.transaction() as tx:
                return await self.repository.get(tx, int(user_id))


async def setup(bot: commands.Bot) -> None:
    """Register the Stage 11 settings group."""
    await bot.add_cog(SettingsCog(bot))
