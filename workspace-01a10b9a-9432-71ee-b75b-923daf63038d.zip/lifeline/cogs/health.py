"""Slash commands for private fictional health status and care actions."""
from __future__ import annotations

from typing import Any

import discord
from discord import app_commands
from discord.ext import commands

from core.embeds import safe_text
from core.health import HealthService
from core.money import format_cents

_ACTIVITY_CHOICES = [
    app_commands.Choice(name="Walk", value="walk"),
    app_commands.Choice(name="Run", value="run"),
    app_commands.Choice(name="Gym", value="gym"),
    app_commands.Choice(name="Mindfulness", value="mindfulness"),
    app_commands.Choice(name="Sports", value="sports"),
]
_SURGERY_CHOICES = [
    app_commands.Choice(name="Treat a severe condition", value="medical"),
    app_commands.Choice(name="Plastic surgery", value="plastic"),
]


def _status_embed(
    character: Any,
    conditions: list[dict[str, Any]],
    visits: list[dict[str, Any]],
    service: HealthService,
) -> discord.Embed:
    """Render owner-only health, diagnosis, insurance, and visit details."""
    embed = discord.Embed(
        title=f"Health · Age {character.age}",
        description=(
            f"**Health:** {character.stats.health}/100 · **Fitness:** {character.stats.fitness}/100\n"
            f"**Stress:** {character.stats.stress}/100 · **Insurance:** "
            f"{'active through age ' + str(character.insurance_paid_through_age) if character.has_insurance else 'none'}"
        ),
        color=discord.Color.teal(),
    )
    active = [row for row in conditions if bool(row["is_active"])]
    if active:
        lines = []
        for row in active[:12]:
            definition = service.diseases.get(str(row["disease_id"]), {})
            name = str(definition.get("name", "Catalog condition")) if bool(row["diagnosed"]) else "Undiagnosed condition"
            identity = f" `{safe_text(str(row['disease_id']), 40)}`" if bool(row["diagnosed"]) else ""
            lines.append(
                f"**{safe_text(name, 80)}**{identity} · severity {int(row['severity'])}/5 · "
                f"{'chronic' if str(row['status']) == 'chronic' else 'active'}"
            )
        embed.add_field(name="Active conditions", value="\n".join(lines), inline=False)
    else:
        embed.add_field(name="Conditions", value="No active conditions are recorded.", inline=False)
    if visits:
        lines = [
            f"Age {int(row['age'])}: {str(row['visit_type']).title()} · {format_cents(int(row['cost_cents']))}"
            for row in visits[:8]
        ]
        embed.add_field(name="Recent care", value="\n".join(lines), inline=False)
    embed.set_footer(text="Fictional game conditions are not medical advice. Care is supportive and PG-13.")
    return embed


class HealthCog(commands.Cog):
    """Expose medical status and server-validated care services."""

    health = app_commands.Group(name="health", description="Review wellbeing and access fictional care services")

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        service = getattr(bot, "health_service", None)
        if service is None:
            engine = getattr(bot, "life_engine", None)
            service = getattr(engine, "health", None)
        if service is None:
            economy = getattr(bot, "economy_service", None)
            if economy is None:
                raise RuntimeError("Health commands require the shared life/economy services.")
            service = HealthService(
                bot.db,
                bot.rng,
                economy,
                getattr(bot, "locks", None),
                data_loader=getattr(bot, "data_loader", None),
            )
            bot.health_service = service
        self.service: HealthService = service

    @health.command(name="status", description="View private health, diagnoses, insurance, and recent visits")
    @app_commands.checks.cooldown(1, 2.0, key=lambda interaction: interaction.user.id)
    async def health_status(self, interaction: discord.Interaction) -> None:
        """Display this user's active life only; no target-user argument is accepted."""
        character, conditions, visits = await self.service.status(interaction.user.id)
        await interaction.response.send_message(
            embed=_status_embed(character, conditions, visits, self.service), ephemeral=True
        )

    @health.command(name="doctor", description="Get a checkup, diagnosis, and basic treatment")
    @app_commands.describe(condition_id="Optional disease ID from /health status; omit for the next active condition")
    @app_commands.checks.cooldown(1, 3.0, key=lambda interaction: interaction.user.id)
    async def health_doctor(self, interaction: discord.Interaction, condition_id: str | None = None) -> None:
        """Diagnose and provide first-line care for one active catalog condition."""
        result = await self.service.doctor_visit(interaction.user.id, condition_id)
        await interaction.response.send_message(result.message, ephemeral=True)

    @health.command(name="hospital", description="Get urgent care for an active condition")
    @app_commands.describe(condition_id="Disease ID shown by /health status")
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def health_hospital(self, interaction: discord.Interaction, condition_id: str) -> None:
        """Apply hospital treatment only after server-side validation of the condition."""
        result = await self.service.hospital_visit(interaction.user.id, condition_id)
        await interaction.response.send_message(result.message, ephemeral=True)

    @health.command(name="therapy", description="Get supportive wellbeing care")
    @app_commands.checks.cooldown(1, 3.0, key=lambda interaction: interaction.user.id)
    async def health_therapy(self, interaction: discord.Interaction) -> None:
        """Offer a supportive, non-stigmatizing therapy visit."""
        result = await self.service.therapy_visit(interaction.user.id)
        await interaction.response.send_message(result.message, ephemeral=True)

    @health.command(name="activity", description="Take a once-per-year activity to support health and fitness")
    @app_commands.choices(activity=_ACTIVITY_CHOICES)
    @app_commands.checks.cooldown(1, 2.0, key=lambda interaction: interaction.user.id)
    async def health_activity(self, interaction: discord.Interaction, activity: str) -> None:
        """Apply exact, catalogued stat changes for one activity this in-game year."""
        result = await self.service.activity(interaction.user.id, activity)
        await interaction.response.send_message(result.message, ephemeral=True)

    @health.command(name="insurance", description="Buy one prepaid year of coverage or cancel the policy")
    @app_commands.describe(enabled="True to purchase/renew; False to cancel immediately")
    @app_commands.checks.cooldown(1, 3.0, key=lambda interaction: interaction.user.id)
    async def health_insurance(self, interaction: discord.Interaction, enabled: bool) -> None:
        """Manage a one-year policy; renewals are charged by annual settlement."""
        result = await self.service.set_insurance(interaction.user.id, enabled)
        await interaction.response.send_message(result.message, ephemeral=True)

    @health.command(name="surgery", description="Treat a severe condition or choose plastic surgery")
    @app_commands.describe(
        condition_id="Disease ID shown by /health status; required for medical surgery",
        procedure="Choose medical treatment or elective plastic surgery",
    )
    @app_commands.choices(procedure=_SURGERY_CHOICES)
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def health_surgery(
        self,
        interaction: discord.Interaction,
        condition_id: str | None = None,
        procedure: str = "medical",
    ) -> None:
        """Perform a deterministic, server-validated medical or cosmetic procedure."""
        result = await self.service.surgery(interaction.user.id, condition_id, procedure)
        await interaction.response.send_message(result.message, ephemeral=True)

    @app_commands.command(name="doctor", description="Alias for /health doctor")
    @app_commands.describe(condition_id="Optional disease ID from /health status; omit for the next active condition")
    @app_commands.checks.cooldown(1, 3.0, key=lambda interaction: interaction.user.id)
    async def doctor_alias(self, interaction: discord.Interaction, condition_id: str | None = None) -> None:
        """Run the shared doctor-visit service through its top-level alias."""
        result = await self.service.doctor_visit(interaction.user.id, condition_id)
        await interaction.response.send_message(result.message, ephemeral=True)

    @app_commands.command(name="hospital", description="Alias for /health hospital")
    @app_commands.describe(condition_id="Disease ID shown by /health status")
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def hospital_alias(self, interaction: discord.Interaction, condition_id: str) -> None:
        """Run the shared hospital-care service through its top-level alias."""
        result = await self.service.hospital_visit(interaction.user.id, condition_id)
        await interaction.response.send_message(result.message, ephemeral=True)

    @app_commands.command(name="therapy", description="Alias for /health therapy")
    @app_commands.checks.cooldown(1, 3.0, key=lambda interaction: interaction.user.id)
    async def therapy_alias(self, interaction: discord.Interaction) -> None:
        """Run the shared wellbeing-care service through its top-level alias."""
        result = await self.service.therapy_visit(interaction.user.id)
        await interaction.response.send_message(result.message, ephemeral=True)

    @app_commands.command(name="insurance", description="Alias for /health insurance")
    @app_commands.describe(enabled="True to purchase/renew; False to cancel immediately")
    @app_commands.checks.cooldown(1, 3.0, key=lambda interaction: interaction.user.id)
    async def insurance_alias(self, interaction: discord.Interaction, enabled: bool) -> None:
        """Run the shared insurance service through its top-level alias."""
        result = await self.service.set_insurance(interaction.user.id, enabled)
        await interaction.response.send_message(result.message, ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    """Register the health command cog."""
    await bot.add_cog(HealthCog(bot))
