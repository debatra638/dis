"""Owner-only slash commands for audited LIFELINE administration."""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from core.admin import AdminService
from core.data_loader import DataLoader
from core.embeds import EmbedColors, safe_text as escape_user_text
from core.errors import GameError
from core.life_engine import LifeEngine
from core.money import format_cents
from core.rng import RNG

logger = logging.getLogger("lifeline.cogs.admin")


async def owner_check(interaction: discord.Interaction) -> bool:
    """Enforce the configured OWNER_IDS on the server, not just in Discord's UI."""
    client = interaction.client
    config = getattr(client, "config", None)
    owner_ids = getattr(config, "owner_ids", frozenset())
    try:
        return int(interaction.user.id) in {int(value) for value in owner_ids}
    except (TypeError, ValueError):
        return False


_STAT_CHOICES = [
    app_commands.Choice(name="Health", value="health"),
    app_commands.Choice(name="Happiness", value="happiness"),
    app_commands.Choice(name="Smarts", value="smarts"),
    app_commands.Choice(name="Looks", value="looks"),
    app_commands.Choice(name="Fitness", value="fitness"),
    app_commands.Choice(name="Karma", value="karma"),
    app_commands.Choice(name="Stress", value="stress"),
    app_commands.Choice(name="Addiction", value="addiction"),
    app_commands.Choice(name="Fame", value="fame"),
]
_MARKET_CHOICES = [
    app_commands.Choice(name="Crash — reduce prices", value="crash"),
    app_commands.Choice(name="Boom — increase prices", value="boom"),
]


class AdminCog(commands.Cog):
    """Require an OWNER_IDS check and administrator UI permissions for each action."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        life_engine = getattr(bot, "life_engine", None)
        if life_engine is None:
            life_engine = LifeEngine(
                bot.db,
                getattr(bot, "rng", RNG()),
                getattr(bot, "locks", None),
                family_service=getattr(bot, "family_service", None),
                crime_service=getattr(bot, "crime_service", None),
                shop_service=getattr(bot, "shop_service", None),
                casino_service=getattr(bot, "casino_service", None),
                investing_service=getattr(bot, "investing_service", None),
                economy_service=getattr(bot, "economy_service", None),
                achievement_service=getattr(bot, "achievement_service", None),
                data_loader=getattr(bot, "data_loader", None),
            )
            bot.life_engine = life_engine
        self.service = getattr(bot, "admin_service", None) or AdminService(
            bot.db,
            life_engine,
            getattr(bot, "investing_service", life_engine.investing),
            getattr(bot, "data_loader", DataLoader()),
            clock=getattr(bot, "clock", __import__("time").time),
        )
        bot.admin_service = self.service

    admin = app_commands.Group(
        name="admin",
        description="Owner-only, fully audited bot and game administration",
        default_permissions=discord.Permissions(administrator=True),
    )

    @admin.command(name="give_money", description="Grant integer cents to a player's active life")
    @app_commands.default_permissions(administrator=True)
    @app_commands.check(owner_check)
    @app_commands.describe(
        target="Player receiving the grant",
        amount_cents="Whole cents to add to the character's cash balance",
    )
    async def give_money(
        self,
        interaction: discord.Interaction,
        target: discord.User,
        amount_cents: app_commands.Range[int, 1, 2_000_000_000],
    ) -> None:
        """Credit an active life and write the balance mutation and audit row atomically."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        character = await self.service.give_money(
            int(interaction.user.id), int(target.id), int(amount_cents)
        )
        await interaction.followup.send(
            f"Granted {format_cents(int(amount_cents))} to {_safe_user(target)}. "
            f"New cash balance: {format_cents(character.cash)}.",
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @admin.command(name="set_stat", description="Set and clamp a player's active-life stat")
    @app_commands.default_permissions(administrator=True)
    @app_commands.check(owner_check)
    @app_commands.describe(
        target="Player whose active life will be updated",
        stat="Stat to set; the saved value is clamped to game bounds",
        value="Requested integer value; stats clamp to 0–100",
    )
    @app_commands.choices(stat=_STAT_CHOICES)
    async def set_stat(
        self,
        interaction: discord.Interaction,
        target: discord.User,
        stat: str,
        value: app_commands.Range[int, -1000, 1000],
    ) -> None:
        """Set a whitelisted stat through the shared model clamp, then audit the result."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        character = await self.service.set_stat(
            int(interaction.user.id), int(target.id), stat, int(value)
        )
        actual = int(getattr(character.stats, stat))
        await interaction.followup.send(
            f"Set {_safe_user(target)}'s **{stat.title()}** to **{actual}/100** (requested {int(value)}).",
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @admin.command(name="kill", description="End and archive a player's active life")
    @app_commands.default_permissions(administrator=True)
    @app_commands.check(owner_check)
    @app_commands.describe(target="Player whose active life will be ended")
    async def kill(self, interaction: discord.Interaction, target: discord.User) -> None:
        """End a life through the Stage 10 archive/estate path and audit the action."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await self.service.kill(int(interaction.user.id), int(target.id))
        await interaction.followup.send(
            f"Ended {_safe_user(target)}'s active life at age {result['character'].age}; the life archive was updated.",
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @admin.command(name="reset_player", description="Archive the current chapter and start a fresh infant life")
    @app_commands.default_permissions(administrator=True)
    @app_commands.check(owner_check)
    @app_commands.describe(target="Player whose active game will be reset")
    async def reset_player(self, interaction: discord.Interaction, target: discord.User) -> None:
        """Reset the target's active life while preserving earlier archived lives."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        character = await self.service.reset_player(int(interaction.user.id), int(target.id))
        await interaction.followup.send(
            f"Reset {_safe_user(target)}'s active game. A fresh life has begun as **{_escape(character.name)}** (Life #{character.char_id}).",
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @admin.command(name="ban", description="Block a player from all LIFELINE game commands")
    @app_commands.default_permissions(administrator=True)
    @app_commands.check(owner_check)
    @app_commands.describe(target="Account to block", reason="Private moderation reason, 1–500 characters")
    async def ban(self, interaction: discord.Interaction, target: discord.User, reason: str) -> None:
        """Ban an account from game actions and persist a moderation audit row."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        await self.service.ban(int(interaction.user.id), int(target.id), reason)
        await interaction.followup.send(
            f"Banned {_safe_user(target)} from LIFELINE game commands.",
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @admin.command(name="unban", description="Restore a player's access to LIFELINE game commands")
    @app_commands.default_permissions(administrator=True)
    @app_commands.check(owner_check)
    @app_commands.describe(target="Account to restore")
    async def unban(self, interaction: discord.Interaction, target: discord.User) -> None:
        """Remove the active ban, audit the attempt, and confirm privately."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        removed = await self.service.unban(int(interaction.user.id), int(target.id))
        status = "Ban removed" if removed else "No active ban was found"
        await interaction.followup.send(
            f"{status} for {_safe_user(target)}.", ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @admin.command(name="market_event", description="Apply a bounded crash or boom to all listed stocks")
    @app_commands.default_permissions(administrator=True)
    @app_commands.check(owner_check)
    @app_commands.describe(event="Global market event", percent="Price change from 1 to 40 percent")
    @app_commands.choices(event=_MARKET_CHOICES)
    async def market_event(
        self,
        interaction: discord.Interaction,
        event: str,
        percent: app_commands.Range[int, 1, 40] = 20,
    ) -> None:
        """Apply a global market price shift and audit the updated market atomically."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        count = await self.service.market_event(int(interaction.user.id), event, int(percent))
        await interaction.followup.send(
            f"Applied a **{event}** market event of **{int(percent)}%** to {count} active ticker(s).",
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @admin.command(name="reload_data", description="Validate all content files and atomically reload catalogs")
    @app_commands.default_permissions(administrator=True)
    @app_commands.check(owner_check)
    async def reload_data(self, interaction: discord.Interaction) -> None:
        """Reload content only after every required file and cross-reference passes validation."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            counts = await self.service.reload_data(int(interaction.user.id))
        except ValueError as exc:
            safe_error = _escape(str(exc))[:1800]
            await interaction.followup.send(
                f"Data reload rejected; the previously loaded catalogs remain active.\n```\n{safe_error}\n```",
                ephemeral=True,
                allowed_mentions=discord.AllowedMentions.none(),
            )
            return
        await interaction.followup.send(
            "Reloaded validated catalogs: " + " · ".join(f"{name} **{count}**" for name, count in counts.items()),
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @admin.command(name="audit", description="View recent owner-admin actions, optionally for one player")
    @app_commands.default_permissions(administrator=True)
    @app_commands.check(owner_check)
    @app_commands.describe(target="Optional player whose admin history to filter")
    async def audit(
        self,
        interaction: discord.Interaction,
        target: Optional[discord.User] = None,
    ) -> None:
        """Read a private, bounded audit page and audit the lookup itself."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        rows = await self.service.list_audit(
            int(interaction.user.id), int(target.id) if target is not None else None
        )
        embed = discord.Embed(
            title="Admin audit log",
            description="Newest owner actions first. This view is private to you.",
            color=EmbedColors.ADMIN,
        )
        if not rows:
            embed.description = "No admin actions match that filter."
        else:
            for row in rows[:12]:
                ts = datetime.fromtimestamp(int(row["ts"]), tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
                details = _escape(_short_details(str(row["details_json"])))
                target_id = row.get("target_user_id")
                target_text = f" · target `{target_id}`" if target_id is not None else ""
                amount = f" · amount `{row['amount']}`" if row.get("amount") is not None else ""
                embed.add_field(
                    name=f"{ts} · {_escape(str(row['action']))}{target_text}{amount}",
                    value=f"Admin `{row.get('admin_id')}` · {details or 'No extra details'}",
                    inline=False,
                )
        embed.set_footer(text=f"Showing up to 12 of {len(rows)} matching records")
        await interaction.followup.send(
            embed=embed,
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @admin.command(name="sync", description="Explicitly synchronize application commands globally")
    @app_commands.default_permissions(administrator=True)
    @app_commands.check(owner_check)
    async def sync(self, interaction: discord.Interaction) -> None:
        """The only global command-sync path; no global sync runs automatically at startup."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            synced = await self.bot.tree.sync()
        except Exception as exc:
            logger.exception("Global app-command sync failed for owner %s", interaction.user.id)
            await self.service.record_sync(
                int(interaction.user.id), success=False, detail=type(exc).__name__
            )
            await interaction.followup.send(
                "Global command sync failed; the attempt was recorded in the admin audit log.",
                ephemeral=True,
                allowed_mentions=discord.AllowedMentions.none(),
            )
            return
        await self.service.record_sync(
            int(interaction.user.id), success=True, detail=f"{len(synced)} commands synchronized"
        )
        await interaction.followup.send(
            f"Globally synchronized {len(synced)} application command(s).",
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )


def _safe_user(user: discord.User) -> str:
    """Format a user reference without creating a mention."""
    return f"{_escape(getattr(user, 'display_name', user.name))} (`{int(user.id)}`)"


def _escape(value: str) -> str:
    """Escape stored/user-supplied text and mentions before displaying it."""
    return escape_user_text(value)


def _short_details(raw: str) -> str:
    """Render compact JSON details without leaking arbitrary long payloads."""
    try:
        data = json.loads(raw)
        return json.dumps(data, ensure_ascii=False, sort_keys=True)[:360]
    except (TypeError, json.JSONDecodeError):
        return raw[:360]


async def setup(bot: commands.Bot) -> None:
    """Register the owner-only Stage 11 command group."""
    await bot.add_cog(AdminCog(bot))
