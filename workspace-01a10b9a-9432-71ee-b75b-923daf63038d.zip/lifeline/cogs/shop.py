"""Slash commands for the Stage 8 shop, inventory, and player trade system."""
from __future__ import annotations

import logging
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands, tasks

from core.embeds import safe_text as escape_user_text
from core.errors import GameError
from core.family import FamilyService, RING_CATALOG
from core.money import format_cents
from core.shop import ShopService
from cogs.shop_views import (
    ShopBrowseView,
    ShopQuoteView,
    TradeBuilderView,
    quote_embed,
)

logger = logging.getLogger("lifeline.shop.cog")
SHOP_CATEGORIES = (
    "housing", "vehicle", "jewelry", "electronics", "health", "collectibles",
    "business", "pet", "consumable", "license", "title", "leisure",
)
RING_CHOICES = [
    app_commands.Choice(name=f"{item['name']} · {format_cents(int(item['price']))}", value=item_id)
    for item_id, item in RING_CATALOG.items()
]


def safe_text(value: str, limit: int = 150) -> str:
    """Escape markdown and mention syntax before adding content to Discord embeds."""
    return escape_user_text(value, limit)


async def shop_item_autocomplete(
    interaction: discord.Interaction,
    current: str,
) -> list[app_commands.Choice[str]]:
    """Suggest shop-visible item IDs by a case-insensitive name prefix."""
    service = getattr(interaction.client, "shop_service", None)
    if service is None:
        return []
    query = current.strip().lower()
    return [
        app_commands.Choice(name=f"{item['name']} · {item['category']}", value=item_id)
        for item_id, item in list(service.items.items())[:]
        if item["shop_available"] and (query in item["name"].lower() or query in item_id)
    ][:25]


async def inventory_item_autocomplete(
    interaction: discord.Interaction,
    current: str,
) -> list[app_commands.Choice[str]]:
    """Suggest item IDs currently held by the caller's active life."""
    service = getattr(interaction.client, "shop_service", None)
    if service is None:
        return []
    try:
        _, items = await service.inventory(interaction.user.id)
    except GameError:
        return []
    query = current.strip().lower()
    results: list[app_commands.Choice[str]] = []
    seen: set[str] = set()
    for row in items:
        item_id = str(row["item_id"])
        if item_id in seen or (query not in str(row["name"]).lower() and query not in item_id):
            continue
        seen.add(item_id)
        results.append(app_commands.Choice(name=f"{row['name']} ×{row['quantity']}", value=item_id))
    return results[:25]


class ShopCog(commands.Cog):
    """Shop, inventory, trade commands, and a robust trade-expiry background task."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        service = getattr(bot, "shop_service", None)
        if service is None:
            service = ShopService(bot.db, bot.rng, getattr(bot, "locks", None))
            bot.shop_service = service
        self.service: ShopService = service
        self.achievement_service = getattr(bot, "achievement_service", None)
        relationships = getattr(bot, "family_service", None)
        if relationships is None:
            relationships = FamilyService(bot.db, bot.rng, getattr(bot, "locks", None))
            bot.family_service = relationships
        self.relationship_service: FamilyService = relationships

    async def cog_load(self) -> None:
        """Start the ten-minute-trade reaper once this extension is loaded."""
        self.expire_trades.start()

    def cog_unload(self) -> None:
        """Stop the periodic expiry task when the extension unloads."""
        self.expire_trades.cancel()

    @tasks.loop(seconds=30.0)
    async def expire_trades(self) -> None:
        """Expire pending offers, logging any error so the loop survives failures."""
        try:
            expired = await self.service.expire_pending()
            if expired:
                logger.info("Expired %s player trade offer(s)", expired)
        except Exception:
            logger.exception("Trade-expiry task failed; it will retry on the next loop")

    @expire_trades.before_loop
    async def before_expire_trades(self) -> None:
        """Wait until the bot is connected before running background database work."""
        await self.bot.wait_until_ready()

    shop = app_commands.Group(name="shop", description="Browse and purchase items")
    inventory_group = app_commands.Group(name="inventory", description="Review and manage your items")
    trade = app_commands.Group(name="trade", description="Offer items and cash to another player")

    @shop.command(name="browse", description="Browse the paginated item shop")
    @app_commands.describe(category="Optional catalog category to browse")
    @app_commands.choices(category=[app_commands.Choice(name=value.title(), value=value) for value in SHOP_CATEGORIES])
    @app_commands.checks.cooldown(1, 4.0, key=lambda interaction: interaction.user.id)
    async def browse_shop(self, interaction: discord.Interaction, category: Optional[str] = None) -> None:
        """Render a paginated shop browser with age-gated purchase quotes."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        items = await self.service.browse(interaction.user.id, category)
        view = ShopBrowseView(
            interaction.user.id, self.service, items, category, self.achievement_service
        )
        message = await interaction.followup.send(embed=view.make_embed(), view=view, ephemeral=True, wait=True)
        view.bind_message(message)

    @shop.command(name="buy", description="Get a versioned purchase quote for an item")
    @app_commands.describe(item="Item catalog entry", quantity="Number to purchase for stackable items")
    @app_commands.autocomplete(item=shop_item_autocomplete)
    @app_commands.checks.cooldown(1, 4.0, key=lambda interaction: interaction.user.id)
    async def buy_item(self, interaction: discord.Interaction, item: str, quantity: int = 1) -> None:
        """Show a price, remaining balance, and cash or financing confirmation."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        quote = await self.service.quote_purchase(interaction.user.id, item, quantity)
        view = ShopQuoteView(interaction.user.id, quote, self.service, self.achievement_service)
        message = await interaction.followup.send(embed=quote_embed(quote), view=view, ephemeral=True, wait=True)
        view.bind_message(message)

    @shop.command(name="ring", description="Buy an engagement ring for your next proposal")
    @app_commands.describe(ring="Ring item to purchase")
    @app_commands.choices(ring=RING_CHOICES)
    @app_commands.checks.cooldown(1, 3.0, key=lambda interaction: interaction.user.id)
    async def buy_ring(self, interaction: discord.Interaction, ring: str) -> None:
        """Preserve relationship-ring purchases under the unified shop command group."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        cost, bonus = await self.relationship_service.buy_ring(interaction.user.id, ring)
        item = RING_CATALOG[ring]
        await interaction.followup.send(
            f"Purchased **{safe_text(item['name'])}** for {format_cents(cost)}. It gives +{bonus}% proposal acceptance.",
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @inventory_group.command(name="view", description="View your inventory and current item values")
    @app_commands.checks.cooldown(1, 4.0, key=lambda interaction: interaction.user.id)
    async def inventory_status(self, interaction: discord.Interaction) -> None:
        """Show current holdings, locks, collateral, and liquid balances."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        character, items = await self.service.inventory(interaction.user.id)
        embed = discord.Embed(title=f"{safe_text(character.name)} · Inventory", color=discord.Color.blurple())
        embed.description = (
            f"Cash: {format_cents(character.cash)} · Bank: {format_cents(character.bank)}\n"
            f"Life age: {character.age}"
        )
        if not items:
            embed.add_field(name="Items", value="Your inventory is empty.", inline=False)
        else:
            lines: list[str] = []
            for row in items[:25]:
                flags = []
                if row["is_locked"]:
                    flags.append("locked in trade")
                if row["collateralized"]:
                    flags.append("loan collateral")
                line = (
                    f"`#{row['asset_id']}` **{safe_text(row['name'], 100)}** ×{row['quantity']} — "
                    f"{format_cents(int(row['current_value']))}"
                )
                if flags:
                    line += " · " + ", ".join(flags)
                lines.append(line)
            embed.add_field(name="Items", value="\n".join(lines), inline=False)
            if len(items) > 25:
                embed.set_footer(text=f"Showing the first 25 of {len(items)} item lots")
        await interaction.followup.send(embed=embed, ephemeral=True)

    @inventory_group.command(name="sell", description="Sell unlocked items at current market value")
    @app_commands.describe(item="Item catalog entry in your inventory", quantity="Number of copies to sell")
    @app_commands.autocomplete(item=inventory_item_autocomplete)
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def sell_item(self, interaction: discord.Interaction, item: str, quantity: int = 1) -> None:
        """Sell at 85% of current value, or 94% for housing, never shop price."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        receipt = await self.service.sell(interaction.user.id, item, quantity)
        await interaction.followup.send(
            f"Sold {receipt.quantity} × **{safe_text(receipt.item_name)}** for "
            f"{format_cents(receipt.payout)}. Remaining liquid balance: {format_cents(receipt.remaining_balance)}.",
            ephemeral=True,
        )

    @inventory_group.command(name="use", description="Use an eligible item from your inventory")
    @app_commands.describe(item="Item catalog entry in your inventory")
    @app_commands.autocomplete(item=inventory_item_autocomplete)
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def use_item(self, interaction: discord.Interaction, item: str) -> None:
        """Apply item effects, consuming a consumable or recording a reusable use."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        if item.lower().strip() == "lottery_ticket":
            casino = getattr(self.bot, "casino_service", None)
            if casino is None:
                raise RuntimeError("Casino service is unavailable.")
            receipt = await casino.use_lottery_ticket(interaction.user.id)
            await interaction.followup.send(receipt.message, ephemeral=True)
            return
        if item.lower().strip() == "gambling_rehab":
            casino = getattr(self.bot, "casino_service", None)
            if casino is None:
                raise RuntimeError("Casino service is unavailable.")
            before, after = await casino.use_rehab(interaction.user.id)
            await interaction.followup.send(
                f"Recovery treatment used. Gambling addiction reduced from {before} to {after}.",
                ephemeral=True,
            )
            return
        receipt = await self.service.use(interaction.user.id, item)
        stats = receipt.stats
        await interaction.followup.send(
            f"Used **{safe_text(receipt.item_name)}**. Remaining in selected stack: {receipt.quantity_remaining}. "
            f"Lottery payout: {format_cents(receipt.payout)}.\n"
            f"Health {stats.health} · Happiness {stats.happiness} · Fitness {stats.fitness} · Stress {stats.stress}.",
            ephemeral=True,
        )

    @trade.command(name="offer", description="Build and send a trade offer to another player")
    @app_commands.describe(target="The other player to trade with")
    @app_commands.checks.cooldown(1, 8.0, key=lambda interaction: interaction.user.id)
    async def offer_trade(self, interaction: discord.Interaction, target: discord.User) -> None:
        """Open paginated item selectors and a cash-entry modal for a trade."""
        if target.id == interaction.user.id:
            await interaction.response.send_message("You cannot trade with yourself.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True, thinking=True)
        initiator_created = int(interaction.user.created_at.timestamp())
        target_created = int(target.created_at.timestamp())
        await self.service.register_player(interaction.user.id, initiator_created)
        await self.service.register_player(target.id, target_created)
        offered, requested = await self.service.trade_candidates(interaction.user.id, target.id)
        view = TradeBuilderView(
            interaction.user.id, target.id, self.service, offered, requested,
            self.achievement_service,
        )
        message = await interaction.followup.send(embed=view.make_embed(), view=view, ephemeral=True, wait=True)
        view.bind_message(message)

    @trade.command(name="list", description="View your recent incoming and outgoing trades")
    @app_commands.checks.cooldown(1, 4.0, key=lambda interaction: interaction.user.id)
    async def list_trades(self, interaction: discord.Interaction) -> None:
        """Display the caller's recent trade status and any failure reason."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        character, rows = await self.service.trade_history(interaction.user.id)
        embed = discord.Embed(title=f"Recent trades · {safe_text(character.name)}", color=discord.Color.blurple())
        if not rows:
            embed.description = "No trade offers yet."
        else:
            lines = []
            for row in rows[:15]:
                side = "out" if int(row["from_user_id"]) == interaction.user.id else "in"
                line = (
                    f"**#{row['trade_id']}** · {side} · {safe_text(str(row['status']).title())} · "
                    f"offer {format_cents(int(row['offer_cash']))} / request {format_cents(int(row['request_cash']))}"
                )
                if row["outcome_message"]:
                    line += f"\n└ {safe_text(str(row['outcome_message']), 140)}"
                lines.append(line)
            embed.description = "\n".join(lines)
        await interaction.followup.send(embed=embed, ephemeral=True)

    @trade.command(name="cancel", description="Cancel one of your pending outgoing trades")
    @app_commands.describe(trade_id="Trade number shown by /trade list")
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def cancel_trade(self, interaction: discord.Interaction, trade_id: app_commands.Range[int, 1]) -> None:
        """Cancel an offer by ID and unlock its items."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await self.service.cancel_trade(int(trade_id), interaction.user.id)
        await interaction.followup.send(result.message, ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    """Register Stage 8 groups and start the persistent expiry worker."""
    await bot.add_cog(ShopCog(bot))
