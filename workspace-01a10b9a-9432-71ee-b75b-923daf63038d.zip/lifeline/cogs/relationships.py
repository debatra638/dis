"""Discord slash commands and nonce-protected menus for Stage 6 relationships."""
from __future__ import annotations

from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from core.achievements import AchievementService
from core.embeds import safe_text as escape_user_text
from core.errors import GameError, ValidationError
from core.family import (
    WEDDING_TIERS,
    DateOutcome,
    DateSearch,
    FamilyService,
    InfidelityPrompt,
    InteractionOutcome,
    ProposalOutcome,
)
from core.money import format_cents
from core.views import OwnedView
from cogs.legacy_views import check_and_notify_achievements


ACTION_CHOICES = [
    app_commands.Choice(name="Spend time", value="spend_time"),
    app_commands.Choice(name="Give a gift", value="gift"),
    app_commands.Choice(name="Compliment", value="compliment"),
    app_commands.Choice(name="Argue", value="argue"),
    app_commands.Choice(name="Ask for money (parents only)", value="ask_for_money"),
    app_commands.Choice(name="Insult", value="insult"),
]
WEDDING_CHOICES = [
    app_commands.Choice(name="Courthouse · $100", value="courthouse"),
    app_commands.Choice(name="Intimate · $2,500", value="intimate"),
    app_commands.Choice(name="Traditional · $25,000", value="traditional"),
    app_commands.Choice(name="Lavish · $80,000 × price index", value="lavish"),
]
def _safe(value: object) -> str:
    """Escape user-facing names and suppress every Discord mention."""
    return escape_user_text(value)


def _person_label(person: dict[str, object]) -> str:
    """Build a compact, escaped person label for family embeds."""
    name = _safe(person.get("name", "Unknown"))
    relation = _safe(person.get("relationship_type", "relative")).title()
    score = int(person.get("relationship_score", 0))
    alive = "Alive" if bool(person.get("is_alive", True)) else f"Died at age {person.get('death_age', '?')}"
    age = int(person.get("age", 0))
    return f"**{name}** · {relation} · age {age} · relationship {score}/100 · {alive}"


def _roster_embed(title: str, character: object, people: list[dict[str, object]]) -> discord.Embed:
    """Render a character's connected NPCs without exposing raw markdown or mentions."""
    name = _safe(getattr(character, "name", "Life"))
    age = int(getattr(character, "age", 0))
    embed = discord.Embed(
        title=f"{title} · {name}",
        description=f"Age {age} · {len(people)} connected person(s)",
        color=discord.Color.blurple(),
    )
    if not people:
        embed.add_field(name="Family and relationships", value="No people are recorded yet.", inline=False)
    for person in people[:20]:
        relation = str(person.get("relationship_type", "relative")).replace("_", " ").title()
        score = int(person.get("relationship_score", 0))
        value = _person_label(person)
        if person.get("custody"):
            value += f"\nCustody: {_safe(person['custody'])}"
        if int(person.get("child_support", 0) or 0) > 0:
            value += f" · Annual support: {format_cents(int(person['child_support']))}"
        embed.add_field(name=f"{relation} · {score}/100", value=value[:1024], inline=False)
    if len(people) > 20:
        embed.set_footer(text=f"Showing 20 of {len(people)} people")
    return embed


def _date_embed(search: DateSearch) -> discord.Embed:
    """Show all three date candidates as selectable profile cards."""
    embed = discord.Embed(
        title="Meet someone new",
        description="Choose one candidate below. Dating age rules are checked again when you select.",
        color=discord.Color.magenta(),
    )
    for index, person in enumerate(search.candidates, start=1):
        embed.add_field(
            name=f"Candidate {index} · {_safe(person['name'])}",
            value=(
                f"Age {person['age']} · {_safe(person['occupation'])}\n"
                f"Looks {person['looks']}/100 · Smarts {person['smarts']}/100 · "
                f"Health {person['health']}/100\n"
                f"Wealth: {format_cents(int(person['wealth']))}"
            ),
            inline=False,
        )
    embed.set_footer(text="This private selection expires in 15 minutes")
    return embed


def _date_outcome_embed(outcome: DateOutcome) -> discord.Embed:
    """Render a date result while retaining the calculated chance for feedback."""
    person = outcome.npc
    if outcome.accepted:
        title = f"A new relationship with {_safe(person['name'])}!"
        description = f"They agreed to date you. Your relationship score is 60/100."
        color = discord.Color.green()
    else:
        title = "The date didn't work out"
        description = f"{_safe(person['name'])} declined this time. You can meet new people with `/date find`."
        color = discord.Color.orange()
    embed = discord.Embed(title=title, description=description, color=color)
    embed.set_footer(text=f"Success chance: {outcome.success_chance:.1f}%")
    return embed


def _interaction_embed(outcome: InteractionOutcome) -> discord.Embed:
    """Render the score and money effect of one person-to-person action."""
    embed = discord.Embed(
        title=f"Relationship · {_safe(outcome.person_name)}",
        description=_safe(outcome.message),
        color=discord.Color.green() if outcome.score_after >= outcome.score_before else discord.Color.orange(),
    )
    embed.add_field(
        name="Relationship score",
        value=f"{outcome.score_before}/100 → {outcome.score_after}/100",
        inline=True,
    )
    if outcome.money_delta:
        embed.add_field(name="Money change", value=format_cents(outcome.money_delta), inline=True)
    embed.set_footer(text="Three interactions per person per in-game year")
    return embed


def _proposal_embed(outcome: ProposalOutcome) -> discord.Embed:
    """Render a proposal result."""
    result = "accepted" if outcome.accepted else "declined"
    return discord.Embed(
        title="💍 Proposal " + result,
        description=(
            f"{_safe(outcome.person_name)} {result} your proposal.\n"
            f"Acceptance chance: {outcome.chance}% · Ring bonus: +{outcome.ring_bonus}%"
        ),
        color=discord.Color.green() if outcome.accepted else discord.Color.orange(),
    )


class DateCandidateSelect(discord.ui.Select["DateSearchView"]):
    """A select menu whose custom ID and server-side nonce protect date options."""

    def __init__(self, search: DateSearch):
        options = [
            discord.SelectOption(
                label=f"{_safe(person['name'])} · age {person['age']}"[:100],
                description=f"{_safe(person['occupation'])} · looks {person['looks']} · smarts {person['smarts']}"[:100],
                value=str(person["npc_id"]),
            )
            for person in search.candidates
        ]
        super().__init__(
            placeholder="Choose a date",
            min_values=1,
            max_values=1,
            options=options,
            custom_id=f"lifeline:date:{search.nonce}",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        """Resolve one candidate and disable the menu after the one-use session."""
        view = self.view
        if not isinstance(view, DateSearchView):
            return
        try:
            await interaction.response.defer()
            outcome = await view.service.choose_date(interaction.user.id, int(self.values[0]), view.nonce)
            if interaction.message is not None:
                await interaction.message.edit(embed=_date_outcome_embed(outcome), view=None)
            view.stop()
            await check_and_notify_achievements(
                interaction, view.achievement_service, interaction.user.id
            )
        except GameError as exc:
            await interaction.followup.send(exc.message, ephemeral=True)
        except (ValueError, TypeError):
            await interaction.followup.send("That date selection is invalid.", ephemeral=True)


class DateSearchView(OwnedView):
    """Owner-checked select menu backed by a database nonce and expiry."""

    def __init__(
        self,
        owner_id: int,
        search: DateSearch,
        service: FamilyService,
        achievement_service: Optional[AchievementService] = None,
    ):
        super().__init__(owner_id, search.nonce, timeout=180.0)
        self.service = service
        self.achievement_service = achievement_service
        self.add_item(DateCandidateSelect(search))


class InfidelityChoiceView(OwnedView):
    """Owner-checked cheat-or-not choice with a persistent one-use nonce."""

    def __init__(
        self,
        owner_id: int,
        prompt: InfidelityPrompt,
        service: FamilyService,
        achievement_service: Optional[AchievementService] = None,
    ):
        super().__init__(owner_id, prompt.nonce, timeout=180.0)
        self.service = service
        self.achievement_service = achievement_service
        self.spouse_name = prompt.spouse_name
        self.add_item(InfidelityChoiceButton("Cheat", True, prompt.nonce))
        self.add_item(InfidelityChoiceButton("Stay faithful", False, prompt.nonce))

    async def resolve_choice(self, interaction: discord.Interaction, cheat: bool) -> None:
        """Resolve the selected temptation and remove controls after use."""
        try:
            await interaction.response.defer()
            message = await self.service.resolve_infidelity_choice(interaction.user.id, self.nonce, cheat)
            embed = discord.Embed(
                title="Relationship choice",
                description=_safe(message),
                color=discord.Color.orange() if cheat else discord.Color.green(),
            )
            if interaction.message is not None:
                await interaction.message.edit(embed=embed, view=None)
            self.stop()
            await check_and_notify_achievements(
                interaction, self.achievement_service, interaction.user.id
            )
        except GameError as exc:
            await interaction.followup.send(exc.message, ephemeral=True)


class InfidelityChoiceButton(discord.ui.Button[InfidelityChoiceView]):
    """One nonce-tagged infidelity option."""

    def __init__(self, label: str, cheat: bool, nonce: str):
        super().__init__(
            label=label,
            style=discord.ButtonStyle.danger if cheat else discord.ButtonStyle.success,
            custom_id=f"lifeline:temptation:{nonce}:{'cheat' if cheat else 'faithful'}",
        )
        self.cheat = cheat

    async def callback(self, interaction: discord.Interaction) -> None:
        """Delegate after the base view confirms component ownership."""
        if isinstance(self.view, InfidelityChoiceView):
            await self.view.resolve_choice(interaction, self.cheat)


class RelationshipsCog(commands.Cog):
    """Family, relationship, dating, friendship, and ring-shop slash commands."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.service = getattr(bot, "family_service", None) or FamilyService(
            bot.db, bot.rng, getattr(bot, "locks", None)
        )
        self.achievement_service = getattr(bot, "achievement_service", None)

    relationship = app_commands.Group(name="relationship", description="Manage friends, romance, and family")
    date = app_commands.Group(name="date", description="Meet age-appropriate dating candidates")
    friends = app_commands.Group(name="friends", description="Meet and manage friends")

    @app_commands.command(name="family", description="View your parents, siblings, partner, and children")
    @app_commands.checks.cooldown(1, 3.0)
    async def family_command(self, interaction: discord.Interaction) -> None:
        """Show the full current family and relationship roster."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        character, people = await self.service.family(interaction.user.id)
        await interaction.followup.send(
            embed=_roster_embed("Family", character, people),
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @relationship.command(name="list", description="List people and relationship scores")
    @app_commands.checks.cooldown(1, 3.0)
    async def relationship_list(self, interaction: discord.Interaction) -> None:
        """List all relatives, friends, partners, former partners, and children."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        character, people = await self.service.relationship_list(interaction.user.id)
        await interaction.followup.send(
            embed=_roster_embed("Relationships", character, people),
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @relationship.command(name="interact", description="Interact with one person up to three times per year")
    @app_commands.describe(
        person="A relative, friend, partner, or other listed NPC",
        action="Choose how to interact",
        gift_dollars="Gift amount in whole dollars (required for the gift action)",
    )
    @app_commands.choices(action=ACTION_CHOICES)
    @app_commands.checks.cooldown(1, 3.0)
    async def interact(
        self,
        interaction: discord.Interaction,
        person: str,
        action: str,
        gift_dollars: Optional[int] = None,
    ) -> None:
        """Apply a selected action to an autocomplete-selected person."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        npc_id = self._person_id(person)
        outcome = await self.service.interact(interaction.user.id, npc_id, action, gift_dollars)
        await interaction.followup.send(
            embed=_interaction_embed(outcome),
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @interact.autocomplete("person")
    async def interaction_person_autocomplete(
        self,
        interaction: discord.Interaction,
        current: str,
    ) -> list[app_commands.Choice[str]]:
        """Offer living connected NPCs with their relationship types."""
        return await self._autocomplete(interaction, current)

    @relationship.command(name="propose", description="Propose after a year together with a strong partner score")
    @app_commands.describe(person="Your current partner; optional owned rings boost acceptance")
    @app_commands.checks.cooldown(1, 3.0)
    async def propose(self, interaction: discord.Interaction, person: str) -> None:
        """Propose to an eligible partner."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        outcome = await self.service.propose(interaction.user.id, self._person_id(person))
        await interaction.followup.send(
            embed=_proposal_embed(outcome),
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @propose.autocomplete("person")
    async def propose_person_autocomplete(
        self,
        interaction: discord.Interaction,
        current: str,
    ) -> list[app_commands.Choice[str]]:
        """Autocomplete connected living NPCs for a proposal."""
        return await self._autocomplete(interaction, current, types={"partner"})

    @relationship.command(name="marry", description="Hold a wedding with your fiance")
    @app_commands.describe(wedding="Wedding size", prenup="Protect premarital cash, bank, and property in divorce")
    @app_commands.choices(wedding=WEDDING_CHOICES)
    @app_commands.checks.cooldown(1, 3.0)
    async def marry(self, interaction: discord.Interaction, wedding: str = "courthouse", prenup: bool = False) -> None:
        """Complete a wedding at the chosen indexed cost and optionally record a prenup."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await self.service.marry(interaction.user.id, wedding, prenup)
        embed = discord.Embed(
            title="💒 Wedding complete",
            description=(
                f"You married **{_safe(result.person_name)}**.\n"
                f"Wedding cost: {format_cents(result.wedding_cost)}\n"
                f"Prenup: {'signed' if result.prenup else 'not signed'}\n"
                f"Spouse annual income: {format_cents(result.annual_income)}"
            ),
            color=discord.Color.gold(),
        )
        await interaction.followup.send(embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @relationship.command(name="divorce", description="End a marriage and settle assets, custody, and support")
    @app_commands.checks.cooldown(1, 3.0)
    async def divorce(self, interaction: discord.Interaction) -> None:
        """Run a transactional divorce with asset division, legal fees, and custody."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        outcome = await self.service.divorce(interaction.user.id)
        embed = discord.Embed(
            title="Divorce finalized",
            description=(
                f"{_safe(outcome.spouse_name)} is now your ex-spouse.\n"
                f"Eligible marital assets: {format_cents(outcome.marital_assets)}\n"
                f"Spouse share: {format_cents(outcome.spouse_share)}\n"
                f"Lawyer fees: {format_cents(outcome.lawyer_fee)}\n"
                f"Children affected: {outcome.children}"
            ),
            color=discord.Color.orange(),
        )
        if outcome.alimony_annual:
            embed.add_field(
                name="Alimony",
                value=(
                    f"{format_cents(outcome.alimony_annual)} per year for "
                    f"{outcome.alimony_years:g} year(s)"
                ),
                inline=False,
            )
        await interaction.followup.send(embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @relationship.command(name="breakup", description="End a dating or engagement relationship")
    @app_commands.describe(person="Your current partner or fiance")
    @app_commands.checks.cooldown(1, 3.0)
    async def breakup(self, interaction: discord.Interaction, person: str) -> None:
        """Break up with an autocomplete-selected partner or fiance."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        message = await self.service.breakup(interaction.user.id, self._person_id(person))
        await interaction.followup.send(_safe(message), ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @breakup.autocomplete("person")
    async def breakup_person_autocomplete(
        self,
        interaction: discord.Interaction,
        current: str,
    ) -> list[app_commands.Choice[str]]:
        """Autocomplete living partners and fiances for breakup."""
        return await self._autocomplete(interaction, current, types={"partner", "fiance"})

    @relationship.command(name="try_for_baby", description="Try for a baby with your partner or spouse")
    @app_commands.checks.cooldown(1, 3.0)
    async def try_for_baby(self, interaction: discord.Interaction) -> None:
        """Use the age-based fertility curve to start a one-year pregnancy."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        success, chance = await self.service.try_for_baby(interaction.user.id)
        message = (
            f"Pregnancy started. The baby is due after your next `/life age`. Chance was {chance * 100:.1f}%."
            if success
            else f"No pregnancy this year. Estimated chance was {chance * 100:.1f}%; you may try again next year."
        )
        await interaction.followup.send(_safe(message), ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @relationship.command(name="adopt", description="Begin a paid adoption with a one-year wait")
    @app_commands.checks.cooldown(1, 3.0)
    async def adopt(self, interaction: discord.Interaction) -> None:
        """Pay the indexed adoption fee and schedule the child's arrival next year."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        cost = await self.service.adopt(interaction.user.id)
        await interaction.followup.send(
            f"Adoption started. The child will join after your next `/life age`. Cost: {format_cents(cost)}.",
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @relationship.command(name="temptation", description="Choose whether to cheat or stay faithful")
    @app_commands.checks.cooldown(1, 3.0)
    async def temptation(self, interaction: discord.Interaction) -> None:
        """Create a one-use infidelity choice event for a married character."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        prompt = await self.service.start_infidelity_choice(interaction.user.id)
        embed = discord.Embed(
            title="A moment of temptation",
            description=f"Your spouse **{_safe(prompt.spouse_name)}** is not here. What do you do?\n\n"
                        "If you cheat, there is a 35% discovery chance each year.",
            color=discord.Color.orange(),
        )
        view = InfidelityChoiceView(
            interaction.user.id, prompt, self.service, self.achievement_service
        )
        message = await interaction.followup.send(
            embed=embed,
            view=view,
            ephemeral=True,
            wait=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        view.bind_message(message)

    @date.command(name="find", description="Find three age-appropriate dating candidates")
    @app_commands.checks.cooldown(1, 3.0)
    async def date_find(self, interaction: discord.Interaction) -> None:
        """Generate three NPC candidates and present an owner-only select menu."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        search = await self.service.find_dates(interaction.user.id)
        view = DateSearchView(
            interaction.user.id, search, self.service, self.achievement_service
        )
        message = await interaction.followup.send(
            embed=_date_embed(search),
            view=view,
            ephemeral=True,
            wait=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        view.bind_message(message)

    @friends.command(name="find", description="Meet an age-appropriate friend")
    @app_commands.checks.cooldown(1, 3.0)
    async def friend_find(self, interaction: discord.Interaction) -> None:
        """Generate one age-appropriate friend NPC."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        person = await self.service.find_friend(interaction.user.id)
        embed = discord.Embed(
            title=f"You met {_safe(person['name'])}!",
            description=(
                f"Age {person['age']} · {_safe(person['occupation'])}\n"
                f"Relationship score: {person['relationship_score']}/100"
            ),
            color=discord.Color.green(),
        )
        await interaction.followup.send(embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @staticmethod
    def _person_id(value: str) -> int:
        """Parse the opaque NPC ID supplied by autocomplete without accepting names."""
        try:
            npc_id = int(value)
        except (TypeError, ValueError) as exc:
            raise ValidationError("Select a person from the autocomplete list.") from exc
        if npc_id <= 0:
            raise ValidationError("Select a person from the autocomplete list.")
        return npc_id

    async def _autocomplete(
        self,
        interaction: discord.Interaction,
        current: str,
        *,
        types: Optional[set[str]] = None,
    ) -> list[app_commands.Choice[str]]:
        """Create escaped Discord choices from the current life's people."""
        people = await self.service.autocomplete_people(interaction.user.id, current)
        if types is not None:
            people = [person for person in people if str(person["relationship_type"]) in types]
        return [
            app_commands.Choice(
                name=f"{_safe(person['name'])} · {_safe(person['relationship_type'])} · age {person['age']}"[:100],
                value=str(person["npc_id"]),
            )
            for person in people[:25]
        ]


async def setup(bot: commands.Bot) -> None:
    """Load the Stage 6 command cog."""
    await bot.add_cog(RelationshipsCog(bot))
