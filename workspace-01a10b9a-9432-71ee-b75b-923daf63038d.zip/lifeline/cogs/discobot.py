"""
DiscoBot Cog - Fun interactive games and commands for Discord
"""
import hashlib
import logging
import secrets
from typing import Any, Optional, List
import discord
from discord.ext import commands
from discord import app_commands
import discord.utils

from core.embeds import safe_text as escape_user_text
from core.rng import RNG
from core.views import allow_unbanned_user

logger = logging.getLogger("lifeline.cogs.discobot")


def _ship_compatibility_score(first_user_id: int, second_user_id: int) -> int:
    """Return a stable pair score from the injected RNG wrapper's isolated seed stream."""
    pair = f"{min(int(first_user_id), int(second_user_id))}-{max(int(first_user_id), int(second_user_id))}".encode("ascii")
    pair_seed = int.from_bytes(hashlib.sha256(pair).digest()[:8], "big")
    return RNG(pair_seed).randint(0, 100)


class TriviaAnswerView(discord.ui.View):
    """One-use trivia selector bound to the player who opened the question."""

    def __init__(
        self,
        owner_id: int,
        question: str,
        answers: list[str],
        correct_index: int,
        difficulty: str,
        db: Any = None,
    ) -> None:
        super().__init__(timeout=120.0)
        self.owner_id = int(owner_id)
        self.nonce = secrets.token_urlsafe(8)
        self.question = question
        self.answers = tuple(str(answer) for answer in answers)
        self.correct_index = int(correct_index)
        self.difficulty = difficulty
        self.db = db
        self.used = False
        self.message: Optional[discord.Message] = None
        self.add_item(_TriviaAnswerSelect(self))

    def bind_message(self, message: discord.Message) -> None:
        """Remember the sent question so timeout can disable its control."""
        self.message = message

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        """Require the opener and the exact nonce on every select interaction."""
        if int(interaction.user.id) != self.owner_id:
            await interaction.response.send_message("Only the player who opened this trivia can answer it.", ephemeral=True)
            return False
        custom_id = str((interaction.data or {}).get("custom_id", ""))
        if custom_id != f"trivia:{self.nonce}" or self.used:
            await interaction.response.send_message("This trivia answer is stale or already used.", ephemeral=True)
            return False
        return await allow_unbanned_user(interaction, self.db)

    async def resolve(self, interaction: discord.Interaction, value: str) -> None:
        """Validate the selected answer, consume the control, and render the result."""
        if not await self.interaction_check(interaction):
            return
        try:
            answer_index = int(value)
        except (TypeError, ValueError):
            await interaction.response.send_message("Choose one of the listed answers.", ephemeral=True)
            return
        if not 0 <= answer_index < len(self.answers):
            await interaction.response.send_message("That answer is not part of this question.", ephemeral=True)
            return
        self.used = True
        for child in self.children:
            if isinstance(child, discord.ui.Select):
                child.disabled = True
        correct = answer_index == self.correct_index
        result = "Correct!" if correct else "Not quite."
        answer = escape_user_text(self.answers[self.correct_index])
        embed = discord.Embed(
            title="🧠 Trivia result",
            description=f"**{result}** The answer was **{answer}**.",
            color=discord.Color.green() if correct else discord.Color.orange(),
        )
        embed.set_footer(text=f"Difficulty: {self.difficulty.title()}")
        self.stop()
        await interaction.response.edit_message(embed=embed, view=None, allowed_mentions=discord.AllowedMentions.none())

    async def on_timeout(self) -> None:
        """Disable unanswered controls when the question expires."""
        for child in self.children:
            if isinstance(child, discord.ui.Select):
                child.disabled = True
        self.stop()
        if self.message is not None:
            try:
                await self.message.edit(view=None)
            except discord.HTTPException:
                logger.debug("Could not remove timed-out trivia controls", exc_info=True)


class _TriviaAnswerSelect(discord.ui.Select[TriviaAnswerView]):
    """Nonce-bound select menu for one trivia question."""

    def __init__(self, view: TriviaAnswerView) -> None:
        options = [
            discord.SelectOption(label=f"{chr(65 + index)}. {answer}"[:100], value=str(index))
            for index, answer in enumerate(view.answers)
        ]
        super().__init__(
            placeholder="Choose your answer",
            min_values=1,
            max_values=1,
            options=options,
            custom_id=f"trivia:{view.nonce}",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        if self.view is not None:
            await self.view.resolve(interaction, self.values[0])


class Discobot(commands.Cog):
    """Fun interactive games and entertainment commands"""
    
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.rng: RNG = getattr(bot, "rng", None) or RNG()
        self.trivia_questions = [
            {
                "question": "What is the capital of Australia?",
                "answers": ["Canberra", "Sydney", "Melbourne", "Perth"],
                "correct": 0
            },
            {
                "question": "Which planet is known as the Red Planet?",
                "answers": ["Mars", "Venus", "Jupiter", "Saturn"],
                "correct": 0
            },
            {
                "question": "What is the largest mammal in the world?",
                "answers": ["Blue Whale", "Elephant", "Giraffe", "Hippopotamus"],
                "correct": 0
            },
            {
                "question": "Who painted the Mona Lisa?",
                "answers": ["Leonardo da Vinci", "Michelangelo", "Pablo Picasso", "Vincent van Gogh"],
                "correct": 0
            },
            {
                "question": "What is the smallest country in the world?",
                "answers": ["Vatican City", "Monaco", "San Marino", "Liechtenstein"],
                "correct": 0
            },
            {
                "question": "Which element has the chemical symbol 'Au'?",
                "answers": ["Gold", "Silver", "Copper", "Iron"],
                "correct": 0
            },
            {
                "question": "How many continents are there?",
                "answers": ["7", "6", "8", "5"],
                "correct": 0
            },
            {
                "question": "What is the largest ocean on Earth?",
                "answers": ["Pacific Ocean", "Atlantic Ocean", "Indian Ocean", "Arctic Ocean"],
                "correct": 0
            },
            {
                "question": "Who wrote Romeo and Juliet?",
                "answers": ["William Shakespeare", "Charles Dickens", "Jane Austen", "Mark Twain"],
                "correct": 0
            },
            {
                "question": "What is the hardest natural substance on Earth?",
                "answers": ["Diamond", "Gold", "Iron", "Quartz"],
                "correct": 0
            }
        ]
    
    # ==================== HELPER METHODS ====================
    
    def create_embed(self, title: str, description: str, color: int = 0x5865F2, 
                     footer: Optional[str] = None, thumbnail: Optional[str] = None) -> discord.Embed:
        """Create a consistent embed"""
        embed = discord.Embed(title=title, description=description, color=color)
        if footer:
            embed.set_footer(text=footer)
        if thumbnail:
            embed.set_thumbnail(url=thumbnail)
        return embed
    
    def create_game_embed(self, title: str, description: str, 
                          fields: List[dict] = None, color: int = 0x5865F2) -> discord.Embed:
        """Create a game embed with optional fields"""
        embed = discord.Embed(title=title, description=description, color=color)
        if fields:
            for field in fields:
                embed.add_field(name=field.get("name", ""), 
                               value=field.get("value", ""), 
                               inline=field.get("inline", False))
        return embed
    
    # ==================== COIN FLIP ====================
    
    @app_commands.command(name="coinflip", description="Flip a coin")
    @app_commands.describe(choice="Choose heads or tails")
    @app_commands.choices(choice=[
        app_commands.Choice(name="Heads", value="heads"),
        app_commands.Choice(name="Tails", value="tails"),
    ])
    async def coinflip(self, interaction: discord.Interaction, choice: str):
        """Flip a coin and see if you win!"""
        result = self.rng.choice(["heads", "tails"])
        won = choice == result
        
        embed = self.create_embed(
            title="🪙 Coin Flip",
            description=f"The coin landed on **{result}**!",
            color=0xFEE75C if won else 0xED4245,
            thumbnail="https://cdn.discordapp.com/emojis/1067708531628077127.png"
        )
        embed.add_field(name="Your Choice", value=choice.capitalize(), inline=True)
        embed.add_field(name="Result", value="🎉 You Won!" if won else "😢 You Lost!", inline=True)
        
        await interaction.response.send_message(embed=embed)
    
    # ==================== DICE ROLL ====================
    
    @app_commands.command(name="roll", description="Roll dice")
    @app_commands.describe(sides="Number of sides on the dice", count="Number of dice to roll")
    async def roll(self, interaction: discord.Interaction, sides: int = 6, count: int = 1):
        """Roll dice with custom sides and count"""
        if sides < 2 or sides > 100:
            await interaction.response.send_message("❌ Dice must have 2-100 sides!", ephemeral=True)
            return
        if count < 1 or count > 10:
            await interaction.response.send_message("❌ Can only roll 1-10 dice at once!", ephemeral=True)
            return
        
        rolls = [self.rng.randint(1, sides) for _ in range(count)]
        total = sum(rolls)
        
        embed = self.create_embed(
            title=f"🎲 Rolling {count}d{sides}",
            description=f"Results: **{', '.join(map(str, rolls))}**\n**Total: {total}**",
            color=0x5865F2
        )
        embed.set_footer(text=f"Rolled by {escape_user_text(interaction.user.display_name, 80)}")
        
        await interaction.response.send_message(embed=embed)
    
    # ==================== COINFLIP BET ====================
    
    @app_commands.command(name="bet", description="Bet on a coinflip")
    @app_commands.describe(amount="Amount to bet", choice="Heads or Tails")
    @app_commands.choices(choice=[
        app_commands.Choice(name="Heads", value="heads"),
        app_commands.Choice(name="Tails", value="tails"),
    ])
    async def bet(self, interaction: discord.Interaction, amount: int, choice: str):
        """Bet on a coinflip"""
        if amount < 1:
            await interaction.response.send_message("❌ Bet must be at least 1!", ephemeral=True)
            return
        
        result = self.rng.choice(["heads", "tails"])
        won = choice == result
        payout = amount * 2 if won else 0
        
        embed = self.create_embed(
            title="💰 Coinflip Bet",
            description=f"You bet **{amount}** on **{choice}**!\nThe coin landed on **{result}**!",
            color=0x57F287 if won else 0xED4245,
        )
        embed.add_field(name="Result", value="🎉 You Won!" if won else "😢 You Lost!", inline=True)
        embed.add_field(name="Payout", value=f"+{payout}" if won else f"-{amount}", inline=True)
        
        await interaction.response.send_message(embed=embed)
    
    # ==================== 8BALL ====================
    
    @app_commands.command(name="8ball", description="Ask the magic 8-ball a question")
    @app_commands.describe(question="Your question")
    async def eightball(self, interaction: discord.Interaction, question: str):
        """Ask the magic 8-ball"""
        responses = [
            "🎱 It is certain.",
            "🎱 It is decidedly so.",
            "🎱 Without a doubt.",
            "🎱 Yes, definitely.",
            "🎱 You may rely on it.",
            "🎱 As I see it, yes.",
            "🎱 Most likely.",
            "🎱 Outlook good.",
            "🎱 Yes.",
            "🎱 Signs point to yes.",
            "🎱 Reply hazy, try again.",
            "🎱 Ask again later.",
            "🎱 Better not tell you now.",
            "🎱 Cannot predict now.",
            "🎱 Concentrate and ask again.",
            "🎱 Don't count on it.",
            "🎱 My reply is no.",
            "🎱 My sources say no.",
            "🎱 Outlook not so good.",
            "🎱 Very doubtful.",
        ]
        
        answer = self.rng.choice(responses)
        
        embed = self.create_embed(
            title="🎱 Magic 8-Ball",
            description=f"**Question:** {escape_user_text(question, 1000)}\n\n**Answer:** {answer}",
            color=0x5865F2,
            thumbnail="https://cdn.discordapp.com/emojis/1067708531628077127.png"
        )
        embed.set_footer(text=f"Asked by {escape_user_text(interaction.user.display_name, 80)}")
        
        await interaction.response.send_message(embed=embed)
    
    # ==================== TRIVIA ====================
    
    @app_commands.command(name="trivia", description="Start a private, select-menu trivia question")
    @app_commands.describe(difficulty="Choose the question difficulty")
    @app_commands.choices(difficulty=[
        app_commands.Choice(name="Easy", value="easy"),
        app_commands.Choice(name="Medium", value="medium"),
        app_commands.Choice(name="Hard", value="hard"),
    ])
    async def trivia(self, interaction: discord.Interaction, difficulty: str = "easy") -> None:
        """Start one owner-bound trivia question without reading message content."""
        question = self.rng.choice(self.trivia_questions)
        answers = [str(answer) for answer in question["answers"]]
        correct_index = int(question["correct"])
        view = TriviaAnswerView(
            int(interaction.user.id),
            str(question["question"]),
            answers,
            correct_index,
            difficulty,
            db=getattr(self.bot, "db", None),
        )
        options = "\n".join(
            f"{chr(65 + index)}. {escape_user_text(answer)}"
            for index, answer in enumerate(answers)
        )
        embed = self.create_embed(
            title="🧠 Trivia Time!",
            description=f"**Question:** {escape_user_text(str(question['question']))}\n\n{options}",
            color=0x5865F2,
            footer=f"Difficulty: {difficulty.title()} · Choose an answer within two minutes",
        )
        message = await interaction.response.send_message(
            embed=embed,
            view=view,
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        message = await interaction.original_response()
        view.bind_message(message)
    
    # ==================== ROCK PAPER SCISSORS ====================
    
    @app_commands.command(name="rps", description="Play Rock Paper Scissors")
    @app_commands.describe(choice="Your choice")
    @app_commands.choices(choice=[
        app_commands.Choice(name="Rock", value="rock"),
        app_commands.Choice(name="Paper", value="paper"),
        app_commands.Choice(name="Scissors", value="scissors"),
    ])
    async def rps(self, interaction: discord.Interaction, choice: str):
        """Play Rock Paper Scissors against the bot"""
        bot_choice = self.rng.choice(["rock", "paper", "scissors"])
        
        # Determine winner
        if choice == bot_choice:
            result = "tie"
            result_text = "It's a tie! 🤝"
            color = 0xFEE75C
        elif (choice == "rock" and bot_choice == "scissors") or \
             (choice == "paper" and bot_choice == "rock") or \
             (choice == "scissors" and bot_choice == "paper"):
            result = "win"
            result_text = "You win! 🎉"
            color = 0x57F287
        else:
            result = "lose"
            result_text = "You lose! 😢"
            color = 0xED4245
        
        embed = self.create_embed(
            title="✂️ Rock Paper Scissors",
            description=f"You chose **{choice}**\nI chose **{bot_choice}**\n\n**{result_text}**",
            color=color
        )
        embed.set_footer(text="Play again with /rps")
        
        await interaction.response.send_message(embed=embed)
    
    # ==================== SLOT MACHINE ====================
    
    @app_commands.command(name="slots", description="Play the slot machine")
    async def slots(self, interaction: discord.Interaction):
        """Play the slot machine"""
        symbols = ["🍒", "🍋", "🍊", "🍇", "🍉", "💎", "7️⃣", "🔔"]
        weights = [30, 25, 20, 15, 10, 5, 3, 2]  # weights for rarity
        
        # Spin
        result = [self.rng.weighted_choice(symbols, weights) for _ in range(3)]
        
        # Check wins
        if result[0] == result[1] == result[2]:
            if result[0] == "7️⃣":
                result_text = "🎰 JACKPOT! 🎰"
                color = 0xFEE75C
                multiplier = 100
            elif result[0] == "💎":
                result_text = "💎 DIAMOND! 💎"
                color = 0x5865F2
                multiplier = 50
            elif result[0] == "🔔":
                result_text = "🔔 BIG WIN! 🔔"
                color = 0xFEE75C
                multiplier = 25
            else:
                result_text = "🎉 THREE OF A KIND! 🎉"
                color = 0x57F287
                multiplier = 10
        elif result[0] == result[1] or result[1] == result[2] or result[0] == result[2]:
            result_text = "🎊 Pair! 🎊"
            color = 0x5865F2
            multiplier = 2
        else:
            result_text = "😢 No match. Try again!"
            color = 0xED4245
            multiplier = 0
        
        embed = self.create_embed(
            title="🎰 Slot Machine",
            description=f"**{' | '.join(result)}**\n\n{result_text}",
            color=color
        )
        embed.set_footer(text="Spin again with /slots")
        
        await interaction.response.send_message(embed=embed)
    
    # ==================== RANDOM NUMBER ====================
    
    @app_commands.command(name="random", description="Generate a random number")
    @app_commands.describe(minimum="Minimum value", maximum="Maximum value")
    async def random_number(self, interaction: discord.Interaction, minimum: int = 1, maximum: int = 100):
        """Generate a random number between min and max"""
        if minimum >= maximum:
            await interaction.response.send_message("❌ Maximum must be greater than minimum!", ephemeral=True)
            return
        
        number = self.rng.randint(minimum, maximum)
        
        embed = self.create_embed(
            title="🔢 Random Number",
            description=f"Your random number between **{minimum}** and **{maximum}** is:\n\n# **{number}**",
            color=0x5865F2
        )
        embed.set_footer(text=f"Generated for {escape_user_text(interaction.user.display_name, 80)}")
        
        await interaction.response.send_message(embed=embed)
    
    # ==================== CHOOSE ====================
    
    @app_commands.command(name="choose", description="Let the bot choose between options")
    @app_commands.describe(options="Comma-separated options to choose from")
    async def choose(self, interaction: discord.Interaction, options: str):
        """Choose randomly between options"""
        options_list = [opt.strip() for opt in options.split(",") if opt.strip()]
        
        if len(options_list) < 2:
            await interaction.response.send_message("❌ Please provide at least 2 options separated by commas!", ephemeral=True)
            return
        
        choice = self.rng.choice(options_list)
        safe_options = ", ".join(escape_user_text(option, 120) for option in options_list)
        if len(safe_options) > 3_000:
            safe_options = safe_options[:2_997] + "..."
        safe_choice = escape_user_text(choice, 120)
        
        embed = self.create_embed(
            title="🤔 Choosing...",
            description=f"Options: {safe_options}\n\n**I choose: {safe_choice}**",
            color=0x5865F2
        )
        embed.set_footer(text=f"Decided for {escape_user_text(interaction.user.display_name, 80)}")
        
        await interaction.response.send_message(embed=embed)
    
    # ==================== SHIP ====================
    
    @app_commands.command(name="ship", description="Ship two users together")
    @app_commands.describe(user1="First user", user2="Second user")
    async def ship(self, interaction: discord.Interaction, user1: discord.User, user2: discord.User):
        """Ship two users together"""
        if user1.id == user2.id:
            await interaction.response.send_message("❌ You can't ship someone with themselves!", ephemeral=True)
            return
        
        # Generate a stable pair score without seeding process-global randomness.
        compatibility = _ship_compatibility_score(user1.id, user2.id)
        
        hearts = "💖" * (compatibility // 20) + "🤍" * (5 - compatibility // 20)
        
        if compatibility >= 80:
            status = "💖 Soulmates!"
            color = 0xFF69B4
        elif compatibility >= 60:
            status = "💕 Great match!"
            color = 0xFF69B4
        elif compatibility >= 40:
            status = "💛 Good potential!"
            color = 0xFEE75C
        elif compatibility >= 20:
            status = "🤝 Could work!"
            color = 0xFEE75C
        else:
            status = "💔 Not compatible..."
            color = 0xED4245
        
        embed = discord.Embed(
            title="💘 Shipping Calculator",
            description=f"{user1.mention} 💕 {user2.mention}\n\n**Compatibility: {compatibility}%**\n{hearts}\n\n**{status}**",
            color=color
        )
        embed.set_footer(text="Results are for fun only! 💖")
        
        await interaction.response.send_message(embed=embed)
    
    # ==================== RANDOM FACT ====================
    
    @app_commands.command(name="fact", description="Get a random fun fact")
    async def fact(self, interaction: discord.Interaction):
        """Get a random fun fact"""
        facts = [
            "Honey never spoils. Archaeologists have found 3000-year-old honey that's still edible!",
            "A group of flamingos is called a 'flamboyance'.",
            "Octopuses have three hearts and blue blood.",
            "Bananas are berries, but strawberries aren't.",
            "A day on Venus is longer than a year on Venus.",
            "Wombat poop is cube-shaped.",
            "There are more trees on Earth than stars in the Milky Way.",
            "Sharks existed before trees.",
            "Cleopatra lived closer in time to the iPhone than to the Pyramids of Giza.",
            "A group of crows is called a 'murder'.",
            "The Eiffel Tower can be 15 cm taller during summer.",
            "Cows have best friends and get depressed when separated.",
            "The shortest war in history lasted 38 minutes.",
            "A shrimp's heart is in its head.",
            "There's a species of jellyfish that's biologically immortal."
        ]
        
        fact = self.rng.choice(facts)
        
        embed = self.create_embed(
            title="🧠 Did You Know?",
            description=fact,
            color=0x5865F2,
            thumbnail="https://cdn.discordapp.com/emojis/1067708531628077127.png"
        )
        embed.set_footer(text=f"Fact for {escape_user_text(interaction.user.display_name, 80)}")
        
        await interaction.response.send_message(embed=embed)
    
    # ==================== JOKE ====================
    
    @app_commands.command(name="joke", description="Get a random joke")
    async def joke(self, interaction: discord.Interaction):
        """Get a random joke"""
        jokes = [
            "Why don't scientists trust atoms? Because they make up everything!",
            "Why did the scarecrow win an award? He was outstanding in his field!",
            "I told my wife she was drawing her eyebrows too high. She looked surprised.",
            "Why don't eggs tell jokes? They'd crack each other up!",
            "I'm reading a book on anti-gravity. It's impossible to put down!",
            "What do you call a fake noodle? An impasta!",
            "Why did the coffee file a police report? It got mugged!",
            "I used to be a banker, but I lost interest.",
            "What do you call a bear with no teeth? A gummy bear!",
            "Parallel lines have so much in common. It's a shame they'll never meet.",
            "I would tell you a UDP joke, but you might not get it.",
            "Why do programmers prefer dark mode? Because light attracts bugs!",
            "What do you call a dinosaur with an extensive vocabulary? A thesaurus!",
        ]
        
        joke = self.rng.choice(jokes)
        
        embed = self.create_embed(
            title="😂 Random Joke",
            description=joke,
            color=0xFEE75C
        )
        embed.set_footer(text=f"Joke for {escape_user_text(interaction.user.display_name, 80)}")
        
        await interaction.response.send_message(embed=embed)
    
    # ==================== RANDOM USER ====================
    
    @app_commands.command(name="randomuser", description="Pick a random user from the server")
    async def random_user(self, interaction: discord.Interaction):
        """Pick a random user from the server"""
        if not interaction.guild:
            await interaction.response.send_message("❌ This command only works in servers!", ephemeral=True)
            return
        
        members = [m for m in interaction.guild.members if not m.bot]
        if not members:
            await interaction.response.send_message("❌ No users found!", ephemeral=True)
            return
        
        chosen = self.rng.choice(members)
        
        embed = discord.Embed(
            title="🎲 Random User",
            description=f"**{chosen.mention}** was randomly selected!",
            color=0x5865F2
        )
        embed.set_thumbnail(url=chosen.display_avatar.url)
        embed.set_footer(text=f"Selected from {len(members)} members")
        
        await interaction.response.send_message(embed=embed)
    
    # ==================== POLL ====================
    
    @app_commands.command(name="poll", description="Create a quick poll")
    @app_commands.describe(question="The poll question", options="Comma-separated options (max 10)")
    async def poll(self, interaction: discord.Interaction, question: str, options: str):
        """Create a quick poll with reactions"""
        options_list = [opt.strip() for opt in options.split(",") if opt.strip()]
        
        if len(options_list) < 2:
            await interaction.response.send_message("❌ Please provide at least 2 options!", ephemeral=True)
            return
        if len(options_list) > 10:
            await interaction.response.send_message("❌ Maximum 10 options allowed!", ephemeral=True)
            return
        
        emojis = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
        
        description = "\n".join(
            f"{emojis[i]} {escape_user_text(opt, 200)}"
            for i, opt in enumerate(options_list)
        )
        safe_question = escape_user_text(question, 500)
        
        embed = self.create_embed(
            title="📊 Poll",
            description=f"**{safe_question}**\n\n{description}",
            color=0x5865F2
        )
        embed.set_footer(text=f"Poll by {escape_user_text(interaction.user.display_name, 80)} | React to vote!")
        
        msg = await interaction.response.send_message(embed=embed, wait=True)
        
        for i in range(len(options_list)):
            await msg.add_reaction(emojis[i])
    
    # ==================== RATE ====================
    
    @app_commands.command(name="rate", description="Rate something out of 10")
    @app_commands.describe(thing="What to rate")
    async def rate(self, interaction: discord.Interaction, thing: str):
        """Rate something out of 10"""
        rating = self.rng.randint(1, 10)
        
        stars = "⭐" * rating + "☆" * (10 - rating)
        
        if rating >= 9:
            comment = "🏆 Perfection!"
        elif rating >= 7:
            comment = "👍 Pretty good!"
        elif rating >= 4:
            comment = "🤷 Decent."
        else:
            comment = "👎 Not great..."
        
        embed = self.create_embed(
            title="⭐ Rating",
            description=f"**{escape_user_text(thing, 400)}**\n\n**{rating}/10**\n{stars}\n\n*{comment}*",
            color=0xFEE75C
        )
        embed.set_footer(text=f"Rated by {escape_user_text(interaction.user.display_name, 80)}")
        
        await interaction.response.send_message(embed=embed)
    
    # ==================== COMPLIMENT ====================
    
    @app_commands.command(name="compliment", description="Give someone a compliment")
    @app_commands.describe(user="User to compliment (optional)")
    async def compliment(self, interaction: discord.Interaction, user: Optional[discord.User] = None):
        """Give a compliment"""
        target = user or interaction.user
        
        compliments = [
            "You have an amazing smile!",
            "You're incredibly thoughtful!",
            "Your creativity is inspiring!",
            "You make everyone around you feel welcome!",
            "You have a great sense of humor!",
            "You're stronger than you know!",
            "Your kindness makes the world better!",
            "You're doing amazing things!",
            "Your perspective is unique and valuable!",
            "You light up every room you enter!",
        ]
        
        compliment = self.rng.choice(compliments)
        
        embed = self.create_embed(
            title="💖 Compliment",
            description=f"{target.mention}, {compliment}",
            color=0xFF69B4
        )
        embed.set_footer(text=f"From {escape_user_text(interaction.user.display_name, 80)} with 💖")
        
        await interaction.response.send_message(embed=embed)
    
    # ==================== ROAST ====================
    
    @app_commands.command(name="roast", description="Playfully roast someone")
    @app_commands.describe(user="User to roast")
    async def roast(self, interaction: discord.Interaction, user: discord.User):
        """Playfully roast someone"""
        if user.id == interaction.user.id:
            await interaction.response.send_message("❌ You can't roast yourself!", ephemeral=True)
            return
        
        if user.bot:
            await interaction.response.send_message("❌ You can't roast bots!", ephemeral=True)
            return
        
        roasts = [
            f"{user.mention}, you're the reason the gene pool needs a lifeguard!",
            f"{user.mention}, you're like a cloud. When you disappear, it's a beautiful day!",
            f"{user.mention}, you're not stupid. You just have bad luck thinking.",
            f"{user.mention}, you're the human equivalent of a participation trophy!",
            f"{user.mention}, you have the perfect face for radio!",
            f"{user.mention}, you're proof that evolution can go in reverse!",
            f"{user.mention}, you're the reason God created the middle finger!",
            f"{user.mention}, you're like a slinky - not really good for anything, but fun to push down stairs!",
        ]
        
        roast = self.rng.choice(roasts)
        
        embed = self.create_embed(
            title="🔥 Roast",
            description=f"{user.mention}, {roast}",
            color=0xED4245
        )
        embed.set_footer(text=f"Roasted by {escape_user_text(interaction.user.display_name, 80)} 🔥")
        
        await interaction.response.send_message(embed=embed)
    
    # ==================== HUG ====================
    
    @app_commands.command(name="hug", description="Give someone a hug")
    @app_commands.describe(user="User to hug")
    async def hug(self, interaction: discord.Interaction, user: discord.User):
        """Give someone a virtual hug"""
        if user.id == interaction.user.id:
            await interaction.response.send_message("❌ You can't hug yourself! 🤗", ephemeral=True)
            return
        
        hugs = [
            "🤗 *wraps arms around*",
            "🤗 *gives a big bear hug*",
            "🤗 *squeezes tightly*",
            "🤗 *gives a warm embrace*",
            "🤗 *offers a comforting hug*",
        ]
        
        hug_action = self.rng.choice(hugs)
        
        embed = discord.Embed(
            title="🤗 Hug!",
            description=f"{interaction.user.mention} {hug_action} {user.mention}\n\n*Virtual hugs are the best hugs!*",
            color=0xFF69B4
        )
        embed.set_footer(text=f"From {escape_user_text(interaction.user.display_name, 80)} with 💖")
        
        await interaction.response.send_message(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(Discobot(bot))