"""Owner-checked, nonce-protected interactive crime, court, and tax views."""
from __future__ import annotations

import time
from typing import Optional

import discord

from core.crime import (
    CrimeAttemptOutcome,
    CrimePreview,
    CrimeService,
    LAWYER_CONVICTION_CHANCES,
    TaxEvasionPrompt,
    TrialPrompt,
    TrialResolution,
)
from core.errors import GameError
from core.money import format_cents
from core.views import OwnedView
from core.achievements import AchievementService
from cogs.legacy_views import check_and_notify_achievements


class CrimeConfirmationView(OwnedView):
    """Risk disclosure with one-use confirm and cancel controls."""

    def __init__(
        self,
        owner_id: int,
        preview: CrimePreview,
        service: CrimeService,
        achievement_service: Optional[AchievementService] = None,
    ) -> None:
        super().__init__(owner_id, preview.nonce, timeout=max(30, preview.expires_at - time.time()))
        self.preview = preview
        self.service = service
        self.achievement_service = achievement_service
        self.add_item(_CrimeConfirmButton(preview.nonce))
        self.add_item(_CrimeCancelButton(preview.nonce))

    async def confirm(self, interaction: discord.Interaction) -> None:
        try:
            result = await self.service.confirm_crime(interaction.user.id, self.nonce)
        except GameError as exc:
            self._disable_all()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
            self.stop()
            return
        self._disable_all()
        embed = attempt_embed(result)
        if result.trial is not None:
            trial_view = TrialView(
                interaction.user.id, result.trial, self.service, self.achievement_service
            )
            trial_view.bind_message(interaction.message)
            await interaction.response.edit_message(embed=embed, view=trial_view)
        else:
            await interaction.response.edit_message(embed=embed, view=self)
        self.stop()
        await check_and_notify_achievements(
            interaction, self.achievement_service, interaction.user.id
        )

    async def cancel(self, interaction: discord.Interaction) -> None:
        try:
            await self.service.cancel_preview(interaction.user.id, self.nonce)
        except GameError as exc:
            self._disable_all()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
            self.stop()
            return
        self._disable_all()
        await interaction.response.edit_message(
            content="Crime confirmation cancelled. No attempt was made.", embed=None, view=self
        )
        self.stop()

    def _disable_all(self) -> None:
        for child in self.children:
            if hasattr(child, "disabled"):
                child.disabled = True


class _CrimeConfirmButton(discord.ui.Button[CrimeConfirmationView]):
    def __init__(self, nonce: str) -> None:
        super().__init__(
            label="Confirm attempt",
            style=discord.ButtonStyle.danger,
            custom_id=f"crime:confirm:{nonce}",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        if isinstance(self.view, CrimeConfirmationView):
            await self.view.confirm(interaction)


class _CrimeCancelButton(discord.ui.Button[CrimeConfirmationView]):
    def __init__(self, nonce: str) -> None:
        super().__init__(
            label="Cancel",
            style=discord.ButtonStyle.secondary,
            custom_id=f"crime:cancel:{nonce}",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        if isinstance(self.view, CrimeConfirmationView):
            await self.view.cancel(interaction)


class TrialView(OwnedView):
    """Three lawyer choices bound to a single owner and persistent court nonce."""

    def __init__(
        self,
        owner_id: int,
        prompt: TrialPrompt,
        service: CrimeService,
        achievement_service: Optional[AchievementService] = None,
    ) -> None:
        super().__init__(owner_id, prompt.nonce, timeout=300)
        self.prompt = prompt
        self.service = service
        self.achievement_service = achievement_service
        for tier, label, style in (
            ("public", "Public defender · free", discord.ButtonStyle.secondary),
            ("standard", "Standard · $10,000", discord.ButtonStyle.primary),
            ("elite", "Elite · $100,000 × index", discord.ButtonStyle.success),
        ):
            self.add_item(_LawyerButton(tier, label, style, prompt.nonce))

    async def resolve(self, interaction: discord.Interaction, tier: str) -> None:
        try:
            result = await self.service.resolve_trial(interaction.user.id, self.nonce, tier)
        except GameError as exc:
            self._disable_all()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
            self.stop()
            return
        self._disable_all()
        await interaction.response.edit_message(embed=trial_resolution_embed(result), view=self)
        self.stop()
        await check_and_notify_achievements(
            interaction, self.achievement_service, interaction.user.id
        )

    def _disable_all(self) -> None:
        for child in self.children:
            if hasattr(child, "disabled"):
                child.disabled = True


class _LawyerButton(discord.ui.Button[TrialView]):
    def __init__(self, tier: str, label: str, style: discord.ButtonStyle, nonce: str) -> None:
        super().__init__(label=label, style=style, custom_id=f"crime:lawyer:{tier}:{nonce}")
        self.tier = tier

    async def callback(self, interaction: discord.Interaction) -> None:
        if isinstance(self.view, TrialView):
            await self.view.resolve(interaction, self.tier)


class TaxChoiceView(OwnedView):
    """One-use owner-only annual income-tax decision."""

    def __init__(
        self,
        owner_id: int,
        prompt: TaxEvasionPrompt,
        service: CrimeService,
        achievement_service: Optional[AchievementService] = None,
    ) -> None:
        super().__init__(owner_id, prompt.nonce, timeout=300)
        self.prompt = prompt
        self.service = service
        self.achievement_service = achievement_service
        for choice, label, style in (
            ("pay", "Pay tax", discord.ButtonStyle.success),
            ("evade_50", "Skip 50%", discord.ButtonStyle.secondary),
            ("evade_75", "Skip 75%", discord.ButtonStyle.primary),
            ("evade_100", "Skip 100%", discord.ButtonStyle.danger),
        ):
            self.add_item(_TaxButton(choice, label, style, prompt.nonce))

    async def resolve(self, interaction: discord.Interaction, choice: str) -> None:
        try:
            result = await self.service.resolve_tax_choice(interaction.user.id, self.nonce, choice)
        except GameError as exc:
            self._disable_all()
            await interaction.response.edit_message(content=exc.message, embed=None, view=self)
            self.stop()
            return
        self._disable_all()
        embed = discord.Embed(
            title="Tax decision recorded",
            description=result.message,
            color=discord.Color.orange() if result.evaded_amount else discord.Color.green(),
        )
        embed.add_field(name="Tax assessed", value=format_cents(result.tax_due), inline=True)
        embed.add_field(name="Deferred to audit risk", value=format_cents(result.evaded_amount), inline=True)
        await interaction.response.edit_message(embed=embed, view=self)
        self.stop()
        await check_and_notify_achievements(
            interaction, self.achievement_service, interaction.user.id
        )

    def _disable_all(self) -> None:
        for child in self.children:
            if hasattr(child, "disabled"):
                child.disabled = True


class _TaxButton(discord.ui.Button[TaxChoiceView]):
    def __init__(self, choice: str, label: str, style: discord.ButtonStyle, nonce: str) -> None:
        super().__init__(label=label, style=style, custom_id=f"crime:tax:{choice}:{nonce}")
        self.choice = choice

    async def callback(self, interaction: discord.Interaction) -> None:
        if isinstance(self.view, TaxChoiceView):
            await self.view.resolve(interaction, self.choice)


def crime_preview_embed(preview: CrimePreview) -> discord.Embed:
    """Display both success and arrest risks before a player confirms."""
    embed = discord.Embed(
        title=f"Crime risk · {preview.crime_name}",
        description=(
            f"{preview.description}\n\n"
            f"**Success chance:** {preview.success_chance:.1f}%\n"
            f"**Arrest chance if successful:** {preview.catch_chance:.1f}%\n"
            f"**Arrest chance if it fails:** {preview.failed_catch_chance:.1f}%\n"
            f"**Possible proceeds:** {format_cents(preview.loot_min)}–{format_cents(preview.loot_max)} (dirty cash)"
        ),
        color=discord.Color.orange(),
    )
    embed.set_footer(text=f"Age {preview.age} · Confirmation expires in about 5 minutes · Maximum two attempts per year")
    return embed


def attempt_embed(result: CrimeAttemptOutcome) -> discord.Embed:
    """Render a neutral fictional outcome without procedural crime details."""
    if result.caught:
        color = discord.Color.red()
    elif result.success:
        color = discord.Color.gold()
    else:
        color = discord.Color.blurple()
    embed = discord.Embed(title=f"Crime outcome · {result.crime_name}", description=result.message, color=color)
    embed.add_field(name="Success roll", value=f"{result.success_chance:.1f}%", inline=True)
    embed.add_field(name="Arrest roll", value=f"{result.catch_chance:.1f}%", inline=True)
    if result.loot:
        embed.add_field(name="Dirty cash", value=format_cents(result.loot), inline=False)
    if result.trial is not None:
        embed.add_field(name="Public defender", value="85% conviction chance · free", inline=False)
        embed.add_field(name="Standard lawyer", value="65% conviction chance · $10,000", inline=False)
        embed.add_field(name="Elite lawyer", value="40% conviction chance · $100,000 × price index", inline=False)
        embed.set_footer(text="Choose counsel below to resolve the pending trial.")
    return embed


def trial_embed(prompt: TrialPrompt) -> discord.Embed:
    """Show available lawyer tiers and the case awaiting a verdict roll."""
    embed = discord.Embed(
        title=f"Trial · {prompt.crime_name}",
        description=(
            "Choose counsel. The displayed percentage is the chance of conviction; "
            "a lower tier costs more but does not guarantee an outcome."
        ),
        color=discord.Color.dark_red(),
    )
    for tier, chance, cost in (
        ("Public defender", LAWYER_CONVICTION_CHANCES["public"], "Free"),
        ("Standard lawyer", LAWYER_CONVICTION_CHANCES["standard"], "$10,000"),
        ("Elite lawyer", LAWYER_CONVICTION_CHANCES["elite"], "$100,000 × price index"),
    ):
        embed.add_field(name=tier, value=f"Conviction chance: {chance:.0f}% · Cost: {cost}", inline=False)
    embed.set_footer(text=f"Case source: {prompt.source.replace('_', ' ')} · Buttons are owner-only and one-use")
    return embed


def trial_resolution_embed(result: TrialResolution) -> discord.Embed:
    """Render a resolved verdict from a ``TrialResolution`` result."""
    return discord.Embed(
        title=f"Trial resolved · {result.crime_name}",
        description=result.message,
        color=discord.Color.red() if result.convicted else discord.Color.green(),
    )


def tax_prompt_embed(prompt: TaxEvasionPrompt) -> discord.Embed:
    """Describe the high-earner tax choice without real-world evasion advice."""
    embed = discord.Embed(
        title="Annual tax choice",
        description=(
            f"Tax assessed: **{format_cents(prompt.tax_due)}**. Choose to pay or defer 50%, 75%, or 100%. "
            "Any skipped amount can trigger a future in-game audit, back taxes, and a sentence."
        ),
        color=discord.Color.orange(),
    )
    embed.set_footer(text="Fictional game decision · Resolve before advancing another year")
    return embed
