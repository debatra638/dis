"""Discord command extensions for LIFELINE."""
