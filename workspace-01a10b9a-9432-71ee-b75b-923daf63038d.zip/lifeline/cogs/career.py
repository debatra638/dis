"""Slash commands for employment, work effort, and retirement."""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from core.careers import CareerService, CareerStatus, WorkResult
from core.models import JobAction
from core.money import format_cents
from core.embeds import safe_text


def _status_embed(status: CareerStatus) -> discord.Embed:
    job = status.job
    career = status.career
    embed = discord.Embed(
        title=f"💼 {status.level_title}",
        description=(
            f"**Career:** {career.name}\n"
            f"**Annual salary:** {format_cents(job.salary)}"
            f"{' · Part-time' if job.is_part_time else ''}\n"
            f"**Performance:** {_performance_bar(job.performance)}\n"
            f"**Time in role:** {job.years_in_role} year(s)\n"
            f"**Time in career:** {job.years_in_career} year(s)"
        ),
        color=discord.Color.blue(),
    )
    if status.next_promotion_years is not None:
        embed.add_field(
            name="Promotion path",
            value=(
                f"Next level: **{career.levels[job.level].title}**\n"
                f"Needs performance ≥ 70 and {status.next_promotion_years} year(s) in this role"
            ),
            inline=False,
        )
    else:
        embed.add_field(name="Promotion path", value="You are at the top of this career ladder.", inline=False)
    if job.warnings:
        embed.add_field(name="Performance warnings", value=str(job.warnings), inline=True)
    embed.set_footer(text="Use /career work once per in-game year to affect performance")
    return embed


def _performance_bar(value: int) -> str:
    filled = max(0, min(10, value // 10))
    return f"{'🟩' * filled}{'⬛' * (10 - filled)} **{value}/100**"


def _work_embed(result: WorkResult) -> discord.Embed:
    sign = "+" if result.performance_after >= result.performance_before else ""
    embed = _status_embed(result.career_status)
    embed.title = f"🛠️ Work year · {result.career_status.level_title}"
    embed.description = (
        f"Effort: **{result.action.value.title()}**\n"
        f"Performance: {result.performance_before} → {result.performance_after} ({sign}"
        f"{result.performance_after - result.performance_before})\n"
        f"Annual salary: **{format_cents(result.career_status.job.salary)}**"
    )
    if result.stat_changes:
        effects = " · ".join(
            f"{key.title()} {'+' if delta > 0 else ''}{delta}"
            for key, delta in result.stat_changes.items()
        )
        embed.add_field(name="Stat effects", value=effects, inline=False)
    return embed


class CareerCog(commands.Cog):
    """Career browsing, applications, work actions, and retirement."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        life_engine = getattr(bot, "life_engine", None)
        self.service = (
            life_engine.careers if life_engine is not None
            else CareerService(bot.db, bot.rng, getattr(bot, "locks", None))
        )

    career = app_commands.Group(name="career", description="Find work and manage your career")

    @career.command(name="list", description="Browse available career paths and salaries")
    async def list_careers(self, interaction: discord.Interaction) -> None:
        embed = discord.Embed(
            title="Career paths",
            description="Salary figures are annual gross pay in the game's currency. Requirements apply when you apply.",
            color=discord.Color.blurple(),
        )
        for item in self.service.careers:
            first, last = item.levels[0], item.levels[-1]
            salary = f"{format_cents(first.annual_salary)}–{format_cents(last.annual_salary)} / year"
            requirement = (
                f"Age {item.minimum_age}+ · {item.minimum_education.value.replace('_', ' ').title()} "
                f"· Smarts {item.minimum_smarts}+"
            )
            if item.part_time_allowed:
                requirement += " · part-time available"
            embed.add_field(
                name=f"{item.name} (`{item.id}`)",
                value=f"{salary}\n{requirement}",
                inline=False,
            )
        embed.set_footer(text="Apply with /career apply; salaries are paid when you use /life age")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    async def career_autocomplete(
        self, interaction: discord.Interaction, current: str
    ) -> list[app_commands.Choice[str]]:
        """Suggest matching catalog careers, capped at Discord's 25-choice limit."""
        query = current.casefold().strip()
        matches = [
            career for career in self.service.careers
            if not query or query in career.id.casefold() or query in career.name.casefold()
        ]
        return [
            app_commands.Choice(
                name=f"{career.name} · age {career.minimum_age}+"[:100],
                value=career.id,
            )
            for career in matches[:25]
        ]

    @career.command(name="apply", description="Apply for a career path")
    @app_commands.describe(career_id="Career path", part_time="Take a reduced-hours role if available")
    @app_commands.autocomplete(career_id=career_autocomplete)
    @app_commands.checks.cooldown(1, 8.0, key=lambda interaction: interaction.user.id)
    async def apply(
        self,
        interaction: discord.Interaction,
        career_id: str,
        part_time: bool = False,
    ) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        status = await self.service.apply(interaction.user.id, career_id, part_time=part_time)
        embed = _status_embed(status)
        embed.description = f"You got the position! Your first paycheck arrives after your next year.\n\n{embed.description}"
        await interaction.followup.send(embed=embed, ephemeral=True)

    @career.command(name="status", description="View your current job and performance")
    async def career_status(self, interaction: discord.Interaction) -> None:
        status = await self.service.status(interaction.user.id)
        await interaction.response.send_message(embed=_status_embed(status), ephemeral=True)

    @career.command(name="history", description="View past and current career records")
    async def career_history(self, interaction: discord.Interaction) -> None:
        records = await self.service.history(interaction.user.id)
        embed = discord.Embed(
            title="Career history",
            description="No career records yet." if not records else "Your employment history for this life.",
            color=discord.Color.blurple(),
        )
        for record in records[:10]:
            years = f"Age {record.start_age}–{record.end_age}" if record.end_age is not None else f"Age {record.start_age}–present"
            end = f" · {record.end_reason.title()}" if record.end_reason else " · Current"
            embed.add_field(
                name=f"{record.career_name} · {record.top_title}",
                value=f"Reached level {record.max_level} · {years}{end}",
                inline=False,
            )
        embed.set_footer(text="Showing the latest 10 records")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @career.command(name="work", description="Choose your work effort for this in-game year")
    @app_commands.describe(effort="Hard, normal, or slack effort")
    @app_commands.choices(effort=[
        app_commands.Choice(name="Work hard — boost performance, gain stress", value="hard"),
        app_commands.Choice(name="Work normally — steady performance", value="normal"),
        app_commands.Choice(name="Slack off — relax, but risk performance", value="slack"),
    ])
    async def work(self, interaction: discord.Interaction, effort: str = "normal") -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await self.service.work(interaction.user.id, effort)
        await interaction.followup.send(embed=_work_embed(result), ephemeral=True)

    @career.command(name="quit", description="Leave your current job")
    async def quit(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        message = await self.service.quit(interaction.user.id)
        await interaction.followup.send(message, ephemeral=True)

    @career.command(name="retire", description="Retire permanently from the workforce (age 60+)")
    async def retire(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        character = await self.service.retire(interaction.user.id)
        await interaction.followup.send(
            f"🌅 **{safe_text(character.name, 80)}** has retired at age {character.age}.",
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(CareerCog(bot))
