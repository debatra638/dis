"""Slash commands for banking, household budgets, six loan types, and bankruptcy."""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from core.economy import EconomyService
from core.errors import GameError, ValidationError
from core.models import Lifestyle
from core.money import format_cents, parse_cents

_LOAN_CHOICES = [
    app_commands.Choice(name="Personal", value="personal"),
    app_commands.Choice(name="Student", value="student"),
    app_commands.Choice(name="Mortgage", value="mortgage"),
    app_commands.Choice(name="Auto", value="auto"),
    app_commands.Choice(name="Payday", value="payday"),
    app_commands.Choice(name="Loan shark", value="loan_shark"),
]
_LIFESTYLE_CHOICES = [
    app_commands.Choice(name="Frugal", value="frugal"),
    app_commands.Choice(name="Normal", value="normal"),
    app_commands.Choice(name="Lavish", value="lavish"),
]
_HOUSING_CHOICES = [
    app_commands.Choice(name="Live with family", value="parents"),
    app_commands.Choice(name="Rent", value="rent"),
]


def _parse_amount(text: str, *, allow_all: bool = False) -> int | None:
    """Convert one Discord string option to strict integer cents."""
    try:
        return parse_cents(text, allow_all=allow_all)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValidationError(str(exc)) from exc


def _status_embed(character: object, loans: list[dict[str, object]], collections: list[dict[str, object]]) -> discord.Embed:
    """Render balances, credit, housing, and active loan/collection details."""
    score = character.stats.credit_score if character.stats.credit_score is not None else 650
    embed = discord.Embed(
        title=f"Household finances · Age {character.age}",
        description=(
            f"**Cash:** {format_cents(character.cash)}\n"
            f"**Bank:** {format_cents(character.bank)}\n"
            f"**Debt:** {format_cents(character.debt_total)}\n"
            f"**Credit score:** {score}\n"
            f"**Price index:** {character.price_index:.3f} · **Lifestyle:** {character.lifestyle.value.title()}\n"
            f"**Housing:** {character.housing_type.value.replace('_', ' ').title()}"
            + (f" · annual rent {format_cents(character.rent_amount)}" if character.rent_amount else "")
        ),
        color=discord.Color.green(),
    )
    active = [row for row in loans if str(row["status"]) == "active"]
    if active:
        lines = [
            f"`#{row['loan_id']}` {str(row['loan_type']).replace('_', ' ').title()} · "
            f"{format_cents(int(row['balance']))} at {float(row['annual_rate']):.1%}; "
            f"annual due {format_cents(int(row['annual_payment']))}; misses {int(row['consecutive_misses'])}"
            for row in active[:10]
        ]
        embed.add_field(name="Active loans", value="\n".join(lines), inline=False)
    open_collections = [row for row in collections if str(row["status"]) == "open"]
    if open_collections:
        total = sum(int(row["balance_cents"]) for row in open_collections)
        embed.add_field(name="Collections", value=f"{len(open_collections)} open bill(s) · {format_cents(total)}", inline=False)
    if character.bankrupt_until_age is not None:
        embed.add_field(name="Credit rebuilding", value=f"Bankruptcy restriction through age {character.bankrupt_until_age}.", inline=False)
    embed.set_footer(text="All game money is stored as integer cents. This is fictional game accounting.")
    return embed


class EconomyCog(commands.Cog):
    """Expose the economic services without replacing existing command groups."""

    bank = app_commands.Group(name="bank", description="Move money between cash and savings")
    loan = app_commands.Group(name="loan", description="Apply for, review, and repay loans")
    finance = app_commands.Group(name="finance", description="Review household finances and bankruptcy")
    economy = app_commands.Group(name="economy", description="Manage housing and lifestyle")

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        service = getattr(bot, "economy_service", None)
        if service is None:
            service = EconomyService(bot.db, bot.rng, getattr(bot, "locks", None),
                                     data_loader=getattr(bot, "data_loader", None))
            bot.economy_service = service
        self.service: EconomyService = service

    @bank.command(name="status", description="View cash, savings, debt, and credit score")
    @app_commands.checks.cooldown(1, 2.0, key=lambda interaction: interaction.user.id)
    async def bank_status(self, interaction: discord.Interaction) -> None:
        """Show private account and liability details for the active life."""
        character, loans, collections = await self.service.loan_status(interaction.user.id)
        await interaction.response.send_message(
            embed=_status_embed(character, loans, collections), ephemeral=True
        )

    @bank.command(name="deposit", description="Deposit cash into savings")
    @app_commands.describe(amount="Non-negative dollars, such as $1,234.56 or $1.2k; use all for all cash")
    @app_commands.checks.cooldown(1, 1.0, key=lambda interaction: interaction.user.id)
    async def bank_deposit(self, interaction: discord.Interaction, amount: str) -> None:
        """Move a strict amount from cash to bank in one database transaction."""
        cents = _parse_amount(amount, allow_all=True)
        character, moved = await self.service.bank_transfer(interaction.user.id, "deposit", cents)
        await interaction.response.send_message(
            f"Deposited {format_cents(moved)}. Cash {format_cents(character.cash)} · bank {format_cents(character.bank)}.",
            ephemeral=True,
        )

    @bank.command(name="withdraw", description="Withdraw savings as cash")
    @app_commands.describe(amount="Non-negative dollars, such as $1,234.56 or $1.2k; use all for all savings")
    @app_commands.checks.cooldown(1, 1.0, key=lambda interaction: interaction.user.id)
    async def bank_withdraw(self, interaction: discord.Interaction, amount: str) -> None:
        """Move a strict amount from bank to cash in one database transaction."""
        cents = _parse_amount(amount, allow_all=True)
        character, moved = await self.service.bank_transfer(interaction.user.id, "withdraw", cents)
        await interaction.response.send_message(
            f"Withdrew {format_cents(moved)}. Cash {format_cents(character.cash)} · bank {format_cents(character.bank)}.",
            ephemeral=True,
        )

    @loan.command(name="list", description="Review current credit, loans, and collections")
    @app_commands.checks.cooldown(1, 2.0, key=lambda interaction: interaction.user.id)
    async def loan_list(self, interaction: discord.Interaction) -> None:
        """Show all active and historical loan balances to the owner only."""
        character, loans, collections = await self.service.loan_status(interaction.user.id)
        embed = _status_embed(character, loans, collections)
        historical = [row for row in loans if str(row["status"]) != "active"]
        if historical:
            lines = [
                f"`#{row['loan_id']}` {str(row['loan_type']).replace('_', ' ').title()} · {str(row['status']).title()}"
                for row in historical[-10:]
            ]
            embed.add_field(name="Closed/defaulted loans", value="\n".join(lines), inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @loan.command(name="apply", description="Apply for one of six fixed-rate loan products")
    @app_commands.describe(
        loan_type="Loan product",
        amount="Non-negative principal in dollars; use a suffix such as 5k or 1m",
        collateral_item_uid="Required asset ID for a mortgage or auto loan",
    )
    @app_commands.choices(loan_type=_LOAN_CHOICES)
    @app_commands.checks.cooldown(1, 3.0, key=lambda interaction: interaction.user.id)
    async def loan_apply(
        self,
        interaction: discord.Interaction,
        loan_type: str,
        amount: str,
        collateral_item_uid: int | None = None,
    ) -> None:
        """Underwrite and issue credit using server-owned balances and collateral."""
        cents = _parse_amount(amount)
        if cents is None:
            raise ValidationError("Enter a numeric loan amount.")
        quote, character, loan_id = await self.service.apply_for_loan(
            interaction.user.id, loan_type, cents, collateral_item_uid=collateral_item_uid
        )
        await interaction.response.send_message(
            f"Loan `#{loan_id}` approved: {format_cents(quote.principal_cents)} at "
            f"{quote.annual_rate:.1%} for {quote.term_years} year(s); annual amortized payment "
            f"{format_cents(quote.annual_payment_cents)}. Bank balance: {format_cents(character.bank)}.",
            ephemeral=True,
        )

    @loan.command(name="pay", description="Make an early payment on an active loan")
    @app_commands.describe(loan_id="The ID shown by /loan list", amount="Payment amount or all for the remaining balance")
    @app_commands.checks.cooldown(1, 1.0, key=lambda interaction: interaction.user.id)
    async def loan_pay(self, interaction: discord.Interaction, loan_id: int, amount: str = "all") -> None:
        """Pay an active loan without overdrawing cash or bank."""
        cents = _parse_amount(amount, allow_all=True)
        character, paid, remaining = await self.service.pay_loan(interaction.user.id, loan_id, cents)
        await interaction.response.send_message(
            f"Paid {format_cents(paid)} on loan `#{loan_id}`; remaining {format_cents(remaining)}. "
            f"Cash {format_cents(character.cash)} · bank {format_cents(character.bank)}.",
            ephemeral=True,
        )

    @finance.command(name="status", description="View your private household balance sheet")
    @app_commands.checks.cooldown(1, 2.0, key=lambda interaction: interaction.user.id)
    async def finance_status(self, interaction: discord.Interaction) -> None:
        """Show the same account summary under the household finance group."""
        character, loans, collections = await self.service.loan_status(interaction.user.id)
        await interaction.response.send_message(
            embed=_status_embed(character, loans, collections), ephemeral=True
        )

    @finance.command(name="bankruptcy", description="File once when insolvent and discharge eligible unsecured debt")
    @app_commands.checks.cooldown(1, 5.0, key=lambda interaction: interaction.user.id)
    async def finance_bankruptcy(self, interaction: discord.Interaction) -> None:
        """Record a server-validated, cooldown-limited bankruptcy filing."""
        character, debt_before, discharged = await self.service.file_bankruptcy(interaction.user.id)
        await interaction.response.send_message(
            f"Bankruptcy filed. Debts before filing: {format_cents(debt_before)}; eligible unsecured debt discharged: "
            f"{format_cents(discharged)}. Credit score reset to {character.stats.credit_score}; "
            f"new credit is restricted until age {character.bankrupt_until_age}.",
            ephemeral=True,
        )

    @economy.command(name="status", description="View annual housing, lifestyle, and money summary")
    @app_commands.checks.cooldown(1, 2.0, key=lambda interaction: interaction.user.id)
    async def economy_status(self, interaction: discord.Interaction) -> None:
        """Show economic state privately."""
        character, loans, collections = await self.service.loan_status(interaction.user.id)
        await interaction.response.send_message(
            embed=_status_embed(character, loans, collections), ephemeral=True
        )

    @economy.command(name="lifestyle", description="Choose a yearly household spending style")
    @app_commands.choices(style=_LIFESTYLE_CHOICES)
    @app_commands.checks.cooldown(1, 2.0, key=lambda interaction: interaction.user.id)
    async def economy_lifestyle(self, interaction: discord.Interaction, style: str) -> None:
        """Set frugal, normal, or lavish household spending for future years."""
        character = await self.service.set_lifestyle(interaction.user.id, style)
        await interaction.response.send_message(
            f"Lifestyle set to **{character.lifestyle.value.title()}**. It changes future annual bills.",
            ephemeral=True,
        )

    @economy.command(name="housing", description="Move in with family or sign a rental agreement")
    @app_commands.choices(mode=_HOUSING_CHOICES)
    @app_commands.describe(mode="Housing arrangement", annual_rent="Optional annual rent for a rental")
    @app_commands.checks.cooldown(1, 2.0, key=lambda interaction: interaction.user.id)
    async def economy_housing(
        self,
        interaction: discord.Interaction,
        mode: str,
        annual_rent: str | None = None,
    ) -> None:
        """Set parents/rent housing; homes are purchased or sold through existing shop commands."""
        rent = _parse_amount(annual_rent) if annual_rent is not None else None
        if rent is not None and mode != "rent":
            raise ValidationError("Annual rent is only used when choosing rent.")
        character = await self.service.set_housing(interaction.user.id, mode, rent)
        await interaction.response.send_message(
            f"Housing set to **{character.housing_type.value.replace('_', ' ').title()}**"
            + (f" at {format_cents(character.rent_amount)} per year." if character.rent_amount else "."),
            ephemeral=True,
        )


async def setup(bot: commands.Bot) -> None:
    """Register the economy command extension."""
    await bot.add_cog(EconomyCog(bot))
