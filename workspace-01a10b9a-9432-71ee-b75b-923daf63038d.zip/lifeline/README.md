# LIFELINE

LIFELINE is a Python-only, headless-engine-backed Discord life simulator. Slash commands guide a fictional character through school, work, relationships, a crime/prison loop, a shop, trades, casino games, investing, annual events, and an immutable life archive. Currency is stored as integer cents in SQLite. Casino and stock markets use fictional in-game currency only; there are no real-money deposits, withdrawals, or cash-outs.

## Requirements

- Python 3.10 or newer (Python 3.13 is supported by the pinned dependencies).
- A Discord application with a bot user and a server where you can install it.
- A Discord bot token. Keep it private; do not commit `.env`.

## Fresh install

From the project directory:

```bash
python3 --version
python3 -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
cp .env.example .env
```

Edit `.env` and set at least `DISCORD_TOKEN`. Set `OWNER_IDS` to a comma-separated list of Discord user IDs allowed to run `/admin` commands. For first-time command registration and development, set `DEV_GUILD_ID` to the server ID where the bot is installed. Start the bot with:

```bash
python bot.py
```

The database is created at `data/lifeline.db` by default. Override it with `DB_PATH`. `RNG_SEED` is optional and is intended for repeatable local/test runs, not production randomness. Logs use `LOG_LEVEL` (default `INFO`).

To obtain a Discord user ID for `OWNER_IDS` or `DEV_GUILD_ID`, enable Developer Mode in the Discord client, then right-click the user or server and choose **Copy User ID** or **Copy Server ID**.

## Discord Developer Portal and installation

1. In the [Discord Developer Portal](https://discord.com/developers/applications), create an application and open its **Bot** page. Use the bot token shown there as `DISCORD_TOKEN`; reset it immediately if it is exposed.
2. This bot uses application commands and the standard gateway intents. **Message Content, Server Members, and Presence privileged intents are not enabled or needed for the core LIFELINE command set.** Do not enable privileged intents unless you later add a feature that needs them.
3. On the app's **Installation** page, configure a **Guild Install** with the `bot` and `applications.commands` scopes. Discord currently includes `applications.commands` with the `bot` scope, but listing both makes the intended installation clear.
4. Grant only the bot permissions needed to answer interactions, render embeds, and add the numbered reactions used by `/poll`: **View Channels**, **Send Messages**, **Embed Links**, and **Add Reactions**. Do not grant Administrator. Server members need access to application commands in the channels where they use the bot. `/admin` is hidden from non-administrators in Discord and also checks `OWNER_IDS` server-side, so configured owners must have the **Administrator** user permission; the bot itself must not receive it. `/guild_death_summaries` is restricted to a human with **Manage Server**; this is a user permission, not a bot permission.
5. Install the bot through the generated Guild Install URL. Start it with `DEV_GUILD_ID` set; startup copies and syncs commands to that development guild. Once `/admin sync` is visible, an authorized `OWNER_IDS` user can publish the command tree globally with `/admin sync`. Startup deliberately does not sync globally when `DEV_GUILD_ID` is empty.

Official references: [Discord OAuth2 scopes](https://discord.com/developers/docs/topics/oauth2), [Application Commands](https://discord.com/developers/docs/interactions/application-commands), [Getting Started / Installation](https://discord.com/developers/docs/quick-start/getting-started), and [Gateway intents](https://discord.com/developers/docs/topics/gateway).

## Slash-command reference

### Life and education

- `/life start`, `/life status`, `/life age`, `/life choice`
- `/education status`, `/education study`, `/education enroll`
- `/career list`, `/career apply`, `/career status`, `/career history`, `/career work`, `/career quit`, `/career retire`

### Relationships, crime, and custody

- `/family`
- `/relationship list`, `/relationship interact`, `/relationship propose`, `/relationship marry`, `/relationship divorce`, `/relationship breakup`, `/relationship try_for_baby`, `/relationship adopt`, `/relationship temptation`
- `/date find`, `/friends find`
- `/crime list`, `/crime commit`, `/crime launder`, `/crime record`
- `/prison status`, `/prison action`

### Economy, health, and care

- `/bank status`, `/bank deposit`, `/bank withdraw`
- `/loan list`, `/loan apply`, `/loan pay`
- `/finance status`, `/finance bankruptcy`
- `/economy status`, `/economy lifestyle`, `/economy housing`
- `/health status`, `/health doctor`, `/health hospital`, `/health therapy`, `/health activity`, `/health insurance`, `/health surgery`
- Top-level care aliases: `/doctor`, `/hospital`, `/therapy`, and `/insurance`; each calls the same service as its `/health` counterpart.
- Choose `/health surgery` with `procedure: plastic` for adult-only cosmetic surgery: $20,000 base cost (indexed), no insurance coverage, and up to +5 looks once per in-game year. Keep `procedure: medical` and provide a condition ID for the existing medical surgery path.
- Money options accept non-negative integer-cent amounts such as `$1,234.56`, `1.2k`, or `3m`; `all` is accepted only on commands that explicitly allow it.
- Annual settlement applies inflation, progressive income tax, capital-gains tax, household expenses, housing, insurance premiums, bank interest/theft, amortizing loan payments, collections, and credit updates. Gambling's existing tax behavior remains separate.
- The health catalog contains 28 fictional conditions. Undiagnosed symptoms can develop or progress; clinical actions can diagnose and treat conditions, and activity affects exact health/fitness/wellbeing stats. Insurance is one-year prepaid with annual renewal.

### Shop, casino, and investing

- `/shop browse`, `/shop buy`, `/shop ring`
- `/inventory view`, `/inventory sell`, `/inventory use`
- `/trade offer`, `/trade list`, `/trade cancel`
- `/casino slots`, `/casino blackjack`, `/casino roulette`, `/casino coinflip`, `/casino compulsion`
- `/invest market`, `/invest buy`, `/invest sell`, `/invest portfolio`, `/invest history`, `/invest bonds buy`

### Archives, settings, and administration

- `/start` — start a fresh life (legacy-compatible root command)
- `/leaderboard`, `/achievements`, `/lives list`, `/lives view`, `/graveyard`, `/inheritance`, `/retire_life`
- `/leaderboard_privacy`, `/settings privacy`, `/settings leaderboard`, `/guild_death_summaries`
- `/admin give_money`, `/admin set_stat`, `/admin kill`, `/admin reset_player`, `/admin ban`, `/admin unban`, `/admin market_event`, `/admin reload_data`, `/admin audit`, `/admin sync`
- `/help`

### Lightweight social commands

These are separate from the persistent LIFELINE economy: `/coinflip`, `/roll`, `/bet`, `/8ball`, `/trivia`, `/rps`, `/slots`, `/random`, `/choose`, `/ship`, `/fact`, `/joke`, `/randomuser`, `/poll`, `/rate`, `/compliment`, `/roast`, and `/hug`.

## Verification and known scope limits

Run the ordinary unit and integration suite with:

```bash
pytest -q
```

The 500-complete-life integration run is intentionally opt-in because it exercises tens of thousands of SQLite-backed yearly transactions:

```bash
LIFELINE_RUN_FULL_LIVES=1 pytest -q -s tests/test_full_lives.py
```

Health conditions, doctor/hospital/therapy/surgery actions, annual lifestyle and insurance, six loan products, collections, repossession, bankruptcy, inflation, and progressive taxation are part of the current engine. Medical effects are fictional, PG-13, and not medical advice; no self-harm mechanic is present. Natural/health death and confirmed retirement are implemented; a crime sentence is not a separate crime-death mechanic. `/randomuser` selects from Discord's currently cached guild members because this bot intentionally does not request the privileged Server Members intent; that cache may not contain every server member. A live Discord login, invite, and command sync still require an operator's token and test guild.

See `DESIGN_NOTES.md` and `VERIFICATION_REPORT.md` for system details, measured results, and limitations.
