"""Integer-cent currency helpers and strict, non-negative player input parsing."""
from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_UP

CENT = Decimal("0.01")
MAX_CENTS = 9_000_000_000_000_000_000
MAX_INPUT_CENTS = 10_000_000_000_000
_MONEY_PATTERN = re.compile(
    r"^\s*\$?\s*((?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d{1,2})?)\s*([kKmM]?)\s*$"
)


def validate_cents(amount: int) -> int:
    """Validate an integer-cent amount and return it unchanged."""
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise TypeError("money amounts must be integer cents")
    if abs(amount) > MAX_CENTS:
        raise OverflowError("money amount is outside the supported range")
    return amount


def dollars_to_cents(amount: str | int | float | Decimal) -> int:
    """Convert a dollar value to cents using conventional half-up rounding."""
    try:
        raw_amount = Decimal(str(amount))
        if not raw_amount.is_finite():
            raise ValueError("money amount must be finite")
        decimal_amount = raw_amount.quantize(CENT, rounding=ROUND_HALF_UP)
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"invalid money amount: {amount!r}") from exc
    cents = int(decimal_amount * 100)
    return validate_cents(cents)


def cents_to_dollars(amount: int) -> Decimal:
    """Return a Decimal dollar value for display or calculation."""
    return (Decimal(validate_cents(amount)) / 100).quantize(CENT)


def format_cents(amount: int, *, symbol: str = "$", include_plus: bool = False) -> str:
    """Format integer cents with grouping and exactly two decimal places."""
    amount = validate_cents(amount)
    sign = "-" if amount < 0 else ("+" if include_plus and amount > 0 else "")
    absolute = abs(amount)
    return f"{sign}{symbol}{absolute // 100:,}.{absolute % 100:02d}"


def parse_cents(value: str, *, allow_all: bool = False) -> int | None:
    """Parse strict dollar input into cents; return ``None`` for allowed ``all``.

    The grammar accepts optional ``$``, correctly grouped commas, up to two
    decimal places, and optional ``k``/``m`` suffixes. It deliberately rejects
    signs, exponents, malformed grouping, non-finite values, and values above
    ``10^13`` cents. ``all`` is a sentinel only when a calling command opts in.
    """
    if not isinstance(value, str):
        raise TypeError("money input must be a string")
    stripped = value.strip()
    if stripped.lower() == "all":
        if allow_all:
            return None
        raise ValueError("`all` is not valid for this money amount")
    match = _MONEY_PATTERN.fullmatch(stripped)
    if match is None:
        raise ValueError("enter a non-negative amount such as `$1,234.56` or `$1.2k`")
    number, suffix = match.groups()
    try:
        amount = Decimal(number.replace(",", ""))
        multiplier = {"": Decimal(1), "k": Decimal(1_000), "m": Decimal(1_000_000)}[suffix.lower()]
        if not amount.is_finite() or amount < 0:
            raise ValueError("money amount must be finite and non-negative")
        cents = int((amount * multiplier * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError("enter a valid, finite money amount") from exc
    if cents > MAX_INPUT_CENTS:
        raise ValueError(f"money input cannot exceed {MAX_INPUT_CENTS:,} cents")
    return validate_cents(cents)


def scale_cents(amount: int, multiplier: int | float | Decimal) -> int:
    """Scale cents with half-up rounding for general-purpose conversions."""
    amount = validate_cents(amount)
    try:
        factor = Decimal(str(multiplier))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"invalid multiplier: {multiplier!r}") from exc
    if not factor.is_finite():
        raise ValueError("multiplier must be finite")
    return validate_cents(int((Decimal(amount) * factor).quantize(Decimal("1"), rounding=ROUND_HALF_UP)))


def charge_cents(amount: int, multiplier: int | float | Decimal) -> int:
    """Scale a non-negative charge upward so fractional cents are never underpaid."""
    return _scale_rounded(amount, multiplier, ROUND_CEILING, nonnegative=True)


def payout_cents(amount: int, multiplier: int | float | Decimal) -> int:
    """Scale a non-negative payout downward so fractional cents are never overpaid."""
    return _scale_rounded(amount, multiplier, ROUND_FLOOR, nonnegative=True)


def _scale_rounded(
    amount: int,
    multiplier: int | float | Decimal,
    rounding: str,
    *,
    nonnegative: bool,
) -> int:
    """Shared finite Decimal scaling with an explicit cent-rounding direction."""
    amount = validate_cents(amount)
    try:
        factor = Decimal(str(multiplier))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"invalid multiplier: {multiplier!r}") from exc
    if not factor.is_finite() or (nonnegative and (amount < 0 or factor < 0)):
        raise ValueError("amount and multiplier must be finite and non-negative")
    return validate_cents(int((Decimal(amount) * factor).quantize(Decimal("1"), rounding=rounding)))
