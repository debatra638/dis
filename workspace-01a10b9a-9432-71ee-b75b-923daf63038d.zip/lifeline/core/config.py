"""Environment-backed configuration and tunable game balance for LIFELINE."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Optional

from dotenv import load_dotenv

load_dotenv()


def _optional_int(value: str | None) -> Optional[int]:
    if value is None or not value.strip():
        return None
    try:
        return int(value.strip())
    except ValueError as exc:
        raise ValueError(f"Expected an integer environment value, got {value!r}") from exc


def _owner_ids(value: str | None = None) -> frozenset[int]:
    raw = os.getenv("OWNER_IDS", "") if value is None else value
    owners: set[int] = set()
    for part in raw.split(","):
        part = part.strip()
        if part:
            try:
                owners.add(int(part))
            except ValueError as exc:
                raise ValueError(f"OWNER_IDS contains a non-integer value: {part!r}") from exc
    return frozenset(owners)


@dataclass(frozen=True, slots=True)
class Config:
    """Runtime settings. Missing secrets are validated when the bot starts, not on import."""

    token: str = field(default_factory=lambda: os.getenv("DISCORD_TOKEN", "").strip())
    db_path: str = field(default_factory=lambda: os.getenv("DB_PATH", "data/lifeline.db"))
    dev_guild_id: Optional[int] = field(default_factory=lambda: _optional_int(os.getenv("DEV_GUILD_ID")))
    owner_ids: frozenset[int] = field(default_factory=_owner_ids)
    log_level: str = field(default_factory=lambda: os.getenv("LOG_LEVEL", "INFO").upper())
    rng_seed: Optional[int] = field(default_factory=lambda: _optional_int(os.getenv("RNG_SEED")))

    @property
    def discord_token(self) -> str:
        """Compatibility alias for callers that prefer an explicit token name."""
        return self.token

    @classmethod
    def from_env(cls) -> "Config":
        """Construct settings from the current process environment."""
        return cls()

    def require_token(self) -> str:
        """Return the bot token or raise a useful startup error."""
        if not self.token:
            raise RuntimeError("DISCORD_TOKEN is required. Copy .env.example to .env and set it.")
        return self.token


# Backwards-compatible module-level settings. They intentionally do not raise when
# DISCORD_TOKEN is absent, so importing game modules remains safe in tests/tools.
DISCORD_TOKEN: str = os.getenv("DISCORD_TOKEN", "").strip()
DEV_GUILD_ID: Optional[int] = _optional_int(os.getenv("DEV_GUILD_ID"))
OWNER_IDS: frozenset[int] = _owner_ids()
DB_PATH: str = os.getenv("DB_PATH", "data/lifeline.db")
LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO").upper()


class GameBalance:
    """Tunable game-balance values. Monetary figures are integer cents."""

    # Aging and mortality
    BASE_LIFESPAN_MEAN: int = 78
    LIFESPAN_MOD_RANGE: tuple[int, int] = (-8, 8)
    MAX_AGE: int = 120
    ANNUAL_EVENT_CHANCE: float = 0.68

    # 0–100 stat range
    STAT_MIN: int = 0
    STAT_MAX: int = 100

    # Birth stat distributions
    HEALTH_INIT_MEAN: int = 80
    HEALTH_INIT_STDDEV: float = 10.0
    HAPPINESS_INIT_MEAN: int = 70
    HAPPINESS_INIT_STDDEV: float = 12.0
    SMARTS_INIT_MEAN: int = 50
    SMARTS_INIT_STDDEV: float = 18.0
    LOOKS_INIT_MEAN: float = 50.0
    LOOKS_INIT_STDDEV: float = 18.0
    FITNESS_INIT_MEAN: float = 40.0
    FITNESS_INIT_STDDEV: float = 15.0

    # Stress and yearly stat drift
    BASE_STRESS: int = 10
    STRESS_DECAY_PER_YEAR: int = 2
    HAPPINESS_DRIFT_TARGET: int = 50
    HAPPINESS_DRIFT_RATE: int = 1

    # Wealth class probabilities at birth
    WEALTH_CLASSES: dict[str, float] = {
        "poor": 0.25,
        "working": 0.35,
        "middle": 0.28,
        "upper": 0.10,
        "rich": 0.02,
    }

    # Annual allowance by wealth class (integer cents; used by later economy stages)
    ALLOWANCE_BY_WEALTH: dict[str, int] = {
        "poor": 50_000,
        "working": 200_000,
        "middle": 500_000,
        "upper": 2_000_000,
        "rich": 20_000_000,
    }

    # Core annual economy (monetary values are integer cents; tuned after A/B verification)
    # Consumer prices follow a bounded Gaussian draw; salaries recover 80% of cumulative inflation.
    ANNUAL_INFLATION_MEAN: float = 0.028
    ANNUAL_INFLATION_STDDEV: float = 0.012
    ANNUAL_INFLATION_MIN: float = -0.01
    ANNUAL_INFLATION_MAX: float = 0.09
    WAGE_INFLATION_PASS_THROUGH: float = 0.8
    CAREER_SALARY_BASE_MULTIPLIER: float = 0.83
    CAREER_DEGREE_SALARY_MULTIPLIER: float = 0.71
    CAREER_PROMOTION_GROWTH_MULTIPLIER: float = 0.05
    INFLATION_INDEX_CAP: float = 20.0
    INCOME_TAX_BRACKETS: tuple[tuple[int | None, float], ...] = (
        (1_000_000, 0.10), (4_000_000, 0.35), (9_000_000, 0.35),
        (18_000_000, 0.45), (30_000_000, 0.50), (None, 0.55),
    )
    CAPITAL_GAINS_TAX_PERCENT: int = 20
    BANK_INTEREST_RATE: float = 0.01
    BANK_THEFT_ANNUAL_CHANCE: float = 0.001
    BANK_THEFT_MIN_FRACTION: float = 0.05
    BANK_THEFT_MAX_FRACTION: float = 0.15
    BASE_ANNUAL_LIVING_COST_CENTS: int = 1_200_000
    BASE_ANNUAL_RENT_CENTS: int = 1_800_000
    HOMELESS_SHELTER_COST_CENTS: int = 300_000
    ANNUAL_HEALTH_INSURANCE_PREMIUM_CENTS: int = 240_000
    HEALTH_INSURANCE_COPAY_PERCENT: int = 20
    HEALTH_ADDICTION_ANNUAL_DAMAGE_DIVISOR: float = 20.0
    HEALTH_ADDICTION_MORTALITY_DIVISOR: float = 200.0
    HEALTH_HOMELESS_MORTALITY_ADDITION: float = 0.3
    HEALTH_PRISON_MORTALITY_ADDITION: float = 0.2
    HEALTH_DOCTOR_FEE_CENTS: int = 35_000
    HEALTH_HOSPITAL_FEE_CENTS: int = 250_000
    HEALTH_THERAPY_FEE_CENTS: int = 12_500
    HEALTH_SURGERY_BASE_FEE_CENTS: int = 200_000
    HEALTH_SURGERY_PER_SEVERITY_CENTS: int = 100_000
    HEALTH_PLASTIC_SURGERY_FEE_CENTS: int = 2_000_000
    HEALTH_PLASTIC_SURGERY_LOOKS_BONUS: int = 5
    HEALTH_PLASTIC_SURGERY_MIN_AGE: int = 18
    HEALTH_DISEASE_ONSET_MULTIPLIER: float = 0.09
    HEALTH_DISEASE_PROGRESSION_AFTER_UNTREATED_YEARS: int = 3
    HEALTH_DISEASE_PROGRESSION_CHANCE: float = 0.20
    HEALTH_DISEASE_AGE_RISK_PER_YEAR: float = 0.01
    HEALTH_DISEASE_SEVERITY_MORTALITY_WEIGHT: float = 0.0012
    HEALTH_DISEASE_UNTREATED_MORTALITY_WEIGHT: float = 0.0005
    HEALTH_MAX_ILLNESS_HAZARD: float = 0.25

    # Crime chances, record impacts, sentencing, and custodial risk. Probabilities use 0–1
    # except values explicitly named *_PERCENT; sentence lengths and ranges are in years.
    CRIME_CHANCE_MIN_PERCENT: float = 3.0
    CRIME_CHANCE_MAX_PERCENT: float = 97.0
    CRIME_SUCCESS_SMARTS_WEIGHT: float = 0.3
    CRIME_SUCCESS_FITNESS_WEIGHT: float = 0.2
    CRIME_SUCCESS_LUCK_WEIGHT: float = 1.0
    CRIME_CATCH_NOTORIETY_WEIGHT: float = 0.4
    CRIME_CATCH_RECORD_WEIGHT: float = 3.0
    CRIME_FAILED_ATTEMPT_CATCH_MULTIPLIER: float = 1.5
    CRIME_RECORD_HIRING_PENALTY_PERCENT: float = 20.0
    CRIME_RECORD_HIRING_PENALTY_MAX_PERCENT: float = 95.0
    CRIME_RELEASE_HIRING_PENALTY_MAX_PERCENT: float = 20.0
    CRIME_RELEASE_HIRING_PENALTY_DECAY_PERCENT_PER_YEAR: float = 2.0
    CRIME_HIRING_CHANCE_MIN_PERCENT: float = 5.0
    CRIME_PUBLIC_COUNSEL_CONVICTION_PERCENT: float = 85.0
    CRIME_STANDARD_COUNSEL_CONVICTION_PERCENT: float = 65.0
    CRIME_ELITE_COUNSEL_CONVICTION_PERCENT: float = 40.0
    CRIME_ANNUAL_ARREST_BASE_CHANCE: float = 0.08
    CRIME_ANNUAL_ARREST_NOTORIETY_WEIGHT: float = 0.003
    CRIME_ANNUAL_ARREST_MAX_CHANCE: float = 0.97
    CRIME_TAX_AUDIT_BASE_CHANCE: float = 0.05
    CRIME_TAX_AUDIT_NOTORIETY_WEIGHT: float = 0.002
    CRIME_TAX_AUDIT_MAX_CHANCE: float = 0.97
    CRIME_UNLAUNDERED_CASH_AUDIT_CHANCE: float = 0.20
    CRIME_TAX_AUDIT_CRIMINAL_CHARGE_CHANCE: float = 0.30
    CRIME_PRISON_BEHAVIOR_REDUCTION_CHANCE: float = 0.20
    CRIME_PRISON_RIOT_ESCALATION_CHANCE: float = 0.10
    CRIME_PRISON_ESCAPE_CHANCE: float = 0.08
    CRIME_ESCAPE_REARREST_CHANCE: float = 0.30
    CRIME_PRISON_ESCAPE_EXTENSION_MIN_YEARS: int = 3
    CRIME_PRISON_ESCAPE_EXTENSION_MAX_YEARS: int = 5
    CRIME_PRISON_VIOLENCE_CHANCE: float = 0.15
    CRIME_PRISON_VIOLENCE_DAMAGE_MIN: int = 2
    CRIME_PRISON_VIOLENCE_DAMAGE_MAX: int = 8
    CRIME_PRISON_VIOLENCE_FATALITY_CHANCE: float = 0.09
    CRIME_JUVENILE_RECORD_SEALING_CHANCE: float = 0.50
    CRIME_FINE_ON_CAUGHT_LOOT_PERCENT: int = 50
    CRIME_SPOUSAL_DIVORCE_AFTER_CONVICTION_CHANCE: float = 0.25
    CRIME_CUSTODY_COST_PER_YEAR_CENTS: int = 5_200_000
    CRIME_PRISON_TIME_COST_PER_YEAR_CENTS: int = 1_700_000
    CRIME_LOST_WAGES_PER_PRISON_YEAR_CENTS: int = 3_500_000
    CRIME_RECORD_EV_BASE_ANNUAL_WAGE_CENTS: int = 2_500_000
    CRIME_RECORD_EV_JOB_SEARCH_CHANCE: float = 0.10
    CAREER_PROMOTION_TIME_MULTIPLIER: float = 1.0

    # Keep each roulette game's exact expected gross return at or below the 97% ceiling.
    CASINO_ROULETTE_PAYOUT_SCALE: float = 0.99
    CASINO_LOTTERY_JACKPOT_CENTS: int = 9_000_000_000
    HEALTH_ACTIVITY_EFFECTS: dict[str, dict[str, int]] = {
        "walk": {"cost_cents": 0, "health": 1, "fitness": 1, "happiness": 1, "stress": -1},
        "run": {"cost_cents": 0, "health": 2, "fitness": 3, "happiness": 1, "stress": -2},
        "gym": {"cost_cents": 5_000, "health": 2, "fitness": 4, "happiness": 1, "stress": -1},
        "mindfulness": {"cost_cents": 0, "health": 0, "fitness": 0, "happiness": 2, "stress": -4},
        "sports": {"cost_cents": 2_500, "health": 1, "fitness": 3, "happiness": 3, "stress": -1},
    }
    FORCED_STOCK_SALE_FEE_PERCENT: int = 1
    CREDIT_SCORE_START: int = 650
    CREDIT_SCORE_MIN: int = 300
    CREDIT_SCORE_MAX: int = 850
    BANKRUPTCY_COOLDOWN_YEARS: int = 10
    BANKRUPTCY_REBUILD_YEARS: int = 7
    BANKRUPTCY_DISCHARGEABLE_DEBT_ASSET_MULTIPLE: float = 2.0
    # User-directed $1.812m floor; do not interpret actionless cohort filing rates as natural choice data.
    BANKRUPTCY_MIN_DISCHARGEABLE_DEBT_CENTS: int = 181_200_000
    BANKRUPTCY_MIN_FIRST_LOAN_AGE_YEARS: int = 2
    BANKRUPTCY_REPAYMENT_HORIZON_YEARS: int = 10
    BANKRUPTCY_CASH_EXEMPTION_CENTS: int = 200_000
    LOAN_DEFAULT_AFTER_MISSES: int = 3
    LOAN_TERMS: dict[str, dict[str, int | float]] = {
        "personal": {"annual_rate": 0.12, "term_years": 5, "max_cents": 5_000_000, "min_credit": 600},
        "student": {"annual_rate": 0.05, "term_years": 10, "max_cents": 15_000_000, "min_credit": 0},
        "mortgage": {"annual_rate": 0.055, "term_years": 30, "max_cents": 200_000_000, "min_credit": 650},
        "auto": {"annual_rate": 0.08, "term_years": 5, "max_cents": 10_000_000, "min_credit": 600},
        "payday": {"annual_rate": 0.35, "term_years": 1, "max_cents": 200_000, "min_credit": 0},
        "loan_shark": {"annual_rate": 0.60, "term_years": 2, "max_cents": 1_000_000, "min_credit": 0},
    }

    # Inheritance tuning (used by later family/economy stages)
    INHERITANCE_BASE_MULTIPLIER: float = 0.09
    INHERITANCE_RANDOM_FACTOR: tuple[float, float] = (0.5, 1.5)

    LIFE_STAGES: dict[str, tuple[int, int]] = {
        "baby": (0, 2),
        "child": (3, 12),
        "teen": (13, 17),
        "young_adult": (18, 29),
        "adult": (30, 49),
        "middle_age": (50, 64),
        "senior": (65, 120),
    }

    # Achievement thresholds (used by later achievements stage)
    ACHIEVEMENT_THRESHOLDS: dict[str, int] = {
        "first_steps": 1,
        "graduate_hs": 18,
        "graduate_college": 22,
        "first_job": 1,
        "first_promotion": 1,
        "first_marriage": 1,
        "first_child": 1,
        "first_home": 1,
        "millionaire": 100_000_000,
        "billionaire": 100_000_000_000,
        "centenarian": 100,
    }

    LEGACY_POINTS_PER_LIFE_SCORE: int = 10
    LEGACY_POINT_STAT_BOOST_COST: int = 50
    LEGACY_MAX_STAT_BOOSTS_PER_LIFE: int = 2


config = Config()


def get_config() -> Config:
    """Get the default environment-backed configuration."""
    return config
