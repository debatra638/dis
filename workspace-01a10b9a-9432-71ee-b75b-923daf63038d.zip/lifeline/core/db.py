"""SQLite database access and ordered, repeat-safe SQL migrations."""
from __future__ import annotations

import logging
import time
from contextlib import asynccontextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import AsyncGenerator, Optional

import aiosqlite

logger = logging.getLogger("lifeline.db")


@dataclass(frozen=True, slots=True)
class ExecutionResult:
    """Metadata from a committed statement; use fetchone/fetchall for query rows."""

    lastrowid: Optional[int]
    rowcount: int


class DatabaseManager:
    """Manages the SQLite file used by the bot.

    Transactions use ``BEGIN IMMEDIATE`` so a read-modify-write action such as
    advancing a character's age cannot race another process writing the same DB.
    """

    def __init__(self, db_path: str):
        self.db_path = str(db_path)
        self._initialized = False

    async def initialize(self) -> None:
        """Create the database directory, enable WAL, then apply migrations."""
        if self._initialized:
            return
        if self.db_path != ":memory:":
            Path(self.db_path).expanduser().parent.mkdir(parents=True, exist_ok=True)

        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("PRAGMA foreign_keys = ON")
            journal_cursor = await db.execute("PRAGMA journal_mode = WAL")
            await journal_cursor.fetchone()
            await db.execute(
                """CREATE TABLE IF NOT EXISTS schema_version (
                       version INTEGER PRIMARY KEY,
                       applied_at INTEGER NOT NULL
                   )"""
            )
            await db.commit()

        await self._run_migrations()
        self._initialized = True
        logger.info("Database initialized at %s", self.db_path)

    async def _run_migrations(self) -> None:
        """Apply each ``NNN_name.sql`` file once, in ascending version order."""
        migrations_dir = Path(__file__).parent / "migrations"
        if not migrations_dir.exists():
            logger.warning("Migrations directory not found: %s", migrations_dir)
            return

        files: list[tuple[int, Path]] = []
        for path in migrations_dir.glob("*.sql"):
            try:
                version = int(path.stem.split("_", 1)[0])
            except (ValueError, IndexError):
                logger.warning("Skipping invalid migration filename: %s", path.name)
                continue
            files.append((version, path))

        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("PRAGMA foreign_keys = ON")
            journal_cursor = await db.execute("PRAGMA journal_mode = WAL")
            await journal_cursor.fetchone()
            db.row_factory = aiosqlite.Row
            cursor = await db.execute("SELECT COALESCE(MAX(version), 0) AS version FROM schema_version")
            row = await cursor.fetchone()
            current_version = int(row["version"] if row else 0)

        for version, migration_file in sorted(files):
            if version <= current_version:
                continue
            sql = migration_file.read_text(encoding="utf-8")
            logger.info("Applying migration %s: %s", version, migration_file.name)
            # executescript commits any pending transaction first. Include BEGIN,
            # version record, and COMMIT in the script itself to keep the migration
            # and its version marker atomic.
            script = (
                "BEGIN IMMEDIATE;\n"
                + sql
                + f"\nINSERT INTO schema_version(version, applied_at) "
                  f"VALUES ({version}, {int(time.time())});\nCOMMIT;"
            )
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute("PRAGMA foreign_keys = ON")
                journal_cursor = await db.execute("PRAGMA journal_mode = WAL")
                await journal_cursor.fetchone()
                try:
                    await db.executescript(script)
                except Exception:
                    await db.rollback()
                    raise
            current_version = version
            logger.info("Migration %s applied", version)

    @asynccontextmanager
    async def transaction(self) -> AsyncGenerator[aiosqlite.Connection, None]:
        """Yield a row-enabled connection inside an immediate transaction."""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("PRAGMA foreign_keys = ON")
            db.row_factory = aiosqlite.Row
            await db.execute("BEGIN IMMEDIATE")
            try:
                yield db
                await db.commit()
            except BaseException:
                await db.rollback()
                raise

    async def execute(self, query: str, params: tuple = ()) -> ExecutionResult:
        """Execute and commit one statement (prefer ``transaction`` for workflows).

        Returns cursor metadata only; use ``fetchone`` or ``fetchall`` for rows,
        because the operation-scoped connection is closed before this returns.
        """
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("PRAGMA foreign_keys = ON")
            cursor = await db.execute(query, params)
            result = ExecutionResult(lastrowid=cursor.lastrowid, rowcount=cursor.rowcount)
            await db.commit()
            await cursor.close()
            return result

    async def fetchone(self, query: str, params: tuple = ()) -> Optional[aiosqlite.Row]:
        """Fetch a single row, or ``None`` when no row matches."""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("PRAGMA foreign_keys = ON")
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(query, params)
            return await cursor.fetchone()

    async def fetchall(self, query: str, params: tuple = ()) -> list[aiosqlite.Row]:
        """Fetch all matching rows."""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("PRAGMA foreign_keys = ON")
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(query, params)
            return await cursor.fetchall()

    async def close(self) -> None:
        """Connections are opened per operation and close automatically."""
        self._initialized = False
