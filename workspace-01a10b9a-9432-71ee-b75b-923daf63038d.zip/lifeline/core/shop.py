"""Stage 8 shop, inventory, secured purchases, and atomic player trading."""
from __future__ import annotations

import copy
import json
import logging
import secrets
import time
from contextlib import AsyncExitStack, asynccontextmanager
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_FLOOR
from typing import Any, AsyncContextManager, AsyncIterator, Callable, Mapping, Optional

from .data_loader import DataLoader
from .economy import amortized_annual_payment
from .config import GameBalance
from .db import DatabaseManager
from .errors import (
    CharacterDead,
    CharacterInPrison,
    CharacterNotFound,
    ConcurrentUpdate,
    InsufficientFunds,
    StaleShopQuote,
    TradeNotFound,
    ValidationError,
)
from .locks import UserLockRegistry
from .models import Character, HousingType, Stats
from .money import format_cents, validate_cents
from .repositories.shop import ShopRepository
from .rng import RNG
from .validators import validate_item_catalog

logger = logging.getLogger("lifeline.shop")
TRADE_TTL_SECONDS = 10 * 60
TRADE_DAILY_LIMIT = 5
TRADE_TAX_PERCENT = 5
IMBALANCE_BASE_CENTS = 10_000_000
ACCOUNT_AGE_REQUIRED_SECONDS = 7 * 24 * 60 * 60


@dataclass(frozen=True, slots=True)
class ShopQuote:
    """Versioned price snapshot shown before a purchase confirmation."""

    user_id: int
    char_id: int
    item_id: str
    item_name: str
    quantity: int
    unit_price: int
    total_price: int
    balance: int
    version: int
    nonce: str
    expires_at: int
    age: int
    can_pay_cash: bool
    finance_type: Optional[str]
    down_payment: int
    loan_principal: int
    loan_term_years: int


@dataclass(frozen=True, slots=True)
class PurchaseReceipt:
    """Summary of a completed shop purchase."""

    item_id: str
    item_name: str
    quantity: int
    total_price: int
    paid_now: int
    loan_principal: int
    asset_id: int
    remaining_balance: int


@dataclass(frozen=True, slots=True)
class SaleReceipt:
    """Summary of item liquidation using the item's stored market value."""

    item_id: str
    item_name: str
    quantity: int
    payout: int
    remaining_balance: int


@dataclass(frozen=True, slots=True)
class UseReceipt:
    """Summary of item use and any random in-game payout."""

    item_id: str
    item_name: str
    quantity_remaining: int
    payout: int
    stats: Stats


@dataclass(frozen=True, slots=True)
class TradeReceipt:
    """Persisted trade proposal with its nonce and immutable terms."""

    trade_id: int
    nonce: str
    created_at: int
    expires_at: int
    from_user_id: int
    to_user_id: int
    offer_cash: int
    request_cash: int
    offer_items: tuple[tuple[str, int], ...]
    request_items: tuple[tuple[str, int], ...]
    imbalance_flag: bool


@dataclass(frozen=True, slots=True)
class TradeResult:
    """Terminal or still-pending response to a trade button or command."""

    success: bool
    status: str
    message: str


@dataclass(frozen=True, slots=True)
class ShopYearProgress:
    """Stage 8 effects applied by the existing yearly age transaction."""

    character: Character
    messages: tuple[str, ...] = ()
    business_income: int = 0


class ShopService:
    """Transactional shop and trading domain service for the Discord bot."""

    def __init__(
        self,
        db: DatabaseManager,
        rng: RNG,
        locks: Optional[UserLockRegistry] = None,
        *,
        clock: Callable[[], float] = time.time,
        data_loader: Optional[DataLoader] = None,
    ) -> None:
        self.db = db
        self.rng = rng
        self.locks = locks or UserLockRegistry()
        self.clock = clock
        self.repository = ShopRepository(db)
        loader = data_loader or DataLoader()
        document = loader.load_items()
        self.items: dict[str, dict[str, Any]] = {str(item["id"]): item for item in document["items"]}
        self.categories: tuple[str, ...] = tuple(sorted({str(item["category"]) for item in document["items"]}))

    def replace_catalog(self, document: dict[str, Any]) -> None:
        """Validate and atomically replace the shop's item definitions."""
        validate_item_catalog(document)
        items = {str(item["id"]): dict(item) for item in document["items"]}
        categories = tuple(sorted({str(item["category"]) for item in document["items"]}))
        self.items = items
        self.categories = categories

    def get_item(self, item_id: str) -> Optional[dict[str, Any]]:
        """Return a defensive item definition by its stable catalog ID."""
        item = self.items.get(str(item_id).strip().lower())
        return copy.deepcopy(item) if item is not None else None

    async def register_player(self, user_id: int, account_created_at: int) -> None:
        """Record a Discord account's original creation timestamp for anti-abuse checks."""
        if isinstance(user_id, bool) or not isinstance(user_id, int) or user_id <= 0:
            raise ValidationError("A valid Discord user is required.")
        if isinstance(account_created_at, bool) or not isinstance(account_created_at, int) or account_created_at < 0:
            raise ValidationError("A valid account creation time is required.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                await self.repository.insert_player(tx, user_id, account_created_at)

    async def browse(self, user_id: int, category: Optional[str] = None) -> list[dict[str, Any]]:
        """Return shop-visible catalog entries after validating the active life."""
        selected_category = str(category).strip().lower() if category else None
        if selected_category is not None and selected_category not in self.categories:
            raise ValidationError("That shop category does not exist.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                return [
                    {**dict(item), "price_cents": self._charge(int(item["base_price_cents"]), character.price_index)}
                    for item in self.items.values()
                    if item["shop_available"] and (selected_category is None or item["category"] == selected_category)
                ]

    async def quote_purchase(self, user_id: int, item_id: str, quantity: int = 1) -> ShopQuote:
        """Create a read-only, versioned quote for a single shop purchase."""
        item = self._catalog_item(item_id)
        if not item["shop_available"]:
            raise ValidationError("That item is not sold in the shop.")
        selected_quantity = self._validate_quantity(item, quantity)
        now = int(self.clock())
        quote_nonce = secrets.token_urlsafe(20)
        expires_at = now + 120
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._active_character(tx, user_id)
                self._check_not_prison(character)
                self._check_age(character, int(item["min_age"]), f"buy {item['name']}")
                owned = await self.repository.count_item_quantity(tx, character.char_id, item["id"])
                if owned + selected_quantity > int(item["max_quantity"]):
                    raise ValidationError(f"You can own at most {item['max_quantity']} of {item['name']} at a time.")
                unit_price = self._charge(int(item["base_price_cents"]), character.price_index)
                total_price = unit_price * selected_quantity
                validate_cents(total_price)
                finance_type, down_payment, principal, term = await self._financing_terms(tx, character, item, total_price)
                await self.repository.save_shop_quote(
                    tx, char_id=character.char_id, nonce=quote_nonce, item_id=str(item["id"]),
                    quantity=selected_quantity,
                    total_price=total_price,
                    balance_cents=character.cash + character.bank,
                    character_version=version,
                    created_at=now,
                    expires_at=expires_at,
                )
                return ShopQuote(
                    user_id=user_id,
                    char_id=character.char_id,
                    item_id=str(item["id"]),
                    item_name=str(item["name"]),
                    quantity=selected_quantity,
                    unit_price=unit_price,
                    total_price=total_price,
                    balance=character.cash + character.bank,
                    version=version,
                    nonce=quote_nonce,
                    expires_at=expires_at,
                    age=character.age,
                    can_pay_cash=character.cash + character.bank >= total_price,
                    finance_type=finance_type,
                    down_payment=down_payment,
                    loan_principal=principal,
                    loan_term_years=term,
                )

    async def purchase(
        self,
        user_id: int,
        item_id: str,
        quantity: int,
        *,
        expected_version: int,
        expected_total: int,
        nonce: str,
        payment_method: str = "cash",
        expected_down_payment: Optional[int] = None,
    ) -> PurchaseReceipt:
        """Complete a cash or secured item purchase against its versioned quote."""
        item = self._catalog_item(item_id)
        selected_quantity = self._validate_quantity(item, quantity)
        method = str(payment_method).strip().lower()
        if method not in {"cash", "finance"}:
            raise ValidationError("Choose cash or financing.")
        validate_cents(expected_total)
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._active_character(tx, user_id)
                self._check_not_prison(character)
                self._check_age(character, int(item["min_age"]), f"buy {item['name']}")
                quote = await self.repository.load_shop_quote(tx, character.char_id, nonce, now)
                if (
                    quote is None
                    or version != expected_version
                    or int(quote["character_version"]) != expected_version
                    or str(quote["item_id"]) != str(item["id"])
                    or int(quote["quantity"]) != selected_quantity
                    or int(quote["total_price"]) != expected_total
                    or int(quote["balance_cents"]) != character.cash + character.bank
                ):
                    raise StaleShopQuote()
                if not item["shop_available"]:
                    raise ValidationError("That item is not sold in the shop.")
                owned = await self.repository.count_item_quantity(tx, character.char_id, item["id"])
                if owned + selected_quantity > int(item["max_quantity"]):
                    raise ValidationError(f"You can own at most {item['max_quantity']} of {item['name']} at a time.")
                unit_price = self._charge(int(item["base_price_cents"]), character.price_index)
                total_price = unit_price * selected_quantity
                if total_price != expected_total:
                    raise StaleShopQuote()

                finance_type: Optional[str] = None
                down_payment = total_price
                principal = 0
                term_years = 0
                if method == "cash":
                    if character.cash + character.bank < total_price:
                        raise InsufficientFunds("You do not have enough cash and bank balance for that purchase.")
                else:
                    finance_type, down_payment, principal, term_years = await self._financing_terms(
                        tx, character, item, total_price
                    )
                    if finance_type is None:
                        raise ValidationError("This item is not eligible for mortgage or auto financing.")
                    if expected_down_payment is not None and expected_down_payment != down_payment:
                        raise StaleShopQuote()
                    if character.cash + character.bank < down_payment:
                        raise InsufficientFunds("You do not have enough available funds for the required down payment.")

                paid_now = total_price if method == "cash" else down_payment
                await self.repository.consume_shop_quote(tx, character.char_id, nonce)
                updated = self._deduct_funds(character, paid_now)
                updated = self._apply_effects(updated, item["effects_on_buy"], selected_quantity)
                asset_id = await self.repository.insert_item(
                    tx,
                    char_id=character.char_id,
                    item_id=str(item["id"]),
                    quantity=selected_quantity,
                    purchase_price=total_price,
                    current_value=total_price,
                    age=character.age,
                    now=now,
                )
                if method == "finance":
                    terms = GameBalance.LOAN_TERMS[str(finance_type)]
                    annual_rate = float(terms["annual_rate"])
                    annual_payment = amortized_annual_payment(principal, annual_rate, term_years)
                    await self.repository.create_loan_for_item(
                        tx,
                        char_id=character.char_id,
                        loan_type=str(finance_type),
                        principal=principal,
                        annual_payment=annual_payment,
                        term_years=term_years,
                        asset_id=asset_id,
                        annual_rate=annual_rate,
                        origination_age=character.age,
                    )
                    updated = replace(updated, debt_total=updated.debt_total + principal)
                if item["category"] == "housing":
                    updated = replace(
                        updated,
                        housing_type=HousingType.OWNED,
                        housing_item_id=asset_id,
                        rent_amount=0,
                    )
                updated = replace(updated, version=version + 1)
                await self.repository.save_character(tx, updated, version)
                if item["category"] == "business":
                    await self.repository.set_front_business_flag(tx, character.char_id, True)
                await self.repository.insert_audit(
                    tx,
                    now=now,
                    user_id=user_id,
                    char_id=character.char_id,
                    action="shop_purchase",
                    amount=total_price,
                    details={
                        "item_id": item["id"],
                        "quantity": selected_quantity,
                        "payment_method": method,
                        "down_payment": paid_now,
                        "loan_principal": principal,
                        "asset_id": asset_id,
                    },
                )
                return PurchaseReceipt(
                    item_id=str(item["id"]),
                    item_name=str(item["name"]),
                    quantity=selected_quantity,
                    total_price=total_price,
                    paid_now=paid_now,
                    loan_principal=principal,
                    asset_id=asset_id,
                    remaining_balance=updated.cash + updated.bank,
                )

    async def inventory(self, user_id: int) -> tuple[Character, list[dict[str, Any]]]:
        """Return one active character's live item rows, including lock/collateral state."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                assets = await self.repository.list_items(tx, character.char_id)
                return character, [self._inventory_display(row) for row in assets]

    async def sell(self, user_id: int, item_id: str, quantity: int = 1) -> SaleReceipt:
        """Sell unlocked items using only their stored current market values."""
        item = self._catalog_item(item_id)
        selected_quantity = self._validate_quantity(item, quantity)
        if item["category"] in {"license", "title", "weapon"} or item["crime_event_only"]:
            raise ValidationError("That item cannot be sold through the shop.")
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._active_character(tx, user_id)
                self._check_not_prison(character)
                rows = await self.repository.list_items(tx, character.char_id)
                candidates = [
                    row for row in rows
                    if row["item_id"] == item["id"] and not bool(row["is_locked"])
                    and not bool(row["collateralized"])
                ]
                available = sum(int(row["quantity"]) for row in candidates)
                if available < selected_quantity:
                    locked = any(row["item_id"] == item["id"] and bool(row["is_locked"]) for row in rows)
                    collateral = any(row["item_id"] == item["id"] and bool(row["collateralized"]) for row in rows)
                    if locked:
                        raise ValidationError("Items locked in a pending trade cannot be sold.")
                    if collateral:
                        raise ValidationError("Settle the collateral loan before selling that item.")
                    raise ValidationError("You do not own enough unlocked copies of that item to sell.")

                total_value = 0
                left = selected_quantity
                for row in candidates:
                    if left == 0:
                        break
                    selected = min(left, int(row["quantity"]))
                    portion = await self.repository.reduce_item(
                        tx,
                        asset_id=int(row["asset_id"]),
                        owner_char_id=character.char_id,
                        quantity=selected,
                    )
                    if portion is None:
                        raise ConcurrentUpdate("An item changed while the sale was processing. Please retry.")
                    total_value += int(portion["current_value"])
                    left -= selected
                multiplier = Decimal("0.94") if item["category"] == "housing" else Decimal("0.85")
                payout = self._payout(total_value, multiplier)
                updated = replace(character, cash=character.cash + payout, version=version + 1)
                if item["category"] == "housing":
                    updated = await self._reconcile_housing(tx, updated, now)
                await self.repository.save_character(tx, updated, version)
                if item["category"] == "business":
                    await self.repository.set_front_business_flag(
                        tx, character.char_id, await self.repository.has_front_business(tx, character.char_id)
                    )
                await self.repository.insert_audit(
                    tx,
                    now=now,
                    user_id=user_id,
                    char_id=character.char_id,
                    action="inventory_sell",
                    amount=payout,
                    details={"item_id": item["id"], "quantity": selected_quantity, "market_value": total_value},
                )
                return SaleReceipt(item["id"], item["name"], selected_quantity, payout, updated.cash + updated.bank)

    async def use(self, user_id: int, item_id: str) -> UseReceipt:
        """Apply one item-use effect, consuming one unit for consumables."""
        item = self._catalog_item(item_id)
        if not item["usable"]:
            raise ValidationError("That item has no use action.")
        if item["id"] in {"lottery_ticket", "gambling_rehab"}:
            raise ValidationError("This item is handled by the Stage 9 casino/treatment service. Use `/inventory use` in the bot.")
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._active_character(tx, user_id)
                self._check_not_prison(character)
                self._check_age(character, int(item["min_age"]), f"use {item['name']}")
                rows = await self.repository.list_items(tx, character.char_id)
                candidates = [
                    row for row in rows if row["item_id"] == item["id"]
                    and not bool(row["is_locked"]) and not bool(row["collateralized"])
                ]
                if not candidates:
                    if any(row["item_id"] == item["id"] and bool(row["is_locked"]) for row in rows):
                        raise ValidationError("Items locked in a pending trade cannot be used.")
                    raise ValidationError("You do not have an unlocked copy of that item.")
                asset = candidates[0]
                asset_id = int(asset["asset_id"])
                if not item["consumable"] and await self.repository.has_used_item(tx, asset_id, character.age):
                    raise ValidationError("You have already used this item during the current in-game year.")
                if item["consumable"]:
                    consumed = await self.repository.reduce_item(
                        tx, asset_id=asset_id, owner_char_id=character.char_id, quantity=1
                    )
                    if consumed is None:
                        raise ConcurrentUpdate("An item changed while the use action was processing. Please retry.")
                else:
                    await self.repository.record_item_use(tx, asset_id, character.age, now)
                updated = self._apply_effects(character, item["effects_on_use"], 1)
                payout_range = item["effects_on_use"].get("payout_range_cents")
                payout = 0
                if payout_range is not None:
                    payout = self.rng.randint(int(payout_range[0]), int(payout_range[1]))
                    updated = replace(updated, cash=updated.cash + payout)
                updated = replace(updated, version=version + 1)
                await self.repository.save_character(tx, updated, version)
                await self.repository.insert_audit(
                    tx,
                    now=now,
                    user_id=user_id,
                    char_id=character.char_id,
                    action="inventory_use",
                    amount=payout,
                    details={"item_id": item["id"], "asset_id": asset_id, "consumed": bool(item["consumable"])},
                )
                remaining = int(asset["quantity"]) - (1 if item["consumable"] else 0)
                return UseReceipt(item["id"], item["name"], remaining, payout, updated.stats)

    async def award_crime_event_item(self, user_id: int, item_id: str, quantity: int = 1) -> int:
        """Grant a legal, age-eligible crime-event-only item without exposing weapon purchases."""
        item = self._catalog_item(item_id)
        if not item["crime_event_only"] or item["category"] != "weapon":
            raise ValidationError("Only catalogued crime-event items can be awarded through this path.")
        selected_quantity = self._validate_quantity(item, quantity)
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._active_character(tx, user_id)
                self._check_not_prison(character)
                self._check_age(character, int(item["min_age"]), f"receive {item['name']}")
                if character.country.lower() not in {str(value) for value in item["legal_countries"]}:
                    raise ValidationError("That crime-event item is not legal in this character's country.")
                owned = await self.repository.count_item_quantity(tx, character.char_id, item["id"])
                if owned + selected_quantity > int(item["max_quantity"]):
                    raise ValidationError("The maximum quantity for that item has been reached.")
                item_value = self._charge(int(item["base_price_cents"]), character.price_index) * selected_quantity
                asset_id = await self.repository.insert_item(
                    tx, char_id=character.char_id, item_id=item["id"], quantity=selected_quantity,
                    purchase_price=0, current_value=item_value, age=character.age, now=now,
                )
                updated = replace(character, version=version + 1)
                await self.repository.save_character(tx, updated, version)
                await self.repository.insert_audit(
                    tx, now=now, user_id=user_id, char_id=character.char_id,
                    action="crime_event_item_award", amount=0,
                    details={"item_id": item["id"], "quantity": selected_quantity, "asset_id": asset_id},
                )
                return asset_id

    async def trade_candidates(self, from_user_id: int, to_user_id: int) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """Load both eligible adult inventories for the offer builder."""
        self._validate_distinct_users(from_user_id, to_user_id)
        async with self._hold_users((from_user_id, to_user_id)):
            async with self.db.transaction() as tx:
                characters = await self._load_trade_characters(tx, from_user_id, to_user_id)
                from_character = characters[from_user_id]
                to_character = characters[to_user_id]
                await self._validate_trade_player(tx, from_character)
                await self._validate_trade_player(tx, to_character)
                left = await self.repository.list_items(tx, from_character.char_id)
                right = await self.repository.list_items(tx, to_character.char_id)
                return self._tradeable_rows(left), self._tradeable_rows(right)

    async def create_trade(
        self,
        from_user_id: int,
        to_user_id: int,
        *,
        offered_items: Mapping[int, int],
        requested_items: Mapping[int, int],
        offer_cash: int = 0,
        request_cash: int = 0,
        nonce: Optional[str] = None,
    ) -> TradeReceipt:
        """Create a ten-minute offer, lock its offered items, and consume daily limits."""
        self._validate_distinct_users(from_user_id, to_user_id)
        offered = self._clean_item_quantities(offered_items)
        requested = self._clean_item_quantities(requested_items)
        sent_cash = self._validate_user_cash(offer_cash)
        received_cash = self._validate_user_cash(request_cash)
        if not offered and not requested and sent_cash == 0 and received_cash == 0:
            raise ValidationError("A trade must include at least one item or a nonzero cash amount.")
        now = int(self.clock())
        trade_nonce = nonce or secrets.token_urlsafe(24)
        day_key = datetime.fromtimestamp(now, tz=timezone.utc).strftime("%Y-%m-%d")
        async with self._hold_users((from_user_id, to_user_id)):
            async with self.db.transaction() as tx:
                characters = await self._load_trade_characters(tx, from_user_id, to_user_id)
                from_character = characters[from_user_id]
                to_character = characters[to_user_id]
                self._validate_trade_creation(from_character)
                self._validate_trade_creation(to_character)
                await self.repository.insert_player(tx, from_user_id, now)
                await self.repository.insert_player(tx, to_user_id, now)
                from_player = await self.repository.load_player(tx, from_user_id)
                to_player = await self.repository.load_player(tx, to_user_id)
                if from_player is None or to_player is None:
                    raise RuntimeError("trade player accounts could not be initialized")
                if bool(from_player["trade_banned"]) or bool(to_player["trade_banned"]):
                    raise ValidationError("A player in this trade is currently trade-banned.")
                if await self.repository.has_pending_outgoing(tx, from_user_id):
                    raise ValidationError("You already have a pending outgoing trade.")
                if await self.repository.trade_daily_count(tx, from_user_id, day_key) >= TRADE_DAILY_LIMIT:
                    raise ValidationError("You have reached the limit of five trades for today.")
                if await self.repository.trade_daily_count(tx, to_user_id, day_key) >= TRADE_DAILY_LIMIT:
                    raise ValidationError("The target player has reached the limit of five trades for today.")

                offered_rows = await self._validate_trade_lines(
                    tx, from_character, offered, expected_locked=False
                )
                requested_rows = await self._validate_trade_lines(
                    tx, to_character, requested, expected_locked=False
                )
                offer_value = sent_cash + sum(line["value"] for line in offered_rows)
                request_value = received_cash + sum(line["value"] for line in requested_rows)
                imbalance, receiver_id = self._imbalance_details(
                    offer_value, request_value, from_character, to_character, from_user_id, to_user_id
                )
                if imbalance:
                    receiver = from_player if receiver_id == from_user_id else to_player
                    created_at = int(receiver["created_at"])
                    if now - created_at < ACCOUNT_AGE_REQUIRED_SECONDS:
                        raise ValidationError("The higher-value side must go to a Discord account at least seven days old.")

                await self.repository.increment_trade_daily(tx, from_user_id, day_key)
                await self.repository.increment_trade_daily(tx, to_user_id, day_key)
                trade_id = await self.repository.create_trade(
                    tx,
                    from_user_id=from_user_id,
                    from_char_id=from_character.char_id,
                    to_user_id=to_user_id,
                    to_char_id=to_character.char_id,
                    offer_cash=sent_cash,
                    request_cash=received_cash,
                    now=now,
                    expires_at=now + TRADE_TTL_SECONDS,
                    nonce=trade_nonce,
                    imbalance_flag=imbalance,
                    imbalance_receiver_id=receiver_id,
                )
                for line in offered_rows:
                    await self.repository.add_trade_item(
                        tx, trade_id=trade_id, side="offer", item_uid=line["asset_id"],
                        item_id=line["item_id"], quantity=line["quantity"], value_snapshot=line["value"],
                    )
                for line in requested_rows:
                    await self.repository.add_trade_item(
                        tx, trade_id=trade_id, side="request", item_uid=line["asset_id"],
                        item_id=line["item_id"], quantity=line["quantity"], value_snapshot=line["value"],
                    )
                if offered and not await self.repository.lock_items(tx, from_character.char_id, tuple(offered)):
                    raise ValidationError("An offered item changed. Please rebuild the trade.")
                await self.repository.insert_audit(
                    tx,
                    now=now,
                    user_id=from_user_id,
                    char_id=from_character.char_id,
                    action="trade_offer_created",
                    amount=sent_cash + received_cash,
                    details={
                        "trade_id": trade_id,
                        "from_user_id": from_user_id,
                        "to_user_id": to_user_id,
                        "offered_item_uids": sorted(offered),
                        "requested_item_uids": sorted(requested),
                        "imbalance_flag": imbalance,
                        "imbalance_receiver_id": receiver_id,
                    },
                )
                if imbalance:
                    await self.repository.insert_audit(
                        tx,
                        now=now,
                        user_id=receiver_id,
                        char_id=(from_character.char_id if receiver_id == from_user_id else to_character.char_id),
                        action="trade_value_imbalance_flag",
                        amount=max(offer_value, request_value),
                        details={"trade_id": trade_id, "offer_value": offer_value, "request_value": request_value},
                    )
                return TradeReceipt(
                    trade_id=trade_id,
                    nonce=trade_nonce,
                    created_at=now,
                    expires_at=now + TRADE_TTL_SECONDS,
                    from_user_id=from_user_id,
                    to_user_id=to_user_id,
                    offer_cash=sent_cash,
                    request_cash=received_cash,
                    offer_items=tuple((str(line["item_id"]), int(line["quantity"])) for line in offered_rows),
                    request_items=tuple((str(line["item_id"]), int(line["quantity"])) for line in requested_rows),
                    imbalance_flag=imbalance,
                )

    async def accept_trade(self, trade_id: int, user_id: int, nonce: str) -> TradeResult:
        """Atomically accept a pending offer after re-fetching every life and item."""
        pair = await self.repository.trade_users_read(trade_id)
        if pair is None:
            raise TradeNotFound()
        if user_id != pair[1]:
            raise TradeNotFound("Only the target player can accept this trade.")
        now = int(self.clock())
        async with self._hold_users(pair):
            async with self.db.transaction() as tx:
                trade = await self.repository.load_trade(tx, trade_id)
                if trade is None:
                    raise TradeNotFound()
                if int(trade["to_user_id"]) != user_id:
                    raise TradeNotFound("Only the target player can accept this trade.")
                if trade["status"] != "pending":
                    return TradeResult(False, str(trade["status"]), str(trade["outcome_message"] or "This trade was already resolved."))
                if str(trade["nonce"]) != str(nonce):
                    return await self._fail_trade(tx, trade, now, "This trade confirmation was stale or invalid.")
                if int(trade["expires_at"]) <= now:
                    return await self._expire_trade(tx, trade, now)

                from_user = int(trade["from_user_id"])
                to_user = int(trade["to_user_id"])
                try:
                    characters = await self._load_trade_characters(tx, from_user, to_user, fail_not_found=True)
                except (CharacterDead, CharacterNotFound) as exc:
                    return await self._fail_trade(tx, trade, now, exc.message)
                from_character = characters[from_user]
                to_character = characters[to_user]
                if from_character.char_id != int(trade["from_char_id"]) or to_character.char_id != int(trade["to_char_id"]):
                    return await self._fail_trade(tx, trade, now, "A character life changed after the offer was made.")
                try:
                    self._validate_trade_creation(from_character)
                    self._validate_trade_creation(to_character)
                except (CharacterDead, CharacterInPrison, ValidationError) as exc:
                    return await self._fail_trade(tx, trade, now, exc.message)
                from_player = await self.repository.load_player(tx, from_user)
                to_player = await self.repository.load_player(tx, to_user)
                if from_player is None or to_player is None or bool(from_player["trade_banned"]) or bool(to_player["trade_banned"]):
                    return await self._fail_trade(tx, trade, now, "A player is no longer eligible to trade.")

                trade_lines = await self.repository.load_trade_items(tx, trade_id)
                if not trade_lines and (int(trade["offer_cash"]) == 0 and int(trade["request_cash"]) == 0):
                    return await self._fail_trade(tx, trade, now, "The trade has no items or cash to exchange.")
                validated_lines: list[dict[str, Any]] = []
                for line in trade_lines:
                    side = str(line["side"])
                    expected_owner = from_character.char_id if side == "offer" else to_character.char_id
                    asset = await self.repository.load_item(tx, int(line["item_uid"]))
                    if asset is None:
                        return await self._fail_trade(tx, trade, now, "An item in the offer was sold or no longer exists.")
                    if int(asset["char_id"]) != expected_owner or str(asset["item_id"]) != str(line["item_id"]):
                        return await self._fail_trade(tx, trade, now, "An item's ownership changed after the offer was made.")
                    item = self.items.get(str(line["item_id"]))
                    if item is None or not item["tradeable"]:
                        return await self._fail_trade(tx, trade, now, "An item in the offer is no longer tradeable.")
                    if bool(asset["collateralized"]):
                        return await self._fail_trade(tx, trade, now, "An item is now encumbered by an active collateral loan.")
                    if int(asset["quantity"]) < int(line["quantity"]):
                        return await self._fail_trade(tx, trade, now, "An item's available quantity changed after the offer was made.")
                    expected_locked = side == "offer"
                    if bool(asset["is_locked"]) != expected_locked:
                        return await self._fail_trade(tx, trade, now, "An item's lock state changed after the offer was made.")
                    current_value = self._portion(
                        int(asset["current_value"]), int(line["quantity"]), int(asset["quantity"])
                    )
                    validated_lines.append({
                        **dict(line),
                        "asset": asset,
                        "item": item,
                        "current_value": current_value,
                    })

                counts_from = await self.repository.list_items(tx, from_character.char_id)
                counts_to = await self.repository.list_items(tx, to_character.char_id)
                count_from = self._item_totals(counts_from)
                count_to = self._item_totals(counts_to)
                for line in validated_lines:
                    item_id = str(line["item_id"])
                    quantity = int(line["quantity"])
                    if line["side"] == "offer":
                        count_from[item_id] = count_from.get(item_id, 0) - quantity
                        count_to[item_id] = count_to.get(item_id, 0) + quantity
                    else:
                        count_to[item_id] = count_to.get(item_id, 0) - quantity
                        count_from[item_id] = count_from.get(item_id, 0) + quantity
                for item_id, count in count_from.items():
                    definition = self.items.get(item_id)
                    if definition is not None and count > int(definition["max_quantity"]):
                        return await self._fail_trade(tx, trade, now, "The sender would exceed the catalog quantity limit.")
                for item_id, count in count_to.items():
                    definition = self.items.get(item_id)
                    if definition is not None and count > int(definition["max_quantity"]):
                        return await self._fail_trade(tx, trade, now, "The recipient would exceed the catalog quantity limit.")

                offer_cash = int(trade["offer_cash"])
                request_cash = int(trade["request_cash"])
                offer_tax = self._percent_charge(offer_cash, TRADE_TAX_PERCENT)
                request_tax = self._percent_charge(request_cash, TRADE_TAX_PERCENT)
                from_due = offer_cash + offer_tax
                to_due = request_cash + request_tax
                if from_character.cash < from_due:
                    return await self._fail_trade(tx, trade, now, "The offerer no longer has enough cash for the transfer and trade tax.")
                if to_character.cash < to_due:
                    return await self._fail_trade(tx, trade, now, "The recipient no longer has enough cash for the transfer and trade tax.")

                offer_value = offer_cash + sum(int(line["current_value"]) for line in validated_lines if line["side"] == "offer")
                request_value = request_cash + sum(int(line["current_value"]) for line in validated_lines if line["side"] == "request")
                imbalance, receiver_id = self._imbalance_details(
                    offer_value, request_value, from_character, to_character, from_user, to_user
                )
                if imbalance:
                    receiver = from_player if receiver_id == from_user else to_player
                    if now - int(receiver["created_at"]) < ACCOUNT_AGE_REQUIRED_SECONDS:
                        return await self._fail_trade(tx, trade, now, "The high-value recipient account is too new for this imbalanced trade.")
                    if not bool(trade["imbalance_flag"]):
                        await self.repository.insert_audit(
                            tx, now=now, user_id=receiver_id,
                            char_id=(from_character.char_id if receiver_id == from_user else to_character.char_id),
                            action="trade_value_imbalance_flag", amount=max(offer_value, request_value),
                            details={"trade_id": trade_id, "offer_value": offer_value, "request_value": request_value},
                        )

                updated_from = replace(
                    from_character,
                    cash=from_character.cash - from_due + request_cash,
                    version=from_character.version + 1,
                )
                updated_to = replace(
                    to_character,
                    cash=to_character.cash - to_due + offer_cash,
                    version=to_character.version + 1,
                )
                # The savepoint keeps the terminal failure path all-or-nothing if a guarded update fails.
                await self.repository.begin_trade_item_transfers(tx)
                await self.repository.unlock_trade_items(tx, trade_id)
                for line in validated_lines:
                    side = str(line["side"])
                    sender = from_character if side == "offer" else to_character
                    recipient = to_character if side == "offer" else from_character
                    moved = await self.repository.transfer_item(
                        tx,
                        asset_id=int(line["item_uid"]),
                        from_char_id=sender.char_id,
                        to_char_id=recipient.char_id,
                        quantity=int(line["quantity"]),
                        to_age=recipient.age,
                        now=now,
                    )
                    if moved is None:
                        await self.repository.rollback_trade_item_transfers(tx)
                        return await self._fail_trade(tx, trade, now, "An item changed while the trade was being accepted.")
                await self.repository.finish_trade_item_transfers(tx)
                updated_from = await self._reconcile_housing(tx, updated_from, now)
                updated_to = await self._reconcile_housing(tx, updated_to, now)
                await self.repository.save_character(tx, updated_from, from_character.version)
                await self.repository.save_character(tx, updated_to, to_character.version)
                await self.repository.set_front_business_flag(
                    tx, from_character.char_id, await self.repository.has_front_business(tx, from_character.char_id)
                )
                await self.repository.set_front_business_flag(
                    tx, to_character.char_id, await self.repository.has_front_business(tx, to_character.char_id)
                )
                await self.repository.set_trade_status(
                    tx, trade_id, status="accepted", resolved_at=now,
                    outcome_message="Trade completed successfully.",
                )
                await self.repository.unlock_trade_items(tx, trade_id)
                await self.repository.insert_audit(
                    tx,
                    now=now,
                    user_id=to_user,
                    char_id=to_character.char_id,
                    action="trade_accepted",
                    amount=offer_cash + request_cash,
                    details={
                        "trade_id": trade_id,
                        "offer_cash": offer_cash,
                        "request_cash": request_cash,
                        "offer_tax": offer_tax,
                        "request_tax": request_tax,
                        "item_lines": [
                            {"side": line["side"], "item_id": line["item_id"], "quantity": line["quantity"]}
                            for line in validated_lines
                        ],
                        "imbalance_flag": imbalance,
                    },
                )
                return TradeResult(
                    True,
                    "accepted",
                    f"Trade completed. Cash tax: {format_cents(offer_tax + request_tax)}.",
                )

    async def decline_trade(self, trade_id: int, user_id: int, nonce: str) -> TradeResult:
        """Decline a pending offer and release its locked items."""
        return await self._resolve_non_accept(trade_id, user_id, nonce, expected_side="target", status="declined")

    async def cancel_trade(self, trade_id: int, user_id: int, nonce: Optional[str] = None) -> TradeResult:
        """Cancel the caller's pending outgoing offer and release its item locks."""
        return await self._resolve_non_accept(trade_id, user_id, nonce, expected_side="sender", status="cancelled")

    async def _resolve_non_accept(
        self,
        trade_id: int,
        user_id: int,
        nonce: Optional[str],
        *,
        expected_side: str,
        status: str,
    ) -> TradeResult:
        """Serialize one decline/cancel transition with a concurrent acceptance."""
        pair = await self.repository.trade_users_read(trade_id)
        if pair is None:
            raise TradeNotFound()
        expected_user = pair[1] if expected_side == "target" else pair[0]
        if user_id != expected_user:
            raise TradeNotFound("Only the player who owns this trade action can resolve it.")
        now = int(self.clock())
        async with self._hold_users(pair):
            async with self.db.transaction() as tx:
                trade = await self.repository.load_trade(tx, trade_id)
                if trade is None:
                    raise TradeNotFound()
                expected_user = int(trade["to_user_id"] if expected_side == "target" else trade["from_user_id"])
                if user_id != expected_user:
                    raise TradeNotFound("Only the player who owns this trade action can resolve it.")
                if trade["status"] != "pending":
                    return TradeResult(False, str(trade["status"]), str(trade["outcome_message"] or "This trade was already resolved."))
                active_row = await self.repository.load_active(tx, user_id)
                expected_char_id = int(trade["to_char_id"] if expected_side == "target" else trade["from_char_id"])
                if active_row is None:
                    return await self._fail_trade(tx, trade, now, "The player no longer has a living active character.")
                active_character = Character.from_dict(json.loads(active_row["data_json"]))
                if int(active_row["char_id"]) != expected_char_id or not active_character.is_alive:
                    return await self._fail_trade(tx, trade, now, "The active character changed after the offer was made.")
                if active_character.age < 18 or active_character.age < 5:
                    return await self._fail_trade(tx, trade, now, "The player no longer meets the adult trade age gate.")
                if nonce is not None and str(trade["nonce"]) != str(nonce):
                    return await self._fail_trade(tx, trade, now, "This trade confirmation was stale or invalid.")
                if int(trade["expires_at"]) <= now:
                    return await self._expire_trade(tx, trade, now)
                message = "Trade declined; offered items were unlocked." if status == "declined" else "Trade cancelled; offered items were unlocked."
                await self.repository.set_trade_status(
                    tx, trade_id, status=status, resolved_at=now, outcome_message=message
                )
                await self.repository.unlock_trade_items(tx, trade_id)
                await self.repository.insert_audit(
                    tx, now=now, user_id=user_id,
                    char_id=int(trade["to_char_id"] if expected_side == "target" else trade["from_char_id"]),
                    action=f"trade_{status}", amount=None, details={"trade_id": trade_id},
                )
                return TradeResult(True, status, message)

    async def expire_pending(self) -> int:
        """Expire due trade proposals; callers should also log uncaught loop errors."""
        now = int(self.clock())
        candidates = await self.repository.expired_trade_ids(now)
        expired = 0
        for candidate in candidates:
            pair = (int(candidate["from_user_id"]), int(candidate["to_user_id"]))
            async with self._hold_users(pair):
                async with self.db.transaction() as tx:
                    trade = await self.repository.due_pending_trade(tx, int(candidate["trade_id"]), now)
                    if trade is None:
                        continue
                    await self.repository.set_trade_status(
                        tx, int(trade["trade_id"]), status="expired", resolved_at=now,
                        outcome_message="Trade expired after ten minutes; offered items were unlocked.",
                    )
                    await self.repository.unlock_trade_items(tx, int(trade["trade_id"]))
                    await self.repository.insert_audit(
                        tx, now=now, user_id=int(trade["from_user_id"]),
                        char_id=int(trade["from_char_id"]), action="trade_expired", amount=None,
                        details={"trade_id": int(trade["trade_id"])},
                    )
                    expired += 1
        return expired

    async def trade_history(self, user_id: int) -> tuple[Character, list[dict[str, Any]]]:
        """Return the active character and its recent trade history."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                return character, await self.repository.trade_history(tx, user_id)

    async def advance_year(self, tx: Any, character: Character, *, now: int) -> ShopYearProgress:
        """Apply item markets, upkeep, business income, and non-prison loan payments."""
        if not character.is_alive:
            return ShopYearProgress(character)
        messages: list[str] = []
        assets = await self.repository.list_items(tx, character.char_id)
        updated = character
        for asset in assets:
            item = self.items.get(str(asset["item_id"]))
            if item is None or int(asset["current_value"]) <= 0:
                continue
            mean_return = -float(item["depreciation_rate_per_year"])
            volatility = float(item["market_volatility"])
            annual_return = self.rng.gauss(mean_return, volatility) if volatility > 0 else mean_return
            annual_return = max(-0.95, min(1.0, annual_return))
            new_value = max(0, int((Decimal(int(asset["current_value"])) * (Decimal("1") + Decimal(str(annual_return)))).to_integral_value(rounding=ROUND_FLOOR)))
            if new_value != int(asset["current_value"]):
                await self.repository.set_item_value(tx, int(asset["asset_id"]), new_value)
                messages.append(f"{item['name']} market value changed to {format_cents(new_value)}.")

        if updated.in_prison:
            return ShopYearProgress(updated, tuple(messages), 0)

        business_income = 0
        for asset in assets:
            item = self.items.get(str(asset["item_id"]))
            if item is None or item["category"] != "business":
                continue
            per_item_income = self._payout(int(item["yearly_effects"]["income_cents"]), Decimal(str(updated.price_index)))
            income = per_item_income * int(asset["quantity"])
            if income:
                updated = replace(updated, bank=updated.bank + income)
                business_income += income
                messages.append(f"{item['name']} earned {format_cents(income)} in annual business income.")

        stat_deltas: dict[str, int] = {}
        for asset in assets:
            item = self.items.get(str(asset["item_id"]))
            if item is None:
                continue
            quantity = int(asset["quantity"])
            upkeep = self._charge(int(item["yearly_upkeep_cents"]), updated.price_index) * quantity
            paid = min(upkeep, max(0, updated.cash) + max(0, updated.bank))
            if paid:
                updated = self._deduct_funds(updated, paid)
            if paid < upkeep:
                messages.append(f"You could not fully cover {item['name']} upkeep of {format_cents(upkeep)}.")
                continue
            for stat, delta in item["yearly_effects"]["stats"].items():
                stat_deltas[stat] = stat_deltas.get(stat, 0) + int(delta) * quantity
        if stat_deltas:
            stats = replace(updated.stats)
            for stat, delta in stat_deltas.items():
                setattr(stats, stat, getattr(stats, stat) + delta)
            updated = replace(updated, stats=stats.clamp_all())

        has_front = await self.repository.has_front_business(tx, updated.char_id)
        await self.repository.set_front_business_flag(tx, updated.char_id, has_front)
        return ShopYearProgress(updated, tuple(messages), business_income)

    async def _fail_trade(self, tx: Any, trade: dict[str, Any], now: int, message: str) -> TradeResult:
        """Commit a failed trade state and unlock items instead of rolling back validation failures."""
        trade_id = int(trade["trade_id"])
        await self.repository.set_trade_status(tx, trade_id, status="failed", resolved_at=now, outcome_message=message)
        await self.repository.unlock_trade_items(tx, trade_id)
        await self.repository.insert_audit(
            tx, now=now, user_id=int(trade["to_user_id"]), char_id=int(trade["to_char_id"]),
            action="trade_failed", amount=None, details={"trade_id": trade_id, "reason": message},
        )
        return TradeResult(False, "failed", message)

    async def _expire_trade(self, tx: Any, trade: dict[str, Any], now: int) -> TradeResult:
        """Commit an expired status when an interaction arrives after its deadline."""
        trade_id = int(trade["trade_id"])
        message = "Trade expired after ten minutes; offered items were unlocked."
        await self.repository.set_trade_status(tx, trade_id, status="expired", resolved_at=now, outcome_message=message)
        await self.repository.unlock_trade_items(tx, trade_id)
        return TradeResult(False, "expired", message)

    async def _validate_trade_lines(
        self,
        tx: Any,
        character: Character,
        quantities: dict[int, int],
        *,
        expected_locked: bool,
    ) -> list[dict[str, Any]]:
        """Validate trade item ownership and return its value at the offer snapshot."""
        rows_by_id = {int(row["asset_id"]): row for row in await self.repository.list_items(tx, character.char_id)}
        result: list[dict[str, Any]] = []
        for asset_id, quantity in quantities.items():
            row = rows_by_id.get(asset_id)
            if row is None:
                raise ValidationError("A selected item is no longer in that player's inventory.")
            item = self.items.get(str(row["item_id"]))
            if item is None or not item["tradeable"]:
                raise ValidationError("One selected item is not tradeable.")
            if bool(row["is_locked"]) != expected_locked:
                raise ValidationError("A selected item is locked in another trade or unavailable.")
            if bool(row["collateralized"]):
                raise ValidationError("Items with an active collateral loan cannot be traded.")
            if quantity > int(row["quantity"]):
                raise ValidationError("A selected item quantity changed; rebuild the trade.")
            if not item["stackable"] and quantity != 1:
                raise ValidationError("Non-stackable items can only be traded one at a time.")
            value = self._portion(int(row["current_value"]), quantity, int(row["quantity"]))
            result.append({
                "asset_id": asset_id,
                "item_id": str(row["item_id"]),
                "quantity": quantity,
                "value": value,
            })
        return result

    async def _financing_terms(
        self,
        tx: Any,
        character: Character,
        item: dict[str, Any],
        total_price: int,
    ) -> tuple[Optional[str], int, int, int]:
        """Return approved loan type, down payment, principal, and fixed annual term."""
        if not item["collateral_eligible"] or item["category"] not in {"housing", "vehicle"}:
            return None, total_price, 0, 0
        if await self.repository.has_defaulted_or_delinquent_loan(tx, character.char_id):
            return None, total_price, 0, 0
        credit_score = int(character.stats.credit_score if character.stats.credit_score is not None else 650)
        if item["category"] == "housing":
            loan_type = "mortgage"
            minimum_credit = 650
            down_payment = self._percent_charge(total_price, 10)
            term_years = 30
        else:
            loan_type = "auto"
            minimum_credit = 600
            down_payment = self._percent_charge(total_price, 20)
            term_years = 5
        if credit_score < minimum_credit:
            return None, down_payment, 0, term_years
        principal = total_price - down_payment
        return loan_type, down_payment, principal, term_years

    def _catalog_item(self, item_id: str) -> dict[str, Any]:
        """Resolve and validate a stable catalog ID or raise a user-safe error."""
        if not isinstance(item_id, str):
            raise ValidationError("Choose an item from the catalog.")
        item = self.items.get(item_id.strip().lower())
        if item is None:
            raise ValidationError("That item is not in the catalog.")
        return item

    @staticmethod
    def _validate_quantity(item: dict[str, Any], quantity: int) -> int:
        """Enforce stackability and the catalog's per-player quantity ceiling."""
        if isinstance(quantity, bool) or not isinstance(quantity, int):
            raise ValidationError("Quantity must be a whole number.")
        if quantity < 1 or quantity > int(item["max_quantity"]):
            raise ValidationError(f"Quantity must be between 1 and {item['max_quantity']}.")
        if not item["stackable"] and quantity != 1:
            raise ValidationError("That item is not stackable; buy, sell, or trade one at a time.")
        return quantity

    @staticmethod
    def _clean_item_quantities(values: Mapping[int, int]) -> dict[int, int]:
        """Normalize item UID quantities and reject malformed/non-positive lines."""
        if not isinstance(values, Mapping):
            raise ValidationError("Trade items must be selected from the inventory menu.")
        clean: dict[int, int] = {}
        for raw_uid, raw_quantity in values.items():
            if isinstance(raw_uid, bool) or isinstance(raw_quantity, bool):
                raise ValidationError("Trade item selections are invalid.")
            if not isinstance(raw_quantity, int) or not isinstance(raw_uid, (int, str)):
                raise ValidationError("Trade item selections must use whole-number IDs and quantities.")
            if isinstance(raw_uid, str) and not raw_uid.isdigit():
                raise ValidationError("Trade item selections must use whole-number IDs and quantities.")
            asset_id = int(raw_uid)
            quantity = raw_quantity
            if asset_id <= 0 or quantity <= 0:
                raise ValidationError("Trade item quantities must be positive whole numbers.")
            clean[asset_id] = quantity
        return clean

    async def _active_character(self, tx: Any, user_id: int) -> tuple[Character, int]:
        """Load an active life and authoritative optimistic version."""
        row = await self.repository.load_active(tx, user_id)
        if row is None:
            if await self.repository.has_any_life(tx, user_id):
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.version = int(row["version"])
        if not character.is_alive:
            raise CharacterDead()
        return character, int(row["version"])

    async def _load_trade_characters(
        self,
        tx: Any,
        from_user_id: int,
        to_user_id: int,
        *,
        fail_not_found: bool = False,
    ) -> dict[int, Character]:
        """Re-fetch and map the two active character rows inside a single transaction."""
        rows = await self.repository.load_active_many(tx, (from_user_id, to_user_id))
        result: dict[int, Character] = {}
        for user_id in (from_user_id, to_user_id):
            row = rows.get(user_id)
            if row is None:
                if fail_not_found:
                    continue
                if await self.repository.has_any_life(tx, user_id):
                    raise CharacterDead("A player in this trade no longer has a living active character.")
                raise CharacterNotFound("Both players need an active life to trade.")
            character = Character.from_dict(json.loads(row["data_json"]))
            character.version = int(row["version"])
            result[user_id] = character
        if fail_not_found and len(result) != 2:
            raise CharacterDead("A player in this trade no longer has a living active character.")
        return result

    @staticmethod
    def _validate_distinct_users(from_user_id: int, to_user_id: int) -> None:
        """Reject a self-trade before creating a database transaction."""
        if (
            isinstance(from_user_id, bool) or isinstance(to_user_id, bool)
            or not isinstance(from_user_id, int) or not isinstance(to_user_id, int)
            or from_user_id <= 0 or to_user_id <= 0
        ):
            raise ValidationError("Both players must be valid Discord users.")
        if from_user_id == to_user_id:
            raise ValidationError("You cannot trade with yourself or another character owned by you.")

    @staticmethod
    def _validate_trade_creation(character: Character) -> None:
        """Validate adult, living, out-of-custody status for a trade participant."""
        if not character.is_alive:
            raise CharacterDead("Both players must have living active characters to trade.")
        if character.in_prison:
            raise CharacterInPrison("Trading is unavailable while either character is in prison.")
        if character.age < 18 or character.age < 5:
            raise ValidationError("Both characters must be at least 18 and have lived at least five in-game years.")

    async def _validate_trade_player(self, tx: Any, character: Character) -> None:
        """Check life gates and any persisted trade-ban flag for offer building."""
        self._validate_trade_creation(character)
        player = await self.repository.load_player(tx, character.user_id)
        if player is not None and bool(player["trade_banned"]):
            raise ValidationError("This player is currently trade-banned.")

    @staticmethod
    def _check_not_prison(character: Character) -> None:
        """Reject shop, inventory modification, and item use while incarcerated."""
        if character.in_prison:
            raise CharacterInPrison()

    @staticmethod
    def _check_age(character: Character, minimum_age: int, action: str) -> None:
        """Enforce catalog age restrictions in the domain service, not only Discord UI."""
        if character.age < minimum_age:
            raise ValidationError(f"You must be at least {minimum_age} to {action}.")

    @staticmethod
    def _charge(amount: int, multiplier: float | Decimal) -> int:
        """Scale a price or upkeep with charge rounding toward the next cent."""
        try:
            factor = Decimal(str(multiplier))
            if not factor.is_finite() or factor < 0:
                raise ValueError
            result = int((Decimal(amount) * factor).to_integral_value(rounding=ROUND_CEILING))
        except (InvalidOperation, ValueError) as exc:
            raise ValidationError("This item's price index is invalid.") from exc
        return validate_cents(result)

    @staticmethod
    def _payout(amount: int, multiplier: float | Decimal) -> int:
        """Scale a market payout with round-down semantics."""
        factor = Decimal(str(multiplier))
        if not factor.is_finite() or factor < 0:
            raise ValueError("payout multiplier must be a finite non-negative number")
        result = int((Decimal(amount) * factor).to_integral_value(rounding=ROUND_FLOOR))
        return validate_cents(result)

    @staticmethod
    def _percent_charge(amount: int, percent: int) -> int:
        """Calculate a percentage fee in cents, rounding charges up."""
        if amount <= 0:
            return 0
        return (amount * percent + 99) // 100

    @staticmethod
    def _divide_up(amount: int, divisor: int) -> int:
        """Split loan principal into equal integer-cent annual payments, rounding up."""
        if amount <= 0 or divisor <= 0:
            return 0
        return (amount + divisor - 1) // divisor

    @staticmethod
    def _portion(total: int, selected_quantity: int, full_quantity: int) -> int:
        """Allocate an aggregate asset value pro rata, rounding a partial payout down."""
        if full_quantity <= 0 or selected_quantity <= 0:
            return 0
        if selected_quantity >= full_quantity:
            return total
        return max(0, total * selected_quantity // full_quantity)

    @staticmethod
    def _deduct_funds(character: Character, amount: int) -> Character:
        """Deduct bank funds before cash without allowing either balance to go negative."""
        if amount < 0 or character.cash + character.bank < amount:
            raise InsufficientFunds()
        bank_paid = min(max(0, character.bank), amount)
        cash_paid = amount - bank_paid
        return replace(
            character,
            cash=max(0, character.cash - cash_paid),
            bank=max(0, character.bank - bank_paid),
        )

    @staticmethod
    def _apply_effects(character: Character, effects: dict[str, Any], multiplier: int) -> Character:
        """Apply bounded catalog stats and flags, then use the shared stat clamp."""
        stats = replace(character.stats)
        for stat, delta in effects.get("stats", {}).items():
            setattr(stats, stat, getattr(stats, stat) + int(delta) * multiplier)
        flags = effects.get("flags", {})
        replacements: dict[str, Any] = {"stats": stats.clamp_all()}
        for key, value in flags.items():
            replacements[key] = bool(value)
        return replace(character, **replacements)

    def _inventory_display(self, row: dict[str, Any]) -> dict[str, Any]:
        """Combine stored item data with its catalog description for commands and views."""
        item = self.items.get(str(row["item_id"]))
        return {
            **row,
            "name": str(item["name"]) if item else str(row["item_id"]).replace("_", " ").title(),
            "category": str(item["category"]) if item else "legacy",
            "tradeable": bool(item and item["tradeable"]),
            "usable": bool(item and item["usable"]),
            "collateral_eligible": bool(item and item["collateral_eligible"]),
        }

    def _tradeable_rows(self, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Filter locked, collateralized, or nontradeable rows for the offer UI."""
        result: list[dict[str, Any]] = []
        for row in rows:
            item = self.items.get(str(row["item_id"]))
            if item is None or not item["tradeable"] or bool(row["is_locked"]) or bool(row["collateralized"]):
                continue
            result.append(self._inventory_display(row))
        return result

    @staticmethod
    def _item_totals(rows: list[dict[str, Any]]) -> dict[str, int]:
        """Aggregate item quantities by catalog ID."""
        totals: dict[str, int] = {}
        for row in rows:
            key = str(row["item_id"])
            totals[key] = totals.get(key, 0) + int(row["quantity"])
        return totals

    def _imbalance_details(
        self,
        offer_value: int,
        request_value: int,
        from_character: Character,
        to_character: Character,
        from_user_id: int,
        to_user_id: int,
    ) -> tuple[bool, Optional[int]]:
        """Detect a high-value transfer where one side contributes less than ten percent."""
        higher = max(offer_value, request_value)
        lower = min(offer_value, request_value)
        if higher <= 0 or lower * 10 >= higher:
            return False, None
        receiver_id = to_user_id if offer_value > request_value else from_user_id
        receiver = to_character if receiver_id == to_user_id else from_character
        threshold = self._charge(IMBALANCE_BASE_CENTS, receiver.price_index)
        return offer_value + request_value > threshold, receiver_id

    async def _reconcile_housing(self, tx: Any, character: Character, now: int) -> Character:
        """Keep the legacy character housing pointer aligned with owned home assets."""
        homes = await self.repository.list_housing_assets(tx, character.char_id)
        if character.housing_item_id is not None and any(
            int(home["asset_id"]) == int(character.housing_item_id) for home in homes
        ):
            return replace(character, housing_type=HousingType.OWNED, rent_amount=0)
        if homes:
            chosen = homes[0]
            return replace(
                character,
                housing_type=HousingType.OWNED,
                housing_item_id=int(chosen["asset_id"]),
                rent_amount=0,
            )
        if character.housing_type is HousingType.OWNED:
            if character.age < 18:
                return replace(character, housing_type=HousingType.PARENTS, housing_item_id=None, rent_amount=0)
            rent = self._charge(1_800_000, character.price_index)
            return replace(character, housing_type=HousingType.RENT, housing_item_id=None, rent_amount=rent)
        return character

    @staticmethod
    def _validate_user_cash(amount: int) -> int:
        """Validate nonnegative integer cents for a cash-trade field."""
        value = validate_cents(amount)
        if value < 0:
            raise ValidationError("Cash amounts cannot be negative.")
        return value

    def _hold_users(self, user_ids: tuple[int, ...]) -> AsyncContextManager[None]:
        """Return an ordered multi-user lock context using this service's registry."""
        return self._hold_users_with_registry(self.locks, user_ids)

    @staticmethod
    @asynccontextmanager
    async def _hold_users_with_registry(
        registry: UserLockRegistry,
        user_ids: tuple[int, ...],
    ) -> AsyncIterator[None]:
        """Acquire multiple shared locks in ascending Discord ID order."""
        async with AsyncExitStack() as stack:
            for user_id in sorted(set(user_ids)):
                await stack.enter_async_context(registry.hold(user_id))
            yield
