"""Parameterized SQL repository for annual economy, credit, loans, and collections."""
from __future__ import annotations

import json
from typing import Any, Optional

import aiosqlite

from ..models import Character


class EconomyRepository:
    """Own all economy SQL; mutating workflows provide one open write transaction."""

    def __init__(self, db: Any) -> None:
        self.db = db

    @staticmethod
    async def _one(tx: aiosqlite.Connection, sql: str, params: tuple[Any, ...] = ()) -> Any:
        """Fetch one row from a caller-owned transaction."""
        cursor = await tx.execute(sql, params)
        return await cursor.fetchone()

    @staticmethod
    async def _all(tx: aiosqlite.Connection, sql: str, params: tuple[Any, ...] = ()) -> list[Any]:
        """Fetch all rows from a caller-owned transaction."""
        cursor = await tx.execute(sql, params)
        return await cursor.fetchall()

    async def active_character(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Load the active life snapshot and authoritative optimistic version."""
        row = await self._one(
            tx,
            "SELECT char_id, user_id, data_json, version FROM characters "
            "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def has_any_life(self, tx: aiosqlite.Connection, user_id: int) -> bool:
        """Distinguish a completed life from a player who has not started one."""
        return await self._one(tx, "SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,)) is not None

    async def save_character(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
    ) -> None:
        """Save the JSON/stat snapshot; database triggers enforce nonnegative balances."""
        from ..errors import ConcurrentUpdate

        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET stats_json = ?, data_json = ?, version = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (stats_json, data_json, character.version, character.char_id, expected_version),
        )
        if cursor.rowcount != 1:
            raise ConcurrentUpdate()

    async def annual_income(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Read gross salary for loan eligibility, returning zero without an active job."""
        row = await self._one(tx, "SELECT salary FROM jobs WHERE char_id = ? LIMIT 1", (char_id,))
        return max(0, int(row["salary"])) if row is not None else 0

    async def loan_rows(self, tx: aiosqlite.Connection, char_id: int, *, active_only: bool = False) -> list[dict[str, Any]]:
        """Load a character's loans in deterministic origination order."""
        query = "SELECT * FROM loans WHERE char_id = ?"
        if active_only:
            query += " AND status = 'active'"
        rows = await self._all(tx, query + " ORDER BY loan_id", (char_id,))
        return [dict(row) for row in rows]

    async def loan_row(self, tx: aiosqlite.Connection, loan_id: int, char_id: int) -> Optional[dict[str, Any]]:
        """Load one loan only when it belongs to the supplied character."""
        row = await self._one(tx, "SELECT * FROM loans WHERE loan_id = ? AND char_id = ?", (loan_id, char_id))
        return dict(row) if row is not None else None

    async def bankruptcy_debt_facts(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Optional[int]]:
        """Sum debt that the filing can discharge and find the first loan's in-game age."""
        loans = await self._one(
            tx,
            """SELECT COALESCE(SUM(
                       CASE WHEN loan_type IN (?, ?, ?) AND status IN (?, ?)
                            THEN balance ELSE 0 END
                   ), 0) AS dischargeable_loan_cents,
                   MIN(origination_age) AS first_loan_age
               FROM loans WHERE char_id = ?""",
            ("personal", "payday", "loan_shark", "active", "defaulted", char_id),
        )
        collections = await self._one(
            tx,
            """SELECT COALESCE(SUM(balance_cents), 0) AS standalone_collection_cents
               FROM economy_collections
               WHERE char_id = ? AND status = ? AND loan_id IS NULL""",
            (char_id, "open"),
        )
        return {
            "dischargeable_loan_cents": max(0, int(loans["dischargeable_loan_cents"])),
            "standalone_collection_cents": max(0, int(collections["standalone_collection_cents"])),
            "first_loan_age": int(loans["first_loan_age"]) if loans["first_loan_age"] is not None else None,
        }

    async def bankruptcy_debt_breakdown(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
    ) -> dict[str, dict[str, int]]:
        """Break down live loan balances and open collections without double-counting mirrors."""
        loan_rows = await self._all(
            tx,
            """SELECT loan_type, COALESCE(SUM(balance), 0) AS balance_cents
               FROM loans WHERE char_id = ? AND status IN (?, ?)
               GROUP BY loan_type ORDER BY loan_type""",
            (char_id, "active", "defaulted"),
        )
        standalone_rows = await self._all(
            tx,
            """SELECT source, COALESCE(SUM(balance_cents), 0) AS balance_cents
               FROM economy_collections
               WHERE char_id = ? AND status = ? AND loan_id IS NULL
               GROUP BY source ORDER BY source""",
            (char_id, "open"),
        )
        linked_rows = await self._all(
            tx,
            """SELECT source, COALESCE(SUM(balance_cents), 0) AS balance_cents
               FROM economy_collections
               WHERE char_id = ? AND status = ? AND loan_id IS NOT NULL
               GROUP BY source ORDER BY source""",
            (char_id, "open"),
        )
        return {
            "live_loan_balances_cents_by_type": {
                str(row["loan_type"]): max(0, int(row["balance_cents"]))
                for row in loan_rows
            },
            "standalone_open_collections_cents_by_source": {
                str(row["source"]): max(0, int(row["balance_cents"]))
                for row in standalone_rows
            },
            "linked_open_collection_mirrors_cents_by_source": {
                str(row["source"]): max(0, int(row["balance_cents"]))
                for row in linked_rows
            },
        }

    async def has_delinquent_loan(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Return whether underwriting is blocked by an existing default or three missed payments."""
        return await self._one(
            tx,
            """SELECT 1 FROM loans WHERE char_id = ?
               AND (status = 'defaulted' OR (status = 'active' AND consecutive_misses >= 3)) LIMIT 1""",
            (char_id,),
        ) is not None

    async def create_loan(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        loan_type: str,
        principal: int,
        annual_rate: float,
        term_years: int,
        annual_payment: int,
        age: int,
        collateral_item_uid: Optional[int] = None,
        grace_until_age: int = 0,
    ) -> int:
        """Insert a new fixed-rate loan and return its generated identifier."""
        cursor = await tx.execute(
            """INSERT INTO loans
                   (char_id, loan_type, balance, annual_payment, missed_payments, status,
                    principal, annual_rate, term_years, years_remaining, collateral_item_uid,
                    origination_age, consecutive_misses, grace_until_age)
               VALUES (?, ?, ?, ?, 0, 'active', ?, ?, ?, ?, ?, ?, 0, ?)""",
            (char_id, loan_type, principal, annual_payment, principal, annual_rate, term_years,
             term_years, collateral_item_uid, age, grace_until_age),
        )
        return int(cursor.lastrowid)

    async def add_loan_interest(self, tx: aiosqlite.Connection, loan_id: int, interest: int) -> None:
        """Capitalize one year of rounded-up interest on a live loan."""
        await tx.execute(
            """UPDATE loans SET balance = balance + ?, interest_paid_cents = interest_paid_cents + ?
               WHERE loan_id = ? AND status = 'active'""",
            (interest, interest, loan_id),
        )

    async def pay_loan(
        self,
        tx: aiosqlite.Connection,
        *,
        loan_id: int,
        payment: int,
        age: int,
        count_year: bool = True,
    ) -> int:
        """Apply a payment to one active loan and return its remaining balance."""
        row = await self._one(
            tx, "SELECT balance, years_remaining FROM loans WHERE loan_id = ? AND status = 'active'", (loan_id,)
        )
        if row is None:
            return 0
        balance = max(0, int(row["balance"]) - max(0, int(payment)))
        years = max(0, int(row["years_remaining"]) - int(count_year))
        await tx.execute(
            """UPDATE loans SET balance = ?, status = ?, years_remaining = ?,
                   missed_payments = 0, consecutive_misses = 0, last_payment_age = ?
               WHERE loan_id = ? AND status = 'active'""",
            (balance, "paid" if balance == 0 else "active", years, age, loan_id),
        )
        return balance

    async def miss_loan_payment(self, tx: aiosqlite.Connection, loan_id: int) -> int:
        """Record a missed payment and return the resulting consecutive miss count."""
        await tx.execute(
            """UPDATE loans SET missed_payments = missed_payments + 1,
                   consecutive_misses = consecutive_misses + 1
               WHERE loan_id = ? AND status = 'active'""",
            (loan_id,),
        )
        row = await self._one(tx, "SELECT consecutive_misses FROM loans WHERE loan_id = ?", (loan_id,))
        return int(row["consecutive_misses"]) if row is not None else 0

    async def mark_loan_defaulted(self, tx: aiosqlite.Connection, loan_id: int, age: int) -> None:
        """Freeze a delinquent account as defaulted before collateral recovery."""
        await tx.execute(
            """UPDATE loans SET status = 'defaulted', defaulted_at_age = ?
               WHERE loan_id = ? AND status = 'active'""",
            (age, loan_id),
        )

    async def set_defaulted_balance(self, tx: aiosqlite.Connection, loan_id: int, balance: int) -> None:
        """Apply repossessed collateral proceeds to a defaulted loan balance."""
        await tx.execute(
            "UPDATE loans SET balance = ? WHERE loan_id = ? AND status = 'defaulted'",
            (max(0, int(balance)), loan_id),
        )

    async def collateral_asset(self, tx: aiosqlite.Connection, asset_id: int) -> Optional[dict[str, Any]]:
        """Return one current, unliquidated pledged item."""
        row = await self._one(
            tx,
            """SELECT asset_id, char_id, item_id, quantity, current_value, is_liquidated
               FROM family_assets WHERE asset_id = ? AND kind = 'item'""",
            (asset_id,),
        )
        return dict(row) if row is not None else None

    async def repossess_asset(self, tx: aiosqlite.Connection, asset_id: int) -> Optional[dict[str, Any]]:
        """Mark pledged property liquidated and return its pre-repossession value."""
        row = await self.collateral_asset(tx, asset_id)
        if row is None or bool(row["is_liquidated"]):
            return None
        await tx.execute(
            """UPDATE family_assets SET quantity = 0, current_value = 0, is_liquidated = 1
               WHERE asset_id = ? AND is_liquidated = 0""",
            (asset_id,),
        )
        return row

    async def add_collection(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        source: str,
        balance: int,
        age: int,
        now: int,
        loan_id: Optional[int] = None,
    ) -> int:
        """Open an itemized collection record for a bill or deficiency."""
        if balance <= 0:
            return 0
        cursor = await tx.execute(
            """INSERT INTO economy_collections
                   (char_id, source, loan_id, balance_cents, created_age, status, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, 'open', ?, ?)""",
            (char_id, source, loan_id, balance, age, now, now),
        )
        return int(cursor.lastrowid)

    async def collection_rows(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Read open and historical collection records for account status."""
        rows = await self._all(
            tx,
            "SELECT * FROM economy_collections WHERE char_id = ? ORDER BY collection_id DESC LIMIT 50",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def pay_collection(self, tx: aiosqlite.Connection, collection_id: int, amount: int, now: int) -> int:
        """Apply payment to one open collection and return the remaining amount."""
        row = await self._one(
            tx,
            "SELECT balance_cents, loan_id FROM economy_collections WHERE collection_id = ? AND status = 'open'",
            (collection_id,),
        )
        if row is None:
            return 0
        remaining = max(0, int(row["balance_cents"]) - max(0, int(amount)))
        await tx.execute(
            """UPDATE economy_collections SET balance_cents = ?,
                   status = ?, updated_at = ?
               WHERE collection_id = ? AND status = 'open'""",
            (remaining, "paid" if remaining == 0 else "open", now, collection_id),
        )
        loan_id = row["loan_id"]
        if loan_id is not None:
            await tx.execute(
                """UPDATE loans SET balance = MAX(0, balance - ?)
                   WHERE loan_id = ? AND status = 'defaulted'""",
                (max(0, int(amount)), int(loan_id)),
            )
        return remaining

    async def is_year_settled(self, tx: aiosqlite.Connection, char_id: int, age: int) -> bool:
        """Return whether the economy component has already settled this life-year."""
        return await self._one(tx, "SELECT 1 FROM economy_years WHERE char_id = ? AND age = ?", (char_id, age)) is not None

    async def save_year_settlement(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        age: int,
        income_tax: int,
        living_cost: int,
        rent: int,
        interest: int,
        theft: int,
        stock_liquidation: int,
        now: int,
    ) -> None:
        """Persist one idempotent annual economy settlement."""
        await tx.execute(
            """INSERT INTO economy_years
                   (char_id, age, income_tax_cents, living_cost_cents, rent_cents,
                    interest_cents, theft_cents, stock_liquidation_cents, settled_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, age, income_tax, living_cost, rent, interest, theft, stock_liquidation, now),
        )

    async def activity_used(self, tx: aiosqlite.Connection, char_id: int, age: int, activity: str) -> bool:
        """Check the unique per-character annual activity marker."""
        return await self._one(
            tx,
            "SELECT 1 FROM economy_activity_uses WHERE char_id = ? AND age = ? AND activity_id = ?",
            (char_id, age, activity),
        ) is not None

    async def record_activity(self, tx: aiosqlite.Connection, char_id: int, age: int, activity: str, now: int) -> None:
        """Mark one activity as used for this in-game year."""
        await tx.execute(
            "INSERT INTO economy_activity_uses(char_id, age, activity_id, used_at) VALUES (?, ?, ?, ?)",
            (char_id, age, activity, now),
        )

    async def stock_holdings_low_to_high(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Read tradable holdings ordered by lowest current share price first."""
        rows = await self._all(
            tx,
            """SELECT h.char_id, h.symbol, h.shares, h.cost_basis_cents, m.price_cents
               FROM stock_holdings AS h JOIN stock_market AS m ON m.symbol = h.symbol
               WHERE h.char_id = ? AND m.is_delisted = 0 AND m.price_cents > 0
               ORDER BY m.price_cents ASC, h.symbol ASC""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def update_holding_after_liquidation(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        symbol: str,
        old_shares: int,
        old_basis: int,
        sold_shares: int,
        now: int,
    ) -> int:
        """Persist a partial/full forced share sale and return fee-inclusive basis removed."""
        basis_sold = old_basis if sold_shares >= old_shares else old_basis * sold_shares // old_shares
        remain_shares = old_shares - sold_shares
        remain_basis = old_basis - basis_sold
        if remain_shares:
            await tx.execute(
                """UPDATE stock_holdings SET shares = ?, cost_basis_cents = ?, updated_at = ?
                   WHERE char_id = ? AND symbol = ?""",
                (remain_shares, remain_basis, now, char_id, symbol),
            )
        else:
            await tx.execute("DELETE FROM stock_holdings WHERE char_id = ? AND symbol = ?", (char_id, symbol))
        return basis_sold

    async def record_forced_stock_sale(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        symbol: str,
        shares: int,
        price: int,
        gross: int,
        fee: int,
        realized_gain: int,
        age: int,
        now: int,
    ) -> None:
        """Record an automatic liquidation in normal investment and audit ledgers."""
        await tx.execute(
            """INSERT INTO investment_trades
                   (char_id, symbol, side, shares, price_cents, gross_cents, fee_cents,
                    realized_gain_cents, age, created_at)
               VALUES (?, ?, 'sell', ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, symbol, shares, price, gross, fee, realized_gain, age, now),
        )
        await tx.execute(
            """INSERT INTO audit_log(ts, user_id, char_id, action, amount, details_json)
               SELECT ?, user_id, ?, 'forced_stock_liquidation', ?, ?
                 FROM characters WHERE char_id = ?""",
            (now, char_id, gross, json.dumps({"symbol": symbol, "shares": shares, "fee_cents": fee}, separators=(",", ":")), char_id),
        )

    async def write_audit(
        self,
        tx: aiosqlite.Connection,
        *,
        now: int,
        user_id: int,
        char_id: int,
        action: str,
        amount: Optional[int],
        details: dict[str, Any],
    ) -> None:
        """Append one parameterized money/credit audit record."""
        await tx.execute(
            """INSERT INTO audit_log(ts, user_id, char_id, action, amount, details_json)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (now, user_id, char_id, action, amount,
             json.dumps(details, ensure_ascii=False, separators=(",", ":"), allow_nan=False)),
        )

    async def insert_bankruptcy(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        age: int,
        debt_before: int,
        assets_before: int,
        discharged: int,
        now: int,
    ) -> int:
        """Persist one non-repeatable bankruptcy filing for this life-year."""
        cursor = await tx.execute(
            """INSERT INTO bankruptcies
                   (char_id, age, debt_before_cents, assets_before_cents, discharged_cents, filed_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (char_id, age, debt_before, assets_before, discharged, now),
        )
        return int(cursor.lastrowid)

    async def bankruptcy_rows(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Read a character's non-editable bankruptcy history."""
        rows = await self._all(tx, "SELECT * FROM bankruptcies WHERE char_id = ? ORDER BY age", (char_id,))
        return [dict(row) for row in rows]

    async def discharge_loan(self, tx: aiosqlite.Connection, loan_id: int) -> int:
        """Close one eligible unsecured loan and return its remaining balance."""
        row = await self._one(tx, "SELECT balance FROM loans WHERE loan_id = ? AND status IN ('active', 'defaulted')", (loan_id,))
        if row is None:
            return 0
        balance = max(0, int(row["balance"]))
        await tx.execute(
            "UPDATE loans SET balance = 0, status = 'discharged', years_remaining = 0 WHERE loan_id = ? AND status IN ('active', 'defaulted')",
            (loan_id,),
        )
        return balance

    async def discharge_open_collections(self, tx: aiosqlite.Connection, char_id: int, now: int) -> int:
        """Mark all open unsecured collections discharged and return their total."""
        row = await self._one(
            tx,
            "SELECT COALESCE(SUM(balance_cents), 0) AS total FROM economy_collections WHERE char_id = ? AND status = 'open' AND loan_id IS NULL",
            (char_id,),
        )
        total = max(0, int(row["total"])) if row is not None else 0
        await tx.execute(
            """UPDATE economy_collections SET status = 'discharged', updated_at = ?
               WHERE char_id = ? AND status = 'open' AND loan_id IS NULL""",
            (now, char_id),
        )
        return total

    async def discharge_collections_for_loan(self, tx: aiosqlite.Connection, loan_id: int, now: int) -> None:
        """Close default-collection mirrors when their linked unsecured loan is discharged."""
        await tx.execute(
            """UPDATE economy_collections SET status = 'discharged', updated_at = ?
               WHERE loan_id = ? AND status = 'open'""",
            (now, loan_id),
        )

    async def open_collections_total(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Return outstanding collection principal."""
        row = await self._one(
            tx,
            "SELECT COALESCE(SUM(balance_cents), 0) AS total FROM economy_collections WHERE char_id = ? AND status = 'open'",
            (char_id,),
        )
        return max(0, int(row["total"])) if row is not None else 0
