"""Parameterized repository for the Stage 9 global market and player investments."""
from __future__ import annotations

from typing import Any, Optional, Sequence

import aiosqlite

from ..models import Character


class InvestingRepository:
    """All stock, bond, yearly-income, and investment-trade SQL."""

    def __init__(self, db: Any) -> None:
        self.db = db

    @staticmethod
    async def _one(tx: aiosqlite.Connection, sql: str, params: tuple[Any, ...] = ()) -> Any:
        cursor = await tx.execute(sql, params)
        return await cursor.fetchone()

    @staticmethod
    async def _all(tx: aiosqlite.Connection, sql: str, params: tuple[Any, ...] = ()) -> list[Any]:
        cursor = await tx.execute(sql, params)
        return await cursor.fetchall()

    async def ensure_market(self, tx: aiosqlite.Connection, stocks: Sequence[dict[str, Any]], now: int) -> None:
        """Seed missing listed companies and the singleton tick cursor exactly once."""
        await tx.execute(
            "INSERT OR IGNORE INTO market_state(singleton_id, last_tick_at, tick_no) VALUES (1, ?, 0)",
            (now,),
        )
        for stock in stocks:
            await tx.execute(
                """INSERT OR IGNORE INTO stock_market
                       (symbol, company_name, sector, price_cents, drift, volatility, is_delisted, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, 0, ?)""",
                (stock["symbol"], stock["name"], stock["sector"], int(stock["initial_price_cents"]),
                 float(stock["drift"]), float(stock["volatility"]), now),
            )
            await tx.execute(
                """INSERT OR IGNORE INTO stock_history(symbol, tick_no, recorded_at, price_cents, event_type)
                   SELECT symbol, 0, updated_at, price_cents, 'none' FROM stock_market WHERE symbol = ?""",
                (stock["symbol"],),
            )

    async def market_state(self, tx: aiosqlite.Connection) -> Optional[dict[str, Any]]:
        """Load the single global tick cursor and current daily event marker."""
        row = await self._one(tx, "SELECT * FROM market_state WHERE singleton_id = 1")
        return dict(row) if row is not None else None

    async def save_market_state(
        self, tx: aiosqlite.Connection, *, last_tick_at: int, tick_no: int,
        event_day: Optional[str], event_type: str,
    ) -> None:
        """Commit the tick cursor only after all price/history writes succeed."""
        await tx.execute(
            """UPDATE market_state SET last_tick_at = ?, tick_no = ?, event_day = ?, event_type = ?
               WHERE singleton_id = 1""",
            (last_tick_at, tick_no, event_day, event_type),
        )

    async def list_stocks(self, tx: aiosqlite.Connection, include_delisted: bool = False) -> list[dict[str, Any]]:
        """Return catalog companies and their latest persisted prices."""
        where = "" if include_delisted else "WHERE is_delisted = 0"
        rows = await self._all(tx, f"SELECT * FROM stock_market {where} ORDER BY symbol")
        return [dict(row) for row in rows]

    async def stock(self, tx: aiosqlite.Connection, symbol: str) -> Optional[dict[str, Any]]:
        """Load a single ticker by normalized symbol."""
        row = await self._one(tx, "SELECT * FROM stock_market WHERE symbol = ? LIMIT 1", (symbol,))
        return dict(row) if row is not None else None

    async def update_stock(
        self, tx: aiosqlite.Connection, *, symbol: str, price_cents: int,
        updated_at: int, delisted: bool, delisted_at: Optional[int],
    ) -> None:
        """Persist one atomic GBM/event movement or permanent bankruptcy."""
        await tx.execute(
            """UPDATE stock_market SET price_cents = ?, updated_at = ?, is_delisted = ?, delisted_at = ?
               WHERE symbol = ?""",
            (price_cents, updated_at, int(delisted), delisted_at, symbol),
        )

    async def insert_history(
        self, tx: aiosqlite.Connection, *, symbol: str, tick_no: int,
        recorded_at: int, price_cents: int, event_type: str,
    ) -> None:
        """Append one symbol/tick point; unique keys make duplicate tick writes harmless."""
        await tx.execute(
            """INSERT OR IGNORE INTO stock_history(symbol, tick_no, recorded_at, price_cents, event_type)
               VALUES (?, ?, ?, ?, ?)""",
            (symbol, tick_no, recorded_at, price_cents, event_type),
        )

    async def trim_history(self, tx: aiosqlite.Connection, symbol: str, keep: int = 500) -> None:
        """Retain only the newest five hundred tick rows for a symbol."""
        await tx.execute(
            """DELETE FROM stock_history WHERE symbol = ? AND history_id NOT IN
                   (SELECT history_id FROM stock_history WHERE symbol = ? ORDER BY tick_no DESC LIMIT ?)""",
            (symbol, symbol, keep),
        )

    async def history(
        self, tx: aiosqlite.Connection, symbol: str, *, limit: int = 100,
        since: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """Read chronologically ordered history with a bounded result size."""
        if since is None:
            rows = await self._all(
                tx,
                "SELECT * FROM (SELECT * FROM stock_history WHERE symbol = ? ORDER BY tick_no DESC LIMIT ?) ORDER BY tick_no ASC",
                (symbol, limit),
            )
        else:
            rows = await self._all(
                tx,
                "SELECT * FROM stock_history WHERE symbol = ? AND recorded_at >= ? ORDER BY tick_no ASC LIMIT ?",
                (symbol, since, limit),
            )
        return [dict(row) for row in rows]

    async def character_row(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Load active-life payload and current optimistic version."""
        row = await self._one(
            tx,
            "SELECT char_id, user_id, data_json, version FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def has_life(self, tx: aiosqlite.Connection, user_id: int) -> bool:
        """Distinguish a dead historical character from a new user."""
        return await self._one(tx, "SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,)) is not None

    async def save_character(self, tx: aiosqlite.Connection, character: Character, expected_version: int) -> None:
        """Persist an investment balance mutation with compare-and-swap versioning."""
        import json
        from ..errors import ConcurrentUpdate

        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET stats_json = ?, data_json = ?, version = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (stats_json, data_json, character.version, character.char_id, expected_version),
        )
        if cursor.rowcount != 1:
            raise ConcurrentUpdate()

    async def trade_count_since(self, tx: aiosqlite.Connection, user_id: int, since: int) -> int:
        """Count stock buy/sell orders across every life owned by this Discord user."""
        row = await self._one(
            tx,
            """SELECT COUNT(*) AS count FROM investment_trades
               WHERE created_at > ? AND char_id IN (SELECT char_id FROM characters WHERE user_id = ?)""",
            (since, user_id),
        )
        return int(row["count"])

    async def last_opposite_trade(
        self, tx: aiosqlite.Connection, user_id: int, symbol: str, side: str
    ) -> Optional[int]:
        """Find the latest opposite-side same-symbol trade across the player's lives."""
        row = await self._one(
            tx,
            """SELECT MAX(created_at) AS ts FROM investment_trades
               WHERE symbol = ? AND side != ?
                 AND char_id IN (SELECT char_id FROM characters WHERE user_id = ?)""",
            (symbol, side, user_id),
        )
        return int(row["ts"]) if row is not None and row["ts"] is not None else None

    async def holding(self, tx: aiosqlite.Connection, char_id: int, symbol: str) -> Optional[dict[str, Any]]:
        """Load one aggregate whole-share position and its total fee-inclusive cost basis."""
        row = await self._one(tx, "SELECT * FROM stock_holdings WHERE char_id = ? AND symbol = ? LIMIT 1", (char_id, symbol))
        return dict(row) if row is not None else None

    async def holdings(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Load all positions, including holdings whose issuer has been delisted."""
        rows = await self._all(
            tx,
            """SELECT h.*, m.company_name, m.price_cents, m.is_delisted
               FROM stock_holdings AS h LEFT JOIN stock_market AS m ON m.symbol = h.symbol
               WHERE h.char_id = ? ORDER BY h.symbol""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def save_holding(
        self, tx: aiosqlite.Connection, *, char_id: int, symbol: str,
        shares: int, cost_basis_cents: int, updated_at: int,
    ) -> None:
        """Insert/update an aggregate holding after a fee-inclusive buy or partial sale."""
        await tx.execute(
            """INSERT INTO stock_holdings(char_id, symbol, shares, cost_basis_cents, updated_at)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(char_id, symbol) DO UPDATE SET
                   shares = excluded.shares, cost_basis_cents = excluded.cost_basis_cents,
                   updated_at = excluded.updated_at""",
            (char_id, symbol, shares, cost_basis_cents, updated_at),
        )

    async def delete_holding(self, tx: aiosqlite.Connection, char_id: int, symbol: str) -> None:
        """Remove an empty position after its final share is sold."""
        await tx.execute("DELETE FROM stock_holdings WHERE char_id = ? AND symbol = ?", (char_id, symbol))

    async def insert_trade(
        self, tx: aiosqlite.Connection, *, char_id: int, symbol: str, side: str,
        shares: int, price_cents: int, gross_cents: int, fee_cents: int,
        realized_gain_cents: int, age: int, created_at: int,
    ) -> int:
        """Append immutable buy/sell execution details and realized gain/loss."""
        cursor = await tx.execute(
            """INSERT INTO investment_trades
                   (char_id, symbol, side, shares, price_cents, gross_cents, fee_cents,
                    realized_gain_cents, age, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, symbol, side, shares, price_cents, gross_cents, fee_cents,
             realized_gain_cents, age, created_at),
        )
        return int(cursor.lastrowid)

    async def trade_history(self, tx: aiosqlite.Connection, char_id: int, symbol: Optional[str] = None, limit: int = 30) -> list[dict[str, Any]]:
        """Return recent transaction receipts for portfolio/history display."""
        if symbol is None:
            rows = await self._all(
                tx,
                "SELECT * FROM investment_trades WHERE char_id = ? ORDER BY created_at DESC, investment_trade_id DESC LIMIT ?",
                (char_id, limit),
            )
        else:
            rows = await self._all(
                tx,
                "SELECT * FROM investment_trades WHERE char_id = ? AND symbol = ? ORDER BY created_at DESC, investment_trade_id DESC LIMIT ?",
                (char_id, symbol, limit),
            )
        return [dict(row) for row in rows]

    async def realized_gain_for_age(self, tx: aiosqlite.Connection, char_id: int, age: int) -> int:
        """Sum realized gains/losses on stock sales in the just-ended life year."""
        row = await self._one(
            tx,
            "SELECT COALESCE(SUM(realized_gain_cents), 0) AS gain FROM investment_trades WHERE char_id = ? AND age = ? AND side = 'sell'",
            (char_id, age),
        )
        return int(row["gain"])

    async def bonds(self, tx: aiosqlite.Connection, char_id: int, locked_only: bool = False) -> list[dict[str, Any]]:
        """Load a player's savings-bond ledger."""
        condition = " AND status = 'locked'" if locked_only else ""
        rows = await self._all(
            tx,
            f"SELECT * FROM savings_bonds WHERE char_id = ?{condition} ORDER BY bond_id",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def insert_bond(
        self, tx: aiosqlite.Connection, *, char_id: int, principal: int,
        purchased_age: int, maturity_age: int, now: int,
    ) -> int:
        """Open a new five-year locked fixed-rate savings bond."""
        cursor = await tx.execute(
            """INSERT INTO savings_bonds
                   (char_id, principal_cents, balance_cents, purchased_age, maturity_age,
                    status, last_accrued_age, created_at)
               VALUES (?, ?, ?, ?, ?, 'locked', ?, ?)""",
            (char_id, principal, principal, purchased_age, maturity_age, purchased_age, now),
        )
        return int(cursor.lastrowid)

    async def update_bond(
        self, tx: aiosqlite.Connection, *, bond_id: int, balance: int,
        last_accrued_age: int, status: str, matured_at: Optional[int],
    ) -> None:
        """Accrue interest or mature a bond, guarded by its current locked state."""
        await tx.execute(
            """UPDATE savings_bonds SET balance_cents = ?, last_accrued_age = ?, status = ?, matured_at = ?
               WHERE bond_id = ? AND status = 'locked'""",
            (balance, last_accrued_age, status, matured_at, bond_id),
        )

    async def housing_assets(
        self, tx: aiosqlite.Connection, char_id: int, item_ids: Sequence[str]
    ) -> list[dict[str, Any]]:
        """Load owned, non-liquidated housing-item lots for rental-income calculation."""
        if not item_ids:
            return []
        placeholders = ",".join("?" for _ in item_ids)
        rows = await self._all(
            tx,
            f"""SELECT asset_id, item_id, quantity, purchase_price, current_value, acquired_age
                FROM family_assets WHERE char_id = ? AND kind = 'item' AND item_id IN ({placeholders})
                  AND quantity > 0 AND is_liquidated = 0 ORDER BY asset_id""",
            (char_id, *item_ids),
        )
        return [dict(row) for row in rows]

    async def yearly_income(self, tx: aiosqlite.Connection, char_id: int, age: int) -> Optional[dict[str, Any]]:
        """Load idempotency marker and recorded passive income for one life year."""
        row = await self._one(
            tx, "SELECT * FROM investment_yearly_income WHERE char_id = ? AND age = ? LIMIT 1", (char_id, age)
        )
        return dict(row) if row is not None else None

    async def save_yearly_income(
        self, tx: aiosqlite.Connection, *, char_id: int, age: int,
        rental_income: int, bond_interest: int,
    ) -> None:
        """Persist yearly passive income once per age for idempotent age-tick tests."""
        await tx.execute(
            """INSERT INTO investment_yearly_income(char_id, age, rental_income_cents, bond_interest_cents)
               VALUES (?, ?, ?, ?)
               ON CONFLICT(char_id, age) DO NOTHING""",
            (char_id, age, rental_income, bond_interest),
        )
