"""Parameterized admin persistence for bans, target lookups, and audit history."""
from __future__ import annotations

import json
from typing import Any, Optional

import aiosqlite

from ..models import Character


class AdminRepository:
    """Keep all owner-action and ban SQL inside a repository."""

    def __init__(self, db: Any) -> None:
        self.db = db

    @staticmethod
    async def _one(tx: aiosqlite.Connection, sql: str, params: tuple[Any, ...] = ()) -> Any:
        cursor = await tx.execute(sql, params)
        return await cursor.fetchone()

    async def is_banned(self, user_id: int) -> bool:
        """Return whether the account is currently banned from game commands."""
        row = await self.db.fetchone(
            "SELECT 1 FROM player_bans WHERE user_id = ? LIMIT 1",
            (int(user_id),),
        )
        return row is not None

    async def active_character(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Load an active character and version for a transactional admin action."""
        row = await self._one(
            tx,
            "SELECT * FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (int(user_id),),
        )
        return dict(row) if row is not None else None

    async def latest_character(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Load the user's most recent character without exposing it to command callers."""
        row = await self._one(
            tx,
            "SELECT * FROM characters WHERE user_id = ? ORDER BY char_id DESC LIMIT 1",
            (int(user_id),),
        )
        return dict(row) if row is not None else None

    async def save_character(self, tx: aiosqlite.Connection, character: Character, expected_version: int) -> None:
        """Persist an admin character mutation with an optimistic version check."""
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        hidden_json = json.dumps({
            "genetic_health_mod": character.hidden.genetic_health_mod,
            "lifespan_mod": character.hidden.lifespan_mod,
            "luck": character.hidden.luck,
            "temperament": character.hidden.temperament,
        }, separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET is_alive = ?, name = ?, gender = ?, country = ?, wealth_class = ?, age = ?,
                   stats_json = ?, hidden_json = ?, version = ?, last_age_at = ?, died_at = ?, death_cause = ?,
                   death_age = ?, data_json = ?
               WHERE char_id = ? AND user_id = ? AND version = ? AND is_alive = 1""",
            (
                int(character.is_alive), character.name, character.gender.value, character.country,
                character.wealth_class, character.age, stats_json, hidden_json, character.version,
                character.last_age_at, character.died_at, character.death_cause, character.death_age,
                data_json, character.char_id, character.user_id, int(expected_version),
            ),
        )
        if cursor.rowcount != 1:
            from ..errors import ConcurrentUpdate
            raise ConcurrentUpdate("The target life changed before the admin action could be saved.")

    async def insert_audit(
        self,
        tx: aiosqlite.Connection,
        *,
        admin_id: int,
        target_user_id: Optional[int],
        char_id: Optional[int],
        action: str,
        amount: Optional[int],
        details: dict[str, Any],
        now: int,
    ) -> int:
        """Record an owner action using the legacy-compatible user_id plus explicit admin fields."""
        import json

        details_json = json.dumps(details, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """INSERT INTO audit_log
                   (ts, user_id, char_id, action, amount, details_json, admin_id, target_user_id)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (int(now), target_user_id, char_id, str(action), amount, details_json, int(admin_id), target_user_id),
        )
        return int(cursor.lastrowid)

    async def set_ban(
        self,
        tx: aiosqlite.Connection,
        *,
        user_id: int,
        admin_id: int,
        reason: str,
        now: int,
    ) -> None:
        """Insert or refresh an active ban row."""
        await tx.execute(
            """INSERT INTO player_bans(user_id, admin_id, reason, created_at)
               VALUES (?, ?, ?, ?)
               ON CONFLICT(user_id) DO UPDATE SET
                   admin_id = excluded.admin_id, reason = excluded.reason, created_at = excluded.created_at""",
            (int(user_id), int(admin_id), str(reason), int(now)),
        )

    async def clear_ban(self, tx: aiosqlite.Connection, user_id: int) -> bool:
        """Remove one active ban and report whether it existed."""
        cursor = await tx.execute("DELETE FROM player_bans WHERE user_id = ?", (int(user_id),))
        return cursor.rowcount == 1

    async def list_audit(
        self,
        *,
        limit: int = 25,
        target_user_id: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """Return a bounded, newest-first slice of owner audit records."""
        bounded_limit = max(1, min(100, int(limit)))
        if target_user_id is None:
            rows = await self.db.fetchall(
                """SELECT audit_id, ts, admin_id, target_user_id, char_id, action, amount, details_json
                   FROM audit_log WHERE admin_id IS NOT NULL ORDER BY ts DESC, audit_id DESC LIMIT ?""",
                (bounded_limit,),
            )
        else:
            rows = await self.db.fetchall(
                """SELECT audit_id, ts, admin_id, target_user_id, char_id, action, amount, details_json
                   FROM audit_log WHERE admin_id IS NOT NULL AND target_user_id = ?
                   ORDER BY ts DESC, audit_id DESC LIMIT ?""",
                (int(target_user_id), bounded_limit),
            )
        return [dict(row) for row in rows]
