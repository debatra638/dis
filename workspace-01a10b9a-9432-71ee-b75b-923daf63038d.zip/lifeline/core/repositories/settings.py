"""Per-player public-result settings and leaderboard visibility persistence."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import aiosqlite


@dataclass(frozen=True, slots=True)
class PlayerSettings:
    """Public-output preferences; a missing row uses the public-by-default values."""

    public_year_summaries: bool = True
    public_deaths: bool = True
    public_casino_results: bool = True
    public_leaderboards: bool = True


class SettingsRepository:
    """Persist privacy preferences without exposing raw SQL to cogs or services."""

    DEFAULTS = PlayerSettings()

    def __init__(self, db: Any) -> None:
        self.db = db

    @staticmethod
    async def _one(tx: aiosqlite.Connection, sql: str, params: tuple[Any, ...] = ()) -> Any:
        cursor = await tx.execute(sql, params)
        return await cursor.fetchone()

    async def get(self, tx: aiosqlite.Connection, user_id: int) -> PlayerSettings:
        """Return saved settings while honoring legacy leaderboard opt-outs."""
        row = await self._one(
            tx,
            """SELECT s.public_year_summaries, s.public_deaths, s.public_casino_results,
                      s.public_leaderboards, p.leaderboard_opt_out
               FROM player_settings AS s LEFT JOIN players AS p ON p.user_id = s.user_id
               WHERE s.user_id = ? LIMIT 1""",
            (int(user_id),),
        )
        if row is None:
            player = await self._one(
                tx,
                "SELECT leaderboard_opt_out FROM players WHERE user_id = ? LIMIT 1",
                (int(user_id),),
            )
            return PlayerSettings(
                public_leaderboards=not bool(player and int(player["leaderboard_opt_out"])),
            )
        public_leaderboards = bool(row["public_leaderboards"])
        if row["leaderboard_opt_out"] is not None and bool(row["leaderboard_opt_out"]):
            public_leaderboards = False
        return PlayerSettings(
            public_year_summaries=bool(row["public_year_summaries"]),
            public_deaths=bool(row["public_deaths"]),
            public_casino_results=bool(row["public_casino_results"]),
            public_leaderboards=public_leaderboards,
        )

    async def update_privacy(
        self,
        tx: aiosqlite.Connection,
        *,
        user_id: int,
        now: int,
        public_year_summaries: bool | None = None,
        public_deaths: bool | None = None,
        public_casino_results: bool | None = None,
    ) -> PlayerSettings:
        """Update only supplied privacy toggles and return the final settings."""
        await self._ensure_player(tx, user_id, now)
        before = await self.get(tx, user_id)
        next_settings = PlayerSettings(
            public_year_summaries=(before.public_year_summaries if public_year_summaries is None else bool(public_year_summaries)),
            public_deaths=(before.public_deaths if public_deaths is None else bool(public_deaths)),
            public_casino_results=(before.public_casino_results if public_casino_results is None else bool(public_casino_results)),
            public_leaderboards=before.public_leaderboards,
        )
        await tx.execute(
            """INSERT INTO player_settings
                   (user_id, public_year_summaries, public_deaths, public_casino_results, public_leaderboards, updated_at)
               VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(user_id) DO UPDATE SET
                   public_year_summaries = excluded.public_year_summaries,
                   public_deaths = excluded.public_deaths,
                   public_casino_results = excluded.public_casino_results,
                   updated_at = excluded.updated_at""",
            (
                int(user_id), int(next_settings.public_year_summaries), int(next_settings.public_deaths),
                int(next_settings.public_casino_results), int(next_settings.public_leaderboards), int(now),
            ),
        )
        return next_settings

    async def set_leaderboard(self, tx: aiosqlite.Connection, *, user_id: int, public: bool, now: int) -> PlayerSettings:
        """Set leaderboard visibility and keep the Stage 10 opt-out column synchronized."""
        await self._ensure_player(tx, user_id, now)
        await tx.execute(
            "UPDATE players SET leaderboard_opt_out = ? WHERE user_id = ?",
            (int(not public), int(user_id)),
        )
        current = await self.get(tx, user_id)
        await tx.execute(
            """INSERT INTO player_settings
                   (user_id, public_year_summaries, public_deaths, public_casino_results, public_leaderboards, updated_at)
               VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(user_id) DO UPDATE SET
                   public_leaderboards = excluded.public_leaderboards,
                   updated_at = excluded.updated_at""",
            (
                int(user_id), int(current.public_year_summaries), int(current.public_deaths),
                int(current.public_casino_results), int(public), int(now),
            ),
        )
        return PlayerSettings(
            current.public_year_summaries, current.public_deaths,
            current.public_casino_results, bool(public),
        )

    async def _ensure_player(self, tx: aiosqlite.Connection, user_id: int, now: int) -> None:
        """Create the parent row needed by privacy settings."""
        await tx.execute(
            "INSERT OR IGNORE INTO players(user_id, created_at) VALUES (?, ?)",
            (int(user_id), int(now)),
        )
