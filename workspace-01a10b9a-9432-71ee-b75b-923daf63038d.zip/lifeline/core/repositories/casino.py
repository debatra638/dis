"""Parameterized repository for casino ledgers, addiction, and blackjack sessions."""
from __future__ import annotations

import json
from typing import Any, Optional

import aiosqlite

from ..models import Character


class CasinoRepository:
    """All Stage 9 casino SQL, executed only through caller-owned transactions."""

    def __init__(self, db: Any) -> None:
        self.db = db

    @staticmethod
    async def _one(tx: aiosqlite.Connection, sql: str, params: tuple[Any, ...] = ()) -> Any:
        cursor = await tx.execute(sql, params)
        return await cursor.fetchone()

    @staticmethod
    async def _all(tx: aiosqlite.Connection, sql: str, params: tuple[Any, ...] = ()) -> list[Any]:
        cursor = await tx.execute(sql, params)
        return await cursor.fetchall()

    async def load_active(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Load an active life and its optimistic version."""
        row = await self._one(
            tx,
            "SELECT char_id, user_id, data_json, version FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def has_any_life(self, tx: aiosqlite.Connection, user_id: int) -> bool:
        """Distinguish a completed life from a user with no character."""
        return await self._one(tx, "SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,)) is not None

    async def save_character(self, tx: aiosqlite.Connection, character: Character, expected_version: int) -> None:
        """Persist character JSON and stats only when the database version is current."""
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET stats_json = ?, data_json = ?, version = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (stats_json, data_json, character.version, character.char_id, expected_version),
        )
        if cursor.rowcount != 1:
            from ..errors import ConcurrentUpdate
            raise ConcurrentUpdate()

    async def ensure_tracking(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Create the Stage 5 stats row before updating Stage 9 cumulative counters."""
        await tx.execute("INSERT OR IGNORE INTO stats_tracking(char_id) VALUES (?)", (char_id,))

    async def tracking(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Any]:
        """Load addiction remainder and cumulative gambling totals."""
        await self.ensure_tracking(tx, char_id)
        row = await self._one(tx, "SELECT * FROM stats_tracking WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row)

    async def save_tracking(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        total_gambled: Optional[int] = None,
        total_gambling_net: Optional[int] = None,
        addiction_fraction: Optional[float] = None,
    ) -> None:
        """Update only supplied stats-tracking fields with parameterized values."""
        await self.ensure_tracking(tx, char_id)
        values = {
            "total_gambled": total_gambled,
            "total_gambling_net": total_gambling_net,
            "gambling_addiction_fraction": addiction_fraction,
        }
        columns = [(name, value) for name, value in values.items() if value is not None]
        if not columns:
            return
        assignments = ", ".join(f"{name} = ?" for name, _ in columns)
        params = tuple(value for _, value in columns) + (char_id,)
        await tx.execute(f"UPDATE stats_tracking SET {assignments} WHERE char_id = ?", params)

    async def reserve_yearly_bet(self, tx: aiosqlite.Connection, char_id: int, age: int, limit: int = 25) -> int:
        """Increment casino_bet in yearly_counters, falling back for lives without NPCs."""
        npc = await self._one(
            tx, "SELECT npc_id FROM npcs WHERE owner_char_id = ? ORDER BY npc_id LIMIT 1", (char_id,)
        )
        if npc is not None:
            cursor = await tx.execute(
                """INSERT INTO yearly_counters(char_id, npc_id, age, action, count)
                   VALUES (?, ?, ?, 'casino_bet', 1)
                   ON CONFLICT(char_id, npc_id, age, action) DO UPDATE SET count = count + 1
                   WHERE count < ?""",
                (char_id, int(npc["npc_id"]), age, limit),
            )
            if cursor.rowcount != 1:
                return -1
            row = await self._one(
                tx,
                "SELECT count FROM yearly_counters WHERE char_id = ? AND npc_id = ? AND age = ? AND action = 'casino_bet'",
                (char_id, int(npc["npc_id"]), age),
            )
            return int(row["count"])
        cursor = await tx.execute(
            """INSERT INTO casino_yearly_bets(char_id, age, count) VALUES (?, ?, 1)
               ON CONFLICT(char_id, age) DO UPDATE SET count = count + 1 WHERE count < ?""",
            (char_id, age, limit),
        )
        if cursor.rowcount != 1:
            return -1
        row = await self._one(tx, "SELECT count FROM casino_yearly_bets WHERE char_id = ? AND age = ?", (char_id, age))
        return int(row["count"])

    async def casino_state(self, tx: aiosqlite.Connection, user_id: int) -> dict[str, Any]:
        """Get persisted cross-life, cross-game cooldown state, creating the row if needed."""
        await tx.execute("INSERT OR IGNORE INTO casino_player_state(user_id) VALUES (?)", (user_id,))
        row = await self._one(tx, "SELECT * FROM casino_player_state WHERE user_id = ?", (user_id,))
        return dict(row)

    async def set_last_bet(self, tx: aiosqlite.Connection, user_id: int, timestamp: int) -> None:
        """Store the most recent real-time wager timestamp by Discord owner."""
        await tx.execute(
            "INSERT INTO casino_player_state(user_id, last_bet_at) VALUES (?, ?) "
            "ON CONFLICT(user_id) DO UPDATE SET last_bet_at = excluded.last_bet_at",
            (user_id, timestamp),
        )

    async def insert_play(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        user_id: int,
        age: int,
        game: str,
        bet_cents: int,
        status: str,
        outcome: dict[str, Any],
        created_at: int,
        payout_cents: Optional[int] = None,
        net_cents: Optional[int] = None,
        session_id: Optional[int] = None,
    ) -> int:
        """Insert one immutable play or pending blackjack ledger row."""
        cursor = await tx.execute(
            """INSERT INTO casino_plays
                   (char_id, user_id, age, game, bet_cents, payout_cents, net_cents,
                    status, outcome_json, session_id, created_at, resolved_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)""",
            (char_id, user_id, age, game, bet_cents, payout_cents, net_cents, status,
             json.dumps(outcome, sort_keys=True, separators=(",", ":"), allow_nan=False), session_id, created_at),
        )
        return int(cursor.lastrowid)

    async def settle_play(
        self,
        tx: aiosqlite.Connection,
        *,
        play_id: int,
        bet_cents: int,
        payout_cents: int,
        net_cents: int,
        status: str,
        outcome: dict[str, Any],
        resolved_at: int,
    ) -> None:
        """Settle or refund a single play exactly once."""
        cursor = await tx.execute(
            """UPDATE casino_plays SET bet_cents = ?, payout_cents = ?, net_cents = ?,
                   status = ?, outcome_json = ?, resolved_at = ?
               WHERE play_id = ? AND status = 'pending'""",
            (bet_cents, payout_cents, net_cents, status,
             json.dumps(outcome, sort_keys=True, separators=(",", ":"), allow_nan=False), resolved_at, play_id),
        )
        if cursor.rowcount != 1:
            from ..errors import ConcurrentUpdate
            raise ConcurrentUpdate("That casino play was already settled.")

    async def insert_session(
        self,
        tx: aiosqlite.Connection,
        *,
        play_id: int,
        char_id: int,
        user_id: int,
        nonce: str,
        bet_cents: int,
        escrow_cash: int,
        escrow_bank: int,
        state: dict[str, Any],
        now: int,
        expires_at: int,
    ) -> int:
        """Persist a pending blackjack hand and the exact debit to refund on restart."""
        cursor = await tx.execute(
            """INSERT INTO casino_sessions
                   (play_id, char_id, user_id, nonce, bet_cents, escrow_cash, escrow_bank,
                    state_json, status, created_at, expires_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?)""",
            (play_id, char_id, user_id, nonce, bet_cents, escrow_cash, escrow_bank,
             json.dumps(state, sort_keys=True, separators=(",", ":"), allow_nan=False), now, expires_at),
        )
        return int(cursor.lastrowid)

    async def load_session(self, tx: aiosqlite.Connection, session_id: int) -> Optional[dict[str, Any]]:
        """Load one blackjack session and its matching play record."""
        row = await self._one(
            tx,
            """SELECT s.*, p.age, p.outcome_json AS play_outcome
               FROM casino_sessions AS s JOIN casino_plays AS p ON p.play_id = s.play_id
               WHERE s.session_id = ? LIMIT 1""",
            (session_id,),
        )
        return dict(row) if row is not None else None

    async def active_session(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Load the active blackjack session for one life, if any."""
        row = await self._one(tx, "SELECT * FROM casino_sessions WHERE char_id = ? AND status = 'active' LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def save_session_state(
        self,
        tx: aiosqlite.Connection,
        *,
        session_id: int,
        expected_nonce: str,
        nonce: str,
        bet_cents: int,
        escrow_cash: int,
        escrow_bank: int,
        state: dict[str, Any],
        expires_at: int,
    ) -> None:
        """Replace the hand and rotate its interaction nonce after each button press."""
        cursor = await tx.execute(
            """UPDATE casino_sessions SET nonce = ?, bet_cents = ?, escrow_cash = ?, escrow_bank = ?,
                   state_json = ?, expires_at = ?
               WHERE session_id = ? AND nonce = ? AND status = 'active'""",
            (nonce, bet_cents, escrow_cash, escrow_bank,
             json.dumps(state, sort_keys=True, separators=(",", ":"), allow_nan=False), expires_at,
             session_id, expected_nonce),
        )
        if cursor.rowcount != 1:
            from ..errors import ConcurrentUpdate
            raise ConcurrentUpdate("That blackjack button is stale or already used.")

    async def finish_session(self, tx: aiosqlite.Connection, session_id: int, nonce: str, status: str, now: int) -> bool:
        """Perform one terminal session transition guarded by status and nonce."""
        cursor = await tx.execute(
            "UPDATE casino_sessions SET status = ?, resolved_at = ? "
            "WHERE session_id = ? AND nonce = ? AND status = 'active'",
            (status, now, session_id, nonce),
        )
        return cursor.rowcount == 1

    async def active_sessions(self, tx: aiosqlite.Connection) -> list[dict[str, Any]]:
        """Load all in-progress hands for exactly-once restart refunds."""
        rows = await self._all(tx, "SELECT * FROM casino_sessions WHERE status = 'active' ORDER BY session_id")
        return [dict(row) for row in rows]

    async def has_active_session(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check if a hand must finish/refund before the life advances."""
        return await self._one(tx, "SELECT 1 FROM casino_sessions WHERE char_id = ? AND status = 'active' LIMIT 1", (char_id,)) is not None

    async def update_play_bet(self, tx: aiosqlite.Connection, play_id: int, new_bet_cents: int, outcome: dict[str, Any]) -> None:
        """Include a double-down wager in the pending play record."""
        await tx.execute(
            "UPDATE casino_plays SET bet_cents = ?, outcome_json = ? WHERE play_id = ? AND status = 'pending'",
            (new_bet_cents, json.dumps(outcome, sort_keys=True, separators=(",", ":"), allow_nan=False), play_id),
        )

    async def upsert_condition(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        disease_id: str,
        severity: int,
        age: int,
        now: int,
        active: bool,
    ) -> None:
        """Diagnose, update, or place an existing disease into remission."""
        status = "active" if active else "in_remission"
        await tx.execute(
            """INSERT INTO health_conditions
                   (char_id, disease_id, severity, diagnosed, onset_age, years_untreated,
                    status, is_active, created_at, updated_at)
               VALUES (?, ?, ?, 1, ?, 0, ?, ?, ?, ?)
               ON CONFLICT(char_id, disease_id) DO UPDATE SET
                   severity = excluded.severity, diagnosed = 1, status = excluded.status,
                   is_active = excluded.is_active, updated_at = excluded.updated_at""",
            (char_id, disease_id, severity, age, status, int(active), now, now),
        )

    async def consume_inventory_item(self, tx: aiosqlite.Connection, char_id: int, item_id: str) -> Optional[dict[str, int]]:
        """Consume one unit from the oldest live unlocked lot of a casino-use item."""
        row = await self._one(
            tx,
            """SELECT asset_id, quantity, purchase_price, current_value FROM family_assets
               WHERE char_id = ? AND kind = 'item' AND item_id = ? AND is_locked = 0
                 AND quantity > 0 AND is_liquidated = 0 ORDER BY asset_id LIMIT 1""",
            (char_id, item_id),
        )
        if row is None:
            return None
        asset_id = int(row["asset_id"])
        quantity = int(row["quantity"])
        old_cost = int(row["purchase_price"])
        old_value = int(row["current_value"])
        if quantity == 1:
            await tx.execute(
                "UPDATE family_assets SET quantity = 0, purchase_price = 0, current_value = 0, is_liquidated = 1 WHERE asset_id = ?",
                (asset_id,),
            )
        else:
            cost = old_cost // quantity
            value = old_value // quantity
            await tx.execute(
                "UPDATE family_assets SET quantity = ?, purchase_price = ?, current_value = ? WHERE asset_id = ?",
                (quantity - 1, old_cost - cost, old_value - value, asset_id),
            )
        return {"asset_id": asset_id, "quantity_remaining": quantity - 1}

    async def insert_audit(
        self,
        tx: aiosqlite.Connection,
        *,
        now: int,
        user_id: int,
        char_id: int,
        action: str,
        amount: int,
        details: dict[str, Any],
    ) -> None:
        """Record an auditable wager, refund, or addiction-treatment action."""
        await tx.execute(
            """INSERT INTO audit_log(ts, user_id, char_id, action, amount, details_json)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (now, user_id, char_id, action, amount,
             json.dumps(details, sort_keys=True, separators=(",", ":"), allow_nan=False)),
        )

    async def pending_compulsion(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return an unresolved addiction-compulsion event."""
        row = await self._one(
            tx, "SELECT * FROM casino_compulsions WHERE char_id = ? AND status = 'pending' ORDER BY compulsion_id DESC LIMIT 1",
            (char_id,),
        )
        return dict(row) if row is not None else None

    async def insert_compulsion(self, tx: aiosqlite.Connection, char_id: int, age: int, nonce: str, amount: int, now: int) -> int:
        """Persist one forced-bet choice for an addicted life and age."""
        cursor = await tx.execute(
            """INSERT INTO casino_compulsions(char_id, age, nonce, forced_bet_cents, created_at)
               VALUES (?, ?, ?, ?, ?)""",
            (char_id, age, nonce, amount, now),
        )
        return int(cursor.lastrowid)

    async def resolve_compulsion(self, tx: aiosqlite.Connection, compulsion_id: int, nonce: str, status: str, now: int, message: str) -> bool:
        """Resolve a choice exactly once using its persisted nonce."""
        cursor = await tx.execute(
            """UPDATE casino_compulsions SET status = ?, resolved_at = ?, outcome_message = ?
               WHERE compulsion_id = ? AND nonce = ? AND status = 'pending'""",
            (status, now, message, compulsion_id, nonce),
        )
        return cursor.rowcount == 1

    async def plays_net_for_age(self, tx: aiosqlite.Connection, char_id: int, age: int) -> int:
        """Sum only settled casino net returns for one in-game year."""
        row = await self._one(
            tx,
            "SELECT COALESCE(SUM(net_cents), 0) AS net FROM casino_plays WHERE char_id = ? AND age = ? AND status = 'settled'",
            (char_id, age),
        )
        return int(row["net"])

    async def insert_yearly_tax(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        age: int,
        gambling_net: int,
        gambling_tax: int,
        capital_gain: int,
        capital_tax: int,
        now: int,
    ) -> bool:
        """Insert one tax settlement per life year; return false if already settled."""
        cursor = await tx.execute(
            """INSERT OR IGNORE INTO casino_yearly_tax
                   (char_id, age, gambling_net_cents, gambling_tax_cents,
                    capital_gain_cents, capital_tax_cents, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (char_id, age, gambling_net, gambling_tax, capital_gain, capital_tax, now),
        )
        return cursor.rowcount == 1

    async def expire_compulsions(self, tx: aiosqlite.Connection, now: int) -> int:
        """Auto-resist old pending compulsion prompts during the yearly transaction."""
        cursor = await tx.execute(
            "UPDATE casino_compulsions SET status = 'expired', resolved_at = ?, outcome_message = 'The compulsion expired.' "
            "WHERE status = 'pending' AND created_at <= ?",
            (now, now - 300),
        )
        return int(cursor.rowcount)

    async def character_record(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Load raw life data, including a life that died before startup recovery."""
        row = await self._one(
            tx, "SELECT char_id, user_id, data_json, version, is_alive FROM characters WHERE char_id = ? LIMIT 1", (char_id,)
        )
        return dict(row) if row is not None else None

    async def save_character_any_life(self, tx: aiosqlite.Connection, character: Character, expected_version: int) -> None:
        """Persist a restart refund even when a corrupted/legacy session belongs to a dead life."""
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            "UPDATE characters SET stats_json = ?, data_json = ?, version = ? WHERE char_id = ? AND version = ?",
            (stats_json, data_json, character.version, character.char_id, expected_version),
        )
        if cursor.rowcount != 1:
            from ..errors import ConcurrentUpdate
            raise ConcurrentUpdate("The character changed while a pending casino bet was refunded.")

    async def load_yearly_tax(self, tx: aiosqlite.Connection, char_id: int, age: int) -> Optional[dict[str, Any]]:
        """Load the idempotent in-game-year tax settlement row."""
        row = await self._one(tx, "SELECT * FROM casino_yearly_tax WHERE char_id = ? AND age = ? LIMIT 1", (char_id, age))
        return dict(row) if row is not None else None

    async def upsert_yearly_tax(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        age: int,
        gambling_net: int,
        gambling_tax: int,
        capital_gain: int,
        capital_tax: int,
        now: int,
    ) -> None:
        """Persist both yearly tax calculations without overwriting the other service's result."""
        await tx.execute(
            """INSERT INTO casino_yearly_tax
                   (char_id, age, gambling_net_cents, gambling_tax_cents,
                    capital_gain_cents, capital_tax_cents, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(char_id, age) DO UPDATE SET
                   gambling_net_cents = excluded.gambling_net_cents,
                   gambling_tax_cents = excluded.gambling_tax_cents,
                   capital_gain_cents = excluded.capital_gain_cents,
                   capital_tax_cents = excluded.capital_tax_cents""",
            (char_id, age, gambling_net, gambling_tax, capital_gain, capital_tax, now),
        )

    async def load_compulsion(self, tx: aiosqlite.Connection, compulsion_id: int) -> Optional[dict[str, Any]]:
        """Load one compulsion prompt for owner and nonce verification."""
        row = await self._one(tx, "SELECT * FROM casino_compulsions WHERE compulsion_id = ? LIMIT 1", (compulsion_id,))
        return dict(row) if row is not None else None

    async def condition_exists(self, tx: aiosqlite.Connection, char_id: int, disease_id: str) -> bool:
        """Check whether addiction has already been diagnosed before transitioning to remission."""
        return await self._one(
            tx, "SELECT 1 FROM health_conditions WHERE char_id = ? AND disease_id = ? LIMIT 1", (char_id, disease_id)
        ) is not None
