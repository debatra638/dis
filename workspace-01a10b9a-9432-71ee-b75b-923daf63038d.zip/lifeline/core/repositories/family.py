"""Parameterized SQLite repository for Stage 6 family and relationship data."""
from __future__ import annotations

import json
from typing import Any, Optional

import aiosqlite

from ..models import Character


class FamilyRepository:
    """Own every SQL statement used by the Stage 6 family domain service."""

    def __init__(self, db: Any) -> None:
        self.db = db

    @staticmethod
    async def _tx_one(tx: aiosqlite.Connection, query: str, params: tuple[Any, ...] = ()) -> Any:
        cursor = await tx.execute(query, params)
        return await cursor.fetchone()

    @staticmethod
    async def _tx_all(tx: aiosqlite.Connection, query: str, params: tuple[Any, ...] = ()) -> list[Any]:
        cursor = await tx.execute(query, params)
        return await cursor.fetchall()

    async def load_active(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Return the active character row and version for a transactional action."""
        row = await self._tx_one(
            tx,
            "SELECT char_id, user_id, data_json, version FROM characters "
            "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def has_any_life(self, tx: aiosqlite.Connection, user_id: int) -> bool:
        """Check whether a user has a completed or active life."""
        row = await self._tx_one(tx, "SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,))
        return row is not None

    async def load_active_read(self, user_id: int) -> Optional[dict[str, Any]]:
        """Return an active character row for a read-only command."""
        row = await self.db.fetchone(
            "SELECT char_id, user_id, data_json, version FROM characters "
            "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def has_any_life_read(self, user_id: int) -> bool:
        """Check read-only character history for a user."""
        row = await self.db.fetchone("SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,))
        return row is not None

    async def has_pending_event(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check for an unresolved life choice before a new family action."""
        row = await self._tx_one(tx, "SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1", (char_id,))
        return row is not None

    async def save_character(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
    ) -> None:
        """Save character JSON and stats with optimistic-version protection."""
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET stats_json = ?, version = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (stats_json, character.version, data_json, character.char_id, expected_version),
        )
        if cursor.rowcount != 1:
            from ..errors import ConcurrentUpdate
            raise ConcurrentUpdate()

    async def create_npc(
        self,
        tx: aiosqlite.Connection,
        *,
        owner_char_id: int,
        name: str,
        gender: str,
        age: int,
        looks: int,
        smarts: int,
        health: int,
        wealth: int,
        occupation: str,
        country: str,
        annual_income: int = 0,
        prefers_smarts: bool = False,
    ) -> int:
        """Persist one generated NPC and return its key."""
        cursor = await tx.execute(
            """INSERT INTO npcs
                   (owner_char_id, name, gender, age, looks, smarts, health, wealth,
                    occupation, is_alive, death_age, country, annual_income, prefers_smarts)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NULL, ?, ?, ?)""",
            (
                owner_char_id, name, gender, age, looks, smarts, health, wealth,
                occupation, country, annual_income, int(prefers_smarts),
            ),
        )
        return int(cursor.lastrowid)

    async def create_relationship(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        npc_id: int,
        relation_type: str,
        score: int,
        since_age: int,
    ) -> None:
        """Insert or update the unique relationship between a life and an NPC."""
        await tx.execute(
            """INSERT INTO relationships(char_id, npc_id, type, score, since_age)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(char_id, npc_id) DO UPDATE SET
                   type = excluded.type, score = excluded.score, since_age = excluded.since_age""",
            (char_id, npc_id, relation_type, max(0, min(100, int(score))), since_age),
        )

    async def get_person(self, tx: aiosqlite.Connection, char_id: int, npc_id: int) -> Optional[dict[str, Any]]:
        """Return an NPC only when it belongs to the selected life."""
        row = await self._tx_one(
            tx,
            """SELECT n.*, r.type AS relationship_type, r.score AS relationship_score,
                      r.since_age AS relationship_since_age, c.custody, c.child_support
               FROM relationships AS r
               JOIN npcs AS n ON n.npc_id = r.npc_id
               LEFT JOIN children AS c ON c.npc_id = n.npc_id AND c.char_id = r.char_id
               WHERE r.char_id = ? AND n.owner_char_id = ? AND n.npc_id = ? LIMIT 1""",
            (char_id, char_id, npc_id),
        )
        return dict(row) if row is not None else None

    async def get_person_read(self, char_id: int, npc_id: int) -> Optional[dict[str, Any]]:
        """Return an owned NPC and relationship for autocomplete or UI rendering."""
        row = await self.db.fetchone(
            """SELECT n.*, r.type AS relationship_type, r.score AS relationship_score,
                      r.since_age AS relationship_since_age, c.custody, c.child_support
               FROM relationships AS r
               JOIN npcs AS n ON n.npc_id = r.npc_id
               LEFT JOIN children AS c ON c.npc_id = n.npc_id AND c.char_id = r.char_id
               WHERE r.char_id = ? AND n.owner_char_id = ? AND n.npc_id = ? LIMIT 1""",
            (char_id, char_id, npc_id),
        )
        return dict(row) if row is not None else None

    async def list_people(self, char_id: int, *, include_dead: bool = True) -> list[dict[str, Any]]:
        """List NPC relationships for one life in family-friendly display order."""
        condition = "" if include_dead else "AND n.is_alive = 1"
        rows = await self.db.fetchall(
            f"""SELECT n.*, r.type AS relationship_type, r.score AS relationship_score,
                       r.since_age AS relationship_since_age, c.custody, c.child_support
                FROM relationships AS r
                JOIN npcs AS n ON n.npc_id = r.npc_id
                LEFT JOIN children AS c ON c.npc_id = n.npc_id AND c.char_id = r.char_id
                WHERE r.char_id = ? {condition}
                ORDER BY CASE r.type WHEN 'spouse' THEN 0 WHEN 'fiance' THEN 1
                     WHEN 'partner' THEN 2 WHEN 'parent' THEN 3 WHEN 'child' THEN 4
                     WHEN 'sibling' THEN 5 WHEN 'friend' THEN 6 ELSE 7 END,
                     r.score DESC, n.name COLLATE NOCASE""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def autocomplete_people(self, char_id: int, query: str) -> list[dict[str, Any]]:
        """Find living connected NPCs for people-option autocomplete."""
        rows = await self.db.fetchall(
            """SELECT n.npc_id, n.name, n.age, r.type AS relationship_type
               FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
               WHERE r.char_id = ? AND n.is_alive = 1 AND lower(n.name) LIKE ?
               ORDER BY n.name COLLATE NOCASE LIMIT 25""",
            (char_id, f"%{query.lower()}%"),
        )
        return [dict(row) for row in rows]

    async def list_relationships_tx(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """List full relationship and NPC records inside an existing transaction."""
        rows = await self._tx_all(
            tx,
            """SELECT n.*, r.type AS relationship_type, r.score AS relationship_score,
                      r.since_age AS relationship_since_age, c.custody, c.child_support
               FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
               LEFT JOIN children AS c ON c.npc_id = n.npc_id AND c.char_id = r.char_id
               WHERE r.char_id = ? ORDER BY n.npc_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def set_relationship_score(self, tx: aiosqlite.Connection, char_id: int, npc_id: int, score: int) -> None:
        """Store a clamped relationship score."""
        await tx.execute(
            "UPDATE relationships SET score = ? WHERE char_id = ? AND npc_id = ?",
            (max(0, min(100, int(score))), char_id, npc_id),
        )

    async def add_relationship_score(self, tx: aiosqlite.Connection, char_id: int, npc_id: int, delta: int) -> None:
        """Apply and clamp a score delta in SQLite."""
        await tx.execute(
            """UPDATE relationships SET score = MIN(100, MAX(0, score + ?))
               WHERE char_id = ? AND npc_id = ?""",
            (int(delta), char_id, npc_id),
        )

    async def set_relationship_type(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        npc_id: int,
        relation_type: str,
    ) -> None:
        """Change one existing relationship's role."""
        await tx.execute(
            "UPDATE relationships SET type = ? WHERE char_id = ? AND npc_id = ?",
            (relation_type, char_id, npc_id),
        )

    async def active_romance(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Find the highest-scoring active partner, fiance, or spouse."""
        row = await self._tx_one(
            tx,
            """SELECT n.*, r.type AS relationship_type, r.score AS relationship_score,
                      r.since_age AS relationship_since_age
               FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
               WHERE r.char_id = ? AND r.type IN ('partner', 'fiance', 'spouse') AND n.is_alive = 1
               ORDER BY CASE r.type WHEN 'spouse' THEN 0 WHEN 'fiance' THEN 1 ELSE 2 END,
                        r.id DESC LIMIT 1""",
            (char_id,),
        )
        return dict(row) if row is not None else None

    async def claim_interaction(self, tx: aiosqlite.Connection, char_id: int, npc_id: int, age: int) -> bool:
        """Atomically reserve one of the three per-year interactions with an NPC."""
        row = await self._tx_one(
            tx,
            """SELECT count FROM yearly_counters
               WHERE char_id = ? AND npc_id = ? AND age = ? AND action = 'relationship_interact'""",
            (char_id, npc_id, age),
        )
        count = int(row["count"]) if row is not None else 0
        if count >= 3:
            return False
        await tx.execute(
            """INSERT INTO yearly_counters(char_id, npc_id, age, action, count)
               VALUES (?, ?, ?, 'relationship_interact', 1)
               ON CONFLICT(char_id, npc_id, age, action) DO UPDATE SET count = count + 1""",
            (char_id, npc_id, age),
        )
        return True

    async def claim_yearly_action(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        npc_id: int,
        age: int,
        action: str,
        *,
        limit: int = 1,
    ) -> bool:
        """Atomically reserve an action with a per-NPC, per-age limit."""
        row = await self._tx_one(
            tx,
            "SELECT count FROM yearly_counters WHERE char_id = ? AND npc_id = ? AND age = ? AND action = ?",
            (char_id, npc_id, age, action),
        )
        count = int(row["count"]) if row is not None else 0
        if count >= limit:
            return False
        await tx.execute(
            """INSERT INTO yearly_counters(char_id, npc_id, age, action, count)
               VALUES (?, ?, ?, ?, 1)
               ON CONFLICT(char_id, npc_id, age, action) DO UPDATE SET count = count + 1""",
            (char_id, npc_id, age, action),
        )
        return True

    async def list_live_npcs(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """List live NPCs owned by a life for the yearly NPC-ageing tick."""
        rows = await self._tx_all(
            tx,
            "SELECT * FROM npcs WHERE owner_char_id = ? AND is_alive = 1 ORDER BY npc_id",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def update_npc_year(self, tx: aiosqlite.Connection, npc_id: int, age: int, *, alive: bool) -> None:
        """Persist a single NPC's age and terminal death state."""
        await tx.execute(
            """UPDATE npcs SET age = ?, is_alive = ?, death_age = ? WHERE npc_id = ? AND is_alive = 1""",
            (age, int(alive), None if alive else age, npc_id),
        )

    async def decay_relationships(self, tx: aiosqlite.Connection, char_id: int, previous_age: int) -> None:
        """Apply annual score decay only to people with no prior-year interaction."""
        await tx.execute(
            """UPDATE relationships
               SET score = MAX(0, score - CASE
                   WHEN type IN ('parent', 'sibling', 'child') THEN 1
                   WHEN type IN ('partner', 'fiance', 'spouse') THEN 3
                   WHEN type = 'friend' THEN 2
                   ELSE 0 END)
               WHERE char_id = ? AND type IN ('parent', 'sibling', 'child', 'friend', 'partner', 'fiance', 'spouse')
                 AND NOT EXISTS (
                     SELECT 1 FROM yearly_counters AS yc
                     WHERE yc.char_id = relationships.char_id
                       AND yc.npc_id = relationships.npc_id
                       AND yc.age = ? AND yc.action = 'relationship_interact' AND yc.count > 0
                 )""",
            (char_id, previous_age),
        )

    async def count_siblings(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Count recorded sibling NPCs for inheritance division."""
        row = await self._tx_one(
            tx,
            """SELECT COUNT(*) AS count FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
               WHERE r.char_id = ? AND r.type = 'sibling' AND n.is_alive = 1""",
            (char_id,),
        )
        return int(row["count"] if row is not None else 0)

    async def parent_relations(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return parent NPC and relationship rows for grief/inheritance logic."""
        rows = await self._tx_all(
            tx,
            """SELECT n.*, r.type AS relationship_type, r.score AS relationship_score
               FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
               WHERE r.char_id = ? AND r.type = 'parent' ORDER BY n.npc_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def insert_life_log(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        age: int,
        category: str,
        text: str,
        importance: int,
        created_at: int,
    ) -> None:
        """Insert a family system log into the shared life journal."""
        await tx.execute(
            """INSERT INTO life_logs(char_id, age, category, text, importance, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (char_id, age, category, text, importance, created_at),
        )

    async def save_dating_session(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        nonce: str,
        created_at: int,
        expires_at: int,
        npc_ids: list[int],
    ) -> None:
        """Replace the previous date search and attach its three generated candidates."""
        await tx.execute(
            """DELETE FROM npcs WHERE npc_id IN (
                   SELECT d.npc_id FROM dating_candidates AS d WHERE d.char_id = ?
               ) AND NOT EXISTS (
                   SELECT 1 FROM relationships AS r WHERE r.npc_id = npcs.npc_id
               )""",
            (char_id,),
        )
        await tx.execute("DELETE FROM dating_sessions WHERE char_id = ?", (char_id,))
        await tx.execute(
            "INSERT INTO dating_sessions(char_id, nonce, created_at, expires_at) VALUES (?, ?, ?, ?)",
            (char_id, nonce, created_at, expires_at),
        )
        for npc_id in npc_ids:
            await tx.execute(
                "INSERT INTO dating_candidates(char_id, npc_id) VALUES (?, ?)",
                (char_id, npc_id),
            )

    async def get_dating_candidate(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        npc_id: int,
        nonce: str,
        now: int,
    ) -> Optional[dict[str, Any]]:
        """Return a candidate only for its live, nonce-matched owner session."""
        row = await self._tx_one(
            tx,
            """SELECT n.*, s.nonce, s.expires_at
               FROM dating_sessions AS s
               JOIN dating_candidates AS d ON d.char_id = s.char_id
               JOIN npcs AS n ON n.npc_id = d.npc_id
               WHERE s.char_id = ? AND s.nonce = ? AND s.expires_at >= ? AND n.npc_id = ?
                 AND n.owner_char_id = ? AND n.is_alive = 1 LIMIT 1""",
            (char_id, nonce, now, npc_id, char_id),
        )
        return dict(row) if row is not None else None

    async def consume_dating_session(self, tx: aiosqlite.Connection, char_id: int, nonce: str) -> None:
        """Remove all unused date candidates after one selection."""
        await tx.execute(
            """DELETE FROM npcs WHERE npc_id IN (
                   SELECT d.npc_id FROM dating_candidates AS d WHERE d.char_id = ?
               ) AND NOT EXISTS (
                   SELECT 1 FROM relationships AS r WHERE r.npc_id = npcs.npc_id
               )""",
            (char_id,),
        )
        await tx.execute("DELETE FROM dating_sessions WHERE char_id = ? AND nonce = ?", (char_id, nonce))

    async def get_marriage(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return the active marriage record."""
        row = await self._tx_one(tx, "SELECT * FROM marriages WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def create_marriage(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        spouse_npc_id: int,
        start_age: int,
        spouse_income: int,
        prenup: bool,
        premarital_cash: int,
        premarital_bank: int,
        wedding_cost: int,
        created_at: int,
    ) -> None:
        """Store marriage terms and premarital liquid-asset baselines."""
        await tx.execute(
            """INSERT INTO marriages
                   (char_id, spouse_npc_id, start_age, spouse_income, prenup,
                    premarital_cash, premarital_bank, wedding_cost, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                char_id, spouse_npc_id, start_age, spouse_income, int(prenup),
                premarital_cash, premarital_bank, wedding_cost, created_at,
            ),
        )

    async def delete_marriage(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Remove the current marriage record after divorce or spouse death."""
        await tx.execute("DELETE FROM marriages WHERE char_id = ?", (char_id,))

    async def get_children(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return each child NPC and custody/support state."""
        rows = await self._tx_all(
            tx,
            """SELECT n.*, c.custody, c.child_support, c.other_parent_npc_id
               FROM children AS c JOIN npcs AS n ON n.npc_id = c.npc_id
               WHERE c.char_id = ? ORDER BY n.age, n.npc_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def add_child(
        self,
        tx: aiosqlite.Connection,
        *,
        npc_id: int,
        char_id: int,
        other_parent_npc_id: Optional[int],
        custody: str = "full",
        child_support: int = 0,
    ) -> None:
        """Attach an NPC child to its player parent and support/custody record."""
        await tx.execute(
            """INSERT INTO children(npc_id, char_id, other_parent_npc_id, custody, child_support)
               VALUES (?, ?, ?, ?, ?)""",
            (npc_id, char_id, other_parent_npc_id, custody, max(0, child_support)),
        )

    async def update_child_support(self, tx: aiosqlite.Connection, npc_id: int, child_support: int) -> None:
        """Refresh the stored annual support amount in integer cents."""
        await tx.execute(
            "UPDATE children SET child_support = ? WHERE npc_id = ?",
            (max(0, int(child_support)), npc_id),
        )

    async def update_custody(self, tx: aiosqlite.Connection, npc_id: int, custody: str) -> None:
        """Persist a custody roll."""
        await tx.execute("UPDATE children SET custody = ? WHERE npc_id = ?", (custody, npc_id))

    async def add_pregnancy(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        other_parent_npc_id: Optional[int],
        conception_age: int,
        due_age: int,
        accidental: bool,
    ) -> None:
        """Persist a pregnancy until its one-year due date."""
        await tx.execute(
            """INSERT INTO pregnancies(char_id, other_parent_npc_id, conception_age, due_age, accidental)
               VALUES (?, ?, ?, ?, ?)""",
            (char_id, other_parent_npc_id, conception_age, due_age, int(accidental)),
        )

    async def get_pregnancy(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return a pending pregnancy if present."""
        row = await self._tx_one(tx, "SELECT * FROM pregnancies WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def delete_pregnancy(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Delete a pregnancy after birth or cancellation."""
        await tx.execute("DELETE FROM pregnancies WHERE char_id = ?", (char_id,))

    async def add_adoption(self, tx: aiosqlite.Connection, char_id: int, started_age: int, due_age: int, paid_cost: int) -> None:
        """Store an adoption completion date."""
        await tx.execute(
            "INSERT INTO adoptions(char_id, started_age, due_age, paid_cost) VALUES (?, ?, ?, ?)",
            (char_id, started_age, due_age, paid_cost),
        )

    async def get_adoption(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return a pending adoption."""
        row = await self._tx_one(tx, "SELECT * FROM adoptions WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def delete_adoption(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Delete a completed adoption."""
        await tx.execute("DELETE FROM adoptions WHERE char_id = ?", (char_id,))

    async def add_asset(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        kind: str,
        item_id: str,
        quantity: int,
        purchase_price: int,
        current_value: int,
        acquired_age: int,
        acquired_at: int,
    ) -> int:
        """Add an item or portfolio asset with integer-cent values."""
        cursor = await tx.execute(
            """INSERT INTO family_assets
                   (char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at),
        )
        return int(cursor.lastrowid)

    async def list_ring_assets(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return unused ring items available to a marriage proposal."""
        rows = await self._tx_all(
            tx,
            """SELECT * FROM family_assets
               WHERE char_id = ? AND kind = 'item' AND item_id LIKE '%_ring'
                 AND quantity > 0 AND is_liquidated = 0 AND is_locked = 0
               ORDER BY current_value DESC, asset_id""", 
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def consume_ring(self, tx: aiosqlite.Connection, asset_id: int) -> None:
        """Consume the selected ring at proposal time."""
        await tx.execute(
            "UPDATE family_assets SET quantity = 0, purchase_price = 0, current_value = 0, is_liquidated = 1 WHERE asset_id = ? AND is_locked = 0",
            (asset_id,),
        )

    async def get_marital_assets(self, tx: aiosqlite.Connection, char_id: int, marriage_started_at: int) -> list[dict[str, Any]]:
        """Return non-liquidated assets acquired at or after the wedding timestamp."""
        rows = await self._tx_all(
            tx,
            """SELECT * FROM family_assets
               WHERE char_id = ? AND acquired_at >= ? AND current_value > 0 AND is_liquidated = 0
                 AND (kind != 'item' OR is_locked = 0)
               ORDER BY CASE kind WHEN 'stock' THEN 0 ELSE 1 END, asset_id""", 
            (char_id, marriage_started_at),
        )
        return [dict(row) for row in rows]

    async def reduce_asset(self, tx: aiosqlite.Connection, asset_id: int, reduction: int) -> int:
        """Reduce an asset's value by up to an integer-cent payment amount."""
        row = await self._tx_one(
            tx, "SELECT current_value FROM family_assets WHERE asset_id = ? AND (kind != 'item' OR is_locked = 0)",
            (asset_id,),
        )
        if row is None:
            return 0
        current = int(row["current_value"])
        used = min(current, max(0, int(reduction)))
        remaining = current - used
        await tx.execute(
            "UPDATE family_assets SET current_value = ?, is_liquidated = ? WHERE asset_id = ?",
            (remaining, int(remaining == 0), asset_id),
        )
        return used

    async def liquidate_stock_assets(self, tx: aiosqlite.Connection, char_id: int, marriage_started_at: int) -> int:
        """Liquidate eligible marital stocks and return their total integer-cent value."""
        row = await self._tx_one(
            tx,
            """SELECT COALESCE(SUM(current_value), 0) AS total FROM family_assets
               WHERE char_id = ? AND kind = 'stock' AND acquired_at >= ?
                 AND current_value > 0 AND is_liquidated = 0""",
            (char_id, marriage_started_at),
        )
        total = int(row["total"] if row is not None else 0)
        await tx.execute(
            """UPDATE family_assets SET current_value = 0, quantity = 0, is_liquidated = 1
               WHERE char_id = ? AND kind = 'stock' AND acquired_at >= ?
                 AND current_value > 0 AND is_liquidated = 0""",
            (char_id, marriage_started_at),
        )
        return total

    async def get_annual_job_income(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Return the current annual salary as integer cents, or zero when unemployed."""
        row = await self._tx_one(tx, "SELECT salary FROM jobs WHERE char_id = ? LIMIT 1", (char_id,))
        return int(row["salary"]) if row is not None else 0

    async def create_alimony(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        ex_npc_id: int,
        annual_amount: int,
        remaining_years: float,
        payer_is_player: bool,
    ) -> None:
        """Persist an alimony agreement."""
        await tx.execute(
            """INSERT INTO alimony(char_id, ex_npc_id, annual_amount, remaining_years, payer_is_player)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(char_id) DO UPDATE SET
                   ex_npc_id = excluded.ex_npc_id,
                   annual_amount = excluded.annual_amount,
                   remaining_years = excluded.remaining_years,
                   payer_is_player = excluded.payer_is_player""",
            (char_id, ex_npc_id, max(0, annual_amount), max(0.0, remaining_years), int(payer_is_player)),
        )

    async def get_alimony(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return an active alimony order."""
        row = await self._tx_one(tx, "SELECT * FROM alimony WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def update_alimony(self, tx: aiosqlite.Connection, char_id: int, remaining_years: float) -> None:
        """Update or remove an expired alimony order."""
        if remaining_years <= 0:
            await tx.execute("DELETE FROM alimony WHERE char_id = ?", (char_id,))
        else:
            await tx.execute(
                "UPDATE alimony SET remaining_years = ? WHERE char_id = ?",
                (remaining_years, char_id),
            )

    async def get_affair(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return an active infidelity record."""
        row = await self._tx_one(tx, "SELECT * FROM affairs WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def save_affair(self, tx: aiosqlite.Connection, char_id: int, spouse_npc_id: int, age: int, nonce: str) -> None:
        """Persist a hidden affair after the player's infidelity choice."""
        await tx.execute(
            """INSERT INTO affairs(char_id, spouse_npc_id, started_age, nonce)
               VALUES (?, ?, ?, ?)
               ON CONFLICT(char_id) DO UPDATE SET
                   spouse_npc_id = excluded.spouse_npc_id,
                   started_age = excluded.started_age,
                   nonce = excluded.nonce""",
            (char_id, spouse_npc_id, age, nonce),
        )

    async def delete_affair(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Delete a discovered or ended affair."""
        await tx.execute("DELETE FROM affairs WHERE char_id = ?", (char_id,))

    async def increment_divorces(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Increment the persistent divorce statistic."""
        await tx.execute(
            """INSERT INTO stats_tracking(char_id, divorces) VALUES (?, 1)
               ON CONFLICT(char_id) DO UPDATE SET divorces = divorces + 1""",
            (char_id,),
        )

    async def insert_divorce_record(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        spouse_npc_id: int,
        age: int,
        prenup: bool,
        marital_assets: int,
        spouse_share: int,
        lawyer_fee: int,
        reason: str,
        created_at: int,
    ) -> None:
        """Persist an audit summary of one completed divorce."""
        await tx.execute(
            """INSERT INTO divorce_records
                   (char_id, spouse_npc_id, age, prenup, marital_assets, spouse_share,
                    lawyer_fee, reason, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, spouse_npc_id, age, int(prenup), marital_assets, spouse_share, lawyer_fee, reason, created_at),
        )

    async def update_custody_and_support(
        self,
        tx: aiosqlite.Connection,
        npc_id: int,
        custody: str,
        support: int,
    ) -> None:
        """Store divorce custody and its annual support amount."""
        await tx.execute(
            "UPDATE children SET custody = ?, child_support = ? WHERE npc_id = ?",
            (custody, max(0, support), npc_id),
        )

    async def list_children_public(self, char_id: int) -> list[dict[str, Any]]:
        """Read child NPCs for the family command."""
        rows = await self.db.fetchall(
            """SELECT n.*, c.custody, c.child_support, c.other_parent_npc_id
               FROM children AS c JOIN npcs AS n ON n.npc_id = c.npc_id
               WHERE c.char_id = ? ORDER BY n.age, n.npc_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def people_by_type(self, tx: aiosqlite.Connection, char_id: int, types: tuple[str, ...]) -> list[dict[str, Any]]:
        """Return NPC relationships filtered by a fixed type list."""
        placeholders = ",".join("?" for _ in types)
        rows = await self._tx_all(
            tx,
            f"""SELECT n.*, r.type AS relationship_type, r.score AS relationship_score,
                       r.since_age AS relationship_since_age
                FROM relationships AS r JOIN npcs AS n ON n.npc_id = r.npc_id
                WHERE r.char_id = ? AND r.type IN ({placeholders}) ORDER BY n.npc_id""",
            (char_id, *types),
        )
        return [dict(row) for row in rows]

    async def log_relationship_interaction(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        age: int,
        text: str,
        now: int,
    ) -> None:
        """Log one relationship action to the life journal."""
        await self.insert_life_log(
            tx,
            char_id=char_id,
            age=age,
            category="relationship",
            text=text,
            importance=2,
            created_at=now,
        )

    async def get_npc_owned(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        npc_id: int,
    ) -> Optional[dict[str, Any]]:
        """Return any NPC owned by a life, whether or not it has a relationship row."""
        row = await self._tx_one(
            tx,
            "SELECT * FROM npcs WHERE owner_char_id = ? AND npc_id = ? LIMIT 1",
            (char_id, npc_id),
        )
        return dict(row) if row is not None else None

    async def add_npc_wealth(self, tx: aiosqlite.Connection, npc_id: int, delta: int) -> None:
        """Apply a non-negative integer-cent wealth change to one NPC."""
        await tx.execute(
            "UPDATE npcs SET wealth = MAX(0, wealth + ?) WHERE npc_id = ?",
            (int(delta), npc_id),
        )

    async def set_npc_wealth(self, tx: aiosqlite.Connection, npc_id: int, wealth: int) -> None:
        """Set an NPC's wealth to a non-negative integer-cent value."""
        await tx.execute("UPDATE npcs SET wealth = ? WHERE npc_id = ?", (max(0, int(wealth)), npc_id))

    async def get_all_assets(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return every non-liquidated item/stock asset for a settlement cascade."""
        rows = await self._tx_all(
            tx,
            """SELECT * FROM family_assets WHERE char_id = ? AND current_value > 0
               AND is_liquidated = 0 AND (kind != 'item' OR is_locked = 0)
               ORDER BY CASE kind WHEN 'stock' THEN 0 ELSE 1 END, asset_id""", 
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def has_infidelity_choice(self, tx: aiosqlite.Connection, char_id: int, age: int) -> bool:
        """Check whether this life already resolved a temptation at this age."""
        row = await self._tx_one(
            tx,
            "SELECT 1 FROM infidelity_choices WHERE char_id = ? AND age = ? LIMIT 1",
            (char_id, age),
        )
        return row is not None

    async def record_infidelity_choice(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        spouse_npc_id: int,
        age: int,
        choice: str,
        created_at: int,
    ) -> None:
        """Persist one choice per in-game age; the unique key protects races."""
        await tx.execute(
            """INSERT INTO infidelity_choices(char_id, spouse_npc_id, age, choice, created_at)
               VALUES (?, ?, ?, ?, ?)""",
            (char_id, spouse_npc_id, age, choice, created_at),
        )

    async def create_infidelity_prompt(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        spouse_npc_id: int,
        nonce: str,
        created_at: int,
        expires_at: int,
    ) -> None:
        """Persist a one-use temptation prompt."""
        await tx.execute("DELETE FROM infidelity_prompts WHERE char_id = ?", (char_id,))
        await tx.execute(
            """INSERT INTO infidelity_prompts(char_id, spouse_npc_id, nonce, created_at, expires_at)
               VALUES (?, ?, ?, ?, ?)""",
            (char_id, spouse_npc_id, nonce, created_at, expires_at),
        )

    async def get_infidelity_prompt(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        nonce: str,
        now: int,
    ) -> Optional[dict[str, Any]]:
        """Return an unexpired prompt only when its owner and nonce match."""
        row = await self._tx_one(
            tx,
            """SELECT * FROM infidelity_prompts
               WHERE char_id = ? AND nonce = ? AND expires_at >= ? LIMIT 1""",
            (char_id, nonce, now),
        )
        return dict(row) if row is not None else None

    async def delete_infidelity_prompt(self, tx: aiosqlite.Connection, char_id: int, nonce: str) -> None:
        """Consume one temptation prompt."""
        await tx.execute("DELETE FROM infidelity_prompts WHERE char_id = ? AND nonce = ?", (char_id, nonce))

    async def update_marriage_low_score_years(self, tx: aiosqlite.Connection, char_id: int, years: int) -> None:
        """Store the consecutive low-score years needed for NPC divorce checks."""
        await tx.execute(
            "UPDATE marriages SET low_score_years = ? WHERE char_id = ?",
            (max(0, int(years)), char_id),
        )
