"""Persistence repositories for LIFELINE's transactional game systems."""
