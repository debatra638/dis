"""Parameterized persistence for Stage 10 achievements, death, estates, and legacy."""
from __future__ import annotations

import json
from typing import Any, Optional, Sequence

import aiosqlite

from ..models import Character


class LegacyRepository:
    """Own all Stage 10 SQL; callers provide an already-open write transaction."""

    def __init__(self, db: Any) -> None:
        self.db = db

    @staticmethod
    async def _one(tx: aiosqlite.Connection, sql: str, params: tuple[Any, ...] = ()) -> Any:
        """Fetch one row from a caller-owned transaction."""
        cursor = await tx.execute(sql, params)
        return await cursor.fetchone()

    @staticmethod
    async def _all(tx: aiosqlite.Connection, sql: str, params: tuple[Any, ...] = ()) -> list[Any]:
        """Fetch all rows from a caller-owned transaction."""
        cursor = await tx.execute(sql, params)
        return await cursor.fetchall()

    async def has_pending_event(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Return whether a life has an unresolved choice event."""
        row = await self._one(tx, "SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1", (char_id,))
        return row is not None

    async def ensure_player(self, tx: aiosqlite.Connection, user_id: int, now: int) -> None:
        """Create the account row needed by achievements and legacy balances."""
        await tx.execute(
            "INSERT OR IGNORE INTO players(user_id, created_at) VALUES (?, ?)",
            (user_id, now),
        )

    async def player_row(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Return a player's privacy, life-count, and legacy-point state."""
        row = await self._one(tx, "SELECT * FROM players WHERE user_id = ? LIMIT 1", (user_id,))
        return dict(row) if row is not None else None

    async def spend_legacy_points(
        self,
        tx: aiosqlite.Connection,
        *,
        user_id: int,
        char_id: int,
        stat_name: str,
        purchase_count: int,
        now: int,
    ) -> int:
        """Spend 50 cosmetic points per starting-stat purchase, up to two."""
        await self.ensure_player(tx, user_id, now)
        cost = purchase_count * 50
        cursor = await tx.execute(
            "UPDATE players SET legacy_points = legacy_points - ? WHERE user_id = ? AND legacy_points >= ?",
            (cost, user_id, cost),
        )
        if cursor.rowcount != 1:
            raise ValueError("not enough legacy points")
        await tx.execute(
            """INSERT INTO legacy_start_purchases
                   (char_id, user_id, stat_name, purchase_count, points_spent, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (char_id, user_id, stat_name, purchase_count, cost, now),
        )
        return cost

    async def audit_legacy_purchase(
        self,
        tx: aiosqlite.Connection,
        *,
        user_id: int,
        char_id: int,
        stat_name: str,
        purchase_count: int,
        now: int,
    ) -> None:
        """Record cosmetic starting-stat spending in the transaction audit log."""
        await tx.execute(
            """INSERT INTO audit_log(ts, user_id, char_id, action, amount, details_json)
               VALUES (?, ?, ?, 'legacy_start_purchase', ?, ?)""",
            (
                now, user_id, char_id, purchase_count * 50,
                json.dumps({"stat": stat_name, "purchases": purchase_count}, separators=(",", ":")),
            ),
        )

    async def active_character(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Return the user's current active character row."""
        row = await self._one(
            tx,
            "SELECT char_id, user_id, is_alive, age, data_json, version FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def character_record(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Load a character whether alive or archived."""
        row = await self._one(tx, "SELECT * FROM characters WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def user_character_rows(self, tx: aiosqlite.Connection, user_id: int) -> list[dict[str, Any]]:
        """Load every persisted life for one player in stable order."""
        rows = await self._all(
            tx,
            "SELECT * FROM characters WHERE user_id = ? ORDER BY char_id ASC",
            (user_id,),
        )
        return [dict(row) for row in rows]

    async def save_heir_character(self, tx: aiosqlite.Connection, character: Character) -> int:
        """Insert one new heir life with its authoritative serialized attributes."""
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        hidden_json = json.dumps(
            {
                "genetic_health_mod": character.hidden.genetic_health_mod,
                "lifespan_mod": character.hidden.lifespan_mod,
                "luck": character.hidden.luck,
                "temperament": character.hidden.temperament,
            },
            separators=(",", ":"),
            allow_nan=False,
        )
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """INSERT INTO characters
                   (user_id, is_alive, name, gender, country, wealth_class, age,
                    stats_json, hidden_json, version, last_age_at, born_at,
                    died_at, death_cause, death_age, data_json)
               VALUES (?, 1, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, NULL, NULL, NULL, ?)""",
            (
                character.user_id, character.name, character.gender.value, character.country,
                character.wealth_class, character.age, stats_json, hidden_json,
                character.last_age_at, character.born_at, data_json,
            ),
        )
        return int(cursor.lastrowid)

    async def refresh_character_json(self, tx: aiosqlite.Connection, character: Character) -> None:
        """Update a newly assigned character ID inside its serialized snapshot."""
        await tx.execute(
            "UPDATE characters SET data_json = ? WHERE char_id = ?",
            (
                json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False),
                character.char_id,
            ),
        )

    async def save_death_character(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
    ) -> None:
        """Persist the terminal character state once, using the life version as a guard."""
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        hidden_json = json.dumps(
            {
                "genetic_health_mod": character.hidden.genetic_health_mod,
                "lifespan_mod": character.hidden.lifespan_mod,
                "luck": character.hidden.luck,
                "temperament": character.hidden.temperament,
            },
            separators=(",", ":"),
            allow_nan=False,
        )
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET is_alive = 0, age = ?, stats_json = ?, hidden_json = ?,
                   version = ?, last_age_at = ?, died_at = ?, death_cause = ?, death_age = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (
                character.age, stats_json, hidden_json, character.version, character.last_age_at,
                character.died_at, character.death_cause, character.death_age, data_json,
                character.char_id, expected_version,
            ),
        )
        if cursor.rowcount != 1:
            from ..errors import ConcurrentUpdate
            raise ConcurrentUpdate("This life has already ended or changed.")

    async def economy_snapshot(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, int]:
        """Compute liquid and recorded asset values without trusting command arguments."""
        record = await self._one(tx, "SELECT data_json FROM characters WHERE char_id = ?", (char_id,))
        if record is None:
            raise ValueError("character not found")
        data = json.loads(record["data_json"])
        cash = max(0, int(data.get("cash", 0)))
        bank = max(0, int(data.get("bank", 0)))
        debt = max(0, int(data.get("debt_total", 0)))
        item_row = await self._one(
            tx,
            """SELECT COALESCE(SUM(current_value), 0) AS value
               FROM family_assets WHERE char_id = ? AND kind = 'item' AND quantity > 0 AND is_liquidated = 0""", 
            (char_id,),
        )
        stock_row = await self._one(
            tx,
            """SELECT COALESCE(SUM(h.shares * CASE WHEN m.is_delisted = 1 OR m.price_cents < 1
                                                     THEN 0 ELSE m.price_cents END), 0) AS value
               FROM stock_holdings AS h LEFT JOIN stock_market AS m ON m.symbol = h.symbol
               WHERE h.char_id = ?""",
            (char_id,),
        )
        bond_row = await self._one(
            tx,
            "SELECT COALESCE(SUM(balance_cents), 0) AS value FROM savings_bonds WHERE char_id = ? AND status = 'locked'",
            (char_id,),
        )
        loan_row = await self._one(
            tx,
            "SELECT COALESCE(SUM(balance), 0) AS value FROM loans WHERE char_id = ? AND status = 'active'",
            (char_id,),
        )
        items = max(0, int(item_row["value"]))
        stocks = max(0, int(stock_row["value"]))
        bonds = max(0, int(bond_row["value"]))
        liabilities = max(debt, max(0, int(loan_row["value"])))
        gross = cash + bank + items + stocks + bonds
        return {
            "cash_cents": cash,
            "bank_cents": bank,
            "item_assets_cents": items,
            "stock_assets_cents": stocks,
            "bond_assets_cents": bonds,
            "gross_assets_cents": gross,
            "debts_cents": liabilities,
            "net_worth_cents": gross - liabilities,
        }

    async def record_life_year(
        self,
        tx: aiosqlite.Connection,
        *,
        character: Character,
        age: int,
        served_prison_year: bool,
        now: int,
    ) -> dict[str, int]:
        """Record annual happiness and the high-water net worth for one age."""
        economy = await self.economy_snapshot(tx, character.char_id)
        prior = await self._one(
            tx,
            "SELECT COALESCE(MAX(peak_net_worth_cents), 0) AS peak FROM life_year_metrics WHERE char_id = ?",
            (character.char_id,),
        )
        peak = max(int(prior["peak"]), economy["net_worth_cents"])
        await tx.execute(
            """INSERT INTO life_year_metrics
                   (char_id, age, happiness, net_worth_cents, peak_net_worth_cents, served_prison_year, recorded_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(char_id, age) DO UPDATE SET
                   net_worth_cents = excluded.net_worth_cents,
                   peak_net_worth_cents = MAX(life_year_metrics.peak_net_worth_cents, excluded.peak_net_worth_cents),
                   served_prison_year = MAX(life_year_metrics.served_prison_year, excluded.served_prison_year)""",
            (
                character.char_id, age, max(0, min(100, int(character.stats.happiness))),
                economy["net_worth_cents"], peak, int(served_prison_year), now,
            ),
        )
        economy["peak_net_worth_cents"] = peak
        return economy

    async def bankruptcy_count(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Return the number of durable bankruptcy filings for one life."""
        row = await self._one(tx, "SELECT COUNT(*) AS count FROM bankruptcies WHERE char_id = ?", (char_id,))
        return int(row["count"]) if row is not None else 0

    async def life_year_metrics(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Read yearly happiness, wealth, and prison-time observations chronologically."""
        rows = await self._all(
            tx,
            "SELECT * FROM life_year_metrics WHERE char_id = ? ORDER BY age ASC",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def ensure_player_for_character(self, tx: aiosqlite.Connection, char_id: int, now: int) -> int:
        """Ensure the player row exists for a character and return its Discord ID."""
        row = await self._one(tx, "SELECT user_id FROM characters WHERE char_id = ?", (char_id,))
        if row is None:
            raise ValueError("character not found")
        user_id = int(row["user_id"])
        await self.ensure_player(tx, user_id, now)
        return user_id

    async def close_open_career(self, tx: aiosqlite.Connection, char_id: int, age: int, reason: str) -> None:
        """Close any still-open career history and remove the active job row."""
        await tx.execute(
            "UPDATE career_history SET end_age = ?, end_reason = ? WHERE char_id = ? AND end_age IS NULL",
            (age, reason, char_id),
        )
        await tx.execute("DELETE FROM jobs WHERE char_id = ?", (char_id,))

    async def archive_marriage(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        end_age: int,
        end_reason: str,
        now: int,
    ) -> Optional[dict[str, Any]]:
        """Move a current marriage into durable history before its live row is removed."""
        row = await self._one(
            tx,
            """SELECT m.*, n.name AS spouse_name FROM marriages AS m
               JOIN npcs AS n ON n.npc_id = m.spouse_npc_id WHERE m.char_id = ? LIMIT 1""",
            (char_id,),
        )
        if row is None:
            return None
        result = dict(row)
        final_age = max(int(result["start_age"]), int(end_age))
        await tx.execute(
            """INSERT INTO marriage_history
                   (char_id, spouse_npc_id, spouse_name, start_age, end_age, end_reason, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                char_id, int(result["spouse_npc_id"]), str(result["spouse_name"]),
                int(result["start_age"]), final_age, end_reason, now,
            ),
        )
        await tx.execute("DELETE FROM marriages WHERE char_id = ?", (char_id,))
        return result

    async def children(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Load all children and their live NPC attributes for summaries and inheritance."""
        rows = await self._all(
            tx,
            """SELECT n.*, c.custody, c.child_support, c.other_parent_npc_id
               FROM children AS c JOIN npcs AS n ON n.npc_id = c.npc_id
               WHERE c.char_id = ? ORDER BY n.npc_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def insert_life_log(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        age: int,
        category: str,
        text: str,
        importance: int,
        created_at: int,
    ) -> None:
        """Insert one sanitized-by-caller life moment using parameterized SQL."""
        await tx.execute(
            """INSERT INTO life_logs(char_id, age, category, text, importance, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (char_id, age, category, text, importance, created_at),
        )

    async def top_life_logs(self, tx: aiosqlite.Connection, char_id: int, limit: int = 10) -> list[dict[str, Any]]:
        """Load the most important life moments with deterministic age/ID ordering."""
        rows = await self._all(
            tx,
            """SELECT age, category, text, importance FROM life_logs WHERE char_id = ?
               ORDER BY importance DESC, age ASC, id ASC LIMIT ?""",
            (char_id, limit),
        )
        return [dict(row) for row in rows]

    async def career_history(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Load recorded careers and maximum levels for a life."""
        rows = await self._all(
            tx,
            "SELECT * FROM career_history WHERE char_id = ? ORDER BY start_age, id",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def marriage_history(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Load ended marriages in chronological order."""
        rows = await self._all(
            tx,
            "SELECT * FROM marriage_history WHERE char_id = ? ORDER BY start_age, marriage_history_id",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def current_marriage(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Load a current spouse and marriage start age."""
        row = await self._one(
            tx,
            """SELECT m.*, n.name AS spouse_name, n.is_alive AS spouse_alive
               FROM marriages AS m JOIN npcs AS n ON n.npc_id = m.spouse_npc_id
               WHERE m.char_id = ? LIMIT 1""",
            (char_id,),
        )
        return dict(row) if row is not None else None

    async def crime_summary(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Any]:
        """Aggregate attempts, convictions, successful escapes, and served years."""
        attempts = await self._one(
            tx,
            """SELECT COUNT(*) AS attempts,
                      SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) AS successes,
                      SUM(CASE WHEN case_status = 'convicted' AND record_sealed = 0 THEN 1 ELSE 0 END) AS convictions,
                      SUM(CASE WHEN record_sealed = 1 THEN 1 ELSE 0 END) AS sealed
               FROM crime_attempts WHERE char_id = ?""",
            (char_id,),
        )
        profile = await self._one(tx, "SELECT * FROM crime_profiles WHERE char_id = ?", (char_id,))
        served = await self._one(
            tx,
            "SELECT COALESCE(SUM(served_prison_year), 0) AS years FROM life_year_metrics WHERE char_id = ?",
            (char_id,),
        )
        escaped_log = await self._one(
            tx,
            "SELECT 1 FROM life_logs WHERE char_id = ? AND category = 'prison' AND lower(text) LIKE '%escaped%' LIMIT 1",
            (char_id,),
        )
        return {
            "attempts": int(attempts["attempts"] or 0),
            "successes": int(attempts["successes"] or 0),
            "convictions": int(attempts["convictions"] or 0),
            "sealed_convictions": int(attempts["sealed"] or 0),
            "profile": dict(profile) if profile is not None else {},
            "years_in_prison": int(served["years"] or 0),
            "escaped": bool(escaped_log) or bool(profile and int(profile["escaped"])),
        }

    async def casino_rows(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Load settled casino outcomes for authoritative achievement checks."""
        rows = await self._all(
            tx,
            "SELECT game, bet_cents, payout_cents, net_cents, status, outcome_json FROM casino_plays WHERE char_id = ? ORDER BY play_id",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def investment_rows(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Any]:
        """Return stock trade, bond maturity, rental, and current holding facts."""
        trades = await self._one(tx, "SELECT COUNT(*) AS count FROM investment_trades WHERE char_id = ?", (char_id,))
        holdings = await self._one(
            tx,
            "SELECT COUNT(*) AS count, COALESCE(SUM(shares), 0) AS shares FROM stock_holdings WHERE char_id = ?",
            (char_id,),
        )
        bonds = await self._one(
            tx,
            "SELECT COUNT(*) AS count FROM savings_bonds WHERE char_id = ? AND status = 'matured'",
            (char_id,),
        )
        rent = await self._one(
            tx,
            "SELECT COALESCE(SUM(rental_income_cents), 0) AS income FROM investment_yearly_income WHERE char_id = ?",
            (char_id,),
        )
        return {
            "trade_count": int(trades["count"]),
            "holding_count": int(holdings["count"]),
            "share_count": int(holdings["shares"]),
            "matured_bonds": int(bonds["count"]),
            "rental_income_cents": int(rent["income"]),
        }

    async def education_rows(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Any]:
        """Read authoritative course and GPA records."""
        row = await self._one(
            tx,
            """SELECT COUNT(*) AS count,
                      SUM(CASE WHEN effort = 'hard' THEN 1 ELSE 0 END) AS hard_count,
                      COALESCE(MAX(gpa_after), 0) AS max_gpa
               FROM education_actions WHERE char_id = ?""",
            (char_id,),
        )
        return {
            "study_actions": int(row["count"] or 0),
            "hard_study_actions": int(row["hard_count"] or 0),
            "max_gpa": float(row["max_gpa"] or 0),
        }

    async def active_job(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Read a current job for career facts and salary summaries."""
        row = await self._one(tx, "SELECT * FROM jobs WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def work_action_count(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Count recorded work actions for a life."""
        row = await self._one(tx, "SELECT COUNT(*) AS count FROM career_actions WHERE char_id = ?", (char_id,))
        return int(row["count"])

    async def divorce_count(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Count completed divorces from the authoritative Stage 6 ledger."""
        row = await self._one(tx, "SELECT COUNT(*) AS count FROM divorce_records WHERE char_id = ?", (char_id,))
        return int(row["count"])

    async def marriage_count(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Count current plus archived marriages."""
        row = await self._one(
            tx,
            """SELECT (SELECT COUNT(*) FROM marriage_history WHERE char_id = ?) +
                      (SELECT COUNT(*) FROM marriages WHERE char_id = ?) AS count""",
            (char_id, char_id),
        )
        return int(row["count"])

    async def max_marriage_years(self, tx: aiosqlite.Connection, char_id: int, current_age: int) -> int:
        """Return the longest recorded or current marriage duration."""
        row = await self._one(
            tx,
            """SELECT COALESCE(MAX(duration), 0) AS years FROM (
                   SELECT MAX(0, end_age - start_age) AS duration FROM marriage_history WHERE char_id = ?
                   UNION ALL
                   SELECT MAX(0, ? - start_age) AS duration FROM marriages WHERE char_id = ?
               )""",
            (char_id, current_age, char_id),
        )
        return int(row["years"])

    async def child_count(self, tx: aiosqlite.Connection, char_id: int) -> int:
        """Count all children recorded for a character, living or deceased."""
        row = await self._one(tx, "SELECT COUNT(*) AS count FROM children WHERE char_id = ?", (char_id,))
        return int(row["count"])

    async def item_facts(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Any]:
        """Return active owned item IDs and the count of distinct live asset lots."""
        rows = await self._all(
            tx,
            "SELECT item_id, quantity FROM family_assets WHERE char_id = ? AND quantity > 0 AND is_liquidated = 0",
            (char_id,),
        )
        return {"item_rows": [dict(row) for row in rows], "asset_lots": len(rows)}

    async def rehab_used(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check whether the authoritative audit ledger records recovery treatment."""
        row = await self._one(
            tx,
            "SELECT 1 FROM audit_log WHERE char_id = ? AND action = 'gambling_rehab_used' LIMIT 1",
            (char_id,),
        )
        return row is not None

    async def stats_tracking(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, int]:
        """Read Stage 9 gambling totals and Stage 6 divorce count."""
        row = await self._one(tx, "SELECT * FROM stats_tracking WHERE char_id = ? LIMIT 1", (char_id,))
        if row is None:
            return {"total_gambled": 0, "total_gambling_net": 0, "divorces": 0}
        data = dict(row)
        return {
            "total_gambled": int(data.get("total_gambled", 0)),
            "total_gambling_net": int(data.get("total_gambling_net", 0)),
            "divorces": int(data.get("divorces", 0)),
        }

    async def insert_achievement(
        self, tx: aiosqlite.Connection, *, user_id: int, achievement_id: str, char_id: int, now: int
    ) -> bool:
        """Insert a first unlock only; the primary key prevents repeat awards."""
        await self.ensure_player(tx, user_id, now)
        cursor = await tx.execute(
            """INSERT OR IGNORE INTO achievements_unlocked(user_id, achievement_id, char_id, unlocked_at)
               VALUES (?, ?, ?, ?)""",
            (user_id, achievement_id, char_id, now),
        )
        return cursor.rowcount == 1

    async def user_achievements(self, tx: aiosqlite.Connection, user_id: int) -> list[dict[str, Any]]:
        """Load a player's earned achievement rows chronologically."""
        rows = await self._all(
            tx,
            """SELECT a.*, c.name AS character_name FROM achievements_unlocked AS a
               JOIN characters AS c ON c.char_id = a.char_id
               WHERE a.user_id = ? ORDER BY a.unlocked_at DESC, a.achievement_id""",
            (user_id,),
        )
        return [dict(row) for row in rows]

    async def character_achievement_rows(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Load achievements earned during a single life for its death summary."""
        rows = await self._all(
            tx,
            """SELECT achievement_id, unlocked_at FROM achievements_unlocked
               WHERE char_id = ? ORDER BY unlocked_at, achievement_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def add_player_legacy_points(self, tx: aiosqlite.Connection, user_id: int, points: int, now: int) -> None:
        """Add the exact cosmetic legacy score to a player account."""
        await self.ensure_player(tx, user_id, now)
        await tx.execute("UPDATE players SET legacy_points = legacy_points + ? WHERE user_id = ?", (points, user_id))

    async def increment_lives_lived(self, tx: aiosqlite.Connection, user_id: int, now: int) -> None:
        """Increment archived-life count once after the immutable archive insert."""
        await self.ensure_player(tx, user_id, now)
        await tx.execute("UPDATE players SET lives_lived = lives_lived + 1 WHERE user_id = ?", (user_id,))

    async def insert_past_life(self, tx: aiosqlite.Connection, summary: dict[str, Any]) -> bool:
        """Insert an immutable archive row without ever replacing an earlier summary."""
        cursor = await tx.execute(
            """INSERT OR IGNORE INTO past_lives
                   (char_id, user_id, death_age, death_cause, born_at, died_at, life_score, grade,
                    legacy_points, peak_net_worth_cents, final_net_worth_cents, gross_assets_cents,
                    debts_paid_cents, estate_tax_cents, estate_cents, unpaid_debt_cents,
                    abandoned, summary_json, archived_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                int(summary["char_id"]), int(summary["user_id"]), int(summary["death_age"]),
                str(summary["death_cause"]), int(summary["born_at"]), int(summary["died_at"]),
                float(summary["life_score"]), str(summary["grade"]), int(summary["legacy_points"]),
                int(summary["peak_net_worth_cents"]), int(summary["final_net_worth_cents"]),
                int(summary["gross_assets_cents"]), int(summary["debts_paid_cents"]),
                int(summary["estate_tax_cents"]), int(summary["estate_cents"]),
                int(summary["unpaid_debt_cents"]), int(bool(summary["abandoned"])),
                json.dumps(
                    summary["summary_json"],
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                    allow_nan=False,
                ),
                int(summary["archived_at"]),
            ),
        )
        return cursor.rowcount == 1

    async def past_life(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Load an archived life by its immutable character ID."""
        row = await self._one(tx, "SELECT * FROM past_lives WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def user_past_lives(self, tx: aiosqlite.Connection, user_id: int, limit: int = 50) -> list[dict[str, Any]]:
        """Load a user's most recent life archives."""
        rows = await self._all(
            tx,
            "SELECT * FROM past_lives WHERE user_id = ? ORDER BY past_life_id DESC LIMIT ?",
            (user_id, limit),
        )
        return [dict(row) for row in rows]

    async def recent_deaths(self, tx: aiosqlite.Connection, limit: int = 50) -> list[dict[str, Any]]:
        """Load the most recent natural/ordinary deaths, excluding voluntary retirement."""
        rows = await self._all(
            tx,
            """SELECT p.*, c.name FROM past_lives AS p
               JOIN characters AS c ON c.char_id = p.char_id
               JOIN players AS pl ON pl.user_id = p.user_id
               WHERE p.abandoned = 0 AND pl.leaderboard_opt_out = 0
               ORDER BY p.archived_at DESC, p.past_life_id DESC LIMIT ?""", 
            (limit,),
        )
        return [dict(row) for row in rows]

    async def settle_loan_balances(self, tx: aiosqlite.Connection, char_id: int, payment_cents: int) -> int:
        """Pay active loans in stable order and default terminal-life balances left unpaid."""
        remaining = max(0, int(payment_cents))
        rows = await self._all(
            tx,
            "SELECT loan_id, balance FROM loans WHERE char_id = ? AND status = 'active' ORDER BY loan_id",
            (char_id,),
        )
        paid = 0
        for row in rows:
            if remaining <= 0:
                break
            balance = max(0, int(row["balance"]))
            part = min(balance, remaining)
            new_balance = balance - part
            await tx.execute(
                "UPDATE loans SET balance = ?, status = ? WHERE loan_id = ? AND status = 'active'",
                (new_balance, "paid" if new_balance == 0 else "active", int(row["loan_id"])),
            )
            paid += part
            remaining -= part
        # A terminal life has no future income from which to collect any remainder.
        # Close unpaid loans as defaulted instead of leaving active debt attached to an archive.
        await tx.execute(
            "UPDATE loans SET status = 'defaulted' WHERE char_id = ? AND status = 'active'",
            (int(char_id),),
        )
        return paid

    async def close_pending_life_estates(self, tx: aiosqlite.Connection, user_id: int, now: int) -> int:
        """Close unclaimed inheritance prompts when a user elects to begin afresh."""
        cursor = await tx.execute(
            "UPDATE life_estates SET status = 'closed', resolved_at = ? WHERE user_id = ? AND status = 'pending'",
            (now, user_id),
        )
        return int(cursor.rowcount)

    async def guild_public_death_summaries(self, tx: aiosqlite.Connection, guild_id: int) -> bool:
        """Read the guild obituary setting; an unconfigured server defaults to public."""
        row = await self._one(
            tx,
            "SELECT public_death_summaries FROM guild_stage10_settings WHERE guild_id = ?",
            (guild_id,),
        )
        return True if row is None else bool(int(row["public_death_summaries"]))

    async def set_guild_public_death_summaries(
        self, tx: aiosqlite.Connection, *, guild_id: int, enabled: bool, user_id: int, now: int
    ) -> None:
        """Persist an administrator's guild-level obituary visibility choice."""
        await tx.execute(
            """INSERT INTO guild_stage10_settings(guild_id, public_death_summaries, updated_by, updated_at)
               VALUES (?, ?, ?, ?)
               ON CONFLICT(guild_id) DO UPDATE SET
                   public_death_summaries = excluded.public_death_summaries,
                   updated_by = excluded.updated_by,
                   updated_at = excluded.updated_at""",
            (guild_id, int(enabled), user_id, now),
        )

    async def insert_life_estate(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        user_id: int,
        estate_cents: int,
        nonce: str,
        eligible_heirs: list[dict[str, Any]],
        now: int,
    ) -> int:
        """Persist one durable owner-bound heir continuation choice."""
        cursor = await tx.execute(
            """INSERT INTO life_estates
                   (char_id, user_id, estate_cents, nonce, eligible_heirs_json, status, created_at)
               VALUES (?, ?, ?, ?, ?, 'pending', ?)""",
            (
                char_id, user_id, estate_cents, nonce,
                json.dumps(eligible_heirs, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False),
                now,
            ),
        )
        return int(cursor.lastrowid)

    async def pending_life_estate(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Load the newest unresolved heir choice for a single owner."""
        row = await self._one(
            tx,
            "SELECT * FROM life_estates WHERE user_id = ? AND status = 'pending' ORDER BY created_at DESC LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def load_life_estate(self, tx: aiosqlite.Connection, estate_id: int) -> Optional[dict[str, Any]]:
        """Load a continuation prompt and its owner/status for server-side validation."""
        row = await self._one(tx, "SELECT * FROM life_estates WHERE estate_id = ? LIMIT 1", (estate_id,))
        return dict(row) if row is not None else None

    async def resolve_life_estate(
        self,
        tx: aiosqlite.Connection,
        *,
        estate_id: int,
        user_id: int,
        nonce: str,
        selected_npc_id: Optional[int],
        now: int,
    ) -> bool:
        """Claim or close a pending inheritance choice exactly once."""
        status = "claimed" if selected_npc_id is not None else "closed"
        cursor = await tx.execute(
            """UPDATE life_estates SET status = ?, selected_npc_id = ?, resolved_at = ?
               WHERE estate_id = ? AND user_id = ? AND nonce = ? AND status = 'pending'""",
            (status, selected_npc_id, now, estate_id, user_id, nonce),
        )
        return cursor.rowcount == 1

    async def pending_retirement_prompt(
        self, tx: aiosqlite.Connection, user_id: int
    ) -> Optional[dict[str, Any]]:
        """Load an active retirement confirmation to prevent duplicate pending prompts."""
        row = await self._one(
            tx,
            "SELECT * FROM retirement_prompts WHERE user_id = ? AND status = 'pending' LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def insert_retirement_prompt(
        self, tx: aiosqlite.Connection, *, user_id: int, char_id: int, nonce: str, now: int, expires_at: int
    ) -> int:
        """Persist a one-time confirmation prompt before abandoning a life."""
        cursor = await tx.execute(
            """INSERT INTO retirement_prompts(user_id, char_id, nonce, created_at, expires_at)
               VALUES (?, ?, ?, ?, ?)""",
            (user_id, char_id, nonce, now, expires_at),
        )
        return int(cursor.lastrowid)

    async def load_retirement_prompt(self, tx: aiosqlite.Connection, prompt_id: int) -> Optional[dict[str, Any]]:
        """Load a retirement confirmation for owner, nonce, and expiry checks."""
        row = await self._one(tx, "SELECT * FROM retirement_prompts WHERE prompt_id = ? LIMIT 1", (prompt_id,))
        return dict(row) if row is not None else None

    async def resolve_retirement_prompt(
        self, tx: aiosqlite.Connection, *, prompt_id: int, user_id: int, nonce: str, status: str, now: int
    ) -> bool:
        """Resolve a pending retirement prompt once."""
        cursor = await tx.execute(
            """UPDATE retirement_prompts SET status = ?, resolved_at = ?
               WHERE prompt_id = ? AND user_id = ? AND nonce = ? AND status = 'pending'""",
            (status, now, prompt_id, user_id, nonce),
        )
        return cursor.rowcount == 1

    async def set_leaderboard_privacy(self, tx: aiosqlite.Connection, user_id: int, opt_out: bool, now: int) -> None:
        """Set both Stage 10 and Stage 11 representations of leaderboard visibility."""
        await self.ensure_player(tx, user_id, now)
        public = int(not opt_out)
        await tx.execute("UPDATE players SET leaderboard_opt_out = ? WHERE user_id = ?", (int(opt_out), user_id))
        await tx.execute(
            """INSERT INTO player_settings
                   (user_id, public_year_summaries, public_deaths, public_casino_results, public_leaderboards, updated_at)
               VALUES (?, 1, 1, 1, ?, ?)
               ON CONFLICT(user_id) DO UPDATE SET
                   public_leaderboards = excluded.public_leaderboards,
                   updated_at = excluded.updated_at""",
            (user_id, public, now),
        )

    async def record_guild_seen(self, tx: aiosqlite.Connection, guild_id: int, user_id: int, now: int) -> None:
        """Remember an actual guild interaction for no-members-intent filtering."""
        await self.ensure_player(tx, user_id, now)
        await tx.execute(
            """INSERT INTO guild_player_seen(guild_id, user_id, last_seen_at) VALUES (?, ?, ?)
               ON CONFLICT(guild_id, user_id) DO UPDATE SET last_seen_at = excluded.last_seen_at""",
            (guild_id, user_id, now),
        )

    async def seen_guild_users(self, tx: aiosqlite.Connection, guild_id: int) -> list[int]:
        """Return player IDs recently observed interacting in a guild."""
        rows = await self._all(
            tx,
            "SELECT user_id FROM guild_player_seen WHERE guild_id = ? ORDER BY last_seen_at DESC, user_id ASC",
            (guild_id,),
        )
        return [int(row["user_id"]) for row in rows]

    async def leaderboard_players(self, tx: aiosqlite.Connection) -> list[dict[str, Any]]:
        """Load all non-opted-out player IDs and their archived-life summaries."""
        rows = await self._all(
            tx,
            """SELECT user_id, lives_lived, legacy_points FROM players
               WHERE leaderboard_opt_out = 0 ORDER BY user_id""",
        )
        return [dict(row) for row in rows]

    async def leaderboard_characters(self, tx: aiosqlite.Connection) -> list[dict[str, Any]]:
        """Load all active characters, excluding archived raw JSON from leaderboard UI."""
        rows = await self._all(
            tx,
            "SELECT char_id, user_id, age, data_json FROM characters WHERE is_alive = 1 ORDER BY user_id, char_id",
        )
        return [dict(row) for row in rows]

    async def leaderboard_past_lives(self, tx: aiosqlite.Connection) -> list[dict[str, Any]]:
        """Load immutable summary metrics for all archived lives."""
        rows = await self._all(
            tx,
            """SELECT user_id, char_id, death_age, life_score, peak_net_worth_cents, final_net_worth_cents,
                      summary_json, abandoned FROM past_lives WHERE abandoned = 0 ORDER BY user_id, past_life_id""",
        )
        return [dict(row) for row in rows]

    async def set_current_marriage_end(
        self, tx: aiosqlite.Connection, char_id: int, age: int, now: int, reason: str
    ) -> Optional[dict[str, Any]]:
        """Archive then remove the active marriage for divorce or spouse death."""
        return await self.archive_marriage(
            tx, char_id=char_id, end_age=age, end_reason=reason, now=now
        )

    async def estate_heirs(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return living adult children eligible for a continuation choice."""
        rows = await self._all(
            tx,
            """SELECT n.npc_id, n.name, n.gender, n.age, n.health, n.smarts, n.looks,
                      n.country, n.wealth, c.char_id AS parent_char_id
               FROM children AS c JOIN npcs AS n ON n.npc_id = c.npc_id
               WHERE c.char_id = ? AND n.is_alive = 1 AND n.age >= 18
               ORDER BY n.npc_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def read_guild_privacy(self, tx: aiosqlite.Connection, user_ids: Sequence[int]) -> dict[int, bool]:
        """Return opt-out settings for a bounded set of accounts."""
        if not user_ids:
            return {}
        placeholders = ",".join("?" for _ in user_ids)
        rows = await self._all(
            tx,
            f"SELECT user_id, leaderboard_opt_out FROM players WHERE user_id IN ({placeholders})",
            tuple(user_ids),
        )
        return {int(row["user_id"]): bool(row["leaderboard_opt_out"]) for row in rows}

    async def latest_past_life(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return the immutable death archive associated with a character."""
        return await self.past_life(tx, char_id)
