"""Parameterized repository for Stage 7 crime, trial, tax, and prison data."""
from __future__ import annotations

import json
from typing import Any, Optional

import aiosqlite

from ..models import Character


class CrimeRepository:
    """Keep all Stage 7 SQL and transactional row mapping in one repository."""

    def __init__(self, db: Any) -> None:
        self.db = db

    @staticmethod
    async def _one(tx: aiosqlite.Connection, query: str, params: tuple[Any, ...] = ()) -> Any:
        cursor = await tx.execute(query, params)
        return await cursor.fetchone()

    @staticmethod
    async def _all(tx: aiosqlite.Connection, query: str, params: tuple[Any, ...] = ()) -> list[Any]:
        cursor = await tx.execute(query, params)
        return await cursor.fetchall()

    async def load_active(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Load the active life and optimistic version for an action transaction."""
        row = await self._one(
            tx,
            "SELECT char_id, user_id, data_json, version FROM characters "
            "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def load_active_read(self, user_id: int) -> Optional[dict[str, Any]]:
        """Read a user's active character without opening a write transaction."""
        row = await self.db.fetchone(
            "SELECT char_id, user_id, data_json, version FROM characters "
            "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def has_any_life(self, tx: aiosqlite.Connection, user_id: int) -> bool:
        """Check if a user has a historical life but no active character."""
        return await self._one(tx, "SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,)) is not None

    async def has_pending_event(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check for unresolved Stage 3 events before a new criminal decision."""
        return await self._one(tx, "SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1", (char_id,)) is not None

    async def insert_life_log(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        age: int,
        category: str,
        text: str,
        importance: int,
        now: int,
    ) -> None:
        """Append a parameterized message to the shared life journal."""
        await tx.execute(
            """INSERT INTO life_logs(char_id, age, category, text, importance, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (char_id, age, category, text, importance, now),
        )

    async def has_any_life_read(self, user_id: int) -> bool:
        """Read whether a user has a historical character."""
        return await self.db.fetchone("SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,)) is not None

    async def save_character(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
    ) -> None:
        """Persist a changed character snapshot with optimistic concurrency protection."""
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET stats_json = ?, version = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (stats_json, character.version, data_json, character.char_id, expected_version),
        )
        if cursor.rowcount != 1:
            from ..errors import ConcurrentUpdate
            raise ConcurrentUpdate()

    async def initialize_profile(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Create the default criminal profile once for a new or legacy character."""
        await tx.execute("INSERT OR IGNORE INTO crime_profiles(char_id) VALUES (?)", (char_id,))

    async def get_profile(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Any]:
        """Return a profile, initializing it if this is a pre-Stage-7 life."""
        await self.initialize_profile(tx, char_id)
        row = await self._one(tx, "SELECT * FROM crime_profiles WHERE char_id = ?", (char_id,))
        if row is None:
            raise RuntimeError("criminal profile could not be initialized")
        return dict(row)

    async def update_profile(self, tx: aiosqlite.Connection, char_id: int, **fields: Any) -> None:
        """Update a fixed allowlist of criminal-profile columns with bound values."""
        allowed = {
            "dirty_cash", "career_rank", "career_years", "career_level", "last_crime_id",
            "evaded_tax", "gang_protected", "escaped", "juvenile_release_age",
            "last_release_age", "front_business",
        }
        if not fields or set(fields) - allowed:
            raise ValueError("criminal profile update contains no fields or an unsupported field")
        assignments = ", ".join(f"{column} = ?" for column in fields)
        await tx.execute(
            f"UPDATE crime_profiles SET {assignments} WHERE char_id = ?",
            (*fields.values(), char_id),
        )

    async def save_preview(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        crime_id: str,
        age: int,
        nonce: str,
        success_chance: float,
        catch_chance: float,
        loot_min: int,
        loot_max: int,
        salary_snapshot: int,
        created_at: int,
        expires_at: int,
    ) -> None:
        """Replace an unconfirmed risk preview for this character."""
        await tx.execute("DELETE FROM crime_previews WHERE char_id = ?", (char_id,))
        await tx.execute(
            """INSERT INTO crime_previews
                   (char_id, crime_id, age, nonce, success_chance, catch_chance,
                    loot_min, loot_max, salary_snapshot, created_at, expires_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, crime_id, age, nonce, success_chance, catch_chance,
             loot_min, loot_max, salary_snapshot, created_at, expires_at),
        )

    async def get_preview(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        nonce: str,
        now: int,
    ) -> Optional[dict[str, Any]]:
        """Fetch a live preview only for its owner and unexpired nonce."""
        row = await self._one(
            tx,
            "SELECT * FROM crime_previews WHERE char_id = ? AND nonce = ? AND expires_at >= ? LIMIT 1",
            (char_id, nonce, now),
        )
        return dict(row) if row is not None else None

    async def delete_preview(self, tx: aiosqlite.Connection, char_id: int, nonce: str) -> None:
        """Consume a crime preview after confirmation or cancellation."""
        await tx.execute("DELETE FROM crime_previews WHERE char_id = ? AND nonce = ?", (char_id, nonce))

    async def cancel_preview(self, tx: aiosqlite.Connection, char_id: int, nonce: str) -> bool:
        """Remove the exact owner's pending preview and report whether it existed."""
        cursor = await tx.execute("DELETE FROM crime_previews WHERE char_id = ? AND nonce = ?", (char_id, nonce))
        return cursor.rowcount == 1

    async def claim_crime_attempt(self, tx: aiosqlite.Connection, char_id: int, age: int, *, limit: int = 2) -> bool:
        """Reserve a crime attempt using Stage 6 yearly_counters when an NPC anchor exists."""
        row = await self._one(
            tx,
            """SELECT COALESCE(SUM(count), 0) AS count FROM yearly_counters
               WHERE char_id = ? AND age = ? AND action = 'crime_commit'""",
            (char_id, age),
        )
        fallback = await self._one(
            tx,
            "SELECT count FROM crime_yearly_actions WHERE char_id = ? AND age = ? AND action = 'crime_commit'",
            (char_id, age),
        )
        count = int(row["count"] if row is not None else 0) + (int(fallback["count"]) if fallback is not None else 0)
        if count >= limit:
            return False
        anchor = await self._one(
            tx,
            "SELECT npc_id FROM npcs WHERE owner_char_id = ? ORDER BY npc_id LIMIT 1",
            (char_id,),
        )
        if anchor is not None:
            await tx.execute(
                """INSERT INTO yearly_counters(char_id, npc_id, age, action, count)
                   VALUES (?, ?, ?, 'crime_commit', 1)
                   ON CONFLICT(char_id, npc_id, age, action) DO UPDATE SET count = count + 1""",
                (char_id, int(anchor["npc_id"]), age),
            )
        else:
            await self.claim_action(tx, char_id, age, "crime_commit")
        return True

    async def claim_action(self, tx: aiosqlite.Connection, char_id: int, age: int, action: str) -> bool:
        """Reserve one prison action per in-game age."""
        row = await self._one(
            tx,
            "SELECT count FROM crime_yearly_actions WHERE char_id = ? AND age = ? AND action = ?",
            (char_id, age, action),
        )
        if row is not None and int(row["count"]) >= 1:
            return False
        await tx.execute(
            """INSERT INTO crime_yearly_actions(char_id, age, action, count) VALUES (?, ?, ?, 1)
               ON CONFLICT(char_id, age, action) DO UPDATE SET count = count + 1""",
            (char_id, age, action),
        )
        return True

    async def insert_attempt(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        crime_id: str,
        age: int,
        source: str,
        success: bool,
        caught: bool,
        loot: int,
        success_chance: float,
        catch_chance: float,
        case_status: str,
        created_at: int,
    ) -> int:
        """Insert a committed attempt or arrest and return its audit-record key."""
        cursor = await tx.execute(
            """INSERT INTO crime_attempts
                   (char_id, crime_id, age, source, success, caught, loot,
                    success_chance, catch_chance, case_status, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, crime_id, age, source, int(success), int(caught), loot,
             success_chance, catch_chance, case_status, created_at),
        )
        return int(cursor.lastrowid)

    async def create_trial(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        attempt_id: int,
        nonce: str,
        created_at: int,
    ) -> None:
        """Create a persistent one-case trial choice."""
        await tx.execute(
            "INSERT INTO crime_trials(char_id, attempt_id, nonce, created_at) VALUES (?, ?, ?, ?)",
            (char_id, attempt_id, nonce, created_at),
        )

    async def pending_trial(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Load an unresolved trial and its associated crime record."""
        row = await self._one(
            tx,
            """SELECT t.nonce, t.created_at AS trial_created_at, a.*
               FROM crime_trials AS t JOIN crime_attempts AS a ON a.attempt_id = t.attempt_id
               WHERE t.char_id = ? LIMIT 1""",
            (char_id,),
        )
        return dict(row) if row is not None else None

    async def pending_trial_read(self, user_id: int) -> Optional[dict[str, Any]]:
        """Read a pending trial for an active life to recreate its button view."""
        row = await self.db.fetchone(
            """SELECT t.nonce, t.created_at AS trial_created_at, a.*
               FROM crime_trials AS t JOIN crime_attempts AS a ON a.attempt_id = t.attempt_id
               JOIN characters AS c ON c.char_id = t.char_id
               WHERE c.user_id = ? AND c.is_alive = 1 LIMIT 1""",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def has_pending_decision(self, tx: aiosqlite.Connection, char_id: int, now: int) -> bool:
        """Check for an unexpired preview, trial, or tax decision before aging."""
        await tx.execute("DELETE FROM crime_previews WHERE char_id = ? AND expires_at < ?", (char_id, now))
        return await self._one(
            tx,
            """SELECT 1 FROM crime_previews WHERE char_id = ?
               UNION ALL SELECT 1 FROM crime_trials WHERE char_id = ?
               UNION ALL SELECT 1 FROM crime_tax_prompts WHERE char_id = ? LIMIT 1""",
            (char_id, char_id, char_id),
        ) is not None

    async def preview_for_character(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Load a pending preview in the caller's transaction."""
        row = await self._one(tx, "SELECT * FROM crime_previews WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def read_preview(self, user_id: int) -> Optional[dict[str, Any]]:
        """Read a pending crime confirmation for its living owner."""
        row = await self.db.fetchone(
            """SELECT p.* FROM crime_previews AS p JOIN characters AS c ON c.char_id = p.char_id
               WHERE c.user_id = ? AND c.is_alive = 1 LIMIT 1""",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def complete_trial(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        attempt_id: int,
        case_status: str,
        lawyer_tier: str,
        sentence_years: int,
        life_sentence: bool,
        record_sealed: bool,
        fine_paid: int,
        resolved_at: int,
    ) -> None:
        """Store verdict details and consume the persistent trial nonce."""
        await tx.execute(
            """UPDATE crime_attempts SET case_status = ?, lawyer_tier = ?, sentence_years = ?,
                   life_sentence = ?, record_sealed = ?, fine_paid = ?, resolved_at = ?
               WHERE attempt_id = ? AND char_id = ? AND case_status = 'pending'""",
            (case_status, lawyer_tier, sentence_years, int(life_sentence), int(record_sealed),
             fine_paid, resolved_at, attempt_id, char_id),
        )
        await tx.execute("DELETE FROM crime_trials WHERE char_id = ? AND attempt_id = ?", (char_id, attempt_id))

    async def resolve_audit_attempt(
        self,
        tx: aiosqlite.Connection,
        attempt_id: int,
        *,
        sentence_years: int,
        resolved_at: int,
    ) -> None:
        """Fill sentence metadata for a direct tax-audit conviction without a trial row."""
        await tx.execute(
            """UPDATE crime_attempts SET case_status = 'convicted', lawyer_tier = NULL,
                   sentence_years = ?, life_sentence = 0, record_sealed = 0,
                   fine_paid = 0, resolved_at = ? WHERE attempt_id = ? AND source = 'tax_audit'""",
            (max(0, sentence_years), resolved_at, attempt_id),
        )

    async def get_job(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return the active job required for embezzlement and prison dismissal."""
        row = await self._one(tx, "SELECT * FROM jobs WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def fire_job_for_prison(self, tx: aiosqlite.Connection, char_id: int, age: int) -> bool:
        """Close an active job with the Stage 7 'prison' history reason."""
        row = await self._one(tx, "SELECT 1 FROM jobs WHERE char_id = ? LIMIT 1", (char_id,))
        if row is None:
            return False
        await tx.execute(
            """UPDATE career_history SET end_age = ?, end_reason = 'prison'
               WHERE char_id = ? AND end_age IS NULL""",
            (age, char_id),
        )
        await tx.execute("DELETE FROM jobs WHERE char_id = ?", (char_id,))
        return True

    async def relationship_scores(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, int]]:
        """Return connected NPC IDs and scores for sentencing consequences."""
        rows = await self._all(tx, "SELECT npc_id, score FROM relationships WHERE char_id = ?", (char_id,))
        return [{"npc_id": int(row["npc_id"]), "score": int(row["score"])} for row in rows]

    async def set_relationship_score(self, tx: aiosqlite.Connection, char_id: int, npc_id: int, score: int) -> None:
        """Persist one nonnegative relationship score."""
        await tx.execute(
            "UPDATE relationships SET score = ? WHERE char_id = ? AND npc_id = ?",
            (max(0, min(100, score)), char_id, npc_id),
        )

    async def has_marriage(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check for an active marriage without leaking another life's spouse data."""
        return await self._one(tx, "SELECT 1 FROM marriages WHERE char_id = ? LIMIT 1", (char_id,)) is not None

    async def add_cashflow(self, tx: aiosqlite.Connection, char_id: int, age: int, action: str, amount: int, now: int) -> None:
        """Log one positive criminal cash-flow amount in integer cents."""
        await tx.execute(
            "INSERT INTO crime_cashflows(char_id, age, action, amount, created_at) VALUES (?, ?, ?, ?, ?)",
            (char_id, age, action, max(0, amount), now),
        )

    async def cashflow_totals(self, tx: aiosqlite.Connection, char_id: int, age: int) -> dict[str, int]:
        """Sum criminal proceeds and laundering for one in-game age."""
        rows = await self._all(
            tx,
            """SELECT action, COALESCE(SUM(amount), 0) AS total FROM crime_cashflows
               WHERE char_id = ? AND age = ? GROUP BY action""",
            (char_id, age),
        )
        return {str(row["action"]): int(row["total"]) for row in rows}

    async def laundering_total_read(self, char_id: int, age: int) -> int:
        """Read gross laundering already used in the current in-game year."""
        row = await self.db.fetchone(
            "SELECT COALESCE(SUM(gross_amount), 0) AS total FROM crime_laundering WHERE char_id = ? AND age = ?",
            (char_id, age),
        )
        return int(row["total"] if row is not None else 0)

    async def laundering_total(self, tx: aiosqlite.Connection, char_id: int, age: int) -> int:
        """Return gross laundering already used in the current in-game year."""
        row = await self._one(
            tx,
            "SELECT COALESCE(SUM(gross_amount), 0) AS total FROM crime_laundering WHERE char_id = ? AND age = ?",
            (char_id, age),
        )
        return int(row["total"] if row is not None else 0)

    async def add_laundering(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        age: int,
        gross: int,
        fee: int,
        net: int,
        now: int,
    ) -> None:
        """Persist a completed laundering transaction."""
        await tx.execute(
            """INSERT INTO crime_laundering(char_id, age, gross_amount, fee_amount, net_amount, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (char_id, age, gross, fee, net, now),
        )

    async def has_front_business(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check the existing item inventory for the required front-business item."""
        row = await self._one(
            tx,
            """SELECT 1 FROM family_assets WHERE char_id = ? AND kind = 'item'
                 AND item_id IN ('front_business', 'laundromat', 'car_wash', 'nightclub')
                 AND quantity > 0 AND is_liquidated = 0 LIMIT 1""", 
            (char_id,),
        )
        return row is not None

    async def grant_front_business(self, tx: aiosqlite.Connection, char_id: int, age: int, now: int) -> None:
        """Grant one zero-cost front-business item at the Crime Boss career tier."""
        if await self.has_front_business(tx, char_id):
            return
        await tx.execute(
            """INSERT INTO family_assets
                   (char_id, kind, item_id, quantity, purchase_price, current_value, acquired_age, acquired_at)
               VALUES (?, 'item', 'front_business', 1, 0, 0, ?, ?)""",
            (char_id, age, now),
        )
        await self.update_profile(tx, char_id, front_business=1)

    async def save_tax_prompt(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        nonce: str,
        age: int,
        tax_due: int,
        prepaid: bool,
        now: int,
        *,
        paid_amount: int = 0,
    ) -> None:
        """Persist a one-use high-earner tax decision."""
        await tx.execute("DELETE FROM crime_tax_prompts WHERE char_id = ?", (char_id,))
        await tx.execute(
            """INSERT INTO crime_tax_prompts
                   (char_id, nonce, age, tax_due, prepaid, paid_amount, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (char_id, nonce, age, tax_due, int(prepaid), max(0, paid_amount), now),
        )

    async def pending_tax_prompt(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return the unresolved tax-evasion event for one life."""
        row = await self._one(tx, "SELECT * FROM crime_tax_prompts WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def pending_tax_prompt_read(self, user_id: int) -> Optional[dict[str, Any]]:
        """Read an active tax decision so its interactive view can be reopened."""
        row = await self.db.fetchone(
            """SELECT p.* FROM crime_tax_prompts AS p JOIN characters AS c ON c.char_id = p.char_id
               WHERE c.user_id = ? AND c.is_alive = 1 LIMIT 1""",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def consume_tax_prompt(self, tx: aiosqlite.Connection, char_id: int, nonce: str) -> bool:
        """Delete exactly one nonce-matched tax event after its choice is recorded."""
        cursor = await tx.execute("DELETE FROM crime_tax_prompts WHERE char_id = ? AND nonce = ?", (char_id, nonce))
        return cursor.rowcount == 1

    async def record_tax_choice(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        age: int,
        choice: str,
        tax_due: int,
        evaded_amount: int,
        now: int,
    ) -> None:
        """Append one selected tax decision to the audit history."""
        await tx.execute(
            """INSERT INTO crime_tax_choices(char_id, age, choice, tax_due, evaded_amount, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (char_id, age, choice, tax_due, evaded_amount, now),
        )

    async def record_audit(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        age: int,
        chance: float,
        triggered: bool,
        evasion_found: bool,
        back_taxes: int,
        sentence_years: int,
        outcome: str,
        now: int,
    ) -> None:
        """Persist an annual financial audit result."""
        await tx.execute(
            """INSERT INTO crime_audits
                   (char_id, age, audit_chance, triggered, tax_evasion_found,
                    back_taxes, sentence_years, outcome, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, age, chance, int(triggered), int(evasion_found), back_taxes, sentence_years, outcome, now),
        )

    async def active_loans(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return unpaid loans for prison's automatic-payment rule."""
        rows = await self._all(tx, "SELECT * FROM loans WHERE char_id = ? AND status = 'active' ORDER BY loan_id", (char_id,))
        return [dict(row) for row in rows]

    async def pay_loan(self, tx: aiosqlite.Connection, loan_id: int, payment: int) -> None:
        """Apply a full available annual payment to one loan."""
        row = await self._one(tx, "SELECT balance FROM loans WHERE loan_id = ? AND status = 'active'", (loan_id,))
        if row is None:
            return
        balance = int(row["balance"])
        remaining = max(0, balance - min(balance, max(0, payment)))
        await tx.execute(
            "UPDATE loans SET balance = ?, status = ? WHERE loan_id = ?",
            (remaining, "paid" if remaining == 0 else "active", loan_id),
        )

    async def miss_loan_payment(self, tx: aiosqlite.Connection, loan_id: int) -> None:
        """Increment missed prison-time loan payments without changing the balance."""
        await tx.execute("UPDATE loans SET missed_payments = missed_payments + 1 WHERE loan_id = ?", (loan_id,))

    async def crime_history_in_transaction(
        self, tx: aiosqlite.Connection, char_id: int, limit: int = 10
    ) -> list[dict[str, Any]]:
        """Return recent attempts using the caller's transaction connection."""
        rows = await self._all(
            tx,
            "SELECT * FROM crime_attempts WHERE char_id = ? ORDER BY age DESC, attempt_id DESC LIMIT ?",
            (char_id, max(1, min(25, limit))),
        )
        return [dict(row) for row in rows]

    async def crime_history(self, char_id: int, limit: int = 10) -> list[dict[str, Any]]:
        """Return recent attempts and court outcomes for a crime-record embed."""
        rows = await self.db.fetchall(
            """SELECT * FROM crime_attempts WHERE char_id = ? ORDER BY age DESC, attempt_id DESC LIMIT ?""",
            (char_id, max(1, min(25, limit))),
        )
        return [dict(row) for row in rows]

    async def read_profile(self, char_id: int) -> Optional[dict[str, Any]]:
        """Read a previously initialized criminal profile."""
        row = await self.db.fetchone("SELECT * FROM crime_profiles WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def get_hiring_context(self, tx: aiosqlite.Connection, char_id: int) -> Optional[dict[str, Any]]:
        """Return release age and record metadata for a job-application calculation."""
        row = await self._one(tx, "SELECT last_release_age FROM crime_profiles WHERE char_id = ? LIMIT 1", (char_id,))
        return dict(row) if row is not None else None

    async def other_pending_prompt(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check trial and tax decisions that cannot overlap with a new age event."""
        return await self._one(
            tx,
            """SELECT 1 FROM crime_trials WHERE char_id = ?
               UNION ALL SELECT 1 FROM crime_tax_prompts WHERE char_id = ? LIMIT 1""",
            (char_id, char_id),
        ) is not None

    async def get_status_data(self, tx: aiosqlite.Connection, char_id: int) -> dict[str, Any]:
        """Load criminal profile and pending prompts for a combined record/status view."""
        profile = await self.get_profile(tx, char_id)
        trial = await self.pending_trial(tx, char_id)
        tax = await self.pending_tax_prompt(tx, char_id)
        return {"profile": profile, "trial": trial, "tax": tax}
