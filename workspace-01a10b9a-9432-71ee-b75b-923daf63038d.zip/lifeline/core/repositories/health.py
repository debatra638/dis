"""Repository for disease progression and medical visit records."""
from __future__ import annotations

import json
from typing import Any, Optional

import aiosqlite


class HealthRepository:
    """Keep all health-condition SQL inside the repository layer."""

    def __init__(self, db: Any) -> None:
        self.db = db

    @staticmethod
    async def _one(
        tx: aiosqlite.Connection,
        sql: str,
        params: tuple[Any, ...] = (),
    ) -> Any:
        cursor = await tx.execute(sql, params)
        return await cursor.fetchone()

    @staticmethod
    async def _all(
        tx: aiosqlite.Connection,
        sql: str,
        params: tuple[Any, ...] = (),
    ) -> list[Any]:
        cursor = await tx.execute(sql, params)
        return await cursor.fetchall()

    async def conditions(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        *,
        active_only: bool = False,
    ) -> list[dict[str, Any]]:
        """Return condition rows in deterministic severity order."""
        sql = "SELECT * FROM health_conditions WHERE char_id = ?"
        if active_only:
            sql += " AND is_active = 1 AND status IN ('active', 'chronic')"
        sql += " ORDER BY severity DESC, disease_id"
        return [dict(row) for row in await self._all(tx, sql, (char_id,))]

    async def condition(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        disease_id: str,
    ) -> Optional[dict[str, Any]]:
        """Return one historical or active condition for a life."""
        row = await self._one(
            tx,
            "SELECT * FROM health_conditions WHERE char_id = ? AND disease_id = ?",
            (char_id, disease_id),
        )
        return dict(row) if row is not None else None

    async def add_condition(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        disease_id: str,
        severity: int,
        age: int,
        duration_years: int,
        chronic: bool,
        now: int,
    ) -> bool:
        """Insert one newly-onset condition; existing lifetime history is not farmable."""
        status = "chronic" if chronic else "active"
        cursor = await tx.execute(
            """INSERT OR IGNORE INTO health_conditions
                   (char_id, disease_id, severity, diagnosed, onset_age, years_untreated,
                    status, is_active, created_at, updated_at, duration_years,
                    last_treated_age, last_progressed_age, progression_count)
               VALUES (?, ?, ?, 0, ?, 0, ?, 1, ?, ?, ?, NULL, ?, 0)""",
            (char_id, disease_id, severity, age, status, now, now, duration_years, age),
        )
        return cursor.rowcount == 1

    async def update_progression(
        self,
        tx: aiosqlite.Connection,
        *,
        condition_id: int,
        severity: int,
        years_untreated: int,
        status: str,
        is_active: bool,
        last_progressed_age: Optional[int],
        progression_count: int,
        now: int,
    ) -> None:
        """Persist annual untreated duration, condition status, and progression."""
        await tx.execute(
            """UPDATE health_conditions SET severity = ?, years_untreated = ?, status = ?,
                   is_active = ?, last_progressed_age = ?, progression_count = ?, updated_at = ?
               WHERE condition_id = ?""",
            (severity, years_untreated, status, int(is_active), last_progressed_age,
             progression_count, now, condition_id),
        )

    async def diagnose_and_treat(
        self,
        tx: aiosqlite.Connection,
        *,
        condition_id: int,
        severity: int,
        status: str,
        is_active: bool,
        age: int,
        now: int,
    ) -> None:
        """Record a clinician's diagnosis and a one-year treatment response."""
        await tx.execute(
            """UPDATE health_conditions SET diagnosed = 1, severity = ?, years_untreated = 0,
                   status = ?, is_active = ?, last_treated_age = ?, updated_at = ?
               WHERE condition_id = ?""",
            (max(1, min(5, int(severity))), status, int(is_active), age, now, condition_id),
        )

    async def mark_diagnosed(
        self,
        tx: aiosqlite.Connection,
        *,
        condition_id: int,
        age: int,
        now: int,
    ) -> None:
        """Set the clinician-confirmed diagnosis timestamp without changing severity."""
        await tx.execute(
            """UPDATE health_conditions SET diagnosed = 1, last_treated_age = ?,
                   years_untreated = 0, updated_at = ? WHERE condition_id = ?""",
            (age, now, condition_id),
        )

    async def visit_used(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        age: int,
        visit_type: str,
    ) -> bool:
        """Check the once-per-in-game-year limit for a clinical visit type."""
        return await self._one(
            tx,
            "SELECT 1 FROM health_visits WHERE char_id = ? AND age = ? AND visit_type = ? LIMIT 1",
            (char_id, age, visit_type),
        ) is not None

    async def record_visit(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        age: int,
        visit_type: str,
        disease_id: Optional[str],
        cost_cents: int,
        outcome: dict[str, Any],
        now: int,
    ) -> int:
        """Insert an immutable, parameterized medical or activity ledger entry."""
        cursor = await tx.execute(
            """INSERT INTO health_visits
                   (char_id, age, visit_type, disease_id, cost_cents, outcome_json, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (char_id, age, visit_type, disease_id, cost_cents,
             json.dumps(outcome, sort_keys=True, separators=(",", ":"), allow_nan=False), now),
        )
        return int(cursor.lastrowid)

    async def recent_visits(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        *,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Return the most recent medical-service ledger entries."""
        rows = await self._all(
            tx,
            "SELECT * FROM health_visits WHERE char_id = ? ORDER BY visit_id DESC LIMIT ?",
            (char_id, limit),
        )
        return [dict(row) for row in rows]
