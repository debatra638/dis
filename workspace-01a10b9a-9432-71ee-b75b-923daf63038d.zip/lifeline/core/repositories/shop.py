"""Parameterized repository for Stage 8 shop, inventory, loans, and trades."""
from __future__ import annotations

import json
from typing import Any, Optional

import aiosqlite

from ..models import Character


class ShopRepository:
    """Own Stage 8 SQL while accepting the caller's ``BEGIN IMMEDIATE`` connection."""

    def __init__(self, db: Any) -> None:
        self.db = db

    @staticmethod
    async def _one(tx: aiosqlite.Connection, query: str, params: tuple[Any, ...] = ()) -> Any:
        cursor = await tx.execute(query, params)
        return await cursor.fetchone()

    @staticmethod
    async def _all(tx: aiosqlite.Connection, query: str, params: tuple[Any, ...] = ()) -> list[Any]:
        cursor = await tx.execute(query, params)
        return await cursor.fetchall()

    async def load_active(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Load the active character snapshot and its database version."""
        row = await self._one(
            tx,
            "SELECT char_id, user_id, data_json, version FROM characters "
            "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        return dict(row) if row is not None else None

    async def load_active_many(self, tx: aiosqlite.Connection, user_ids: tuple[int, ...]) -> dict[int, dict[str, Any]]:
        """Load active character snapshots for a stable set of user IDs."""
        if not user_ids:
            return {}
        placeholders = ",".join("?" for _ in user_ids)
        rows = await self._all(
            tx,
            f"SELECT char_id, user_id, data_json, version FROM characters "
            f"WHERE user_id IN ({placeholders}) AND is_alive = 1 ORDER BY user_id",
            user_ids,
        )
        return {int(row["user_id"]): dict(row) for row in rows}

    async def has_any_life(self, tx: aiosqlite.Connection, user_id: int) -> bool:
        """Distinguish a completed life from a user who has never started."""
        return await self._one(tx, "SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,)) is not None

    async def has_pending_event(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check for an unresolved Stage 3 choice before a transactional action."""
        return await self._one(tx, "SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1", (char_id,)) is not None

    async def save_character(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
    ) -> None:
        """Save JSON/stats and reject a stale character snapshot."""
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET stats_json = ?, version = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (stats_json, character.version, data_json, character.char_id, expected_version),
        )
        if cursor.rowcount != 1:
            from ..errors import ConcurrentUpdate
            raise ConcurrentUpdate()

    async def save_shop_quote(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        nonce: str,
        item_id: str,
        quantity: int,
        total_price: int,
        balance_cents: int,
        character_version: int,
        created_at: int,
        expires_at: int,
    ) -> None:
        """Replace a character's single short-lived, owner-bound shop quote."""
        await tx.execute("DELETE FROM shop_quotes WHERE char_id = ?", (char_id,))
        await tx.execute(
            """INSERT INTO shop_quotes
                   (char_id, nonce, item_id, quantity, total_price, balance_cents,
                    character_version, created_at, expires_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (char_id, nonce, item_id, quantity, total_price, balance_cents,
             character_version, created_at, expires_at),
        )

    async def load_shop_quote(
        self,
        tx: aiosqlite.Connection,
        char_id: int,
        nonce: str,
        now: int,
    ) -> Optional[dict[str, Any]]:
        """Fetch the exact unexpired price/version quote associated with a nonce."""
        row = await self._one(
            tx,
            "SELECT * FROM shop_quotes WHERE char_id = ? AND nonce = ? AND expires_at >= ? LIMIT 1",
            (char_id, nonce, now),
        )
        return dict(row) if row is not None else None

    async def consume_shop_quote(self, tx: aiosqlite.Connection, char_id: int, nonce: str) -> None:
        """Consume a confirmed quote so it cannot be replayed."""
        await tx.execute("DELETE FROM shop_quotes WHERE char_id = ? AND nonce = ?", (char_id, nonce))

    async def list_items(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return active item assets with an authoritative collateral flag."""
        rows = await self._all(
            tx,
            """SELECT a.*,
                      EXISTS(SELECT 1 FROM loans AS l
                             WHERE l.collateral_item_uid = a.asset_id
                               AND l.status = 'active' AND l.balance > 0) AS collateralized
               FROM family_assets AS a
               WHERE a.char_id = ? AND a.kind = 'item' AND a.quantity > 0 AND a.is_liquidated = 0
               ORDER BY a.item_id COLLATE NOCASE, a.asset_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def load_item(self, tx: aiosqlite.Connection, asset_id: int) -> Optional[dict[str, Any]]:
        """Load one item asset and whether a live loan encumbers it."""
        row = await self._one(
            tx,
            """SELECT a.*,
                      EXISTS(SELECT 1 FROM loans AS l
                             WHERE l.collateral_item_uid = a.asset_id
                               AND l.status = 'active' AND l.balance > 0) AS collateralized
               FROM family_assets AS a
               WHERE a.asset_id = ? AND a.kind = 'item' AND a.quantity > 0 AND a.is_liquidated = 0
               LIMIT 1""",
            (asset_id,),
        )
        return dict(row) if row is not None else None

    async def count_item_quantity(self, tx: aiosqlite.Connection, char_id: int, item_id: str) -> int:
        """Sum all live stacks of an item owned by one character."""
        row = await self._one(
            tx,
            """SELECT COALESCE(SUM(quantity), 0) AS quantity FROM family_assets
               WHERE char_id = ? AND kind = 'item' AND item_id = ?
                 AND quantity > 0 AND is_liquidated = 0""",
            (char_id, item_id),
        )
        return int(row["quantity"] if row is not None else 0)

    async def insert_item(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        item_id: str,
        quantity: int,
        purchase_price: int,
        current_value: int,
        age: int,
        now: int,
    ) -> int:
        """Persist a purchased or event-awarded item as a family asset."""
        cursor = await tx.execute(
            """INSERT INTO family_assets
                   (char_id, kind, item_id, quantity, purchase_price, current_value,
                    acquired_age, acquired_at, is_liquidated, is_locked)
               VALUES (?, 'item', ?, ?, ?, ?, ?, ?, 0, 0)""",
            (char_id, item_id, quantity, purchase_price, current_value, age, now),
        )
        return int(cursor.lastrowid)

    async def set_item_value(self, tx: aiosqlite.Connection, asset_id: int, value: int) -> None:
        """Update an item's aggregate current market value in cents."""
        await tx.execute(
            "UPDATE family_assets SET current_value = ? WHERE asset_id = ? AND kind = 'item'",
            (max(0, int(value)), asset_id),
        )

    async def reduce_item(
        self,
        tx: aiosqlite.Connection,
        *,
        asset_id: int,
        owner_char_id: int,
        quantity: int,
    ) -> Optional[dict[str, int]]:
        """Remove part of an unlocked item lot and return its proportional cost/value."""
        row = await self._one(
            tx,
            """SELECT quantity, purchase_price, current_value FROM family_assets
               WHERE asset_id = ? AND char_id = ? AND kind = 'item' AND is_locked = 0
                 AND quantity > 0 AND is_liquidated = 0 LIMIT 1""",
            (asset_id, owner_char_id),
        )
        if row is None:
            return None
        old_quantity = int(row["quantity"])
        selected = int(quantity)
        if selected <= 0 or selected > old_quantity:
            return None
        old_cost = int(row["purchase_price"])
        old_value = int(row["current_value"])
        if selected == old_quantity:
            part_cost, part_value = old_cost, old_value
            await tx.execute(
                """UPDATE family_assets SET quantity = 0, purchase_price = 0,
                       current_value = 0, is_liquidated = 1 WHERE asset_id = ?""",
                (asset_id,),
            )
        else:
            part_cost = old_cost * selected // old_quantity
            part_value = old_value * selected // old_quantity
            await tx.execute(
                """UPDATE family_assets SET quantity = ?, purchase_price = ?, current_value = ?
                   WHERE asset_id = ?""",
                (old_quantity - selected, old_cost - part_cost, old_value - part_value, asset_id),
            )
        return {"purchase_price": part_cost, "current_value": part_value, "quantity": selected}

    async def begin_trade_item_transfers(self, tx: aiosqlite.Connection) -> None:
        """Start a savepoint so a conditional item-transfer failure cannot partially commit."""
        await tx.execute("SAVEPOINT shop_trade_item_transfers")

    async def rollback_trade_item_transfers(self, tx: aiosqlite.Connection) -> None:
        """Undo only trade asset mutations before marking an otherwise valid offer failed."""
        await tx.execute("ROLLBACK TO SAVEPOINT shop_trade_item_transfers")
        await tx.execute("RELEASE SAVEPOINT shop_trade_item_transfers")

    async def finish_trade_item_transfers(self, tx: aiosqlite.Connection) -> None:
        """Release the item-transfer savepoint after every conditional update succeeds."""
        await tx.execute("RELEASE SAVEPOINT shop_trade_item_transfers")

    async def transfer_item(
        self,
        tx: aiosqlite.Connection,
        *,
        asset_id: int,
        from_char_id: int,
        to_char_id: int,
        quantity: int,
        to_age: int,
        now: int,
    ) -> Optional[int]:
        """Transfer an unlocked, unencumbered item lot, splitting it if needed."""
        row = await self._one(
            tx,
            """SELECT a.* FROM family_assets AS a
               WHERE a.asset_id = ? AND a.char_id = ? AND a.kind = 'item'
                 AND a.quantity > 0 AND a.is_liquidated = 0 AND a.is_locked = 0
                 AND NOT EXISTS(SELECT 1 FROM loans AS l
                                WHERE l.collateral_item_uid = a.asset_id
                                  AND l.status = 'active' AND l.balance > 0)
               LIMIT 1""",
            (asset_id, from_char_id),
        )
        if row is None:
            return None
        original_quantity = int(row["quantity"])
        amount = int(quantity)
        if amount <= 0 or amount > original_quantity:
            return None
        old_cost = int(row["purchase_price"])
        old_value = int(row["current_value"])
        if amount == original_quantity:
            await tx.execute(
                """UPDATE family_assets SET char_id = ?, acquired_age = ?, acquired_at = ?, is_locked = 0
                   WHERE asset_id = ? AND char_id = ? AND is_locked = 0""",
                (to_char_id, to_age, now, asset_id, from_char_id),
            )
            return asset_id
        part_cost = old_cost * amount // original_quantity
        part_value = old_value * amount // original_quantity
        await tx.execute(
            """UPDATE family_assets SET quantity = ?, purchase_price = ?, current_value = ?
               WHERE asset_id = ? AND char_id = ? AND is_locked = 0""",
            (original_quantity - amount, old_cost - part_cost, old_value - part_value, asset_id, from_char_id),
        )
        return await self.insert_item(
            tx,
            char_id=to_char_id,
            item_id=str(row["item_id"]),
            quantity=amount,
            purchase_price=part_cost,
            current_value=part_value,
            age=to_age,
            now=now,
        )

    async def has_used_item(self, tx: aiosqlite.Connection, asset_id: int, age: int) -> bool:
        """Check whether a non-consumable item was used during this in-game year."""
        return await self._one(
            tx, "SELECT 1 FROM inventory_uses WHERE asset_id = ? AND age = ? LIMIT 1", (asset_id, age)
        ) is not None

    async def record_item_use(self, tx: aiosqlite.Connection, asset_id: int, age: int, now: int) -> None:
        """Record the one permitted annual use of a reusable item."""
        await tx.execute(
            "INSERT INTO inventory_uses(asset_id, age, used_at) VALUES (?, ?, ?)",
            (asset_id, age, now),
        )

    async def lock_items(self, tx: aiosqlite.Connection, char_id: int, asset_ids: tuple[int, ...]) -> bool:
        """Lock every selected offered item iff all are still owned and available."""
        for asset_id in asset_ids:
            cursor = await tx.execute(
                """UPDATE family_assets SET is_locked = 1
                   WHERE asset_id = ? AND char_id = ? AND kind = 'item' AND is_locked = 0
                     AND quantity > 0 AND is_liquidated = 0""",
                (asset_id, char_id),
            )
            if cursor.rowcount != 1:
                return False
        return True

    async def active_loans(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return live loans in deterministic payment order."""
        rows = await self._all(
            tx,
            "SELECT * FROM loans WHERE char_id = ? AND status = 'active' ORDER BY loan_id",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def has_defaulted_or_delinquent_loan(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check the conservative financing gate for a default or three missed payments."""
        return await self._one(
            tx,
            """SELECT 1 FROM loans WHERE char_id = ?
               AND (status = 'defaulted' OR (status = 'active' AND (missed_payments >= 3 OR consecutive_misses >= 3))) LIMIT 1""",
            (char_id,),
        ) is not None

    async def create_loan(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        loan_type: str,
        principal: int,
        annual_payment: int,
        term_years: int,
        collateral_item_uid: int,
        annual_rate: float,
        origination_age: int,
    ) -> int:
        """Create a fixed-rate secured mortgage or auto loan for a purchased asset."""
        cursor = await tx.execute(
            """INSERT INTO loans
                   (char_id, loan_type, balance, annual_payment, missed_payments, status,
                    principal, annual_rate, term_years, years_remaining, collateral_item_uid,
                    origination_age)
               VALUES (?, ?, ?, ?, 0, 'active', ?, ?, ?, ?, ?, ?)""",
            (char_id, loan_type, principal, annual_payment, principal, annual_rate,
             term_years, term_years, collateral_item_uid, origination_age),
        )
        return int(cursor.lastrowid)

    async def pay_loan(self, tx: aiosqlite.Connection, loan_id: int, payment: int) -> None:
        """Apply an annual loan payment and close a fully settled loan."""
        row = await self._one(tx, "SELECT balance, years_remaining FROM loans WHERE loan_id = ? AND status = 'active'", (loan_id,))
        if row is None:
            return
        balance = int(row["balance"])
        amount = min(balance, max(0, int(payment)))
        remaining = balance - amount
        years = max(0, int(row["years_remaining"]) - 1)
        await tx.execute(
            """UPDATE loans SET balance = ?, status = ?, years_remaining = ?, missed_payments = 0
               WHERE loan_id = ? AND status = 'active'""",
            (remaining, "paid" if remaining == 0 else "active", years, loan_id),
        )

    async def miss_loan_payment(self, tx: aiosqlite.Connection, loan_id: int) -> None:
        """Record a missed annual payment without making character balances negative."""
        await tx.execute("UPDATE loans SET missed_payments = missed_payments + 1 WHERE loan_id = ? AND status = 'active'", (loan_id,))

    async def insert_player(self, tx: aiosqlite.Connection, user_id: int, created_at: int) -> None:
        """Persist a Discord account's original creation time once."""
        await tx.execute(
            "INSERT OR IGNORE INTO players(user_id, created_at) VALUES (?, ?)",
            (user_id, created_at),
        )

    async def load_player(self, tx: aiosqlite.Connection, user_id: int) -> Optional[dict[str, Any]]:
        """Load a registered player and trade-ban flag."""
        row = await self._one(tx, "SELECT * FROM players WHERE user_id = ? LIMIT 1", (user_id,))
        return dict(row) if row is not None else None

    async def trade_daily_count(self, tx: aiosqlite.Connection, user_id: int, day_key: str) -> int:
        """Read this player's trade offers created on a UTC calendar day."""
        row = await self._one(
            tx, "SELECT trades FROM trade_daily_usage WHERE user_id = ? AND day_key = ?",
            (user_id, day_key),
        )
        return int(row["trades"]) if row is not None else 0

    async def increment_trade_daily(self, tx: aiosqlite.Connection, user_id: int, day_key: str) -> None:
        """Consume one daily trade allowance, guarded by the five-trade limit."""
        cursor = await tx.execute(
            """INSERT INTO trade_daily_usage(user_id, day_key, trades) VALUES (?, ?, 1)
               ON CONFLICT(user_id, day_key) DO UPDATE SET trades = trades + 1
               WHERE trades < 5""",
            (user_id, day_key),
        )
        if cursor.rowcount != 1:
            raise ValueError("daily trade limit reached")

    async def has_pending_outgoing(self, tx: aiosqlite.Connection, user_id: int) -> bool:
        """Check for one pending outgoing proposal by this player."""
        return await self._one(
            tx, "SELECT 1 FROM trades WHERE from_user_id = ? AND status = 'pending' LIMIT 1", (user_id,)
        ) is not None

    async def create_trade(
        self,
        tx: aiosqlite.Connection,
        *,
        from_user_id: int,
        from_char_id: int,
        to_user_id: int,
        to_char_id: int,
        offer_cash: int,
        request_cash: int,
        now: int,
        expires_at: int,
        nonce: str,
        imbalance_flag: bool,
        imbalance_receiver_id: Optional[int],
    ) -> int:
        """Insert an auditable trade proposal."""
        cursor = await tx.execute(
            """INSERT INTO trades
                   (from_user_id, from_char_id, to_user_id, to_char_id, offer_cash, request_cash,
                    status, created_at, expires_at, nonce, imbalance_flag, imbalance_receiver_id)
               VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?)""",
            (from_user_id, from_char_id, to_user_id, to_char_id, offer_cash, request_cash,
             now, expires_at, nonce, int(imbalance_flag), imbalance_receiver_id),
        )
        return int(cursor.lastrowid)

    async def add_trade_item(
        self,
        tx: aiosqlite.Connection,
        *,
        trade_id: int,
        side: str,
        item_uid: int,
        item_id: str,
        quantity: int,
        value_snapshot: int,
    ) -> None:
        """Persist a versioned item line in the offer or request."""
        await tx.execute(
            """INSERT INTO trade_items(trade_id, side, item_uid, item_id, quantity, value_snapshot)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (trade_id, side, item_uid, item_id, quantity, value_snapshot),
        )

    async def load_trade(self, tx: aiosqlite.Connection, trade_id: int) -> Optional[dict[str, Any]]:
        """Load one trade status, nonce, owners, and cash terms."""
        row = await self._one(tx, "SELECT * FROM trades WHERE trade_id = ? LIMIT 1", (trade_id,))
        return dict(row) if row is not None else None

    async def trade_users_read(self, trade_id: int) -> Optional[tuple[int, int]]:
        """Read the two lock keys needed before taking a trade-resolution lock."""
        row = await self.db.fetchone(
            "SELECT from_user_id, to_user_id FROM trades WHERE trade_id = ? LIMIT 1", (trade_id,)
        )
        return (int(row["from_user_id"]), int(row["to_user_id"])) if row is not None else None

    async def load_trade_items(self, tx: aiosqlite.Connection, trade_id: int) -> list[dict[str, Any]]:
        """Load every originally requested or offered line, including stale references."""
        rows = await self._all(
            tx, "SELECT * FROM trade_items WHERE trade_id = ? ORDER BY side, trade_item_id", (trade_id,)
        )
        return [dict(row) for row in rows]

    async def set_trade_status(
        self,
        tx: aiosqlite.Connection,
        trade_id: int,
        *,
        status: str,
        resolved_at: int,
        outcome_message: str,
    ) -> None:
        """Set one trade's terminal status inside the current transaction."""
        await tx.execute(
            """UPDATE trades SET status = ?, resolved_at = ?, outcome_message = ?
               WHERE trade_id = ? AND status = 'pending'""",
            (status, resolved_at, outcome_message, trade_id),
        )

    async def unlock_trade_items(self, tx: aiosqlite.Connection, trade_id: int) -> None:
        """Unlock all extant item lots offered by a trade after its terminal result."""
        await tx.execute(
            """UPDATE family_assets SET is_locked = 0
               WHERE is_locked = 1 AND asset_id IN (
                   SELECT item_uid FROM trade_items WHERE trade_id = ? AND side = 'offer'
               )""",
            (trade_id,),
        )

    async def expired_trade_ids(self, now: int) -> list[dict[str, int]]:
        """Read pending trades whose ten-minute deadline has passed."""
        rows = await self.db.fetchall(
            "SELECT trade_id, from_user_id, to_user_id FROM trades WHERE status = 'pending' AND expires_at <= ? ORDER BY trade_id",
            (now,),
        )
        return [dict(row) for row in rows]

    async def trade_history(self, tx: aiosqlite.Connection, user_id: int, limit: int = 20) -> list[dict[str, Any]]:
        """List a player's recent outgoing and incoming trades."""
        rows = await self._all(
            tx,
            """SELECT trade_id, from_user_id, to_user_id, offer_cash, request_cash, status,
                      created_at, expires_at, resolved_at, outcome_message, imbalance_flag
               FROM trades WHERE from_user_id = ? OR to_user_id = ?
               ORDER BY created_at DESC, trade_id DESC LIMIT ?""",
            (user_id, user_id, max(1, min(50, int(limit)))),
        )
        return [dict(row) for row in rows]

    async def insert_audit(
        self,
        tx: aiosqlite.Connection,
        *,
        now: int,
        user_id: Optional[int],
        char_id: Optional[int],
        action: str,
        amount: Optional[int],
        details: dict[str, Any],
    ) -> None:
        """Write a structured financial or anti-exploit audit record."""
        await tx.execute(
            """INSERT INTO audit_log(ts, user_id, char_id, action, amount, details_json)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (now, user_id, char_id, action, amount,
             json.dumps(details, sort_keys=True, separators=(",", ":"), allow_nan=False)),
        )

    async def create_loan_for_item(
        self,
        tx: aiosqlite.Connection,
        *,
        char_id: int,
        loan_type: str,
        principal: int,
        annual_payment: int,
        term_years: int,
        asset_id: int,
        annual_rate: float,
        origination_age: int,
    ) -> int:
        """Insert a fixed-rate secured loan for an already-created asset."""
        return await self.create_loan(
            tx, char_id=char_id, loan_type=loan_type, principal=principal,
            annual_payment=annual_payment, term_years=term_years,
            collateral_item_uid=asset_id, annual_rate=annual_rate,
            origination_age=origination_age,
        )

    async def has_front_business(self, tx: aiosqlite.Connection, char_id: int) -> bool:
        """Check new business assets and the legacy Stage 7 crime-career front."""
        return await self._one(
            tx,
            """SELECT 1 FROM family_assets WHERE char_id = ? AND kind = 'item'
                 AND item_id IN ('front_business', 'laundromat', 'car_wash', 'nightclub')
                 AND quantity > 0 AND is_liquidated = 0 LIMIT 1""",
            (char_id,),
        ) is not None

    async def set_front_business_flag(self, tx: aiosqlite.Connection, char_id: int, enabled: bool) -> None:
        """Keep Stage 7 laundering access synchronized with owned front businesses."""
        await tx.execute("UPDATE crime_profiles SET front_business = ? WHERE char_id = ?", (int(enabled), char_id))

    async def list_housing_assets(self, tx: aiosqlite.Connection, char_id: int) -> list[dict[str, Any]]:
        """Return active housing lots for primary-home reconciliation."""
        rows = await self._all(
            tx,
            """SELECT * FROM family_assets WHERE char_id = ? AND kind = 'item'
                 AND item_id IN ('trailer', 'starter_home', 'suburban_house', 'townhouse',
                                 'luxury_villa', 'mansion', 'private_island')
                 AND quantity > 0 AND is_liquidated = 0
               ORDER BY current_value DESC, asset_id""",
            (char_id,),
        )
        return [dict(row) for row in rows]

    async def due_pending_trade(self, tx: aiosqlite.Connection, trade_id: int, now: int) -> Optional[dict[str, Any]]:
        """Recheck one candidate expiry while holding both player locks."""
        row = await self._one(
            tx,
            "SELECT * FROM trades WHERE trade_id = ? AND status = 'pending' AND expires_at <= ? LIMIT 1",
            (trade_id, now),
        )
        return dict(row) if row is not None else None
