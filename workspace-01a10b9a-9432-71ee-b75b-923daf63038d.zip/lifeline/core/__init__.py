"""Core game and infrastructure components for LIFELINE."""
