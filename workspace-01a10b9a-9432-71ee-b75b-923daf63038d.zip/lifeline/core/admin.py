"""Transactional owner-only game administration and auditable catalog reloads."""
from __future__ import annotations

import time
from dataclasses import replace
from typing import Any, Callable, Optional

from .data_loader import DataLoader
from .errors import CharacterNotFound, ValidationError
from .life_engine import LifeEngine, roll_birth_attributes
from .money import MAX_CENTS, validate_cents
from .models import Character, Gender, Stats
from .repositories.admin import AdminRepository


class AdminService:
    """Perform bounded admin mutations with one audit row per completed action."""

    def __init__(
        self,
        db: Any,
        life_engine: LifeEngine,
        investing_service: Any,
        data_loader: DataLoader,
        *,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.db = db
        self.life_engine = life_engine
        self.investing_service = investing_service
        self.data_loader = data_loader
        self.clock = clock
        self.repository = AdminRepository(db)

    @staticmethod
    def _user_id(user_id: int) -> int:
        """Validate a Discord snowflake supplied by an owner command."""
        if isinstance(user_id, bool) or not isinstance(user_id, int) or user_id <= 0:
            raise ValidationError("Choose a valid Discord account.")
        return user_id

    async def give_money(self, admin_id: int, target_user_id: int, amount_cents: int) -> Character:
        """Credit integer cents to an active character without exceeding currency bounds."""
        admin_id = self._user_id(admin_id)
        target_user_id = self._user_id(target_user_id)
        amount = validate_cents(amount_cents)
        if amount <= 0:
            raise ValidationError("Money grants must be at least one cent.")
        async with self.life_engine.locks.hold(target_user_id):
            async with self.db.transaction() as tx:
                row = await self.repository.active_character(tx, target_user_id)
                if row is None:
                    raise CharacterNotFound("The target has no active life to receive money.")
                character = Character.from_dict(__import__("json").loads(row["data_json"]))
                character.char_id = int(row["char_id"])
                character.user_id = target_user_id
                if character.cash > MAX_CENTS - amount:
                    raise ValidationError("That grant would exceed the supported money limit.")
                updated = replace(character, cash=character.cash + amount, version=int(row["version"]) + 1)
                await self.repository.save_character(tx, updated, int(row["version"]))
                await self.repository.insert_audit(
                    tx, admin_id=admin_id, target_user_id=target_user_id,
                    char_id=updated.char_id, action="give_money", amount=amount,
                    details={"balance":"cash_cents","granted_cents":amount}, now=int(self.clock()),
                )
                return updated

    async def set_stat(self, admin_id: int, target_user_id: int, stat: str, value: int) -> Character:
        """Set a whitelisted stat, clamping it with the shared ``Stats`` rules."""
        admin_id = self._user_id(admin_id)
        target_user_id = self._user_id(target_user_id)
        allowed = {"health", "happiness", "smarts", "looks", "fitness", "karma", "stress", "addiction", "fame"}
        if stat not in allowed:
            raise ValidationError("Choose a supported character stat.")
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValidationError("The stat value must be an integer.")
        async with self.life_engine.locks.hold(target_user_id):
            async with self.db.transaction() as tx:
                row = await self.repository.active_character(tx, target_user_id)
                if row is None:
                    raise CharacterNotFound("The target has no active life to update.")
                character = Character.from_dict(__import__("json").loads(row["data_json"]))
                character.char_id = int(row["char_id"])
                character.user_id = target_user_id
                raw_stats = character.stats.to_dict()
                before = int(getattr(character.stats, stat))
                raw_stats[stat] = int(value)
                updated_stats = Stats.from_dict(raw_stats).clamp_all()
                after = int(getattr(updated_stats, stat))
                updated = replace(character, stats=updated_stats, version=int(row["version"]) + 1)
                await self.repository.save_character(tx, updated, int(row["version"]))
                await self.repository.insert_audit(
                    tx, admin_id=admin_id, target_user_id=target_user_id,
                    char_id=updated.char_id, action="set_stat", amount=after,
                    details={"stat":stat,"requested_value":int(value),"previous_value":before,"value":after},
                    now=int(self.clock()),
                )
                return updated

    async def kill(self, admin_id: int, target_user_id: int) -> dict[str, Any]:
        """End and archive a target's active life within the same transaction as the audit."""
        admin_id = self._user_id(admin_id)
        target_user_id = self._user_id(target_user_id)
        now = int(self.clock())
        async with self.life_engine.locks.hold(target_user_id):
            async with self.db.transaction() as tx:
                row = await self.repository.active_character(tx, target_user_id)
                if row is None:
                    raise CharacterNotFound("The target has no active life to end.")
                character = Character.from_dict(__import__("json").loads(row["data_json"]))
                character.char_id = int(row["char_id"])
                character.user_id = target_user_id
                ended = replace(
                    character, is_alive=False, died_at=now, death_cause="Administrative action",
                    death_age=character.age, last_age_at=now, version=int(row["version"]) + 1,
                )
                await self.repository.save_character(tx, ended, int(row["version"]))
                death = await self.life_engine.death.handle_death(tx, ended, now=now, guild_id=None)
                await self.repository.insert_audit(
                    tx, admin_id=admin_id, target_user_id=target_user_id,
                    char_id=ended.char_id, action="kill", amount=ended.age,
                    details={"death_cause":"Administrative action","archived":death is not None}, now=now,
                )
                return {"character":ended,"death":death}

    async def reset_player(self, admin_id: int, target_user_id: int) -> Character:
        """Archive the current chapter as abandoned and atomically create a fresh infant life."""
        admin_id = self._user_id(admin_id)
        target_user_id = self._user_id(target_user_id)
        now = int(self.clock())
        async with self.life_engine.locks.hold(target_user_id):
            async with self.db.transaction() as tx:
                row = await self.repository.active_character(tx, target_user_id)
                if row is None:
                    row = await self.repository.latest_character(tx, target_user_id)
                    if row is None:
                        raise CharacterNotFound("The target has no existing life to reset.")
                    previous = Character.from_dict(__import__("json").loads(row["data_json"]))
                    previous.char_id = int(row["char_id"])
                    previous.user_id = target_user_id
                else:
                    previous = Character.from_dict(__import__("json").loads(row["data_json"]))
                    previous.char_id = int(row["char_id"])
                    previous.user_id = target_user_id
                    ended = replace(
                        previous, is_alive=False, died_at=now, death_cause="Life abandoned",
                        death_age=previous.age, last_age_at=now, version=int(row["version"]) + 1,
                    )
                    await self.repository.save_character(tx, ended, int(row["version"]))
                    await self.life_engine.death.handle_death(tx, ended, now=now, guild_id=None)
                    previous = ended

                await self.life_engine.legacy_repository.close_pending_life_estates(tx, target_user_id, now)
                stats, hidden, wealth_class = roll_birth_attributes(self.life_engine.rng)
                fresh = Character(
                    user_id=target_user_id,
                    name=previous.name,
                    gender=previous.gender,
                    country=previous.country,
                    wealth_class=wealth_class,
                    age=0,
                    stats=stats,
                    hidden=hidden,
                    last_age_at=now,
                    born_at=now,
                    generation=1,
                )
                cursor = await tx.execute(
                    """INSERT INTO characters
                           (user_id, is_alive, name, gender, country, wealth_class, age, stats_json,
                            hidden_json, version, last_age_at, born_at, died_at, death_cause, death_age, data_json)
                       VALUES (?, 1, ?, ?, ?, ?, 0, ?, ?, 0, ?, ?, NULL, NULL, NULL, ?)""",
                    self.life_engine._row_values(fresh),
                )
                fresh = replace(fresh, char_id=int(cursor.lastrowid))
                await self.life_engine._refresh_data_json(tx, fresh)
                await self.life_engine.legacy_repository.ensure_player(tx, target_user_id, now)
                await self.life_engine.family.initialize_family(tx, fresh)
                await self.life_engine.crimes.initialize_character(tx, fresh)
                await self.life_engine._insert_log(
                    tx, fresh, age=0, category="birth", text=f"{fresh.name} began a new life after an administrative reset.",
                    importance=3, created_at=now,
                )
                await self.repository.insert_audit(
                    tx, admin_id=admin_id, target_user_id=target_user_id,
                    char_id=fresh.char_id, action="reset_player", amount=None,
                    details={"previous_char_id":previous.char_id,"new_char_id":fresh.char_id}, now=now,
                )
                return fresh

    async def ban(self, admin_id: int, target_user_id: int, reason: str) -> None:
        """Ban a target from player-facing game commands and audit the reason."""
        admin_id = self._user_id(admin_id)
        target_user_id = self._user_id(target_user_id)
        clean_reason = " ".join(str(reason).split()).strip()
        if not clean_reason or len(clean_reason) > 500 or any(ord(char) < 32 and char not in "\t" for char in clean_reason):
            raise ValidationError("A ban reason must be 1–500 printable characters.")
        async with self.db.transaction() as tx:
            now = int(self.clock())
            await self.repository.set_ban(
                tx, user_id=target_user_id, admin_id=admin_id, reason=clean_reason, now=now,
            )
            await self.repository.insert_audit(
                tx, admin_id=admin_id, target_user_id=target_user_id, char_id=None,
                action="ban", amount=None, details={"reason":clean_reason}, now=now,
            )

    async def unban(self, admin_id: int, target_user_id: int) -> bool:
        """Remove a target ban and audit even if no active ban existed."""
        admin_id = self._user_id(admin_id)
        target_user_id = self._user_id(target_user_id)
        async with self.db.transaction() as tx:
            removed = await self.repository.clear_ban(tx, target_user_id)
            await self.repository.insert_audit(
                tx, admin_id=admin_id, target_user_id=target_user_id, char_id=None,
                action="unban", amount=None, details={"ban_existed":removed}, now=int(self.clock()),
            )
        return removed

    async def market_event(self, admin_id: int, event: str, percent: int) -> int:
        """Apply a bounded global crash/boom market event and audit affected symbols."""
        admin_id = self._user_id(admin_id)
        if event not in {"crash", "boom"}:
            raise ValidationError("Choose crash or boom for a market event.")
        if isinstance(percent, bool) or not isinstance(percent, int) or not 1 <= percent <= 40:
            raise ValidationError("Market-event magnitude must be between 1 and 40 percent.")
        now = int(self.clock())
        async with self.db.transaction() as tx:
            affected = await self.investing_service.apply_admin_market_event(
                tx, event, percent, now=now,
            )
            await self.repository.insert_audit(
                tx, admin_id=admin_id, target_user_id=None, char_id=None,
                action="market_event", amount=percent,
                details={"event":event,"percent":percent,"affected_stocks":affected}, now=now,
            )
        return len(affected)

    async def reload_data(self, admin_id: int) -> dict[str, int]:
        """Validate every file then atomically refresh live service catalogs; audit failures too."""
        admin_id = self._user_id(admin_id)
        try:
            catalogs = self.data_loader.reload_all()
            self.life_engine.reload_catalogs(catalogs)
            if self.investing_service is not self.life_engine.investing:
                self.investing_service.replace_catalogs(catalogs["stocks"], catalogs["items"])
            await self.life_engine.investing.initialize_market()
        except Exception as exc:
            async with self.db.transaction() as tx:
                await self.repository.insert_audit(
                    tx, admin_id=admin_id, target_user_id=None, char_id=None,
                    action="reload_data_failed", amount=None,
                    details={"error":str(exc)[:1000]}, now=int(self.clock()),
                )
            raise
        counts = {
            "events":len(catalogs["events"]["events"]),
            "careers":len(catalogs["careers"]["careers"]),
            "items":len(catalogs["items"]["items"]),
            "diseases":len(catalogs["diseases"]["diseases"]),
            "crimes":len(catalogs["crimes"]["crimes"]),
            "majors":len(catalogs["majors"]["majors"]),
            "stocks":len(catalogs["stocks"]["stocks"]),
            "achievements":len(catalogs["achievements"]["achievements"]),
            "countries":len(catalogs["countries"]["countries"]),
        }
        async with self.db.transaction() as tx:
            await self.repository.insert_audit(
                tx, admin_id=admin_id, target_user_id=None, char_id=None,
                action="reload_data", amount=None, details={"counts":counts}, now=int(self.clock()),
            )
        return counts

    async def record_sync(self, admin_id: int, *, success: bool, detail: str = "") -> None:
        """Audit an explicit `/admin sync` attempt, including Discord API failures."""
        action = "sync" if success else "sync_failed"
        async with self.db.transaction() as tx:
            await self.repository.insert_audit(
                tx, admin_id=self._user_id(admin_id), target_user_id=None, char_id=None,
                action=action, amount=None, details={"detail":str(detail)[:500]}, now=int(self.clock()),
            )

    async def list_audit(self, admin_id: int, target_user_id: Optional[int] = None) -> list[dict[str, Any]]:
        """Audit the history lookup, then return the newest 25 matching owner actions."""
        admin_id = self._user_id(admin_id)
        if target_user_id is not None:
            target_user_id = self._user_id(target_user_id)
        async with self.db.transaction() as tx:
            await self.repository.insert_audit(
                tx, admin_id=admin_id, target_user_id=target_user_id, char_id=None,
                action="audit", amount=None, details={"filter_user_id":target_user_id}, now=int(self.clock()),
            )
        return await self.repository.list_audit(limit=25, target_user_id=target_user_id)
