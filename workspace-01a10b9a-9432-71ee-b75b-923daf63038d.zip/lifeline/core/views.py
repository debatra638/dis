"""Reusable owner-checked Discord views for life-event choices."""
from __future__ import annotations

import logging
from typing import Any, Optional

import discord

from .achievements import AchievementService
from .errors import GameError
from .events import EventEngine, EventPrompt, EventResolution
from .embeds import EmbedColors, apply_life_footer, safe_text, stage_for_age
from .repositories.admin import AdminRepository

logger = logging.getLogger("lifeline.views")


async def allow_unbanned_user(interaction: discord.Interaction, db: Any) -> bool:
    """Reject a banned player from an already-open game control with a private response."""
    if db is None:
        return True
    try:
        banned = await AdminRepository(db).is_banned(int(interaction.user.id))
    except Exception:
        logger.exception("Could not verify component access for user %s", interaction.user.id)
        message = "The game could not verify your access right now. Please try again shortly."
    else:
        if not banned:
            return True
        message = (
            "Your account is currently banned from LIFELINE game commands. "
            "Contact a bot administrator if you believe this is an error."
        )
    try:
        if interaction.response.is_done():
            await interaction.followup.send(
                message, ephemeral=True, allowed_mentions=discord.AllowedMentions.none()
            )
        else:
            await interaction.response.send_message(
                message, ephemeral=True, allowed_mentions=discord.AllowedMentions.none()
            )
    except discord.HTTPException:
        logger.info("Could not send private banned-player response", exc_info=True)
    return False


class LifelineView(discord.ui.View):
    """Base view with version-independent, explicit component disabling."""

    def disable_all_items(self) -> None:
        """Disable every button and select without relying on discord.py version helpers."""
        for item in self.children:
            if hasattr(item, "disabled"):
                item.disabled = True


class OwnedView(LifelineView):
    """A view restricted to its owner and disabled after timeout."""

    def __init__(self, owner_id: int, nonce: str, *, timeout: float = 180.0):
        super().__init__(timeout=timeout)
        self.owner_id = int(owner_id)
        self.nonce = nonce
        self._bound_message: Optional[Any] = None

    def bind_message(self, message: Any) -> None:
        """Keep a reference so timeout can disable the visible controls."""
        self._bound_message = message

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        """Check owner and active ban state before any game component callback runs."""
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                "Only the player who received this event can choose an option.",
                ephemeral=True,
                allowed_mentions=discord.AllowedMentions.none(),
            )
            return False
        service = getattr(self, "service", None) or getattr(self, "event_engine", None)
        database = getattr(service, "db", None)
        return await allow_unbanned_user(interaction, database)

    async def on_timeout(self) -> None:
        for item in self.children:
            if hasattr(item, "disabled"):
                item.disabled = True
        if self._bound_message is not None:
            try:
                await self._bound_message.edit(view=self)
            except discord.HTTPException:
                logger.debug("Could not disable timed-out event controls", exc_info=True)


class EventChoiceView(OwnedView):
    """Buttons for resolving one database-backed pending event."""

    def __init__(
        self,
        owner_id: int,
        prompt: EventPrompt,
        event_engine: EventEngine,
        *,
        achievement_service: Optional[AchievementService] = None,
        timeout: float = 180.0,
    ):
        super().__init__(owner_id, prompt.nonce, timeout=timeout)
        self.prompt = prompt
        self.event_engine = event_engine
        self.achievement_service = achievement_service
        for index, choice in enumerate(prompt.event.choices):
            self.add_item(_EventChoiceButton(choice, index, prompt.nonce))

    async def resolve(self, interaction: discord.Interaction, choice_id: str) -> None:
        try:
            result = await self.event_engine.resolve_choice(
                interaction.user.id,
                self.nonce,
                choice_id,
            )
        except GameError as exc:
            await interaction.response.send_message(exc.message, ephemeral=True)
            return

        for item in self.children:
            if hasattr(item, "disabled"):
                item.disabled = True
        embed = _resolution_embed(result)
        await interaction.response.edit_message(embed=embed, view=None)
        self.stop()
        if self.achievement_service is not None:
            try:
                await self.achievement_service.check_user(
                    interaction.user.id, guild_id=interaction.guild_id
                )
                notices = self.achievement_service.consume_notifications(interaction.user.id)
                if notices:
                    lines = [
                        f"🏆 **{safe_text(str(row['name']))}**"
                        for row in notices[:5]
                    ]
                    if len(notices) > 5:
                        lines.append(f"…and {len(notices) - 5} more achievement(s)")
                    notice = discord.Embed(
                        title="Achievement unlocked!" if len(notices) == 1 else "Achievements unlocked!",
                        description="\n".join(lines), color=discord.Color.gold(),
                    )
                    await interaction.followup.send(
                        embed=notice, ephemeral=True,
                        allowed_mentions=discord.AllowedMentions.none(),
                    )
            except Exception:
                logger.exception("Could not check event-choice achievements for user %s", interaction.user.id)


class _EventChoiceButton(discord.ui.Button[EventChoiceView]):
    def __init__(self, choice: Any, index: int, nonce: str):
        super().__init__(
            label=choice.label,
            style=discord.ButtonStyle.primary if index == 0 else discord.ButtonStyle.secondary,
            custom_id=f"life:event:{nonce}:{choice.id}",
            row=index // 2,
        )
        self.choice_id = choice.id

    async def callback(self, interaction: discord.Interaction) -> None:
        view = self.view
        if isinstance(view, EventChoiceView):
            await view.resolve(interaction, self.choice_id)


def event_embed(prompt: EventPrompt, *, lead: Optional[str] = None) -> discord.Embed:
    """Render an event and its choices into a Discord-friendly embed."""
    polarity_colors = {
        "positive": EmbedColors.POSITIVE,
        "negative": EmbedColors.NEGATIVE,
        "neutral": EmbedColors.NEUTRAL,
    }
    description = prompt.event.description
    if lead:
        description = f"{lead}\n\n{description}"
    embed = discord.Embed(
        title=f"✨ {prompt.event.title}",
        description=description,
        color=polarity_colors[prompt.event.polarity.value],
    )
    for index, choice in enumerate(prompt.event.choices, start=1):
        value = choice.description or "Select this option to continue."
        embed.add_field(name=f"{index}. {choice.label}", value=value, inline=False)
    apply_life_footer(embed, prompt.age, stage_for_age(prompt.age), prompt.char_id)
    return embed


def _resolution_embed(result: EventResolution) -> discord.Embed:
    changes = []
    for stat, delta in result.stat_changes.items():
        name = stat.replace("_", " ").title()
        changes.append(f"{name} {'+' if delta > 0 else ''}{delta}")
    description = f"You chose **{result.choice.label}**.\n\n{result.choice.description}"
    description += "\n\n**Stat changes:** " + (" · ".join(changes) if changes else "No stat changes.")
    if result.cash_change_cents:
        from .money import format_cents
        description += f"\n**Cash:** {format_cents(result.cash_change_cents, include_plus=True)}"
    description += f"\n**Outcome:** {result.outcome.id.replace('_', ' ').title()}"
    embed = discord.Embed(
        title=f"Event resolved · {result.event.title}",
        description=description,
        color=EmbedColors.POSITIVE,
    )
    apply_life_footer(embed, result.character.age, result.character.life_stage, result.character.char_id)
    return embed
