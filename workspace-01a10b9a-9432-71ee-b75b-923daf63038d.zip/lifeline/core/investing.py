"""Stage 9 global stocks, brokerage, bonds, rental income, and yearly capital tax."""
from __future__ import annotations

import json
import logging
import math
import time
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from typing import Any, Callable, Optional

import aiosqlite

from .data_loader import DataLoader
from .economy import capital_gains_tax, _country_modifiers
from .db import DatabaseManager
from .errors import (
    CharacterDead,
    CharacterInPrison,
    CharacterNotFound,
    ConcurrentUpdate,
    InsufficientFunds,
    ValidationError,
)
from .locks import UserLockRegistry
from .models import Character
from .money import MAX_CENTS, validate_cents
from .repositories.casino import CasinoRepository
from .repositories.investing import InvestingRepository
from .rng import RNG
from .validators import validate_stock_catalog, validate_item_catalog

logger = logging.getLogger("lifeline.investing")
TICK_INTERVAL_SECONDS = 600
TICK_DT = 1.0 / 52.0
MAX_CATCH_UP_TICKS = 6
HISTORY_LIMIT = 500
MAX_TRADES_PER_HOUR = 20
SAME_SYMBOL_COOLDOWN_SECONDS = 60
BROKERAGE_FEE_MINIMUM_CENTS = 100


@dataclass(frozen=True, slots=True)
class StockQuote:
    """Latest company price and 24-hour movement for market display."""

    symbol: str
    name: str
    sector: str
    price_cents: int
    change_cents: int
    change_percent: float
    sparkline: str
    delisted: bool = False


@dataclass(frozen=True, slots=True)
class InvestmentReceipt:
    """Completed stock or bond order and resulting account balance."""

    action: str
    symbol: Optional[str]
    shares: int
    price_cents: int
    gross_cents: int
    fee_cents: int
    realized_gain_cents: int
    bank_balance_cents: int
    message: str


@dataclass(frozen=True, slots=True)
class InvestmentYearProgress:
    """Annual passive income, bond accrual/maturity, and capital-gains tax."""

    character: Character
    messages: tuple[str, ...] = ()
    income_cents: int = 0


@dataclass(frozen=True, slots=True)
class MarketTickResult:
    """Result of a global idempotent ticker invocation."""

    ticks: int
    last_tick_at: int
    last_tick_no: int
    events: tuple[str, ...] = ()


class InvestingService:
    """Transactional market and long-term investment service."""

    def __init__(
        self,
        db: DatabaseManager,
        rng: RNG,
        locks: Optional[UserLockRegistry] = None,
        *,
        clock: Callable[[], float] = time.time,
        data_loader: Optional[DataLoader] = None,
    ) -> None:
        self.db = db
        self.rng = rng
        self.locks = locks or UserLockRegistry()
        self.clock = clock
        self.repository = InvestingRepository(db)
        self.casino_repository = CasinoRepository(db)
        loader = data_loader or DataLoader()
        self.economic_countries = loader.load_countries()
        self.catalog = loader.load_stocks()
        self.stocks = {str(row["symbol"]): dict(row) for row in self.catalog["stocks"]}
        self.item_catalog = {str(row["id"]): dict(row) for row in loader.load_items()["items"]}

    def replace_catalogs(self, stocks: dict[str, Any], items: dict[str, Any]) -> None:
        """Validate and atomically replace market and item lookup tables."""
        validate_stock_catalog(stocks)
        validate_item_catalog(items)
        new_catalog = dict(stocks)
        new_stocks = {str(row["symbol"]): dict(row) for row in stocks["stocks"]}
        new_items = {str(row["id"]): dict(row) for row in items["items"]}
        self.catalog = new_catalog
        self.stocks = new_stocks
        self.item_catalog = new_items

    async def initialize_market(self) -> None:
        """Seed missing companies and tick-zero history without resetting existing prices."""
        now = int(self.clock())
        async with self.db.transaction() as tx:
            await self.repository.ensure_market(tx, self.catalog["stocks"], now)

    async def apply_admin_market_event(
        self,
        tx: aiosqlite.Connection,
        event: str,
        percent: int,
        *,
        now: int,
    ) -> list[str]:
        """Apply one explicit bounded event inside a caller-owned audit transaction."""
        if event not in {"crash", "boom"} or isinstance(percent, bool) or not isinstance(percent, int) or not 1 <= percent <= 40:
            raise ValueError("invalid admin market event")
        if now < 0:
            raise ValueError("market event time cannot be negative")
        await self.repository.ensure_market(tx, self.catalog["stocks"], int(now))
        state = await self.repository.market_state(tx)
        if state is None:
            raise RuntimeError("Global market state failed to initialize.")
        tick_no = int(state["tick_no"]) + 1
        stocks = await self.repository.list_stocks(tx, include_delisted=False)
        affected: list[str] = []
        for stock in stocks:
            symbol = str(stock["symbol"])
            old_price = int(stock["price_cents"])
            if event == "crash":
                new_price = max(1, old_price * (100 - percent) // 100)
            else:
                new_price = max(1, old_price * (100 + percent) // 100)
            await self.repository.update_stock(
                tx, symbol=symbol, price_cents=new_price, updated_at=int(now),
                delisted=False, delisted_at=None,
            )
            await self.repository.insert_history(
                tx, symbol=symbol, tick_no=tick_no, recorded_at=int(now),
                price_cents=new_price, event_type=event,
            )
            await self.repository.trim_history(tx, symbol, HISTORY_LIMIT)
            affected.append(symbol)
        day = datetime.fromtimestamp(int(now), tz=timezone.utc).date().isoformat()
        await self.repository.save_market_state(
            tx, last_tick_at=int(state["last_tick_at"]), tick_no=tick_no,
            event_day=day, event_type=event,
        )
        return affected

    async def tick_global(self, now: Optional[int] = None) -> MarketTickResult:
        """Advance the global market transactionally, without backfill or over-six catch-up."""
        timestamp = int(self.clock()) if now is None else int(now)
        if timestamp < 0:
            raise ValueError("ticker timestamps cannot be negative")
        event_labels: list[str] = []
        async with self.db.transaction() as tx:
            await self.repository.ensure_market(tx, self.catalog["stocks"], timestamp)
            state = await self.repository.market_state(tx)
            if state is None:
                raise RuntimeError("Global market state failed to initialize.")
            previous_at = int(state["last_tick_at"])
            previous_tick = int(state["tick_no"])
            due = max(0, (timestamp - previous_at) // TICK_INTERVAL_SECONDS)
            if due <= 0:
                return MarketTickResult(0, previous_at, previous_tick, ())
            count = min(int(due), MAX_CATCH_UP_TICKS)
            if due > MAX_CATCH_UP_TICKS:
                tick_times = [timestamp - (count - 1 - index) * TICK_INTERVAL_SECONDS for index in range(count)]
                final_tick_at = timestamp
            else:
                tick_times = [previous_at + TICK_INTERVAL_SECONDS * (index + 1) for index in range(count)]
                final_tick_at = tick_times[-1]
            event_day = str(state["event_day"]) if state["event_day"] is not None else None
            last_event_type = str(state["event_type"])
            tick_no = previous_tick
            for tick_at in tick_times:
                tick_no += 1
                day = datetime.fromtimestamp(tick_at, tz=timezone.utc).date().isoformat()
                current_event = "none"
                if day != event_day:
                    event_day = day
                    chance = self.rng.random()
                    if chance < 0.02:
                        current_event = "crash"
                    elif chance < 0.05:
                        current_event = "boom"
                    last_event_type = current_event
                    if current_event != "none":
                        event_labels.append(f"{current_event}:{day}")
                stocks = await self.repository.list_stocks(tx, include_delisted=False)
                for stock in stocks:
                    symbol = str(stock["symbol"])
                    old_price = int(stock["price_cents"])
                    z = self.rng.gauss(0.0, 1.0)
                    new_price = self.gbm_price_step(
                        old_price, float(stock["drift"]), float(stock["volatility"]), z, dt=TICK_DT
                    )
                    if current_event == "crash":
                        drop = self.rng.uniform(0.15, 0.40)
                        new_price = max(1, int(math.floor(new_price * (1.0 - drop))))
                    elif current_event == "boom":
                        rise = self.rng.uniform(0.10, 0.25)
                        new_price = max(1, int(math.floor(new_price * (1.0 + rise))))
                    delisted = False
                    if new_price < 100 and self.rng.random() < 0.0005:
                        new_price = 0
                        delisted = True
                    await self.repository.update_stock(
                        tx, symbol=symbol, price_cents=new_price, updated_at=tick_at,
                        delisted=delisted, delisted_at=tick_at if delisted else None,
                    )
                    await self.repository.insert_history(
                        tx, symbol=symbol, tick_no=tick_no, recorded_at=tick_at,
                        price_cents=new_price, event_type=current_event,
                    )
                    await self.repository.trim_history(tx, symbol, HISTORY_LIMIT)
            await self.repository.save_market_state(
                tx, last_tick_at=final_tick_at, tick_no=tick_no,
                event_day=event_day, event_type=last_event_type,
            )
            return MarketTickResult(count, final_tick_at, tick_no, tuple(event_labels))

    @staticmethod
    def gbm_price_step(price_cents: int, drift: float, volatility: float, z: float, *, dt: float = TICK_DT) -> int:
        """Apply one geometric-Brownian-motion tick and floor the result at one cent."""
        if isinstance(price_cents, bool) or not isinstance(price_cents, int) or price_cents < 0:
            raise ValueError("stock price must be a non-negative integer number of cents")
        if not all(math.isfinite(value) for value in (drift, volatility, z, dt)) or volatility < 0 or dt < 0:
            raise ValueError("GBM parameters must be finite and volatility/dt non-negative")
        if price_cents == 0:
            return 0
        exponent = (drift - 0.5 * volatility * volatility) * dt + volatility * math.sqrt(dt) * z
        raw = price_cents * math.exp(exponent)
        return min(MAX_CENTS, max(1, int(math.floor(raw))))

    @staticmethod
    def brokerage_fee(gross_cents: int) -> int:
        """Charge 0.5% brokerage rounded up, with a $1.00 minimum."""
        validate_cents(gross_cents)
        if gross_cents < 0:
            raise ValueError("trade gross cannot be negative")
        return max(BROKERAGE_FEE_MINIMUM_CENTS, (gross_cents + 199) // 200)

    @staticmethod
    def _active_character(character: Character) -> None:
        if not character.is_alive:
            raise CharacterDead()

    async def _load_character(self, tx: aiosqlite.Connection, user_id: int) -> tuple[Character, int]:
        row = await self.repository.character_row(tx, user_id)
        if row is None:
            if await self.repository.has_life(tx, user_id):
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        self._active_character(character)
        return character, int(row["version"])

    @staticmethod
    def _check_investing_access(character: Character) -> None:
        if character.age < 18:
            raise ValidationError("Investing requires an active character aged 18 or older.")
        if character.in_prison:
            raise CharacterInPrison("Investment orders are unavailable while your character is in prison.")

    async def market(self, user_id: int) -> list[StockQuote]:
        """Read listed tickers, 24-hour percentage movements, and text sparklines."""
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._load_character(tx, user_id)
                self._check_investing_access(character)
                stocks = await self.repository.list_stocks(tx, include_delisted=True)
                result: list[StockQuote] = []
                for stock in stocks:
                    symbol = str(stock["symbol"])
                    history = await self.repository.history(tx, symbol, since=now - 86_400, limit=500)
                    if not history:
                        history = await self.repository.history(tx, symbol, limit=1)
                    first_price = int(history[0]["price_cents"]) if history else int(stock["price_cents"])
                    current_price = int(stock["price_cents"])
                    change = current_price - first_price
                    percent = (change / first_price * 100.0) if first_price > 0 else 0.0
                    spark = self.sparkline([int(point["price_cents"]) for point in history[-24:]])
                    result.append(
                        StockQuote(symbol, str(stock["company_name"]), str(stock["sector"]), current_price,
                                   change, percent, spark, bool(stock["is_delisted"]))
                    )
                return result

    async def symbol_history(self, user_id: int, symbol: str) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        """Return one company's latest price and recent persisted ticks."""
        normalized = self._normalize_symbol(symbol)
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._load_character(tx, user_id)
                self._check_investing_access(character)
                stock = await self.repository.stock(tx, normalized)
                if stock is None:
                    raise ValidationError("Unknown stock symbol. Use autocomplete to choose a listed company.")
                history = await self.repository.history(tx, normalized, limit=50)
                return stock, history

    async def buy(self, user_id: int, symbol: str, shares: int) -> InvestmentReceipt:
        """Buy whole shares at transaction-time price using bank funds only."""
        normalized = self._normalize_symbol(symbol)
        quantity = self._validate_shares(shares)
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._load_character(tx, user_id)
                self._check_investing_access(character)
                await self._check_trade_limits(tx, user_id, normalized, "buy", now)
                stock = await self.repository.stock(tx, normalized)
                if stock is None or bool(stock["is_delisted"]):
                    raise ValidationError("That stock is not currently listed for trading.")
                price = int(stock["price_cents"])
                if price < 1:
                    raise ValidationError("That stock has no tradable price.")
                gross = validate_cents(price * quantity)
                fee = self.brokerage_fee(gross)
                total = validate_cents(gross + fee)
                if character.bank < total:
                    raise InsufficientFunds("Stock purchases and brokerage fees are paid from your bank balance only.")
                holding = await self.repository.holding(tx, character.char_id, normalized)
                old_shares = int(holding["shares"]) if holding else 0
                old_basis = int(holding["cost_basis_cents"]) if holding else 0
                new_shares = old_shares + quantity
                new_basis = validate_cents(old_basis + total)
                updated = replace(character, bank=character.bank - total, version=version + 1)
                await self.repository.save_character(tx, updated, version)
                await self.repository.save_holding(
                    tx, char_id=character.char_id, symbol=normalized, shares=new_shares,
                    cost_basis_cents=new_basis, updated_at=now,
                )
                await self.repository.insert_trade(
                    tx, char_id=character.char_id, symbol=normalized, side="buy", shares=quantity,
                    price_cents=price, gross_cents=gross, fee_cents=fee,
                    realized_gain_cents=0, age=character.age, created_at=now,
                )
                await self.casino_repository.insert_audit(
                    tx, now=now, user_id=user_id, char_id=character.char_id,
                    action="investment_stock_buy", amount=total,
                    details={"symbol": normalized, "shares": quantity, "price_cents": price, "gross_cents": gross, "fee_cents": fee},
                )
                return InvestmentReceipt(
                    "buy", normalized, quantity, price, gross, fee, 0, updated.bank,
                    f"Bought {quantity} {normalized} share(s) at {price:,}¢ each; gross {gross:,}¢, fee {fee:,}¢. Bank: {updated.bank:,}¢.",
                )

    async def sell(self, user_id: int, symbol: str, shares: int | str) -> InvestmentReceipt:
        """Sell whole shares or the entire position at transaction-time price."""
        normalized = self._normalize_symbol(symbol)
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._load_character(tx, user_id)
                self._check_investing_access(character)
                stock = await self.repository.stock(tx, normalized)
                if stock is None or bool(stock["is_delisted"]) or int(stock["price_cents"]) < 1:
                    raise ValidationError("This issuer is delisted or worthless; its shares cannot be sold.")
                holding = await self.repository.holding(tx, character.char_id, normalized)
                if holding is None:
                    raise ValidationError(f"You do not own any {normalized} shares.")
                owned = int(holding["shares"])
                if isinstance(shares, str) and shares.strip().lower() == "all":
                    quantity = owned
                else:
                    try:
                        quantity = int(shares)
                    except (TypeError, ValueError) as exc:
                        raise ValidationError("Shares must be a positive whole number or `all`.") from exc
                    quantity = self._validate_shares(quantity)
                if quantity > owned:
                    raise ValidationError(f"You only own {owned} {normalized} share(s).")
                await self._check_trade_limits(tx, user_id, normalized, "sell", now)
                price = int(stock["price_cents"])
                gross = validate_cents(price * quantity)
                fee = self.brokerage_fee(gross)
                total_basis = int(holding["cost_basis_cents"])
                basis_sold = total_basis if quantity == owned else total_basis * quantity // owned
                realized = gross - fee - basis_sold
                new_shares = owned - quantity
                new_basis = total_basis - basis_sold
                resulting_bank = character.bank + gross - fee
                if resulting_bank < 0:
                    raise InsufficientFunds("Your bank balance must cover any shortfall from the $1 minimum brokerage fee.")
                validate_cents(resulting_bank)
                updated = replace(character, bank=resulting_bank, version=version + 1)
                await self.repository.save_character(tx, updated, version)
                if new_shares:
                    await self.repository.save_holding(
                        tx, char_id=character.char_id, symbol=normalized, shares=new_shares,
                        cost_basis_cents=new_basis, updated_at=now,
                    )
                else:
                    await self.repository.delete_holding(tx, character.char_id, normalized)
                await self.repository.insert_trade(
                    tx, char_id=character.char_id, symbol=normalized, side="sell", shares=quantity,
                    price_cents=price, gross_cents=gross, fee_cents=fee,
                    realized_gain_cents=realized, age=character.age, created_at=now,
                )
                await self.casino_repository.insert_audit(
                    tx, now=now, user_id=user_id, char_id=character.char_id,
                    action="investment_stock_sell", amount=gross,
                    details={"symbol": normalized, "shares": quantity, "price_cents": price,
                             "gross_cents": gross, "fee_cents": fee, "realized_gain_cents": realized},
                )
                return InvestmentReceipt(
                    "sell", normalized, quantity, price, gross, fee, realized, updated.bank,
                    f"Sold {quantity} {normalized} share(s) at {price:,}¢; gross {gross:,}¢, fee {fee:,}¢, realized gain/loss {realized:+,}¢. Bank: {updated.bank:,}¢.",
                )

    async def portfolio(self, user_id: int) -> tuple[list[dict[str, Any]], list[dict[str, Any]], int]:
        """Return stock holdings, locked bonds, and bank balance with delisted value at zero."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._load_character(tx, user_id)
                self._check_investing_access(character)
                holdings = await self.repository.holdings(tx, character.char_id)
                for holding in holdings:
                    price = 0 if holding["price_cents"] is None or bool(holding["is_delisted"]) else int(holding["price_cents"])
                    holding["market_value_cents"] = int(holding["shares"]) * price
                    holding["unrealized_gain_cents"] = holding["market_value_cents"] - int(holding["cost_basis_cents"])
                bonds = await self.repository.bonds(tx, character.char_id, locked_only=True)
                return holdings, bonds, character.bank

    async def trade_history(self, user_id: int, symbol: str) -> tuple[dict[str, Any], list[dict[str, Any]], list[dict[str, Any]]]:
        """Return recent price ticks and this life’s executions for one symbol."""
        normalized = self._normalize_symbol(symbol)
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._load_character(tx, user_id)
                self._check_investing_access(character)
                stock = await self.repository.stock(tx, normalized)
                if stock is None:
                    raise ValidationError("Unknown stock symbol. Use autocomplete to choose a listed company.")
                history = await self.repository.history(tx, normalized, limit=50)
                trades = await self.repository.trade_history(tx, character.char_id, normalized, limit=20)
                return stock, history, trades

    async def bond_buy(self, user_id: int, amount_cents: int) -> InvestmentReceipt:
        """Buy a fixed 3.5% annual bond locked for five in-game years, from bank only."""
        try:
            amount = validate_cents(amount_cents)
        except (TypeError, OverflowError) as exc:
            raise ValidationError("Bond principal must be a valid whole-cent amount.") from exc
        if amount < 100:
            raise ValidationError("The minimum bond purchase is $1.00.")
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._load_character(tx, user_id)
                self._check_investing_access(character)
                if character.bank < amount:
                    raise InsufficientFunds("Bond principal is paid from your bank balance only.")
                bond_id = await self.repository.insert_bond(
                    tx, char_id=character.char_id, principal=amount,
                    purchased_age=character.age, maturity_age=character.age + 5, now=now,
                )
                updated = replace(character, bank=character.bank - amount, version=version + 1)
                await self.repository.save_character(tx, updated, version)
                await self.casino_repository.insert_audit(
                    tx, now=now, user_id=user_id, char_id=character.char_id,
                    action="investment_bond_buy", amount=amount,
                    details={"bond_id": bond_id, "maturity_age": character.age + 5, "rate_bps": 350},
                )
                return InvestmentReceipt(
                    "bond_buy", None, 0, 0, amount, 0, 0, updated.bank,
                    f"Bond #{bond_id} purchased for {amount:,}¢ at 3.5% fixed annual return; locked until age {character.age + 5}.",
                )

    async def advance_year(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        previous_age: int,
        now: int,
        housing_upkeep_paid: bool = False,
    ) -> InvestmentYearProgress:
        """Accrue bonds, apply rental income/vacancy/upkeep, and assess 15% realized-gain tax.

        The existing Stage 8 shop tick charges housing upkeep before this service in
        ``LifeEngine.age_up``. Direct callers default to charging rental upkeep here.
        """
        if await self.repository.yearly_income(tx, character.char_id, previous_age) is not None:
            return InvestmentYearProgress(character)
        messages: list[str] = []
        updated = character
        total_income = 0
        rental_net = 0
        bond_interest = 0
        new_age = previous_age + 1
        housing_ids = [item_id for item_id, item in self.item_catalog.items() if item["category"] == "housing"]
        houses = await self.repository.housing_assets(tx, character.char_id, housing_ids)
        primary_asset = int(character.housing_item_id) if character.housing_item_id is not None else None
        if primary_asset is None and houses:
            primary_asset = int(houses[0]["asset_id"])
        rent_candidates = [row for row in houses if int(row["asset_id"]) != primary_asset]
        if len(houses) >= 2:
            for house in rent_candidates:
                item = self.item_catalog.get(str(house["item_id"]))
                if item is None:
                    continue
                vacant = self.rng.random() < 0.10
                gross_rent = 0 if vacant else int(int(house["current_value"]) * 6 // 100)
                upkeep = self._scale_charge(int(item["yearly_upkeep_cents"]), updated.price_index)
                if gross_rent:
                    updated = replace(updated, bank=validate_cents(updated.bank + gross_rent))
                if not housing_upkeep_paid:
                    paid = min(upkeep, updated.cash + updated.bank)
                    if paid:
                        updated = self._deduct_available(updated, paid)
                    if paid < upkeep:
                        shortfall = upkeep - paid
                        updated = replace(updated, debt_total=validate_cents(updated.debt_total + shortfall))
                        messages.append(f"Rental upkeep for {item['name']} was short by {shortfall:,}¢ and added to debt.")
                net = gross_rent - upkeep
                rental_net += net
                messages.append(
                    f"{item['name']} was {'vacant' if vacant else 'rented'}: rent {gross_rent:,}¢, upkeep {upkeep:,}¢, net {net:+,}¢."
                )
        for bond in await self.repository.bonds(tx, character.char_id, locked_only=True):
            if int(bond["purchased_age"]) > previous_age or int(bond["last_accrued_age"]) >= new_age:
                continue
            balance = int(bond["balance_cents"])
            interest = balance * 35 // 1000
            balance = validate_cents(balance + interest)
            bond_interest += interest
            maturity_age = int(bond["maturity_age"])
            matured = new_age >= maturity_age
            await self.repository.update_bond(
                tx, bond_id=int(bond["bond_id"]), balance=balance,
                last_accrued_age=new_age, status="matured" if matured else "locked",
                matured_at=now if matured else None,
            )
            if matured:
                updated = replace(updated, bank=validate_cents(updated.bank + balance))
                messages.append(f"Savings bond #{bond['bond_id']} matured at {balance:,}¢ and was deposited to your bank.")
            elif interest:
                messages.append(f"Savings bond #{bond['bond_id']} accrued {interest:,}¢; it remains locked until age {maturity_age}.")
        total_income = rental_net + bond_interest
        tax_record = await self.casino_repository.load_yearly_tax(tx, character.char_id, previous_age)
        capital_gain = await self.repository.realized_gain_for_age(tx, character.char_id, previous_age)
        tax_mod, _, _ = _country_modifiers(self.economic_countries, character.country)
        capital_tax = capital_gains_tax(max(0, capital_gain), tax_mod=tax_mod)
        gambling_net = int(tax_record["gambling_net_cents"]) if tax_record else 0
        gambling_tax = int(tax_record["gambling_tax_cents"]) if tax_record else 0
        already_taxed = int(tax_record["capital_tax_cents"]) if tax_record else 0
        if tax_record is None or already_taxed == 0:
            updated, paid, unpaid = self._collect_tax(updated, capital_tax)
            await self.casino_repository.upsert_yearly_tax(
                tx, char_id=character.char_id, age=previous_age,
                gambling_net=gambling_net, gambling_tax=gambling_tax,
                capital_gain=capital_gain, capital_tax=capital_tax, now=now,
            )
            if capital_tax:
                messages.append(
                    f"Capital-gains tax: {capital_tax:,}¢ assessed on realized stock gains of {max(0, capital_gain):,}¢; paid {paid:,}¢"
                    + (f"; {unpaid:,}¢ added to tax debt." if unpaid else ".")
                )
        await self.repository.save_yearly_income(
            tx, char_id=character.char_id, age=previous_age,
            rental_income=rental_net, bond_interest=bond_interest,
        )
        return InvestmentYearProgress(updated, tuple(messages), total_income)

    @staticmethod
    def _scale_charge(base_cents: int, price_index: float) -> int:
        """Scale a charge upward using integer cents and the current price index."""
        value = Decimal(base_cents) * Decimal(str(price_index))
        return int(value.to_integral_value(rounding=ROUND_CEILING))

    @staticmethod
    def _deduct_available(character: Character, amount: int) -> Character:
        """Pay an operating cost cash-first then bank without crossing zero."""
        if amount < 0 or character.cash + character.bank < amount:
            raise InsufficientFunds("Annual investment cost exceeds available funds.")
        bank_paid = min(character.bank, amount)
        cash_paid = amount - bank_paid
        return replace(character, cash=character.cash - cash_paid, bank=character.bank - bank_paid)

    @staticmethod
    def _collect_tax(character: Character, tax_cents: int) -> tuple[Character, int, int]:
        """Assess taxes without negative balances; unpaid tax remains explicit debt."""
        validate_cents(tax_cents)
        if tax_cents <= 0:
            return character, 0, 0
        cash_paid = min(character.cash, tax_cents)
        remainder = tax_cents - cash_paid
        bank_paid = min(character.bank, remainder)
        unpaid = remainder - bank_paid
        updated = replace(
            character, cash=character.cash - cash_paid, bank=character.bank - bank_paid,
            debt_total=validate_cents(character.debt_total + unpaid),
        )
        return updated, cash_paid + bank_paid, unpaid

    @staticmethod
    def _percent_ceiling(amount_cents: int, percent: int) -> int:
        """Round tax charges upward to the next cent."""
        if amount_cents <= 0:
            return 0
        return (amount_cents * percent + 99) // 100

    async def _check_trade_limits(
        self, tx: aiosqlite.Connection, user_id: int, symbol: str, side: str, now: int
    ) -> None:
        """Enforce the rolling hourly player cap and same-symbol anti-churn cooldown."""
        count = await self.repository.trade_count_since(tx, user_id, now - 3600)
        if count >= MAX_TRADES_PER_HOUR:
            raise ValidationError(f"You have reached the limit of {MAX_TRADES_PER_HOUR} stock trades per real-time hour.")
        last_opposite = await self.repository.last_opposite_trade(tx, user_id, symbol, side)
        if last_opposite is not None and now - last_opposite < SAME_SYMBOL_COOLDOWN_SECONDS:
            remaining = SAME_SYMBOL_COOLDOWN_SECONDS - max(0, now - last_opposite)
            raise ValidationError(f"Wait {remaining} more second(s) before trading {symbol} in the opposite direction.")

    @staticmethod
    def _normalize_symbol(symbol: str) -> str:
        """Normalize and validate a ticker token before parameterized lookup."""
        normalized = str(symbol).strip().upper()
        if not normalized or len(normalized) > 8 or not normalized.isascii() or not normalized.isalnum():
            raise ValidationError("Enter a valid stock symbol.")
        return normalized

    @staticmethod
    def _validate_shares(shares: int) -> int:
        """Validate whole-share order size within SQLite-safe bounds."""
        if isinstance(shares, bool) or not isinstance(shares, int) or not 1 <= shares <= 1_000_000_000:
            raise ValidationError("Share amount must be a positive whole number no greater than 1,000,000,000.")
        return shares

    @staticmethod
    def sparkline(values: list[int]) -> str:
        """Render a compact Unicode text chart from integer-cent observations."""
        glyphs = "▁▂▃▄▅▆▇█"
        if not values:
            return "—"
        low, high = min(values), max(values)
        if low == high:
            return glyphs[3] * min(24, len(values))
        scale = len(glyphs) - 1
        return "".join(glyphs[round((value - low) / (high - low) * scale)] for value in values[-24:])

    def symbol_options(self, current: str = "") -> list[tuple[str, str]]:
        """Return catalog autocomplete options matching a typed prefix."""
        query = str(current).strip().upper()
        entries = [
            (symbol, str(stock["name"]))
            for symbol, stock in self.stocks.items()
            if query in symbol or query in str(stock["name"]).upper()
        ]
        return entries[:25]
