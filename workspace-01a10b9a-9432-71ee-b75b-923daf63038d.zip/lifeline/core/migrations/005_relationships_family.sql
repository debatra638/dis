-- Stage 6: family NPCs, relationships, dating, marriage, children, and support.
CREATE TABLE IF NOT EXISTS npcs (
    npc_id             INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_char_id      INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    name               TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 80),
    gender             TEXT NOT NULL CHECK (gender IN ('male', 'female', 'non_binary')),
    age                INTEGER NOT NULL DEFAULT 0 CHECK (age BETWEEN 0 AND 120),
    looks              INTEGER NOT NULL CHECK (looks BETWEEN 0 AND 100),
    smarts             INTEGER NOT NULL CHECK (smarts BETWEEN 0 AND 100),
    health             INTEGER NOT NULL CHECK (health BETWEEN 0 AND 100),
    wealth             INTEGER NOT NULL DEFAULT 0 CHECK (wealth >= 0),
    occupation         TEXT NOT NULL DEFAULT 'Unemployed',
    is_alive           INTEGER NOT NULL DEFAULT 1 CHECK (is_alive IN (0, 1)),
    death_age          INTEGER,
    country            TEXT NOT NULL DEFAULT 'usa',
    annual_income      INTEGER NOT NULL DEFAULT 0 CHECK (annual_income >= 0),
    prefers_smarts     INTEGER NOT NULL DEFAULT 0 CHECK (prefers_smarts IN (0, 1)),
    CHECK ((is_alive = 1 AND death_age IS NULL) OR (is_alive = 0 AND death_age IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS idx_npcs_owner_alive ON npcs(owner_char_id, is_alive, age);

CREATE TABLE IF NOT EXISTS relationships (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id     INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    npc_id      INTEGER NOT NULL REFERENCES npcs(npc_id) ON DELETE CASCADE,
    type        TEXT NOT NULL CHECK (type IN ('parent', 'sibling', 'child', 'friend', 'partner', 'fiance', 'spouse', 'ex', 'enemy', 'coworker')),
    score       INTEGER NOT NULL DEFAULT 50 CHECK (score BETWEEN 0 AND 100),
    since_age   INTEGER NOT NULL DEFAULT 0 CHECK (since_age >= 0),
    UNIQUE(char_id, npc_id)
);
CREATE INDEX IF NOT EXISTS idx_relationships_character_type ON relationships(char_id, type, score DESC);

CREATE TABLE IF NOT EXISTS children (
    npc_id               INTEGER PRIMARY KEY REFERENCES npcs(npc_id) ON DELETE CASCADE,
    char_id              INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    other_parent_npc_id  INTEGER REFERENCES npcs(npc_id) ON DELETE SET NULL,
    custody              TEXT NOT NULL DEFAULT 'full' CHECK (custody IN ('full', 'shared', 'none')),
    child_support        INTEGER NOT NULL DEFAULT 0 CHECK (child_support >= 0)
);
CREATE INDEX IF NOT EXISTS idx_children_character ON children(char_id, custody);

-- Count interactions per person and in-game age; a primary key prevents duplicate races.
CREATE TABLE IF NOT EXISTS yearly_counters (
    char_id  INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    npc_id   INTEGER NOT NULL REFERENCES npcs(npc_id) ON DELETE CASCADE,
    age      INTEGER NOT NULL CHECK (age >= 0),
    action   TEXT NOT NULL,
    count    INTEGER NOT NULL DEFAULT 0 CHECK (count >= 0),
    PRIMARY KEY(char_id, npc_id, age, action)
);

CREATE TABLE IF NOT EXISTS dating_sessions (
    char_id     INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    nonce       TEXT NOT NULL UNIQUE,
    created_at  INTEGER NOT NULL,
    expires_at  INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS dating_candidates (
    char_id  INTEGER NOT NULL REFERENCES dating_sessions(char_id) ON DELETE CASCADE,
    npc_id   INTEGER NOT NULL REFERENCES npcs(npc_id) ON DELETE CASCADE,
    PRIMARY KEY(char_id, npc_id)
);

CREATE TABLE IF NOT EXISTS marriages (
    char_id          INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    spouse_npc_id    INTEGER NOT NULL REFERENCES npcs(npc_id) ON DELETE CASCADE,
    start_age        INTEGER NOT NULL CHECK (start_age >= 0),
    spouse_income    INTEGER NOT NULL DEFAULT 0 CHECK (spouse_income >= 0),
    prenup           INTEGER NOT NULL DEFAULT 0 CHECK (prenup IN (0, 1)),
    premarital_cash  INTEGER NOT NULL DEFAULT 0 CHECK (premarital_cash >= 0),
    premarital_bank  INTEGER NOT NULL DEFAULT 0 CHECK (premarital_bank >= 0),
    wedding_cost     INTEGER NOT NULL DEFAULT 0 CHECK (wedding_cost >= 0),
    low_score_years  INTEGER NOT NULL DEFAULT 0 CHECK (low_score_years >= 0),
    created_at       INTEGER NOT NULL,
    UNIQUE(spouse_npc_id)
);

CREATE TABLE IF NOT EXISTS pregnancies (
    char_id              INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    other_parent_npc_id  INTEGER REFERENCES npcs(npc_id) ON DELETE SET NULL,
    conception_age       INTEGER NOT NULL CHECK (conception_age >= 0),
    due_age              INTEGER NOT NULL CHECK (due_age >= conception_age),
    accidental           INTEGER NOT NULL DEFAULT 0 CHECK (accidental IN (0, 1))
);
CREATE TABLE IF NOT EXISTS adoptions (
    char_id      INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    started_age  INTEGER NOT NULL CHECK (started_age >= 0),
    due_age      INTEGER NOT NULL CHECK (due_age > started_age),
    paid_cost    INTEGER NOT NULL CHECK (paid_cost >= 0)
);

-- Minimal persistent inventory/portfolio values for rings and divorce valuation.
CREATE TABLE IF NOT EXISTS family_assets (
    asset_id        INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id         INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    kind            TEXT NOT NULL CHECK (kind IN ('item', 'stock')),
    item_id         TEXT NOT NULL,
    quantity        INTEGER NOT NULL DEFAULT 1 CHECK (quantity >= 0),
    purchase_price  INTEGER NOT NULL CHECK (purchase_price >= 0),
    current_value   INTEGER NOT NULL CHECK (current_value >= 0),
    acquired_age    INTEGER NOT NULL CHECK (acquired_age >= 0),
    acquired_at     INTEGER NOT NULL DEFAULT 0,
    is_liquidated   INTEGER NOT NULL DEFAULT 0 CHECK (is_liquidated IN (0, 1))
);
CREATE INDEX IF NOT EXISTS idx_family_assets_character_age ON family_assets(char_id, acquired_age, kind);

CREATE TABLE IF NOT EXISTS alimony (
    char_id          INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    ex_npc_id        INTEGER NOT NULL REFERENCES npcs(npc_id) ON DELETE CASCADE,
    annual_amount    INTEGER NOT NULL CHECK (annual_amount >= 0),
    remaining_years  REAL NOT NULL CHECK (remaining_years >= 0),
    payer_is_player  INTEGER NOT NULL CHECK (payer_is_player IN (0, 1))
);
CREATE TABLE IF NOT EXISTS affairs (
    char_id        INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    spouse_npc_id  INTEGER NOT NULL REFERENCES npcs(npc_id) ON DELETE CASCADE,
    started_age    INTEGER NOT NULL CHECK (started_age >= 0),
    nonce          TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS infidelity_prompts (
    char_id        INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    spouse_npc_id  INTEGER NOT NULL REFERENCES npcs(npc_id) ON DELETE CASCADE,
    nonce          TEXT NOT NULL UNIQUE,
    created_at     INTEGER NOT NULL,
    expires_at     INTEGER NOT NULL CHECK (expires_at >= created_at)
);
CREATE TABLE IF NOT EXISTS infidelity_choices (
    char_id      INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    spouse_npc_id INTEGER NOT NULL REFERENCES npcs(npc_id) ON DELETE CASCADE,
    age          INTEGER NOT NULL CHECK (age >= 0),
    choice       TEXT NOT NULL CHECK (choice IN ('cheat', 'faithful')),
    created_at   INTEGER NOT NULL,
    PRIMARY KEY(char_id, age)
);

CREATE TABLE IF NOT EXISTS divorce_records (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id         INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    spouse_npc_id   INTEGER NOT NULL REFERENCES npcs(npc_id),
    age             INTEGER NOT NULL CHECK (age >= 0),
    prenup          INTEGER NOT NULL CHECK (prenup IN (0, 1)),
    marital_assets  INTEGER NOT NULL CHECK (marital_assets >= 0),
    spouse_share    INTEGER NOT NULL CHECK (spouse_share >= 0),
    lawyer_fee      INTEGER NOT NULL CHECK (lawyer_fee >= 0),
    reason          TEXT NOT NULL CHECK (reason IN ('player', 'discovery', 'npc_initiated')),
    created_at      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_divorce_history_character ON divorce_records(char_id, age DESC);

CREATE TABLE IF NOT EXISTS stats_tracking (
    char_id    INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    divorces   INTEGER NOT NULL DEFAULT 0 CHECK (divorces >= 0)
);
