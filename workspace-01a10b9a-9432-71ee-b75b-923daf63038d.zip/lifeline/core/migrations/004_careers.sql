-- Stage 5: active jobs, career history, and one work action per in-game year.
CREATE TABLE IF NOT EXISTS jobs (
    char_id          INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    career_id        TEXT NOT NULL,
    level            INTEGER NOT NULL CHECK (level >= 1),
    performance      INTEGER NOT NULL DEFAULT 50 CHECK (performance BETWEEN 0 AND 100),
    years_in_role    INTEGER NOT NULL DEFAULT 0 CHECK (years_in_role >= 0),
    years_in_career  INTEGER NOT NULL DEFAULT 0 CHECK (years_in_career >= 0),
    salary           INTEGER NOT NULL CHECK (salary >= 0),
    is_part_time     INTEGER NOT NULL DEFAULT 0 CHECK (is_part_time IN (0, 1)),
    warnings         INTEGER NOT NULL DEFAULT 0 CHECK (warnings >= 0)
);

CREATE TABLE IF NOT EXISTS career_history (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id     INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    career_id   TEXT NOT NULL,
    max_level   INTEGER NOT NULL CHECK (max_level >= 1),
    start_age   INTEGER NOT NULL CHECK (start_age >= 0),
    end_age     INTEGER,
    end_reason  TEXT,
    CHECK (
        (end_age IS NULL AND end_reason IS NULL)
        OR
        (end_age IS NOT NULL AND end_reason IN ('quit', 'fired', 'retired', 'died'))
    )
);
CREATE INDEX IF NOT EXISTS idx_career_history_character
    ON career_history(char_id, start_age DESC);

CREATE TABLE IF NOT EXISTS career_actions (
    char_id             INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age                 INTEGER NOT NULL CHECK (age >= 0),
    action              TEXT NOT NULL CHECK (action IN ('hard', 'normal', 'slack')),
    performance_before  INTEGER NOT NULL CHECK (performance_before BETWEEN 0 AND 100),
    performance_after   INTEGER NOT NULL CHECK (performance_after BETWEEN 0 AND 100),
    created_at          INTEGER NOT NULL,
    PRIMARY KEY (char_id, age)
);
