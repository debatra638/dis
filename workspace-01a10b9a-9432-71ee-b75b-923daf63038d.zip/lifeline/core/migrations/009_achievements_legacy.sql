-- Stage 10: achievements, yearly life metrics, death archives, estates, and legacy.
ALTER TABLE players
    ADD COLUMN lives_lived INTEGER NOT NULL DEFAULT 0 CHECK (lives_lived >= 0);
ALTER TABLE players
    ADD COLUMN legacy_points INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players
    ADD COLUMN leaderboard_opt_out INTEGER NOT NULL DEFAULT 0 CHECK (leaderboard_opt_out IN (0, 1));
INSERT OR IGNORE INTO players(user_id, created_at)
    SELECT user_id, MIN(born_at) FROM characters GROUP BY user_id;

CREATE TABLE IF NOT EXISTS achievements_unlocked (
    user_id        INTEGER NOT NULL REFERENCES players(user_id) ON DELETE CASCADE,
    achievement_id TEXT NOT NULL,
    char_id        INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    unlocked_at    INTEGER NOT NULL CHECK (unlocked_at >= 0),
    PRIMARY KEY (user_id, achievement_id)
);
CREATE INDEX IF NOT EXISTS idx_achievements_character
    ON achievements_unlocked(char_id, unlocked_at DESC);

CREATE TABLE IF NOT EXISTS life_year_metrics (
    char_id               INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age                   INTEGER NOT NULL CHECK (age >= 0),
    happiness             INTEGER NOT NULL CHECK (happiness BETWEEN 0 AND 100),
    net_worth_cents       INTEGER NOT NULL,
    peak_net_worth_cents  INTEGER NOT NULL,
    served_prison_year    INTEGER NOT NULL DEFAULT 0 CHECK (served_prison_year IN (0, 1)),
    recorded_at           INTEGER NOT NULL CHECK (recorded_at >= 0),
    PRIMARY KEY (char_id, age)
);
CREATE INDEX IF NOT EXISTS idx_life_year_metrics_character_age
    ON life_year_metrics(char_id, age DESC);

CREATE TABLE IF NOT EXISTS marriage_history (
    marriage_history_id INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id             INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    spouse_npc_id       INTEGER,
    spouse_name         TEXT NOT NULL,
    start_age           INTEGER NOT NULL CHECK (start_age >= 0),
    end_age             INTEGER NOT NULL CHECK (end_age >= start_age),
    end_reason          TEXT NOT NULL CHECK (end_reason IN ('divorce', 'spouse_death', 'character_death', 'retirement')),
    created_at          INTEGER NOT NULL CHECK (created_at >= 0)
);
CREATE INDEX IF NOT EXISTS idx_marriage_history_character
    ON marriage_history(char_id, start_age, end_age);

CREATE TABLE IF NOT EXISTS past_lives (
    past_life_id             INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id                  INTEGER NOT NULL UNIQUE REFERENCES characters(char_id) ON DELETE RESTRICT,
    user_id                  INTEGER NOT NULL REFERENCES players(user_id) ON DELETE CASCADE,
    death_age                INTEGER NOT NULL CHECK (death_age >= 0),
    death_cause              TEXT NOT NULL,
    born_at                  INTEGER NOT NULL CHECK (born_at >= 0),
    died_at                  INTEGER NOT NULL CHECK (died_at >= 0),
    life_score               REAL NOT NULL,
    grade                    TEXT NOT NULL CHECK (grade IN ('S', 'A', 'B', 'C', 'D', 'F')),
    legacy_points            INTEGER NOT NULL,
    peak_net_worth_cents     INTEGER NOT NULL,
    final_net_worth_cents    INTEGER NOT NULL,
    gross_assets_cents       INTEGER NOT NULL CHECK (gross_assets_cents >= 0),
    debts_paid_cents         INTEGER NOT NULL CHECK (debts_paid_cents >= 0),
    estate_tax_cents         INTEGER NOT NULL CHECK (estate_tax_cents >= 0),
    estate_cents             INTEGER NOT NULL CHECK (estate_cents >= 0),
    unpaid_debt_cents        INTEGER NOT NULL CHECK (unpaid_debt_cents >= 0),
    abandoned                INTEGER NOT NULL DEFAULT 0 CHECK (abandoned IN (0, 1)),
    summary_json             TEXT NOT NULL,
    archived_at              INTEGER NOT NULL CHECK (archived_at >= 0)
);
CREATE INDEX IF NOT EXISTS idx_past_lives_user_archive
    ON past_lives(user_id, archived_at DESC, past_life_id DESC);
CREATE INDEX IF NOT EXISTS idx_past_lives_death
    ON past_lives(abandoned, archived_at DESC);
CREATE TRIGGER IF NOT EXISTS trg_past_lives_immutable_update
BEFORE UPDATE ON past_lives
BEGIN
    SELECT RAISE(ABORT, 'past_lives rows are immutable');
END;
CREATE TRIGGER IF NOT EXISTS trg_past_lives_immutable_delete
BEFORE DELETE ON past_lives
BEGIN
    SELECT RAISE(ABORT, 'past_lives rows are immutable');
END;

CREATE TABLE IF NOT EXISTS life_estates (
    estate_id           INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id             INTEGER NOT NULL UNIQUE REFERENCES past_lives(char_id) ON DELETE CASCADE,
    user_id             INTEGER NOT NULL REFERENCES players(user_id) ON DELETE CASCADE,
    estate_cents        INTEGER NOT NULL CHECK (estate_cents >= 0),
    nonce               TEXT NOT NULL UNIQUE,
    eligible_heirs_json TEXT NOT NULL,
    status              TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'claimed', 'closed')),
    selected_npc_id     INTEGER,
    created_at          INTEGER NOT NULL CHECK (created_at >= 0),
    resolved_at         INTEGER
);
CREATE INDEX IF NOT EXISTS idx_life_estates_user_status
    ON life_estates(user_id, status, created_at DESC);

CREATE TABLE IF NOT EXISTS retirement_prompts (
    prompt_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES players(user_id) ON DELETE CASCADE,
    char_id      INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    nonce        TEXT NOT NULL UNIQUE,
    status       TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'cancelled', 'expired')),
    created_at   INTEGER NOT NULL CHECK (created_at >= 0),
    expires_at   INTEGER NOT NULL CHECK (expires_at >= created_at),
    resolved_at  INTEGER
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_retirement_one_pending_per_user
    ON retirement_prompts(user_id) WHERE status = 'pending';

CREATE TABLE IF NOT EXISTS legacy_start_purchases (
    char_id        INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    user_id        INTEGER NOT NULL REFERENCES players(user_id) ON DELETE CASCADE,
    stat_name      TEXT NOT NULL CHECK (stat_name IN ('health', 'happiness', 'smarts', 'looks', 'fitness', 'karma')),
    purchase_count INTEGER NOT NULL CHECK (purchase_count BETWEEN 1 AND 2),
    points_spent   INTEGER NOT NULL CHECK (points_spent = purchase_count * 50),
    created_at     INTEGER NOT NULL CHECK (created_at >= 0)
);

CREATE TABLE IF NOT EXISTS guild_player_seen (
    guild_id      INTEGER NOT NULL CHECK (guild_id > 0),
    user_id       INTEGER NOT NULL REFERENCES players(user_id) ON DELETE CASCADE,
    last_seen_at  INTEGER NOT NULL CHECK (last_seen_at >= 0),
    PRIMARY KEY (guild_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_guild_player_seen_recent
    ON guild_player_seen(guild_id, last_seen_at DESC);

CREATE TABLE IF NOT EXISTS guild_stage10_settings (
    guild_id                INTEGER PRIMARY KEY CHECK (guild_id > 0),
    public_death_summaries  INTEGER NOT NULL DEFAULT 0 CHECK (public_death_summaries IN (0, 1)),
    updated_by              INTEGER NOT NULL CHECK (updated_by > 0),
    updated_at              INTEGER NOT NULL CHECK (updated_at >= 0)
);
