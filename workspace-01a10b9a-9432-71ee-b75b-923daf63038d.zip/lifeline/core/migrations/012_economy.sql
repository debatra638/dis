-- Stage 12 repair Part A: authoritative balance checks, amortizing loans, and economy ledgers.
-- Existing character balances remain in the JSON snapshot for backwards compatibility;
-- checked mirror columns are synchronized by triggers on every JSON write.
ALTER TABLE characters
    ADD COLUMN cash_cents INTEGER NOT NULL DEFAULT 0 CHECK (cash_cents >= 0);
ALTER TABLE characters
    ADD COLUMN bank_cents INTEGER NOT NULL DEFAULT 0 CHECK (bank_cents >= 0);
UPDATE characters
   SET cash_cents = MAX(0, CAST(json_extract(data_json, '$.cash') AS INTEGER)),
       bank_cents = MAX(0, CAST(json_extract(data_json, '$.bank') AS INTEGER));

CREATE TRIGGER IF NOT EXISTS trg_characters_balances_after_insert
AFTER INSERT ON characters
BEGIN
    UPDATE characters
       SET cash_cents = MAX(0, CAST(json_extract(NEW.data_json, '$.cash') AS INTEGER)),
           bank_cents = MAX(0, CAST(json_extract(NEW.data_json, '$.bank') AS INTEGER))
     WHERE char_id = NEW.char_id;
END;
CREATE TRIGGER IF NOT EXISTS trg_characters_balances_after_json_update
AFTER UPDATE OF data_json ON characters
BEGIN
    UPDATE characters
       SET cash_cents = CAST(json_extract(NEW.data_json, '$.cash') AS INTEGER),
           bank_cents = CAST(json_extract(NEW.data_json, '$.bank') AS INTEGER)
     WHERE char_id = NEW.char_id;
END;

-- Migration 006's loan status constraint predated the DISCHARGED model state.
-- Rebuild only this leaf table; no table has a foreign key pointing at loans.
CREATE TABLE loans_012 (
    loan_id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id                 INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    loan_type               TEXT NOT NULL DEFAULT 'personal'
                            CHECK (loan_type IN ('personal', 'student', 'mortgage', 'auto', 'payday', 'loan_shark')),
    balance                 INTEGER NOT NULL CHECK (balance >= 0),
    annual_payment          INTEGER NOT NULL CHECK (annual_payment >= 0),
    missed_payments         INTEGER NOT NULL DEFAULT 0 CHECK (missed_payments >= 0),
    status                  TEXT NOT NULL DEFAULT 'active'
                            CHECK (status IN ('active', 'paid', 'defaulted', 'discharged')),
    principal               INTEGER NOT NULL DEFAULT 0 CHECK (principal >= 0),
    annual_rate             REAL NOT NULL DEFAULT 0 CHECK (annual_rate BETWEEN 0 AND 2),
    term_years              INTEGER NOT NULL DEFAULT 0 CHECK (term_years >= 0),
    years_remaining         INTEGER NOT NULL DEFAULT 0 CHECK (years_remaining >= 0),
    collateral_item_uid     INTEGER REFERENCES family_assets(asset_id),
    origination_age         INTEGER NOT NULL DEFAULT 0 CHECK (origination_age >= 0),
    consecutive_misses      INTEGER NOT NULL DEFAULT 0 CHECK (consecutive_misses >= 0),
    last_payment_age        INTEGER,
    grace_until_age         INTEGER NOT NULL DEFAULT 0 CHECK (grace_until_age >= 0),
    defaulted_at_age        INTEGER,
    interest_paid_cents     INTEGER NOT NULL DEFAULT 0 CHECK (interest_paid_cents >= 0),
    CHECK (last_payment_age IS NULL OR last_payment_age >= 0),
    CHECK (defaulted_at_age IS NULL OR defaulted_at_age >= 0)
);
INSERT INTO loans_012 (
    loan_id, char_id, loan_type, balance, annual_payment, missed_payments,
    status, principal, annual_rate, term_years, years_remaining,
    collateral_item_uid, origination_age, consecutive_misses
)
SELECT loan_id, char_id, loan_type, balance, annual_payment, missed_payments,
       CASE WHEN status IN ('active', 'paid', 'defaulted') THEN status ELSE 'active' END,
       COALESCE(principal, balance), COALESCE(annual_rate, 0), COALESCE(term_years, 0),
       COALESCE(years_remaining, 0), collateral_item_uid, 0, COALESCE(missed_payments, 0)
  FROM loans;
DROP TABLE loans;
ALTER TABLE loans_012 RENAME TO loans;
CREATE INDEX IF NOT EXISTS idx_loans_character_status ON loans(char_id, status);
CREATE INDEX IF NOT EXISTS idx_loans_collateral ON loans(collateral_item_uid, status);

CREATE TABLE IF NOT EXISTS economy_years (
    char_id                 INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age                     INTEGER NOT NULL CHECK (age >= 0),
    income_tax_cents        INTEGER NOT NULL DEFAULT 0 CHECK (income_tax_cents >= 0),
    living_cost_cents       INTEGER NOT NULL DEFAULT 0 CHECK (living_cost_cents >= 0),
    rent_cents              INTEGER NOT NULL DEFAULT 0 CHECK (rent_cents >= 0),
    interest_cents          INTEGER NOT NULL DEFAULT 0 CHECK (interest_cents >= 0),
    theft_cents             INTEGER NOT NULL DEFAULT 0 CHECK (theft_cents >= 0),
    stock_liquidation_cents INTEGER NOT NULL DEFAULT 0 CHECK (stock_liquidation_cents >= 0),
    settled_at              INTEGER NOT NULL CHECK (settled_at >= 0),
    PRIMARY KEY (char_id, age)
);

CREATE TABLE IF NOT EXISTS economy_collections (
    collection_id INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id       INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    source        TEXT NOT NULL CHECK (source IN ('rent', 'living_expense', 'loan_deficiency', 'medical', 'tax')),
    loan_id       INTEGER REFERENCES loans(loan_id) ON DELETE SET NULL,
    balance_cents INTEGER NOT NULL CHECK (balance_cents >= 0),
    created_age   INTEGER NOT NULL CHECK (created_age >= 0),
    status        TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'paid', 'discharged')),
    created_at    INTEGER NOT NULL CHECK (created_at >= 0),
    updated_at    INTEGER NOT NULL CHECK (updated_at >= created_at)
);
CREATE INDEX IF NOT EXISTS idx_economy_collections_character_status
    ON economy_collections(char_id, status, created_age);

CREATE TABLE IF NOT EXISTS economy_activity_uses (
    char_id     INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age         INTEGER NOT NULL CHECK (age >= 0),
    activity_id TEXT NOT NULL CHECK (activity_id IN ('walk', 'run', 'gym', 'mindfulness', 'sports')),
    used_at     INTEGER NOT NULL CHECK (used_at >= 0),
    PRIMARY KEY (char_id, age, activity_id)
);

CREATE TABLE IF NOT EXISTS bankruptcies (
    bankruptcy_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id             INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age                 INTEGER NOT NULL CHECK (age >= 0),
    debt_before_cents   INTEGER NOT NULL CHECK (debt_before_cents >= 0),
    assets_before_cents INTEGER NOT NULL CHECK (assets_before_cents >= 0),
    discharged_cents    INTEGER NOT NULL CHECK (discharged_cents >= 0),
    filed_at            INTEGER NOT NULL CHECK (filed_at >= 0),
    UNIQUE (char_id, age)
);
CREATE INDEX IF NOT EXISTS idx_bankruptcies_character_age ON bankruptcies(char_id, age DESC);
