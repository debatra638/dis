-- Stage 12: repair the nested JSON envelope written by the original archive repository.
-- Keep the immutable archive trigger disabled only inside this atomic one-time migration.
DROP TRIGGER IF EXISTS trg_past_lives_immutable_update;

UPDATE past_lives
SET summary_json = json_extract(summary_json, '$.summary_json')
WHERE json_valid(summary_json)
  AND json_type(summary_json, '$.summary_json') = 'object'
  AND json_type(summary_json, '$.name') IS NULL;

CREATE TRIGGER IF NOT EXISTS trg_past_lives_immutable_update
BEFORE UPDATE ON past_lives
BEGIN
    SELECT RAISE(ABORT, 'past_lives rows are immutable');
END;
