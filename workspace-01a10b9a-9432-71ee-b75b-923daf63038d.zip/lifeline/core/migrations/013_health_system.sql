-- Part B health progression, treatment timing, insurance renewal, and visit history.
ALTER TABLE health_conditions
    ADD COLUMN duration_years INTEGER NOT NULL DEFAULT 1 CHECK (duration_years BETWEEN 0 AND 120);
ALTER TABLE health_conditions
    ADD COLUMN last_treated_age INTEGER CHECK (last_treated_age IS NULL OR last_treated_age >= 0);
ALTER TABLE health_conditions
    ADD COLUMN last_progressed_age INTEGER CHECK (last_progressed_age IS NULL OR last_progressed_age >= 0);
ALTER TABLE health_conditions
    ADD COLUMN progression_count INTEGER NOT NULL DEFAULT 0 CHECK (progression_count >= 0);

CREATE TABLE IF NOT EXISTS health_visits (
    visit_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id        INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age            INTEGER NOT NULL CHECK (age >= 0),
    visit_type     TEXT NOT NULL CHECK (visit_type IN ('doctor', 'hospital', 'therapy', 'surgery', 'insurance', 'activity')),
    disease_id     TEXT,
    cost_cents     INTEGER NOT NULL DEFAULT 0 CHECK (cost_cents >= 0),
    outcome_json   TEXT NOT NULL DEFAULT '{}',
    created_at     INTEGER NOT NULL CHECK (created_at >= 0)
);
CREATE INDEX IF NOT EXISTS idx_health_visits_character_age
    ON health_visits(char_id, age DESC, visit_id DESC);
