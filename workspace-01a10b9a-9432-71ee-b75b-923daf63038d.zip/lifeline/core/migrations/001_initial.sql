-- LIFELINE Stage 2 foundation: active characters and chronological life logs.
CREATE TABLE IF NOT EXISTS characters (
    char_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL,
    is_alive      INTEGER NOT NULL DEFAULT 1 CHECK (is_alive IN (0, 1)),
    name          TEXT NOT NULL,
    gender        TEXT NOT NULL CHECK (gender IN ('male', 'female', 'non_binary')),
    country       TEXT NOT NULL DEFAULT 'usa',
    wealth_class  TEXT NOT NULL,
    age           INTEGER NOT NULL DEFAULT 0 CHECK (age >= 0),
    stats_json    TEXT NOT NULL,
    hidden_json   TEXT NOT NULL,
    version       INTEGER NOT NULL DEFAULT 0 CHECK (version >= 0),
    last_age_at   INTEGER,
    born_at       INTEGER NOT NULL,
    died_at       INTEGER,
    death_cause   TEXT,
    death_age     INTEGER,
    data_json     TEXT NOT NULL,
    CHECK (
        (is_alive = 1 AND died_at IS NULL AND death_age IS NULL)
        OR
        (is_alive = 0 AND died_at IS NOT NULL AND death_age IS NOT NULL)
    )
);

-- A user may keep historical lives but can only have one active life at a time.
CREATE UNIQUE INDEX IF NOT EXISTS idx_characters_one_active_per_user
    ON characters(user_id) WHERE is_alive = 1;
CREATE INDEX IF NOT EXISTS idx_characters_user_history
    ON characters(user_id, char_id DESC);

CREATE TABLE IF NOT EXISTS life_logs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id     INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age         INTEGER NOT NULL CHECK (age >= 0),
    category    TEXT NOT NULL,
    text        TEXT NOT NULL,
    importance  INTEGER NOT NULL DEFAULT 1 CHECK (importance BETWEEN 1 AND 5),
    created_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_life_logs_character_age
    ON life_logs(char_id, age, id);
