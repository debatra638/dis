-- Stage 4: one study action per character per in-game year.
CREATE TABLE IF NOT EXISTS education_actions (
    char_id       INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age           INTEGER NOT NULL CHECK (age >= 0),
    effort        TEXT NOT NULL CHECK (effort IN ('hard', 'normal', 'slack')),
    gpa_before    REAL NOT NULL CHECK (gpa_before BETWEEN 0.0 AND 4.0),
    gpa_after     REAL NOT NULL CHECK (gpa_after BETWEEN 0.0 AND 4.0),
    effects_json  TEXT NOT NULL,
    created_at    INTEGER NOT NULL,
    PRIMARY KEY (char_id, age)
);
CREATE INDEX IF NOT EXISTS idx_education_actions_character
    ON education_actions(char_id, age DESC);
