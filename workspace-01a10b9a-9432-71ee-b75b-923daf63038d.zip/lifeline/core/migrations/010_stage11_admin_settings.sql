-- Stage 11: owner-admin audit fields, bans, and per-player public-result settings.
ALTER TABLE audit_log
    ADD COLUMN admin_id INTEGER CHECK (admin_id IS NULL OR admin_id > 0);
ALTER TABLE audit_log
    ADD COLUMN target_user_id INTEGER CHECK (target_user_id IS NULL OR target_user_id > 0);
CREATE INDEX IF NOT EXISTS idx_audit_log_admin_time
    ON audit_log(admin_id, ts DESC);
CREATE INDEX IF NOT EXISTS idx_audit_log_target_time
    ON audit_log(target_user_id, ts DESC);

CREATE TABLE IF NOT EXISTS player_bans (
    user_id       INTEGER PRIMARY KEY CHECK (user_id > 0),
    admin_id      INTEGER NOT NULL CHECK (admin_id > 0),
    reason        TEXT NOT NULL CHECK (length(reason) BETWEEN 1 AND 500),
    created_at    INTEGER NOT NULL CHECK (created_at >= 0)
);
CREATE INDEX IF NOT EXISTS idx_player_bans_created
    ON player_bans(created_at DESC);

CREATE TABLE IF NOT EXISTS player_settings (
    user_id                  INTEGER PRIMARY KEY REFERENCES players(user_id) ON DELETE CASCADE,
    public_year_summaries    INTEGER NOT NULL DEFAULT 1 CHECK (public_year_summaries IN (0, 1)),
    public_deaths            INTEGER NOT NULL DEFAULT 1 CHECK (public_deaths IN (0, 1)),
    public_casino_results    INTEGER NOT NULL DEFAULT 1 CHECK (public_casino_results IN (0, 1)),
    public_leaderboards      INTEGER NOT NULL DEFAULT 1 CHECK (public_leaderboards IN (0, 1)),
    updated_at               INTEGER NOT NULL DEFAULT 0 CHECK (updated_at >= 0)
);
CREATE INDEX IF NOT EXISTS idx_player_settings_leaderboard
    ON player_settings(public_leaderboards, user_id);
