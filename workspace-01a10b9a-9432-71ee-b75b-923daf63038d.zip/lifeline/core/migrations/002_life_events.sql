-- Stage 3: persist one unresolved choice per character and record resolutions.
CREATE TABLE IF NOT EXISTS pending_events (
    char_id       INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    event_key     TEXT NOT NULL,
    age           INTEGER NOT NULL CHECK (age >= 0),
    nonce         TEXT NOT NULL UNIQUE,
    context_json  TEXT NOT NULL,
    created_at    INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS character_events (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id       INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    event_key     TEXT NOT NULL,
    choice_id     TEXT NOT NULL,
    age           INTEGER NOT NULL CHECK (age >= 0),
    effects_json  TEXT NOT NULL,
    resolved_at   INTEGER NOT NULL,
    UNIQUE (char_id, age)
);
CREATE INDEX IF NOT EXISTS idx_character_events_history
    ON character_events(char_id, age DESC);
