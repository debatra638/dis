-- Stage 7: crime, criminal careers, taxes/audits, trials, and prison.
-- Preserve the historical career rows while extending the allowed prison end reason.
CREATE TABLE career_history_stage7 (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id     INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    career_id   TEXT NOT NULL,
    max_level   INTEGER NOT NULL CHECK (max_level >= 1),
    start_age   INTEGER NOT NULL CHECK (start_age >= 0),
    end_age     INTEGER,
    end_reason  TEXT,
    CHECK (
        (end_age IS NULL AND end_reason IS NULL)
        OR
        (end_age IS NOT NULL AND end_reason IN ('quit', 'fired', 'retired', 'died', 'prison'))
    )
);
INSERT INTO career_history_stage7(id, char_id, career_id, max_level, start_age, end_age, end_reason)
SELECT id, char_id, career_id, max_level, start_age, end_age, end_reason FROM career_history;
DROP TABLE career_history;
ALTER TABLE career_history_stage7 RENAME TO career_history;
CREATE INDEX IF NOT EXISTS idx_career_history_character
    ON career_history(char_id, start_age DESC);

CREATE TABLE IF NOT EXISTS crime_profiles (
    char_id             INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    dirty_cash          INTEGER NOT NULL DEFAULT 0 CHECK (dirty_cash >= 0),
    career_rank         TEXT,
    career_years        INTEGER NOT NULL DEFAULT 0 CHECK (career_years >= 0),
    career_level        INTEGER NOT NULL DEFAULT -1 CHECK (career_level BETWEEN -1 AND 5),
    last_crime_id       TEXT,
    evaded_tax          INTEGER NOT NULL DEFAULT 0 CHECK (evaded_tax >= 0),
    gang_protected      INTEGER NOT NULL DEFAULT 0 CHECK (gang_protected IN (0, 1)),
    escaped             INTEGER NOT NULL DEFAULT 0 CHECK (escaped IN (0, 1)),
    juvenile_release_age INTEGER CHECK (juvenile_release_age BETWEEN 0 AND 120),
    last_release_age    INTEGER CHECK (last_release_age BETWEEN 0 AND 120),
    front_business      INTEGER NOT NULL DEFAULT 0 CHECK (front_business IN (0, 1))
);
INSERT OR IGNORE INTO crime_profiles(char_id) SELECT char_id FROM characters;

CREATE TABLE IF NOT EXISTS crime_previews (
    char_id            INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    crime_id           TEXT NOT NULL,
    age                INTEGER NOT NULL CHECK (age >= 0),
    nonce              TEXT NOT NULL UNIQUE,
    success_chance     REAL NOT NULL CHECK (success_chance BETWEEN 3.0 AND 97.0),
    catch_chance       REAL NOT NULL CHECK (catch_chance BETWEEN 3.0 AND 97.0),
    loot_min           INTEGER NOT NULL CHECK (loot_min >= 0),
    loot_max           INTEGER NOT NULL CHECK (loot_max >= loot_min),
    salary_snapshot    INTEGER NOT NULL DEFAULT 0 CHECK (salary_snapshot >= 0),
    created_at         INTEGER NOT NULL,
    expires_at         INTEGER NOT NULL CHECK (expires_at >= created_at)
);

CREATE TABLE IF NOT EXISTS crime_attempts (
    attempt_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id          INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    crime_id         TEXT NOT NULL,
    age              INTEGER NOT NULL CHECK (age >= 0),
    source           TEXT NOT NULL DEFAULT 'attempt'
                     CHECK (source IN ('attempt', 'career_arrest', 'escape_rearrest', 'tax_audit')),
    success          INTEGER NOT NULL CHECK (success IN (0, 1)),
    caught           INTEGER NOT NULL CHECK (caught IN (0, 1)),
    loot             INTEGER NOT NULL DEFAULT 0 CHECK (loot >= 0),
    success_chance   REAL NOT NULL CHECK (success_chance BETWEEN 0.0 AND 100.0),
    catch_chance     REAL NOT NULL CHECK (catch_chance BETWEEN 0.0 AND 100.0),
    case_status      TEXT NOT NULL DEFAULT 'clear'
                     CHECK (case_status IN ('clear', 'pending', 'convicted', 'acquitted')),
    lawyer_tier      TEXT CHECK (lawyer_tier IN ('public', 'standard', 'elite')),
    sentence_years   INTEGER NOT NULL DEFAULT 0 CHECK (sentence_years >= 0),
    life_sentence    INTEGER NOT NULL DEFAULT 0 CHECK (life_sentence IN (0, 1)),
    record_sealed    INTEGER NOT NULL DEFAULT 0 CHECK (record_sealed IN (0, 1)),
    fine_paid        INTEGER NOT NULL DEFAULT 0 CHECK (fine_paid >= 0),
    created_at       INTEGER NOT NULL,
    resolved_at      INTEGER
);
CREATE INDEX IF NOT EXISTS idx_crime_attempts_character_age
    ON crime_attempts(char_id, age DESC, attempt_id DESC);

CREATE TABLE IF NOT EXISTS crime_trials (
    char_id      INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    attempt_id   INTEGER NOT NULL UNIQUE REFERENCES crime_attempts(attempt_id) ON DELETE CASCADE,
    nonce        TEXT NOT NULL UNIQUE,
    created_at   INTEGER NOT NULL
);

-- The Stage 6 yearly_counters table requires an NPC foreign key. This fallback
-- counter supports migrated lives that predate family NPC initialization.
CREATE TABLE IF NOT EXISTS crime_yearly_actions (
    char_id  INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age      INTEGER NOT NULL CHECK (age >= 0),
    action   TEXT NOT NULL,
    count    INTEGER NOT NULL DEFAULT 0 CHECK (count >= 0),
    PRIMARY KEY(char_id, age, action)
);

CREATE TABLE IF NOT EXISTS crime_cashflows (
    flow_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id    INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age        INTEGER NOT NULL CHECK (age >= 0),
    action     TEXT NOT NULL CHECK (action IN ('crime_income', 'career_income', 'launder', 'fine', 'tax', 'audit')),
    amount     INTEGER NOT NULL CHECK (amount >= 0),
    created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_crime_cashflows_character_age
    ON crime_cashflows(char_id, age, action);

CREATE TABLE IF NOT EXISTS crime_laundering (
    laundering_id INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id       INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age           INTEGER NOT NULL CHECK (age >= 0),
    gross_amount  INTEGER NOT NULL CHECK (gross_amount > 0),
    fee_amount    INTEGER NOT NULL CHECK (fee_amount >= 0),
    net_amount    INTEGER NOT NULL CHECK (net_amount >= 0),
    created_at    INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_crime_laundering_character_age
    ON crime_laundering(char_id, age);

CREATE TABLE IF NOT EXISTS crime_tax_prompts (
    char_id      INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    nonce        TEXT NOT NULL UNIQUE,
    age          INTEGER NOT NULL CHECK (age >= 0),
    tax_due      INTEGER NOT NULL CHECK (tax_due >= 0),
    prepaid      INTEGER NOT NULL CHECK (prepaid IN (0, 1)),
    paid_amount  INTEGER NOT NULL DEFAULT 0 CHECK (paid_amount >= 0),
    created_at   INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS crime_tax_choices (
    choice_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id        INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age            INTEGER NOT NULL CHECK (age >= 0),
    choice         TEXT NOT NULL CHECK (choice IN ('pay', 'evade_50', 'evade_75', 'evade_100')),
    tax_due        INTEGER NOT NULL CHECK (tax_due >= 0),
    evaded_amount  INTEGER NOT NULL CHECK (evaded_amount >= 0),
    created_at     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS crime_audits (
    audit_id           INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id            INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age                INTEGER NOT NULL CHECK (age >= 0),
    audit_chance       REAL NOT NULL CHECK (audit_chance BETWEEN 0.0 AND 100.0),
    triggered          INTEGER NOT NULL CHECK (triggered IN (0, 1)),
    tax_evasion_found  INTEGER NOT NULL CHECK (tax_evasion_found IN (0, 1)),
    back_taxes         INTEGER NOT NULL DEFAULT 0 CHECK (back_taxes >= 0),
    sentence_years     INTEGER NOT NULL DEFAULT 0 CHECK (sentence_years >= 0),
    outcome            TEXT NOT NULL,
    created_at         INTEGER NOT NULL
);

-- Minimal persisted loan data for prison-only automatic annual payments.
CREATE TABLE IF NOT EXISTS loans (
    loan_id          INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id          INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    loan_type        TEXT NOT NULL DEFAULT 'personal',
    balance          INTEGER NOT NULL CHECK (balance >= 0),
    annual_payment   INTEGER NOT NULL CHECK (annual_payment >= 0),
    missed_payments  INTEGER NOT NULL DEFAULT 0 CHECK (missed_payments >= 0),
    status           TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'paid', 'defaulted'))
);
CREATE INDEX IF NOT EXISTS idx_loans_character_status ON loans(char_id, status);
