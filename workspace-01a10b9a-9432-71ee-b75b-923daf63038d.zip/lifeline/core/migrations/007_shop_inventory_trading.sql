-- Stage 8: player accounts, item inventory locks, collateral links, and atomic trades.
ALTER TABLE family_assets
    ADD COLUMN is_locked INTEGER NOT NULL DEFAULT 0 CHECK (is_locked IN (0, 1));

ALTER TABLE loans
    ADD COLUMN principal INTEGER NOT NULL DEFAULT 0 CHECK (principal >= 0);
ALTER TABLE loans
    ADD COLUMN annual_rate REAL NOT NULL DEFAULT 0 CHECK (annual_rate BETWEEN 0 AND 1);
ALTER TABLE loans
    ADD COLUMN term_years INTEGER NOT NULL DEFAULT 0 CHECK (term_years >= 0);
ALTER TABLE loans
    ADD COLUMN years_remaining INTEGER NOT NULL DEFAULT 0 CHECK (years_remaining >= 0);
ALTER TABLE loans
    ADD COLUMN collateral_item_uid INTEGER REFERENCES family_assets(asset_id);

CREATE TABLE IF NOT EXISTS shop_quotes (
    char_id             INTEGER PRIMARY KEY REFERENCES characters(char_id) ON DELETE CASCADE,
    nonce               TEXT NOT NULL UNIQUE,
    item_id             TEXT NOT NULL,
    quantity            INTEGER NOT NULL CHECK (quantity > 0),
    total_price         INTEGER NOT NULL CHECK (total_price >= 0),
    balance_cents       INTEGER NOT NULL CHECK (balance_cents >= 0),
    character_version   INTEGER NOT NULL CHECK (character_version >= 0),
    created_at          INTEGER NOT NULL CHECK (created_at >= 0),
    expires_at          INTEGER NOT NULL CHECK (expires_at >= created_at)
);

CREATE TABLE IF NOT EXISTS players (
    user_id       INTEGER PRIMARY KEY CHECK (user_id > 0),
    created_at    INTEGER NOT NULL CHECK (created_at >= 0),
    trade_banned  INTEGER NOT NULL DEFAULT 0 CHECK (trade_banned IN (0, 1))
);

CREATE TABLE IF NOT EXISTS trades (
    trade_id               INTEGER PRIMARY KEY AUTOINCREMENT,
    from_user_id           INTEGER NOT NULL REFERENCES players(user_id),
    from_char_id           INTEGER NOT NULL REFERENCES characters(char_id),
    to_user_id             INTEGER NOT NULL REFERENCES players(user_id),
    to_char_id             INTEGER NOT NULL REFERENCES characters(char_id),
    offer_cash             INTEGER NOT NULL DEFAULT 0 CHECK (offer_cash >= 0),
    request_cash           INTEGER NOT NULL DEFAULT 0 CHECK (request_cash >= 0),
    status                 TEXT NOT NULL DEFAULT 'pending'
                           CHECK (status IN ('pending', 'accepted', 'declined', 'cancelled', 'expired', 'failed')),
    created_at             INTEGER NOT NULL CHECK (created_at >= 0),
    expires_at             INTEGER NOT NULL CHECK (expires_at >= created_at),
    resolved_at            INTEGER,
    nonce                  TEXT NOT NULL UNIQUE,
    imbalance_flag         INTEGER NOT NULL DEFAULT 0 CHECK (imbalance_flag IN (0, 1)),
    imbalance_receiver_id  INTEGER,
    outcome_message        TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_trades_from_user_status ON trades(from_user_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_trades_to_user_status ON trades(to_user_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_trades_expiry ON trades(status, expires_at);
CREATE UNIQUE INDEX IF NOT EXISTS idx_trades_one_pending_outgoing
    ON trades(from_user_id) WHERE status = 'pending';

CREATE TABLE IF NOT EXISTS trade_items (
    trade_item_id  INTEGER PRIMARY KEY AUTOINCREMENT,
    trade_id       INTEGER NOT NULL REFERENCES trades(trade_id) ON DELETE CASCADE,
    side           TEXT NOT NULL CHECK (side IN ('offer', 'request')),
    item_uid       INTEGER NOT NULL,
    item_id        TEXT NOT NULL,
    quantity       INTEGER NOT NULL CHECK (quantity > 0),
    value_snapshot INTEGER NOT NULL CHECK (value_snapshot >= 0),
    UNIQUE(trade_id, side, item_uid)
);
CREATE INDEX IF NOT EXISTS idx_trade_items_trade_side ON trade_items(trade_id, side, item_uid);

CREATE TABLE IF NOT EXISTS trade_daily_usage (
    user_id   INTEGER NOT NULL REFERENCES players(user_id),
    day_key   TEXT NOT NULL,
    trades    INTEGER NOT NULL DEFAULT 0 CHECK (trades BETWEEN 0 AND 5),
    PRIMARY KEY(user_id, day_key)
);

CREATE TABLE IF NOT EXISTS inventory_uses (
    asset_id  INTEGER NOT NULL REFERENCES family_assets(asset_id) ON DELETE CASCADE,
    age       INTEGER NOT NULL CHECK (age >= 0),
    used_at   INTEGER NOT NULL CHECK (used_at >= 0),
    PRIMARY KEY(asset_id, age)
);

CREATE TABLE IF NOT EXISTS audit_log (
    audit_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    ts           INTEGER NOT NULL CHECK (ts >= 0),
    user_id      INTEGER,
    char_id      INTEGER,
    action       TEXT NOT NULL,
    amount       INTEGER CHECK (amount IS NULL OR amount >= 0),
    details_json TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_audit_log_character_time ON audit_log(char_id, ts DESC);
