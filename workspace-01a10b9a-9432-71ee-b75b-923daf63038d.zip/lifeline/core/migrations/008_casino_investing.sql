-- Stage 9: casino ledgers, disease tracking, securities, bonds, and market state.
ALTER TABLE stats_tracking
    ADD COLUMN total_gambled INTEGER NOT NULL DEFAULT 0 CHECK (total_gambled >= 0);
ALTER TABLE stats_tracking
    ADD COLUMN total_gambling_net INTEGER NOT NULL DEFAULT 0;
ALTER TABLE stats_tracking
    ADD COLUMN gambling_addiction_fraction REAL NOT NULL DEFAULT 0.0
    CHECK (gambling_addiction_fraction >= 0.0 AND gambling_addiction_fraction < 1.0);

CREATE TABLE IF NOT EXISTS health_conditions (
    condition_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id          INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    disease_id       TEXT NOT NULL,
    severity         INTEGER NOT NULL DEFAULT 1 CHECK (severity BETWEEN 1 AND 5),
    diagnosed        INTEGER NOT NULL DEFAULT 1 CHECK (diagnosed IN (0, 1)),
    onset_age        INTEGER NOT NULL CHECK (onset_age >= 0),
    years_untreated  INTEGER NOT NULL DEFAULT 0 CHECK (years_untreated >= 0),
    status           TEXT NOT NULL DEFAULT 'active'
                     CHECK (status IN ('active', 'cured', 'chronic', 'in_remission')),
    is_active        INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    created_at       INTEGER NOT NULL,
    updated_at       INTEGER NOT NULL,
    UNIQUE(char_id, disease_id)
);
CREATE INDEX IF NOT EXISTS idx_health_conditions_character_active
    ON health_conditions(char_id, is_active, disease_id);

CREATE TABLE IF NOT EXISTS casino_player_state (
    user_id       INTEGER PRIMARY KEY,
    last_bet_at   INTEGER CHECK (last_bet_at IS NULL OR last_bet_at >= 0)
);

-- The standard counter is written to Stage 6's yearly_counters using an owned NPC anchor.
-- This fallback supports legacy/migrated characters that have no NPC rows.
CREATE TABLE IF NOT EXISTS casino_yearly_bets (
    char_id  INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age      INTEGER NOT NULL CHECK (age >= 0),
    count    INTEGER NOT NULL DEFAULT 0 CHECK (count BETWEEN 0 AND 25),
    PRIMARY KEY(char_id, age)
);

CREATE TABLE IF NOT EXISTS casino_plays (
    play_id        INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id        INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    user_id        INTEGER NOT NULL,
    age            INTEGER NOT NULL CHECK (age >= 0),
    game           TEXT NOT NULL CHECK (game IN ('slots', 'blackjack', 'roulette', 'coinflip', 'lottery')),
    bet_cents      INTEGER NOT NULL CHECK (bet_cents >= 0),
    payout_cents   INTEGER CHECK (payout_cents IS NULL OR payout_cents >= 0),
    net_cents      INTEGER,
    status         TEXT NOT NULL DEFAULT 'settled' CHECK (status IN ('pending', 'settled', 'refunded')),
    outcome_json   TEXT NOT NULL DEFAULT '{}',
    session_id     INTEGER,
    created_at     INTEGER NOT NULL CHECK (created_at >= 0),
    resolved_at    INTEGER
);
CREATE INDEX IF NOT EXISTS idx_casino_plays_character_age
    ON casino_plays(char_id, age, status);
CREATE INDEX IF NOT EXISTS idx_casino_plays_user_created
    ON casino_plays(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS casino_sessions (
    session_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    play_id         INTEGER NOT NULL UNIQUE REFERENCES casino_plays(play_id),
    char_id         INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    user_id         INTEGER NOT NULL,
    nonce           TEXT NOT NULL UNIQUE,
    bet_cents       INTEGER NOT NULL CHECK (bet_cents >= 100),
    escrow_cash     INTEGER NOT NULL CHECK (escrow_cash >= 0),
    escrow_bank     INTEGER NOT NULL CHECK (escrow_bank >= 0),
    state_json      TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'settled', 'refunded')),
    created_at      INTEGER NOT NULL CHECK (created_at >= 0),
    expires_at      INTEGER NOT NULL CHECK (expires_at >= created_at),
    resolved_at     INTEGER
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_casino_one_active_hand
    ON casino_sessions(char_id) WHERE status = 'active';

CREATE TABLE IF NOT EXISTS casino_compulsions (
    compulsion_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id          INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age              INTEGER NOT NULL CHECK (age >= 0),
    nonce            TEXT NOT NULL UNIQUE,
    forced_bet_cents INTEGER NOT NULL CHECK (forced_bet_cents >= 100),
    status           TEXT NOT NULL DEFAULT 'pending'
                     CHECK (status IN ('pending', 'indulged', 'resisted', 'expired')),
    created_at       INTEGER NOT NULL CHECK (created_at >= 0),
    resolved_at      INTEGER,
    outcome_message  TEXT NOT NULL DEFAULT '',
    UNIQUE(char_id, age)
);
CREATE INDEX IF NOT EXISTS idx_casino_compulsions_pending
    ON casino_compulsions(char_id, status);

CREATE TABLE IF NOT EXISTS casino_yearly_tax (
    char_id             INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age                 INTEGER NOT NULL CHECK (age >= 0),
    gambling_net_cents  INTEGER NOT NULL DEFAULT 0,
    gambling_tax_cents  INTEGER NOT NULL DEFAULT 0 CHECK (gambling_tax_cents >= 0),
    capital_gain_cents  INTEGER NOT NULL DEFAULT 0,
    capital_tax_cents   INTEGER NOT NULL DEFAULT 0 CHECK (capital_tax_cents >= 0),
    created_at          INTEGER NOT NULL,
    PRIMARY KEY(char_id, age)
);

CREATE TABLE IF NOT EXISTS market_state (
    singleton_id   INTEGER PRIMARY KEY CHECK (singleton_id = 1),
    last_tick_at  INTEGER NOT NULL CHECK (last_tick_at >= 0),
    tick_no       INTEGER NOT NULL DEFAULT 0 CHECK (tick_no >= 0),
    event_day     TEXT,
    event_type     TEXT NOT NULL DEFAULT 'none' CHECK (event_type IN ('none', 'crash', 'boom'))
);

CREATE TABLE IF NOT EXISTS stock_market (
    symbol          TEXT PRIMARY KEY,
    company_name    TEXT NOT NULL,
    sector          TEXT NOT NULL,
    price_cents     INTEGER NOT NULL CHECK (price_cents >= 0),
    drift           REAL NOT NULL,
    volatility      REAL NOT NULL CHECK (volatility > 0),
    is_delisted     INTEGER NOT NULL DEFAULT 0 CHECK (is_delisted IN (0, 1)),
    updated_at      INTEGER NOT NULL CHECK (updated_at >= 0),
    delisted_at     INTEGER
);

CREATE TABLE IF NOT EXISTS stock_history (
    history_id  INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol      TEXT NOT NULL,
    tick_no     INTEGER NOT NULL CHECK (tick_no >= 0),
    recorded_at INTEGER NOT NULL CHECK (recorded_at >= 0),
    price_cents INTEGER NOT NULL CHECK (price_cents >= 0),
    event_type  TEXT NOT NULL DEFAULT 'none',
    UNIQUE(symbol, tick_no)
);
CREATE INDEX IF NOT EXISTS idx_stock_history_symbol_time
    ON stock_history(symbol, recorded_at DESC, tick_no DESC);

CREATE TABLE IF NOT EXISTS stock_holdings (
    char_id          INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    symbol           TEXT NOT NULL,
    shares           INTEGER NOT NULL CHECK (shares > 0),
    cost_basis_cents INTEGER NOT NULL CHECK (cost_basis_cents >= 0),
    updated_at       INTEGER NOT NULL CHECK (updated_at >= 0),
    PRIMARY KEY(char_id, symbol)
);

CREATE TABLE IF NOT EXISTS investment_trades (
    investment_trade_id INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id             INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    symbol              TEXT NOT NULL,
    side                TEXT NOT NULL CHECK (side IN ('buy', 'sell')),
    shares              INTEGER NOT NULL CHECK (shares > 0),
    price_cents         INTEGER NOT NULL CHECK (price_cents >= 1),
    gross_cents         INTEGER NOT NULL CHECK (gross_cents >= 0),
    fee_cents           INTEGER NOT NULL CHECK (fee_cents >= 0),
    realized_gain_cents INTEGER NOT NULL DEFAULT 0,
    age                 INTEGER NOT NULL CHECK (age >= 0),
    created_at          INTEGER NOT NULL CHECK (created_at >= 0)
);
CREATE INDEX IF NOT EXISTS idx_investment_trades_character_time
    ON investment_trades(char_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_investment_trades_character_symbol
    ON investment_trades(char_id, symbol, created_at DESC);

CREATE TABLE IF NOT EXISTS savings_bonds (
    bond_id          INTEGER PRIMARY KEY AUTOINCREMENT,
    char_id          INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    principal_cents  INTEGER NOT NULL CHECK (principal_cents > 0),
    balance_cents    INTEGER NOT NULL CHECK (balance_cents >= 0),
    purchased_age    INTEGER NOT NULL CHECK (purchased_age >= 0),
    maturity_age     INTEGER NOT NULL CHECK (maturity_age >= purchased_age + 5),
    status           TEXT NOT NULL DEFAULT 'locked' CHECK (status IN ('locked', 'matured')),
    last_accrued_age INTEGER NOT NULL CHECK (last_accrued_age >= purchased_age),
    created_at       INTEGER NOT NULL CHECK (created_at >= 0),
    matured_at       INTEGER
);
CREATE INDEX IF NOT EXISTS idx_savings_bonds_character_status
    ON savings_bonds(char_id, status, maturity_age);

CREATE TABLE IF NOT EXISTS investment_yearly_income (
    char_id             INTEGER NOT NULL REFERENCES characters(char_id) ON DELETE CASCADE,
    age                 INTEGER NOT NULL CHECK (age >= 0),
    rental_income_cents INTEGER NOT NULL DEFAULT 0,
    bond_interest_cents INTEGER NOT NULL DEFAULT 0 CHECK (bond_interest_cents >= 0),
    PRIMARY KEY(char_id, age)
);
