"""Shared Discord embed colors and life-aware footer formatting."""
from __future__ import annotations

import re
from typing import Any

import discord

_MENTION_TOKEN_RE = re.compile(r"<(@!?|@&|#)(\d+)>")
_BROADCAST_MENTION_RE = re.compile(r"@(everyone|here)\b", re.IGNORECASE)


class EmbedColors:
    """Consistent palette for player, admin, settings, and help embeds."""

    LIFE = discord.Color.green()
    POSITIVE = discord.Color.green()
    NEGATIVE = discord.Color.orange()
    NEUTRAL = discord.Color.blurple()
    ADMIN = discord.Color.dark_red()
    SETTINGS = discord.Color.blurple()
    HELP = discord.Color.blurple()
    SUCCESS = discord.Color.brand_green()
    WARNING = discord.Color.orange()
    PRIVATE = discord.Color.dark_grey()


def safe_text(value: Any, limit: int | None = None) -> str:
    """Escape markdown and Discord mention syntax before displaying user-controlled text."""
    rendered = discord.utils.escape_markdown(str(value))
    rendered = _BROADCAST_MENTION_RE.sub(
        lambda match: f"@{chr(8203)}{match.group(1)}",
        rendered,
    )
    rendered = _MENTION_TOKEN_RE.sub(
        lambda match: f"<{match.group(1)}{chr(8203)}{match.group(2)}>",
        rendered,
    )
    return rendered if limit is None else rendered[:max(0, int(limit))]


def normalized_stage(stage: Any) -> str:
    """Return a readable stage label from a string or Stage enum."""
    raw = getattr(stage, "value", stage)
    return str(raw).replace("_", " ").title()


def stage_for_age(age: int) -> str:
    """Map a numeric age to the same stages used by the life model."""
    value = int(age)
    if value <= 2:
        return "Baby"
    if value <= 12:
        return "Child"
    if value <= 17:
        return "Teen"
    if value <= 29:
        return "Young Adult"
    if value <= 49:
        return "Adult"
    if value <= 64:
        return "Middle Age"
    return "Senior"


def life_footer(age: int, stage: Any, life_id: int) -> str:
    """Format the shared footer required on life-facing embeds."""
    return f"Age {int(age)} • {normalized_stage(stage)} • Life #{int(life_id)}"


def apply_life_footer(embed: discord.Embed, age: int, stage: Any, life_id: int) -> discord.Embed:
    """Set a consistent life footer and return the same embed for chaining."""
    embed.set_footer(text=life_footer(age, stage, life_id))
    return embed


def life_embed(
    *,
    title: str,
    description: str,
    age: int,
    stage: Any,
    life_id: int,
    color: discord.Color = EmbedColors.LIFE,
) -> discord.Embed:
    """Create a shared life-context embed with the canonical footer."""
    embed = discord.Embed(title=title, description=description, color=color)
    apply_life_footer(embed, age, stage, life_id)
    return embed
