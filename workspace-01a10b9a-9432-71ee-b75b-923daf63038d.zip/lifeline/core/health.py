"""Fictional disease, preventive care, activity, and mortality systems."""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, replace
from decimal import Decimal
from typing import Any, Callable, Optional

import aiosqlite

from .config import GameBalance
from .data_loader import DataLoader
from .errors import InsufficientFunds, ValidationError
from .economy import EconomyService
from .locks import UserLockRegistry
from .models import Character, DiseaseStatus, HousingType, Stats
from .money import charge_cents, format_cents, validate_cents
from .repositories.health import HealthRepository
from .rng import RNG


@dataclass(frozen=True, slots=True)
class MortalityRisk:
    """Annual competing hazards and the resulting per-year death probability."""

    natural_hazard: float
    illness_hazard: float
    total_probability: float


@dataclass(frozen=True, slots=True)
class HealthYearResult:
    """Character health changes, new symptoms, and persisted active conditions."""

    character: Character
    messages: tuple[str, ...]
    active_conditions: tuple[dict[str, Any], ...]


@dataclass(frozen=True, slots=True)
class HealthActionResult:
    """Outcome of one doctor, hospital, therapy, insurance, activity, or surgery action."""

    character: Character
    message: str
    cost_cents: int = 0
    disease_id: Optional[str] = None


def calculate_mortality_risk(
    character: Character,
    conditions: list[dict[str, Any]] | tuple[dict[str, Any], ...],
) -> MortalityRisk:
    """Compute an annual age/health baseline plus independent condition hazards.

    The fictional baseline preserves the prior LIFELINE age curve. Active conditions
    add a severity and untreated-duration hazard, then the competing probabilities
    combine as ``1 - (1 - natural) * (1 - illness)``.
    """
    if character.age < 0 or character.age > GameBalance.MAX_AGE:
        raise ValueError("mortality age is outside the configured life span")
    stats = character.stats.clamp_all()
    expected_lifespan = (
        GameBalance.BASE_LIFESPAN_MEAN
        + character.hidden.lifespan_mod
        + round(character.hidden.genetic_health_mod * 0.25)
    )
    age_hazard = 0.001 + max(0, character.age - 55) * 0.00035
    lifespan_hazard = max(0, character.age - expected_lifespan) * 0.018
    health_multiplier = max(0.55, min(1.8, 1.0 + (50 - stats.health) * 0.012))
    fitness_multiplier = max(0.75, min(1.25, 1.0 + (50 - stats.fitness) * 0.005))
    lifestyle_multiplier = (
        1.0
        + stats.addiction / GameBalance.HEALTH_ADDICTION_MORTALITY_DIVISOR
        + (GameBalance.HEALTH_HOMELESS_MORTALITY_ADDITION
           if character.housing_type is HousingType.HOMELESS else 0.0)
        + (GameBalance.HEALTH_PRISON_MORTALITY_ADDITION if character.in_prison else 0.0)
    )
    natural = min(
        0.90,
        max(
            0.0,
            (age_hazard + lifespan_hazard)
            * health_multiplier
            * fitness_multiplier
            * lifestyle_multiplier,
        ),
    )

    illness = 0.0
    for row in conditions:
        if not bool(row.get("is_active", 1)) or str(row.get("status", "active")) not in {"active", "chronic"}:
            continue
        severity = max(1, min(5, int(row.get("severity", 1))))
        untreated = max(0, min(20, int(row.get("years_untreated", 0))))
        illness += (
            severity * GameBalance.HEALTH_DISEASE_SEVERITY_MORTALITY_WEIGHT
            + min(10, untreated) * GameBalance.HEALTH_DISEASE_UNTREATED_MORTALITY_WEIGHT
        )
    illness = min(GameBalance.HEALTH_MAX_ILLNESS_HAZARD, max(0.0, illness))
    if stats.health <= 0:
        return MortalityRisk(0.0, 1.0, 1.0)
    if character.age >= GameBalance.MAX_AGE:
        return MortalityRisk(1.0, 0.0, 1.0)
    total = min(0.95, 1.0 - (1.0 - natural) * (1.0 - illness))
    return MortalityRisk(natural, illness, total)


class HealthService:
    """Transactional care commands and annual progression for all catalog diseases."""

    ACTIVITY_IDS = frozenset(GameBalance.HEALTH_ACTIVITY_EFFECTS)

    def __init__(
        self,
        db: Any,
        rng: RNG,
        economy: EconomyService,
        locks: Optional[UserLockRegistry] = None,
        *,
        clock: Callable[[], float] = time.time,
        data_loader: Optional[DataLoader] = None,
    ) -> None:
        self.db = db
        self.rng = rng.fork("lifeline-health")
        self.economy = economy
        self.locks = locks or UserLockRegistry()
        self.clock = clock
        self.data_loader = data_loader or DataLoader()
        self.repository = HealthRepository(db)
        self.replace_catalog(self.data_loader.load_diseases())

    def replace_catalog(self, document: dict[str, Any]) -> None:
        """Atomically replace the validated disease definitions used by this service."""
        self.diseases = {
            str(row["id"]): dict(row)
            for row in document.get("diseases", [])
            if isinstance(row, dict) and "id" in row
        }
        if len(self.diseases) != len(document.get("diseases", [])) or len(self.diseases) != 28:
            raise ValueError("The health engine requires all 28 unique disease definitions.")

    def disease(self, disease_id: str) -> dict[str, Any]:
        """Return one known catalog definition or raise a user-safe validation error."""
        value = self.diseases.get(str(disease_id).strip().lower())
        if value is None:
            raise ValidationError("Choose a condition from the health catalog.")
        return dict(value)

    def _medical_cost(self, character: Character, base_cents: int, *, insured: bool = True) -> int:
        """Apply country healthcare costs, world inflation, and the insured copay."""
        _, _, healthcare_mod = self.economy.country_modifiers(character.country)
        gross = charge_cents(
            base_cents,
            Decimal(str(character.price_index)) * Decimal(str(healthcare_mod)),
        )
        currently_insured = (
            insured
            and character.has_insurance
            and (character.insurance_paid_through_age is None
                 or character.age <= character.insurance_paid_through_age)
        )
        if currently_insured:
            gross = charge_cents(gross, Decimal(GameBalance.HEALTH_INSURANCE_COPAY_PERCENT) / 100)
        return gross

    @staticmethod
    def _deduct(character: Character, amount: int) -> Character:
        """Pay a medical charge bank-first, then cash, without ever overdrawing."""
        value = validate_cents(amount)
        if value < 0:
            raise ValidationError("Medical charges cannot be negative.")
        if character.cash + character.bank < value:
            raise InsufficientFunds(f"You need {format_cents(value)} in available cash and savings for this care.")
        from_bank = min(character.bank, value)
        remaining = value - from_bank
        return replace(character, bank=character.bank - from_bank, cash=character.cash - remaining)

    async def status(
        self,
        user_id: int,
    ) -> tuple[Character, list[dict[str, Any]], list[dict[str, Any]]]:
        """Return the active life, condition history, and recent care history."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self.economy._load_active(tx, user_id)
                return (
                    character,
                    await self.repository.conditions(tx, character.char_id),
                    await self.repository.recent_visits(tx, character.char_id),
                )

    async def advance_year(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        previous_age: int,
        now: int,
    ) -> HealthYearResult:
        """Progress active diseases and probabilistically introduce age-eligible conditions."""
        age = int(character.age)
        if age != previous_age + 1:
            raise ValueError("health progression expects exactly one age advance")
        rows = await self.repository.conditions(tx, character.char_id)
        by_disease = {str(row["disease_id"]): row for row in rows}
        updated_stats = replace(character.stats)
        messages: list[str] = []

        for disease_id, row in by_disease.items():
            definition = self.diseases.get(disease_id)
            if definition is None:
                continue
            if not bool(row["is_active"]) or str(row["status"]) not in {"active", "chronic"}:
                continue
            severity = max(1, min(5, int(row["severity"])))
            years_untreated = int(row["years_untreated"])
            treated_recently = row.get("last_treated_age") is not None and age <= int(row["last_treated_age"]) + 1
            if not treated_recently:
                years_untreated += 1
            status = str(row["status"])
            active = True
            last_progressed = row.get("last_progressed_age")
            progression_count = int(row.get("progression_count", 0))
            duration = max(0, int(row.get("duration_years", 1)))

            if status != DiseaseStatus.CHRONIC.value and age - int(row["onset_age"]) >= duration:
                status = DiseaseStatus.CURED.value
                active = False
                messages.append("A temporary health condition resolved with time and care.")
            elif (
                not treated_recently
                and years_untreated >= GameBalance.HEALTH_DISEASE_PROGRESSION_AFTER_UNTREATED_YEARS
                and int(last_progressed or -1) < age
                and severity < int(definition["severity_max"])
                and self.rng.random() < GameBalance.HEALTH_DISEASE_PROGRESSION_CHANCE
            ):
                severity += 1
                progression_count += 1
                last_progressed = age
                messages.append("An untreated health condition became more severe; professional care is available.")

            if active:
                updated_stats.health += int(definition["annual_health_delta"])
            await self.repository.update_progression(
                tx,
                condition_id=int(row["condition_id"]),
                severity=severity,
                years_untreated=years_untreated,
                status=status,
                is_active=active,
                last_progressed_age=(int(last_progressed) if last_progressed is not None else None),
                progression_count=progression_count,
                now=now,
            )

        # Carry fractional health loss so repeated addiction/20 damage is not rounded away.
        damage_divisor = float(GameBalance.HEALTH_ADDICTION_ANNUAL_DAMAGE_DIVISOR)
        if not math.isfinite(damage_divisor) or damage_divisor <= 0:
            raise ValueError("addiction health-damage divisor must be finite and positive")
        fractional_damage = float(character.stats.addiction) / damage_divisor
        accumulated_damage = max(0.0, float(character.addiction_health_remainder)) + fractional_damage
        whole_damage = math.floor(accumulated_damage + 1e-9)
        damage_remainder = round(accumulated_damage - whole_damage, 10)
        updated_stats.health -= whole_damage

        age_factor = 1.0 + max(0, age - 30) * GameBalance.HEALTH_DISEASE_AGE_RISK_PER_YEAR
        health_factor = max(0.50, min(1.50, 1.0 + (60 - updated_stats.health) * 0.006))
        fitness_factor = max(0.75, min(1.25, 1.0 + (50 - updated_stats.fitness) * 0.005))
        for disease_id, definition in self.diseases.items():
            if disease_id in by_disease or not int(definition["min_age"]) <= age <= int(definition["max_age"]):
                continue
            base_probability = float(definition["base_probability"])
            probability = min(
                0.25,
                max(0.0, base_probability * GameBalance.HEALTH_DISEASE_ONSET_MULTIPLIER
                    * age_factor * health_factor * fitness_factor),
            )
            if probability <= 0.0 or self.rng.random() >= probability:
                continue
            severity = self.rng.randint(int(definition["severity_min"]), int(definition["severity_max"]))
            chronic = self.rng.random() < float(definition["chronic_probability"])
            duration = 0 if chronic else self.rng.randint(
                int(definition["duration_min_years"]), int(definition["duration_max_years"])
            )
            inserted = await self.repository.add_condition(
                tx,
                char_id=character.char_id,
                disease_id=disease_id,
                severity=severity,
                age=age,
                duration_years=duration,
                chronic=chronic,
                now=now,
            )
            if inserted:
                updated_stats.health += int(definition["annual_health_delta"])
                messages.append("You began experiencing symptoms; an undiagnosed condition is available for a checkup.")

        updated = replace(
            character,
            stats=updated_stats.clamp_all(),
            addiction_health_remainder=damage_remainder,
        )
        active = await self.repository.conditions(tx, character.char_id, active_only=True)
        return HealthYearResult(updated, tuple(messages), tuple(active))

    def resolve_mortality(
        self,
        character: Character,
        conditions: list[dict[str, Any]] | tuple[dict[str, Any], ...],
        *,
        now: int,
    ) -> tuple[Character, Optional[str], MortalityRisk]:
        """Resolve one annual death draw and select a cause from its competing hazards."""
        risk = calculate_mortality_risk(character, conditions)
        cause: Optional[str] = None
        if character.age >= GameBalance.MAX_AGE:
            cause = "natural causes"
        elif character.stats.health <= 0:
            cause = self._illness_cause(conditions)
        elif self.rng.random() < risk.total_probability:
            if risk.illness_hazard > 0 and risk.natural_hazard > 0:
                selected = self.rng.weighted_choice(
                    ("illness", "natural causes"),
                    (risk.illness_hazard, risk.natural_hazard),
                )
                cause = self._illness_cause(conditions) if selected == "illness" else "natural causes"
            elif risk.illness_hazard > 0:
                cause = self._illness_cause(conditions)
            else:
                cause = "natural causes"
        if cause is None:
            return replace(character, is_alive=True, died_at=None, death_age=None, death_cause=None), None, risk
        dead = replace(
            character,
            is_alive=False,
            died_at=now,
            death_age=character.age,
            death_cause=cause,
        )
        return dead, cause, risk

    def _illness_cause(self, conditions: list[dict[str, Any]] | tuple[dict[str, Any], ...]) -> str:
        """Choose a PG-13 disease name from active condition severity weights."""
        active = [
            row for row in conditions
            if bool(row.get("is_active", 1)) and str(row.get("status", "active")) in {"active", "chronic"}
        ]
        if not active:
            return "illness"
        weights: list[float] = []
        names: list[str] = []
        for row in active:
            disease = self.diseases.get(str(row["disease_id"]))
            if disease is None:
                continue
            weights.append(max(1, int(row.get("severity", 1))) * (1.0 + min(10, int(row.get("years_untreated", 0))) * 0.1))
            names.append(str(disease["name"]))
        if not names:
            return "illness"
        return f"illness: {self.rng.weighted_choice(names, weights)}"

    async def doctor_visit(
        self,
        user_id: int,
        disease_id: Optional[str] = None,
    ) -> HealthActionResult:
        """Diagnose and modestly treat one condition, or provide a preventive checkup."""
        requested = str(disease_id).strip().lower() if disease_id else None
        if requested:
            self.disease(requested)
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self.economy._load_active(tx, user_id)
                if await self.repository.visit_used(tx, character.char_id, character.age, "doctor"):
                    raise ValidationError("A doctor visit has already been used this in-game year.")
                active = await self.repository.conditions(tx, character.char_id, active_only=True)
                row = next((item for item in active if str(item["disease_id"]) == requested), None) if requested else None
                if requested and row is None:
                    raise ValidationError("No active condition with that catalog ID was found for this life.")
                if row is None and not requested and active:
                    row = next((item for item in active if not bool(item["diagnosed"])), active[0])
                cost = self._medical_cost(character, GameBalance.HEALTH_DOCTOR_FEE_CENTS)
                updated = self._deduct(character, cost)
                if row is None:
                    stats = replace(
                        updated.stats,
                        health=min(100, updated.stats.health + 2),
                        stress=max(0, updated.stats.stress - 2),
                    ).clamp_all()
                    updated = replace(updated, stats=stats)
                    message = f"Preventive checkup complete for {format_cents(cost)}; health +2, stress −2."
                    outcome = {"result": "preventive_checkup", "health_delta": 2, "stress_delta": -2}
                    visit_disease = None
                else:
                    definition = self.disease(str(row["disease_id"]))
                    new_severity = max(0, int(row["severity"]) - 1)
                    status = "cured" if new_severity == 0 else str(row["status"])
                    await self.repository.diagnose_and_treat(
                        tx,
                        condition_id=int(row["condition_id"]),
                        severity=new_severity,
                        status=status,
                        is_active=new_severity > 0,
                        age=character.age,
                        now=now,
                    )
                    updated = replace(
                        updated,
                        stats=replace(updated.stats, health=min(100, updated.stats.health + 2)).clamp_all(),
                    )
                    action = "resolved" if new_severity == 0 else f"severity {new_severity}"
                    message = f"Doctor diagnosed {definition['name']} and provided care ({action}) for {format_cents(cost)}."
                    outcome = {"result": "diagnosed_and_treated", "severity_before": int(row["severity"]),
                               "severity_after": new_severity, "diagnosed": True}
                    visit_disease = str(row["disease_id"])
                updated = await self.economy._save(tx, updated, version)
                await self.repository.record_visit(
                    tx, char_id=character.char_id, age=character.age, visit_type="doctor",
                    disease_id=visit_disease, cost_cents=cost, outcome=outcome, now=now,
                )
                return HealthActionResult(updated, message, cost, visit_disease)

    async def hospital_visit(self, user_id: int, disease_id: str) -> HealthActionResult:
        """Provide urgent, stronger treatment for one active condition."""
        selected = self.disease(disease_id)
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self.economy._load_active(tx, user_id)
                if await self.repository.visit_used(tx, character.char_id, character.age, "hospital"):
                    raise ValidationError("A hospital visit has already been used this in-game year.")
                row = await self.repository.condition(tx, character.char_id, str(selected["id"]))
                if row is None or not bool(row["is_active"]):
                    raise ValidationError("Hospital care needs an active condition from this life.")
                cost = self._medical_cost(character, GameBalance.HEALTH_HOSPITAL_FEE_CENTS)
                updated = self._deduct(character, cost)
                severity = max(0, int(row["severity"]) - 2)
                status = "cured" if severity == 0 else str(row["status"])
                await self.repository.diagnose_and_treat(
                    tx, condition_id=int(row["condition_id"]), severity=severity,
                    status=status, is_active=severity > 0, age=character.age, now=now,
                )
                updated = replace(
                    updated,
                    stats=replace(updated.stats, health=min(100, updated.stats.health + 8)).clamp_all(),
                )
                updated = await self.economy._save(tx, updated, version)
                outcome = {"result": "hospital_treatment", "severity_before": int(row["severity"]),
                           "severity_after": severity, "diagnosed": True}
                await self.repository.record_visit(
                    tx, char_id=character.char_id, age=character.age, visit_type="hospital",
                    disease_id=str(selected["id"]), cost_cents=cost, outcome=outcome, now=now,
                )
                wording = "resolved" if severity == 0 else f"severity reduced to {severity}"
                return HealthActionResult(
                    updated,
                    f"Hospital treatment for {selected['name']} {wording}; health +8. Cost {format_cents(cost)}.",
                    cost,
                    str(selected["id"]),
                )

    async def therapy_visit(self, user_id: int) -> HealthActionResult:
        """Offer a non-stigmatizing wellbeing visit and treat one active mental-health condition."""
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self.economy._load_active(tx, user_id)
                if await self.repository.visit_used(tx, character.char_id, character.age, "therapy"):
                    raise ValidationError("A therapy visit has already been used this in-game year.")
                active = await self.repository.conditions(tx, character.char_id, active_only=True)
                row = next((item for item in active
                            if self.diseases.get(str(item["disease_id"]), {}).get("category") == "mental_health"), None)
                cost = self._medical_cost(character, GameBalance.HEALTH_THERAPY_FEE_CENTS)
                updated = self._deduct(character, cost)
                disease_id: Optional[str] = None
                outcome: dict[str, Any] = {"result": "wellbeing_support", "stress_delta": -8, "happiness_delta": 4}
                if row is not None:
                    disease_id = str(row["disease_id"])
                    new_severity = max(0, int(row["severity"]) - 1)
                    status = "cured" if new_severity == 0 else str(row["status"])
                    await self.repository.diagnose_and_treat(
                        tx, condition_id=int(row["condition_id"]), severity=new_severity,
                        status=status, is_active=new_severity > 0, age=character.age, now=now,
                    )
                    outcome.update({"disease_id": disease_id, "severity_after": new_severity, "diagnosed": True})
                updated = replace(
                    updated,
                    stats=replace(
                        updated.stats,
                        happiness=min(100, updated.stats.happiness + 4),
                        stress=max(0, updated.stats.stress - 8),
                    ).clamp_all(),
                )
                updated = await self.economy._save(tx, updated, version)
                await self.repository.record_visit(
                    tx, char_id=character.char_id, age=character.age, visit_type="therapy",
                    disease_id=disease_id, cost_cents=cost, outcome=outcome, now=now,
                )
                label = "and supported an active condition" if row is not None else ""
                return HealthActionResult(
                    updated,
                    f"Wellbeing visit {label}; happiness +4, stress −8. Cost {format_cents(cost)}.",
                    cost,
                    disease_id,
                )

    async def surgery(
        self,
        user_id: int,
        disease_id: str | None = None,
        procedure: str = "medical",
    ) -> HealthActionResult:
        """Perform one validated medical or elective plastic-surgery action."""
        selected: dict[str, Any] | None = None
        procedure_id = str(procedure).strip().lower()
        if procedure_id == "medical":
            if disease_id is None or not str(disease_id).strip():
                raise ValidationError("Choose an active condition for medical surgery.")
            selected = self.disease(disease_id)
            if not bool(selected["treatable"]) or str(selected["category"]) == "mental_health":
                raise ValidationError("That condition is not eligible for this elective procedure.")
        elif procedure_id == "plastic":
            if disease_id is not None and str(disease_id).strip():
                raise ValidationError("Plastic surgery does not use a condition ID.")
        else:
            raise ValidationError("Choose medical or plastic surgery.")

        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self.economy._load_active(tx, user_id)
                if await self.repository.visit_used(tx, character.char_id, character.age, "surgery"):
                    raise ValidationError("Surgery has already been used this in-game year.")

                if procedure_id == "plastic":
                    if character.age < GameBalance.HEALTH_PLASTIC_SURGERY_MIN_AGE:
                        raise ValidationError(
                            f"Plastic surgery is available only from age {GameBalance.HEALTH_PLASTIC_SURGERY_MIN_AGE}."
                        )
                    if character.in_prison:
                        raise ValidationError("Plastic surgery is unavailable while in prison.")
                    if character.stats.looks >= GameBalance.STAT_MAX:
                        raise ValidationError("There is no appearance benefit available right now.")
                    cost = self._medical_cost(
                        character, GameBalance.HEALTH_PLASTIC_SURGERY_FEE_CENTS, insured=False
                    )
                    updated = self._deduct(character, cost)
                    looks_before = character.stats.looks
                    looks_after = min(
                        GameBalance.STAT_MAX,
                        looks_before + GameBalance.HEALTH_PLASTIC_SURGERY_LOOKS_BONUS,
                    )
                    updated = replace(
                        updated,
                        stats=replace(updated.stats, looks=looks_after).clamp_all(),
                    )
                    updated = await self.economy._save(tx, updated, version)
                    outcome = {
                        "result": "plastic_surgery_success",
                        "looks_before": looks_before,
                        "looks_after": looks_after,
                        "insured": False,
                    }
                    await self.repository.record_visit(
                        tx, char_id=character.char_id, age=character.age, visit_type="surgery",
                        disease_id=None, cost_cents=cost, outcome=outcome, now=now,
                    )
                    return HealthActionResult(
                        updated,
                        f"Plastic surgery improved looks from {looks_before} to {looks_after}. "
                        f"Cosmetic surgery is not covered by insurance; cost {format_cents(cost)}.",
                        cost,
                    )

                assert selected is not None
                row = await self.repository.condition(tx, character.char_id, str(selected["id"]))
                if row is None or not bool(row["is_active"]):
                    raise ValidationError("Surgery needs an active condition from this life.")
                severity = int(row["severity"])
                if severity < 3:
                    raise ValidationError("Elective surgery is available only for severity 3 or higher conditions.")
                base = GameBalance.HEALTH_SURGERY_BASE_FEE_CENTS + severity * GameBalance.HEALTH_SURGERY_PER_SEVERITY_CENTS
                cost = self._medical_cost(character, base)
                updated = self._deduct(character, cost)
                await self.repository.diagnose_and_treat(
                    tx, condition_id=int(row["condition_id"]), severity=0,
                    status="cured", is_active=False, age=character.age, now=now,
                )
                updated = replace(
                    updated,
                    stats=replace(updated.stats, health=min(100, updated.stats.health + 5)).clamp_all(),
                )
                updated = await self.economy._save(tx, updated, version)
                outcome = {"result": "surgery_success", "severity_before": severity, "severity_after": 0}
                await self.repository.record_visit(
                    tx, char_id=character.char_id, age=character.age, visit_type="surgery",
                    disease_id=str(selected["id"]), cost_cents=cost, outcome=outcome, now=now,
                )
                return HealthActionResult(
                    updated,
                    f"Surgery resolved {selected['name']}; health +5. Cost {format_cents(cost)}.",
                    cost,
                    str(selected["id"]),
                )

    async def set_insurance(self, user_id: int, enabled: bool) -> HealthActionResult:
        """Purchase one prepaid year of coverage or cancel future renewal."""
        if not isinstance(enabled, bool):
            raise ValidationError("Insurance must be enabled or cancelled.")
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self.economy._load_active(tx, user_id)
                if not enabled:
                    if not character.has_insurance:
                        raise ValidationError("There is no active policy to cancel.")
                    updated = replace(character, has_insurance=False)
                    message = "Insurance cancelled immediately. The paid premium is not refundable."
                    cost = 0
                    outcome = {"result": "cancelled"}
                else:
                    if character.has_insurance and (
                        character.insurance_paid_through_age is None
                        or character.age <= character.insurance_paid_through_age
                    ):
                        raise ValidationError("An insurance policy is already active for this year.")
                    _, _, healthcare_mod = self.economy.country_modifiers(character.country)
                    cost = charge_cents(
                        GameBalance.ANNUAL_HEALTH_INSURANCE_PREMIUM_CENTS,
                        Decimal(str(character.price_index)) * Decimal(str(healthcare_mod)),
                    )
                    updated = self._deduct(character, cost)
                    updated = replace(
                        updated,
                        has_insurance=True,
                        insurance_paid_through_age=character.age + 1,
                    )
                    message = (
                        f"One year of health coverage purchased through age {character.age + 1}; "
                        f"premium {format_cents(cost)}."
                    )
                    outcome = {"result": "purchased", "paid_through_age": character.age + 1}
                updated = await self.economy._save(tx, updated, version)
                await self.repository.record_visit(
                    tx, char_id=character.char_id, age=character.age, visit_type="insurance",
                    disease_id=None, cost_cents=cost, outcome=outcome, now=now,
                )
                return HealthActionResult(updated, message, cost)

    async def activity(self, user_id: int, activity_id: str) -> HealthActionResult:
        """Apply one documented activity's exact stat changes once per in-game year."""
        activity = str(activity_id).strip().lower()
        effect = GameBalance.HEALTH_ACTIVITY_EFFECTS.get(activity)
        if effect is None:
            raise ValidationError("Choose walk, run, gym, mindfulness, or sports.")
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self.economy._load_active(tx, user_id)
                if character.in_prison:
                    raise ValidationError("Outdoor and facility activities are unavailable while imprisoned.")
                if await self.economy.repository.activity_used(tx, character.char_id, character.age, activity):
                    raise ValidationError("That activity has already been used this in-game year.")
                _, cost_mod, _ = self.economy.country_modifiers(character.country)
                cost = charge_cents(
                    int(effect["cost_cents"]),
                    Decimal(str(character.price_index)) * Decimal(str(cost_mod)),
                )
                updated = self._deduct(character, cost)
                stats = replace(
                    updated.stats,
                    health=max(0, min(100, updated.stats.health + int(effect["health"]))),
                    fitness=max(0, min(100, updated.stats.fitness + int(effect["fitness"]))),
                    happiness=max(0, min(100, updated.stats.happiness + int(effect["happiness"]))),
                    stress=max(0, min(100, updated.stats.stress + int(effect["stress"]))),
                ).clamp_all()
                updated = replace(updated, stats=stats)
                await self.economy.repository.record_activity(tx, character.char_id, character.age, activity, now)
                updated = await self.economy._save(tx, updated, version)
                deltas = {key: int(effect[key]) for key in ("health", "fitness", "happiness", "stress") if int(effect[key]) != 0}
                outcome = {"result": "activity", "activity_id": activity, "stat_changes": deltas}
                await self.repository.record_visit(
                    tx, char_id=character.char_id, age=character.age, visit_type="activity",
                    disease_id=None, cost_cents=cost, outcome=outcome, now=now,
                )
                changes = ", ".join(f"{key} {'+' if value > 0 else ''}{value}" for key, value in deltas.items())
                return HealthActionResult(
                    updated,
                    f"Activity complete: {activity.title()} ({changes or 'rest'}). Cost {format_cents(cost)}.",
                    cost,
                )
