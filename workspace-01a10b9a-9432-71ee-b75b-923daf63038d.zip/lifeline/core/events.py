"""Data-driven annual life events and transactional choice resolution."""
from __future__ import annotations

import json
import logging
import secrets
import time
from dataclasses import dataclass, replace
from typing import Any, Optional

import aiosqlite

from .config import GameBalance
from .data_loader import DataLoader
from .errors import ConcurrentUpdate, GameError, PendingEventNotFound, StaleEvent, ValidationError
from .locks import UserLockRegistry
from .models import Character, EventPolarity, Stats
from .money import MAX_CENTS, validate_cents
from .rng import RNG
from .validators import validate_event_catalog

logger = logging.getLogger("lifeline.events")
_ALLOWED_EVENT_STATS = {
    "health", "happiness", "smarts", "looks", "fitness", "karma",
    "stress", "addiction", "fame",
}


def evaluate_event_effects(character: Character, effects: dict[str, Any]) -> tuple[Character, dict[str, int], int]:
    """Safely apply only bounded stats and integer-cent cash effects to a character."""
    if not isinstance(effects, dict) or set(effects) - {"stats", "cash_cents"}:
        raise ValidationError("This event contains an unsupported effect.")
    raw_stats = effects.get("stats", {})
    if not isinstance(raw_stats, dict):
        raise ValidationError("This event contains invalid stat effects.")
    updated_values = character.stats.to_dict()
    for stat_name, delta in raw_stats.items():
        if stat_name not in _ALLOWED_EVENT_STATS or isinstance(delta, bool) or not isinstance(delta, int) or not -25 <= delta <= 25:
            raise ValidationError("This event contains an invalid stat change.")
        updated_values[stat_name] = int(updated_values[stat_name]) + delta
    updated_stats = Stats.from_dict(updated_values).clamp_all()
    actual_changes = {
        name: int(getattr(updated_stats, name) - getattr(character.stats, name))
        for name in raw_stats
        if getattr(updated_stats, name) != getattr(character.stats, name)
    }
    raw_cash = effects.get("cash_cents", 0)
    if isinstance(raw_cash, bool) or not isinstance(raw_cash, int) or not -100_000_000 <= raw_cash <= 100_000_000:
        raise ValidationError("This event contains an invalid cash change.")
    requested_cash = validate_cents(int(character.cash) + raw_cash)
    new_cash = max(0, min(MAX_CENTS, requested_cash))
    cash_change = new_cash - int(character.cash)
    return replace(character, stats=updated_stats, cash=new_cash), actual_changes, cash_change


@dataclass(frozen=True, slots=True)
class EventOutcome:
    """One whitelisted, weighted result for a player-selected response."""

    id: str
    weight: float
    probability: Optional[float]
    effects: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        """Serialize the outcome as inert JSON-compatible data."""
        result: dict[str, Any] = {"id": self.id, "weight": self.weight, "effects": dict(self.effects)}
        if self.probability is not None:
            result["probability"] = self.probability
        return result


@dataclass(frozen=True, slots=True)
class EventChoice:
    """A player-selectable response with one or more weighted safe outcomes."""

    id: str
    label: str
    description: str
    outcomes: tuple[EventOutcome, ...]

    @property
    def stat_effects(self) -> dict[str, int]:
        """Compatibility view of the first outcome's stat deltas."""
        if not self.outcomes:
            return {}
        return dict(self.outcomes[0].effects.get("stats", {}))

    def to_dict(self) -> dict[str, Any]:
        """Serialize the choice and its weighted outcomes."""
        return {
            "id": self.id,
            "label": self.label,
            "description": self.description,
            "outcomes": [outcome.to_dict() for outcome in self.outcomes],
        }


@dataclass(frozen=True, slots=True)
class EventTemplate:
    """Validated immutable definition of a data-file life event."""

    id: str
    title: str
    description: str
    category: str
    polarity: EventPolarity
    min_age: int
    max_age: int
    weight: float
    repeatable: bool
    once_per_life: bool
    cooldown_years: int
    event_type: str
    context: dict[str, Any]
    wealth_classes: tuple[str, ...]
    countries: tuple[str, ...]
    choices: tuple[EventChoice, ...]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "EventTemplate":
        """Create a runtime template from a fully validated event record."""
        conditions = data.get("conditions", {})
        choices: list[EventChoice] = []
        for item in data["choices"]:
            raw_outcomes = item.get("outcomes")
            if raw_outcomes is None:
                raw_outcomes = [{"id": "legacy_result", "weight": 1.0, "effects": item.get("effects", {})}]
            outcomes = tuple(
                EventOutcome(
                    id=str(outcome["id"]),
                    weight=float(outcome["weight"]),
                    probability=(float(outcome["probability"]) if "probability" in outcome else None),
                    effects=dict(outcome.get("effects", {})),
                )
                for outcome in raw_outcomes
            )
            choices.append(EventChoice(
                id=item["id"],
                label=item["label"],
                description=item.get("description", ""),
                outcomes=outcomes,
            ))
        once_per_life = bool(data.get("once_per_life", not data.get("repeatable", False)))
        return cls(
            id=data["id"],
            title=str(data.get("title", data.get("text", data["id"]))),
            description=str(data.get("description", data.get("text", ""))),
            category=data["category"],
            polarity=EventPolarity(data["polarity"]),
            min_age=int(conditions.get("min_age", data.get("min_age", 0))),
            max_age=int(conditions.get("max_age", data.get("max_age", 120))),
            weight=float(data["weight"]),
            repeatable=bool(data.get("repeatable", not once_per_life)),
            once_per_life=once_per_life,
            cooldown_years=int(data.get("cooldown_years", 0)),
            event_type=str(data.get("type", "choice")),
            context=dict(data.get("context", {})),
            wealth_classes=tuple(conditions.get("wealth_classes", data.get("wealth_classes", ()))),
            countries=tuple(conditions.get("countries", data.get("countries", ()))),
            choices=tuple(choices),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return a validated pending-event snapshot with Stage 11 schema fields."""
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "text": self.description,
            "category": self.category,
            "type": self.event_type,
            "polarity": self.polarity.value,
            "min_age": self.min_age,
            "max_age": self.max_age,
            "conditions": {
                "min_age": self.min_age,
                "max_age": self.max_age,
                "wealth_classes": list(self.wealth_classes),
                "countries": list(self.countries),
            },
            "weight": self.weight,
            "repeatable": self.repeatable,
            "once_per_life": self.once_per_life,
            "cooldown_years": self.cooldown_years,
            "wealth_classes": list(self.wealth_classes),
            "countries": list(self.countries),
            "context": dict(self.context),
            "choices": [choice.to_dict() for choice in self.choices],
        }


@dataclass(frozen=True, slots=True)
class EventPrompt:
    """Persisted event awaiting a choice from its character owner."""

    char_id: int
    age: int
    nonce: str
    created_at: int
    event: EventTemplate


@dataclass(frozen=True, slots=True)
class EventResolution:
    """Outcome of resolving one pending event."""

    character: Character
    event: EventTemplate
    choice: EventChoice
    outcome: EventOutcome
    stat_changes: dict[str, int]
    cash_change_cents: int
    resolved_at: int


class EventEngine:
    """Select, persist, retrieve, and atomically resolve annual choice events."""

    def __init__(
        self,
        db: Any,
        rng: RNG,
        locks: Optional[UserLockRegistry] = None,
        *,
        data_loader: Optional[DataLoader] = None,
        event_chance: Optional[float] = None,
    ) -> None:
        self.db = db
        self.rng = rng
        self.locks = locks or UserLockRegistry()
        self.event_chance = (
            GameBalance.ANNUAL_EVENT_CHANCE if event_chance is None else float(event_chance)
        )
        if not 0.0 <= self.event_chance <= 1.0:
            raise ValueError("event_chance must be between 0 and 1")
        catalog_data = (data_loader or DataLoader()).load_events()
        validate_event_catalog(catalog_data)
        self.catalog = tuple(EventTemplate.from_dict(item) for item in catalog_data["events"])
        self._by_id = {event.id: event for event in self.catalog}

    def replace_catalog(self, document: dict[str, Any]) -> None:
        """Validate and atomically replace the in-memory event definitions."""
        validate_event_catalog(document)
        catalog = tuple(EventTemplate.from_dict(item) for item in document["events"])
        by_id = {event.id: event for event in catalog}
        self.catalog = catalog
        self._by_id = by_id

    async def maybe_create_pending(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        now: int,
    ) -> Optional[EventPrompt]:
        """Roll an annual event and save its full definition in the same transaction."""
        if not character.is_alive or self.rng.random() >= self.event_chance:
            return None

        cursor = await tx.execute(
            """SELECT event_key, MAX(age) AS last_age FROM character_events
               WHERE char_id = ? GROUP BY event_key""",
            (character.char_id,),
        )
        last_used = {str(row["event_key"]): int(row["last_age"]) for row in await cursor.fetchall()}
        candidates = [
            event for event in self.catalog
            if event.event_type == "choice"
            and event.min_age <= character.age <= event.max_age
            and (not event.wealth_classes or character.wealth_class in event.wealth_classes)
            and (not event.countries or character.country.lower() in event.countries)
            and not (event.once_per_life and event.id in last_used)
            and (
                event.id not in last_used
                or event.cooldown_years == 0
                or character.age - last_used[event.id] >= event.cooldown_years
            )
        ]
        if not candidates:
            return None

        event = self.rng.weighted_choice(candidates, [item.weight for item in candidates])
        nonce = secrets.token_urlsafe(12)
        prompt = EventPrompt(
            char_id=character.char_id,
            age=character.age,
            nonce=nonce,
            created_at=int(now),
            event=event,
        )
        await tx.execute(
            """INSERT INTO pending_events
                   (char_id, event_key, age, nonce, context_json, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                prompt.char_id,
                event.id,
                prompt.age,
                prompt.nonce,
                json.dumps(event.to_dict(), ensure_ascii=False, separators=(",", ":")),
                prompt.created_at,
            ),
        )
        return prompt

    async def get_pending_event(self, user_id: int) -> EventPrompt:
        """Return the unresolved event for a user's active life."""
        row = await self.db.fetchone(
            """SELECT p.char_id, p.event_key, p.age, p.nonce, p.context_json, p.created_at
               FROM pending_events AS p
               JOIN characters AS c ON c.char_id = p.char_id
               WHERE c.user_id = ? AND c.is_alive = 1
               LIMIT 1""",
            (user_id,),
        )
        if row is None:
            raise PendingEventNotFound()
        return self._prompt_from_row(row)

    async def resolve_choice(
        self,
        user_id: int,
        nonce: str,
        choice_id: str,
    ) -> EventResolution:
        """Apply an event choice exactly once and write its audit/history records."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                cursor = await tx.execute(
                    """SELECT p.char_id, p.event_key, p.age, p.nonce, p.context_json,
                              p.created_at, c.data_json, c.version
                       FROM pending_events AS p
                       JOIN characters AS c ON c.char_id = p.char_id
                       WHERE c.user_id = ? AND c.is_alive = 1 AND p.nonce = ?
                       LIMIT 1""",
                    (user_id, nonce),
                )
                row = await cursor.fetchone()
                if row is None:
                    cursor = await tx.execute(
                        """SELECT 1 FROM pending_events AS p
                           JOIN characters AS c ON c.char_id = p.char_id
                           WHERE c.user_id = ? AND c.is_alive = 1 LIMIT 1""",
                        (user_id,),
                    )
                    if await cursor.fetchone():
                        raise StaleEvent()
                    raise PendingEventNotFound()

                prompt = self._prompt_from_row(row)
                choice = next((item for item in prompt.event.choices if item.id == choice_id), None)
                if choice is None:
                    raise ValidationError("That choice is not part of this event.")

                character = Character.from_dict(json.loads(row["data_json"]))
                expected_version = int(row["version"])
                character.version = expected_version
                outcome = self.rng.weighted_choice(
                    choice.outcomes,
                    [item.weight for item in choice.outcomes],
                )
                changed_character, actual_changes, cash_change = evaluate_event_effects(
                    character, outcome.effects
                )
                resolved_at = int(time.time())
                updated_character = replace(
                    changed_character,
                    version=expected_version + 1,
                )
                stats_json = json.dumps(updated_character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
                updated_data = json.dumps(
                    updated_character.to_dict(),
                    ensure_ascii=False,
                    separators=(",", ":"),
                    allow_nan=False,
                )
                update_cursor = await tx.execute(
                    """UPDATE characters
                       SET stats_json = ?, version = ?, data_json = ?
                       WHERE char_id = ? AND version = ? AND is_alive = 1""",
                    (
                        stats_json,
                        updated_character.version,
                        updated_data,
                        updated_character.char_id,
                        expected_version,
                    ),
                )
                if update_cursor.rowcount != 1:
                    raise ConcurrentUpdate()

                effects_json = json.dumps(
                    {"stats": actual_changes, "cash_cents": cash_change, "outcome_id": outcome.id},
                    separators=(",", ":"),
                    allow_nan=False,
                )
                await tx.execute(
                    """INSERT INTO character_events
                           (char_id, event_key, choice_id, age, effects_json, resolved_at)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (
                        prompt.char_id,
                        prompt.event.id,
                        choice.id,
                        prompt.age,
                        effects_json,
                        resolved_at,
                    ),
                )
                delete_cursor = await tx.execute(
                    "DELETE FROM pending_events WHERE char_id = ? AND nonce = ?",
                    (prompt.char_id, nonce),
                )
                if delete_cursor.rowcount != 1:
                    raise StaleEvent()
                await tx.execute(
                    """INSERT INTO life_logs (char_id, age, category, text, importance, created_at)
                       VALUES (?, ?, 'event', ?, 2, ?)""",
                    (
                        prompt.char_id,
                        prompt.age,
                        f"{character.name} chose ‘{choice.label}’ during {prompt.event.title}.",
                        resolved_at,
                    ),
                )
                return EventResolution(
                    character=updated_character,
                    event=prompt.event,
                    choice=choice,
                    outcome=outcome,
                    stat_changes=actual_changes,
                    cash_change_cents=cash_change,
                    resolved_at=resolved_at,
                )

    def _prompt_from_row(self, row: Any) -> EventPrompt:
        try:
            event_data = json.loads(row["context_json"])
            validate_event_catalog({"schema_version": 1, "events": [event_data]})
            event = EventTemplate.from_dict(event_data)
            if event.id != row["event_key"]:
                raise ValueError("snapshot event key mismatch")
            return EventPrompt(
                char_id=int(row["char_id"]),
                age=int(row["age"]),
                nonce=str(row["nonce"]),
                created_at=int(row["created_at"]),
                event=event,
            )
        except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
            logger.exception("Could not restore a pending event snapshot")
            raise GameError("This event could not be loaded. Please contact a bot administrator.") from exc
