"""Stage 7 fictional crime, sentencing, laundering, audits, and prison rules.

Crime outcomes are abstract game rolls only. This module contains no real-world
procedural guidance; all persistence is delegated to ``CrimeRepository``.
"""
from __future__ import annotations

import json
import logging
import math
import secrets
import time
from dataclasses import dataclass, replace
from decimal import Decimal
from typing import Any, Callable, Optional

import aiosqlite

from .config import GameBalance
from .economy import progressive_income_tax, _country_modifiers
from .errors import (
    CharacterDead,
    CharacterInPrison,
    CharacterNotFound,
    CharacterNotInPrison,
    CrimeActionAlreadyUsed,
    CrimeLimitReached,
    CrimeSessionExpired,
    EducationRequirementError,
    InsufficientFunds,
    PendingEventExists,
    TaxDecisionNotFound,
    TrialNotFound,
    ValidationError,
)
from .family import FamilyService
from .locks import UserLockRegistry
from .models import Character, HousingType, Stats
from .money import charge_cents, dollars_to_cents, format_cents, payout_cents, scale_cents
from .repositories.crime import CrimeRepository
from .rng import RNG
from .data_loader import DataLoader

logger = logging.getLogger("lifeline.crime")

LAWYER_CONVICTION_CHANCES: dict[str, float] = {
    "public": GameBalance.CRIME_PUBLIC_COUNSEL_CONVICTION_PERCENT,
    "standard": GameBalance.CRIME_STANDARD_COUNSEL_CONVICTION_PERCENT,
    "elite": GameBalance.CRIME_ELITE_COUNSEL_CONVICTION_PERCENT,
}
LAWYER_FEES: dict[str, int] = {
    "public": 0,
    "standard": dollars_to_cents(10_000),
    "elite": dollars_to_cents(100_000),
}


def lawyer_conviction_chance(tier: str) -> float:
    """Return the configured conviction probability for one counsel tier."""
    chances = {
        "public": GameBalance.CRIME_PUBLIC_COUNSEL_CONVICTION_PERCENT,
        "standard": GameBalance.CRIME_STANDARD_COUNSEL_CONVICTION_PERCENT,
        "elite": GameBalance.CRIME_ELITE_COUNSEL_CONVICTION_PERCENT,
    }
    selected = str(tier).lower()
    if selected not in chances:
        raise ValueError("unknown counsel tier")
    return float(chances[selected])
CAREER_RANKS: tuple[tuple[str, int, int], ...] = (
    ("Street Dealer", 0, dollars_to_cents(10_000)),
    ("Hustler", 20, dollars_to_cents(25_000)),
    ("Crew Leader", 40, dollars_to_cents(50_000)),
    ("Enforcer", 60, dollars_to_cents(100_000)),
    ("Crime Boss", 80, dollars_to_cents(250_000)),
    ("Kingpin", 95, dollars_to_cents(500_000)),
)
TAX_EVENT_INCOME_THRESHOLD = dollars_to_cents(100_000)
LAUNDERING_ANNUAL_CAP = dollars_to_cents(50_000)
MAX_GAME_AGE = 120


@dataclass(frozen=True, slots=True)
class CrimeDefinition:
    """Validated, immutable crime data used by the engine and command UI."""

    id: str
    name: str
    description: str
    min_age: int
    base_success: Optional[float]
    loot_min_dollars: int
    loot_max_dollars: int
    base_catch: Optional[float]
    sentence_min: int
    sentence_max: Optional[int]
    life_sentence: bool
    violence: bool
    success_stat: str
    requires_job: bool
    commit_enabled: bool
    salary_loot_min_fraction: float = 0.0
    salary_loot_max_fraction: float = 0.0
    salary_loot_multiplier: int = 1

    @classmethod
    def from_dict(cls, values: dict[str, Any]) -> "CrimeDefinition":
        """Create a typed definition from a validated JSON object."""
        raw_max = values["sentence_max"]
        return cls(
            id=str(values["id"]),
            name=str(values["name"]),
            description=str(values["description"]),
            min_age=int(values["min_age"]),
            base_success=None if values["base_success"] is None else float(values["base_success"]),
            loot_min_dollars=int(values["loot_min_dollars"]),
            loot_max_dollars=int(values["loot_max_dollars"]),
            base_catch=None if values["base_catch"] is None else float(values["base_catch"]),
            sentence_min=int(values["sentence_min"]),
            sentence_max=None if raw_max == "life" else int(raw_max),
            life_sentence=raw_max == "life",
            violence=bool(values["violence"]),
            success_stat=str(values["success_stat"]),
            requires_job=bool(values["requires_job"]),
            commit_enabled=bool(values["commit_enabled"]),
            salary_loot_min_fraction=float(values.get("salary_loot_min_fraction", 0.0)),
            salary_loot_max_fraction=float(values.get("salary_loot_max_fraction", 0.0)),
            salary_loot_multiplier=int(values.get("salary_loot_multiplier", 1)),
        )


@dataclass(frozen=True, slots=True)
class CrimePreview:
    """Risk summary persisted before a crime can be confirmed."""

    crime_id: str
    crime_name: str
    description: str
    age: int
    nonce: str
    success_chance: float
    catch_chance: float
    failed_catch_chance: float
    loot_min: int
    loot_max: int
    expires_at: int


@dataclass(frozen=True, slots=True)
class CrimeAttemptOutcome:
    """Result of one confirmed fictional crime attempt."""

    crime_id: str
    crime_name: str
    success: bool
    caught: bool
    loot: int
    success_chance: float
    catch_chance: float
    message: str
    trial: Optional["TrialPrompt"] = None


@dataclass(frozen=True, slots=True)
class TrialPrompt:
    """Owner/nonce-bound lawyer selection for one pending case."""

    nonce: str
    attempt_id: int
    crime_id: str
    crime_name: str
    age: int
    source: str


@dataclass(frozen=True, slots=True)
class TrialResolution:
    """Verdict, sentence, fine, and updated life after lawyer selection."""

    character: Character
    crime_name: str
    lawyer_tier: str
    conviction_chance: float
    convicted: bool
    sentence_years: int
    life_sentence: bool
    record_sealed: bool
    fine_paid: int
    message: str


@dataclass(frozen=True, slots=True)
class TaxEvasionPrompt:
    """Persistent annual high-earner tax decision."""

    nonce: str
    age: int
    tax_due: int
    paid_amount: int
    prepaid: bool


@dataclass(frozen=True, slots=True)
class CrimeYearResult:
    """Character, journal messages, and any decision produced by yearly step 12."""

    character: Character
    messages: tuple[str, ...] = ()
    pending_trial: Optional[TrialPrompt] = None
    pending_tax: Optional[TaxEvasionPrompt] = None


@dataclass(frozen=True, slots=True)
class TaxChoiceResult:
    """Tax decision settlement returned to the interactive choice view."""

    character: Character
    choice: str
    tax_due: int
    evaded_amount: int
    message: str


@dataclass(frozen=True, slots=True)
class LaunderResult:
    """Gross cash, fee, and bank deposit from one laundering action."""

    gross_amount: int
    fee_amount: int
    net_amount: int
    annual_limit: int


@dataclass(frozen=True, slots=True)
class PrisonActionResult:
    """Outcome of one prison-only action."""

    character: Character
    action: str
    message: str


@dataclass(frozen=True, slots=True)
class PrisonStatus:
    """Concise prison status and criminal-career details for command output."""

    character: Character
    in_prison: bool
    years_left: int
    juvenile_release_age: Optional[int]
    career_rank: Optional[str]
    career_years: int
    dirty_cash: int
    gang_protected: bool
    escaped: bool


@dataclass(frozen=True, slots=True)
class CrimeRecord:
    """Recent offenses, criminal-career state, and recoverable pending prompts."""

    character: Character
    career_rank: Optional[str]
    career_years: int
    dirty_cash: int
    evaded_tax: int
    attempts: tuple[dict[str, Any], ...]
    trial: Optional[TrialPrompt]
    tax_prompt: Optional[TaxEvasionPrompt]
    preview: Optional[CrimePreview]


def clamp_chance(value: float) -> float:
    """Clamp probability in percentage points to the configured safe interval."""
    return max(
        GameBalance.CRIME_CHANCE_MIN_PERCENT,
        min(GameBalance.CRIME_CHANCE_MAX_PERCENT, float(value)),
    )


def calculate_crime_success_chance(
    base_success: float,
    *,
    smarts: int,
    fitness: int,
    luck: int,
    success_stat: str,
) -> float:
    """Apply the specified skill/physical/luck modifiers to a crime success roll."""
    value = float(base_success)
    if success_stat == "skill":
        value += (int(smarts) - 50) * GameBalance.CRIME_SUCCESS_SMARTS_WEIGHT
    elif success_stat == "physical":
        value += (int(fitness) - 50) * GameBalance.CRIME_SUCCESS_FITNESS_WEIGHT
    elif success_stat != "none":
        raise ValueError("success_stat must be none, skill, or physical")
    value += int(luck) * GameBalance.CRIME_SUCCESS_LUCK_WEIGHT
    return clamp_chance(value)


def calculate_crime_catch_chance(
    base_catch: float,
    *,
    notoriety: int,
    criminal_record: int,
    failed_attempt: bool = False,
) -> float:
    """Apply notoriety, record, and the 1.5 failed-attempt multiplier."""
    value = (
        float(base_catch)
        + int(notoriety) * GameBalance.CRIME_CATCH_NOTORIETY_WEIGHT
        + int(criminal_record) * GameBalance.CRIME_CATCH_RECORD_WEIGHT
    )
    if failed_attempt:
        value *= GameBalance.CRIME_FAILED_ATTEMPT_CATCH_MULTIPLIER
    return clamp_chance(value)


def calculate_job_application_chance(
    criminal_record: int,
    *,
    age: int,
    last_release_age: Optional[int],
) -> float:
    """Apply a permanent per-record penalty and a release penalty that fades over 10 years."""
    count = max(0, int(criminal_record))
    if count == 0:
        return 100.0
    years_since_release = max(0, int(age) - int(last_release_age)) if last_release_age is not None else 0
    release_penalty = (
        max(
            0.0,
            GameBalance.CRIME_RELEASE_HIRING_PENALTY_MAX_PERCENT
            - GameBalance.CRIME_RELEASE_HIRING_PENALTY_DECAY_PERCENT_PER_YEAR * years_since_release,
        )
        if last_release_age is not None else 0.0
    )
    record_penalty = min(
        GameBalance.CRIME_RECORD_HIRING_PENALTY_MAX_PERCENT,
        GameBalance.CRIME_RECORD_HIRING_PENALTY_PERCENT * count,
    )
    return max(
        GameBalance.CRIME_HIRING_CHANCE_MIN_PERCENT,
        100.0 - record_penalty - release_penalty,
    )


def calculate_single_income_tax(
    income: int,
    *,
    price_index: float = 1.0,
    tax_mod: float = 1.0,
) -> int:
    """Calculate integer-cent progressive tax with inflation-adjusted brackets."""
    return progressive_income_tax(income, price_index=price_index, tax_mod=tax_mod)


def calculate_laundering(amount: int) -> tuple[int, int]:
    """Return a 25% integer-cent laundering fee and the remaining bank deposit."""
    if isinstance(amount, bool) or not isinstance(amount, int) or amount <= 0:
        raise ValueError("laundering amount must be positive integer cents")
    fee = charge_cents(amount, Decimal("0.25"))
    return fee, amount - fee


class CrimeService:
    """Transactional engine for abstract crime, court, tax, and prison gameplay."""

    def __init__(
        self,
        db: Any,
        rng: RNG,
        locks: Optional[UserLockRegistry] = None,
        *,
        repository: Optional[CrimeRepository] = None,
        family_service: Optional[FamilyService] = None,
        data_loader: Optional[DataLoader] = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.db = db
        self.rng = rng.fork("lifeline-stage7-crime")
        self.locks = locks or UserLockRegistry()
        self.repository = repository or CrimeRepository(db)
        self.family_service = family_service or FamilyService(db, rng, self.locks, clock=clock)
        self.clock = clock
        self.data_loader = data_loader or DataLoader()
        catalog = self.data_loader.load_crimes()
        self.economic_countries = self.data_loader.load_countries()
        self.country_severity = {str(key).lower(): float(value) for key, value in catalog["crime_severity_mod"].items()}
        self.crimes = tuple(CrimeDefinition.from_dict(item) for item in catalog["crimes"])
        self._by_id = {crime.id: crime for crime in self.crimes}

    def replace_catalog(self, document: dict[str, Any]) -> None:
        """Validate and atomically replace crime definitions and regional modifiers."""
        from .validators import validate_crime_catalog
        validate_crime_catalog(document)
        crimes = tuple(CrimeDefinition.from_dict(item) for item in document["crimes"])
        by_id = {crime.id: crime for crime in crimes}
        severity = {str(key).lower(): float(value) for key, value in document["crime_severity_mod"].items()}
        self.crimes = crimes
        self._by_id = by_id
        self.country_severity = severity

    async def initialize_character(self, tx: aiosqlite.Connection, character: Character) -> None:
        """Initialize Stage 7 profile data during birth without changing RNG streams."""
        await self.repository.initialize_profile(tx, character.char_id)

    async def list_crimes(self, user_id: int) -> tuple[CrimeDefinition, ...]:
        """Return the validated crime catalog only to a living player with an active life."""
        async with self.locks.hold(user_id):
            await self._active_character_read(user_id)
            return self.crimes

    async def preview_crime(self, user_id: int, crime_id: str) -> CrimePreview:
        """Persist risk estimates before the player sees a one-use confirm button."""
        crime = self._by_id.get(str(crime_id))
        if crime is None or not crime.commit_enabled:
            raise ValidationError("Choose a committable crime from `/crime list`.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character.char_id)
                await self._check_no_trial_or_tax(tx, character.char_id)
                self._check_not_imprisoned(character)
                if character.age < crime.min_age:
                    raise EducationRequirementError(f"You must be at least {crime.min_age} to attempt {crime.name}.")
                job = await self.repository.get_job(tx, character.char_id)
                if crime.requires_job and job is None:
                    raise EducationRequirementError(f"{crime.name} requires an active job.")
                salary = int(job["salary"]) if job is not None else 0
                success = calculate_crime_success_chance(
                    float(crime.base_success or 0.0),
                    smarts=character.stats.smarts,
                    fitness=character.stats.fitness,
                    luck=character.hidden.luck,
                    success_stat=crime.success_stat,
                )
                catch = calculate_crime_catch_chance(
                    float(crime.base_catch or 0.0),
                    notoriety=character.notoriety,
                    criminal_record=character.criminal_record,
                )
                loot_min, loot_max = self._loot_bounds(crime, character, salary)
                nonce = secrets.token_urlsafe(16)
                now = int(self.clock())
                await self.repository.save_preview(
                    tx,
                    char_id=character.char_id,
                    crime_id=crime.id,
                    age=character.age,
                    nonce=nonce,
                    success_chance=success,
                    catch_chance=catch,
                    loot_min=loot_min,
                    loot_max=loot_max,
                    salary_snapshot=salary,
                    created_at=now,
                    expires_at=now + 300,
                )
                return CrimePreview(
                    crime.id, crime.name, crime.description, character.age, nonce,
                    success, catch,
                    clamp_chance(catch * GameBalance.CRIME_FAILED_ATTEMPT_CATCH_MULTIPLIER),
                    loot_min, loot_max, now + 300,
                )

    async def cancel_preview(self, user_id: int, nonce: str) -> None:
        """Consume a matching risk preview when its owner cancels."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                if not await self.repository.cancel_preview(tx, character.char_id, nonce):
                    raise CrimeSessionExpired()

    async def confirm_crime(self, user_id: int, nonce: str) -> CrimeAttemptOutcome:
        """Resolve a saved risk preview, record the attempt, and open trial if caught."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                self._check_not_imprisoned(character)
                await self._check_pending_event(tx, character.char_id)
                await self._check_no_trial_or_tax(tx, character.char_id)
                now = int(self.clock())
                preview = await self.repository.get_preview(tx, character.char_id, nonce, now)
                if preview is None or int(preview["age"]) != character.age:
                    raise CrimeSessionExpired()
                crime = self._by_id.get(str(preview["crime_id"]))
                if crime is None or not crime.commit_enabled:
                    raise CrimeSessionExpired()
                if crime.requires_job and await self.repository.get_job(tx, character.char_id) is None:
                    raise EducationRequirementError(f"{crime.name} requires an active job.")
                if not await self.repository.claim_crime_attempt(tx, character.char_id, character.age):
                    raise CrimeLimitReached()

                success_chance = float(preview["success_chance"])
                success = self.rng.random() * 100.0 < success_chance
                catch_chance = float(preview["catch_chance"])
                if not success:
                    catch_chance = clamp_chance(
                        catch_chance * GameBalance.CRIME_FAILED_ATTEMPT_CATCH_MULTIPLIER
                    )
                caught = self.rng.random() * 100.0 < catch_chance
                loot = self.rng.randint(int(preview["loot_min"]), int(preview["loot_max"])) if success else 0
                notoriety_gain = self.rng.randint(5, 25)
                karma_loss = self.rng.randint(5, 50)
                stats = replace(character.stats)
                stats.karma = max(0, stats.karma - karma_loss)
                if crime.id == "vandalism" and character.hidden.temperament == "volatile" and success:
                    stats.happiness = min(100, stats.happiness + 5)
                updated = replace(
                    character,
                    cash=character.cash + loot,
                    stats=stats,
                    notoriety=max(0, min(100, character.notoriety + notoriety_gain)),
                    version=expected_version + 1,
                )
                profile = await self.repository.get_profile(tx, character.char_id)
                dirty_cash = int(profile["dirty_cash"]) + loot
                career_level = int(profile["career_level"])
                if career_level < 0:
                    career_level = 0
                else:
                    career_level = max(career_level, self._career_level(updated.notoriety))
                career_rank = CAREER_RANKS[career_level][0]
                attempt_id = await self.repository.insert_attempt(
                    tx,
                    char_id=character.char_id,
                    crime_id=crime.id,
                    age=character.age,
                    source="attempt",
                    success=success,
                    caught=caught,
                    loot=loot,
                    success_chance=success_chance,
                    catch_chance=catch_chance,
                    case_status="pending" if caught else "clear",
                    created_at=now,
                )
                await self.repository.delete_preview(tx, character.char_id, nonce)
                await self.repository.update_profile(
                    tx,
                    character.char_id,
                    dirty_cash=dirty_cash,
                    career_rank=career_rank,
                    career_level=career_level,
                    last_crime_id=crime.id,
                )
                if loot:
                    await self.repository.add_cashflow(tx, character.char_id, character.age, "crime_income", loot, now)
                if career_level >= 4:
                    await self.repository.grant_front_business(tx, character.char_id, character.age, now)
                trial = None
                if caught:
                    trial_nonce = secrets.token_urlsafe(16)
                    await self.repository.create_trial(tx, character.char_id, attempt_id, trial_nonce, now)
                    trial = TrialPrompt(trial_nonce, attempt_id, crime.id, crime.name, character.age, "attempt")
                    message = f"You were caught after the {crime.name} attempt. Choose a lawyer for your trial."
                elif success:
                    message = f"The fictional {crime.name} attempt succeeded; {format_cents(loot)} was added as dirty cash."
                else:
                    message = f"The fictional {crime.name} attempt failed, but you avoided arrest."
                await self.repository.save_character(tx, updated, expected_version)
                await self.repository.insert_life_log(
                    tx, character.char_id, character.age, "crime", message, 4, now
                )
                return CrimeAttemptOutcome(
                    crime.id, crime.name, success, caught, loot,
                    success_chance, catch_chance, message, trial,
                )

    async def resolve_trial(self, user_id: int, nonce: str, lawyer_tier: str) -> TrialResolution:
        """Roll a conviction using the selected lawyer and settle every consequence atomically."""
        tier = str(lawyer_tier).lower()
        if tier not in LAWYER_CONVICTION_CHANCES:
            raise ValidationError("Choose public defender, standard, or elite counsel.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                trial = await self.repository.pending_trial(tx, character.char_id)
                if trial is None or str(trial["nonce"]) != nonce:
                    raise TrialNotFound()
                crime = self._by_id.get(str(trial["crime_id"]))
                if crime is None:
                    raise TrialNotFound("The charge data could not be loaded for this trial.")
                fee = 0 if tier == "public" else LAWYER_FEES[tier]
                if tier == "elite":
                    fee = charge_cents(fee, Decimal(str(character.price_index)))
                if character.cash + character.bank < fee:
                    raise InsufficientFunds(f"You need {format_cents(fee)} for that lawyer. The public defender is free.")
                updated, _ = self._deduct_funds(character, fee)
                conviction_chance = lawyer_conviction_chance(tier)
                convicted = self.rng.random() * 100.0 < conviction_chance
                fine_paid = 0
                sentence_years = 0
                life_sentence = False
                record_sealed = False
                profile = await self.repository.get_profile(tx, character.char_id)
                if convicted:
                    updated, profile, sentence_years, life_sentence, record_sealed, fine_paid = await self._apply_conviction(
                        tx,
                        updated,
                        expected_version,
                        crime,
                        profile,
                        source=str(trial["source"]),
                        loot=int(trial["loot"]),
                        now=int(self.clock()),
                        sentence_override=None,
                        life_override=False,
                        assess_fine=True,
                    )
                    case_status = "convicted"
                    verdict = "convicted"
                else:
                    updated = replace(updated, version=expected_version + 1)
                    case_status = "acquitted"
                    verdict = "acquitted"
                now = int(self.clock())
                await self.repository.complete_trial(
                    tx,
                    char_id=character.char_id,
                    attempt_id=int(trial["attempt_id"]),
                    case_status=case_status,
                    lawyer_tier=tier,
                    sentence_years=sentence_years,
                    life_sentence=life_sentence,
                    record_sealed=record_sealed,
                    fine_paid=fine_paid,
                    resolved_at=now,
                )
                await self.repository.save_character(tx, updated, expected_version)
                message = (
                    f"The court {verdict} you. Lawyer: {tier.replace('_', ' ')}; "
                    f"conviction chance: {conviction_chance:.0f}%."
                )
                if convicted:
                    if sentence_years:
                        message += f" Sentence: {sentence_years} year(s){' (life sentence)' if life_sentence else ''}."
                    if record_sealed:
                        message += " Your juvenile record was sealed."
                    if fine_paid:
                        message += f" {format_cents(fine_paid)} was seized from available crime proceeds."
                    if updated.in_prison:
                        message += " You are now in prison."
                await self.repository.insert_life_log(tx, character.char_id, character.age, "crime", message, 5, now)
                return TrialResolution(
                    updated, crime.name, tier, conviction_chance, convicted,
                    sentence_years, life_sentence, record_sealed, fine_paid, message,
                )

    async def launder(self, user_id: int, amount_dollars: int) -> LaunderResult:
        """Convert dirty cash to bank balance after the fixed 25% laundering fee."""
        if isinstance(amount_dollars, bool) or not isinstance(amount_dollars, int) or amount_dollars <= 0:
            raise ValidationError("Enter a positive whole-dollar amount to launder.")
        gross = dollars_to_cents(amount_dollars)
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character.char_id)
                await self._check_no_trial_or_tax(tx, character.char_id)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "launder money")
                profile = await self.repository.get_profile(tx, character.char_id)
                available_dirty = min(int(profile["dirty_cash"]), character.cash)
                if gross > available_dirty:
                    raise InsufficientFunds("You do not have that much available dirty cash to launder.")
                has_front = await self.repository.has_front_business(tx, character.char_id)
                used = await self.repository.laundering_total(tx, character.char_id, character.age)
                limit = 0 if has_front else LAUNDERING_ANNUAL_CAP
                if not has_front and used + gross > LAUNDERING_ANNUAL_CAP:
                    remaining = max(0, LAUNDERING_ANNUAL_CAP - used)
                    raise ValidationError(
                        f"Without a front-business item, the annual laundering cap is {format_cents(LAUNDERING_ANNUAL_CAP)}; "
                        f"you have {format_cents(remaining)} left this year."
                    )
                fee, net = calculate_laundering(gross)
                updated = replace(
                    character,
                    cash=max(0, character.cash - gross),
                    bank=character.bank + net,
                    version=expected_version + 1,
                )
                await self.repository.update_profile(
                    tx, character.char_id, dirty_cash=max(0, int(profile["dirty_cash"]) - gross)
                )
                now = int(self.clock())
                await self.repository.add_laundering(tx, character.char_id, character.age, gross, fee, net, now)
                await self.repository.add_cashflow(tx, character.char_id, character.age, "launder", gross, now)
                await self.repository.add_cashflow(tx, character.char_id, character.age, "fine", fee, now)
                await self.repository.save_character(tx, updated, expected_version)
                await self.repository.insert_life_log(
                    tx, character.char_id, character.age, "crime",
                    f"Laundered {format_cents(gross)}; the fee was {format_cents(fee)}.", 3, now,
                )
                return LaunderResult(gross, fee, net, limit)

    async def resolve_tax_choice(self, user_id: int, nonce: str, choice: str) -> TaxChoiceResult:
        """Resolve one high-earner pay-or-evade event and persist its audit exposure."""
        selected = str(choice).lower()
        evasion_rates = {"pay": 0.0, "evade_50": 0.50, "evade_75": 0.75, "evade_100": 1.0}
        if selected not in evasion_rates:
            raise ValidationError("Choose to pay tax or evade 50%, 75%, or 100%.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                prompt = await self.repository.pending_tax_prompt(tx, character.char_id)
                if prompt is None or str(prompt["nonce"]) != nonce:
                    raise TaxDecisionNotFound()
                tax_due = int(prompt["tax_due"])
                rate = Decimal(str(evasion_rates[selected]))
                evaded = payout_cents(tax_due, rate)
                payable = max(0, tax_due - evaded)
                updated = character
                if bool(prompt["prepaid"]):
                    paid_before = min(int(prompt["paid_amount"]), tax_due)
                    unpaid_before = max(0, tax_due - paid_before)
                    debt_reduction = min(unpaid_before, evaded)
                    refund = min(paid_before, max(0, evaded - debt_reduction))
                    updated = replace(
                        updated,
                        cash=updated.cash + refund,
                        debt_total=max(0, updated.debt_total - debt_reduction),
                    )
                else:
                    updated, unpaid = self._deduct_funds(updated, payable)
                    if unpaid:
                        updated = replace(updated, debt_total=updated.debt_total + unpaid)
                profile = await self.repository.get_profile(tx, character.char_id)
                if evaded:
                    await self.repository.update_profile(
                        tx, character.char_id, evaded_tax=int(profile["evaded_tax"]) + evaded
                    )
                now = int(self.clock())
                await self.repository.record_tax_choice(
                    tx, character.char_id, int(prompt["age"]), selected, tax_due, evaded, now
                )
                if not await self.repository.consume_tax_prompt(tx, character.char_id, nonce):
                    raise TaxDecisionNotFound()
                updated = replace(updated, version=expected_version + 1)
                await self.repository.save_character(tx, updated, expected_version)
                await self.repository.insert_life_log(
                    tx, character.char_id, character.age, "crime",
                    f"Tax decision: {selected.replace('_', ' ')}; {format_cents(evaded)} was deferred.", 3, now,
                )
                message = (
                    f"Tax decision recorded. {format_cents(payable)} was paid or remained withheld; "
                    f"{format_cents(evaded)} is exposed to a future audit."
                )
                return TaxChoiceResult(updated, selected, tax_due, evaded, message)

    async def laundered_amount(self, user_id: int) -> int:
        """Return a read-only estimate of the current year's laundering cap usage."""
        async with self.locks.hold(user_id):
            character = await self._active_character_read(user_id)
            return await self.repository.laundering_total_read(character.char_id, character.age)

    async def get_trial_prompt(self, user_id: int) -> TrialPrompt:
        """Reopen a pending trial after a component timed out or its message was lost."""
        async with self.locks.hold(user_id):
            await self._active_character_read(user_id)
            row = await self.repository.pending_trial_read(user_id)
            if row is None:
                raise TrialNotFound()
            crime = self._by_id.get(str(row["crime_id"]))
            if crime is None:
                raise TrialNotFound("The charge data could not be loaded for this trial.")
            return TrialPrompt(
                str(row["nonce"]), int(row["attempt_id"]), crime.id, crime.name,
                int(row["age"]), str(row["source"]),
            )

    async def get_tax_prompt(self, user_id: int) -> TaxEvasionPrompt:
        """Reopen an unresolved tax choice through the /crime record command."""
        async with self.locks.hold(user_id):
            await self._active_character_read(user_id)
            row = await self.repository.pending_tax_prompt_read(user_id)
            if row is None:
                raise TaxDecisionNotFound()
            return self._tax_prompt_from_row(row)

    async def prison_action(self, user_id: int, action: str) -> PrisonActionResult:
        """Resolve one annual prison action using its own in-game-year counter."""
        selected = str(action).lower()
        if selected not in {"behave", "workout", "study", "riot", "escape", "gang"}:
            raise ValidationError("Choose behave, workout, study, riot, escape, or gang.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                if not character.in_prison:
                    raise CharacterNotInPrison()
                self._check_age(character, 10, "take a prison action")
                await self._check_pending_event(tx, character.char_id)
                if await self.repository.other_pending_prompt(tx, character.char_id):
                    raise PendingEventExists("Resolve your pending crime or tax decision before taking another action.")
                if not await self.repository.claim_action(tx, character.char_id, character.age, "prison_action"):
                    raise CrimeActionAlreadyUsed()
                profile = await self.repository.get_profile(tx, character.char_id)
                updated = character
                message = ""
                if selected == "behave":
                    if self.rng.random() < GameBalance.CRIME_PRISON_BEHAVIOR_REDUCTION_CHANCE:
                        years_left = max(0, character.prison_years_left - 1)
                        updated = replace(updated, prison_years_left=years_left)
                        message = "Good behavior earned one year off your sentence."
                        if years_left == 0:
                            updated, profile = await self._release(tx, updated, profile, juvenile=False)
                            message += " Your sentence is complete; you are released."
                    else:
                        message = "You kept your conduct steady, but no sentence reduction was awarded this year."
                elif selected == "workout":
                    gain = self.rng.randint(3, 6)
                    stats = replace(updated.stats, fitness=min(100, updated.stats.fitness + gain))
                    updated = replace(updated, stats=stats)
                    message = f"A routine workout improved fitness by {gain}."
                elif selected == "study":
                    if not updated.has_ged:
                        updated = replace(updated, has_ged=True)
                        message = "Your study effort earned GED eligibility for future job applications."
                    else:
                        message = "You continued studying and kept your GED credential current."
                elif selected in {"escape", "riot"}:
                    if selected == "riot" and self.rng.random() >= GameBalance.CRIME_PRISON_RIOT_ESCALATION_CHANCE:
                        message = "The riot did not turn into an escape attempt."
                    else:
                        if selected == "riot":
                            message = "The disturbance created an escape opportunity. "
                        escaped = self.rng.random() < GameBalance.CRIME_PRISON_ESCAPE_CHANCE
                        if escaped:
                            updated = replace(
                                updated,
                                in_prison=False,
                                prison_years_left=0,
                                notoriety=min(100, updated.notoriety + 40),
                            )
                            await self.repository.update_profile(
                                tx, character.char_id, escaped=1, juvenile_release_age=None, gang_protected=0
                            )
                            message += "You escaped. Notoriety rose by 40; re-arrest risk is 30% each year."
                        else:
                            extension = self.rng.randint(
                                GameBalance.CRIME_PRISON_ESCAPE_EXTENSION_MIN_YEARS,
                                GameBalance.CRIME_PRISON_ESCAPE_EXTENSION_MAX_YEARS,
                            )
                            updated = replace(updated, prison_years_left=updated.prison_years_left + extension)
                            message += f"The escape failed and added {extension} year(s) to your sentence."
                else:
                    notoriety_gain = self.rng.randint(5, 10)
                    updated = replace(updated, notoriety=min(100, updated.notoriety + notoriety_gain))
                    await self.repository.update_profile(tx, character.char_id, gang_protected=1)
                    profile["gang_protected"] = 1
                    message = f"You gained protection from random prison violence; notoriety rose by {notoriety_gain}."
                updated = replace(updated, version=expected_version + 1)
                await self.repository.save_character(tx, updated, expected_version)
                now = int(self.clock())
                await self.repository.insert_life_log(
                    tx, character.char_id, character.age, "prison", message, 3, now
                )
                return PrisonActionResult(updated, selected, message)

    async def prison_status(self, user_id: int) -> PrisonStatus:
        """Return current custody, sentence, gang, and criminal-career status."""
        async with self.locks.hold(user_id):
            character = await self._active_character_read(user_id)
            profile = await self.repository.read_profile(character.char_id) or {}
            return PrisonStatus(
                character=character,
                in_prison=character.in_prison,
                years_left=character.prison_years_left,
                juvenile_release_age=(int(profile["juvenile_release_age"]) if profile.get("juvenile_release_age") is not None else None),
                career_rank=str(profile["career_rank"]) if profile.get("career_rank") else None,
                career_years=int(profile.get("career_years", 0)),
                dirty_cash=int(profile.get("dirty_cash", 0)),
                gang_protected=bool(profile.get("gang_protected", 0)),
                escaped=bool(profile.get("escaped", 0)),
            )

    async def crime_record(self, user_id: int) -> CrimeRecord:
        """Show lifetime criminal outcomes and recover any pending owner-only decision."""
        async with self.locks.hold(user_id):
            character = await self._active_character_read(user_id)
            async with self.db.transaction() as tx:
                await self.repository.initialize_profile(tx, character.char_id)
                profile = await self.repository.get_profile(tx, character.char_id)
                preview_row = await self.repository.preview_for_character(tx, character.char_id)
                if preview_row is not None and int(preview_row["expires_at"]) < int(self.clock()):
                    await self.repository.cancel_preview(tx, character.char_id, str(preview_row["nonce"]))
                    preview_row = None
                trial_row = await self.repository.pending_trial(tx, character.char_id)
                tax_row = await self.repository.pending_tax_prompt(tx, character.char_id)
                history = await self.repository.crime_history_in_transaction(tx, character.char_id, 10)
                preview = self._preview_from_row(preview_row) if preview_row else None
                trial = self._trial_from_row(trial_row) if trial_row else None
                tax = self._tax_prompt_from_row(tax_row) if tax_row else None
                return CrimeRecord(
                    character,
                    str(profile["career_rank"]) if profile["career_rank"] else None,
                    int(profile["career_years"]),
                    int(profile["dirty_cash"]),
                    int(profile["evaded_tax"]),
                    tuple(history),
                    trial,
                    tax,
                    preview,
                )

    async def advance_year(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        previous_age: int,
        personal_income: int,
        household_income: int,
        tax_assessed: int,
        tax_paid: int,
        now: int,
    ) -> CrimeYearResult:
        """Execute Stage 7 annual step 12 inside the existing /life age transaction."""
        if not character.is_alive:
            return CrimeYearResult(character)
        profile = await self.repository.get_profile(tx, character.char_id)
        messages: list[str] = []
        updated = character
        pending_trial: Optional[TrialPrompt] = None
        pending_tax: Optional[TaxEvasionPrompt] = None
        was_in_prison = bool(character.in_prison)

        if was_in_prison:
            updated, profile, prison_messages = await self._advance_prison_year(tx, updated, profile, now)
            messages.extend(prison_messages)
        else:
            updated, profile, audit_messages = await self._run_annual_audit(
                tx, updated, profile, previous_age, household_income, now
            )
            messages.extend(audit_messages)
            if updated.is_alive and not updated.in_prison:
                if bool(profile["escaped"]):
                    if self.rng.random() < GameBalance.CRIME_ESCAPE_REARREST_CHANCE:
                        pending_trial = await self._create_career_arrest_trial(
                            tx, updated, profile, source="escape_rearrest", now=now
                        )
                        messages.append("Authorities located you after your escape; a new trial is pending.")
                if pending_trial is None and int(profile["career_level"]) >= 0:
                    arrest_chance = min(
                        GameBalance.CRIME_ANNUAL_ARREST_MAX_CHANCE,
                        GameBalance.CRIME_ANNUAL_ARREST_BASE_CHANCE
                        + updated.notoriety * GameBalance.CRIME_ANNUAL_ARREST_NOTORIETY_WEIGHT,
                    )
                    if self.rng.random() < arrest_chance:
                        pending_trial = await self._create_career_arrest_trial(
                            tx, updated, profile, source="career_arrest", now=now
                        )
                        messages.append("A yearly criminal-career arrest roll resulted in a pending trial.")
                if pending_trial is None and int(profile["career_level"]) >= 0:
                    updated, profile, income_message = await self._pay_criminal_career_income(
                        tx, updated, profile, now
                    )
                    if income_message:
                        messages.append(income_message)

            if updated.is_alive and not updated.in_prison:
                has_marriage = await self.repository.has_marriage(tx, updated.char_id)
                if has_marriage:
                    annual_tax = max(0, int(tax_assessed))
                    prepaid = True
                    paid_amount = max(0, min(annual_tax, int(tax_paid)))
                else:
                    tax_mod, _, _ = _country_modifiers(self.economic_countries, updated.country)
                    annual_tax = (
                        calculate_single_income_tax(
                            max(0, int(personal_income)),
                            price_index=updated.price_index,
                            tax_mod=tax_mod,
                        )
                        if updated.age >= 18 else 0
                    )
                    prepaid = False
                    paid_amount = 0
                high_earner = updated.age >= 18 and household_income >= TAX_EVENT_INCOME_THRESHOLD
                if annual_tax > 0 and high_earner:
                    nonce = secrets.token_urlsafe(16)
                    await self.repository.save_tax_prompt(
                        tx, updated.char_id, nonce, updated.age, annual_tax, prepaid, now,
                        paid_amount=paid_amount,
                    )
                    pending_tax = TaxEvasionPrompt(nonce, updated.age, annual_tax, paid_amount, prepaid)
                    messages.append("A progressive income-tax decision is waiting for you.")
                elif annual_tax > 0 and prepaid:
                    await self.repository.add_cashflow(
                        tx, updated.char_id, updated.age, "tax", paid_amount, now
                    )
                elif annual_tax > 0:
                    bank_paid = min(max(0, updated.bank), annual_tax)
                    cash_paid = min(max(0, updated.cash), annual_tax - bank_paid)
                    paid_amount = bank_paid + cash_paid
                    unpaid = annual_tax - paid_amount
                    updated = replace(
                        updated,
                        bank=updated.bank - bank_paid,
                        cash=updated.cash - cash_paid,
                        debt_total=max(0, updated.debt_total) + unpaid,
                    )
                    await self.repository.add_cashflow(
                        tx, updated.char_id, updated.age, "tax", paid_amount, now
                    )
                    if unpaid:
                        messages.append(f"Income tax of {annual_tax:,}¢ was assessed; {unpaid:,}¢ was added to tax debt.")
                    elif paid_amount:
                        messages.append(f"Progressive income tax of {paid_amount:,}¢ was paid.")
            elif updated.in_prison:
                messages.append("No wages or ordinary bills were charged during imprisonment.")

        # Notoriety cools by five points each completed year, after arrest/audit rolls.
        notoriety = max(0, updated.notoriety - 5)
        updated = replace(updated, notoriety=notoriety)
        await self.repository.update_profile(tx, updated.char_id, dirty_cash=max(0, int(profile["dirty_cash"])))
        return CrimeYearResult(updated, tuple(messages), pending_trial, pending_tax)

    async def ensure_no_pending_decision(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Block /life age until pending Stage 7 confirmation, trial, or tax buttons resolve."""
        if await self.repository.has_pending_decision(tx, char_id, int(self.clock())):
            raise PendingEventExists("Resolve the crime confirmation, trial, or tax choice before using `/life age`.")

    async def _run_annual_audit(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        profile: dict[str, Any],
        previous_age: int,
        annual_income: int,
        now: int,
    ) -> tuple[Character, dict[str, Any], list[str]]:
        """Roll annual tax and unlaundered-cash audits and settle a detected evasion."""
        messages: list[str] = []
        totals = await self.repository.cashflow_totals(tx, character.char_id, previous_age)
        income = int(totals.get("crime_income", 0)) + int(totals.get("career_income", 0))
        laundered = int(totals.get("launder", 0))
        threshold = scale_cents(dollars_to_cents(10_000), Decimal(str(character.price_index)))
        cash_flag = max(0, income - laundered) > threshold
        evaded = int(profile["evaded_tax"])
        auditable = evaded > 0 or int(annual_income) >= TAX_EVENT_INCOME_THRESHOLD or cash_flag
        tax_chance = min(
            GameBalance.CRIME_TAX_AUDIT_MAX_CHANCE,
            GameBalance.CRIME_TAX_AUDIT_BASE_CHANCE
            + character.notoriety * GameBalance.CRIME_TAX_AUDIT_NOTORIETY_WEIGHT,
        ) if auditable else 0.0
        cash_chance = GameBalance.CRIME_UNLAUNDERED_CASH_AUDIT_CHANCE if cash_flag else 0.0
        chance = 1.0 - (1.0 - tax_chance) * (1.0 - cash_chance)
        triggered = chance > 0 and self.rng.random() < chance
        sentence_years = 0
        back_taxes = 0
        updated = character
        if triggered and evaded > 0:
            back_taxes = evaded * 2
            updated, unpaid = self._deduct_funds(updated, back_taxes)
            if unpaid:
                updated = replace(updated, debt_total=updated.debt_total + unpaid)
            await self.repository.update_profile(tx, character.char_id, evaded_tax=0)
            await self.repository.add_cashflow(tx, character.char_id, character.age, "audit", back_taxes, now)
            messages.append(f"A tax audit found evaded taxes; {format_cents(back_taxes)} in back taxes was assessed.")
            if self.rng.random() < GameBalance.CRIME_TAX_AUDIT_CRIMINAL_CHARGE_CHANCE:
                tax_crime = self._by_id["tax_evasion"]
                source_record = await self.repository.insert_attempt(
                    tx,
                    char_id=character.char_id,
                    crime_id=tax_crime.id,
                    age=character.age,
                    source="tax_audit",
                    success=False,
                    caught=True,
                    loot=0,
                    success_chance=0.0,
                    catch_chance=chance * 100.0,
                    case_status="convicted",
                    created_at=now,
                )
                base_sentence = self.rng.randint(tax_crime.sentence_min, int(tax_crime.sentence_max or 5))
                updated, profile, sentence_years, _, _, _ = await self._apply_conviction(
                    tx,
                    updated,
                    character.version,
                    tax_crime,
                    profile,
                    source="tax_audit",
                    loot=0,
                    now=now,
                    sentence_override=base_sentence,
                    life_override=False,
                    assess_fine=False,
                )
                await self.repository.resolve_audit_attempt(
                    tx, source_record, sentence_years=sentence_years, resolved_at=now
                )
                messages.append(f"The tax audit also resulted in a {sentence_years}-year sentence.")
        elif triggered:
            messages.append("A financial audit reviewed the year's activity and found no tax evasion.")
        elif auditable:
            messages.append("The year's tax and cash activity passed its random audit roll.")
        await self.repository.record_audit(
            tx,
            character.char_id,
            character.age,
            chance * 100.0,
            triggered,
            bool(triggered and evaded > 0),
            back_taxes,
            sentence_years,
            "caught" if triggered and evaded > 0 else ("reviewed" if triggered else "not_triggered"),
            now,
        )
        return updated, profile, messages

    async def _create_career_arrest_trial(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        profile: dict[str, Any],
        *,
        source: str,
        now: int,
    ) -> TrialPrompt:
        """Open a lawyer-choice trial after a yearly career or escape arrest roll."""
        crime_id = str(profile["last_crime_id"] or "shoplift")
        crime = self._by_id.get(crime_id, self._by_id["shoplift"])
        attempt_id = await self.repository.insert_attempt(
            tx,
            char_id=character.char_id,
            crime_id=crime.id,
            age=character.age,
            source=source,
            success=False,
            caught=True,
            loot=0,
            success_chance=0.0,
            catch_chance=clamp_chance(
                (
                    GameBalance.CRIME_ESCAPE_REARREST_CHANCE
                    if source == "escape_rearrest"
                    else GameBalance.CRIME_ANNUAL_ARREST_BASE_CHANCE
                    + character.notoriety * GameBalance.CRIME_ANNUAL_ARREST_NOTORIETY_WEIGHT
                ) * 100.0
            ),
            case_status="pending",
            created_at=now,
        )
        nonce = secrets.token_urlsafe(16)
        await self.repository.create_trial(tx, character.char_id, attempt_id, nonce, now)
        return TrialPrompt(nonce, attempt_id, crime.id, crime.name, character.age, source)

    async def _pay_criminal_career_income(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        profile: dict[str, Any],
        now: int,
    ) -> tuple[Character, dict[str, Any], str]:
        """Pay yearly illegal income into cash as dirty proceeds and advance career rank."""
        current_level = max(0, int(profile["career_level"]))
        desired_level = max(current_level, self._career_level(character.notoriety))
        rank_name, _, income = CAREER_RANKS[desired_level]
        updated = character
        messages: list[str] = []
        if desired_level > current_level:
            messages.append(f"Your criminal career advanced to {rank_name}.")
        updated = replace(updated, cash=updated.cash + income)
        profile["dirty_cash"] = int(profile["dirty_cash"]) + income
        profile["career_level"] = desired_level
        profile["career_rank"] = rank_name
        profile["career_years"] = int(profile["career_years"]) + 1
        await self.repository.update_profile(
            tx,
            character.char_id,
            career_level=desired_level,
            career_rank=rank_name,
            career_years=int(profile["career_years"]),
            dirty_cash=int(profile["dirty_cash"]),
        )
        await self.repository.add_cashflow(tx, character.char_id, character.age, "career_income", income, now)
        if desired_level >= 4:
            await self.repository.grant_front_business(tx, character.char_id, character.age, now)
            profile["front_business"] = 1
        messages.append(f"Criminal-career income added {format_cents(income)} as dirty cash.")
        return updated, profile, " ".join(messages)

    async def _advance_prison_year(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        profile: dict[str, Any],
        now: int,
    ) -> tuple[Character, dict[str, Any], list[str]]:
        """Tick a prison sentence and resolve non-graphic violence; economy settles debts later."""
        messages: list[str] = []
        updated = character
        years_left = max(0, updated.prison_years_left - 1)
        updated = replace(updated, prison_years_left=years_left)
        juvenile_release = profile.get("juvenile_release_age")
        release_due = years_left == 0 or (
            juvenile_release is not None and updated.age >= int(juvenile_release)
        )
        if release_due:
            updated, profile = await self._release(tx, updated, profile, juvenile=juvenile_release is not None)
            messages.append("Your sentence ended and you were released from custody.")
        elif (
            not bool(profile["gang_protected"])
            and self.rng.random() < GameBalance.CRIME_PRISON_VIOLENCE_CHANCE
        ):
            damage = self.rng.randint(
                GameBalance.CRIME_PRISON_VIOLENCE_DAMAGE_MIN,
                GameBalance.CRIME_PRISON_VIOLENCE_DAMAGE_MAX,
            )
            stats = replace(updated.stats)
            stats.health = max(0, stats.health - damage)
            stats.happiness = max(0, stats.happiness - self.rng.randint(2, 6))
            updated = replace(updated, stats=stats)
            messages.append("A non-graphic prison disturbance lowered your health and happiness.")
            if (
                stats.health <= 0
                or self.rng.random() < GameBalance.CRIME_PRISON_VIOLENCE_FATALITY_CHANCE
            ):
                updated = replace(
                    updated,
                    is_alive=False,
                    in_prison=False,
                    prison_years_left=0,
                    death_cause="prison violence",
                    death_age=updated.age,
                    died_at=now,
                )
                messages.append(f"Life ended at age {updated.age} after a prison-violence event.")
        elif bool(profile["gang_protected"]):
            messages.append("Gang protection deterred random prison violence this year.")
        return updated, profile, messages

    async def _release(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        profile: dict[str, Any],
        *,
        juvenile: bool,
    ) -> tuple[Character, dict[str, Any]]:
        """Clear prison flags and record the release age for hiring recovery."""
        updated = replace(character, in_prison=False, prison_years_left=0)
        profile["last_release_age"] = updated.age
        profile["juvenile_release_age"] = None
        profile["gang_protected"] = 0
        profile["escaped"] = 0
        await self.repository.update_profile(
            tx,
            character.char_id,
            last_release_age=updated.age,
            juvenile_release_age=None,
            gang_protected=0,
            escaped=0,
        )
        if juvenile:
            profile["juvenile_release_age"] = None
        return updated, profile

    async def _apply_conviction(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
        crime: CrimeDefinition,
        profile: dict[str, Any],
        *,
        source: str,
        loot: int,
        now: int,
        sentence_override: Optional[int],
        life_override: bool,
        assess_fine: bool,
        create_trial: bool = True,
    ) -> tuple[Character, dict[str, Any], int, bool, bool, int]:
        """Apply conviction consequences, including juvenile record-sealing chance."""
        updated = character
        juvenile = character.age < 18
        record_sealed = (
            juvenile
            and self.rng.random() < GameBalance.CRIME_JUVENILE_RECORD_SEALING_CHANCE
        )
        if not record_sealed:
            updated = replace(updated, criminal_record=max(0, updated.criminal_record + 1))
        sentence_years, life_sentence, juvenile_release_age = self._sentence(
            crime, character, sentence_override=sentence_override, life_override=life_override
        )
        if sentence_years > 0:
            custody_years = sentence_years
            if juvenile:
                custody_years = min(sentence_years, max(1, 18 - character.age))
                juvenile_release_age = min(18, character.age + custody_years)
            elif life_sentence:
                custody_years = max(1, 120 - character.age)
            updated = replace(updated, in_prison=True, prison_years_left=custody_years)
            if juvenile:
                await self.repository.update_profile(
                    tx, character.char_id, juvenile_release_age=juvenile_release_age
                )
            else:
                await self.repository.update_profile(tx, character.char_id, juvenile_release_age=None)
            fired = await self.repository.fire_job_for_prison(tx, character.char_id, character.age)
            if fired:
                await self.repository.insert_life_log(
                    tx, character.char_id, character.age, "career",
                    "Employment ended because of a prison sentence.", 4, now,
                )
            if updated.housing_type is HousingType.RENT:
                updated = replace(updated, housing_type=HousingType.HOMELESS, housing_item_id=None, rent_amount=0)

        profile = await self.repository.get_profile(tx, character.char_id)
        fine_paid = 0
        if assess_fine and loot > 0:
            target_fine = charge_cents(
                loot, Decimal(GameBalance.CRIME_FINE_ON_CAUGHT_LOOT_PERCENT) / 100
            )
            available_dirty = min(int(profile["dirty_cash"]), max(0, updated.cash))
            fine_paid = min(target_fine, available_dirty)
            if fine_paid:
                updated = replace(updated, cash=max(0, updated.cash - fine_paid))
                profile["dirty_cash"] = max(0, int(profile["dirty_cash"]) - fine_paid)
                await self.repository.update_profile(tx, character.char_id, dirty_cash=int(profile["dirty_cash"]))
                await self.repository.add_cashflow(tx, character.char_id, character.age, "fine", fine_paid, now)

        for relation in await self.repository.relationship_scores(tx, character.char_id):
            penalty = self.rng.randint(10, 30)
            await self.repository.set_relationship_score(
                tx,
                character.char_id,
                int(relation["npc_id"]),
                max(0, int(relation["score"]) - penalty),
            )
        if (
            await self.repository.has_marriage(tx, character.char_id)
            and self.rng.random() < GameBalance.CRIME_SPOUSAL_DIVORCE_AFTER_CONVICTION_CHANCE
        ):
            divorce, updated = await self.family_service._divorce_in_tx(
                tx,
                updated,
                expected_version,
                reason="npc_initiated",
                now=now,
                save_character=False,
            )
            logger.info("Automatic spouse divorce after conviction for character %s", character.char_id)
        updated = replace(updated, version=expected_version + 1)
        return updated, profile, sentence_years, life_sentence, record_sealed, fine_paid

    def _sentence(
        self,
        crime: CrimeDefinition,
        character: Character,
        *,
        sentence_override: Optional[int],
        life_override: bool,
    ) -> tuple[int, bool, Optional[int]]:
        """Roll and country-scale a sentence, halving juvenile terms and capping release at 18."""
        if sentence_override is not None:
            base_years = max(0, int(sentence_override))
            life = bool(life_override)
        elif crime.sentence_max is None:
            lifetime_remaining = max(crime.sentence_min, 120 - character.age)
            base_years = self.rng.randint(crime.sentence_min, lifetime_remaining)
            life = base_years >= max(1, 120 - character.age)
        elif crime.sentence_min == crime.sentence_max:
            base_years = crime.sentence_min
            life = False
        else:
            base_years = self.rng.randint(crime.sentence_min, int(crime.sentence_max))
            life = False
        severity = self._severity(character.country)
        scaled = 0 if base_years == 0 else max(1, math.ceil(base_years * severity))
        scaled = min(scaled, max(0, 120 - character.age))
        juvenile_release_age: Optional[int] = None
        if character.age < 18 and scaled > 0:
            scaled = max(1, math.ceil(scaled / 2))
            juvenile_release_age = min(18, character.age + scaled)
        return scaled, life, juvenile_release_age

    def _loot_bounds(self, crime: CrimeDefinition, character: Character, salary: int) -> tuple[int, int]:
        """Scale catalog dollars or salary-linked loot into integer cents."""
        if crime.requires_job:
            minimum = payout_cents(
                salary,
                Decimal(str(crime.salary_loot_min_fraction * crime.salary_loot_multiplier))
                * Decimal(str(character.price_index)),
            )
            maximum = payout_cents(
                salary,
                Decimal(str(crime.salary_loot_max_fraction * crime.salary_loot_multiplier))
                * Decimal(str(character.price_index)),
            )
            return min(minimum, maximum), max(minimum, maximum)
        minimum = payout_cents(dollars_to_cents(crime.loot_min_dollars), Decimal(str(character.price_index)))
        maximum = payout_cents(dollars_to_cents(crime.loot_max_dollars), Decimal(str(character.price_index)))
        return min(minimum, maximum), max(minimum, maximum)

    async def _active_character(
        self,
        tx: aiosqlite.Connection,
        user_id: int,
    ) -> tuple[Character, int]:
        """Load an active living character and its concurrency version."""
        row = await self.repository.load_active(tx, user_id)
        if row is None:
            if await self.repository.has_any_life(tx, user_id):
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.char_id = int(row["char_id"])
        character.user_id = int(row["user_id"])
        character.version = int(row["version"])
        if not character.is_alive:
            raise CharacterDead()
        return character, int(row["version"])

    async def _active_character_read(self, user_id: int) -> Character:
        """Load the user's living character for a read-only game command."""
        row = await self.repository.load_active_read(user_id)
        if row is None:
            if await self.repository.has_any_life_read(user_id):
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.char_id = int(row["char_id"])
        character.user_id = int(row["user_id"])
        character.version = int(row["version"])
        if not character.is_alive:
            raise CharacterDead()
        return character

    async def _check_pending_event(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Keep unresolved Stage 3 choices ahead of crime actions."""
        if await self.repository.has_pending_event(tx, char_id):
            raise PendingEventExists()

    async def _check_no_trial_or_tax(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Prevent replacing a pending court or tax choice with another criminal action."""
        if await self.repository.other_pending_prompt(tx, char_id):
            raise PendingEventExists("Resolve the pending court or tax buttons before starting another crime action.")

    @staticmethod
    def _check_not_imprisoned(character: Character) -> None:
        """Enforce prison gates inside the engine."""
        if character.in_prison:
            raise CharacterInPrison()

    @staticmethod
    def _check_age(character: Character, minimum: int, action: str) -> None:
        """Enforce an age gate in the service rather than trusting slash-command UI."""
        if character.age < minimum:
            raise EducationRequirementError(f"You must be at least {minimum} to {action}.")

    def _severity(self, country: str) -> float:
        """Get a country-specific crime_severity_mod sentencing modifier, with an explicit neutral default."""
        return self.country_severity.get(country.lower(), self.country_severity["default"])

    @staticmethod
    def _career_level(notoriety: int) -> int:
        """Return the highest criminal-career tier unlocked by notoriety."""
        selected = 0
        for index, (_, threshold, _) in enumerate(CAREER_RANKS):
            if int(notoriety) >= threshold:
                selected = index
        return selected

    @staticmethod
    def _deduct_funds(character: Character, amount: int) -> tuple[Character, int]:
        """Deduct from cash then bank, keeping both nonnegative and returning unpaid cents."""
        remaining = max(0, int(amount))
        cash_paid = min(max(0, character.cash), remaining)
        remaining -= cash_paid
        bank_paid = min(max(0, character.bank), remaining)
        remaining -= bank_paid
        return replace(
            character,
            cash=max(0, character.cash - cash_paid),
            bank=max(0, character.bank - bank_paid),
        ), remaining

    def _preview_from_row(self, row: dict[str, Any]) -> CrimePreview:
        """Recreate the visible risk card from a persisted preview row."""
        catch = float(row["catch_chance"])
        crime = self._by_id.get(str(row["crime_id"]))
        name = crime.name if crime is not None else str(row["crime_id"]).replace("_", " ").title()
        description = crime.description if crime is not None else "A pending crime confirmation."
        return CrimePreview(
            str(row["crime_id"]), name, description, int(row["age"]), str(row["nonce"]),
            float(row["success_chance"]), catch,
            clamp_chance(catch * GameBalance.CRIME_FAILED_ATTEMPT_CATCH_MULTIPLIER),
            int(row["loot_min"]), int(row["loot_max"]), int(row["expires_at"]),
        )

    def _trial_from_row(self, row: Optional[dict[str, Any]]) -> Optional[TrialPrompt]:
        """Map a stored trial record to its command-view model."""
        if row is None:
            return None
        crime = self._by_id.get(str(row["crime_id"]))
        name = crime.name if crime is not None else str(row["crime_id"]).replace("_", " ").title()
        return TrialPrompt(
            str(row["nonce"]), int(row["attempt_id"]), str(row["crime_id"]), name,
            int(row["age"]), str(row["source"]),
        )

    @staticmethod
    def _tax_prompt_from_row(row: dict[str, Any]) -> TaxEvasionPrompt:
        """Map a stored tax choice row into a typed view model."""
        return TaxEvasionPrompt(
            str(row["nonce"]), int(row["age"]), int(row["tax_due"]),
            int(row.get("paid_amount", 0)), bool(row["prepaid"]),
        )
