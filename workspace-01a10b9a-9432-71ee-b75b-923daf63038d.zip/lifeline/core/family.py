"""Stage 6 family generation, relationships, dating, marriage, and yearly care."""
from __future__ import annotations

import json
import logging
import secrets
import time
from dataclasses import dataclass, replace
from decimal import Decimal
from typing import Any, Callable, Optional

import aiosqlite

from .config import GameBalance
from .data_loader import DataLoader
from .economy import progressive_income_tax, _country_modifiers
from .errors import (
    CharacterDead,
    CharacterNotFound,
    ConcurrentUpdate,
    DateSessionExpired,
    EducationRequirementError,
    FamilyRequirementError,
    InsufficientFunds,
    InteractionLimitReached,
    NoActiveMarriage,
    PendingEventExists,
    RelationshipNotFound,
    ValidationError,
)
from .locks import UserLockRegistry
from .models import Character, EducationLevel, Gender, Stats
from .money import charge_cents, dollars_to_cents, payout_cents, scale_cents
from .repositories.family import FamilyRepository
from .rng import RNG

logger = logging.getLogger("lifeline.family")


@dataclass(frozen=True, slots=True)
class DateSearch:
    """Three generated NPC candidates and the owner/nonce-bound menu token."""

    nonce: str
    candidates: tuple[dict[str, Any], ...]
    expires_at: int


@dataclass(frozen=True, slots=True)
class DateOutcome:
    """Outcome of selecting one candidate from a date search."""

    npc: dict[str, Any]
    success_chance: float
    accepted: bool
    relationship_score: Optional[int]


@dataclass(frozen=True, slots=True)
class InteractionOutcome:
    """Result of one relationship interaction."""

    person_name: str
    action: str
    score_before: int
    score_after: int
    message: str
    money_delta: int = 0


@dataclass(frozen=True, slots=True)
class ProposalOutcome:
    """Outcome of proposing to an eligible partner."""

    person_name: str
    chance: int
    accepted: bool
    ring_bonus: int


@dataclass(frozen=True, slots=True)
class MarriageOutcome:
    """Wedding details after cost, prenup, and spouse income are recorded."""

    person_name: str
    wedding_cost: int
    prenup: bool
    annual_income: int


@dataclass(frozen=True, slots=True)
class DivorceSplit:
    """Pure integer-cent divorce asset allocation result."""

    eligible_assets: int
    spouse_share: int
    protected_assets: int


@dataclass(frozen=True, slots=True)
class DivorceOutcome:
    """Completed divorce settlement and its cash-flow consequences."""

    character: Character
    spouse_name: str
    marital_assets: int
    spouse_share: int
    lawyer_fee: int
    children: int
    alimony_annual: int
    alimony_years: float
    message: str


@dataclass(frozen=True, slots=True)
class FamilyYearResult:
    """Character state, messages, and tax details from the annual family tick."""

    character: Character
    messages: tuple[str, ...] = ()
    tax_assessed: int = 0
    tax_paid: int = 0
    household_income: int = 0


@dataclass(frozen=True, slots=True)
class InfidelityPrompt:
    """Nonce-protected choice between cheating and remaining faithful."""

    nonce: str
    spouse_name: str
    expires_at: int


RING_CATALOG: dict[str, dict[str, int | str]] = {
    "simple_ring": {"name": "Simple band", "price": 10_000, "bonus": 1},
    "silver_ring": {"name": "Silver ring", "price": 100_000, "bonus": 4},
    "gold_ring": {"name": "Gold ring", "price": 500_000, "bonus": 8},
    "diamond_ring": {"name": "Diamond ring", "price": 2_000_000, "bonus": 14},
    "heirloom_ring": {"name": "Heirloom ring", "price": 10_000_000, "bonus": 20},
}

WEDDING_TIERS: dict[str, tuple[str, int]] = {
    "courthouse": ("Courthouse", 10_000),
    "intimate": ("Intimate", 250_000),
    "traditional": ("Traditional", 2_500_000),
    "lavish": ("Lavish", 8_000_000),
}

_NAME_GENDERS = (Gender.MALE, Gender.FEMALE, Gender.NON_BINARY)
_WEALTH_RANGES = {
    "poor": (100_000, 1_500_000),
    "working": (1_500_000, 8_000_000),
    "middle": (8_000_000, 60_000_000),
    "upper": (60_000_000, 500_000_000),
    "rich": (500_000_000, 5_000_000_000),
}
_WEALTH_WEIGHTS = ("poor", "working", "middle", "upper", "rich")
_WEALTH_PROBABILITIES = (0.10, 0.25, 0.40, 0.18, 0.07)
_OCCUPATION_INCOMES = (
    ("Teacher", 5_200_000),
    ("Nurse", 6_000_000),
    ("Engineer", 8_400_000),
    ("Small business owner", 6_500_000),
    ("Artist", 3_800_000),
    ("Accountant", 6_200_000),
    ("Chef", 4_000_000),
    ("Researcher", 7_200_000),
    ("Mechanic", 4_600_000),
    ("Public servant", 5_000_000),
)
_COST_OF_LIVING = {"poor": 0.80, "working": 0.90, "middle": 1.00, "upper": 1.20, "rich": 1.50}


def can_date_ages(player_age: int, npc_age: int) -> bool:
    """Enforce the age boundary for dating independently of generated/UI options."""
    if player_age < 16 or npc_age < 0:
        return False
    if player_age < 18:
        return npc_age < 18 and abs(player_age - npc_age) <= 2
    return npc_age >= 18 and abs(player_age - npc_age) <= 5


def proposal_acceptance_chance(score: int, ring_bonus: int = 0) -> int:
    """Return a clamped proposal chance from relationship score and ring bonus."""
    return max(0, min(100, int(score) - 20 + max(0, min(20, int(ring_bonus)))))


def dating_success_chance(
    *,
    player_looks: int,
    npc_looks: int,
    player_smarts: int,
    npc_smarts: int,
    npc_prefers_smarts: bool,
    fame: int,
    npc_wealth: int,
) -> float:
    """Calculate the requested dating formula and clamp it to 5–90 percent."""
    smarts_bonus = (player_smarts - npc_smarts) * 0.4 if npc_prefers_smarts else 0.0
    wealthy_bonus = 10.0 if npc_wealth >= dollars_to_cents(1_000_000) else 0.0
    value = 40.0 + (player_looks - npc_looks) * 0.8 + smarts_bonus + fame * 0.2 + wealthy_bonus
    return max(5.0, min(90.0, value))


def calculate_fertility_factor(age: int) -> float:
    """Return the specified piecewise female fertility curve."""
    if age < 0:
        raise ValueError("age cannot be negative")
    if age < 30:
        return 1.0
    if age < 35:
        return 1.0 - (age - 30) * 0.06
    if age < 40:
        return 0.7 - (age - 35) * 0.08
    if age < 45:
        return 0.3 - (age - 40) * 0.05
    if age < 50:
        return max(0.0, 0.05 - (age - 45) * 0.01)
    return 0.0


def calculate_male_fertility_factor(age: int) -> float:
    """Return a gentle age-related male fertility multiplier."""
    if age < 0:
        raise ValueError("age cannot be negative")
    return max(0.2, 1.0 - max(0, age - 30) * 0.02)


def calculate_divorce_split(
    *,
    cash: int,
    bank: int,
    marital_item_values: list[int] | tuple[int, ...],
    prenup: bool,
    premarital_cash: int = 0,
    premarital_bank: int = 0,
) -> DivorceSplit:
    """Calculate a 50/50 split in integer cents without making balances negative."""
    values = (cash, bank, premarital_cash, premarital_bank, *marital_item_values)
    if any(isinstance(value, bool) or not isinstance(value, int) or value < 0 for value in values):
        raise ValueError("divorce assets must be non-negative integer cents")
    protected_cash = min(cash, premarital_cash) if prenup else 0
    protected_bank = min(bank, premarital_bank) if prenup else 0
    eligible = cash - protected_cash + bank - protected_bank + sum(marital_item_values)
    return DivorceSplit(
        eligible_assets=eligible,
        spouse_share=eligible // 2,
        protected_assets=protected_cash + protected_bank,
    )


def calculate_alimony(player_income: int, spouse_income: int, marriage_years: int) -> tuple[bool, int, float]:
    """Return (player_pays, annual amount, duration) from 20% of income difference."""
    if player_income < 0 or spouse_income < 0 or marriage_years < 0:
        raise ValueError("incomes and marriage duration must be non-negative")
    difference = abs(int(player_income) - int(spouse_income))
    annual = charge_cents(difference, Decimal("0.20"))
    duration = float(marriage_years) / 2.0
    return player_income > spouse_income, annual, duration


def calculate_joint_tax(
    combined_income: int,
    *,
    price_index: float = 1.0,
    tax_mod: float = 1.0,
) -> int:
    """Apply the same progressive schedule with doubled, inflation-indexed joint brackets."""
    return progressive_income_tax(
        combined_income, price_index=price_index, tax_mod=tax_mod, joint=True
    )


class FamilyService:
    """Transactional family/NPC domain service integrated into LIFELINE's age tick."""

    def __init__(
        self,
        db: Any,
        rng: RNG,
        locks: Optional[UserLockRegistry] = None,
        *,
        repository: Optional[FamilyRepository] = None,
        data_loader: Optional[DataLoader] = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.db = db
        self.rng = rng.fork("lifeline-stage6-family")
        self.locks = locks or UserLockRegistry()
        self.repository = repository or FamilyRepository(db)
        self.clock = clock
        self.data_loader = data_loader or DataLoader()
        self.economic_countries = self.data_loader.load_countries()
        self.names = self.data_loader.load_json("names.json")
        self._validate_names(self.names)

    @staticmethod
    def _validate_names(document: Any) -> None:
        if not isinstance(document, dict) or document.get("schema_version") != 1:
            raise ValueError("names.json must be a schema-version-1 object")
        defaults = document.get("defaults")
        countries = document.get("countries")
        if not isinstance(defaults, dict) or not isinstance(countries, dict):
            raise ValueError("names.json requires defaults and countries objects")
        for group in (defaults, *countries.values()):
            if not isinstance(group, dict):
                raise ValueError("each names group must be an object")
            for gender in ("male", "female", "non_binary"):
                names = group.get(gender)
                if not isinstance(names, list) or not names or any(not isinstance(name, str) or not name.strip() for name in names):
                    raise ValueError(f"names.json requires non-empty {gender} name lists")

    def _name(self, country: str, gender: Gender) -> str:
        """Select a gender-aware name from the character's country or fallback list."""
        group = self.names["countries"].get(country.lower(), self.names["defaults"])
        return self.rng.choice(group[gender.value])

    def _wealth(self, wealth_class: str) -> int:
        """Roll integer-cent NPC net worth within a class-specific band."""
        low, high = _WEALTH_RANGES.get(wealth_class, _WEALTH_RANGES["middle"])
        return self.rng.randint(low, high)

    def _occupation(self, wealth_class: str, *, child: bool = False) -> tuple[str, int]:
        """Choose an NPC occupation and annual income in integer cents."""
        if child:
            return "Student", 0
        occupation, base_income = self.rng.choice(_OCCUPATION_INCOMES)
        multiplier = {"poor": 0.70, "working": 0.85, "middle": 1.0, "upper": 1.3, "rich": 1.8}.get(wealth_class, 1.0)
        return occupation, payout_cents(base_income, multiplier)

    def _stats(self, *, means: Optional[tuple[float, float, float]] = None) -> tuple[int, int, int]:
        """Generate bounded NPC looks, smarts, and health from Gaussian rolls."""
        look_mean, smarts_mean, health_mean = means or (50.0, 50.0, 75.0)
        values = (
            int(round(self.rng.gauss(look_mean, 15.0))),
            int(round(self.rng.gauss(smarts_mean, 15.0))),
            int(round(self.rng.gauss(health_mean, 12.0))),
        )
        return tuple(max(0, min(100, value)) for value in values)  # type: ignore[return-value]

    def _npc_fields(
        self,
        character: Character,
        *,
        gender: Gender,
        age: int,
        wealth_class: Optional[str] = None,
        occupation: Optional[str] = None,
        annual_income: Optional[int] = None,
        means: Optional[tuple[float, float, float]] = None,
        prefers_smarts: Optional[bool] = None,
    ) -> dict[str, Any]:
        """Create generation data while keeping gameplay randomness in the RNG wrapper."""
        selected_wealth = wealth_class or self.rng.weighted_choice(_WEALTH_WEIGHTS, _WEALTH_PROBABILITIES)
        selected_occupation, selected_income = self._occupation(selected_wealth, child=occupation == "Student")
        if occupation is not None:
            selected_occupation = occupation
        if annual_income is not None:
            selected_income = annual_income
        looks, smarts, health = self._stats(means=means)
        return {
            "owner_char_id": character.char_id,
            "name": self._name(character.country, gender),
            "gender": gender.value,
            "age": max(0, min(120, int(age))),
            "looks": looks,
            "smarts": smarts,
            "health": health,
            "wealth": 0 if occupation == "Student" else self._wealth(selected_wealth),
            "occupation": selected_occupation,
            "country": character.country,
            "annual_income": selected_income,
            "prefers_smarts": bool(self.rng.random() < 0.35) if prefers_smarts is None else prefers_smarts,
        }

    async def _insert_npc(self, tx: aiosqlite.Connection, fields: dict[str, Any]) -> int:
        """Persist one NPC using the Stage 6 repository."""
        return await self.repository.create_npc(tx, **fields)

    async def initialize_family(self, tx: aiosqlite.Connection, character: Character) -> tuple[str, ...]:
        """Generate two parents and zero to three siblings at the character's birth."""
        messages: list[str] = []
        parent_ages: list[int] = []
        for gender in (Gender.FEMALE, Gender.MALE):
            age = self.rng.randint(22, 40)
            parent_ages.append(age)
            npc_id = await self._insert_npc(
                tx,
                self._npc_fields(character, gender=gender, age=age, wealth_class=character.wealth_class),
            )
            score = self.rng.randint(60, 90)
            await self.repository.create_relationship(
                tx,
                char_id=character.char_id,
                npc_id=npc_id,
                relation_type="parent",
                score=score,
                since_age=0,
            )
        sibling_count = self.rng.randint(0, 3)
        for _ in range(sibling_count):
            gender = self.rng.choice(_NAME_GENDERS)
            age = self.rng.randint(0, 8)
            fields = self._npc_fields(
                character,
                gender=gender,
                age=age,
                wealth_class=character.wealth_class,
                occupation="Student",
                annual_income=0,
            )
            fields["wealth"] = self._wealth(character.wealth_class)
            npc_id = await self._insert_npc(tx, fields)
            await self.repository.create_relationship(
                tx,
                char_id=character.char_id,
                npc_id=npc_id,
                relation_type="sibling",
                score=self.rng.randint(60, 90),
                since_age=0,
            )
        message = f"Family generated: two parents and {sibling_count} sibling(s)."
        await self.repository.insert_life_log(
            tx,
            char_id=character.char_id,
            age=0,
            category="family",
            text=message,
            importance=2,
            created_at=int(self.clock()),
        )
        messages.append(message)
        return tuple(messages)

    async def _active_character(self, tx: aiosqlite.Connection, user_id: int) -> tuple[Character, int]:
        """Load a versioned active life or raise a user-safe life error."""
        row = await self.repository.load_active(tx, user_id)
        if row is None:
            if await self.repository.has_any_life(tx, user_id):
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.char_id = int(row["char_id"])
        character.user_id = int(row["user_id"])
        character.version = int(row["version"])
        if not character.is_alive:
            raise CharacterDead()
        return character, int(row["version"])

    async def _active_character_read(self, user_id: int) -> Character:
        """Load an active character outside a write transaction."""
        row = await self.repository.load_active_read(user_id)
        if row is None:
            if await self.repository.has_any_life_read(user_id):
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.char_id = int(row["char_id"])
        character.user_id = int(row["user_id"])
        character.version = int(row["version"])
        if not character.is_alive:
            raise CharacterDead()
        return character

    def _check_age(self, character: Character, minimum: int, action: str, *, maximum: Optional[int] = None) -> None:
        """Enforce age gates in the domain engine rather than relying on Discord UI."""
        if character.age < minimum:
            raise EducationRequirementError(f"You must be at least {minimum} to {action}.")
        if maximum is not None and character.age > maximum:
            raise EducationRequirementError(f"You must be age {maximum} or younger to {action}.")

    @staticmethod
    def _check_not_imprisoned(character: Character) -> None:
        """Prevent family actions while the character is serving a prison sentence."""
        if character.in_prison:
            raise FamilyRequirementError("You cannot do this while your character is in prison.")

    async def _check_pending_event(self, tx: aiosqlite.Connection, character: Character) -> None:
        """Keep unresolved Stage 3 choices ahead of new family decisions."""
        if await self.repository.has_pending_event(tx, character.char_id):
            raise PendingEventExists()

    async def family(self, user_id: int) -> tuple[Character, list[dict[str, Any]]]:
        """Return the active life and its complete relationship roster."""
        async with self.locks.hold(user_id):
            character = await self._active_character_read(user_id)
            people = await self.repository.list_people(character.char_id)
            return character, people

    async def relationship_list(self, user_id: int) -> tuple[Character, list[dict[str, Any]]]:
        """Return the same relationship roster for the explicit relationship command."""
        return await self.family(user_id)

    async def autocomplete_people(self, user_id: int, query: str) -> list[dict[str, Any]]:
        """Return owned, living NPC relationships matching a short autocomplete query."""
        character = await self._active_character_read(user_id)
        return await self.repository.autocomplete_people(character.char_id, query[:80])

    async def find_dates(self, user_id: int) -> DateSearch:
        """Create exactly three age-eligible, persistent dating candidates."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 16, "start dating")
                romance = await self.repository.active_romance(tx, character.char_id)
                if romance is not None:
                    raise FamilyRequirementError("End your current relationship before searching for dates.")
                candidates: list[dict[str, Any]] = []
                npc_ids: list[int] = []
                for _ in range(3):
                    gender = self.rng.choice(_NAME_GENDERS)
                    if character.age < 18:
                        low, high = max(0, character.age - 2), min(17, character.age + 2)
                    else:
                        low, high = max(18, character.age - 5), min(120, character.age + 5)
                    age = self.rng.randint(low, high)
                    fields = self._npc_fields(character, gender=gender, age=age)
                    npc_id = await self._insert_npc(tx, fields)
                    fields["npc_id"] = npc_id
                    candidates.append(fields)
                    npc_ids.append(npc_id)
                now = int(self.clock())
                nonce = secrets.token_urlsafe(16)
                expires = now + 900
                await self.repository.save_dating_session(tx, character.char_id, nonce, now, expires, npc_ids)
                return DateSearch(nonce, tuple(candidates), expires)

    async def choose_date(self, user_id: int, npc_id: int, nonce: str) -> DateOutcome:
        """Resolve a date select-menu choice, enforcing age and ownership in-engine."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 16, "date")
                candidate = await self.repository.get_dating_candidate(
                    tx, character.char_id, int(npc_id), nonce, int(self.clock())
                )
                if candidate is None:
                    raise DateSessionExpired()
                if not can_date_ages(character.age, int(candidate["age"])):
                    raise FamilyRequirementError("Dating age rules do not allow that match.")
                if await self.repository.active_romance(tx, character.char_id) is not None:
                    raise FamilyRequirementError("You already have an active relationship.")
                stats = character.stats
                chance = dating_success_chance(
                    player_looks=stats.looks,
                    npc_looks=int(candidate["looks"]),
                    player_smarts=stats.smarts,
                    npc_smarts=int(candidate["smarts"]),
                    npc_prefers_smarts=bool(candidate["prefers_smarts"]),
                    fame=stats.fame,
                    npc_wealth=int(candidate["wealth"]),
                )
                accepted = self.rng.random() * 100.0 < chance
                if accepted:
                    await self.repository.create_relationship(
                        tx,
                        char_id=character.char_id,
                        npc_id=int(candidate["npc_id"]),
                        relation_type="partner",
                        score=60,
                        since_age=character.age,
                    )
                await self.repository.consume_dating_session(tx, character.char_id, nonce)
                name = str(candidate["name"])
                await self.repository.insert_life_log(
                    tx,
                    char_id=character.char_id,
                    age=character.age,
                    category="relationship",
                    text=(f"Started dating {name}." if accepted else f"A date with {name} did not turn into a relationship."),
                    importance=2,
                    created_at=int(self.clock()),
                )
                return DateOutcome(dict(candidate), chance, accepted, 60 if accepted else None)

    async def find_friend(self, user_id: int) -> dict[str, Any]:
        """Meet one age-appropriate NPC friend and persist the relationship."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 6, "make new friends")
                if character.age < 18:
                    low, high = max(0, character.age - 2), min(17, character.age + 2)
                else:
                    low, high = max(18, character.age - 5), min(120, character.age + 5)
                age = self.rng.randint(low, high)
                gender = self.rng.choice(_NAME_GENDERS)
                npc_id = await self._insert_npc(
                    tx,
                    self._npc_fields(character, gender=gender, age=age),
                )
                score = self.rng.randint(50, 65)
                await self.repository.create_relationship(
                    tx,
                    char_id=character.char_id,
                    npc_id=npc_id,
                    relation_type="friend",
                    score=score,
                    since_age=character.age,
                )
                person = await self.repository.get_person(tx, character.char_id, npc_id)
                return dict(person or {"npc_id": npc_id, "name": "Friend", "age": age, "relationship_score": score})

    async def interact(self, user_id: int, npc_id: int, action: str, gift_dollars: Optional[int] = None) -> InteractionOutcome:
        """Interact with one connected NPC, enforcing three actions per person/year."""
        selected = str(action).lower()
        allowed = {"spend_time", "gift", "compliment", "argue", "ask_for_money", "insult"}
        if selected not in allowed:
            raise ValidationError("Choose spend_time, gift, compliment, argue, ask_for_money, or insult.")
        if selected == "gift" and (gift_dollars is None or gift_dollars <= 0):
            raise ValidationError("A gift requires a positive amount in whole dollars.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 6, "interact with people")
                person = await self.repository.get_person(tx, character.char_id, int(npc_id))
                if person is None:
                    raise RelationshipNotFound()
                if not bool(person["is_alive"]):
                    raise FamilyRequirementError("You cannot interact with someone who has died.")
                if not await self.repository.claim_interaction(tx, character.char_id, int(npc_id), character.age):
                    raise InteractionLimitReached()

                before = int(person["relationship_score"])
                money_delta = 0
                if selected == "spend_time":
                    delta = self.rng.randint(5, 10)
                    message = f"You spent quality time with {person['name']} (+{delta} relationship)."
                elif selected == "compliment":
                    delta = self.rng.randint(2, 8)
                    message = f"You gave {person['name']} a sincere compliment (+{delta})."
                elif selected == "argue":
                    delta = -self.rng.randint(5, 15)
                    message = f"You argued with {person['name']} ({delta} relationship)."
                elif selected == "insult":
                    delta = -self.rng.randint(10, 25)
                    message = f"You insulted {person['name']} ({delta} relationship)."
                elif selected == "gift":
                    gift_value = dollars_to_cents(gift_dollars or 0)
                    available = character.cash + character.bank
                    if gift_value > available:
                        raise InsufficientFunds("You do not have enough cash or bank balance for that gift.")
                    income = await self.repository.get_annual_job_income(tx, character.char_id)
                    reference = max(income, dollars_to_cents(1_000))
                    ratio = min(1.0, gift_value / reference)
                    delta = max(3, min(15, int(round(3 + 12 * ratio))))
                    character, _ = self._deduct_cash_bank(character, gift_value)
                    character = replace(character, version=expected_version + 1)
                    await self.repository.save_character(tx, character, expected_version)
                    await self.repository.add_npc_wealth(tx, int(npc_id), gift_value)
                    money_delta = -gift_value
                    message = f"You gave {person['name']} a gift worth {gift_dollars:,} dollars (+{delta} relationship)."
                else:
                    if person["relationship_type"] != "parent":
                        raise FamilyRequirementError("Only a parent can be asked for money.")
                    wealth = int(person["wealth"])
                    income_factor = min(25, (wealth // dollars_to_cents(100_000)) * 3)
                    chance = max(5, min(90, int(before * 0.60 + income_factor)))
                    if self.rng.random() * 100 < chance and wealth > 0:
                        amount = min(wealth, dollars_to_cents(self.rng.randint(100, 5_000)))
                        await self.repository.add_npc_wealth(tx, int(npc_id), -amount)
                        character = replace(character, cash=character.cash + amount, version=expected_version + 1)
                        await self.repository.save_character(tx, character, expected_version)
                        money_delta = amount
                        delta = self.rng.randint(1, 4)
                        message = f"{person['name']} agreed to help with {amount // 100:,} dollars."
                    else:
                        delta = -self.rng.randint(1, 3)
                        message = f"{person['name']} could not help with money this time."
                after = max(0, min(100, before + delta))
                await self.repository.set_relationship_score(tx, character.char_id, int(npc_id), after)
                await self.repository.log_relationship_interaction(
                    tx, character.char_id, character.age, message, int(self.clock())
                )
                return InteractionOutcome(str(person["name"]), selected, before, after, message, money_delta)

    async def propose(self, user_id: int, npc_id: int) -> ProposalOutcome:
        """Propose after a year of dating with a score of at least 70."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "propose")
                person = await self.repository.get_person(tx, character.char_id, int(npc_id))
                if person is None or not bool(person["is_alive"]):
                    raise RelationshipNotFound()
                if person["relationship_type"] != "partner" or int(person["relationship_score"]) < 70:
                    raise FamilyRequirementError("You need a living partner with relationship score 70 or higher.")
                if character.age - int(person["relationship_since_age"]) < 1:
                    raise FamilyRequirementError("You must have been dating for at least one in-game year.")
                if int(person["age"]) < 18:
                    raise FamilyRequirementError("Adults may only propose to adults.")
                active = await self.repository.active_romance(tx, character.char_id)
                if active is not None and int(active["npc_id"]) != int(npc_id):
                    raise FamilyRequirementError("End your other active relationship before proposing.")
                rings = await self.repository.list_ring_assets(tx, character.char_id)
                ring = rings[0] if rings else None
                ring_bonus = int(RING_CATALOG.get(str(ring["item_id"]), {}).get("bonus", 0)) if ring else 0
                chance = proposal_acceptance_chance(int(person["relationship_score"]), ring_bonus)
                if ring is not None:
                    await self.repository.consume_ring(tx, int(ring["asset_id"]))
                accepted = self.rng.random() * 100.0 < chance
                if accepted:
                    await self.repository.set_relationship_type(tx, character.char_id, int(npc_id), "fiance")
                    message = f"{person['name']} accepted your proposal!"
                else:
                    message = f"{person['name']} declined the proposal."
                await self.repository.insert_life_log(
                    tx, char_id=character.char_id, age=character.age,
                    category="relationship", text=message, importance=3, created_at=int(self.clock()),
                )
                return ProposalOutcome(str(person["name"]), chance, accepted, ring_bonus)

    async def buy_ring(self, user_id: int, item_id: str) -> tuple[int, int]:
        """Purchase one catalog ring for a future proposal."""
        ring = RING_CATALOG.get(str(item_id))
        if ring is None:
            raise ValidationError("That ring is not sold by the relationship shop.")
        price = int(ring["price"])
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "buy a wedding ring")
                if character.cash + character.bank < price:
                    raise InsufficientFunds("You do not have enough available funds for this ring.")
                updated, _ = self._deduct_cash_bank(character, price)
                updated = replace(updated, version=expected_version + 1)
                await self.repository.save_character(tx, updated, expected_version)
                await self.repository.add_asset(
                    tx, char_id=character.char_id, kind="item", item_id=str(item_id), quantity=1,
                    purchase_price=price, current_value=price, acquired_age=character.age,
                    acquired_at=int(self.clock()),
                )
                return price, int(ring["bonus"])

    async def marry(self, user_id: int, wedding: str = "courthouse", prenup: bool = False) -> MarriageOutcome:
        """Hold a wedding, charge its price-indexed cost, and save optional prenup terms."""
        selected = str(wedding).lower()
        if selected not in WEDDING_TIERS:
            raise ValidationError("Choose courthouse, intimate, traditional, or lavish.")
        if not isinstance(prenup, bool):
            raise ValidationError("Prenup must be true or false.")
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "get married")
                if await self.repository.get_marriage(tx, character.char_id) is not None:
                    raise FamilyRequirementError("You are already married.")
                person = await self.repository.active_romance(tx, character.char_id)
                if person is None or person["relationship_type"] != "fiance" or not bool(person["is_alive"]):
                    raise FamilyRequirementError("You need a living fiance before you can marry.")
                if int(person["age"]) < 18:
                    raise FamilyRequirementError("Both partners must be adults to marry.")
                label, base_cost = WEDDING_TIERS[selected]
                cost = charge_cents(base_cost, Decimal(str(character.price_index)))
                if character.cash + character.bank < cost:
                    raise InsufficientFunds(f"You need {cost // 100:,} dollars for this wedding.")
                updated, _ = self._deduct_cash_bank(character, cost)
                updated = replace(updated, version=expected_version + 1)
                await self.repository.save_character(tx, updated, expected_version)
                await self.repository.set_relationship_type(tx, character.char_id, int(person["npc_id"]), "spouse")
                await self.repository.create_marriage(
                    tx,
                    char_id=character.char_id,
                    spouse_npc_id=int(person["npc_id"]),
                    start_age=character.age,
                    spouse_income=int(person["annual_income"]),
                    prenup=prenup,
                    premarital_cash=updated.cash,
                    premarital_bank=updated.bank,
                    wedding_cost=cost,
                    created_at=int(self.clock()),
                )
                await self.repository.insert_life_log(
                    tx,
                    char_id=character.char_id,
                    age=character.age,
                    category="relationship",
                    text=f"{character.name} married {person['name']} in a {label.lower()} wedding.",
                    importance=4,
                    created_at=int(self.clock()),
                )
                return MarriageOutcome(str(person["name"]), cost, prenup, int(person["annual_income"]))

    async def divorce(self, user_id: int) -> DivorceOutcome:
        """Atomically divorce, divide eligible assets, roll custody, and record support."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "divorce")
                result, updated = await self._divorce_in_tx(
                    tx, character, expected_version, reason="player", now=int(self.clock()), save_character=True
                )
                return replace(result, character=updated)

    async def _divorce_in_tx(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
        *,
        reason: str,
        now: int,
        save_character: bool,
    ) -> tuple[DivorceOutcome, Character]:
        """Perform every divorce write in the caller's existing transaction."""
        marriage = await self.repository.get_marriage(tx, character.char_id)
        if marriage is None:
            raise NoActiveMarriage()
        spouse = await self.repository.get_person(tx, character.char_id, int(marriage["spouse_npc_id"]))
        if spouse is None:
            raise FamilyRequirementError("Your spouse record is unavailable.")
        marriage_years = max(0, character.age - int(marriage["start_age"]))
        player_income = await self.repository.get_annual_job_income(tx, character.char_id)
        spouse_income = int(spouse["annual_income"])
        player_pays_alimony, alimony_annual, alimony_years = calculate_alimony(
            player_income, spouse_income, marriage_years
        )
        updated = character

        # Liquidate marital stocks into bank cash before calculating the split.
        stock_total = await self.repository.liquidate_stock_assets(
            tx, character.char_id, int(marriage["created_at"])
        )
        updated = replace(updated, bank=updated.bank + stock_total)
        item_assets = await self.repository.get_marital_assets(
            tx, character.char_id, int(marriage["created_at"])
        )
        item_values = [int(asset["current_value"]) for asset in item_assets if asset["kind"] == "item"]
        split = calculate_divorce_split(
            cash=updated.cash,
            bank=updated.bank,
            marital_item_values=item_values,
            prenup=bool(marriage["prenup"]),
            premarital_cash=int(marriage["premarital_cash"]),
            premarital_bank=int(marriage["premarital_bank"]),
        )
        protected_cash = int(marriage["premarital_cash"]) if bool(marriage["prenup"]) else 0
        protected_bank = int(marriage["premarital_bank"]) if bool(marriage["prenup"]) else 0
        updated, _ = await self._pay_divorce_assets(
            tx,
            updated,
            split.spouse_share,
            marriage_timestamp=int(marriage["created_at"]),
            protect_cash=protected_cash,
            protect_bank=protected_bank,
            marital_only=True,
        )
        await self.repository.add_npc_wealth(tx, int(spouse["npc_id"]), split.spouse_share)

        lawyer_fee = self.rng.randint(dollars_to_cents(5_000), dollars_to_cents(50_000))
        updated, _ = await self._pay_divorce_assets(
            tx,
            updated,
            lawyer_fee,
            marriage_timestamp=int(marriage["created_at"]),
            marital_only=False,
        )

        children = await self.repository.get_children(tx, character.char_id)
        support_amount = charge_cents(max(0, player_income), Decimal("0.15"))
        for child in children:
            if not bool(child["is_alive"]) or int(child["age"]) >= 18:
                await self.repository.update_child_support(tx, int(child["npc_id"]), 0)
                continue
            custody = self._roll_custody(character, player_income)
            child_support = support_amount if custody != "full" else 0
            await self.repository.update_custody_and_support(
                tx, int(child["npc_id"]), custody, child_support
            )
        if alimony_annual > 0 and alimony_years > 0:
            await self.repository.create_alimony(
                tx,
                character.char_id,
                int(spouse["npc_id"]),
                alimony_annual,
                alimony_years,
                player_pays_alimony,
            )
        await self.repository.set_relationship_type(tx, character.char_id, int(spouse["npc_id"]), "ex")
        await self.repository.set_relationship_score(
            tx, character.char_id, int(spouse["npc_id"]), max(0, int(spouse.get("relationship_score", 50)) - 30)
        )
        await self.repository.delete_marriage(tx, character.char_id)
        await self.repository.delete_affair(tx, character.char_id)
        stats = replace(character.stats)
        stats.happiness = max(0, stats.happiness - 25)
        updated = replace(updated, stats=stats, version=expected_version + 1)
        if save_character:
            await self.repository.save_character(tx, updated, expected_version)
        await self.repository.increment_divorces(tx, character.char_id)
        await self.repository.insert_divorce_record(
            tx,
            char_id=character.char_id,
            spouse_npc_id=int(spouse["npc_id"]),
            age=character.age,
            prenup=bool(marriage["prenup"]),
            marital_assets=split.eligible_assets,
            spouse_share=split.spouse_share,
            lawyer_fee=lawyer_fee,
            reason=reason,
            created_at=now,
        )
        message = (
            f"Divorced {spouse['name']}. The spouse's share was {split.spouse_share // 100:,} dollars; "
            f"lawyer fees were {lawyer_fee // 100:,} dollars."
        )
        await self.repository.insert_life_log(
            tx,
            char_id=character.char_id,
            age=character.age,
            category="relationship",
            text=message,
            importance=4,
            created_at=now,
        )
        return (
            DivorceOutcome(
                updated,
                str(spouse["name"]),
                split.eligible_assets,
                split.spouse_share,
                lawyer_fee,
                sum(1 for child in children if bool(child["is_alive"]) and int(child["age"]) < 18),
                alimony_annual,
                alimony_years,
                message,
            ),
            updated,
        )

    async def breakup(self, user_id: int, npc_id: int) -> str:
        """End a dating or engagement relationship without legal divorce."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 16, "end a relationship")
                person = await self.repository.get_person(tx, character.char_id, int(npc_id))
                if (
                    person is None
                    or not bool(person["is_alive"])
                    or person["relationship_type"] not in {"partner", "fiance"}
                ):
                    raise FamilyRequirementError("You can only break up with a living partner or fiance.")
                await self.repository.set_relationship_type(tx, character.char_id, int(npc_id), "ex")
                await self.repository.add_relationship_score(tx, character.char_id, int(npc_id), -20)
                await self.repository.insert_life_log(
                    tx, char_id=character.char_id, age=character.age, category="relationship",
                    text=f"Ended the relationship with {person['name']}.", importance=3, created_at=int(self.clock()),
                )
                return f"You and {person['name']} have broken up."

    async def try_for_baby(self, user_id: int) -> tuple[bool, float]:
        """Try to conceive with a current partner or spouse using age-based fertility."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "try for a baby")
                partner = await self.repository.active_romance(tx, character.char_id)
                if (
                    partner is None
                    or partner["relationship_type"] not in {"partner", "spouse"}
                    or not bool(partner["is_alive"])
                ):
                    raise FamilyRequirementError("You need a living partner or spouse to try for a baby.")
                if int(partner["age"]) < 18:
                    raise FamilyRequirementError("Both partners must be adults to try for a baby.")
                if await self.repository.get_pregnancy(tx, character.char_id) is not None:
                    raise FamilyRequirementError("A pregnancy is already in progress.")
                if await self.repository.get_adoption(tx, character.char_id) is not None:
                    raise FamilyRequirementError("An adoption is already in progress.")
                if not await self.repository.claim_yearly_action(
                    tx, character.char_id, int(partner["npc_id"]), character.age, "try_for_baby"
                ):
                    raise FamilyRequirementError("You can try for a baby with this partner once per year.")
                probability = self._couple_fertility(character, partner)
                success = self.rng.random() < probability
                if success:
                    await self.repository.add_pregnancy(
                        tx,
                        char_id=character.char_id,
                        other_parent_npc_id=int(partner["npc_id"]),
                        conception_age=character.age,
                        due_age=character.age + 1,
                        accidental=False,
                    )
                    message = f"A pregnancy is underway with {partner['name']}; the baby is due after one year."
                else:
                    message = "There was no pregnancy this year. You can try again next year."
                await self.repository.insert_life_log(
                    tx, char_id=character.char_id, age=character.age, category="family",
                    text=message, importance=3, created_at=int(self.clock()),
                )
                return success, probability

    @staticmethod
    def _couple_fertility(character: Character, partner: dict[str, Any]) -> float:
        """Combine the gestational partner curve and the other partner's factor."""
        try:
            partner_gender = Gender(str(partner["gender"]))
        except ValueError:
            partner_gender = Gender.NON_BINARY
        if character.gender is Gender.FEMALE:
            female_age = character.age
            male_age = int(partner["age"]) if partner_gender is Gender.MALE else 30
        elif partner_gender is Gender.FEMALE:
            female_age = int(partner["age"])
            male_age = character.age
        else:
            return 0.0
        return 0.35 * calculate_fertility_factor(female_age) * calculate_male_fertility_factor(male_age)

    async def adopt(self, user_id: int) -> int:
        """Pay the indexed adoption cost and schedule an infant after one age tick."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 21, "adopt a child")
                if await self.repository.get_adoption(tx, character.char_id) is not None:
                    raise FamilyRequirementError("An adoption is already in progress.")
                if await self.repository.get_pregnancy(tx, character.char_id) is not None:
                    raise FamilyRequirementError("Resolve the current pregnancy before starting an adoption.")
                cost = charge_cents(dollars_to_cents(30_000), Decimal(str(character.price_index)))
                if character.cash + character.bank < cost:
                    raise InsufficientFunds("You need enough cash or bank balance to cover the adoption cost.")
                updated, _ = self._deduct_cash_bank(character, cost)
                updated = replace(updated, version=expected_version + 1)
                await self.repository.save_character(tx, updated, expected_version)
                await self.repository.add_adoption(tx, character.char_id, character.age, character.age + 1, cost)
                await self.repository.insert_life_log(
                    tx, char_id=character.char_id, age=character.age, category="family",
                    text=f"Started an adoption; the child will join the family after one year. Cost: {cost // 100:,} dollars.",
                    importance=3, created_at=int(self.clock()),
                )
                return cost

    async def buy_ring_options(self) -> tuple[dict[str, Any], ...]:
        """Return immutable view data for the ring shop."""
        return tuple({"id": item_id, **values} for item_id, values in RING_CATALOG.items())

    async def start_infidelity_choice(self, user_id: int) -> InfidelityPrompt:
        """Create a one-use choice prompt for a married character's temptation event."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "consider an affair")
                marriage = await self.repository.get_marriage(tx, character.char_id)
                if marriage is None:
                    raise NoActiveMarriage()
                if await self.repository.has_infidelity_choice(tx, character.char_id, character.age):
                    raise FamilyRequirementError("The relationship choice for this in-game year has already been resolved.")
                spouse = await self.repository.get_npc_owned(tx, character.char_id, int(marriage["spouse_npc_id"]))
                if spouse is None or not bool(spouse["is_alive"]):
                    raise FamilyRequirementError("There is no living spouse to betray.")
                nonce = secrets.token_urlsafe(16)
                now = int(self.clock())
                await self.repository.create_infidelity_prompt(
                    tx, character.char_id, int(spouse["npc_id"]), nonce, now, now + 300
                )
                return InfidelityPrompt(nonce, str(spouse["name"]), now + 300)

    async def resolve_infidelity_choice(self, user_id: int, nonce: str, cheat: bool) -> str:
        """Resolve a nonce-protected temptation choice and record an affair if chosen."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                await self._check_pending_event(tx, character)
                self._check_not_imprisoned(character)
                self._check_age(character, 18, "resolve a relationship choice")
                prompt = await self.repository.get_infidelity_prompt(
                    tx, character.char_id, nonce, int(self.clock())
                )
                if prompt is None:
                    raise DateSessionExpired("This relationship choice expired. Start a new one with `/relationship temptation`.")
                marriage = await self.repository.get_marriage(tx, character.char_id)
                if marriage is None or int(marriage["spouse_npc_id"]) != int(prompt["spouse_npc_id"]):
                    raise FamilyRequirementError("The marriage ended before this choice was resolved.")
                now = int(self.clock())
                await self.repository.record_infidelity_choice(
                    tx,
                    character.char_id,
                    int(prompt["spouse_npc_id"]),
                    character.age,
                    "cheat" if cheat else "faithful",
                    now,
                )
                if cheat:
                    await self.repository.save_affair(
                        tx, character.char_id, int(prompt["spouse_npc_id"]), character.age, nonce
                    )
                    message = "You chose to cheat. There is a 35% chance of discovery each year."
                else:
                    message = "You stayed faithful and ended the temptation."
                await self.repository.delete_infidelity_prompt(tx, character.char_id, nonce)
                await self.repository.insert_life_log(
                    tx, char_id=character.char_id, age=character.age, category="relationship",
                    text=message, importance=3, created_at=now,
                )
                return message

    async def _create_child(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        other_parent_npc_id: Optional[int],
        *,
        adopted: bool,
    ) -> tuple[int, str]:
        """Create a child NPC with parent-average traits and a full-custody record."""
        other_parent = None
        if other_parent_npc_id is not None:
            other_parent = await self.repository.get_npc_owned(tx, character.char_id, other_parent_npc_id)
        if adopted or other_parent is None:
            means = (50.0, 50.0, 75.0)
        else:
            means = (
                (character.stats.looks + int(other_parent["looks"])) / 2,
                (character.stats.smarts + int(other_parent["smarts"])) / 2,
                (character.stats.health + int(other_parent["health"])) / 2,
            )
        gender = self.rng.choice(_NAME_GENDERS)
        fields = self._npc_fields(
            character,
            gender=gender,
            age=0,
            wealth_class="poor",
            occupation="Student",
            annual_income=0,
            means=means,
        )
        fields["wealth"] = 0
        npc_id = await self._insert_npc(tx, fields)
        score = self.rng.randint(80, 95)
        await self.repository.create_relationship(
            tx, char_id=character.char_id, npc_id=npc_id, relation_type="child", score=score, since_age=character.age
        )
        await self.repository.add_child(
            tx,
            npc_id=npc_id,
            char_id=character.char_id,
            other_parent_npc_id=other_parent_npc_id,
            custody="full",
            child_support=0,
        )
        return npc_id, str(fields["name"])

    async def advance_year(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        previous_age: int,
        personal_income: int,
        now: int,
    ) -> FamilyYearResult:
        """Settle family expenses/support and execute Stage 6 yearly step 11.

        This runs in the same BEGIN IMMEDIATE transaction as ``/life age``. It
        pays spouse wages/tax, child costs/support and alimony, completes adoptions
        and pregnancies, checks infidelity/divorce, then decays relationships and
        ages all NPCs. Stage 1-5 RNG is not consumed; this service owns a forked RNG.
        """
        updated = character
        messages: list[str] = []
        newborn_npc_ids: set[int] = set()
        tax_assessed = 0
        tax_paid = 0
        household_income = max(0, int(personal_income))
        marriage = await self.repository.get_marriage(tx, character.char_id)
        if marriage is not None:
            spouse = await self.repository.get_npc_owned(tx, character.char_id, int(marriage["spouse_npc_id"]))
            if spouse is not None and bool(spouse["is_alive"]):
                spouse_income = int(spouse["annual_income"])
                household_income += spouse_income
                if not character.in_prison:
                    tax_mod, _, _ = _country_modifiers(self.economic_countries, updated.country)
                    joint_tax = calculate_joint_tax(
                        max(0, personal_income) + spouse_income,
                        price_index=updated.price_index,
                        tax_mod=tax_mod,
                    )
                    updated = replace(updated, cash=updated.cash + spouse_income)
                    updated, tax_unpaid = self._deduct_cash_bank(updated, joint_tax)
                    tax_assessed = joint_tax
                    tax_paid = max(0, joint_tax - tax_unpaid)
                    if tax_unpaid:
                        updated = replace(updated, debt_total=updated.debt_total + tax_unpaid)
                    messages.append(
                        f"Household income included {spouse_income // 100:,} dollars from {spouse['name']}; joint tax was {joint_tax // 100:,} dollars."
                    )
                else:
                    messages.append("Spouse income and household tax settlement were paused during imprisonment.")
            else:
                await self.repository.set_relationship_type(
                    tx, character.char_id, int(marriage["spouse_npc_id"]), "ex"
                )
                await self.repository.delete_marriage(tx, character.char_id)
                messages.append("The marriage ended after your spouse's death.")

        children = await self.repository.get_children(tx, character.char_id)
        for child in children:
            child_age = int(child["age"]) + (1 if bool(child["is_alive"]) else 0)
            custody = str(child["custody"])
            minor_alive = bool(child["is_alive"]) and child_age < 18
            if not character.in_prison and minor_alive and custody in {"full", "shared"}:
                cost = charge_cents(
                    dollars_to_cents(12_000),
                    Decimal(str(character.price_index))
                    * Decimal(str(_COST_OF_LIVING.get(character.wealth_class, 1.0)))
                    * (Decimal("0.5") if custody == "shared" else Decimal("1")),
                )
                updated, unpaid = self._deduct_cash_bank(updated, cost)
                if unpaid:
                    updated = replace(updated, debt_total=updated.debt_total + unpaid)
                messages.append(f"Child care cost for {child['name']}: {cost // 100:,} dollars.")
            if not character.in_prison and minor_alive and custody != "full":
                support = charge_cents(max(0, personal_income), Decimal("0.15"))
                await self.repository.update_child_support(tx, int(child["npc_id"]), support)
                updated, unpaid = self._deduct_cash_bank(updated, support)
                if unpaid:
                    updated = replace(updated, debt_total=updated.debt_total + unpaid)
                if support and child["other_parent_npc_id"] is not None:
                    await self.repository.add_npc_wealth(tx, int(child["other_parent_npc_id"]), support)
                if support:
                    messages.append(f"Child support paid for {child['name']}: {support // 100:,} dollars.")
            elif (child_age >= 18 or not bool(child["is_alive"])) and int(child["child_support"]) > 0:
                await self.repository.update_child_support(tx, int(child["npc_id"]), 0)
                if bool(child["is_alive"]):
                    messages.append(f"Child support ended for {child['name']} at age 18.")
                else:
                    messages.append(f"Child support ended for {child['name']} after their death.")

        alimony = await self.repository.get_alimony(tx, character.char_id)
        if alimony is not None and not character.in_prison:
            fraction = min(1.0, float(alimony["remaining_years"]))
            amount = charge_cents(int(alimony["annual_amount"]), Decimal(str(fraction)))
            if bool(alimony["payer_is_player"]):
                updated, unpaid = self._deduct_cash_bank(updated, amount)
                if unpaid:
                    updated = replace(updated, debt_total=updated.debt_total + unpaid)
                if amount:
                    await self.repository.add_npc_wealth(tx, int(alimony["ex_npc_id"]), amount)
                    messages.append(f"Alimony paid: {amount // 100:,} dollars.")
            else:
                updated = replace(updated, cash=updated.cash + amount)
                await self.repository.add_npc_wealth(tx, int(alimony["ex_npc_id"]), -amount)
                if amount:
                    messages.append(f"Alimony received: {amount // 100:,} dollars.")
            await self.repository.update_alimony(
                tx, character.char_id, max(0.0, float(alimony["remaining_years"]) - 1.0)
            )

        pregnancy = await self.repository.get_pregnancy(tx, character.char_id)
        if pregnancy is not None and int(pregnancy["due_age"]) <= character.age:
            newborn_id, child_name = await self._create_child(
                tx, character, pregnancy["other_parent_npc_id"], adopted=False
            )
            newborn_npc_ids.add(newborn_id)
            await self.repository.delete_pregnancy(tx, character.char_id)
            messages.append(f"{child_name} joined the family.")

        adoption = await self.repository.get_adoption(tx, character.char_id)
        if adoption is not None and int(adoption["due_age"]) <= character.age:
            newborn_id, child_name = await self._create_child(tx, character, None, adopted=True)
            newborn_npc_ids.add(newborn_id)
            await self.repository.delete_adoption(tx, character.char_id)
            messages.append(f"The adoption was finalized: {child_name} joined the family.")

        if marriage is not None and not character.in_prison:
            affair = await self.repository.get_affair(tx, character.char_id)
            if affair is not None and int(affair["started_age"]) < character.age:
                if self.rng.random() < 0.35:
                    await self.repository.add_relationship_score(
                        tx, character.char_id, int(affair["spouse_npc_id"]), -40
                    )
                    await self.repository.delete_affair(tx, character.char_id)
                    messages.append("Your infidelity was discovered; your spouse's relationship score fell by 40.")
                    if self.rng.random() < 0.60:
                        expected = character.version
                        divorce, updated = await self._divorce_in_tx(
                            tx, updated, expected, reason="discovery", now=now, save_character=False
                        )
                        messages.append(divorce.message)

            # Below-20 spouse relationship scores can trigger an NPC-initiated divorce.
            current_marriage = await self.repository.get_marriage(tx, character.char_id)
            if current_marriage is not None:
                spouse_relation = await self.repository.get_person(
                    tx, character.char_id, int(current_marriage["spouse_npc_id"])
                )
                if spouse_relation is not None:
                    low_years = int(current_marriage.get("low_score_years", 0))
                    if int(spouse_relation["relationship_score"]) < 20:
                        low_years += 1
                    else:
                        low_years = 0
                    await self.repository.update_marriage_low_score_years(tx, character.char_id, low_years)
                    if low_years >= 2 and self.rng.random() < 0.50:
                        divorce, updated = await self._divorce_in_tx(
                            tx, updated, character.version, reason="npc_initiated", now=now, save_character=False
                        )
                        messages.append(divorce.message)

        # Accidentally conceived pregnancies are permitted while an adult is partnered.
        active = await self.repository.active_romance(tx, character.char_id)
        if (
            character.is_alive
            and not character.in_prison
            and character.age >= 18
            and active is not None
            and bool(active["is_alive"])
            and await self.repository.get_pregnancy(tx, character.char_id) is None
            and await self.repository.get_adoption(tx, character.char_id) is None
        ):
            fertility = self._couple_fertility(character, active)
            if fertility > 0 and self.rng.random() < 0.02 * fertility:
                await self.repository.add_pregnancy(
                    tx,
                    char_id=character.char_id,
                    other_parent_npc_id=int(active["npc_id"]),
                    conception_age=character.age,
                    due_age=character.age + 1,
                    accidental=True,
                )
                messages.append("An unexpected pregnancy began; the baby is due after one year.")

        # Step 11: decay scores for unattended connections, then age and roll NPC mortality.
        await self.repository.decay_relationships(tx, character.char_id, previous_age)
        npc_rows = await self.repository.list_live_npcs(tx, character.char_id)
        for npc in npc_rows:
            if int(npc["npc_id"]) in newborn_npc_ids:
                continue
            next_age = min(120, int(npc["age"]) + 1)
            risk = self._npc_death_chance(next_age, int(npc["health"]))
            alive = next_age < 120 and self.rng.random() >= risk
            await self.repository.update_npc_year(tx, int(npc["npc_id"]), next_age, alive=alive)
            if not alive:
                updated = await self._on_npc_death(tx, updated, npc, next_age, now, messages)

        romance = await self.repository.active_romance(tx, character.char_id)
        if (
            romance is not None
            and romance["relationship_type"] in {"partner", "fiance"}
            and not can_date_ages(character.age, int(romance["age"]))
        ):
            await self.repository.set_relationship_type(
                tx, character.char_id, int(romance["npc_id"]), "ex"
            )
            messages.append(f"The relationship with {romance['name']} ended as your ages no longer met dating rules.")
        if not character.in_prison:
            updated = await self._family_events(tx, updated, messages)
        return FamilyYearResult(updated, tuple(messages), tax_assessed, tax_paid, household_income)

    @staticmethod
    def _npc_death_chance(age: int, health: int) -> float:
        """Return an age- and health-sensitive annual NPC death probability."""
        if age >= 120:
            return 1.0
        age_risk = 0.0005 + max(0, age - 60) * 0.0015
        health_risk = max(0, 50 - health) * 0.0015
        if age < 18:
            age_risk *= 0.15
        return min(0.65, age_risk + health_risk)

    async def _on_npc_death(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        npc: dict[str, Any],
        death_age: int,
        now: int,
        messages: list[str],
    ) -> Character:
        """Apply grief, inheritance, or relationship changes after NPC death."""
        person = await self.repository.get_person(tx, character.char_id, int(npc["npc_id"]))
        if person is None:
            messages.append(f"{npc['name']} died at age {death_age}.")
            return character
        relation = str(person["relationship_type"])
        if relation == "parent":
            grief = self.rng.randint(15, 30)
            stats = replace(character.stats)
            stats.happiness = max(0, stats.happiness - grief)
            sibling_count = await self.repository.count_siblings(tx, character.char_id) + 1
            gross = int(npc["wealth"]) // sibling_count
            inheritance_base = payout_cents(gross, GameBalance.INHERITANCE_BASE_MULTIPLIER)
            threshold = scale_cents(dollars_to_cents(1_000_000), Decimal(str(character.price_index)))
            tax = charge_cents(max(0, inheritance_base - threshold), Decimal("0.10"))
            inheritance = max(0, inheritance_base - tax)
            await self.repository.set_npc_wealth(tx, int(npc["npc_id"]), 0)
            if character.in_prison:
                messages.append(f"{npc['name']} died. Grief lowered happiness; inheritance was held during imprisonment.")
                return replace(character, stats=stats)
            messages.append(
                f"{npc['name']} died. Grief reduced happiness by {grief}; inheritance after tax was {inheritance // 100:,} dollars."
            )
            return replace(character, stats=stats, bank=character.bank + inheritance)
        if relation == "spouse":
            marriage = await self.repository.get_marriage(tx, character.char_id)
            if marriage is not None and int(marriage["spouse_npc_id"]) == int(npc["npc_id"]):
                await self.repository.delete_marriage(tx, character.char_id)
                await self.repository.delete_affair(tx, character.char_id)
                await self.repository.set_relationship_type(tx, character.char_id, int(npc["npc_id"]), "ex")
                messages.append(f"Your spouse {npc['name']} died; the marriage ended.")
                return character
        if relation in {"partner", "fiance"}:
            await self.repository.set_relationship_type(tx, character.char_id, int(npc["npc_id"]), "ex")
        messages.append(f"{npc['name']} ({relation}) died at age {death_age}.")
        return character

    async def _family_events(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        messages: list[str],
    ) -> Character:
        """Roll family reunion, sibling-rivalry, adult-child, and elder-care events."""
        updated = character
        siblings = [
            row for row in await self.repository.people_by_type(tx, character.char_id, ("sibling",))
            if bool(row["is_alive"])
        ]
        family = [
            row for row in await self.repository.people_by_type(tx, character.char_id, ("parent", "sibling"))
            if bool(row["is_alive"])
        ]
        if siblings and self.rng.random() < 0.04:
            sibling = self.rng.choice(siblings)
            delta = self.rng.randint(3, 10)
            await self.repository.add_relationship_score(tx, character.char_id, int(sibling["npc_id"]), -delta)
            messages.append(f"A bout of sibling rivalry strained things with {sibling['name']} (-{delta}).")
        elif family and self.rng.random() < 0.03:
            relative = self.rng.choice(family)
            delta = self.rng.randint(3, 8)
            await self.repository.add_relationship_score(tx, character.char_id, int(relative["npc_id"]), delta)
            stats = replace(updated.stats)
            stats.happiness = min(100, stats.happiness + 2)
            updated = replace(updated, stats=stats)
            messages.append(f"A family reunion brought {relative['name']} closer (+{delta}); happiness +2.")
        children = await self.repository.get_children(tx, character.char_id)
        adult_children = [child for child in children if int(child["age"]) >= 18 and bool(child["is_alive"])]
        if adult_children and character.age >= 60 and self.rng.random() < 0.05:
            child = self.rng.choice(adult_children)
            gift = dollars_to_cents(self.rng.randint(100, 2_000))
            updated = replace(updated, cash=updated.cash + gift)
            messages.append(f"Your adult child {child['name']} helped with {gift // 100:,} dollars.")
        elif adult_children and self.rng.random() < 0.03:
            child = self.rng.choice(adult_children)
            amount = dollars_to_cents(self.rng.randint(100, 1_000))
            updated, unpaid = self._deduct_cash_bank(updated, amount)
            if unpaid:
                updated = replace(updated, debt_total=updated.debt_total + unpaid)
            messages.append(f"Your adult child {child['name']} asked for {amount // 100:,} dollars.")
        parents = await self.repository.parent_relations(tx, character.char_id)
        elderly = [parent for parent in parents if bool(parent["is_alive"]) and int(parent["age"]) >= 75]
        if elderly and self.rng.random() < 0.03:
            parent = self.rng.choice(elderly)
            care_cost = dollars_to_cents(self.rng.randint(250, 2_500))
            updated, unpaid = self._deduct_cash_bank(updated, care_cost)
            if unpaid:
                updated = replace(updated, debt_total=updated.debt_total + unpaid)
            messages.append(f"Your elderly parent {parent['name']} needed care costing {care_cost // 100:,} dollars.")
        return updated

    def _roll_custody(self, character: Character, annual_income: int) -> str:
        """Choose full/shared/none custody using karma, income, and criminal history."""
        income_factor = min(20, max(0, int(annual_income // dollars_to_cents(10_000))))
        criminal_penalty = min(35, max(0, int(character.criminal_record)) * 5)
        full = max(5, 60 + (character.stats.karma - 50) // 2 + income_factor - criminal_penalty)
        shared = max(5, 30 + criminal_penalty // 2)
        none = max(5, 10 + criminal_penalty - income_factor)
        return self.rng.weighted_choice(("full", "shared", "none"), (full, shared, none))

    @staticmethod
    def _deduct_cash_bank(character: Character, amount: int) -> tuple[Character, int]:
        """Deduct integer cents from cash then bank without allowing negatives."""
        amount = max(0, int(amount))
        bank_paid = min(max(0, character.bank), amount)
        remaining = amount - bank_paid
        cash_paid = min(max(0, character.cash), remaining)
        unpaid = remaining - cash_paid
        return replace(
            character,
            cash=max(0, character.cash - cash_paid),
            bank=max(0, character.bank - bank_paid),
        ), unpaid

    async def _pay_divorce_assets(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        amount: int,
        *,
        marriage_timestamp: int,
        protect_cash: int = 0,
        protect_bank: int = 0,
        marital_only: bool,
    ) -> tuple[Character, int]:
        """Pay a divorce settlement by liquid cash, then assets, then recorded debt."""
        if marital_only:
            updated, remaining = self._pay_from_liquid_assets(
                character, amount, protected_cash=protect_cash, protected_bank=protect_bank
            )
            assets = await self.repository.get_marital_assets(
                tx, character.char_id, marriage_timestamp
            )
        else:
            updated, remaining = self._deduct_cash_bank(character, amount)
            assets = await self.repository.get_all_assets(tx, character.char_id)
        for asset in assets:
            if remaining <= 0:
                break
            used = await self.repository.reduce_asset(tx, int(asset["asset_id"]), remaining)
            remaining -= used
        if remaining > 0:
            updated = replace(updated, debt_total=updated.debt_total + remaining)
        return updated, remaining

    @staticmethod
    def _pay_from_liquid_assets(
        character: Character,
        amount: int,
        *,
        protected_cash: int = 0,
        protected_bank: int = 0,
    ) -> tuple[Character, int]:
        """Pay only from available cash/bank above prenup-protected baselines."""
        amount = max(0, int(amount))
        available_cash = max(0, character.cash - protected_cash)
        cash_paid = min(available_cash, amount)
        remaining = amount - cash_paid
        available_bank = max(0, character.bank - protected_bank)
        bank_paid = min(available_bank, remaining)
        remaining -= bank_paid
        return replace(
            character,
            cash=max(0, character.cash - cash_paid),
            bank=max(0, character.bank - bank_paid),
        ), remaining

    async def _settle_player_payment(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        amount: int,
        *,
        allow_assets: bool = False,
    ) -> tuple[Character, int]:
        """Pay a household expense, optionally liquidating all player assets."""
        updated, unpaid = self._deduct_cash_bank(character, amount)
        if allow_assets and unpaid:
            for asset in await self.repository.get_all_assets(tx, character.char_id):
                if unpaid <= 0:
                    break
                used = await self.repository.reduce_asset(tx, int(asset["asset_id"]), unpaid)
                unpaid -= used
        if unpaid:
            updated = replace(updated, debt_total=updated.debt_total + unpaid)
        return updated, unpaid

