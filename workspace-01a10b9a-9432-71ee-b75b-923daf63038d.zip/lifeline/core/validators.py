"""Strict validation for game data files loaded at runtime."""
from __future__ import annotations

import math
import re
from typing import Any


class DataValidationError(ValueError):
    """Raised when a bundled game-data document is malformed or unsafe."""


_EVENT_ID = re.compile(r"^[a-z][a-z0-9_]{0,39}$")
_ALLOWED_POLARITIES = {"positive", "negative", "neutral"}
_ALLOWED_WEALTH = {"poor", "working", "middle", "upper", "rich"}
_ALLOWED_STATS = {
    "health", "happiness", "smarts", "looks", "fitness", "karma",
    "stress", "addiction", "fame",
}


def _fail(path: str, message: str) -> None:
    raise DataValidationError(f"{path}: {message}")


def _string(value: Any, path: str, *, minimum: int, maximum: int) -> str:
    if not isinstance(value, str):
        _fail(path, "must be a string")
    clean = value.strip()
    if not minimum <= len(clean) <= maximum:
        _fail(path, f"length must be between {minimum} and {maximum}")
    if any(ord(char) < 32 or ord(char) == 127 for char in clean):
        _fail(path, "must not contain control characters")
    return clean


def _integer(value: Any, path: str, *, minimum: int, maximum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        _fail(path, "must be an integer")
    if not minimum <= value <= maximum:
        _fail(path, f"must be between {minimum} and {maximum}")
    return value


def _validate_event_effects(effects: Any, path: str) -> None:
    """Validate bounded declarative event effects; executable expressions are never accepted."""
    if not isinstance(effects, dict) or set(effects) - {"stats", "cash_cents"}:
        _fail(path, "may contain only stats and cash_cents")
    stats = effects.get("stats", {})
    if not isinstance(stats, dict):
        _fail(f"{path}.stats", "must be an object")
    for stat_name, delta in stats.items():
        if stat_name not in _ALLOWED_STATS:
            _fail(f"{path}.stats.{stat_name}", "is not a mutable game stat")
        _integer(delta, f"{path}.stats.{stat_name}", minimum=-25, maximum=25)
    if "cash_cents" in effects:
        _integer(effects["cash_cents"], f"{path}.cash_cents", minimum=-100_000_000, maximum=100_000_000)


def validate_event_catalog(document: Any) -> dict[str, Any]:
    """Validate version-1 choice events and safe declarative outcomes.

    Both the Stage 1-10 fields and the richer Stage 11 ``conditions``/``outcomes``
    fields are accepted so saved event snapshots and test catalogs remain readable.
    The evaluator supports only whitelisted stat and integer-cent changes; ``eval``
    and data-supplied Python expressions are never used.
    """
    if not isinstance(document, dict):
        _fail("events", "document must be an object")
    if document.get("schema_version") != 1:
        _fail("schema_version", "only version 1 is supported")
    events = document.get("events")
    if not isinstance(events, list) or not 1 <= len(events) <= 500:
        _fail("events", "must contain between 1 and 500 event definitions")

    seen_event_ids: set[str] = set()
    for event_index, event in enumerate(events):
        path = f"events[{event_index}]"
        if not isinstance(event, dict):
            _fail(path, "must be an object")
        event_id = _string(event.get("id"), f"{path}.id", minimum=1, maximum=40)
        if not _EVENT_ID.fullmatch(event_id):
            _fail(f"{path}.id", "use lowercase letters, digits, and underscores")
        if event_id in seen_event_ids:
            _fail(f"{path}.id", "event IDs must be unique")
        seen_event_ids.add(event_id)

        _string(event.get("title", event.get("text")), f"{path}.title", minimum=1, maximum=100)
        _string(event.get("description", event.get("text")), f"{path}.description", minimum=1, maximum=1000)
        category = _string(event.get("category"), f"{path}.category", minimum=1, maximum=32)
        if not re.fullmatch(r"[a-z][a-z0-9_]*", category):
            _fail(f"{path}.category", "must be a lowercase category key")
        if event.get("polarity") not in _ALLOWED_POLARITIES:
            _fail(f"{path}.polarity", "must be positive, negative, or neutral")
        event_type = event.get("type", "choice")
        if event_type not in {"auto", "choice"}:
            _fail(f"{path}.type", "must be auto or choice")

        conditions = event.get("conditions", {})
        if not isinstance(conditions, dict):
            _fail(f"{path}.conditions", "must be an object")
        minimum_age = _integer(
            conditions.get("min_age", event.get("min_age")),
            f"{path}.conditions.min_age", minimum=0, maximum=120,
        )
        maximum_age = _integer(
            conditions.get("max_age", event.get("max_age")),
            f"{path}.conditions.max_age", minimum=0, maximum=120,
        )
        if minimum_age > maximum_age:
            _fail(f"{path}.conditions", "min_age cannot exceed max_age")
        for stat_key in ("min_stats", "max_stats"):
            stat_bounds = conditions.get(stat_key, {})
            if not isinstance(stat_bounds, dict):
                _fail(f"{path}.conditions.{stat_key}", "must be an object")
            for stat_name, value in stat_bounds.items():
                if stat_name not in _ALLOWED_STATS:
                    _fail(f"{path}.conditions.{stat_key}.{stat_name}", "is not a game stat")
                _integer(value, f"{path}.conditions.{stat_key}.{stat_name}", minimum=0, maximum=100)
        weight = event.get("weight")
        if isinstance(weight, bool) or not isinstance(weight, (int, float)):
            _fail(f"{path}.weight", "must be a number")
        if not math.isfinite(float(weight)) or not 0 < float(weight) <= 1000:
            _fail(f"{path}.weight", "must be greater than 0 and at most 1000")

        repeatable = event.get("repeatable", not bool(event.get("once_per_life", True)))
        if not isinstance(repeatable, bool):
            _fail(f"{path}.repeatable", "must be true or false")
        once_per_life = event.get("once_per_life", not repeatable)
        if not isinstance(once_per_life, bool):
            _fail(f"{path}.once_per_life", "must be true or false")
        cooldown = event.get("cooldown_years", 0)
        _integer(cooldown, f"{path}.cooldown_years", minimum=0, maximum=120)

        wealth_classes = conditions.get("wealth_classes", event.get("wealth_classes", []))
        if not isinstance(wealth_classes, list) or any(
            not isinstance(value, str) or value not in _ALLOWED_WEALTH for value in wealth_classes
        ):
            _fail(f"{path}.conditions.wealth_classes", "must be a list of valid wealth-class keys")
        if len(set(wealth_classes)) != len(wealth_classes):
            _fail(f"{path}.conditions.wealth_classes", "values must be unique")
        countries = conditions.get("countries", event.get("countries", []))
        if not isinstance(countries, list) or any(
            not isinstance(value, str) or not re.fullmatch(r"[a-z0-9_-]{2,40}", value)
            for value in countries
        ):
            _fail(f"{path}.conditions.countries", "must be a list of lowercase country/region keys")
        if len(set(countries)) != len(countries):
            _fail(f"{path}.conditions.countries", "values must be unique")

        context = event.get("context", {})
        if not isinstance(context, dict):
            _fail(f"{path}.context", "must be an object")
        if "summary" in context:
            _string(context["summary"], f"{path}.context.summary", minimum=1, maximum=1000)
        references = context.get("references", {})
        allowed_refs = {"items", "diseases", "careers", "majors", "crimes", "achievements"}
        if not isinstance(references, dict) or set(references) - allowed_refs:
            _fail(f"{path}.context.references", "contains an unsupported reference category")
        for reference_type, identifiers in references.items():
            if not isinstance(identifiers, list) or len(set(identifiers)) != len(identifiers):
                _fail(f"{path}.context.references.{reference_type}", "must be a unique list of IDs")
            for reference_index, identifier in enumerate(identifiers):
                value = _string(identifier, f"{path}.context.references.{reference_type}[{reference_index}]", minimum=1, maximum=48)
                if not _EVENT_ID.fullmatch(value):
                    _fail(f"{path}.context.references.{reference_type}[{reference_index}]", "must be a lowercase ID")

        choices = event.get("choices")
        if not isinstance(choices, list):
            _fail(f"{path}.choices", "must be a list")
        if event_type == "choice" and not 2 <= len(choices) <= 4:
            _fail(f"{path}.choices", "choice events must contain between 2 and 4 choices")
        if event_type == "auto" and len(choices) > 4:
            _fail(f"{path}.choices", "auto events may contain at most 4 outcomes")
        seen_choice_ids: set[str] = set()
        for choice_index, choice in enumerate(choices):
            choice_path = f"{path}.choices[{choice_index}]"
            if not isinstance(choice, dict):
                _fail(choice_path, "must be an object")
            choice_id = _string(choice.get("id"), f"{choice_path}.id", minimum=1, maximum=32)
            if not _EVENT_ID.fullmatch(choice_id) or choice_id in seen_choice_ids:
                _fail(f"{choice_path}.id", "must be unique and use lowercase letters, digits, and underscores")
            seen_choice_ids.add(choice_id)
            _string(choice.get("label"), f"{choice_path}.label", minimum=1, maximum=80)
            description = choice.get("description", "")
            if description:
                _string(description, f"{choice_path}.description", minimum=1, maximum=250)
            outcomes = choice.get("outcomes")
            if outcomes is None:
                _validate_event_effects(choice.get("effects", {}), f"{choice_path}.effects")
                continue
            if not isinstance(outcomes, list) or not 1 <= len(outcomes) <= 5:
                _fail(f"{choice_path}.outcomes", "must contain between 1 and 5 weighted outcomes")
            seen_outcome_ids: set[str] = set()
            probabilities: list[float] = []
            for outcome_index, outcome in enumerate(outcomes):
                outcome_path = f"{choice_path}.outcomes[{outcome_index}]"
                if not isinstance(outcome, dict):
                    _fail(outcome_path, "must be an object")
                outcome_id = _string(outcome.get("id"), f"{outcome_path}.id", minimum=1, maximum=32)
                if not _EVENT_ID.fullmatch(outcome_id) or outcome_id in seen_outcome_ids:
                    _fail(f"{outcome_path}.id", "must be unique and use lowercase letters, digits, and underscores")
                seen_outcome_ids.add(outcome_id)
                outcome_weight = outcome.get("weight")
                if isinstance(outcome_weight, bool) or not isinstance(outcome_weight, (int, float)) or not math.isfinite(float(outcome_weight)) or float(outcome_weight) <= 0:
                    _fail(f"{outcome_path}.weight", "must be a finite positive number")
                if "probability" in outcome:
                    probability = outcome["probability"]
                    if isinstance(probability, bool) or not isinstance(probability, (int, float)) or not math.isfinite(float(probability)) or not 0 <= float(probability) <= 1:
                        _fail(f"{outcome_path}.probability", "must be between 0 and 1")
                    probabilities.append(float(probability))
                _validate_event_effects(outcome.get("effects", {}), f"{outcome_path}.effects")
            if probabilities and (len(probabilities) != len(outcomes) or not math.isclose(sum(probabilities), 1.0, abs_tol=1e-6)):
                _fail(f"{choice_path}.outcomes", "probabilities must be provided for every outcome and sum to 1")
    return document


def validate_career_catalog(document: Any) -> dict[str, Any]:
    """Validate a career catalog containing finite, positive integer-cent salaries."""
    if not isinstance(document, dict):
        _fail("careers", "document must be an object")
    if document.get("schema_version") != 1:
        _fail("schema_version", "only version 1 is supported")
    careers = document.get("careers")
    if not isinstance(careers, list) or not 1 <= len(careers) <= 100:
        _fail("careers", "must contain between 1 and 100 career definitions")

    allowed_education = {"none", "primary", "high_school", "bachelor", "master", "doctorate"}
    career_ids: set[str] = set()
    for index, career in enumerate(careers):
        path = f"careers[{index}]"
        if not isinstance(career, dict):
            _fail(path, "must be an object")
        career_id = _string(career.get("id"), f"{path}.id", minimum=1, maximum=40)
        if not _EVENT_ID.fullmatch(career_id):
            _fail(f"{path}.id", "use lowercase letters, digits, and underscores")
        if career_id in career_ids:
            _fail(f"{path}.id", "career IDs must be unique")
        career_ids.add(career_id)
        _string(career.get("name"), f"{path}.name", minimum=1, maximum=80)
        minimum_age = _integer(career.get("minimum_age"), f"{path}.minimum_age", minimum=14, maximum=80)
        retirement_age = _integer(career.get("retirement_age"), f"{path}.retirement_age", minimum=40, maximum=120)
        if retirement_age <= minimum_age:
            _fail(path, "retirement_age must be greater than minimum_age")
        if career.get("minimum_education") not in allowed_education:
            _fail(f"{path}.minimum_education", "must be a supported education level")
        _integer(career.get("minimum_smarts"), f"{path}.minimum_smarts", minimum=0, maximum=100)
        part_time_allowed = career.get("part_time_allowed", False)
        if not isinstance(part_time_allowed, bool):
            _fail(f"{path}.part_time_allowed", "must be true or false")
        multiplier = career.get("part_time_multiplier", 0.5)
        if isinstance(multiplier, bool) or not isinstance(multiplier, (int, float)):
            _fail(f"{path}.part_time_multiplier", "must be a number")
        if not math.isfinite(float(multiplier)) or not 0 < float(multiplier) <= 1:
            _fail(f"{path}.part_time_multiplier", "must be greater than 0 and at most 1")

        levels = career.get("levels")
        if not isinstance(levels, list) or not 2 <= len(levels) <= 8:
            _fail(f"{path}.levels", "must contain between 2 and 8 levels")
        for level_index, level in enumerate(levels):
            level_path = f"{path}.levels[{level_index}]"
            if not isinstance(level, dict):
                _fail(level_path, "must be an object")
            _string(level.get("title"), f"{level_path}.title", minimum=1, maximum=80)
            _integer(level.get("annual_salary"), f"{level_path}.annual_salary", minimum=1, maximum=10_000_000_000)
            _integer(level.get("promotion_years"), f"{level_path}.promotion_years", minimum=1, maximum=30)

    return document


def _validate_item_effects(value: Any, path: str, *, allow_flags: bool = False, allow_payout: bool = False) -> dict[str, Any]:
    """Validate a bounded, declarative item effect document."""
    if not isinstance(value, dict):
        _fail(path, "must be an object")
    allowed = {"stats"}
    if allow_flags:
        allowed.add("flags")
    if allow_payout:
        allowed.add("payout_range_cents")
    if set(value) - allowed:
        _fail(path, f"may contain only: {', '.join(sorted(allowed))}")
    stats = value.get("stats", {})
    if not isinstance(stats, dict):
        _fail(f"{path}.stats", "must be an object")
    for stat_name, delta in stats.items():
        if stat_name not in _ALLOWED_STATS:
            _fail(f"{path}.stats.{stat_name}", "is not a supported game stat")
        _integer(delta, f"{path}.stats.{stat_name}", minimum=-100, maximum=100)
    if allow_flags:
        flags = value.get("flags", {})
        if not isinstance(flags, dict) or set(flags) - {"has_license", "has_ged"}:
            _fail(f"{path}.flags", "may contain only supported character flags")
        for flag, enabled in flags.items():
            if not isinstance(enabled, bool):
                _fail(f"{path}.flags.{flag}", "must be true or false")
    if allow_payout and "payout_range_cents" in value:
        payout = value["payout_range_cents"]
        if not isinstance(payout, list) or len(payout) != 2:
            _fail(f"{path}.payout_range_cents", "must contain a minimum and maximum")
        minimum = _integer(payout[0], f"{path}.payout_range_cents[0]", minimum=0, maximum=9_000_000_000_000_000_000)
        maximum = _integer(payout[1], f"{path}.payout_range_cents[1]", minimum=minimum, maximum=9_000_000_000_000_000_000)
    return value


def validate_item_catalog(document: Any) -> dict[str, Any]:
    """Validate the full Stage 8 item catalog and its finite gameplay effects."""
    if not isinstance(document, dict):
        _fail("items", "document must be an object")
    if isinstance(document.get("schema_version"), bool) or document.get("schema_version") != 1:
        _fail("items.schema_version", "only version 1 is supported")
    if set(document) != {"schema_version", "items"}:
        _fail("items", "must contain exactly schema_version and items")
    items = document.get("items")
    if not isinstance(items, list) or not 60 <= len(items) <= 500:
        _fail("items", "must contain between 60 and 500 item definitions")
    categories = {
        "housing", "vehicle", "jewelry", "electronics", "health", "collectibles",
        "business", "pet", "weapon", "consumable", "license", "title", "leisure",
    }
    required = {
        "id", "name", "category", "base_price_cents", "min_age", "stackable",
        "max_quantity", "tradeable", "effects_on_buy", "effects_on_use", "yearly_effects",
        "yearly_upkeep_cents", "depreciation_rate_per_year", "market_volatility",
        "collateral_eligible", "consumable", "usable", "shop_available",
        "crime_event_only", "legal_countries",
    }
    seen: set[str] = set()
    for index, item in enumerate(items):
        path = f"items[{index}]"
        if not isinstance(item, dict):
            _fail(path, "must be an object")
        if set(item) != required:
            missing = required - set(item)
            extra = set(item) - required
            detail = []
            if missing:
                detail.append(f"missing {', '.join(sorted(missing))}")
            if extra:
                detail.append(f"unsupported {', '.join(sorted(extra))}")
            _fail(path, "; ".join(detail))
        item_id = _string(item.get("id"), f"{path}.id", minimum=1, maximum=40)
        if not _EVENT_ID.fullmatch(item_id) or item_id in seen:
            _fail(f"{path}.id", "must be unique and use lowercase letters, digits, and underscores")
        seen.add(item_id)
        _string(item.get("name"), f"{path}.name", minimum=1, maximum=80)
        if item.get("category") not in categories:
            _fail(f"{path}.category", "is not a supported shop category")
        _integer(item.get("base_price_cents"), f"{path}.base_price_cents", minimum=0, maximum=9_000_000_000_000_000_000)
        _integer(item.get("min_age"), f"{path}.min_age", minimum=0, maximum=120)
        stackable = item.get("stackable")
        if not isinstance(stackable, bool):
            _fail(f"{path}.stackable", "must be true or false")
        maximum = _integer(item.get("max_quantity"), f"{path}.max_quantity", minimum=1, maximum=999)
        if not stackable and maximum != 1:
            _fail(f"{path}.max_quantity", "non-stackable items must have max_quantity 1")
        for field in ("tradeable", "collateral_eligible", "consumable", "usable", "shop_available", "crime_event_only"):
            if not isinstance(item.get(field), bool):
                _fail(f"{path}.{field}", "must be true or false")
        if not isinstance(item.get("legal_countries"), list):
            _fail(f"{path}.legal_countries", "must be a list")
        legal_countries = item["legal_countries"]
        if any(
            not isinstance(country, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{1,39}", country)
            for country in legal_countries
        ):
            _fail(f"{path}.legal_countries", "must contain lowercase country codes")
        if len(set(legal_countries)) != len(legal_countries):
            _fail(f"{path}.legal_countries", "country codes must be unique")
        if item["crime_event_only"] and (item["shop_available"] or item["category"] != "weapon"):
            _fail(path, "crime-event-only items must be weapons and unavailable in /shop")
        if item["category"] == "weapon" and (not item["crime_event_only"] or not legal_countries or item["min_age"] < 18 or item["tradeable"]):
            _fail(path, "weapons must be nontradeable, crime-event-only, adult-gated items with country legality")
        if item["category"] in {"title", "license"} and item["tradeable"]:
            _fail(path, "titles and licenses cannot be traded")
        if item["category"] == "consumable" and not item["tradeable"]:
            _fail(path, "consumables must be tradeable")
        if item["base_price_cents"] == 0 and not (item["crime_event_only"] or not item["shop_available"]):
            _fail(f"{path}.base_price_cents", "zero-price items must be event-only or hidden")
        if item["collateral_eligible"] and item["category"] not in {"housing", "vehicle"}:
            _fail(f"{path}.collateral_eligible", "only housing and vehicles may secure loans")
        if item["category"] in {"housing", "vehicle"} and (not item["tradeable"] or not item["collateral_eligible"]):
            _fail(path, "housing and vehicles must be tradeable and collateral-eligible")
        if item["consumable"] and (not stackable or not item["usable"]):
            _fail(path, "consumables must be stackable and usable")
        _validate_item_effects(item["effects_on_buy"], f"{path}.effects_on_buy", allow_flags=True)
        _validate_item_effects(item["effects_on_use"], f"{path}.effects_on_use", allow_payout=True)
        yearly = item["yearly_effects"]
        if not isinstance(yearly, dict) or set(yearly) != {"stats", "income_cents"}:
            _fail(f"{path}.yearly_effects", "must contain stats and income_cents")
        _validate_item_effects({"stats": yearly["stats"]}, f"{path}.yearly_effects")
        _integer(yearly["income_cents"], f"{path}.yearly_effects.income_cents", minimum=0, maximum=9_000_000_000_000_000_000)
        _integer(item["yearly_upkeep_cents"], f"{path}.yearly_upkeep_cents", minimum=0, maximum=9_000_000_000_000_000_000)
        rate = item["depreciation_rate_per_year"]
        volatility = item["market_volatility"]
        for field, number in (("depreciation_rate_per_year", rate), ("market_volatility", volatility)):
            if isinstance(number, bool) or not isinstance(number, (int, float)) or not math.isfinite(float(number)):
                _fail(f"{path}.{field}", "must be a finite number")
        if not -0.95 <= float(rate) <= 0.95:
            _fail(f"{path}.depreciation_rate_per_year", "must be between -0.95 and 0.95")
        if not 0 <= float(volatility) <= 0.5:
            _fail(f"{path}.market_volatility", "must be between 0 and 0.5")
        if item["shop_available"] and item["crime_event_only"]:
            _fail(path, "crime-event-only items cannot be sold in /shop")
    return document


def validate_crime_catalog(document: Any) -> dict[str, Any]:
    """Validate the complete non-instructional crime catalog used at startup."""
    if not isinstance(document, dict):
        _fail("crimes", "document must be an object")
    if isinstance(document.get("schema_version"), bool) or document.get("schema_version") != 1:
        _fail("crimes.schema_version", "only version 1 is supported")
    allowed_top = {"schema_version", "crime_severity_mod", "crimes"}
    if set(document) != allowed_top:
        _fail("crimes", f"must contain exactly these keys: {', '.join(sorted(allowed_top))}")
    severity = document.get("crime_severity_mod")
    if not isinstance(severity, dict) or "default" not in severity:
        _fail("crimes.crime_severity_mod", "must be an object with a default modifier")
    for country, modifier in severity.items():
        _string(country, "crimes.crime_severity_mod key", minimum=2, maximum=40)
        if not re.fullmatch(r"[a-z][a-z0-9_]{1,39}", country):
            _fail("crimes.crime_severity_mod", "country keys must be lowercase codes")
        if isinstance(modifier, bool) or not isinstance(modifier, (int, float)):
            _fail(f"crimes.crime_severity_mod.{country}", "must be a number")
        if not math.isfinite(float(modifier)) or not 0.25 <= float(modifier) <= 3.0:
            _fail(f"crimes.crime_severity_mod.{country}", "must be between 0.25 and 3")
    crimes = document.get("crimes")
    if not isinstance(crimes, list) or len(crimes) < 14 or len(crimes) > 100:
        _fail("crimes", "must contain at least 14 and at most 100 crime definitions")
    seen: set[str] = set()
    has_event_only_tax = False
    for index, crime in enumerate(crimes):
        path = f"crimes[{index}]"
        if not isinstance(crime, dict):
            _fail(path, "must be an object")
        required_fields = {
            "id", "name", "description", "min_age", "base_success", "loot_min_dollars",
            "loot_max_dollars", "base_catch", "sentence_min", "sentence_max",
            "violence", "success_stat", "requires_job", "commit_enabled",
        }
        optional_fields = {
            "salary_loot_min_fraction", "salary_loot_max_fraction", "salary_loot_multiplier",
        }
        missing_fields = required_fields - set(crime)
        extra_fields = set(crime) - required_fields - optional_fields
        if missing_fields:
            _fail(path, f"missing required fields: {', '.join(sorted(missing_fields))}")
        if extra_fields:
            _fail(path, f"unsupported fields: {', '.join(sorted(extra_fields))}")
        crime_id = _string(crime.get("id"), f"{path}.id", minimum=1, maximum=40)
        if not _EVENT_ID.fullmatch(crime_id) or crime_id in seen:
            _fail(f"{path}.id", "must be unique and use lowercase letters, digits, and underscores")
        seen.add(crime_id)
        _string(crime.get("name"), f"{path}.name", minimum=1, maximum=80)
        _string(crime.get("description"), f"{path}.description", minimum=1, maximum=250)
        minimum_age = crime.get("min_age")
        if minimum_age is not None:
            _integer(minimum_age, f"{path}.min_age", minimum=0, maximum=120)
        enabled = crime.get("commit_enabled")
        if not isinstance(enabled, bool):
            _fail(f"{path}.commit_enabled", "must be true or false")
        for key in ("violence", "requires_job"):
            if not isinstance(crime.get(key), bool):
                _fail(f"{path}.{key}", "must be true or false")
        if crime.get("success_stat") not in {"none", "skill", "physical"}:
            _fail(f"{path}.success_stat", "must be none, skill, or physical")
        loot_min = _integer(crime.get("loot_min_dollars"), f"{path}.loot_min_dollars", minimum=0, maximum=10_000_000)
        loot_max = _integer(crime.get("loot_max_dollars"), f"{path}.loot_max_dollars", minimum=0, maximum=10_000_000)
        if loot_min > loot_max:
            _fail(path, "loot_min_dollars cannot exceed loot_max_dollars")
        sentence_min = _integer(crime.get("sentence_min"), f"{path}.sentence_min", minimum=0, maximum=120)
        sentence_max = crime.get("sentence_max")
        if sentence_max != "life":
            sentence_max = _integer(sentence_max, f"{path}.sentence_max", minimum=0, maximum=120)
            if sentence_min > sentence_max:
                _fail(path, "sentence_min cannot exceed sentence_max")
        if enabled:
            if minimum_age is None:
                _fail(f"{path}.min_age", "committable crimes require a minimum age")
            for key in ("base_success", "base_catch"):
                chance = crime.get(key)
                if isinstance(chance, bool) or not isinstance(chance, (int, float)):
                    _fail(f"{path}.{key}", "committable crimes require a numeric chance")
                if not math.isfinite(float(chance)) or not 0 <= float(chance) <= 100:
                    _fail(f"{path}.{key}", "must be between 0 and 100")
        else:
            if crime_id == "tax_evasion":
                has_event_only_tax = True
                if minimum_age != 18:
                    _fail(f"{path}.min_age", "tax_evasion is an adult-only event")
            if crime.get("base_success") is not None or crime.get("base_catch") is not None:
                _fail(path, "event-only crimes must not define commit chances")
        has_salary_range = "salary_loot_min_fraction" in crime or "salary_loot_max_fraction" in crime
        if "salary_loot_multiplier" in crime and not has_salary_range:
            _fail(path, "salary_loot_multiplier requires salary loot fractions")
        if crime["requires_job"] and not has_salary_range:
            _fail(path, "job-required crimes need salary loot fractions")
        if has_salary_range:
            for key in ("salary_loot_min_fraction", "salary_loot_max_fraction"):
                value = crime.get(key)
                if isinstance(value, bool) or not isinstance(value, (int, float)):
                    _fail(f"{path}.{key}", "must be a number")
                if not math.isfinite(float(value)) or not 0 <= float(value) <= 1:
                    _fail(f"{path}.{key}", "must be between 0 and 1")
            if crime["salary_loot_min_fraction"] > crime["salary_loot_max_fraction"]:
                _fail(path, "salary loot minimum fraction cannot exceed maximum fraction")
            _integer(crime.get("salary_loot_multiplier"), f"{path}.salary_loot_multiplier", minimum=1, maximum=10)
    if not has_event_only_tax:
        _fail("crimes", "must include event-only tax_evasion")
    return document


def validate_achievement_catalog(document: Any) -> dict[str, Any]:
    """Validate the finite, non-executable Stage 10 achievement catalog."""
    if not isinstance(document, dict) or set(document) != {"schema_version", "achievements"}:
        _fail("achievements", "must contain exactly schema_version and achievements")
    if isinstance(document.get("schema_version"), bool) or document.get("schema_version") != 1:
        _fail("achievements.schema_version", "only version 1 is supported")
    entries = document.get("achievements")
    if not isinstance(entries, list) or not 60 <= len(entries) <= 500:
        _fail("achievements", "must contain between 60 and 500 definitions")
    rules = {
        "age_at_least", "education_at_least", "peak_net_worth_at_least", "rags_to_riches",
        "marriage_years_at_least", "children_at_least", "prison_years_at_least",
        "convictions_at_least", "crime_level_at_least", "escaped", "max_bet_at_least", "jackpot", "bankrupt",
        "divorces_at_least", "gpa_at_least", "executive_role", "fame_at_least",
        "study_actions_at_least", "generation_at_least", "died_before_age",
        "clean_centenarian", "hard_study_actions_at_least", "career_years_at_least",
        "career_level_at_least", "career_count_at_least", "business_asset", "homes_at_least",
        "owns_stock", "stock_trades_at_least", "matured_bond", "rental_income",
        "debt_free", "marriages_at_least", "completed_life", "lottery_win",
        "blackjack_wins_at_least", "casino_plays_at_least", "average_happiness_at_least",
        "karma_at_least", "rehab_used", "addiction_free_after_gambling", "salary_at_least",
        "asset_lots_at_least", "happiness_at_least", "fitness_at_least", "smarts_at_least",
        "crime_recovery", "multiple_careers_level_two", "total_gambled_at_least",
        "gambling_net_positive", "financial_comeback", "no_convictions",
    }
    categories = {"longevity", "education", "wealth", "family", "crime", "hardship", "career", "recovery", "completion"}
    education_levels = {"none", "primary", "high_school", "bachelor", "master", "doctorate"}
    seen: set[str] = set()
    for index, entry in enumerate(entries):
        path = f"achievements[{index}]"
        required = {"id", "name", "description", "category", "rule", "threshold"}
        if not isinstance(entry, dict) or set(entry) != required:
            _fail(path, "must contain exactly id, name, description, category, rule, and threshold")
        identifier = _string(entry.get("id"), f"{path}.id", minimum=2, maximum=48)
        if not re.fullmatch(r"[a-z][a-z0-9_]{1,47}", identifier) or identifier in seen:
            _fail(f"{path}.id", "must be unique lowercase letters, digits, and underscores")
        seen.add(identifier)
        _string(entry.get("name"), f"{path}.name", minimum=1, maximum=80)
        _string(entry.get("description"), f"{path}.description", minimum=1, maximum=240)
        if entry.get("category") not in categories:
            _fail(f"{path}.category", "is not a supported achievement category")
        if entry.get("rule") not in rules:
            _fail(f"{path}.rule", "is not an implemented authoritative achievement rule")
        threshold = entry.get("threshold")
        if entry["rule"] == "education_at_least":
            if not isinstance(threshold, str) or threshold not in education_levels:
                _fail(f"{path}.threshold", "must be a supported education level")
        elif entry["rule"] == "gpa_at_least":
            if isinstance(threshold, bool) or not isinstance(threshold, (int, float)) or not math.isfinite(float(threshold)) or not 0 <= float(threshold) <= 4:
                _fail(f"{path}.threshold", "must be a finite GPA from 0 to 4")
        else:
            _integer(threshold, f"{path}.threshold", minimum=0, maximum=9_000_000_000_000_000_000)
    if len(seen) < 60:
        _fail("achievements", "must define at least 60 unique achievements")
    return document


def validate_gambling_ages(document: Any) -> dict[str, Any]:
    """Validate country-keyed fictional minimum ages and a safe fallback."""
    if not isinstance(document, dict) or set(document) != {"schema_version", "default_age", "countries"}:
        _fail("gambling_ages", "must contain exactly schema_version, default_age, and countries")
    if isinstance(document.get("schema_version"), bool) or document.get("schema_version") != 1:
        _fail("gambling_ages.schema_version", "only version 1 is supported")
    _integer(document.get("default_age"), "gambling_ages.default_age", minimum=18, maximum=25)
    countries = document.get("countries")
    if not isinstance(countries, dict) or not countries:
        _fail("gambling_ages.countries", "must be a non-empty country-to-age object")
    for country, age in countries.items():
        if not isinstance(country, str) or not re.fullmatch(r"[a-z][a-z0-9_]{1,39}", country):
            _fail("gambling_ages.countries", "keys must be lowercase country/region codes")
        _integer(age, f"gambling_ages.countries.{country}", minimum=18, maximum=25)
    return document


def validate_stock_catalog(document: Any) -> dict[str, Any]:
    """Validate at least twelve fictional public companies and their GBM inputs."""
    if not isinstance(document, dict) or set(document) != {"schema_version", "stocks"}:
        _fail("stocks", "must contain exactly schema_version and stocks")
    if isinstance(document.get("schema_version"), bool) or document.get("schema_version") != 1:
        _fail("stocks.schema_version", "only version 1 is supported")
    stocks = document.get("stocks")
    if not isinstance(stocks, list) or not 12 <= len(stocks) <= 500:
        _fail("stocks", "must contain between 12 and 500 definitions")
    required = {"symbol", "name", "sector", "initial_price_cents", "drift", "volatility"}
    allowed_sectors = {"tech", "energy", "health", "finance", "consumer", "crypto"}
    symbols: set[str] = set()
    sectors: set[str] = set()
    hypercoin_seen = False
    for index, stock in enumerate(stocks):
        path = f"stocks[{index}]"
        if not isinstance(stock, dict) or set(stock) != required:
            _fail(path, "must contain exactly symbol, name, sector, initial_price_cents, drift, and volatility")
        symbol = _string(stock.get("symbol"), f"{path}.symbol", minimum=1, maximum=8)
        if not re.fullmatch(r"[A-Z][A-Z0-9]{0,7}", symbol) or symbol in symbols:
            _fail(f"{path}.symbol", "must be unique uppercase letters/digits")
        symbols.add(symbol)
        _string(stock.get("name"), f"{path}.name", minimum=2, maximum=80)
        sector = stock.get("sector")
        if sector not in allowed_sectors:
            _fail(f"{path}.sector", "is not a supported fictional market sector")
        sectors.add(str(sector))
        _integer(stock.get("initial_price_cents"), f"{path}.initial_price_cents", minimum=1, maximum=9_000_000_000_000_000_000)
        for field in ("drift", "volatility"):
            value = stock.get(field)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(float(value)):
                _fail(f"{path}.{field}", "must be a finite number")
        if not -1.0 <= float(stock["drift"]) <= 1.0:
            _fail(f"{path}.drift", "must be between -1 and 1")
        if not 0.01 <= float(stock["volatility"]) <= 2.5:
            _fail(f"{path}.volatility", "must be between 0.01 and 2.5")
        if symbol == "HYPER":
            hypercoin_seen = True
            if stock["name"] != "HyperCoin" or sector != "crypto" or float(stock["volatility"]) < 1.0:
                _fail(path, "HYPER must be the high-volatility crypto-like HyperCoin")
    if not {"tech", "energy", "health", "finance", "consumer"}.issubset(sectors):
        _fail("stocks", "must cover tech, energy, health, finance, and consumer sectors")
    if not hypercoin_seen:
        _fail("stocks", "must include the HyperCoin symbol HYPER")
    return document


def validate_disease_catalog(document: Any) -> dict[str, Any]:
    """Validate bounded, non-prescriptive fictional health-condition definitions."""
    if not isinstance(document, dict) or set(document) != {"schema_version", "diseases"}:
        _fail("diseases", "must contain exactly schema_version and diseases")
    if isinstance(document.get("schema_version"), bool) or document.get("schema_version") != 1:
        _fail("diseases.schema_version", "only version 1 is supported")
    diseases = document.get("diseases")
    if not isinstance(diseases, list) or not 25 <= len(diseases) <= 200:
        _fail("diseases", "must contain between 25 and 200 definitions")
    required = {
        "id", "name", "description", "category", "min_age", "max_age",
        "base_probability", "severity_min", "severity_max", "duration_min_years",
        "duration_max_years", "chronic_probability", "annual_health_delta", "treatable",
    }
    seen: set[str] = set()
    for index, item in enumerate(diseases):
        path = f"diseases[{index}]"
        if not isinstance(item, dict) or set(item) != required:
            _fail(path, "must contain the supported disease fields")
        identifier = _string(item.get("id"), f"{path}.id", minimum=1, maximum=40)
        if not _EVENT_ID.fullmatch(identifier) or identifier in seen:
            _fail(f"{path}.id", "must be unique and use lowercase letters, digits, and underscores")
        seen.add(identifier)
        _string(item.get("name"), f"{path}.name", minimum=1, maximum=80)
        _string(item.get("description"), f"{path}.description", minimum=1, maximum=300)
        category = _string(item.get("category"), f"{path}.category", minimum=1, maximum=32)
        if not re.fullmatch(r"[a-z][a-z0-9_]*", category):
            _fail(f"{path}.category", "must be a lowercase category key")
        minimum_age = _integer(item.get("min_age"), f"{path}.min_age", minimum=0, maximum=120)
        maximum_age = _integer(item.get("max_age"), f"{path}.max_age", minimum=0, maximum=120)
        if minimum_age > maximum_age:
            _fail(path, "min_age cannot exceed max_age")
        for probability_key in ("base_probability", "chronic_probability"):
            probability = item.get(probability_key)
            if isinstance(probability, bool) or not isinstance(probability, (int, float)):
                _fail(f"{path}.{probability_key}", "must be a number")
            if not math.isfinite(float(probability)) or not 0.0 <= float(probability) <= 1.0:
                _fail(f"{path}.{probability_key}", "must be between 0 and 1")
        severity_min = _integer(item.get("severity_min"), f"{path}.severity_min", minimum=1, maximum=5)
        severity_max = _integer(item.get("severity_max"), f"{path}.severity_max", minimum=1, maximum=5)
        if severity_min > severity_max:
            _fail(path, "severity_min cannot exceed severity_max")
        duration_min = _integer(item.get("duration_min_years"), f"{path}.duration_min_years", minimum=1, maximum=120)
        duration_max = _integer(item.get("duration_max_years"), f"{path}.duration_max_years", minimum=1, maximum=120)
        if duration_min > duration_max:
            _fail(path, "duration_min_years cannot exceed duration_max_years")
        _integer(item.get("annual_health_delta"), f"{path}.annual_health_delta", minimum=-25, maximum=0)
        if not isinstance(item.get("treatable"), bool):
            _fail(f"{path}.treatable", "must be true or false")
    if "gambling_addiction" not in seen:
        _fail("diseases", "must include the casino condition gambling_addiction")
    return document


def validate_major_catalog(document: Any) -> dict[str, Any]:
    """Validate a major catalog with at least fifteen career-mapped disciplines."""
    if not isinstance(document, dict) or set(document) != {"schema_version", "majors"}:
        _fail("majors", "must contain exactly schema_version and majors")
    if isinstance(document.get("schema_version"), bool) or document.get("schema_version") != 1:
        _fail("majors.schema_version", "only version 1 is supported")
    majors = document.get("majors")
    if not isinstance(majors, list) or not 15 <= len(majors) <= 200:
        _fail("majors", "must contain between 15 and 200 definitions")
    seen: set[str] = set()
    for index, major in enumerate(majors):
        path = f"majors[{index}]"
        if not isinstance(major, dict) or set(major) != {"id", "name", "career_ids"}:
            _fail(path, "must contain exactly id, name, and career_ids")
        identifier = _string(major.get("id"), f"{path}.id", minimum=1, maximum=40)
        if not _EVENT_ID.fullmatch(identifier) or identifier in seen:
            _fail(f"{path}.id", "must be unique and use lowercase letters, digits, and underscores")
        seen.add(identifier)
        _string(major.get("name"), f"{path}.name", minimum=2, maximum=80)
        career_ids = major.get("career_ids")
        if not isinstance(career_ids, list) or not career_ids:
            _fail(f"{path}.career_ids", "must contain at least one career ID")
        if len(set(career_ids)) != len(career_ids):
            _fail(f"{path}.career_ids", "career IDs must be unique")
        for reference_index, career_id in enumerate(career_ids):
            value = _string(career_id, f"{path}.career_ids[{reference_index}]", minimum=1, maximum=40)
            if not _EVENT_ID.fullmatch(value):
                _fail(f"{path}.career_ids[{reference_index}]", "must be a lowercase career ID")
    return document


def validate_country_catalog(document: Any) -> dict[str, Any]:
    """Validate country display metadata and supported fictional gambling ages."""
    if not isinstance(document, dict) or set(document) != {"schema_version", "default_country", "countries"}:
        _fail("countries", "must contain exactly schema_version, default_country, and countries")
    if isinstance(document.get("schema_version"), bool) or document.get("schema_version") != 1:
        _fail("countries.schema_version", "only version 1 is supported")
    countries = document.get("countries")
    if not isinstance(countries, list) or not 20 <= len(countries) <= 250:
        _fail("countries", "must contain between 20 and 250 country/region definitions")
    seen: set[str] = set()
    for index, country in enumerate(countries):
        path = f"countries[{index}]"
        required_fields = {"id", "name", "gambling_age"}
        optional_modifiers = {"tax_mod", "cost_of_living_mod", "healthcare_mod"}
        if not isinstance(country, dict) or not required_fields.issubset(country) or set(country) - required_fields - optional_modifiers:
            _fail(path, "must contain id, name, gambling_age, and only supported economic modifiers")
        identifier = _string(country.get("id"), f"{path}.id", minimum=2, maximum=40)
        if not re.fullmatch(r"[a-z][a-z0-9_-]{1,39}", identifier) or identifier in seen:
            _fail(f"{path}.id", "must be unique and use a lowercase country code")
        seen.add(identifier)
        _string(country.get("name"), f"{path}.name", minimum=2, maximum=80)
        _integer(country.get("gambling_age"), f"{path}.gambling_age", minimum=18, maximum=25)
        for modifier in ("tax_mod", "cost_of_living_mod", "healthcare_mod"):
            if modifier in country:
                value = country[modifier]
                if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(float(value)):
                    _fail(f"{path}.{modifier}", "must be a finite number")
                if not 0.0 <= float(value) <= 5.0:
                    _fail(f"{path}.{modifier}", "must be between 0 and 5")
    default_country = _string(document.get("default_country"), "countries.default_country", minimum=2, maximum=40)
    if default_country not in seen:
        _fail("countries.default_country", "must reference a country in the catalog")
    return document


def validate_name_catalog(document: Any) -> dict[str, Any]:
    """Validate realistic regional name pools without privileged Discord data."""
    if not isinstance(document, dict) or set(document) != {"schema_version", "defaults", "countries"}:
        _fail("names", "must contain exactly schema_version, defaults, and countries")
    if isinstance(document.get("schema_version"), bool) or document.get("schema_version") != 1:
        _fail("names.schema_version", "only version 1 is supported")
    genders = {"male", "female", "non_binary"}
    defaults = document.get("defaults")
    if not isinstance(defaults, dict) or set(defaults) != genders:
        _fail("names.defaults", "must contain male, female, and non_binary pools")
    for gender, values in defaults.items():
        _validate_name_pool(values, f"names.defaults.{gender}")
    countries = document.get("countries")
    if not isinstance(countries, dict) or len(countries) < 20:
        _fail("names.countries", "must contain at least twenty regional name pools")
    for country_id, pools in countries.items():
        path = f"names.countries.{country_id}"
        if not isinstance(country_id, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{1,39}", country_id):
            _fail(path, "country key must be a lowercase code")
        if not isinstance(pools, dict) or set(pools) != genders:
            _fail(path, "must contain male, female, and non_binary pools")
        for gender, values in pools.items():
            _validate_name_pool(values, f"{path}.{gender}")
    return document


def _validate_name_pool(values: Any, path: str) -> None:
    """Validate one gender-specific first-name pool."""
    if not isinstance(values, list) or not 8 <= len(values) <= 200:
        _fail(path, "must contain between 8 and 200 names")
    seen: set[str] = set()
    for index, value in enumerate(values):
        clean = _string(value, f"{path}[{index}]", minimum=1, maximum=40)
        normalized = clean.casefold()
        if normalized in seen:
            _fail(f"{path}[{index}]", "names must be unique within a pool")
        seen.add(normalized)


def validate_catalog_set(documents: dict[str, Any]) -> dict[str, Any]:
    """Validate every required data file, record IDs, minimum counts, and cross-references.

    This startup/reload entry point accumulates errors across documents and event/career
    records. Messages include a filename and a record identifier whenever one is present.
    """
    validators = {
        "events.json": ("events", validate_event_catalog),
        "careers.json": ("careers", validate_career_catalog),
        "items.json": ("items", validate_item_catalog),
        "diseases.json": ("diseases", validate_disease_catalog),
        "crimes.json": ("crimes", validate_crime_catalog),
        "majors.json": ("majors", validate_major_catalog),
        "stocks.json": ("stocks", validate_stock_catalog),
        "achievements.json": ("achievements", validate_achievement_catalog),
        "names.json": ("names", validate_name_catalog),
        "countries.json": ("countries", validate_country_catalog),
        "gambling_ages.json": ("gambling_ages", validate_gambling_ages),
    }
    errors: list[str] = []
    for filename, (key, validator) in validators.items():
        if key not in documents:
            errors.append(f"{filename}: required catalog is missing")
            continue
        try:
            validator(documents[key])
        except (DataValidationError, TypeError, ValueError) as exc:
            errors.append(f"{filename}: {exc}")

    events = documents.get("events", {}).get("events", []) if isinstance(documents.get("events"), dict) else []
    careers = documents.get("careers", {}).get("careers", []) if isinstance(documents.get("careers"), dict) else []
    items = documents.get("items", {}).get("items", []) if isinstance(documents.get("items"), dict) else []
    diseases = documents.get("diseases", {}).get("diseases", []) if isinstance(documents.get("diseases"), dict) else []
    crimes = documents.get("crimes", {}).get("crimes", []) if isinstance(documents.get("crimes"), dict) else []
    majors = documents.get("majors", {}).get("majors", []) if isinstance(documents.get("majors"), dict) else []
    stocks = documents.get("stocks", {}).get("stocks", []) if isinstance(documents.get("stocks"), dict) else []
    achievements = documents.get("achievements", {}).get("achievements", []) if isinstance(documents.get("achievements"), dict) else []
    countries_doc = documents.get("countries", {})
    countries = countries_doc.get("countries", []) if isinstance(countries_doc, dict) else []
    names_doc = documents.get("names", {})
    names = names_doc.get("countries", {}) if isinstance(names_doc, dict) else {}
    careers_by_id = {str(row.get("id")): row for row in careers if isinstance(row, dict)}
    item_ids = {str(row.get("id")) for row in items if isinstance(row, dict)}
    disease_ids = {str(row.get("id")) for row in diseases if isinstance(row, dict)}
    crime_ids = {str(row.get("id")) for row in crimes if isinstance(row, dict)}
    major_ids = {str(row.get("id")) for row in majors if isinstance(row, dict)}
    achievement_ids = {str(row.get("id")) for row in achievements if isinstance(row, dict)}
    country_ids = {str(row.get("id")) for row in countries if isinstance(row, dict)}
    country_ids.update(names.keys())

    if len(events) < 150:
        errors.append(f"events.json: catalog has {len(events)} records; minimum is 150")
    required_categories = {
        "childhood", "school", "teen", "work", "romance", "family", "health",
        "money", "crime", "random_luck", "senior", "world",
    }
    actual_categories = {str(row.get("category")) for row in events if isinstance(row, dict)}
    for category in sorted(required_categories - actual_categories):
        errors.append(f"events.json: missing required category '{category}'")
    event_text = " ".join(
        str(row.get("title", "")) + " " + str(row.get("text", row.get("description", "")))
        for row in events if isinstance(row, dict)
    ).casefold()
    for required_term in ("pandemic", "recession", "lottery"):
        if required_term not in event_text:
            errors.append(f"events.json: required world event topic '{required_term}' is missing")
    if len(careers) < 28:
        errors.append(f"careers.json: catalog has {len(careers)} records; minimum is 28")
    for career in careers:
        if isinstance(career, dict) and len(career.get("levels", [])) < 4:
            errors.append(f"careers.json: record '{career.get('id', '<unknown>')}' has fewer than four levels")
    if len(items) < 60:
        errors.append(f"items.json: catalog has {len(items)} records; minimum is 60")
    if len(diseases) < 25:
        errors.append(f"diseases.json: catalog has {len(diseases)} records; minimum is 25")
    if len(crimes) < 14:
        errors.append(f"crimes.json: catalog has {len(crimes)} records; minimum is 14")
    if len(majors) < 15:
        errors.append(f"majors.json: catalog has {len(majors)} records; minimum is 15")
    if len(stocks) < 12:
        errors.append(f"stocks.json: catalog has {len(stocks)} records; minimum is 12")
    if len(achievements) < 60:
        errors.append(f"achievements.json: catalog has {len(achievements)} records; minimum is 60")
    if len(country_ids) < 20:
        errors.append(f"countries.json/names.json: only {len(country_ids)} distinct country pools; minimum is 20")

    def record_ref(filename: str, record_id: str, field: str, target: str, known: set[str]) -> None:
        if target not in known:
            errors.append(f"{filename}: record '{record_id}' field '{field}' references unknown ID '{target}'")

    for event in events:
        if not isinstance(event, dict):
            continue
        event_id = str(event.get("id", "<unknown>"))
        references = event.get("context", {}).get("references", {}) if isinstance(event.get("context"), dict) else {}
        ref_types = {
            "items": ("items.json", item_ids), "diseases": ("diseases.json", disease_ids),
            "careers": ("careers.json", set(careers_by_id)), "majors": ("majors.json", major_ids),
            "crimes": ("crimes.json", crime_ids), "achievements": ("achievements.json", achievement_ids),
        }
        if isinstance(references, dict):
            for reference_type, identifiers in references.items():
                if reference_type not in ref_types or not isinstance(identifiers, list):
                    continue
                filename, known = ref_types[reference_type]
                for target in identifiers:
                    record_ref("events.json", event_id, f"context.references.{reference_type}", str(target), known)
        conditions = event.get("conditions", {})
        event_countries = conditions.get("countries", event.get("countries", [])) if isinstance(conditions, dict) else []
        if isinstance(event_countries, list):
            for target in event_countries:
                record_ref("events.json", event_id, "conditions.countries", str(target), country_ids)
    for major in majors:
        if isinstance(major, dict):
            for target in major.get("career_ids", []):
                record_ref("majors.json", str(major.get("id", "<unknown>")), "career_ids", str(target), set(careers_by_id))
    for item in items:
        if isinstance(item, dict):
            for target in item.get("legal_countries", []):
                record_ref("items.json", str(item.get("id", "<unknown>")), "legal_countries", str(target), country_ids)
    gambling_ages = documents.get("gambling_ages", {}).get("countries", {}) if isinstance(documents.get("gambling_ages"), dict) else {}
    if isinstance(gambling_ages, dict):
        for target in gambling_ages:
            record_ref("gambling_ages.json", "<countries>", "countries", str(target), country_ids)
    crime_mods = documents.get("crimes", {}).get("crime_severity_mod", {}) if isinstance(documents.get("crimes"), dict) else {}
    if isinstance(crime_mods, dict):
        for target in crime_mods:
            if target != "default":
                record_ref("crimes.json", "<country modifiers>", "crime_severity_mod", str(target), country_ids)
    for country_id in names:
        record_ref("names.json", str(country_id), "countries", str(country_id), {str(row.get("id")) for row in countries if isinstance(row, dict)})

    if errors:
        raise DataValidationError("Content validation failed:\n- " + "\n- ".join(errors))
    return documents
