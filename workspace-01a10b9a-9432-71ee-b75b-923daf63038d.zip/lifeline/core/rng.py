"""Seedable random-number helpers used by game systems and deterministic tests."""
from __future__ import annotations

import hashlib
import random
from typing import Sequence, TypeVar

T = TypeVar("T")


class RNG:
    """Small wrapper around ``random.Random`` with a stable, injectable seed."""

    def __init__(self, seed: int | str | bytes | bytearray | None = None):
        self._random = random.Random(seed)

    def seed(self, seed: int | str | bytes | bytearray | None = None) -> None:
        self._random.seed(seed)

    def fork(self, namespace: str) -> "RNG":
        """Create a deterministic independent stream without consuming this stream."""
        if not isinstance(namespace, str) or not namespace:
            raise ValueError("RNG fork namespace must be a non-empty string")
        state = repr(self._random.getstate()).encode("utf-8")
        seed = hashlib.sha256(state + b"|" + namespace.encode("utf-8")).digest()
        return RNG(seed)

    def random(self) -> float:
        return self._random.random()

    def randint(self, a: int, b: int) -> int:
        return self._random.randint(a, b)

    def randrange(self, *args: int) -> int:
        return self._random.randrange(*args)

    def uniform(self, a: float, b: float) -> float:
        return self._random.uniform(a, b)

    def gauss(self, mu: float, sigma: float) -> float:
        return self._random.gauss(mu, sigma)

    def choice(self, values: Sequence[T]) -> T:
        if not values:
            raise IndexError("Cannot choose from an empty sequence")
        return self._random.choice(values)

    def sample(self, population: Sequence[T], k: int) -> list[T]:
        return self._random.sample(population, k)

    def shuffle(self, values: list[T]) -> None:
        self._random.shuffle(values)

    def weighted_choice(self, values: Sequence[T], weights: Sequence[float]) -> T:
        """Choose one value proportionally to positive weights."""
        if len(values) != len(weights) or not values:
            raise ValueError("values and weights must have the same non-zero length")
        clean_weights = [float(weight) for weight in weights]
        if any(weight < 0 for weight in clean_weights):
            raise ValueError("weights cannot be negative")
        total = sum(clean_weights)
        if total <= 0:
            raise ValueError("at least one weight must be positive")
        threshold = self.random() * total
        cumulative = 0.0
        for value, weight in zip(values, clean_weights):
            cumulative += weight
            if threshold < cumulative:
                return value
        # Protect against floating-point rounding at the upper endpoint.
        return values[-1]
