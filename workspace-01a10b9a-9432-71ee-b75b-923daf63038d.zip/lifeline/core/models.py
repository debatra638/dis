"""
Data models for LIFELINE bot.
All game entities as dataclasses with type hints.
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, List, Dict, Any
from enum import Enum


class Gender(str, Enum):
    MALE = "male"
    FEMALE = "female"
    NON_BINARY = "non_binary"


class LifeStage(str, Enum):
    BABY = "baby"
    CHILD = "child"
    TEEN = "teen"
    YOUNG_ADULT = "young_adult"
    ADULT = "adult"
    MIDDLE_AGE = "middle_age"
    SENIOR = "senior"


class HousingType(str, Enum):
    PARENTS = "parents"
    RENT = "rent"
    OWNED = "owned"
    HOMELESS = "homeless"
    PRISON = "prison"


class EducationLevel(str, Enum):
    NONE = "none"
    PRIMARY = "primary"
    HIGH_SCHOOL = "high_school"
    BACHELOR = "bachelor"
    MASTER = "master"
    DOCTORATE = "doctorate"


class RelationshipType(str, Enum):
    PARENT = "parent"
    SIBLING = "sibling"
    CHILD = "child"
    FRIEND = "friend"
    PARTNER = "partner"
    FIANCE = "fiance"
    SPOUSE = "spouse"
    EX = "ex"
    ENEMY = "enemy"
    COWORKER = "coworker"


class LoanType(str, Enum):
    PERSONAL = "personal"
    STUDENT = "student"
    MORTGAGE = "mortgage"
    AUTO = "auto"
    PAYDAY = "payday"
    LOAN_SHARK = "loan_shark"


class LoanStatus(str, Enum):
    ACTIVE = "active"
    PAID = "paid"
    DEFAULTED = "defaulted"
    DISCHARGED = "discharged"


class DiseaseStatus(str, Enum):
    ACTIVE = "active"
    CURED = "cured"
    CHRONIC = "chronic"
    IN_REMISSION = "in_remission"


class CrimeResult(str, Enum):
    SUCCESS = "success"
    FAILED = "failed"
    CAUGHT = "caught"


class JobAction(str, Enum):
    WORK_HARD = "hard"
    WORK_NORMAL = "normal"
    WORK_SLACK = "slack"


class StudyEffort(str, Enum):
    HARD = "hard"
    NORMAL = "normal"
    SLACK = "slack"


class Lifestyle(str, Enum):
    FRUGAL = "frugal"
    NORMAL = "normal"
    LAVISH = "lavish"


class PrisonAction(str, Enum):
    BEHAVE = "behave"
    WORKOUT = "workout"
    STUDY = "study"
    RIOT = "riot"
    ESCAPE = "escape"
    GANG = "gang"


class TradeStatus(str, Enum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    DECLINED = "declined"
    CANCELLED = "cancelled"
    EXPIRED = "expired"
    FAILED = "failed"


class EventType(str, Enum):
    AUTO = "auto"
    CHOICE = "choice"


class EventPolarity(str, Enum):
    POSITIVE = "positive"
    NEGATIVE = "negative"
    NEUTRAL = "neutral"


@dataclass
class Stats:
    """Core character stats (0-100)."""
    health: int = 80
    happiness: int = 70
    smarts: int = 50
    looks: int = 50
    fitness: int = 40
    karma: int = 50
    stress: int = 10
    addiction: int = 0
    fame: int = 0
    credit_score: Optional[int] = None

    def clamp_all(self) -> "Stats":
        """Return a copy with game stats clamped to 0–100 (credit score 300–850)."""
        def clamp(value: int | float) -> int:
            return max(0, min(100, int(round(value))))

        return Stats(
            health=clamp(self.health),
            happiness=clamp(self.happiness),
            smarts=clamp(self.smarts),
            looks=clamp(self.looks),
            fitness=clamp(self.fitness),
            karma=clamp(self.karma),
            stress=clamp(self.stress),
            addiction=clamp(self.addiction),
            fame=clamp(self.fame),
            credit_score=(max(300, min(850, int(round(self.credit_score)))) if self.credit_score is not None else None),
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "health": self.health,
            "happiness": self.happiness,
            "smarts": self.smarts,
            "looks": self.looks,
            "fitness": self.fitness,
            "karma": self.karma,
            "stress": self.stress,
            "addiction": self.addiction,
            "fame": self.fame,
            "credit_score": self.credit_score
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Stats":
        return cls(
            health=data.get("health", 80),
            happiness=data.get("happiness", 70),
            smarts=data.get("smarts", 50),
            looks=data.get("looks", 50),
            fitness=data.get("fitness", 40),
            karma=data.get("karma", 50),
            stress=data.get("stress", 10),
            addiction=data.get("addiction", 0),
            fame=data.get("fame", 0),
            credit_score=data.get("credit_score")
        )


@dataclass
class HiddenTraits:
    """Hidden traits rolled at birth."""
    genetic_health_mod: int = 0      # -10 to +10
    lifespan_mod: int = 0            # -8 to +8 years
    luck: int = 0                    # -5 to +5
    temperament: str = "neutral"     # calm, neutral, volatile


@dataclass
class Character:
    """Main character/life entity."""
    char_id: int = 0
    user_id: int = 0
    is_alive: bool = True
    name: str = ""
    gender: Gender = Gender.MALE
    country: str = "usa"
    wealth_class: str = "middle"
    age: int = 0
    stats: Stats = field(default_factory=Stats)
    hidden: HiddenTraits = field(default_factory=HiddenTraits)
    cash: int = 0
    bank: int = 0
    debt_total: int = 0
    price_index: float = 1.0
    housing_type: HousingType = HousingType.PARENTS
    lifestyle: Lifestyle = Lifestyle.NORMAL
    housing_item_id: Optional[int] = None
    rent_amount: int = 0
    education_level: EducationLevel = EducationLevel.NONE
    current_school: Optional[str] = None
    school_program: Optional[EducationLevel] = None
    school_years_left: int = 0
    gpa: Optional[float] = None
    major: Optional[str] = None
    has_license: bool = False
    has_ged: bool = False
    criminal_record: int = 0
    notoriety: int = 0
    in_prison: bool = False
    prison_years_left: int = 0
    has_insurance: bool = False
    insurance_paid_through_age: Optional[int] = None
    is_retired: bool = False
    bankrupt_until_age: Optional[int] = None
    last_bankruptcy_age: Optional[int] = None
    addiction_health_remainder: float = 0.0
    parent_char_id: Optional[int] = None
    generation: int = 1
    last_age_at: Optional[int] = None
    busy: bool = False
    version: int = 0
    born_at: int = 0
    died_at: Optional[int] = None
    death_cause: Optional[str] = None
    death_age: Optional[int] = None

    @property
    def life_stage(self) -> LifeStage:
        if self.age <= 2:
            return LifeStage.BABY
        elif self.age <= 12:
            return LifeStage.CHILD
        elif self.age <= 17:
            return LifeStage.TEEN
        elif self.age <= 29:
            return LifeStage.YOUNG_ADULT
        elif self.age <= 49:
            return LifeStage.ADULT
        elif self.age <= 64:
            return LifeStage.MIDDLE_AGE
        else:
            return LifeStage.SENIOR

    @property
    def net_worth(self) -> int:
        """Calculate net worth - will be computed by engine with items/holdings/loans."""
        return self.cash + self.bank - self.debt_total

    def to_dict(self) -> Dict[str, Any]:
        return {
            "char_id": self.char_id,
            "user_id": self.user_id,
            "is_alive": self.is_alive,
            "name": self.name,
            "gender": self.gender.value,
            "country": self.country,
            "wealth_class": self.wealth_class,
            "age": self.age,
            "stats": self.stats.to_dict(),
            "hidden": {
                "genetic_health_mod": self.hidden.genetic_health_mod,
                "lifespan_mod": self.hidden.lifespan_mod,
                "luck": self.hidden.luck,
                "temperament": self.hidden.temperament
            },
            "cash": self.cash,
            "bank": self.bank,
            "debt_total": self.debt_total,
            "price_index": self.price_index,
            "housing_type": self.housing_type.value,
            "lifestyle": self.lifestyle.value,
            "housing_item_id": self.housing_item_id,
            "rent_amount": self.rent_amount,
            "education_level": self.education_level.value,
            "current_school": self.current_school,
            "school_program": self.school_program.value if self.school_program else None,
            "school_years_left": self.school_years_left,
            "gpa": self.gpa,
            "major": self.major,
            "has_license": self.has_license,
            "has_ged": self.has_ged,
            "criminal_record": self.criminal_record,
            "notoriety": self.notoriety,
            "in_prison": self.in_prison,
            "prison_years_left": self.prison_years_left,
            "has_insurance": self.has_insurance,
            "insurance_paid_through_age": self.insurance_paid_through_age,
            "is_retired": self.is_retired,
            "bankrupt_until_age": self.bankrupt_until_age,
            "last_bankruptcy_age": self.last_bankruptcy_age,
            "addiction_health_remainder": self.addiction_health_remainder,
            "parent_char_id": self.parent_char_id,
            "generation": self.generation,
            "last_age_at": self.last_age_at,
            "busy": self.busy,
            "version": self.version,
            "born_at": self.born_at,
            "died_at": self.died_at,
            "death_cause": self.death_cause,
            "death_age": self.death_age
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Character":
        """Build a character from the JSON-safe representation used by SQLite."""
        hidden_data = data.get("hidden") or {}
        return cls(
            char_id=int(data.get("char_id", 0)),
            user_id=int(data.get("user_id", 0)),
            is_alive=bool(data.get("is_alive", True)),
            name=str(data.get("name", "")),
            gender=Gender(data.get("gender", Gender.MALE.value)),
            country=str(data.get("country", "usa")),
            wealth_class=str(data.get("wealth_class", "middle")),
            age=int(data.get("age", 0)),
            stats=Stats.from_dict(data.get("stats") or {}),
            hidden=HiddenTraits(
                genetic_health_mod=int(hidden_data.get("genetic_health_mod", 0)),
                lifespan_mod=int(hidden_data.get("lifespan_mod", 0)),
                luck=int(hidden_data.get("luck", 0)),
                temperament=str(hidden_data.get("temperament", "neutral")),
            ),
            cash=int(data.get("cash", 0)),
            bank=int(data.get("bank", 0)),
            debt_total=int(data.get("debt_total", 0)),
            price_index=float(data.get("price_index", 1.0)),
            housing_type=HousingType(data.get("housing_type", HousingType.PARENTS.value)),
            lifestyle=Lifestyle(data.get("lifestyle", Lifestyle.NORMAL.value)),
            housing_item_id=data.get("housing_item_id"),
            rent_amount=int(data.get("rent_amount", 0)),
            education_level=EducationLevel(data.get("education_level", EducationLevel.NONE.value)),
            current_school=data.get("current_school"),
            school_program=(EducationLevel(data["school_program"]) if data.get("school_program") else None),
            school_years_left=int(data.get("school_years_left", 0)),
            gpa=float(data["gpa"]) if data.get("gpa") is not None else None,
            major=data.get("major"),
            has_license=bool(data.get("has_license", False)),
            has_ged=bool(data.get("has_ged", False)),
            criminal_record=int(data.get("criminal_record", 0)),
            notoriety=int(data.get("notoriety", 0)),
            in_prison=bool(data.get("in_prison", False)),
            prison_years_left=int(data.get("prison_years_left", 0)),
            has_insurance=bool(data.get("has_insurance", False)),
            insurance_paid_through_age=(int(data["insurance_paid_through_age"])
                                        if data.get("insurance_paid_through_age") is not None else None),
            is_retired=bool(data.get("is_retired", False)),
            bankrupt_until_age=(int(data["bankrupt_until_age"]) if data.get("bankrupt_until_age") is not None else None),
            last_bankruptcy_age=(int(data["last_bankruptcy_age"]) if data.get("last_bankruptcy_age") is not None else None),
            addiction_health_remainder=float(data.get("addiction_health_remainder", 0.0)),
            parent_char_id=data.get("parent_char_id"),
            generation=int(data.get("generation", 1)),
            last_age_at=data.get("last_age_at"),
            busy=bool(data.get("busy", False)),
            version=int(data.get("version", 0)),
            born_at=int(data.get("born_at", 0)),
            died_at=data.get("died_at"),
            death_cause=data.get("death_cause"),
            death_age=data.get("death_age"),
        )


@dataclass
class Job:
    """Character's current job."""
    char_id: int = 0
    career_id: str = ""
    level: int = 0
    performance: int = 50
    years_in_role: int = 0
    years_in_career: int = 0
    salary: int = 0
    is_part_time: bool = False
    warnings: int = 0


@dataclass
class CareerHistory:
    """Historical career record."""
    id: int = 0
    char_id: int = 0
    career_id: str = ""
    max_level: int = 0
    start_age: int = 0
    end_age: Optional[int] = None
    end_reason: Optional[str] = None  # quit|fired|retired|laid_off|prison|died


@dataclass
class NPC:
    """Non-player character (family, partners, friends, children)."""
    npc_id: int = 0
    owner_char_id: int = 0
    name: str = ""
    gender: Gender = Gender.MALE
    age: int = 0
    looks: int = 50
    smarts: int = 50
    health: int = 80
    wealth: int = 0
    occupation: Optional[str] = None
    is_alive: bool = True
    death_age: Optional[int] = None


@dataclass
class Relationship:
    """Relationship between character and NPC."""
    id: int = 0
    char_id: int = 0
    npc_id: int = 0
    type: RelationshipType = RelationshipType.FRIEND
    score: int = 50
    since_age: int = 0


@dataclass
class ChildData:
    """Extra data for child NPCs."""
    npc_id: int = 0
    char_id: int = 0
    other_parent_npc_id: Optional[int] = None
    custody: str = "full"  # full|shared|none
    child_support: int = 0


@dataclass
class Item:
    """Item instance owned by character."""
    item_uid: int = 0
    char_id: int = 0
    item_id: str = ""
    quantity: int = 1
    purchase_price: int = 0
    current_value: int = 0
    condition: int = 100
    acquired_age: int = 0
    is_locked: bool = False


@dataclass
class Loan:
    """Loan held by character."""
    loan_id: int = 0
    char_id: int = 0
    type: LoanType = LoanType.PERSONAL
    principal: int = 0
    balance: int = 0
    annual_rate: float = 0.0
    term_years: int = 0
    annual_payment: int = 0
    years_remaining: int = 0
    missed_payments: int = 0
    collateral_item_uid: Optional[int] = None
    status: LoanStatus = LoanStatus.ACTIVE


@dataclass
class HealthCondition:
    """Active disease/condition."""
    id: int = 0
    char_id: int = 0
    disease_id: str = ""
    severity: int = 1
    diagnosed: bool = False
    onset_age: int = 0
    years_untreated: int = 0
    is_active: bool = True
    status: DiseaseStatus = DiseaseStatus.ACTIVE
    duration_years: int = 1
    last_treated_age: Optional[int] = None
    last_progressed_age: Optional[int] = None
    progression_count: int = 0


@dataclass
class CrimeLog:
    """Record of committed crime."""
    id: int = 0
    char_id: int = 0
    crime_id: str = ""
    age: int = 0
    success: bool = False
    caught: bool = False
    loot: int = 0
    sentence_years: int = 0


@dataclass
class PendingEvent:
    """Unresolved choice event."""
    char_id: int = 0
    event_id: str = ""
    context_json: str = ""
    nonce: str = ""
    created_at: int = 0


@dataclass
class LifeLogEntry:
    """Yearly life log entry."""
    id: int = 0
    char_id: int = 0
    age: int = 0
    category: str = ""
    text: str = ""
    importance: int = 1


@dataclass
class Stock:
    """Stock market symbol."""
    symbol: str = ""
    name: str = ""
    sector: str = ""
    price: int = 0
    volatility: float = 0.0
    drift: float = 0.0
    last_tick: int = 0
    is_delisted: bool = False


@dataclass
class Holding:
    """Character's stock holding."""
    char_id: int = 0
    symbol: str = ""
    shares: int = 0
    avg_cost: int = 0


@dataclass
class Trade:
    """Player-to-player trade."""
    trade_id: int = 0
    from_char: int = 0
    to_char: int = 0
    offer_cash: int = 0
    request_cash: int = 0
    offer_items_json: str = "[]"
    request_items_json: str = "[]"
    status: TradeStatus = TradeStatus.PENDING
    created_at: int = 0
    resolved_at: Optional[int] = None
    nonce: str = ""


@dataclass
class AchievementUnlocked:
    """User achievement record."""
    user_id: int = 0
    achievement_id: str = ""
    char_id: Optional[int] = None
    unlocked_at: int = 0


@dataclass
class PastLife:
    """Archived dead character summary."""
    char_id: int = 0
    user_id: int = 0
    name: str = ""
    death_age: int = 0
    death_cause: str = ""
    peak_net_worth: int = 0
    final_net_worth: int = 0
    education: str = ""
    top_career: Optional[str] = None
    children_count: int = 0
    marriages: int = 0
    convictions: int = 0
    life_score: int = 0
    epitaph: str = ""
    summary_json: str = ""
    ended_at: int = 0


@dataclass
class Cooldown:
    """Action cooldown."""
    user_id: int = 0
    action: str = ""
    expires_at: int = 0


@dataclass
class YearlyCounter:
    """Per-year action counter."""
    char_id: int = 0
    age: int = 0
    action: str = ""
    count: int = 0


@dataclass
class AuditLog:
    """Audit trail for money movements."""
    id: int = 0
    ts: int = 0
    user_id: Optional[int] = None
    char_id: Optional[int] = None
    action: str = ""
    amount: Optional[int] = None
    details_json: str = ""


@dataclass
class StatsTracking:
    """Lifetime stats for achievements/summary."""
    char_id: int = 0
    peak_net_worth: int = 0
    total_earned: int = 0
    total_taxes: int = 0
    total_gambled: int = 0
    total_gambling_net: int = 0
    crimes_committed: int = 0
    years_in_prison: int = 0
    marriages: int = 0
    divorces: int = 0
    hospital_visits: int = 0
    times_fired: int = 0
    promotions: int = 0