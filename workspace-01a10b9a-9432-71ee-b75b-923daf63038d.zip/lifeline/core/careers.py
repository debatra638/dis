"""Career catalog, job actions, promotions, and annual salary settlement."""
from __future__ import annotations

import json
import logging
import math
import time
from dataclasses import dataclass, replace
from typing import Any, Callable, Optional

import aiosqlite

from .config import GameBalance
from .data_loader import DataLoader
from .education import EDUCATION_RANK
from .errors import (
    CareerApplicationRejected,
    CharacterDead,
    CharacterInPrison,
    CharacterNotFound,
    ConcurrentUpdate,
    EducationRequirementError,
    JobAlreadyExists,
    NoActiveJob,
    PendingEventExists,
    RetiredCharacter,
    ValidationError,
    WorkAlreadyUsed,
)
from .locks import UserLockRegistry
from .models import Character, EducationLevel, Job, JobAction, Stats
from .money import format_cents, payout_cents, scale_cents
from .rng import RNG
from .repositories.crime import CrimeRepository
from .crime import calculate_job_application_chance
from .validators import validate_career_catalog

logger = logging.getLogger("lifeline.careers")


@dataclass(frozen=True, slots=True)
class CareerLevel:
    title: str
    annual_salary: int
    promotion_years: int


@dataclass(frozen=True, slots=True)
class CareerDefinition:
    id: str
    name: str
    minimum_age: int
    retirement_age: int
    minimum_education: EducationLevel
    minimum_smarts: int
    part_time_allowed: bool
    part_time_multiplier: float
    levels: tuple[CareerLevel, ...]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CareerDefinition":
        return cls(
            id=data["id"],
            name=data["name"],
            minimum_age=int(data["minimum_age"]),
            retirement_age=int(data["retirement_age"]),
            minimum_education=EducationLevel(data["minimum_education"]),
            minimum_smarts=int(data["minimum_smarts"]),
            part_time_allowed=bool(data.get("part_time_allowed", False)),
            part_time_multiplier=float(data.get("part_time_multiplier", 0.5)),
            levels=tuple(
                CareerLevel(
                    title=level["title"],
                    annual_salary=int(level["annual_salary"]),
                    promotion_years=int(level["promotion_years"]),
                )
                for level in data["levels"]
            ),
        )

    def salary_for(self, level: int, *, part_time: bool, price_index: float = 1.0) -> int:
        """Return an inflation-indexed annual salary, rounded down to whole cents."""
        if not 1 <= level <= len(self.levels):
            raise ValueError("career level is outside this career's ladder")
        if price_index <= 0 or not math.isfinite(float(price_index)):
            raise ValueError("price index must be finite and positive")
        entry_salary = self.levels[0].annual_salary
        raw_salary = self.levels[level - 1].annual_salary
        growth = max(0.0, float(GameBalance.CAREER_PROMOTION_GROWTH_MULTIPLIER))
        salary_before_index = entry_salary + payout_cents(max(0, raw_salary - entry_salary), growth)
        education_multiplier = GameBalance.CAREER_SALARY_BASE_MULTIPLIER
        if EDUCATION_RANK[self.minimum_education] >= EDUCATION_RANK[EducationLevel.BACHELOR]:
            education_multiplier *= GameBalance.CAREER_DEGREE_SALARY_MULTIPLIER
        salary = payout_cents(salary_before_index, education_multiplier)
        part_time_salary = payout_cents(salary, self.part_time_multiplier if part_time else 1.0)
        wage_index = float(price_index) ** GameBalance.WAGE_INFLATION_PASS_THROUGH
        return payout_cents(part_time_salary, wage_index)


@dataclass(frozen=True, slots=True)
class CareerStatus:
    job: Job
    career: CareerDefinition
    level_title: str
    next_promotion_years: Optional[int]


@dataclass(frozen=True, slots=True)
class CareerHistoryEntry:
    career_name: str
    top_title: str
    max_level: int
    start_age: int
    end_age: Optional[int]
    end_reason: Optional[str]


@dataclass(frozen=True, slots=True)
class WorkResult:
    character: Character
    career_status: CareerStatus
    action: JobAction
    performance_before: int
    performance_after: int
    stat_changes: dict[str, int]


@dataclass(frozen=True, slots=True)
class CareerYearResult:
    character: Character
    messages: tuple[str, ...] = ()


class CareerService:
    """Career actions persisted transactionally alongside the character record."""

    def __init__(
        self,
        db: Any,
        rng: RNG,
        locks: Optional[UserLockRegistry] = None,
        *,
        data_loader: Optional[DataLoader] = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.db = db
        self.rng = rng
        self.hiring_rng = rng.fork("lifeline-stage7-hiring")
        self.locks = locks or UserLockRegistry()
        self.clock = clock
        self.crime_repository = CrimeRepository(db)
        catalog = (data_loader or DataLoader()).load_careers()
        validate_career_catalog(catalog)
        self.careers = tuple(CareerDefinition.from_dict(item) for item in catalog["careers"])
        self._by_id = {career.id: career for career in self.careers}

    def replace_catalog(self, document: dict[str, Any]) -> None:
        """Validate and atomically replace the career definitions."""
        validate_career_catalog(document)
        careers = tuple(CareerDefinition.from_dict(item) for item in document["careers"])
        by_id = {career.id: career for career in careers}
        self.careers = careers
        self._by_id = by_id

    def get_career(self, career_id: str) -> CareerDefinition:
        try:
            return self._by_id[career_id]
        except KeyError as exc:
            raise ValidationError("That career is not available. Use `/career list` to browse careers.") from exc

    def eligible_careers(self, character: Character) -> list[CareerDefinition]:
        """Careers for which the character currently meets listed requirements."""
        if character.is_retired or not character.is_alive or character.in_prison:
            return []
        education_rank = max(
            EDUCATION_RANK[character.education_level],
            EDUCATION_RANK[EducationLevel.HIGH_SCHOOL] if character.has_ged else 0,
        )
        return [
            career for career in self.careers
            if career.minimum_age <= character.age <= career.retirement_age
            and education_rank >= EDUCATION_RANK[career.minimum_education]
            and character.stats.smarts >= career.minimum_smarts
        ]

    async def apply(self, user_id: int, career_id: str, *, part_time: bool = False) -> CareerStatus:
        """Start a job after validating age, education, ability, and part-time rules."""
        if not isinstance(user_id, int) or user_id <= 0:
            raise ValidationError("A valid Discord user ID is required.")
        if not isinstance(part_time, bool):
            raise ValidationError("Part-time must be true or false.")
        career = self.get_career(career_id)

        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._load_active(tx, user_id)
                await self._ensure_no_pending_event(tx, character.char_id)
                if character.in_prison:
                    raise CharacterInPrison()
                if await self.crime_repository.other_pending_prompt(tx, character.char_id):
                    raise PendingEventExists("Resolve the pending court or tax buttons before applying for a job.")
                if character.is_retired:
                    raise RetiredCharacter()
                if character.age < career.minimum_age:
                    raise EducationRequirementError(
                        f"You must be at least {career.minimum_age} to apply for {career.name}."
                    )
                if character.age > career.retirement_age:
                    raise EducationRequirementError(f"This career's retirement age is {career.retirement_age}.")
                education_rank = max(
                    EDUCATION_RANK[character.education_level],
                    EDUCATION_RANK[EducationLevel.HIGH_SCHOOL] if character.has_ged else 0,
                )
                if education_rank < EDUCATION_RANK[career.minimum_education]:
                    needed = career.minimum_education.value.replace("_", " ").title()
                    raise EducationRequirementError(f"{career.name} requires {needed} education.")
                if character.stats.smarts < career.minimum_smarts:
                    raise EducationRequirementError(
                        f"{career.name} requires at least {career.minimum_smarts} smarts."
                    )
                if part_time and not career.part_time_allowed:
                    raise EducationRequirementError(f"{career.name} does not offer part-time positions.")

                cursor = await tx.execute("SELECT 1 FROM jobs WHERE char_id = ?", (character.char_id,))
                if await cursor.fetchone():
                    raise JobAlreadyExists()

                await self.crime_repository.initialize_profile(tx, character.char_id)
                hiring_context = await self.crime_repository.get_hiring_context(tx, character.char_id) or {}
                hiring_chance = calculate_job_application_chance(
                    character.criminal_record,
                    age=character.age,
                    last_release_age=(
                        int(hiring_context["last_release_age"])
                        if hiring_context.get("last_release_age") is not None else None
                    ),
                )
                if self.hiring_rng.random() * 100.0 >= hiring_chance:
                    raise CareerApplicationRejected(
                        f"Your application was declined after a background check. Current hiring chance: {hiring_chance:.0f}%."
                    )

                level = 1
                first_level = career.levels[0]
                performance = max(20, min(80, 50 + character.hidden.luck * 2))
                salary = career.salary_for(
                    level, part_time=part_time, price_index=character.price_index
                )
                cursor = await tx.execute(
                    """INSERT INTO jobs
                           (char_id, career_id, level, performance, years_in_role,
                            years_in_career, salary, is_part_time, warnings)
                       VALUES (?, ?, ?, ?, 0, 0, ?, ?, 0)""",
                    (character.char_id, career.id, level, performance, salary, int(part_time)),
                )
                await tx.execute(
                    """INSERT INTO career_history (char_id, career_id, max_level, start_age)
                       VALUES (?, ?, ?, ?)""",
                    (character.char_id, career.id, level, character.age),
                )
                await self._insert_log(
                    tx,
                    character,
                    f"Started work as {first_level.title} in {career.name}, earning {format_cents(salary)} per year.",
                    int(self.clock()),
                )
                job = Job(
                    char_id=character.char_id,
                    career_id=career.id,
                    level=level,
                    performance=performance,
                    salary=salary,
                    is_part_time=part_time,
                )
                return self._status(job, career)

    async def status(self, user_id: int) -> CareerStatus:
        row = await self.db.fetchone(
            """SELECT j.* FROM jobs AS j
               JOIN characters AS c ON c.char_id = j.char_id
               WHERE c.user_id = ? AND c.is_alive = 1 LIMIT 1""",
            (user_id,),
        )
        if row is None:
            raise NoActiveJob()
        job = self._job_from_row(row)
        career = self.get_career(job.career_id)
        return self._status(job, career)

    async def history(self, user_id: int) -> list[CareerHistoryEntry]:
        """Return career records from the user's most recent life."""
        row = await self.db.fetchone(
            "SELECT char_id FROM characters WHERE user_id = ? ORDER BY char_id DESC LIMIT 1",
            (user_id,),
        )
        if row is None:
            raise CharacterNotFound()
        records = await self.db.fetchall(
            """SELECT career_id, max_level, start_age, end_age, end_reason
               FROM career_history WHERE char_id = ? ORDER BY start_age DESC, id DESC""",
            (row["char_id"],),
        )
        history: list[CareerHistoryEntry] = []
        for record in records:
            career = self._by_id.get(record["career_id"])
            max_level = int(record["max_level"])
            top_title = career.levels[max_level - 1].title if career and max_level <= len(career.levels) else record["career_id"]
            history.append(CareerHistoryEntry(
                career_name=career.name if career else str(record["career_id"]),
                top_title=top_title,
                max_level=max_level,
                start_age=int(record["start_age"]),
                end_age=int(record["end_age"]) if record["end_age"] is not None else None,
                end_reason=record["end_reason"],
            ))
        return history

    async def work(self, user_id: int, action: JobAction | str = JobAction.WORK_NORMAL) -> WorkResult:
        """Work once in the current in-game year to influence performance and stats."""
        try:
            selected_action = action if isinstance(action, JobAction) else JobAction(str(action).lower())
        except ValueError as exc:
            raise ValidationError("Choose hard, normal, or slack effort.") from exc

        performance_delta = {
            JobAction.WORK_HARD: 12,
            JobAction.WORK_NORMAL: 7,
            JobAction.WORK_SLACK: -8,
        }[selected_action]
        stress_delta = {
            JobAction.WORK_HARD: 3,
            JobAction.WORK_NORMAL: 1,
            JobAction.WORK_SLACK: -1,
        }[selected_action]
        happiness_delta = -1 if selected_action is JobAction.WORK_HARD else (1 if selected_action is JobAction.WORK_SLACK else 0)

        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._load_active(tx, user_id)
                await self._ensure_no_pending_event(tx, character.char_id)
                if character.in_prison:
                    raise CharacterInPrison()
                if character.is_retired:
                    raise RetiredCharacter()
                cursor = await tx.execute("SELECT * FROM jobs WHERE char_id = ?", (character.char_id,))
                row = await cursor.fetchone()
                if row is None:
                    raise NoActiveJob()
                job = self._job_from_row(row)
                career = self.get_career(job.career_id)
                cursor = await tx.execute(
                    "SELECT 1 FROM career_actions WHERE char_id = ? AND age = ? LIMIT 1",
                    (character.char_id, character.age),
                )
                if await cursor.fetchone():
                    raise WorkAlreadyUsed()

                performance_before = job.performance
                performance_after = max(0, min(100, performance_before + performance_delta))
                updated_job = replace(job, performance=performance_after)
                await tx.execute(
                    "UPDATE jobs SET performance = ? WHERE char_id = ?",
                    (performance_after, character.char_id),
                )

                before = character.stats.to_dict()
                stats = Stats.from_dict(before)
                stats.stress += stress_delta
                stats.happiness += happiness_delta
                stats = stats.clamp_all()
                stat_changes = {
                    key: int(getattr(stats, key) - before[key])
                    for key in ("stress", "happiness")
                    if getattr(stats, key) != before[key]
                }
                updated_character = replace(
                    character,
                    stats=stats,
                    version=expected_version + 1,
                )
                await self._save_character(tx, updated_character, expected_version)
                created_at = int(self.clock())
                await tx.execute(
                    """INSERT INTO career_actions
                           (char_id, age, action, performance_before, performance_after, created_at)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (
                        character.char_id,
                        character.age,
                        selected_action.value,
                        performance_before,
                        performance_after,
                        created_at,
                    ),
                )
                await self._insert_log(
                    tx,
                    updated_character,
                    f"Worked {selected_action.value} as {career.levels[job.level - 1].title}; performance is {performance_after}.",
                    created_at,
                )
                return WorkResult(
                    updated_character,
                    self._status(updated_job, career),
                    selected_action,
                    performance_before,
                    performance_after,
                    stat_changes,
                )

    async def quit(self, user_id: int) -> str:
        """Quit the active job and close its career-history entry."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._load_active(tx, user_id)
                await self._ensure_no_pending_event(tx, character.char_id)
                if character.in_prison:
                    raise CharacterInPrison()
                cursor = await tx.execute("SELECT career_id, level FROM jobs WHERE char_id = ?", (character.char_id,))
                row = await cursor.fetchone()
                if row is None:
                    raise NoActiveJob()
                career = self.get_career(row["career_id"])
                level_title = career.levels[int(row["level"]) - 1].title
                await self._close_job(tx, character.char_id, character.age, "quit")
                await self._insert_log(
                    tx,
                    character,
                    f"Quit the position of {level_title} in {career.name}.",
                    int(self.clock()),
                )
                return f"You quit your job as {level_title}. Your career history has been saved."

    async def retire(self, user_id: int) -> Character:
        """Retire from employment permanently, with an optional current job to close."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._load_active(tx, user_id)
                await self._ensure_no_pending_event(tx, character.char_id)
                if character.in_prison:
                    raise CharacterInPrison()
                if character.is_retired:
                    raise RetiredCharacter("You are already retired.")
                if character.age < 60:
                    raise EducationRequirementError("You must be at least 60 to retire.")
                cursor = await tx.execute("SELECT career_id FROM jobs WHERE char_id = ?", (character.char_id,))
                row = await cursor.fetchone()
                if row is not None:
                    await self._close_job(tx, character.char_id, character.age, "retired")
                updated = replace(character, is_retired=True, version=expected_version + 1)
                await self._save_character(tx, updated, expected_version)
                await self._insert_log(tx, updated, "Retired from the workforce.", int(self.clock()))
                return updated

    async def advance_year(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        previous_age: int,
        now: int,
    ) -> CareerYearResult:
        """Settle one worked year and update promotions/retirement inside age transaction."""
        if character.in_prison:
            return CareerYearResult(character, ("Employment income and work progression were paused during imprisonment.",))

        cursor = await tx.execute("SELECT * FROM jobs WHERE char_id = ?", (character.char_id,))
        row = await cursor.fetchone()
        if row is None:
            return CareerYearResult(character)

        job = self._job_from_row(row)
        career = self.get_career(job.career_id)
        paid_salary = career.salary_for(
            job.level, part_time=job.is_part_time, price_index=character.price_index
        )
        updated_character = replace(character, cash=character.cash + paid_salary)
        messages = [f"Earned {format_cents(paid_salary)} from {career.name} this year."]

        cursor = await tx.execute(
            "SELECT action FROM career_actions WHERE char_id = ? AND age = ? LIMIT 1",
            (character.char_id, previous_age),
        )
        action_row = await cursor.fetchone()
        performance = job.performance if action_row else max(0, job.performance - 2)
        years_in_role = job.years_in_role + 1
        years_in_career = job.years_in_career + 1
        warnings = job.warnings + 1 if performance < 20 else 0

        if not character.is_alive:
            await self._close_job(tx, character.char_id, character.age, "died")
            messages.append(f"Employment at {career.name} ended with the character's death.")
            return CareerYearResult(updated_character, tuple(messages))

        if character.age >= career.retirement_age:
            await self._close_job(tx, character.char_id, character.age, "retired")
            updated_character = replace(updated_character, is_retired=True)
            messages.append(f"Retired from {career.name} at age {character.age}.")
            return CareerYearResult(updated_character, tuple(messages))

        if warnings >= 2:
            await self._close_job(tx, character.char_id, character.age, "fired")
            messages.append(f"Was dismissed from {career.name} after repeated low-performance years.")
            return CareerYearResult(updated_character, tuple(messages))

        level = job.level
        salary = paid_salary
        if level < len(career.levels):
            current_level = career.levels[level - 1]
            promotion_years = max(
                1,
                math.ceil(current_level.promotion_years * GameBalance.CAREER_PROMOTION_TIME_MULTIPLIER),
            )
            if years_in_role >= promotion_years and performance >= 70:
                level += 1
                years_in_role = 0
                salary = career.salary_for(
                    level, part_time=job.is_part_time, price_index=character.price_index
                )
                performance = max(50, performance - 5)
                messages.append(f"Promoted to {career.levels[level - 1].title} in {career.name}!")
                await tx.execute(
                    """UPDATE career_history SET max_level = MAX(max_level, ?)
                       WHERE char_id = ? AND end_age IS NULL""",
                    (level, character.char_id),
                )

        await tx.execute(
            """UPDATE jobs SET level = ?, performance = ?, years_in_role = ?,
                   years_in_career = ?, salary = ?, warnings = ?
               WHERE char_id = ?""",
            (level, performance, years_in_role, years_in_career, salary, warnings, character.char_id),
        )
        return CareerYearResult(updated_character, tuple(messages))

    async def _load_active(self, tx: aiosqlite.Connection, user_id: int) -> tuple[Character, int]:
        cursor = await tx.execute(
            "SELECT char_id, data_json, version FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        row = await cursor.fetchone()
        if row is None:
            cursor = await tx.execute("SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,))
            if await cursor.fetchone():
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.char_id = int(row["char_id"])
        character.version = int(row["version"])
        return character, int(row["version"])

    @staticmethod
    async def _ensure_no_pending_event(tx: aiosqlite.Connection, char_id: int) -> None:
        cursor = await tx.execute("SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1", (char_id,))
        if await cursor.fetchone():
            raise PendingEventExists()

    @staticmethod
    async def _save_character(
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
    ) -> None:
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET stats_json = ?, version = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (stats_json, character.version, data_json, character.char_id, expected_version),
        )
        if cursor.rowcount != 1:
            raise ConcurrentUpdate()

    async def _close_job(self, tx: aiosqlite.Connection, char_id: int, age: int, reason: str) -> None:
        await tx.execute(
            """UPDATE career_history SET end_age = ?, end_reason = ?
               WHERE char_id = ? AND end_age IS NULL""",
            (age, reason, char_id),
        )
        await tx.execute("DELETE FROM jobs WHERE char_id = ?", (char_id,))

    @staticmethod
    async def _insert_log(
        tx: aiosqlite.Connection,
        character: Character,
        text: str,
        created_at: int,
    ) -> None:
        await tx.execute(
            """INSERT INTO life_logs (char_id, age, category, text, importance, created_at)
               VALUES (?, ?, 'career', ?, 2, ?)""",
            (character.char_id, character.age, text, created_at),
        )

    @staticmethod
    def _job_from_row(row: Any) -> Job:
        return Job(
            char_id=int(row["char_id"]),
            career_id=str(row["career_id"]),
            level=int(row["level"]),
            performance=int(row["performance"]),
            years_in_role=int(row["years_in_role"]),
            years_in_career=int(row["years_in_career"]),
            salary=int(row["salary"]),
            is_part_time=bool(row["is_part_time"]),
            warnings=int(row["warnings"]),
        )

    @staticmethod
    def _status(job: Job, career: CareerDefinition) -> CareerStatus:
        level = career.levels[job.level - 1]
        next_years = (
            max(0, level.promotion_years - job.years_in_role)
            if job.level < len(career.levels)
            else None
        )
        return CareerStatus(job, career, level.title, next_years)
