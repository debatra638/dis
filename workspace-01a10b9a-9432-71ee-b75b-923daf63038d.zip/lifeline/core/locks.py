"""In-process async lock registry for serializing actions per Discord user."""
from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import AsyncIterator, Hashable


@dataclass
class _LockEntry:
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    references: int = 0


class UserLockRegistry:
    """Provides one shared asyncio lock per key and cleans up unused entries."""

    def __init__(self) -> None:
        self._entries: dict[Hashable, _LockEntry] = {}
        self._guard = asyncio.Lock()

    @asynccontextmanager
    async def hold(self, key: Hashable) -> AsyncIterator[None]:
        async with self._guard:
            entry = self._entries.get(key)
            if entry is None:
                entry = self._entries[key] = _LockEntry()
            entry.references += 1

        try:
            async with entry.lock:
                yield
        finally:
            async with self._guard:
                entry.references -= 1
                if entry.references == 0 and self._entries.get(key) is entry:
                    del self._entries[key]

    @property
    def active_keys(self) -> int:
        """Number of keys currently held or awaited (primarily useful for tests)."""
        return len(self._entries)
