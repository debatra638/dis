"""Birth creation, stat rolls, and one-year life simulation."""
from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass, replace
from typing import Any, Callable, Optional

import aiosqlite

from .achievements import AchievementService
from .careers import CareerService
from .death import DeathResult, DeathService
from .casino import CasinoService
from .investing import InvestingService
from .crime import CrimeService, TaxEvasionPrompt, TrialPrompt
from .config import GameBalance
from .data_loader import DataLoader
from .education import advance_school_year
from .family import FamilyService
from .errors import (
    CharacterAlreadyExists,
    CharacterDead,
    CharacterNotFound,
    ConcurrentUpdate,
    InsufficientFunds,
    PendingEventExists,
    ValidationError,
)
from .events import EventEngine, EventPrompt
from .economy import EconomyService
from .health import HealthService
from .locks import UserLockRegistry
from .models import Character, Gender, HiddenTraits, LifeStage, Stats
from .repositories.legacy import LegacyRepository
from .rng import RNG
from .shop import ShopService

logger = logging.getLogger("lifeline.life")
_NAME_RE = re.compile(r"[^\x00-\x1f\x7f]+")


@dataclass(frozen=True, slots=True)
class YearOutcome:
    """Result of applying one simulated year to a character."""

    character: Character
    previous_age: int
    new_age: int
    died: bool
    death_cause: Optional[str]
    stat_changes: dict[str, int]
    previous_stage: LifeStage
    new_stage: LifeStage
    log_messages: tuple[str, ...]
    pending_event: Optional[EventPrompt] = None
    pending_trial: Optional[TrialPrompt] = None
    pending_tax: Optional[TaxEvasionPrompt] = None
    pending_compulsion: Optional[dict[str, Any]] = None
    unlocked_achievements: tuple[dict[str, Any], ...] = ()
    death_summary: Optional[dict[str, Any]] = None
    death_estate_id: Optional[int] = None
    death_estate_nonce: Optional[str] = None
    death_heirs: tuple[dict[str, Any], ...] = ()
    death_public_summary: bool = False


def _clamp_stat(value: int | float) -> int:
    return max(GameBalance.STAT_MIN, min(GameBalance.STAT_MAX, int(round(value))))


def _random_stat(rng: RNG, mean: float, stddev: float) -> int:
    return _clamp_stat(rng.gauss(mean, stddev))


def roll_birth_attributes(rng: RNG) -> tuple[Stats, HiddenTraits, str]:
    """Roll reproducible starting stats, hidden traits, and household wealth class."""
    hidden = HiddenTraits(
        genetic_health_mod=rng.randint(-10, 10),
        lifespan_mod=rng.randint(*GameBalance.LIFESPAN_MOD_RANGE),
        luck=rng.randint(-5, 5),
        temperament=rng.weighted_choice(
            ("calm", "neutral", "volatile"),
            (0.25, 0.55, 0.20),
        ),
    )
    wealth_class = rng.weighted_choice(
        tuple(GameBalance.WEALTH_CLASSES),
        tuple(GameBalance.WEALTH_CLASSES.values()),
    )
    stats = Stats(
        health=_clamp_stat(
            _random_stat(rng, GameBalance.HEALTH_INIT_MEAN, GameBalance.HEALTH_INIT_STDDEV)
            + hidden.genetic_health_mod
        ),
        happiness=_random_stat(rng, GameBalance.HAPPINESS_INIT_MEAN, GameBalance.HAPPINESS_INIT_STDDEV),
        smarts=_random_stat(rng, GameBalance.SMARTS_INIT_MEAN, GameBalance.SMARTS_INIT_STDDEV),
        looks=_random_stat(rng, GameBalance.LOOKS_INIT_MEAN, GameBalance.LOOKS_INIT_STDDEV),
        fitness=_random_stat(rng, GameBalance.FITNESS_INIT_MEAN, GameBalance.FITNESS_INIT_STDDEV),
        karma=_clamp_stat(50 + rng.randint(-10, 10)),
        stress=GameBalance.BASE_STRESS,
        addiction=0,
        fame=0,
        credit_score=None,
    ).clamp_all()
    return stats, hidden, wealth_class


def simulate_year(
    character: Character,
    rng: RNG,
    *,
    now: Optional[int] = None,
    apply_mortality: bool = True,
) -> YearOutcome:
    """Purely calculate one year's aging effects without writing to a database.

    Each call advances exactly one year. Stats remain within 0–100 and a character
    is guaranteed to die no later than ``GameBalance.MAX_AGE``.
    """
    if not character.is_alive:
        raise CharacterDead()
    if character.age < 0:
        raise ValidationError("Character age cannot be negative.")
    if character.age >= GameBalance.MAX_AGE:
        raise CharacterDead("This life has reached the maximum age and has ended.")

    old_age = character.age
    new_age = old_age + 1
    old_stage = character.life_stage
    stats = replace(character.stats)
    before = stats.to_dict()

    # Health varies slightly year to year; age and inherited resilience shape the drift.
    health_delta = rng.randint(-1, 1)
    if new_age >= 50:
        health_delta -= 1
    if new_age >= 70:
        health_delta -= 1
    if character.hidden.genetic_health_mod >= 7 and new_age < 70:
        health_delta += 1
    elif character.hidden.genetic_health_mod <= -7:
        health_delta -= 1
    stats.health = _clamp_stat(stats.health + health_delta)

    # Happiness trends gently toward the game's neutral point; stress recovers naturally.
    target = GameBalance.HAPPINESS_DRIFT_TARGET
    if stats.happiness < target:
        stats.happiness += GameBalance.HAPPINESS_DRIFT_RATE
    elif stats.happiness > target:
        stats.happiness -= GameBalance.HAPPINESS_DRIFT_RATE
    stats.stress = max(0, stats.stress - GameBalance.STRESS_DECAY_PER_YEAR)

    # Childhood and young adulthood build learning and fitness; aging slowly reduces fitness.
    if 6 <= new_age <= 29 and rng.random() < 0.55:
        stats.smarts += 1
    if new_age <= 25 and rng.random() < 0.35:
        stats.fitness += 1
    elif new_age >= 40:
        stats.fitness -= 1
    if new_age >= 70:
        stats.fitness -= 1
    if new_age >= 35 and new_age % 5 == 0:
        stats.looks -= 1

    stats = stats.clamp_all()
    death_cause: Optional[str] = None

    if apply_mortality:
        # Standalone simulation retains the legacy age/health hazard. LifeEngine uses
        # the integrated HealthService competing-risk calculation after disease progression.
        expected_lifespan = (
            GameBalance.BASE_LIFESPAN_MEAN
            + character.hidden.lifespan_mod
            + round(character.hidden.genetic_health_mod * 0.25)
        )
        age_hazard = 0.001 + max(0, new_age - 55) * 0.00035
        lifespan_hazard = max(0, new_age - expected_lifespan) * 0.018
        health_multiplier = max(0.55, min(1.8, 1.0 + (50 - stats.health) * 0.012))
        mortality_chance = min(0.95, (age_hazard + lifespan_hazard) * health_multiplier)
        if stats.health <= 0:
            death_cause = "illness"
        elif new_age >= GameBalance.MAX_AGE or rng.random() < mortality_chance:
            death_cause = "natural causes"

    timestamp = int(time.time()) if now is None else int(now)
    updated = replace(
        character,
        age=new_age,
        stats=stats,
        is_alive=death_cause is None,
        died_at=timestamp if death_cause else None,
        death_cause=death_cause,
        death_age=new_age if death_cause else None,
        last_age_at=timestamp,
    )
    new_stage = updated.life_stage
    changes = {
        key: int(stats.to_dict()[key] - before[key])
        for key in stats.to_dict()
        if stats.to_dict()[key] != before[key]
    }

    messages = [f"{updated.name or 'Your character'} turned {new_age}."]
    if new_stage != old_stage:
        messages.append(f"Entered the {new_stage.value.replace('_', ' ')} stage of life.")
    if death_cause:
        messages.append(f"Life ended at age {new_age} from {death_cause}.")

    return YearOutcome(
        character=updated,
        previous_age=old_age,
        new_age=new_age,
        died=death_cause is not None,
        death_cause=death_cause,
        stat_changes=changes,
        previous_stage=old_stage,
        new_stage=new_stage,
        log_messages=tuple(messages),
    )


class LifeEngine:
    """Persistence-backed API for creating, viewing, and aging a user's life."""

    def __init__(
        self,
        db: Any,
        rng: RNG,
        locks: Optional[UserLockRegistry] = None,
        clock: Callable[[], float] = time.time,
        event_engine: Optional[EventEngine] = None,
        event_chance: Optional[float] = None,
        career_service: Optional[CareerService] = None,
        family_service: Optional[FamilyService] = None,
        crime_service: Optional[CrimeService] = None,
        shop_service: Optional[ShopService] = None,
        casino_service: Optional[CasinoService] = None,
        investing_service: Optional[InvestingService] = None,
        economy_service: Optional[EconomyService] = None,
        health_service: Optional[HealthService] = None,
        achievement_service: Optional[AchievementService] = None,
        death_service: Optional[DeathService] = None,
        data_loader: Optional[DataLoader] = None,
    ) -> None:
        self.db = db
        self.rng = rng
        self.locks = locks or UserLockRegistry()
        self.clock = clock
        self.data_loader = data_loader or DataLoader()
        self.events = event_engine or EventEngine(
            db,
            rng,
            self.locks,
            data_loader=self.data_loader,
            event_chance=event_chance,
        )
        self.careers = career_service or CareerService(db, rng, self.locks, clock=clock, data_loader=self.data_loader)
        self.family = family_service or FamilyService(db, rng, self.locks, clock=clock)
        self.crimes = crime_service or CrimeService(
            db, rng, self.locks, family_service=self.family, clock=clock, data_loader=self.data_loader
        )
        self.shop = shop_service or ShopService(db, rng, self.locks, clock=clock, data_loader=self.data_loader)
        self.casino = casino_service or CasinoService(db, rng, self.locks, clock=clock, data_loader=self.data_loader)
        self.investing = investing_service or InvestingService(db, rng, self.locks, clock=clock, data_loader=self.data_loader)
        self.economy = economy_service or EconomyService(db, rng, self.locks, clock=clock, data_loader=self.data_loader)
        self.health = health_service or HealthService(
            db, rng, self.economy, self.locks, clock=clock, data_loader=self.data_loader
        )
        self.legacy_repository = LegacyRepository(db)
        self.achievements = achievement_service or AchievementService(
            db, self.locks, clock=clock, data_loader=self.data_loader
        )
        self.death = death_service or DeathService(
            db, self.locks, clock=clock, achievements=self.achievements,
            family_service=self.family, crime_service=self.crimes, casino_service=self.casino,
        )

    def reload_catalogs(self, catalogs: dict[str, Any]) -> None:
        """Replace validated in-memory service catalogs after an atomic data reload."""
        self.events.replace_catalog(catalogs["events"])
        self.careers.replace_catalog(catalogs["careers"])
        self.crimes.replace_catalog(catalogs["crimes"])
        self.shop.replace_catalog(catalogs["items"])
        self.casino.replace_catalogs(catalogs["items"], catalogs["gambling_ages"])
        self.investing.replace_catalogs(catalogs["stocks"], catalogs["items"])
        self.achievements.replace_catalogs(catalogs["achievements"], catalogs["items"])
        self.health.replace_catalog(catalogs["diseases"])

    async def create_character(
        self,
        user_id: int,
        name: str,
        *,
        gender: Gender | str = Gender.MALE,
        country: str = "usa",
        parent_char_id: Optional[int] = None,
        legacy_stat: Optional[str] = None,
        legacy_purchases: int = 0,
    ) -> Character:
        """Create one active life for a Discord user, starting at age zero."""
        if not isinstance(user_id, int) or user_id <= 0:
            raise ValidationError("A valid Discord user ID is required.")
        clean_name = self._validate_name(name)
        clean_country = self._validate_country(country)
        try:
            clean_gender = gender if isinstance(gender, Gender) else Gender(str(gender).lower())
        except ValueError as exc:
            raise ValidationError("Choose male, female, or non-binary.") from exc
        allowed_legacy_stats = {"health", "happiness", "smarts", "looks", "fitness", "karma"}
        if isinstance(legacy_purchases, bool) or legacy_purchases not in (0, 1, 2):
            raise ValidationError("Legacy purchases must be zero, one, or two.")
        if legacy_purchases == 0 and legacy_stat is not None:
            raise ValidationError("Choose a legacy stat only when spending legacy points.")
        if legacy_purchases > 0 and legacy_stat not in allowed_legacy_stats:
            raise ValidationError("Choose a valid starting stat for your legacy purchase.")

        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                cursor = await tx.execute(
                    "SELECT char_id FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
                    (user_id,),
                )
                if await cursor.fetchone():
                    raise CharacterAlreadyExists()
                now = int(self.clock())
                if legacy_purchases:
                    await self.legacy_repository.ensure_player(tx, user_id, now)
                await self.legacy_repository.close_pending_life_estates(tx, user_id, now)

                generation = 1
                if parent_char_id is not None:
                    cursor = await tx.execute(
                        "SELECT data_json FROM characters WHERE char_id = ?",
                        (parent_char_id,),
                    )
                    parent_row = await cursor.fetchone()
                    if parent_row is None:
                        raise ValidationError("The selected parent life could not be found.")
                    parent = Character.from_dict(json.loads(parent_row["data_json"]))
                    generation = parent.generation + 1

                stats, hidden, wealth_class = roll_birth_attributes(self.rng)
                character = Character(
                    user_id=user_id,
                    name=clean_name,
                    gender=clean_gender,
                    country=clean_country,
                    wealth_class=wealth_class,
                    age=0,
                    stats=stats,
                    hidden=hidden,
                    cash=0,
                    bank=0,
                    debt_total=0,
                    parent_char_id=parent_char_id,
                    generation=generation,
                    last_age_at=now,
                    born_at=now,
                )
                cursor = await tx.execute(
                    """INSERT INTO characters (
                           user_id, is_alive, name, gender, country, wealth_class, age,
                           stats_json, hidden_json, version, last_age_at, born_at,
                           died_at, death_cause, death_age, data_json
                       ) VALUES (?, 1, ?, ?, ?, ?, 0, ?, ?, 0, ?, ?, NULL, NULL, NULL, ?)""",
                    self._row_values(character),
                )
                char_id = int(cursor.lastrowid)
                character = replace(character, char_id=char_id)
                await self._refresh_data_json(tx, character)
                if legacy_purchases:
                    try:
                        await self.legacy_repository.spend_legacy_points(
                            tx, user_id=user_id, char_id=char_id, stat_name=str(legacy_stat),
                            purchase_count=legacy_purchases, now=now,
                        )
                    except ValueError as exc:
                        raise InsufficientFunds("You do not have enough legacy points for that starting-stat purchase.") from exc
                    boosted = replace(character.stats)
                    setattr(boosted, str(legacy_stat), min(100, getattr(boosted, str(legacy_stat)) + 5 * legacy_purchases))
                    character = replace(character, stats=boosted.clamp_all())
                    await self._refresh_data_json(tx, character)
                    await self.legacy_repository.audit_legacy_purchase(
                        tx, user_id=user_id, char_id=char_id, stat_name=str(legacy_stat),
                        purchase_count=legacy_purchases, now=now,
                    )
                await self.family.initialize_family(tx, character)
                await self.crimes.initialize_character(tx, character)
                await self._insert_log(
                    tx,
                    character,
                    age=0,
                    category="birth",
                    text=f"{clean_name} was born into a {wealth_class} household.",
                    importance=3,
                    created_at=now,
                )
                return character

    async def get_active_character(self, user_id: int) -> Character:
        """Return a user's active character or raise ``CharacterNotFound``."""
        row = await self.db.fetchone(
            "SELECT data_json FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        if row is None:
            latest = await self.db.fetchone(
                "SELECT data_json FROM characters WHERE user_id = ? ORDER BY char_id DESC LIMIT 1",
                (user_id,),
            )
            if latest is not None:
                raise CharacterDead()
            raise CharacterNotFound()
        return Character.from_dict(json.loads(row["data_json"]))

    async def age_up(self, user_id: int, *, guild_id: Optional[int] = None) -> YearOutcome:
        """Advance a year and run Stage 10 metrics, achievements, and death in the tick transaction."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                cursor = await tx.execute(
                    "SELECT data_json, version FROM characters "
                    "WHERE user_id = ? AND is_alive = 1 LIMIT 1",
                    (user_id,),
                )
                row = await cursor.fetchone()
                if row is None:
                    # Distinguish a completed life from a user who never started.
                    cursor = await tx.execute(
                        "SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,)
                    )
                    if await cursor.fetchone():
                        raise CharacterDead()
                    raise CharacterNotFound()

                character = Character.from_dict(json.loads(row["data_json"]))
                # A pending choice must be resolved before the next simulated year.
                cursor = await tx.execute(
                    "SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1",
                    (character.char_id,),
                )
                if await cursor.fetchone():
                    raise PendingEventExists()
                await self.crimes.ensure_no_pending_decision(tx, character.char_id)
                await self.casino.require_no_active_hand(tx, character.char_id)
                await self.casino.require_no_pending_compulsion(tx, character.char_id)

                # Keep the database version authoritative if a caller's JSON was stale.
                character.version = int(row["version"])
                timestamp = int(self.clock())
                prior_stats = character.stats.to_dict()
                outcome = simulate_year(character, self.rng, now=timestamp, apply_mortality=False)
                health_progress = await self.health.advance_year(
                    tx,
                    outcome.character,
                    previous_age=outcome.previous_age,
                    now=timestamp,
                )
                health_character, death_cause, _ = self.health.resolve_mortality(
                    health_progress.character,
                    health_progress.active_conditions,
                    now=timestamp,
                )
                age_messages = list(outcome.log_messages) + list(health_progress.messages)
                if death_cause:
                    age_messages.append(f"Life ended at age {health_character.age} from {death_cause}.")
                updated_stats = health_character.stats.to_dict()
                stat_changes = {
                    key: int(updated_stats[key] - prior_stats[key])
                    for key in updated_stats
                    if updated_stats[key] != prior_stats[key]
                }
                outcome = replace(
                    outcome,
                    character=health_character,
                    died=death_cause is not None,
                    death_cause=death_cause,
                    stat_changes=stat_changes,
                    log_messages=tuple(age_messages),
                )
                school_progress = advance_school_year(outcome.character)
                career_progress = await self.careers.advance_year(
                    tx,
                    school_progress.character,
                    previous_age=outcome.previous_age,
                    now=timestamp,
                )
                shop_progress = await self.shop.advance_year(
                    tx,
                    career_progress.character,
                    now=timestamp,
                )
                casino_progress = await self.casino.advance_year(
                    tx,
                    shop_progress.character,
                    previous_age=outcome.previous_age,
                    now=timestamp,
                )
                investment_progress = await self.investing.advance_year(
                    tx,
                    casino_progress.character,
                    previous_age=outcome.previous_age,
                    now=timestamp,
                    housing_upkeep_paid=shop_progress.character.is_alive and not shop_progress.character.in_prison,
                )
                career_income = max(0, career_progress.character.cash - school_progress.character.cash)
                personal_income = career_income + shop_progress.business_income + investment_progress.income_cents
                family_progress = await self.family.advance_year(
                    tx,
                    investment_progress.character,
                    previous_age=outcome.previous_age,
                    personal_income=personal_income,
                    now=timestamp,
                )
                crime_progress = await self.crimes.advance_year(
                    tx,
                    family_progress.character,
                    previous_age=outcome.previous_age,
                    personal_income=personal_income,
                    household_income=family_progress.household_income,
                    tax_assessed=family_progress.tax_assessed,
                    tax_paid=family_progress.tax_paid,
                    now=timestamp,
                )
                economy_progress = await self.economy.advance_year(
                    tx,
                    crime_progress.character,
                    previous_age=outcome.previous_age,
                    now=timestamp,
                )
                updated = replace(economy_progress.character, version=character.version + 1)
                all_messages = (
                    outcome.log_messages
                    + school_progress.messages
                    + career_progress.messages
                    + shop_progress.messages
                    + casino_progress.messages
                    + investment_progress.messages
                    + family_progress.messages
                    + crime_progress.messages
                    + economy_progress.messages
                )
                outcome = replace(outcome, character=updated, log_messages=all_messages)
                await self._save_character(tx, updated, expected_version=character.version)

                for message in outcome.log_messages:
                    if message.startswith("Life ended at age"):
                        category, importance = "death", 5
                    elif message in school_progress.messages:
                        category, importance = "education", 3
                    elif message in career_progress.messages:
                        category, importance = "career", 2
                    elif message in shop_progress.messages:
                        category, importance = "economy", 2
                    elif message in casino_progress.messages:
                        category, importance = "casino", 2
                    elif message in investment_progress.messages:
                        category, importance = "investing", 2
                    elif message in family_progress.messages:
                        category, importance = "family", 2
                    elif message in crime_progress.messages:
                        category, importance = ("prison" if "prison" in message.lower() else "crime"), 3
                    elif message in economy_progress.messages:
                        category, importance = "economy", 2
                    elif message in health_progress.messages:
                        category, importance = "health", 2
                    else:
                        category = "aging"
                        importance = 3 if "stage of life" in message else 1
                    await self._insert_log(
                        tx,
                        updated,
                        age=updated.age,
                        category=category,
                        text=message,
                        importance=importance,
                        created_at=timestamp,
                    )

                pending_event = None
                has_stage7_prompt = crime_progress.pending_trial is not None or crime_progress.pending_tax is not None
                if (updated.is_alive and not updated.in_prison and not has_stage7_prompt
                        and casino_progress.compulsion is None):
                    pending_event = await self.events.maybe_create_pending(
                        tx,
                        updated,
                        now=timestamp,
                    )
                    if pending_event is not None:
                        await self._insert_log(
                            tx,
                            updated,
                            age=updated.age,
                            category="event",
                            text=f"A choice event began: {pending_event.event.title}.",
                            importance=2,
                            created_at=timestamp,
                        )

                # Stage 10 step 15: record the annual observation, unlock from authoritative
                # records, then archive a death before this BEGIN IMMEDIATE transaction commits.
                await self.legacy_repository.record_life_year(
                    tx,
                    character=updated,
                    age=updated.age,
                    served_prison_year=character.in_prison,
                    now=timestamp,
                )
                unlocked = await self.achievements.check_user_in_tx(
                    tx, user_id, now=timestamp, guild_id=guild_id
                )
                death_result: Optional[DeathResult] = None
                if not updated.is_alive:
                    death_result = await self.death.handle_death(
                        tx, updated, now=timestamp, guild_id=guild_id
                    )

                newly_unlocked = {str(row["id"]): row for row in unlocked}
                if death_result is not None:
                    newly_unlocked.update(
                        (str(row["id"]), row)
                        for row in death_result.unlocked_achievements
                    )
                committed_unlocks = tuple(newly_unlocked.values())
                result = replace(
                    outcome,
                    character=updated,
                    died=not updated.is_alive,
                    death_cause=updated.death_cause,
                    pending_event=pending_event,
                    pending_trial=crime_progress.pending_trial,
                    pending_tax=crime_progress.pending_tax,
                    pending_compulsion=casino_progress.compulsion,
                    unlocked_achievements=committed_unlocks,
                    death_summary=death_result.summary if death_result is not None else None,
                    death_estate_id=death_result.estate_id if death_result is not None else None,
                    death_estate_nonce=death_result.estate_nonce if death_result is not None else None,
                    death_heirs=death_result.heirs if death_result is not None else (),
                    death_public_summary=death_result.public_summary if death_result is not None else False,
                )
            self.achievements.queue_notifications(user_id, committed_unlocks)
            return result

    @staticmethod
    def _validate_name(name: str) -> str:
        if not isinstance(name, str):
            raise ValidationError("Enter a character name.")
        clean = " ".join(name.split()).strip()
        if not clean or len(clean) > 32 or not _NAME_RE.fullmatch(clean):
            raise ValidationError("Name must be 1–32 characters and contain no control characters.")
        return clean

    @staticmethod
    def _validate_country(country: str) -> str:
        if not isinstance(country, str):
            raise ValidationError("Enter a country or region code.")
        clean = " ".join(country.split()).strip().lower()
        if not clean or len(clean) > 40 or not _NAME_RE.fullmatch(clean):
            raise ValidationError("Country or region must be 1–40 characters.")
        return clean

    @staticmethod
    def _row_values(character: Character) -> tuple[Any, ...]:
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        hidden_json = json.dumps({
            "genetic_health_mod": character.hidden.genetic_health_mod,
            "lifespan_mod": character.hidden.lifespan_mod,
            "luck": character.hidden.luck,
            "temperament": character.hidden.temperament,
        }, separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        return (
            character.user_id,
            character.name,
            character.gender.value,
            character.country,
            character.wealth_class,
            stats_json,
            hidden_json,
            character.last_age_at,
            character.born_at,
            data_json,
        )

    async def _refresh_data_json(self, tx: aiosqlite.Connection, character: Character) -> None:
        """Persist a newly assigned ID to the JSON snapshot."""
        await tx.execute(
            "UPDATE characters SET data_json = ? WHERE char_id = ?",
            (json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False), character.char_id),
        )

    async def _save_character(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        expected_version: int,
    ) -> None:
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        hidden_json = json.dumps({
            "genetic_health_mod": character.hidden.genetic_health_mod,
            "lifespan_mod": character.hidden.lifespan_mod,
            "luck": character.hidden.luck,
            "temperament": character.hidden.temperament,
        }, separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET
                   is_alive = ?, name = ?, gender = ?, country = ?, wealth_class = ?, age = ?,
                   stats_json = ?, hidden_json = ?, version = ?, last_age_at = ?,
                   died_at = ?, death_cause = ?, death_age = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (
                int(character.is_alive), character.name, character.gender.value,
                character.country, character.wealth_class, character.age,
                stats_json, hidden_json, character.version, character.last_age_at,
                character.died_at, character.death_cause, character.death_age,
                data_json, character.char_id, expected_version,
            ),
        )
        if cursor.rowcount != 1:
            raise ConcurrentUpdate()

    @staticmethod
    async def _insert_log(
        tx: aiosqlite.Connection,
        character: Character,
        *,
        age: int,
        category: str,
        text: str,
        importance: int,
        created_at: int,
    ) -> None:
        await tx.execute(
            """INSERT INTO life_logs (char_id, age, category, text, importance, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (character.char_id, age, category, text, importance, created_at),
        )
