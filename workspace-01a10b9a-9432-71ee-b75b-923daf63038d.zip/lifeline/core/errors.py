"""User-safe domain exceptions for LIFELINE game operations."""
from __future__ import annotations


class GameError(Exception):
    """Expected game-rule error whose message is safe to show to a player."""

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message


class ValidationError(GameError):
    """An input value does not satisfy game rules."""


class CharacterNotFound(GameError):
    def __init__(self, message: str = "You do not have a life yet. Start one with `/life start`."):
        super().__init__(message)


class CharacterAlreadyExists(GameError):
    def __init__(self, message: str = "You already have an active life. Use `/life status` to view it."):
        super().__init__(message)


class CharacterDead(GameError):
    def __init__(self, message: str = "This life has ended. Start a new one to continue playing."):
        super().__init__(message)


class CharacterBusy(GameError):
    def __init__(self, message: str = "Your character is already processing an action. Try again in a moment."):
        super().__init__(message)


class ConcurrentUpdate(GameError):
    def __init__(self, message: str = "Your life changed while this action was processing. Please try again."):
        super().__init__(message)


class PendingEventExists(GameError):
    def __init__(self, message: str = "Resolve your pending life event with `/life choice` before aging again."):
        super().__init__(message)


class PendingEventNotFound(GameError):
    def __init__(self, message: str = "You have no pending life event. Use `/life age` to continue your story."):
        super().__init__(message)


class StaleEvent(GameError):
    def __init__(self, message: str = "This choice has already been resolved or is no longer available. Use `/life choice` to check for another event."):
        super().__init__(message)


class NotEnrolled(GameError):
    def __init__(self, message: str = "You are not currently enrolled. Check `/education status` for options."):
        super().__init__(message)


class StudyAlreadyUsed(GameError):
    def __init__(self, message: str = "You have already studied this year. You can study again after `/life age`."):
        super().__init__(message)


class EducationRequirementError(GameError):
    def __init__(self, message: str):
        super().__init__(message)


class JobAlreadyExists(GameError):
    def __init__(self, message: str = "You already have a job. Use `/career status` or `/career quit` first."):
        super().__init__(message)


class NoActiveJob(GameError):
    def __init__(self, message: str = "You do not have a job right now. Use `/career list` to explore careers."):
        super().__init__(message)


class WorkAlreadyUsed(GameError):
    def __init__(self, message: str = "You have already worked this in-game year. Work again after `/life age`."):
        super().__init__(message)


class RetiredCharacter(GameError):
    def __init__(self, message: str = "You are retired and cannot take a new job."):
        super().__init__(message)


class FamilyRequirementError(GameError):
    """A family or relationship action is not permitted by current life state."""


class RelationshipNotFound(GameError):
    def __init__(self, message: str = "That person is not in your relationship list."):
        super().__init__(message)


class InteractionLimitReached(GameError):
    def __init__(self, message: str = "You have used all three interactions with this person this year."):
        super().__init__(message)


class InsufficientFunds(GameError):
    def __init__(self, message: str = "You do not have enough available funds for that action."):
        super().__init__(message)


class DateSessionExpired(GameError):
    def __init__(self, message: str = "These date options expired. Use `/date find` to meet new people."):
        super().__init__(message)


class NoActiveMarriage(GameError):
    def __init__(self, message: str = "You are not currently married."):
        super().__init__(message)


class CharacterInPrison(GameError):
    """A command is unavailable while the active character is incarcerated."""

    def __init__(self, message: str = "This action is unavailable while your character is in prison."):
        super().__init__(message)


class CharacterNotInPrison(GameError):
    """A prison-only action was requested by a character outside custody."""

    def __init__(self, message: str = "Your character is not currently in prison."):
        super().__init__(message)


class CrimeLimitReached(GameError):
    """The character has used both crime attempts available this in-game year."""

    def __init__(self, message: str = "You have already attempted two crimes this in-game year."):
        super().__init__(message)


class CrimeSessionExpired(GameError):
    """A risk-confirmation nonce expired or was already consumed."""

    def __init__(self, message: str = "This crime confirmation expired. Use `/crime commit` to review the risk again."):
        super().__init__(message)


class TrialNotFound(GameError):
    """No owner-matched criminal trial is waiting for a lawyer choice."""

    def __init__(self, message: str = "There is no pending trial for this life. Use `/crime record` to review your record."):
        super().__init__(message)


class TaxDecisionNotFound(GameError):
    """No owner-matched high-earner tax decision is waiting for a choice."""

    def __init__(self, message: str = "There is no pending tax decision for this life."):
        super().__init__(message)


class CrimeActionAlreadyUsed(GameError):
    """A prisoner already used their one prison action for this in-game year."""

    def __init__(self, message: str = "You have already taken a prison action this year."):
        super().__init__(message)


class CareerApplicationRejected(GameError):
    """A criminal-record hiring roll did not result in a job offer."""

    def __init__(self, message: str = "Your application was declined after the employer's background check."):
        super().__init__(message)


class StaleShopQuote(GameError):
    """A shop confirmation no longer matches current prices or balances."""

    def __init__(self, message: str = "Your price or balance changed. Please retry the shop purchase."):
        super().__init__(message)


class TradeNotFound(GameError):
    """A trade identifier is missing or does not belong to the requesting player."""

    def __init__(self, message: str = "That trade is unavailable or does not belong to you."):
        super().__init__(message)


class TradeExpired(GameError):
    """A trade proposal is no longer pending or its ten-minute window elapsed."""

    def __init__(self, message: str = "That trade is no longer pending. Use `/trade list` to review its status."):
        super().__init__(message)
