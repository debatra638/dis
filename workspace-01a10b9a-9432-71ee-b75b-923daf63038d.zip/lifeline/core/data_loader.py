"""JSON game-data loading with schema validation and modification-time caching."""
from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any, Callable, Optional

from .validators import (
    DataValidationError,
    validate_career_catalog,
    validate_crime_catalog,
    validate_event_catalog,
    validate_item_catalog,
    validate_stock_catalog,
    validate_gambling_ages,
    validate_achievement_catalog,
    validate_disease_catalog,
    validate_major_catalog,
    validate_country_catalog,
    validate_name_catalog,
    validate_catalog_set,
)


Validator = Callable[[Any], Any]


class DataLoader:
    """Load validated JSON files from the bot's ``data`` directory."""

    CONTENT_FILES: dict[str, Validator] = {
        "events.json": validate_event_catalog,
        "careers.json": validate_career_catalog,
        "items.json": validate_item_catalog,
        "diseases.json": validate_disease_catalog,
        "crimes.json": validate_crime_catalog,
        "majors.json": validate_major_catalog,
        "stocks.json": validate_stock_catalog,
        "achievements.json": validate_achievement_catalog,
        "names.json": validate_name_catalog,
        "countries.json": validate_country_catalog,
        "gambling_ages.json": validate_gambling_ages,
    }

    def __init__(self, data_dir: str | Path | None = None):
        self.data_dir = Path(data_dir) if data_dir is not None else Path(__file__).parent.parent / "data"
        self._cache: dict[str, tuple[int, Any]] = {}
        self._catalog_snapshot: dict[str, Any] | None = None

    def load_json(self, filename: str, validator: Optional[Validator] = None) -> Any:
        """Read and validate a JSON file; cached copies are returned defensively."""
        if Path(filename).name != filename or not filename.endswith(".json"):
            raise ValueError("Game data filenames must be simple .json filenames")
        path = self.data_dir / filename
        try:
            modified_at = path.stat().st_mtime_ns
        except FileNotFoundError as exc:
            raise FileNotFoundError(f"Required game data file not found: {path}") from exc

        cached = self._cache.get(filename)
        if cached and cached[0] == modified_at:
            return copy.deepcopy(cached[1])

        try:
            with path.open("r", encoding="utf-8") as handle:
                document = json.load(handle)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON in {path} at line {exc.lineno}, column {exc.colno}: {exc.msg}") from exc

        validated = validator(document) if validator is not None else document
        self._cache[filename] = (modified_at, copy.deepcopy(validated))
        return copy.deepcopy(validated)

    def load_events(self) -> dict[str, Any]:
        """Load the validated life-event catalog."""
        return self.load_json("events.json", validate_event_catalog)

    def load_careers(self) -> dict[str, Any]:
        """Load the validated career catalog."""
        return self.load_json("careers.json", validate_career_catalog)

    def load_crimes(self) -> dict[str, Any]:
        """Load the fully validated crime and country-sentencing catalog."""
        return self.load_json("crimes.json", validate_crime_catalog)

    def load_items(self) -> dict[str, Any]:
        """Load the strictly validated Stage 8 shop and inventory catalog."""
        return self.load_json("items.json", validate_item_catalog)

    def load_stocks(self) -> dict[str, Any]:
        """Load the strictly validated Stage 9 global equity and crypto catalog."""
        return self.load_json("stocks.json", validate_stock_catalog)

    def load_achievements(self) -> dict[str, Any]:
        """Load the validated, finite Stage 10 achievement definitions."""
        return self.load_json("achievements.json", validate_achievement_catalog)

    def load_gambling_ages(self) -> dict[str, Any]:
        """Load country minimum ages with a validated age-18 fallback for unknown keys."""
        return self.load_json("gambling_ages.json", validate_gambling_ages)

    def load_diseases(self) -> dict[str, Any]:
        """Load the validated Stage 11 fictional health-condition catalog."""
        return self.load_json("diseases.json", validate_disease_catalog)

    def load_majors(self) -> dict[str, Any]:
        """Load education majors and their validated career mappings."""
        return self.load_json("majors.json", validate_major_catalog)

    def load_countries(self) -> dict[str, Any]:
        """Load display names and supported regions for character generation."""
        return self.load_json("countries.json", validate_country_catalog)

    def load_names(self) -> dict[str, Any]:
        """Load gender-inclusive regional first-name pools."""
        return self.load_json("names.json", validate_name_catalog)

    def load_all(self) -> dict[str, Any]:
        """Validate every required game-data file and atomically publish a deep-copied snapshot.

        Minimum Stage 11 content counts and cross-file references are checked here. If
        any file is missing, malformed, or inconsistent, neither the cache nor the last
        successful snapshot changes.
        """
        return self._read_and_validate_all()

    def reload_all(self) -> dict[str, Any]:
        """Force a complete content reload, retaining the last-good snapshot on failure."""
        return self._read_and_validate_all()

    def _read_and_validate_all(self) -> dict[str, Any]:
        documents: dict[str, Any] = {}
        candidate_cache: dict[str, tuple[int, Any]] = {}
        errors: list[str] = []
        for filename in self.CONTENT_FILES:
            path = self.data_dir / filename
            try:
                modified_at = path.stat().st_mtime_ns
                with path.open("r", encoding="utf-8") as handle:
                    document = json.load(handle)
            except FileNotFoundError:
                errors.append(f"{filename}: required file not found at {path}")
                continue
            except json.JSONDecodeError as exc:
                errors.append(f"{filename}: invalid JSON at line {exc.lineno}, column {exc.colno}: {exc.msg}")
                continue
            documents[filename.removesuffix(".json")] = document
            candidate_cache[filename] = (modified_at, copy.deepcopy(document))
        if errors:
            raise DataValidationError("Content validation failed:\n- " + "\n- ".join(errors))
        validate_catalog_set(documents)
        self._cache = candidate_cache
        self._catalog_snapshot = copy.deepcopy(documents)
        return copy.deepcopy(documents)

    def last_good_snapshot(self) -> dict[str, Any] | None:
        """Return a defensive copy of the most recently validated full catalog set."""
        return copy.deepcopy(self._catalog_snapshot) if self._catalog_snapshot is not None else None
