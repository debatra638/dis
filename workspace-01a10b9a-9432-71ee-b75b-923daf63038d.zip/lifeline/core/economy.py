"""Annual inflation, taxes, banking, loans, credit, housing, and bankruptcy rules."""
from __future__ import annotations

import json
import logging
import math
import time
from dataclasses import dataclass, replace
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_FLOOR
from typing import Any, Callable, Optional

import aiosqlite

from .config import GameBalance
from .data_loader import DataLoader
from .errors import CharacterDead, CharacterNotFound, ConcurrentUpdate, InsufficientFunds, ValidationError
from .locks import UserLockRegistry
from .models import Character, HousingType, Lifestyle, LoanStatus, LoanType
from .money import charge_cents, format_cents, payout_cents, validate_cents
from .repositories.economy import EconomyRepository
from .repositories.legacy import LegacyRepository
from .rng import RNG

logger = logging.getLogger("lifeline.economy")

_WEALTH_COST_MODIFIERS = {"poor": 0.80, "working": 0.90, "middle": 1.00, "upper": 1.20, "rich": 1.50}
_LIFESTYLE_COST_MODIFIERS = {"frugal": 0.75, "normal": 1.00, "lavish": 1.75}
_LOAN_TYPES = {item.value for item in LoanType}


@dataclass(frozen=True, slots=True)
class EconomyYearResult:
    """Updated character and message details for one annual economy settlement."""

    character: Character
    messages: tuple[str, ...] = ()
    living_cost_cents: int = 0
    rent_cents: int = 0
    interest_cents: int = 0
    theft_cents: int = 0
    stock_liquidation_cents: int = 0


@dataclass(frozen=True, slots=True)
class LoanQuote:
    """Server-calculated terms shown before a direct loan application is committed."""

    loan_type: str
    principal_cents: int
    annual_rate: float
    term_years: int
    annual_payment_cents: int
    collateral_item_uid: Optional[int]


@dataclass(frozen=True, slots=True)
class BankruptcyEligibility:
    """Eligibility snapshot separating dischargeable debt from all recorded liabilities."""

    eligible: bool
    reason_code: str
    reason: str
    debt_before_cents: int
    dischargeable_debt_cents: int
    gross_assets_cents: int
    liquid_assets_cents: int
    annual_surplus_cents: int
    repayment_capacity_cents: int
    first_loan_age: Optional[int]


def progressive_income_tax(
    income_cents: int,
    *,
    price_index: float = 1.0,
    tax_mod: float = 1.0,
    joint: bool = False,
) -> int:
    """Calculate progressive income tax with inflation-indexed thresholds and tax modifier."""
    validate_cents(income_cents)
    if income_cents <= 0:
        return 0
    if not math.isfinite(float(price_index)) or price_index <= 0:
        raise ValueError("price index must be finite and positive")
    if not math.isfinite(float(tax_mod)) or tax_mod < 0:
        raise ValueError("tax modifier must be finite and non-negative")
    remaining = int(income_cents)
    lower = 0
    tax_due = Decimal(0)
    joint_multiplier = 2 if joint else 1
    for upper_base, rate in GameBalance.INCOME_TAX_BRACKETS:
        if upper_base is None:
            upper = None
        else:
            upper = int((Decimal(upper_base) * Decimal(str(price_index)) * joint_multiplier).to_integral_value(rounding=ROUND_FLOOR))
        width = remaining if upper is None else max(0, min(remaining, upper - lower))
        if width:
            tax_due += Decimal(width) * Decimal(str(rate)) * Decimal(str(tax_mod))
            remaining -= width
        if remaining <= 0:
            break
        if upper is not None:
            lower = upper
    tax = int(tax_due.to_integral_value(rounding=ROUND_CEILING))
    return min(int(income_cents), max(0, tax))


def capital_gains_tax(gain_cents: int, *, tax_mod: float = 1.0) -> int:
    """Assess the configured realized-gain levy, rounding the charge upward to a cent."""
    validate_cents(gain_cents)
    if gain_cents <= 0:
        return 0
    if not math.isfinite(float(tax_mod)) or tax_mod < 0:
        raise ValueError("tax modifier must be finite and non-negative")
    return min(gain_cents, charge_cents(gain_cents, Decimal(GameBalance.CAPITAL_GAINS_TAX_PERCENT) / 100 * Decimal(str(tax_mod))))


def amortized_annual_payment(principal_cents: int, annual_rate: float, term_years: int) -> int:
    """Return the level annual payment for a fixed-rate amortizing integer-cent loan."""
    validate_cents(principal_cents)
    if principal_cents < 0 or isinstance(term_years, bool) or not isinstance(term_years, int) or term_years <= 0:
        raise ValueError("principal must be non-negative and term must be a positive integer")
    try:
        rate = Decimal(str(annual_rate))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError("annual rate must be finite") from exc
    if not rate.is_finite() or rate < 0 or rate > 2:
        raise ValueError("annual rate must be between zero and two")
    if principal_cents == 0:
        return 0
    if rate == 0:
        return int((Decimal(principal_cents) / term_years).to_integral_value(rounding=ROUND_CEILING))
    factor = (Decimal(1) + rate) ** term_years
    payment = Decimal(principal_cents) * rate * factor / (factor - Decimal(1))
    return int(payment.to_integral_value(rounding=ROUND_CEILING))


def loan_interest_cents(balance_cents: int, annual_rate: float) -> int:
    """Return one year's capitalized loan interest, rounded upward."""
    validate_cents(balance_cents)
    if balance_cents < 0 or not math.isfinite(float(annual_rate)) or not 0 <= annual_rate <= 2:
        raise ValueError("loan balance or annual rate is invalid")
    return charge_cents(balance_cents, Decimal(str(annual_rate)))


def _country_modifiers(document: dict[str, Any], country_id: str) -> tuple[float, float, float]:
    """Read optional per-country tax, cost-of-living, and healthcare modifiers."""
    by_id = {str(row.get("id", "")): row for row in document.get("countries", []) if isinstance(row, dict)}
    row = by_id.get(str(country_id).lower()) or by_id.get(str(document.get("default_country", "usa"))) or {}
    values = (
        float(row.get("tax_mod", 1.0)),
        float(row.get("cost_of_living_mod", 1.0)),
        float(row.get("healthcare_mod", 1.0)),
    )
    tax_mod, cost_mod, healthcare_mod = values
    if (not math.isfinite(tax_mod) or not 0 <= tax_mod <= 5
            or not math.isfinite(cost_mod) or not 0 < cost_mod <= 5
            or not math.isfinite(healthcare_mod) or not 0 <= healthcare_mod <= 5):
        return 1.0, 1.0, 1.0
    return values


class EconomyService:
    """Transactional economic services used by slash commands and the yearly tick."""

    def __init__(
        self,
        db: Any,
        rng: RNG,
        locks: Optional[UserLockRegistry] = None,
        *,
        clock: Callable[[], float] = time.time,
        data_loader: Optional[DataLoader] = None,
    ) -> None:
        self.db = db
        self.rng = rng.fork("lifeline-economy")
        self.locks = locks or UserLockRegistry()
        self.clock = clock
        self.repository = EconomyRepository(db)
        self.legacy_repository = LegacyRepository(db)
        self.data_loader = data_loader or DataLoader()
        self.countries = self.data_loader.load_countries()
        self.items = {str(item["id"]): dict(item) for item in self.data_loader.load_items()["items"]}

    def country_modifiers(self, country_id: str) -> tuple[float, float, float]:
        """Return ``(tax_mod, cost_of_living_mod, healthcare_mod)`` for a country code."""
        return _country_modifiers(self.countries, country_id)

    @staticmethod
    def _validate_amount(amount: int) -> int:
        """Reject booleans, negatives, and non-integer currency values."""
        value = validate_cents(amount)
        if value < 0:
            raise ValidationError("Money amounts must be non-negative.")
        return value

    async def _load_active(self, tx: aiosqlite.Connection, user_id: int) -> tuple[Character, int]:
        """Load the active character or raise a safe missing/dead-life error."""
        row = await self.repository.active_character(tx, user_id)
        if row is None:
            if await self.repository.has_any_life(tx, user_id):
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.char_id = int(row["char_id"])
        character.user_id = int(row["user_id"])
        character.version = int(row["version"])
        return character, int(row["version"])

    async def _save(self, tx: aiosqlite.Connection, character: Character, version: int) -> Character:
        """Save one command mutation and return the incremented authoritative snapshot."""
        updated = replace(character, version=version + 1)
        await self.repository.save_character(tx, updated, version)
        return updated

    async def bank_transfer(self, user_id: int, direction: str, amount_cents: Optional[int]) -> tuple[Character, int]:
        """Move integer cents between cash and bank without allowing an overdraft."""
        selected = str(direction).strip().lower()
        if selected not in {"deposit", "withdraw"}:
            raise ValidationError("Choose deposit or withdraw.")
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._load_active(tx, user_id)
                available = character.cash if selected == "deposit" else character.bank
                amount = available if amount_cents is None else self._validate_amount(amount_cents)
                if amount <= 0:
                    raise ValidationError("Enter a positive amount or `all`.")
                if amount > available:
                    account = "cash" if selected == "deposit" else "bank"
                    raise InsufficientFunds(f"Your {account} balance is only {format_cents(available)}.")
                if selected == "deposit":
                    updated = replace(character, cash=character.cash - amount, bank=character.bank + amount)
                else:
                    updated = replace(character, cash=character.cash + amount, bank=character.bank - amount)
                updated = await self._save(tx, updated, version)
                await self.repository.write_audit(
                    tx, now=now, user_id=user_id, char_id=character.char_id,
                    action=f"bank_{selected}", amount=amount, details={"amount_cents": amount},
                )
                return updated, amount

    async def set_lifestyle(self, user_id: int, lifestyle: str | Lifestyle) -> Character:
        """Set a validated household lifestyle for future annual bills and health effects."""
        try:
            selected = lifestyle if isinstance(lifestyle, Lifestyle) else Lifestyle(str(lifestyle).lower())
        except ValueError as exc:
            raise ValidationError("Choose frugal, normal, or lavish.") from exc
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._load_active(tx, user_id)
                updated = await self._save(tx, replace(character, lifestyle=selected), version)
                return updated

    async def set_housing(
        self,
        user_id: int,
        mode: str,
        annual_rent_cents: Optional[int] = None,
    ) -> Character:
        """Move in with family or rent; purchased homes remain managed through /shop."""
        selected = str(mode).strip().lower()
        if selected not in {"parents", "rent"}:
            raise ValidationError("Choose parents or rent. Owned homes are managed through `/shop`.")
        if annual_rent_cents is not None:
            rent = self._validate_amount(annual_rent_cents)
            if rent < 100_000 or rent > 100_000_000:
                raise ValidationError("Annual rent must be between $1,000 and $1,000,000.")
        else:
            rent = GameBalance.BASE_ANNUAL_RENT_CENTS
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._load_active(tx, user_id)
                if character.in_prison:
                    raise ValidationError("Housing cannot be changed while imprisoned.")
                if selected == "rent" and character.age < 18:
                    raise ValidationError("You must be an adult to sign a rental agreement.")
                if selected == "parents":
                    updated = replace(character, housing_type=HousingType.PARENTS, housing_item_id=None, rent_amount=0)
                else:
                    updated = replace(character, housing_type=HousingType.RENT, housing_item_id=None, rent_amount=rent)
                return await self._save(tx, updated, version)

    async def loan_status(self, user_id: int) -> tuple[Character, list[dict[str, Any]], list[dict[str, Any]]]:
        """Return the active character, all loans, and recent open/closed collections."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._load_active(tx, user_id)
                return (
                    character,
                    await self.repository.loan_rows(tx, character.char_id),
                    await self.repository.collection_rows(tx, character.char_id),
                )

    async def apply_for_loan(
        self,
        user_id: int,
        loan_type: str | LoanType,
        principal_cents: int,
        *,
        collateral_item_uid: Optional[int] = None,
    ) -> tuple[LoanQuote, Character, int]:
        """Underwrite and create one of six fixed-rate loans, optionally secured by an asset."""
        kind = loan_type.value if isinstance(loan_type, LoanType) else str(loan_type).strip().lower()
        if kind not in _LOAN_TYPES:
            raise ValidationError("Choose personal, student, mortgage, auto, payday, or loan_shark.")
        amount = self._validate_amount(principal_cents)
        if amount <= 0:
            raise ValidationError("Loan principal must be greater than zero.")
        terms = GameBalance.LOAN_TERMS[kind]
        if amount > int(terms["max_cents"]):
            raise ValidationError(f"The maximum {kind.replace('_', ' ')} loan is {format_cents(int(terms['max_cents']))}.")
        age = int(self.clock())
        now = age
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._load_active(tx, user_id)
                now = int(self.clock())
                if character.in_prison:
                    raise ValidationError("You cannot apply for credit while in prison.")
                minimum_age = 16 if kind == "student" else 18
                if character.age < minimum_age:
                    raise ValidationError(f"You must be at least {minimum_age} to apply for this loan.")
                if character.bankrupt_until_age is not None and character.age < character.bankrupt_until_age:
                    raise ValidationError("Your credit is in a bankruptcy rebuilding period; new loans are unavailable.")
                if await self.repository.has_delinquent_loan(tx, character.char_id):
                    raise ValidationError("Resolve defaulted or seriously delinquent loans before borrowing again.")
                credit = int(character.stats.credit_score or GameBalance.CREDIT_SCORE_START)
                minimum_credit = int(terms["min_credit"])
                if credit < minimum_credit:
                    raise ValidationError(f"This loan requires a credit score of at least {minimum_credit}.")
                collateral_id: Optional[int] = None
                if kind in {"mortgage", "auto"}:
                    if collateral_item_uid is None:
                        raise ValidationError("Mortgage and auto loans require an owned property or vehicle as collateral.")
                    asset = await self.repository.collateral_asset(tx, int(collateral_item_uid))
                    item = self.items.get(str(asset["item_id"])) if asset is not None else None
                    allowed_category = "housing" if kind == "mortgage" else "vehicle"
                    if (
                        asset is None or int(asset["char_id"]) != character.char_id or bool(asset["is_liquidated"])
                        or int(asset["quantity"]) <= 0 or item is None or item["category"] != allowed_category
                    ):
                        raise ValidationError("That collateral is not an eligible asset owned by your active life.")
                    pledged = await self.repository.loan_rows(tx, character.char_id, active_only=True)
                    if any(int(row["collateral_item_uid"] or 0) == int(collateral_item_uid) for row in pledged):
                        raise ValidationError("That asset is already pledged as loan collateral.")
                    if amount > int(asset["current_value"]):
                        raise ValidationError("Loan principal cannot exceed the collateral's current value.")
                    collateral_id = int(collateral_item_uid)
                annual_income = await self.repository.annual_income(tx, character.char_id)
                active_loans = await self.repository.loan_rows(tx, character.char_id, active_only=True)
                existing_payment = sum(int(row["annual_payment"]) for row in active_loans)
                annual_rate = float(terms["annual_rate"])
                term_years = int(terms["term_years"])
                annual_payment = amortized_annual_payment(amount, annual_rate, term_years)
                if kind in {"personal", "auto", "mortgage"}:
                    if annual_income <= 0:
                        raise ValidationError("A documented annual salary is required for this conventional loan.")
                    payment_limit = annual_income * (35 if kind == "mortgage" else 45) // 100
                    if existing_payment + annual_payment > payment_limit:
                        raise ValidationError("The scheduled loan payments exceed the income-based credit limit.")
                elif kind == "student" and character.age > 30:
                    raise ValidationError("Student loans are available only through age 30.")
                grace_until = character.age + 4 if kind == "student" else 0
                loan_id = await self.repository.create_loan(
                    tx,
                    char_id=character.char_id,
                    loan_type=kind,
                    principal=amount,
                    annual_rate=annual_rate,
                    term_years=term_years,
                    annual_payment=annual_payment,
                    age=character.age,
                    collateral_item_uid=collateral_id,
                    grace_until_age=grace_until,
                )
                stats = replace(character.stats, credit_score=max(GameBalance.CREDIT_SCORE_MIN, credit - 3))
                updated = replace(character, bank=validate_cents(character.bank + amount),
                                  debt_total=validate_cents(character.debt_total + amount), stats=stats)
                updated = await self._save(tx, updated, version)
                await self.repository.write_audit(
                    tx, now=now, user_id=user_id, char_id=character.char_id,
                    action="loan_originated", amount=amount,
                    details={"loan_id": loan_id, "loan_type": kind, "annual_rate": annual_rate,
                             "term_years": term_years, "annual_payment_cents": annual_payment,
                             "collateral_item_uid": collateral_id},
                )
                quote = LoanQuote(kind, amount, annual_rate, term_years, annual_payment, collateral_id)
                return quote, updated, loan_id

    async def pay_loan(self, user_id: int, loan_id: int, amount_cents: Optional[int]) -> tuple[Character, int, int]:
        """Make an optional early loan payment using bank then cash and return remaining balance."""
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._load_active(tx, user_id)
                loan = await self.repository.loan_row(tx, int(loan_id), character.char_id)
                if loan is None or str(loan["status"]) != LoanStatus.ACTIVE.value:
                    raise ValidationError("That active loan does not belong to your current life.")
                balance = int(loan["balance"])
                amount = balance if amount_cents is None else min(balance, self._validate_amount(amount_cents))
                if amount <= 0:
                    raise ValidationError("Enter a positive payment or `all`.")
                if character.cash + character.bank < amount:
                    raise InsufficientFunds("Your cash and bank balances are not enough for that payment.")
                updated = self._deduct_bank_then_cash(character, amount)
                remaining = await self.repository.pay_loan(
                    tx, loan_id=int(loan_id), payment=amount, age=character.age, count_year=False
                )
                stats = replace(updated.stats, credit_score=min(GameBalance.CREDIT_SCORE_MAX,
                                                                 int(updated.stats.credit_score or GameBalance.CREDIT_SCORE_START) + 2))
                updated = replace(updated, stats=stats, debt_total=max(0, updated.debt_total - amount))
                updated = await self._save(tx, updated, version)
                await self.repository.write_audit(
                    tx, now=now, user_id=user_id, char_id=character.char_id,
                    action="loan_payment", amount=amount,
                    details={"loan_id": int(loan_id), "remaining_balance_cents": remaining},
                )
                return updated, amount, remaining

    async def bankruptcy_eligibility(self, user_id: int) -> BankruptcyEligibility:
        """Return whether filing would discharge meaningful debt for the active life."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._load_active(tx, user_id)
                return await self._bankruptcy_eligibility(tx, character)

    async def _bankruptcy_eligibility(
        self,
        tx: aiosqlite.Connection,
        character: Character,
    ) -> BankruptcyEligibility:
        """Assess filing conditions using liabilities that bankruptcy can actually discharge."""
        snapshot = await self.legacy_repository.economy_snapshot(tx, character.char_id)
        debt_facts = await self.repository.bankruptcy_debt_facts(tx, character.char_id)
        dischargeable = (
            int(debt_facts["dischargeable_loan_cents"] or 0)
            + int(debt_facts["standalone_collection_cents"] or 0)
        )
        debt_before = max(
            0,
            int(snapshot["debts_cents"]),
            int(character.debt_total),
        )
        gross_assets = max(0, int(snapshot["gross_assets_cents"]))
        liquid_assets = max(0, int(character.cash)) + max(0, int(character.bank))
        first_loan_age = debt_facts["first_loan_age"]
        annual_salary = await self.repository.annual_income(tx, character.char_id)
        tax_mod, cost_mod, _ = self.country_modifiers(character.country)
        annual_tax = (
            progressive_income_tax(
                annual_salary,
                price_index=character.price_index,
                tax_mod=tax_mod,
            )
            if character.age >= 18 else 0
        )
        annual_living = charge_cents(
            GameBalance.BASE_ANNUAL_LIVING_COST_CENTS,
            Decimal(str(character.price_index))
            * Decimal(str(cost_mod))
            * Decimal(str(_WEALTH_COST_MODIFIERS.get(character.wealth_class.lower(), 1.0)))
            * Decimal(str(_LIFESTYLE_COST_MODIFIERS[character.lifestyle.value])),
        )
        annual_housing = 0
        if character.housing_type is HousingType.RENT:
            annual_housing = charge_cents(
                character.rent_amount or GameBalance.BASE_ANNUAL_RENT_CENTS,
                Decimal(str(character.price_index)) * Decimal(str(cost_mod)),
            )
        elif character.housing_type is HousingType.HOMELESS:
            annual_housing = charge_cents(
                GameBalance.HOMELESS_SHELTER_COST_CENTS,
                Decimal(str(character.price_index)) * Decimal(str(cost_mod)),
            )
        annual_surplus = max(0, annual_salary - annual_tax - annual_living - annual_housing)
        repayment_capacity = (
            liquid_assets
            + annual_surplus * GameBalance.BANKRUPTCY_REPAYMENT_HORIZON_YEARS
        )
        reason_code = "eligible"
        reason = "Filing would discharge eligible unsecured debt."

        if character.age < 18:
            reason_code, reason = "underage", "Bankruptcy is available only to adults."
        elif character.in_prison:
            reason_code, reason = "imprisoned", "Bankruptcy cannot be filed while imprisoned."
        elif (
            character.last_bankruptcy_age is not None
            and character.age - character.last_bankruptcy_age < GameBalance.BANKRUPTCY_COOLDOWN_YEARS
        ):
            remaining = GameBalance.BANKRUPTCY_COOLDOWN_YEARS - (
                character.age - character.last_bankruptcy_age
            )
            reason_code = "cooldown"
            reason = f"You must wait {remaining} more in-game year(s) before filing again."
        elif dischargeable <= 0:
            reason_code, reason = "no_dischargeable_debt", "There is no dischargeable debt to clear."
        elif dischargeable < GameBalance.BANKRUPTCY_MIN_DISCHARGEABLE_DEBT_CENTS:
            reason_code = "dischargeable_debt_below_minimum"
            reason = "Dischargeable debt is below the minimum balance for a filing."
        elif Decimal(dischargeable) <= (
            Decimal(str(GameBalance.BANKRUPTCY_DISCHARGEABLE_DEBT_ASSET_MULTIPLE))
            * Decimal(gross_assets)
        ):
            reason_code = "debt_not_over_asset_multiple"
            multiple = GameBalance.BANKRUPTCY_DISCHARGEABLE_DEBT_ASSET_MULTIPLE
            reason = f"Dischargeable debt must exceed {multiple:g} times gross assets."
        elif liquid_assets >= dischargeable:
            reason_code = "liquid_assets_can_pay"
            reason = "Available cash and bank savings are enough to pay the dischargeable debt."
        elif repayment_capacity >= dischargeable:
            reason_code = "income_can_repay"
            horizon = GameBalance.BANKRUPTCY_REPAYMENT_HORIZON_YEARS
            reason = f"Current liquid funds and {horizon} years of after-tax surplus can pay the dischargeable debt."
        elif (
            first_loan_age is not None
            and character.age - int(first_loan_age) < GameBalance.BANKRUPTCY_MIN_FIRST_LOAN_AGE_YEARS
        ):
            reason_code = "first_loan_too_young"
            age_required = GameBalance.BANKRUPTCY_MIN_FIRST_LOAN_AGE_YEARS
            reason = f"The first loan must be at least {age_required} in-game years old before filing."

        return BankruptcyEligibility(
            eligible=reason_code == "eligible",
            reason_code=reason_code,
            reason=reason,
            debt_before_cents=debt_before,
            dischargeable_debt_cents=dischargeable,
            gross_assets_cents=gross_assets,
            liquid_assets_cents=liquid_assets,
            annual_surplus_cents=annual_surplus,
            repayment_capacity_cents=repayment_capacity,
            first_loan_age=(int(first_loan_age) if first_loan_age is not None else None),
        )

    async def file_bankruptcy(self, user_id: int) -> tuple[Character, int, int]:
        """Discharge meaningful unsecured debt once per ten years and reset credit safely."""
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._load_active(tx, user_id)
                eligibility = await self._bankruptcy_eligibility(tx, character)
                if not eligibility.eligible:
                    raise ValidationError(eligibility.reason)
                debt_before = eligibility.debt_before_cents
                assets_before = eligibility.gross_assets_cents
                eligible_types = {LoanType.PERSONAL.value, LoanType.PAYDAY.value, LoanType.LOAN_SHARK.value}
                discharged = 0
                for loan in await self.repository.loan_rows(tx, character.char_id, active_only=False):
                    if (str(loan["loan_type"]) in eligible_types
                            and str(loan["status"]) in {LoanStatus.ACTIVE.value, LoanStatus.DEFAULTED.value}):
                        loan_id = int(loan["loan_id"])
                        discharged += await self.repository.discharge_loan(tx, loan_id)
                        await self.repository.discharge_collections_for_loan(tx, loan_id, now)
                discharged += await self.repository.discharge_open_collections(tx, character.char_id, now)
                # Student loans and secured mortgages/autos survive discharge by design.
                updated_debt = max(0, int(character.debt_total) - discharged)
                stats = replace(character.stats, credit_score=GameBalance.CREDIT_SCORE_MIN)
                updated = replace(
                    character,
                    debt_total=updated_debt,
                    bankrupt_until_age=character.age + GameBalance.BANKRUPTCY_REBUILD_YEARS,
                    last_bankruptcy_age=character.age,
                    stats=stats,
                )
                await self.repository.insert_bankruptcy(
                    tx, char_id=character.char_id, age=character.age, debt_before=debt_before,
                    assets_before=assets_before, discharged=discharged, now=now,
                )
                updated = await self._save(tx, updated, version)
                await self.repository.write_audit(
                    tx, now=now, user_id=user_id, char_id=character.char_id,
                    action="bankruptcy_filed", amount=discharged,
                    details={"debt_before_cents": debt_before, "assets_before_cents": assets_before,
                             "discharged_cents": discharged, "credit_score": GameBalance.CREDIT_SCORE_MIN},
                )
                return updated, debt_before, discharged

    async def advance_year(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        previous_age: int,
        now: int,
    ) -> EconomyYearResult:
        """Settle bills, loan payments, interest, theft, credit, and inflation once per year."""
        if not character.is_alive:
            return EconomyYearResult(character)
        if await self.repository.is_year_settled(tx, character.char_id, previous_age):
            return EconomyYearResult(character)
        updated = character
        messages: list[str] = []
        living_cost = 0
        rent = 0
        theft = 0
        interest = 0
        liquidated = 0
        tax_mod, cost_mod, healthcare_mod = self.country_modifiers(updated.country)

        was_in_prison = bool(character.in_prison)
        if updated.age >= 18:
            if not was_in_prison:
                lifestyle_mod = _LIFESTYLE_COST_MODIFIERS[updated.lifestyle.value]
                wealth_mod = _WEALTH_COST_MODIFIERS.get(updated.wealth_class.lower(), 1.0)
                living_cost = charge_cents(
                    GameBalance.BASE_ANNUAL_LIVING_COST_CENTS,
                    Decimal(str(updated.price_index)) * Decimal(str(cost_mod)) * Decimal(str(wealth_mod))
                    * Decimal(str(lifestyle_mod)),
                )
                if updated.housing_type is HousingType.RENT:
                    raw_rent = updated.rent_amount or GameBalance.BASE_ANNUAL_RENT_CENTS
                    rent = charge_cents(raw_rent, Decimal(str(updated.price_index)) * Decimal(str(cost_mod)))
                elif updated.housing_type is HousingType.HOMELESS:
                    rent = charge_cents(GameBalance.HOMELESS_SHELTER_COST_CENTS,
                                        Decimal(str(updated.price_index)) * Decimal(str(cost_mod)))
                updated, living_shortfall, proceeds = await self._settle_bill(
                    tx, updated, living_cost, source="living_expense", age=previous_age, now=now
                )
                liquidated += proceeds
                if living_shortfall:
                    updated = replace(updated, debt_total=validate_cents(updated.debt_total + living_shortfall))
                    await self.repository.add_collection(
                        tx, char_id=updated.char_id, source="living_expense", balance=living_shortfall,
                        age=previous_age, now=now,
                    )
                    messages.append(f"Unpaid living bills of {format_cents(living_shortfall)} went to collections.")
                if rent:
                    updated, rent_shortfall, proceeds = await self._settle_bill(
                        tx, updated, rent, source="rent", age=previous_age, now=now
                    )
                    liquidated += proceeds
                    if rent_shortfall:
                        updated = replace(
                            updated,
                            debt_total=validate_cents(updated.debt_total + rent_shortfall),
                            housing_type=HousingType.HOMELESS,
                            housing_item_id=None,
                            rent_amount=0,
                        )
                        await self.repository.add_collection(
                            tx, char_id=updated.char_id, source="rent", balance=rent_shortfall,
                            age=previous_age, now=now,
                        )
                        messages.append("Rent remained unpaid after the payment cascade; eviction placed you in temporary housing and collections began.")
                    else:
                        messages.append(f"Annual rent and housing cost: {format_cents(rent)}.")
                insurance_due = (
                    updated.has_insurance
                    and (updated.insurance_paid_through_age is None
                         or updated.age > updated.insurance_paid_through_age)
                )
                if insurance_due:
                    insurance = charge_cents(
                        GameBalance.ANNUAL_HEALTH_INSURANCE_PREMIUM_CENTS,
                        Decimal(str(updated.price_index)) * Decimal(str(healthcare_mod)),
                    )
                    updated, insurance_shortfall, proceeds = await self._settle_bill(
                        tx, updated, insurance, source="living_expense", age=previous_age, now=now
                    )
                    liquidated += proceeds
                    if insurance_shortfall:
                        updated = replace(updated, debt_total=validate_cents(updated.debt_total + insurance_shortfall),
                                          has_insurance=False)
                        await self.repository.add_collection(
                            tx, char_id=updated.char_id, source="living_expense", balance=insurance_shortfall,
                            age=previous_age, now=now,
                        )
                        messages.append("The insurance renewal premium was unpaid; it went to collections and coverage ended.")
                    else:
                        updated = replace(updated, insurance_paid_through_age=updated.age)
                        messages.append(f"Insurance renewed through age {updated.age} for {format_cents(insurance)}.")
                messages.append(f"Annual living expenses: {format_cents(living_cost)}.")

            # Collections recover up to one fifth of available balances after mandatory bills.
            if not was_in_prison:
                open_collections = [
                    row for row in await self.repository.collection_rows(tx, updated.char_id)
                    if str(row["status"]) == "open"
                ]
                collection_balance = sum(int(row["balance_cents"]) for row in open_collections)
                recovery_budget = min(collection_balance, (updated.cash + updated.bank) // 5)
                recovery_remaining = recovery_budget
                for row in reversed(open_collections):
                    if recovery_remaining <= 0:
                        break
                    due_collection = int(row["balance_cents"])
                    payment = min(due_collection, recovery_remaining)
                    await self.repository.pay_collection(tx, int(row["collection_id"]), payment, now)
                    recovery_remaining -= payment
                recovered = recovery_budget - recovery_remaining
                if recovered:
                    updated = self._deduct_bank_then_cash(updated, recovered)
                    updated = replace(updated, debt_total=max(0, updated.debt_total - recovered))
                    messages.append(f"Collections recovered {format_cents(recovered)} from available funds.")

            # Required-payment loans are last in the cascade, after bills and forced stock sales.
            for loan in await self.repository.loan_rows(tx, updated.char_id, active_only=True):
                if previous_age + 1 < int(loan["grace_until_age"]):
                    continue
                interest_due = loan_interest_cents(int(loan["balance"]), float(loan["annual_rate"]))
                if interest_due:
                    await self.repository.add_loan_interest(tx, int(loan["loan_id"]), interest_due)
                    updated = replace(updated, debt_total=validate_cents(updated.debt_total + interest_due))
                due = min(int(loan["annual_payment"]), int(loan["balance"]) + interest_due)
                if due <= 0:
                    continue
                if updated.cash + updated.bank < due:
                    proceeds = await self._liquidate_stocks(
                        tx, updated, due - updated.cash - updated.bank, age=previous_age, now=now
                    )
                    if proceeds:
                        updated = replace(updated, bank=validate_cents(updated.bank + proceeds))
                        liquidated += proceeds
                if updated.cash + updated.bank >= due:
                    updated = self._deduct_bank_then_cash(updated, due)
                    balance = await self.repository.pay_loan(
                        tx, loan_id=int(loan["loan_id"]), payment=due,
                        age=previous_age + 1, count_year=True,
                    )
                    updated = replace(updated, debt_total=max(0, updated.debt_total - due))
                    stats = replace(updated.stats, credit_score=min(
                        GameBalance.CREDIT_SCORE_MAX,
                        int(updated.stats.credit_score or GameBalance.CREDIT_SCORE_START) + 5,
                    ))
                    updated = replace(updated, stats=stats)
                    messages.append(f"Loan #{loan['loan_id']} payment of {format_cents(due)} cleared; balance {format_cents(balance)}.")
                else:
                    misses = await self.repository.miss_loan_payment(tx, int(loan["loan_id"]))
                    stats = replace(updated.stats, credit_score=max(
                        GameBalance.CREDIT_SCORE_MIN,
                        int(updated.stats.credit_score or GameBalance.CREDIT_SCORE_START) - 20,
                    ))
                    updated = replace(updated, stats=stats)
                    messages.append(f"Loan #{loan['loan_id']} payment was missed ({misses} consecutive).")
                    if misses >= GameBalance.LOAN_DEFAULT_AFTER_MISSES:
                        await self.repository.mark_loan_defaulted(tx, int(loan["loan_id"]), previous_age + 1)
                        collateral_id = loan.get("collateral_item_uid")
                        recovery = 0
                        if collateral_id is not None:
                            asset = await self.repository.repossess_asset(tx, int(collateral_id))
                            if asset is not None:
                                recovery = min(int(asset["current_value"]), int(loan["balance"]) + interest_due)
                                remaining_loan = max(0, int(loan["balance"]) + interest_due - recovery)
                                await self.repository.set_defaulted_balance(
                                    tx, int(loan["loan_id"]), remaining_loan
                                )
                                updated = replace(updated, debt_total=max(0, updated.debt_total - recovery))
                                if updated.housing_item_id == int(collateral_id):
                                    updated = replace(
                                        updated, housing_item_id=None,
                                        housing_type=(HousingType.RENT if updated.age >= 18 else HousingType.PARENTS),
                                        rent_amount=(GameBalance.BASE_ANNUAL_RENT_CENTS if updated.age >= 18 else 0),
                                    )
                                messages.append(f"Loan default triggered repossession; {format_cents(recovery)} of collateral value was applied.")
                                if remaining_loan:
                                    await self.repository.add_collection(
                                        tx, char_id=updated.char_id, source="loan_deficiency",
                                        balance=remaining_loan, age=previous_age + 1, now=now,
                                        loan_id=int(loan["loan_id"]),
                                    )
                        else:
                            await self.repository.add_collection(
                                tx, char_id=updated.char_id, source="loan_deficiency",
                                balance=int(loan["balance"]) + interest_due,
                                age=previous_age + 1, now=now,
                                loan_id=int(loan["loan_id"]),
                            )
                        messages.append(f"Loan #{loan['loan_id']} defaulted after repeated missed payments.")

        interest = payout_cents(updated.bank, GameBalance.BANK_INTEREST_RATE)
        if interest:
            updated = replace(updated, bank=validate_cents(updated.bank + interest))
            messages.append(f"Bank interest added {format_cents(interest)} to savings.")
        if updated.bank > 0 and self.rng.random() < GameBalance.BANK_THEFT_ANNUAL_CHANCE:
            fraction = self.rng.uniform(GameBalance.BANK_THEFT_MIN_FRACTION, GameBalance.BANK_THEFT_MAX_FRACTION)
            theft = min(updated.bank, charge_cents(updated.bank, fraction))
            updated = replace(updated, bank=updated.bank - theft)
            messages.append(f"A bank-account theft removed {format_cents(theft)} from savings.")

        if updated.stats.credit_score is None and updated.age >= 18:
            updated = replace(updated, stats=replace(updated.stats, credit_score=GameBalance.CREDIT_SCORE_START))
        if updated.bankrupt_until_age is not None and updated.age >= updated.bankrupt_until_age:
            updated = replace(updated, bankrupt_until_age=None)

        annual_inflation = min(
            GameBalance.ANNUAL_INFLATION_MAX,
            max(
                GameBalance.ANNUAL_INFLATION_MIN,
                self.rng.gauss(
                    GameBalance.ANNUAL_INFLATION_MEAN,
                    GameBalance.ANNUAL_INFLATION_STDDEV,
                ),
            ),
        )
        next_index = min(
            GameBalance.INFLATION_INDEX_CAP,
            max(0.1, float(updated.price_index) * (1.0 + annual_inflation)),
        )
        updated = replace(updated, price_index=next_index)
        await self.repository.save_year_settlement(
            tx, char_id=updated.char_id, age=previous_age, income_tax=0,
            living_cost=living_cost, rent=rent, interest=interest, theft=theft,
            stock_liquidation=liquidated, now=now,
        )
        return EconomyYearResult(
            updated, tuple(messages), living_cost, rent, interest, theft, liquidated
        )

    async def _settle_bill(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        amount: int,
        *,
        source: str,
        age: int,
        now: int,
    ) -> tuple[Character, int, int]:
        """Pay a mandatory bill bank-first, cash-second, then liquidate low-value shares."""
        if amount <= 0:
            return character, 0, 0
        updated = character
        remaining = amount
        bank_paid = min(updated.bank, remaining)
        updated = replace(updated, bank=updated.bank - bank_paid)
        remaining -= bank_paid
        cash_paid = min(updated.cash, remaining)
        updated = replace(updated, cash=updated.cash - cash_paid)
        remaining -= cash_paid
        proceeds = 0
        if remaining:
            proceeds = await self._liquidate_stocks(tx, updated, remaining, age=age, now=now)
            if proceeds:
                updated = replace(updated, bank=validate_cents(updated.bank + proceeds))
                bank_paid = min(updated.bank, remaining)
                updated = replace(updated, bank=updated.bank - bank_paid)
                remaining -= bank_paid
                cash_paid = min(updated.cash, remaining)
                updated = replace(updated, cash=updated.cash - cash_paid)
                remaining -= cash_paid
        return updated, remaining, proceeds

    async def _liquidate_stocks(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        needed_cents: int,
        *,
        age: int,
        now: int,
    ) -> int:
        """Sell the lowest-priced tradable stock positions until a target is raised."""
        remaining = max(0, int(needed_cents))
        proceeds_total = 0
        fee_percent = GameBalance.FORCED_STOCK_SALE_FEE_PERCENT
        for holding in await self.repository.stock_holdings_low_to_high(tx, character.char_id):
            if remaining <= 0:
                break
            shares = int(holding["shares"])
            price = int(holding["price_cents"])
            if shares <= 0 or price <= 0:
                continue
            conservative_net_per_share = max(1, price * (100 - fee_percent) // 100)
            quantity = min(shares, max(1, (remaining + conservative_net_per_share - 1) // conservative_net_per_share))
            gross = price * quantity
            fee = max(100, (gross * fee_percent + 99) // 100)
            if fee >= gross:
                # A minimum brokerage charge must not create debt through a forced sale.
                continue
            net = gross - fee
            if net < remaining and quantity < shares:
                quantity += 1
                gross = price * quantity
                fee = max(100, (gross * fee_percent + 99) // 100)
                if fee >= gross:
                    continue
                net = gross - fee
            basis = await self.repository.update_holding_after_liquidation(
                tx, char_id=character.char_id, symbol=str(holding["symbol"]),
                old_shares=shares, old_basis=int(holding["cost_basis_cents"]),
                sold_shares=quantity, now=now,
            )
            realized = gross - fee - basis
            await self.repository.record_forced_stock_sale(
                tx, char_id=character.char_id, symbol=str(holding["symbol"]),
                shares=quantity, price=price, gross=gross, fee=fee,
                realized_gain=realized, age=age, now=now,
            )
            proceeds_total = validate_cents(proceeds_total + net)
            remaining -= net
        return proceeds_total

    @staticmethod
    def _deduct_bank_then_cash(character: Character, amount: int) -> Character:
        """Return a character after consuming bank balance first, then cash."""
        if amount < 0 or character.cash + character.bank < amount:
            raise InsufficientFunds("Available cash and savings are not enough for that payment.")
        bank_paid = min(character.bank, amount)
        remainder = amount - bank_paid
        return replace(character, bank=character.bank - bank_paid, cash=character.cash - remainder)
