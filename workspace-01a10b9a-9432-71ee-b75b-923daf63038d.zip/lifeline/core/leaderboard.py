"""Privacy-aware, deterministic Stage 10 leaderboards with a short cache."""
from __future__ import annotations

import copy
import json
import time
from dataclasses import dataclass
from typing import Any, Callable, Optional

from .achievements import AchievementService
from .death import calculate_life_score
from .errors import ValidationError
from .locks import UserLockRegistry
from .models import Character
from .repositories.legacy import LegacyRepository

METRICS: dict[str, str] = {
    "net_worth": "Net Worth",
    "life_score": "Life Score",
    "age": "Age",
    "fame": "Fame",
    "lives": "Lives",
    "gambling": "Total Wagered",
    "crime": "Successful Crimes",
}
SCOPES = {"server", "global"}
PERIODS = {"current", "all_time"}


@dataclass(frozen=True, slots=True)
class LeaderboardResult:
    """One ranked and privacy-filtered leaderboard snapshot."""

    metric: str
    scope: str
    period: str
    guild_id: Optional[int]
    entries: tuple[dict[str, Any], ...]
    created_at: float
    expires_at: float


class LeaderboardService:
    """Build owner-independent rankings with deterministic ties and a 60-second cache."""

    def __init__(
        self,
        db: Any,
        achievements: AchievementService,
        locks: Optional[UserLockRegistry] = None,
        *,
        clock: Callable[[], float] = time.monotonic,
        cache_seconds: int = 60,
    ) -> None:
        self.db = db
        self.achievements = achievements
        self.locks = locks or UserLockRegistry()
        self.clock = clock
        self.cache_seconds = int(cache_seconds)
        self.repository = LegacyRepository(db)
        self._cache: dict[tuple[Optional[int], str, str, str], tuple[float, tuple[dict[str, Any], ...]]] = {}

    async def get_leaderboard(
        self,
        actor_id: int,
        *,
        metric: str,
        scope: str = "server",
        period: str = "current",
        guild_id: Optional[int] = None,
    ) -> LeaderboardResult:
        """Return a cached or freshly computed ranking for one public scope."""
        if isinstance(actor_id, bool) or not isinstance(actor_id, int) or actor_id <= 0:
            raise ValidationError("A valid Discord account is required.")
        if metric not in METRICS:
            raise ValidationError("Choose a supported leaderboard category.")
        if scope not in SCOPES:
            raise ValidationError("Leaderboard scope must be server or global.")
        if period not in PERIODS:
            raise ValidationError("Leaderboard period must be current or all_time.")
        if scope == "server" and (guild_id is None or guild_id <= 0):
            raise ValidationError("Server leaderboards are only available inside a server.")
        key = (guild_id if scope == "server" else None, metric, scope, period)
        timestamp = float(self.clock())
        cached = self._cache.get(key)
        if cached is not None and timestamp < cached[0]:
            expires_at, entries = cached
            return LeaderboardResult(
                metric, scope, period, guild_id if scope == "server" else None,
                copy.deepcopy(entries), expires_at - self.cache_seconds, expires_at,
            )
        async with self.locks.hold(actor_id):
            async with self.db.transaction() as tx:
                if scope == "server":
                    await self.repository.record_guild_seen(tx, int(guild_id), actor_id, int(time.time()))
                users = await self.repository.leaderboard_players(tx)
                visible_ids = {int(row["user_id"]) for row in users}
                if scope == "server":
                    seen_ids = set(await self.repository.seen_guild_users(tx, int(guild_id)))
                    visible_ids.intersection_update(seen_ids)
                active_rows = await self.repository.leaderboard_characters(tx)
                active_by_user = {
                    int(row["user_id"]): row for row in active_rows
                    if int(row["user_id"]) in visible_ids
                }
                past_rows = await self.repository.leaderboard_past_lives(tx)
                past_by_user: dict[int, list[dict[str, Any]]] = {}
                for row in past_rows:
                    user_id = int(row["user_id"])
                    if user_id in visible_ids:
                        past_by_user.setdefault(user_id, []).append(dict(row))
                player_by_id = {int(row["user_id"]): dict(row) for row in users}
                result: list[dict[str, Any]] = []
                for user_id in sorted(visible_ids):
                    active_row = active_by_user.get(user_id)
                    past = past_by_user.get(user_id, [])
                    current = await self._current_facts(tx, active_row) if active_row is not None else None
                    if period == "current":
                        if current is None:
                            continue
                        value = self._metric_value(metric, current, [], player_by_id[user_id], all_time=False)
                    else:
                        value = self._metric_value(metric, current, past, player_by_id[user_id], all_time=True)
                    result.append({"user_id": user_id, "value": value})
                result.sort(key=lambda item: (-float(item["value"]), int(item["user_id"])))
                frozen_entries = tuple(
                    {"rank": index + 1, "user_id": int(item["user_id"]), "value": item["value"]}
                    for index, item in enumerate(result)
                )
        expires_at = timestamp + self.cache_seconds
        self._cache[key] = (expires_at, frozen_entries)
        return LeaderboardResult(
            metric, scope, period, guild_id if scope == "server" else None,
            copy.deepcopy(frozen_entries), timestamp, expires_at,
        )

    async def set_opt_out(self, user_id: int, opt_out: bool, *, now: Optional[int] = None) -> None:
        """Set the user's public ranking/profile visibility preference."""
        timestamp = int(time.time()) if now is None else int(now)
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                await self.repository.set_leaderboard_privacy(tx, user_id, bool(opt_out), timestamp)
        self._cache.clear()

    async def is_opted_out(self, user_id: int) -> bool:
        """Return whether another user's achievements and life summaries are private."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                row = await self.repository.player_row(tx, user_id)
        return bool(row and row.get("leaderboard_opt_out"))

    def clear_cache(self) -> None:
        """Clear all leaderboard snapshots after a privacy or data change."""
        self._cache.clear()

    async def _current_facts(self, tx: Any, row: dict[str, Any]) -> dict[str, Any]:
        """Calculate metrics for one active character from persisted state."""
        character = Character.from_dict(json.loads(str(row["data_json"])))
        character.char_id = int(row["char_id"])
        character.user_id = int(row["user_id"])
        facts = await self.achievements._facts(tx, character)
        score = calculate_life_score(
            age=character.age,
            average_happiness=float(facts["average_happiness"]),
            final_health=character.stats.health,
            education_level=character.education_level.value,
            career_years=int(facts["career_years"]),
            children=int(facts["children"]),
            marriage_count=int(facts["marriage_count"]),
            peak_net_worth_cents=max(0, int(facts["peak_net_worth_cents"])),
            unsealed_convictions=int(facts["convictions"]),
        )
        tracking = await self.repository.stats_tracking(tx, character.char_id)
        return {
            "net_worth": int(facts["net_worth_cents"]),
            "peak_net_worth": int(facts["peak_net_worth_cents"]),
            "life_score": score,
            "age": int(character.age),
            "fame": int(character.stats.fame),
            "lives": int(character.generation),
            "gambling": int(tracking["total_gambled"]),
            "crime": int(facts["successes"]),
            "generation": int(character.generation),
        }

    @staticmethod
    def _metric_value(
        metric: str,
        current: Optional[dict[str, Any]],
        past_rows: list[dict[str, Any]],
        player: dict[str, Any],
        *,
        all_time: bool,
    ) -> int | float:
        """Combine current and archived life facts according to the chosen period."""
        if not all_time:
            return 0 if current is None else current[metric]
        summaries: list[dict[str, Any]] = []
        for row in past_rows:
            try:
                summaries.append(json.loads(str(row["summary_json"])))
            except (TypeError, json.JSONDecodeError):
                summaries.append({})
        if metric == "net_worth":
            values = [int(row.get("peak_net_worth_cents", 0)) for row in summaries]
            if current is not None:
                values.append(int(current["peak_net_worth"]))
            return max(values, default=0)
        if metric == "life_score":
            values = [float(row.get("life_score", 0.0)) for row in summaries]
            if current is not None:
                values.append(float(current["life_score"]))
            return max(values, default=0.0)
        if metric == "age":
            values = [int(row.get("death_age", 0)) for row in summaries]
            if current is not None:
                values.append(int(current["age"]))
            return max(values, default=0)
        if metric == "fame":
            values = [int(row.get("fame", 0)) for row in summaries]
            if current is not None:
                values.append(int(current["fame"]))
            return max(values, default=0)
        if metric == "lives":
            return int(player.get("lives_lived", 0)) + int(current is not None)
        if metric == "gambling":
            archived = sum(int(row.get("gambling", {}).get("total_gambled_cents", 0)) for row in summaries)
            return archived + (int(current["gambling"]) if current is not None else 0)
        if metric == "crime":
            archived = sum(int(row.get("crime", {}).get("successes", 0)) for row in summaries)
            return archived + (int(current["crime"]) if current is not None else 0)
        raise ValidationError("Choose a supported leaderboard category.")
