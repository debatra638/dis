"""Exactly-once death archiving, life scoring, epitaphs, and estate settlement."""
from __future__ import annotations

import hashlib
import json
import math
import secrets
import time
from dataclasses import dataclass, replace
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_HALF_UP
from typing import Any, Callable, Optional

import aiosqlite

from .achievements import AchievementService
from .errors import CharacterAlreadyExists, CharacterDead, CharacterNotFound, ConcurrentUpdate, ValidationError
from .family import FamilyService
from .crime import CrimeService
from .casino import CasinoService
from .locks import UserLockRegistry
from .models import Character, EducationLevel, Gender, Stats
from .money import dollars_to_cents, format_cents, scale_cents
from .repositories.legacy import LegacyRepository
from .repositories.settings import SettingsRepository


GRADE_CUTOFFS: tuple[tuple[float, str], ...] = (
    (90.0, "S"),
    (80.0, "A"),
    (70.0, "B"),
    (55.0, "C"),
    (40.0, "D"),
    (0.0, "F"),
)
_EDUCATION_RANK = {
    EducationLevel.NONE.value: 0,
    EducationLevel.PRIMARY.value: 1,
    EducationLevel.HIGH_SCHOOL.value: 2,
    EducationLevel.BACHELOR.value: 3,
    EducationLevel.MASTER.value: 4,
    EducationLevel.DOCTORATE.value: 5,
}

# Templates are selected by ordered, objective conditions and a stable character-ID index.
_EPITAPHS: dict[str, tuple[str, ...]] = {
    "abandoned": (
        "Their chapter ended by choice, with room for a new beginning.",
        "They closed this chapter and carried their story forward.",
        "A life set aside is still a story worth remembering.",
    ),
    "century": (
        "A century of stories ended; the stories remain.",
        "One hundred years, countless small kindnesses, and a life well remembered.",
        "They crossed a century with curiosity and heart.",
        "The years were many; the memories are more.",
    ),
    "family": (
        "Their family carries forward the warmth they gave.",
        "A generous home was built around them.",
        "They left a family tree full of new branches.",
        "Love was the inheritance they gave first.",
    ),
    "long_marriage": (
        "A long partnership made a home of the passing years.",
        "They shared the ordinary days, and made them matter.",
        "Two lives walked side by side for many seasons.",
    ),
    "education": (
        "They kept asking questions, and kept finding new doors.",
        "Learning was a lifelong companion.",
        "Their curiosity outlived every lesson.",
    ),
    "career": (
        "Their steady work helped shape the lives around them.",
        "They built a vocation with patience and care.",
        "Their craft was remembered by those who learned from them.",
    ),
    "crime_recovery": (
        "Their hardest chapter did not define the whole story.",
        "They found a steadier path, one choice at a time.",
        "A second chance became part of their legacy.",
    ),
    "crime": (
        "Their life held difficult choices and hard-won lessons.",
        "The record remembers the deeds; the people remember the person.",
        "Their story was more complicated than any single chapter.",
    ),
    "illness": (
        "Remembered for more than the illness that ended their life.",
        "Care and compassion stayed with them through difficult days.",
        "Their life was larger than its final challenge.",
    ),
    "hardship": (
        "They met lean years with grit and kept looking ahead.",
        "Setbacks were chapters, not the whole book.",
        "They found strength in beginning again.",
    ),
    "wealth": (
        "They made something lasting from what they were given.",
        "Their success was measured in more than money.",
        "They built a life with purpose and room to share.",
    ),
    "long_life": (
        "A long life, remembered in many small moments.",
        "They stayed curious through many changing seasons.",
        "The years were full of stories worth retelling.",
    ),
    "young": (
        "Their story was brief, but their place in it was lasting.",
        "A life is not measured only by the number of years.",
        "They were loved, and they will be remembered.",
    ),
    "general": (
        "Their story lives on in the people they touched.",
        "Remembered with warmth, laughter, and care.",
        "A life of many chapters, held close by those who knew them.",
        "They made a difference in ways both large and quiet.",
        "Their name remains in the stories shared by friends and family.",
    ),
}


@dataclass(frozen=True, slots=True)
class EstateSettlement:
    """Integer-cent estate result after debt payment and estate tax."""

    gross_assets_cents: int
    debts_due_cents: int
    debts_paid_cents: int
    unpaid_debt_cents: int
    taxable_threshold_cents: int
    estate_tax_cents: int
    estate_cents: int


@dataclass(frozen=True, slots=True)
class DeathResult:
    """Archived death summary and optional owner-bound heir menu payload."""

    summary: dict[str, Any]
    estate_id: Optional[int]
    estate_nonce: Optional[str]
    heirs: tuple[dict[str, Any], ...]
    public_summary: bool
    unlocked_achievements: tuple[dict[str, Any], ...] = ()


@dataclass(frozen=True, slots=True)
class RetirementPrompt:
    """One-time owner-bound retirement confirmation details."""

    prompt_id: int
    nonce: str
    expires_at: int


@dataclass(frozen=True, slots=True)
class RetirementResult:
    """Result of an accepted retirement confirmation."""

    summary: dict[str, Any]
    public_summary: bool = False


def calculate_life_score(
    *,
    age: int,
    average_happiness: float,
    final_health: int,
    education_level: str,
    career_years: int,
    children: int,
    marriage_count: int,
    peak_net_worth_cents: int,
    unsealed_convictions: int,
) -> float:
    """Score a life from 0–100 using fixed, documented and reproducible components.

    Components (maximum points): longevity ``age × 0.30`` capped at 30;
    lifetime average happiness ``× 0.15`` (15); final health ``× 0.10`` (10);
    education rank ``× 2`` (10); career tenure ``years ÷ 5`` capped at 10;
    family ``2`` per child capped at 6 plus 4 for any marriage (10); peak
    net worth ``$1M`` per point capped at 10; and 5 for a clean conviction
    record. The result is rounded half-up to two decimal places.
    """
    if age < 0 or career_years < 0 or children < 0 or marriage_count < 0 or peak_net_worth_cents < 0:
        raise ValueError("life-score inputs cannot be negative")
    if not 0 <= average_happiness <= 100 or not 0 <= final_health <= 100:
        raise ValueError("happiness and health must be between 0 and 100")
    rank = _EDUCATION_RANK.get(str(education_level), 0)
    wealth_millions = Decimal(max(0, int(peak_net_worth_cents))) / Decimal(dollars_to_cents(1_000_000))
    components = (
        min(30.0, float(age) * 0.30)
        + float(average_happiness) * 0.15
        + float(final_health) * 0.10
        + rank * 2.0
        + min(10.0, float(career_years) / 5.0)
        + min(6.0, float(children) * 2.0)
        + (4.0 if marriage_count > 0 else 0.0)
        + float(min(Decimal("10"), wealth_millions))
        + (5.0 if unsealed_convictions == 0 else 0.0)
    )
    return float(Decimal(str(max(0.0, min(100.0, components)))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def grade_for_life_score(score: float) -> str:
    """Map a score to documented cutoffs: S 90+, A 80+, B 70+, C 55+, D 40+, F below."""
    if not math.isfinite(float(score)) or not 0 <= float(score) <= 100:
        raise ValueError("life score must be finite and between 0 and 100")
    for cutoff, grade in GRADE_CUTOFFS:
        if float(score) >= cutoff:
            return grade
    return "F"


def legacy_points_for_score(score: float) -> int:
    """Grant cosmetic legacy points as floor(life_score / 10)."""
    if not math.isfinite(float(score)) or not 0 <= float(score) <= 100:
        raise ValueError("life score must be finite and between 0 and 100")
    return math.floor(float(score) / 10.0)


def calculate_estate_settlement(
    *, gross_assets_cents: int, debts_due_cents: int, price_index: float
) -> EstateSettlement:
    """Pay liabilities first, then tax 40% of remaining assets above $5M × price index.

    Tax rounds upward to a whole cent. All input and output balances are never
    negative, and all monetary values are integer cents.
    """
    for name, value in (("gross_assets_cents", gross_assets_cents), ("debts_due_cents", debts_due_cents)):
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(f"{name} must be non-negative integer cents")
    try:
        index = Decimal(str(price_index))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError("price_index must be a finite positive number") from exc
    if not index.is_finite() or index <= 0:
        raise ValueError("price_index must be a finite positive number")
    paid = min(gross_assets_cents, debts_due_cents)
    unpaid = debts_due_cents - paid
    after_debt = gross_assets_cents - paid
    threshold = scale_cents(dollars_to_cents(5_000_000), index)
    taxable = max(0, after_debt - threshold)
    tax = int((Decimal(taxable) * Decimal("0.40")).quantize(Decimal("1"), rounding=ROUND_CEILING))
    tax = min(after_debt, max(0, tax))
    return EstateSettlement(
        gross_assets_cents=gross_assets_cents,
        debts_due_cents=debts_due_cents,
        debts_paid_cents=paid,
        unpaid_debt_cents=unpaid,
        taxable_threshold_cents=threshold,
        estate_tax_cents=tax,
        estate_cents=max(0, after_debt - tax),
    )


def select_epitaph(
    *,
    char_id: int,
    age: int,
    cause: str,
    education_level: str,
    children: int,
    marriage_years: int,
    career_count: int,
    conviction_count: int,
    sealed_convictions: int,
    net_worth_cents: int,
    hardship_recovered: bool,
) -> str:
    """Choose from 40+ respectful epitaphs using ordered facts and a stable ID index.

    The priority is century, family, long marriage, education, career, crime
    recovery, criminal record, illness, hardship, wealth, long life, young death,
    then general. No random source or command-supplied trigger is used.
    """
    if cause.strip().lower() == "life abandoned":
        theme = "abandoned"
    elif age >= 100:
        theme = "century"
    elif children >= 5:
        theme = "family"
    elif marriage_years >= 50:
        theme = "long_marriage"
    elif _EDUCATION_RANK.get(str(education_level), 0) >= 4:
        theme = "education"
    elif career_count >= 2:
        theme = "career"
    elif hardship_recovered:
        theme = "crime_recovery"
    elif conviction_count > 0 or sealed_convictions > 0:
        theme = "crime"
    elif "ill" in cause.lower() or "disease" in cause.lower():
        theme = "illness"
    elif net_worth_cents < 0:
        theme = "hardship"
    elif net_worth_cents >= dollars_to_cents(1_000_000):
        theme = "wealth"
    elif age >= 80:
        theme = "long_life"
    elif age < 30:
        theme = "young"
    else:
        theme = "general"
    templates = _EPITAPHS[theme]
    return templates[abs(int(char_id)) % len(templates)]


class DeathService:
    """Apply death and retirement exactly once inside a caller-owned transaction."""

    def __init__(
        self,
        db: Any,
        locks: Optional[UserLockRegistry] = None,
        *,
        clock: Callable[[], float] = time.time,
        repository: Optional[LegacyRepository] = None,
        achievements: Optional[AchievementService] = None,
        family_service: Optional[FamilyService] = None,
        crime_service: Optional[CrimeService] = None,
        casino_service: Optional[CasinoService] = None,
    ) -> None:
        self.db = db
        self.locks = locks or UserLockRegistry()
        self.clock = clock
        self.repository = repository or LegacyRepository(db)
        self.achievements = achievements or AchievementService(db, self.locks, clock=clock)
        self.family_service = family_service
        self.crime_service = crime_service
        self.casino_service = casino_service

    async def handle_death(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        now: Optional[int] = None,
        guild_id: Optional[int] = None,
    ) -> Optional[DeathResult]:
        """Archive a naturally ended life once; duplicate calls are safe no-ops."""
        timestamp = int(self.clock()) if now is None else int(now)
        if character.is_alive:
            raise ValidationError("Death can only be archived after the character has ended.")
        existing = await self.repository.past_life(tx, character.char_id)
        if existing is not None:
            return None
        record = await self.repository.character_record(tx, character.char_id)
        if record is None or int(record["user_id"]) != character.user_id:
            raise CharacterNotFound("The life to archive could not be found.")
        stored = Character.from_dict(json.loads(record["data_json"]))
        if stored.is_alive:
            raise ConcurrentUpdate("The saved character has not yet entered its terminal state.")
        character = stored
        await self.repository.ensure_player(tx, character.user_id, timestamp)
        # Evaluate death-age and completion achievements from the persisted terminal character
        # before its active career and marriage rows are closed. The caller queues notices only
        # after its transaction commits.
        unlocked = await self.achievements.check_user_in_tx(
            tx, character.user_id, now=timestamp
        )
        abandoned = character.death_cause == "Life abandoned"
        await self.repository.close_open_career(
            tx, character.char_id, character.age, "retired" if abandoned else "died"
        )
        await self.repository.archive_marriage(
            tx, char_id=character.char_id, end_age=character.age,
            end_reason="retirement" if abandoned else "character_death", now=timestamp,
        )
        result = await self._archive(
            tx, character, now=timestamp, guild_id=guild_id, abandoned=abandoned
        )
        if result is None:
            return None
        return replace(result, unlocked_achievements=tuple(unlocked))

    async def _archive(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        now: int,
        guild_id: Optional[int],
        abandoned: bool,
    ) -> Optional[DeathResult]:
        """Build and insert the immutable life summary, settle assets, and offer heirs."""
        char_id = character.char_id
        user_id = character.user_id
        existing = await self.repository.past_life(tx, char_id)
        if existing is not None:
            return None
        careers = await self.repository.career_history(tx, char_id)
        marriages = await self.repository.marriage_history(tx, char_id)
        current_marriage = await self.repository.current_marriage(tx, char_id)
        children = await self.repository.children(tx, char_id)
        logs = await self.repository.top_life_logs(tx, char_id, 10)
        metrics = await self.repository.life_year_metrics(tx, char_id)
        crime = await self.repository.crime_summary(tx, char_id)
        tracking = await self.repository.stats_tracking(tx, char_id)
        economy = await self.repository.economy_snapshot(tx, char_id)
        peak_net_worth = max(
            [economy["net_worth_cents"]]
            + [int(row["peak_net_worth_cents"]) for row in metrics]
        )
        average_happiness = (
            sum(int(row["happiness"]) for row in metrics) / len(metrics)
            if metrics else float(character.stats.happiness)
        )
        prison_years = int(crime["years_in_prison"])
        career_years = sum(
            max(0, (int(row["end_age"]) if row["end_age"] is not None else character.age) - int(row["start_age"]))
            for row in careers
        )
        child_count = len(children)
        marriage_count = len(marriages) + int(current_marriage is not None)
        marriage_years = await self.repository.max_marriage_years(tx, char_id, character.age)
        settlement = calculate_estate_settlement(
            gross_assets_cents=economy["gross_assets_cents"],
            debts_due_cents=economy["debts_cents"],
            price_index=max(0.000001, float(character.price_index)),
        )
        if abandoned:
            estate_tax = 0
            estate_cents = 0
            debts_paid = 0
            unpaid_debt = economy["debts_cents"]
            # Retirement has no estate transfer; close all remaining loans as defaulted.
            await self.repository.settle_loan_balances(tx, char_id, 0)
        else:
            settlement_paid = await self.repository.settle_loan_balances(
                tx, char_id, settlement.debts_paid_cents
            )
            debts_paid = settlement.debts_paid_cents
            # Loan subledger rows are retired in stable order; remaining debt is not passed to an heir.
            estate_tax = settlement.estate_tax_cents
            estate_cents = settlement.estate_cents
            unpaid_debt = settlement.unpaid_debt_cents
            if settlement_paid > debts_paid:
                raise AssertionError("loan payment cannot exceed estate debt payment")
        final_worth = economy["net_worth_cents"]
        score = calculate_life_score(
            age=character.age,
            average_happiness=average_happiness,
            final_health=character.stats.health,
            education_level=character.education_level.value,
            career_years=career_years,
            children=child_count,
            marriage_count=marriage_count,
            peak_net_worth_cents=max(0, peak_net_worth),
            unsealed_convictions=int(crime["convictions"]),
        )
        grade = grade_for_life_score(score)
        points = 0 if abandoned else legacy_points_for_score(score)
        has_recovered = int(crime["sealed_convictions"]) > 0 and int(crime["convictions"]) == 0
        epitaph = select_epitaph(
            char_id=char_id,
            age=character.age,
            cause=character.death_cause or ("Life abandoned" if abandoned else "natural causes"),
            education_level=character.education_level.value,
            children=child_count,
            marriage_years=marriage_years,
            career_count=len(careers),
            conviction_count=int(crime["convictions"]),
            sealed_convictions=int(crime["sealed_convictions"]),
            net_worth_cents=final_worth,
            hardship_recovered=has_recovered,
        )
        earned = await self.repository.character_achievement_rows(tx, char_id)
        public_summary = False
        if guild_id is not None and not abandoned:
            guild_enabled = await self.repository.guild_public_death_summaries(tx, guild_id)
            player = await self.repository.player_row(tx, user_id)
            settings = await SettingsRepository(self.db).get(tx, user_id)
            public_summary = (
                guild_enabled
                and settings.public_deaths
                and not bool(player and player.get("leaderboard_opt_out"))
            )
        summary: dict[str, Any] = {
            "char_id": char_id,
            "user_id": user_id,
            "name": character.name,
            "gender": character.gender.value,
            "country": character.country,
            "generation": character.generation,
            "parent_char_id": character.parent_char_id,
            "death_age": character.age,
            "death_cause": "Life abandoned" if abandoned else (character.death_cause or "natural causes"),
            "born_at": character.born_at,
            "died_at": character.died_at or now,
            "years_lived": character.age,
            "epitaph": epitaph,
            "education": {
                "level": character.education_level.value,
                "gpa": character.gpa,
                "major": character.major,
            },
            "careers": careers,
            "career_years": career_years,
            "peak_net_worth_cents": peak_net_worth,
            "final_net_worth_cents": final_worth,
            "gross_assets_cents": economy["gross_assets_cents"],
            "debts_due_cents": economy["debts_cents"],
            "debts_paid_cents": debts_paid,
            "estate_tax_cents": estate_tax,
            "estate_tax_rate": 0.40,
            "estate_tax_threshold_cents": settlement.taxable_threshold_cents,
            "estate_cents": estate_cents,
            "unpaid_debt_cents": unpaid_debt,
            "price_index": character.price_index,
            "marriages": marriages,
            "marriage_count": marriage_count,
            "marriage_years": marriage_years,
            "current_marriage": current_marriage,
            "children": children,
            "child_count": child_count,
            "crime": {
                "attempts": crime["attempts"],
                "successes": crime["successes"],
                "convictions": crime["convictions"],
                "sealed_convictions": crime["sealed_convictions"],
                "years_in_prison": prison_years,
                "escaped": crime["escaped"],
                "career_level": int(crime["profile"].get("career_level", 0)),
            },
            "gambling": {
                "total_gambled_cents": tracking["total_gambled"],
                "net_cents": tracking["total_gambling_net"],
            },
            "fame": character.stats.fame,
            "average_happiness": round(average_happiness, 2),
            "life_years": metrics,
            "life_log_top": logs,
            "achievements": earned,
            "life_score": score,
            "grade": grade,
            "legacy_points": points,
            "abandoned": abandoned,
            "public_summary": public_summary,
            "archived_at": now,
        }
        inserted = await self.repository.insert_past_life(
            tx,
            {
                "char_id": char_id,
                "user_id": user_id,
                "death_age": character.age,
                "death_cause": summary["death_cause"],
                "born_at": character.born_at,
                "died_at": int(summary["died_at"]),
                "life_score": score,
                "grade": grade,
                "legacy_points": points,
                "peak_net_worth_cents": peak_net_worth,
                "final_net_worth_cents": final_worth,
                "gross_assets_cents": economy["gross_assets_cents"],
                "debts_paid_cents": debts_paid,
                "estate_tax_cents": estate_tax,
                "estate_cents": estate_cents,
                "unpaid_debt_cents": unpaid_debt,
                "abandoned": abandoned,
                "summary_json": summary,
                "archived_at": now,
            },
        )
        if not inserted:
            return None  # A competing/replayed invocation already archived this character.
        if not abandoned:
            await self.repository.increment_lives_lived(tx, user_id, now)
        if points:
            await self.repository.add_player_legacy_points(tx, user_id, points, now)
        heirs: list[dict[str, Any]] = []
        estate_id: Optional[int] = None
        estate_nonce: Optional[str] = None
        if not abandoned:
            eligible = await self.repository.estate_heirs(tx, char_id)
            heirs = self._split_inheritance(eligible, estate_cents)
            if heirs:
                estate_nonce = secrets.token_urlsafe(18)
                estate_id = await self.repository.insert_life_estate(
                    tx,
                    char_id=char_id,
                    user_id=user_id,
                    estate_cents=estate_cents,
                    nonce=estate_nonce,
                    eligible_heirs=heirs,
                    now=now,
                )
        return DeathResult(
            summary=summary,
            estate_id=estate_id,
            estate_nonce=estate_nonce,
            heirs=tuple(heirs),
            public_summary=public_summary,
        )

    @staticmethod
    def _split_inheritance(heirs: list[dict[str, Any]], estate_cents: int) -> list[dict[str, Any]]:
        """Split cents evenly by eligible child ID, assigning remainder cents stably."""
        if not heirs or estate_cents < 0:
            return []
        ordered = sorted(heirs, key=lambda row: int(row["npc_id"]))
        base, remainder = divmod(int(estate_cents), len(ordered))
        return [
            {**row, "inheritance_cents": base + int(index < remainder)}
            for index, row in enumerate(ordered)
        ]

    async def begin_retirement(self, user_id: int, *, now: Optional[int] = None) -> RetirementPrompt:
        """Create a 60-second owner-bound confirmation prompt for abandoning a life."""
        timestamp = int(self.clock()) if now is None else int(now)
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                await self.repository.ensure_player(tx, user_id, timestamp)
                active = await self.repository.active_character(tx, user_id)
                if active is None:
                    raise CharacterNotFound("You need an active life before you can retire it.")
                character = Character.from_dict(json.loads(active["data_json"]))
                if self.crime_service is not None:
                    await self.crime_service.ensure_no_pending_decision(tx, character.char_id)
                if self.casino_service is not None:
                    await self.casino_service.require_no_active_hand(tx, character.char_id)
                    await self.casino_service.require_no_pending_compulsion(tx, character.char_id)
                if await self.repository.has_pending_event(tx, character.char_id):
                    raise ValidationError("Resolve your pending life event before retiring.")
                pending = await self.repository.pending_retirement_prompt(tx, user_id)
                if pending is not None and int(pending["expires_at"]) >= timestamp:
                    raise ValidationError("A retirement confirmation is already open. Use it or wait for it to expire.")
                if pending is not None:
                    await self.repository.resolve_retirement_prompt(
                        tx, prompt_id=int(pending["prompt_id"]), user_id=user_id,
                        nonce=str(pending["nonce"]), status="expired", now=timestamp,
                    )
                nonce = secrets.token_urlsafe(18)
                prompt_id = await self.repository.insert_retirement_prompt(
                    tx, user_id=user_id, char_id=character.char_id, nonce=nonce,
                    now=timestamp, expires_at=timestamp + 60,
                )
                return RetirementPrompt(prompt_id=prompt_id, nonce=nonce, expires_at=timestamp + 60)

    async def confirm_retirement(
        self,
        user_id: int,
        prompt_id: int,
        nonce: str,
        *,
        guild_id: Optional[int] = None,
        now: Optional[int] = None,
    ) -> RetirementResult:
        """Confirm retirement once, archive the life with no points or heir transfer."""
        timestamp = int(self.clock()) if now is None else int(now)
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                prompt = await self.repository.load_retirement_prompt(tx, prompt_id)
                if (
                    prompt is None
                    or int(prompt["user_id"]) != user_id
                    or str(prompt["nonce"]) != nonce
                    or str(prompt["status"]) != "pending"
                ):
                    raise ValidationError("This retirement confirmation is no longer valid.")
                if int(prompt["expires_at"]) < timestamp:
                    await self.repository.resolve_retirement_prompt(
                        tx, prompt_id=prompt_id, user_id=user_id, nonce=nonce,
                        status="expired", now=timestamp,
                    )
                    raise ValidationError("This retirement confirmation expired. Run `/retire_life` again.")
                active = await self.repository.active_character(tx, user_id)
                if active is None or int(active["char_id"]) != int(prompt["char_id"]):
                    raise CharacterDead("Your active life changed; this retirement prompt is stale.")
                character = Character.from_dict(json.loads(active["data_json"]))
                if await self.repository.past_life(tx, character.char_id) is not None:
                    raise CharacterDead("This life has already been archived.")
                await self.repository.resolve_retirement_prompt(
                    tx, prompt_id=prompt_id, user_id=user_id, nonce=nonce,
                    status="confirmed", now=timestamp,
                )
                retired = replace(
                    character,
                    is_alive=False,
                    death_cause="Life abandoned",
                    death_age=character.age,
                    died_at=timestamp,
                    last_age_at=timestamp,
                    version=character.version + 1,
                )
                await self.repository.save_death_character(
                    tx, retired, expected_version=int(active["version"])
                )
                await self.repository.insert_life_log(
                    tx, char_id=retired.char_id, age=retired.age,
                    category="retirement", text="Life abandoned by player.",
                    importance=4, created_at=timestamp,
                )
                await self.repository.record_life_year(
                    tx, character=retired, age=retired.age, served_prison_year=False, now=timestamp
                )
                result = await self.handle_death(tx, retired, now=timestamp, guild_id=guild_id)
                if result is None:
                    raise CharacterDead("This life has already been archived.")
                retirement_result = RetirementResult(summary=result.summary, public_summary=False)
            self.achievements.queue_notifications(user_id, result.unlocked_achievements)
            return retirement_result

    async def cancel_retirement(
        self, user_id: int, prompt_id: int, nonce: str, *, now: Optional[int] = None
    ) -> bool:
        """Cancel an owner-bound pending retirement prompt once."""
        timestamp = int(self.clock()) if now is None else int(now)
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                prompt = await self.repository.load_retirement_prompt(tx, prompt_id)
                if prompt is None or int(prompt["user_id"]) != user_id or str(prompt["nonce"]) != nonce:
                    return False
                return await self.repository.resolve_retirement_prompt(
                    tx, prompt_id=prompt_id, user_id=user_id, nonce=nonce,
                    status="cancelled", now=timestamp,
                )

    async def choose_heir(
        self,
        user_id: int,
        estate_id: int,
        nonce: str,
        selected_npc_id: Optional[int],
        *,
        now: Optional[int] = None,
    ) -> Optional[Character]:
        """Claim an eligible adult child as heir, or close the prompt to start fresh."""
        timestamp = int(self.clock()) if now is None else int(now)
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                estate = await self.repository.load_life_estate(tx, estate_id)
                if (
                    estate is None
                    or int(estate["user_id"]) != user_id
                    or str(estate["nonce"]) != nonce
                    or str(estate["status"]) != "pending"
                ):
                    raise ValidationError("This inheritance menu has already been used or is not yours.")
                if await self.repository.active_character(tx, user_id) is not None:
                    raise CharacterAlreadyExists("An active life already exists for your account.")
                eligible = json.loads(str(estate["eligible_heirs_json"]))
                if selected_npc_id is None:
                    if not await self.repository.resolve_life_estate(
                        tx, estate_id=estate_id, user_id=user_id, nonce=nonce,
                        selected_npc_id=None, now=timestamp,
                    ):
                        raise ValidationError("This inheritance menu has already been used.")
                    return None
                selected = next((row for row in eligible if int(row["npc_id"]) == selected_npc_id), None)
                if selected is None:
                    raise ValidationError("That child is not an eligible heir.")
                current_heirs = await self.repository.estate_heirs(tx, int(estate["char_id"]))
                still_eligible = next(
                    (row for row in current_heirs if int(row["npc_id"]) == selected_npc_id), None
                )
                if still_eligible is None:
                    raise ValidationError("That child is no longer a living adult heir.")
                parent_row = await self.repository.character_record(tx, int(estate["char_id"]))
                past = await self.repository.past_life(tx, int(estate["char_id"]))
                if parent_row is None or past is None:
                    raise ValidationError("The archived parent life could not be found.")
                parent = Character.from_dict(json.loads(parent_row["data_json"]))
                share = max(0, int(selected.get("inheritance_cents", 0)))
                heir = Character(
                    user_id=user_id,
                    is_alive=True,
                    name=str(still_eligible["name"]),
                    gender=Gender(str(still_eligible["gender"])),
                    country=str(still_eligible["country"]),
                    wealth_class=self._wealth_class(int(still_eligible["wealth"])),
                    age=int(still_eligible["age"]),
                    stats=Stats(
                        health=max(0, min(100, int(still_eligible["health"]))),
                        happiness=70,
                        smarts=max(0, min(100, int(still_eligible["smarts"]))),
                        looks=max(0, min(100, int(still_eligible["looks"]))),
                        fitness=40,
                        karma=50,
                        stress=10,
                        addiction=0,
                        fame=0,
                    ),
                    cash=share,
                    bank=0,
                    debt_total=0,
                    price_index=float(parent.price_index),
                    parent_char_id=parent.char_id,
                    generation=parent.generation + 1,
                    last_age_at=timestamp,
                    born_at=timestamp,
                )
                char_id = await self.repository.save_heir_character(tx, heir)
                heir.char_id = char_id
                await self.repository.refresh_character_json(tx, heir)
                if self.family_service is not None:
                    await self.family_service.initialize_family(tx, heir)
                if self.crime_service is not None:
                    await self.crime_service.initialize_character(tx, heir)
                if not await self.repository.resolve_life_estate(
                    tx, estate_id=estate_id, user_id=user_id, nonce=nonce,
                    selected_npc_id=selected_npc_id, now=timestamp,
                ):
                    raise ValidationError("This inheritance menu has already been used.")
                await self.repository.insert_life_log(
                    tx, char_id=heir.char_id, age=heir.age,
                    category="family", text="Continued the family as an heir.",
                    importance=4, created_at=timestamp,
                )
                unlocked = await self.achievements.check_user_in_tx(
                    tx, user_id, now=timestamp
                )
            self.achievements.queue_notifications(user_id, unlocked)
            return heir

    @staticmethod
    def _wealth_class(wealth_cents: int) -> str:
        """Map recorded NPC cents to the five established starting wealth labels."""
        thresholds = (
            (dollars_to_cents(15_000), "poor"),
            (dollars_to_cents(80_000), "working"),
            (dollars_to_cents(600_000), "middle"),
            (dollars_to_cents(5_000_000), "upper"),
        )
        for cutoff, label in thresholds:
            if wealth_cents < cutoff:
                return label
        return "rich"
