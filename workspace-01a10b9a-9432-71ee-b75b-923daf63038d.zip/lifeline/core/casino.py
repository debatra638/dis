"""Stage 9 casino rules, blackjack sessions, addiction, and yearly settlement."""
from __future__ import annotations

import json
import math
import secrets
import time
from dataclasses import dataclass, replace
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from typing import Any, Callable, Optional, Sequence

import aiosqlite

from .config import GameBalance
from .data_loader import DataLoader
from .db import DatabaseManager
from .errors import (
    CharacterDead,
    CharacterInPrison,
    CharacterNotFound,
    ConcurrentUpdate,
    InsufficientFunds,
    ValidationError,
)
from .locks import UserLockRegistry
from .models import Character
from .money import MAX_CENTS, payout_cents, validate_cents
from .repositories.casino import CasinoRepository
from .rng import RNG
from .validators import validate_gambling_ages, validate_item_catalog

CASINO_MAX_BETS_PER_YEAR = 25
CASINO_COOLDOWN_SECONDS = 3
CASINO_SESSION_TIMEOUT_SECONDS = 120
CASINO_MAX_BET_BASE_CENTS = 25_000_000
GAMBLING_DISEASE_ID = "gambling_addiction"
SLOT_SYMBOLS = ("cherry", "lemon", "bell", "diamond")
SLOT_WEIGHTS = (50, 30, 15, 5)
SLOT_TRIPLE_MULTIPLIERS = {"cherry": (3, 2), "lemon": (3, 1), "bell": (6, 1), "diamond": (22, 1)}
RED_NUMBERS = frozenset({1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36})


@dataclass(frozen=True, slots=True)
class CasinoReceipt:
    """Settled game receipt or current blackjack hand state."""

    game: str
    bet_cents: int
    payout_cents: Optional[int]
    net_cents: Optional[int]
    outcome: dict[str, Any]
    message: str
    status: str = "settled"
    session_id: Optional[int] = None
    nonce: Optional[str] = None
    expires_at: Optional[int] = None


@dataclass(frozen=True, slots=True)
class CasinoYearProgress:
    """Annual casino tax assessment and a possible addiction-compulsion choice."""

    character: Character
    messages: tuple[str, ...] = ()
    compulsion: Optional[dict[str, Any]] = None


@dataclass(frozen=True, slots=True)
class CompulsionReceipt:
    """Owner-bound result of resolving an addiction-compulsion prompt."""

    status: str
    message: str
    receipt: Optional[CasinoReceipt] = None


class CasinoService:
    """Transactional casino and gambling-addiction service.

    All wager writes use ``BEGIN IMMEDIATE`` and the same per-user lock shared by
    the rest of the game. Casino play randomness is injected through ``RNG``.
    """

    def __init__(
        self,
        db: DatabaseManager,
        rng: RNG,
        locks: Optional[UserLockRegistry] = None,
        *,
        clock: Callable[[], float] = time.time,
        data_loader: Optional[DataLoader] = None,
    ) -> None:
        self.db = db
        self.rng = rng
        self.locks = locks or UserLockRegistry()
        self.clock = clock
        self.repository = CasinoRepository(db)
        loader = data_loader or DataLoader()
        item_doc = loader.load_items()
        self.items = {str(item["id"]): item for item in item_doc["items"]}
        age_doc = loader.load_gambling_ages()
        self.gambling_ages = {str(key): int(value) for key, value in age_doc["countries"].items()}
        self.default_gambling_age = int(age_doc["default_age"])

    def replace_catalogs(self, items: dict[str, Any], gambling_ages: dict[str, Any]) -> None:
        """Validate and atomically replace item and country-age lookup tables."""
        validate_item_catalog(items)
        validate_gambling_ages(gambling_ages)
        new_items = {str(item["id"]): dict(item) for item in items["items"]}
        new_ages = {str(key): int(value) for key, value in gambling_ages["countries"].items()}
        self.items = new_items
        self.gambling_ages = new_ages
        self.default_gambling_age = int(gambling_ages["default_age"])

    @staticmethod
    def max_bet_cents(character: Character) -> int:
        """Return the balance and price-index scaled wager ceiling, rounded down."""
        scaled_cap = int(
            (Decimal(CASINO_MAX_BET_BASE_CENTS) * Decimal(str(character.price_index))).to_integral_value(
                rounding=ROUND_FLOOR
            )
        )
        return max(0, min(character.cash + character.bank, scaled_cap))

    def gambling_age(self, country: str) -> int:
        """Return a validated country minimum; unknown region keys safely default to 18."""
        return max(18, self.gambling_ages.get(str(country).lower(), self.default_gambling_age))

    def _check_gambling_eligibility(self, character: Character) -> None:
        if character.age < self.gambling_age(character.country):
            raise ValidationError(
                f"Casino games require age {self.gambling_age(character.country)} in {character.country.upper()} (and never under 18)."
            )
        if character.in_prison:
            raise CharacterInPrison("Casino games are unavailable while your character is in prison.")

    @staticmethod
    def _validate_bet(bet_cents: int) -> int:
        try:
            bet = validate_cents(bet_cents)
        except (TypeError, OverflowError) as exc:
            raise ValidationError("The bet must be a valid whole-cent amount.") from exc
        if bet < 100:
            raise ValidationError("The minimum casino bet is $1.00.")
        return bet

    @staticmethod
    def _validate_active_character(character: Character) -> None:
        if not character.is_alive:
            raise CharacterDead()

    async def _active_character(self, tx: aiosqlite.Connection, user_id: int) -> tuple[Character, int]:
        row = await self.repository.load_active(tx, user_id)
        if row is None:
            if await self.repository.has_any_life(tx, user_id):
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        self._validate_active_character(character)
        return character, int(row["version"])

    async def _reserve_bet(
        self,
        tx: aiosqlite.Connection,
        *,
        character: Character,
        user_id: int,
        bet_cents: int,
        now: int,
        count_for_limit: bool = True,
        enforce_cooldown: bool = True,
    ) -> None:
        """Validate account balance, player cooldown, and the in-game annual cap."""
        bet = self._validate_bet(bet_cents)
        self._check_gambling_eligibility(character)
        max_bet = self.max_bet_cents(character)
        if bet > max_bet:
            raise ValidationError(f"That bet exceeds your maximum of {max_bet:,} cents at the current price index.")
        if character.cash + character.bank < bet:
            raise InsufficientFunds("Your combined cash and bank balance cannot cover that bet.")
        if enforce_cooldown:
            cooldown = await self.repository.casino_state(tx, user_id)
            last_bet_value = cooldown["last_bet_at"]
            last_bet = int(last_bet_value) if last_bet_value is not None else None
            if last_bet is not None and now - last_bet < CASINO_COOLDOWN_SECONDS:
                remaining = CASINO_COOLDOWN_SECONDS - max(0, now - last_bet)
                raise ValidationError(f"Casino cooldown: wait {remaining} more second(s) before another bet.")
        if count_for_limit:
            counter = await self.repository.reserve_yearly_bet(tx, character.char_id, character.age, CASINO_MAX_BETS_PER_YEAR)
            if counter < 0:
                raise ValidationError(f"You have reached the limit of {CASINO_MAX_BETS_PER_YEAR} bets this in-game year.")
        if enforce_cooldown:
            await self.repository.set_last_bet(tx, user_id, now)

    @staticmethod
    def _deduct(character: Character, amount: int) -> tuple[Character, int, int]:
        """Debit cash first, then bank, without allowing either balance to go negative."""
        validate_cents(amount)
        if amount < 0:
            raise ValidationError("A debit cannot be negative.")
        if character.cash + character.bank < amount:
            raise InsufficientFunds()
        cash_debit = min(character.cash, amount)
        bank_debit = amount - cash_debit
        updated = replace(character, cash=character.cash - cash_debit, bank=character.bank - bank_debit)
        return updated, cash_debit, bank_debit

    @staticmethod
    def _credit_bank(character: Character, amount: int) -> Character:
        """Credit a non-negative gross return to bank with integer-cent validation."""
        validate_cents(amount)
        if amount < 0:
            raise ValidationError("A casino payout cannot be negative.")
        return replace(character, bank=validate_cents(character.bank + amount))

    async def _record_wager_effect(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        bet_cents: int,
        net_cents: Optional[int],
        now: int,
    ) -> Character:
        """Add $0.20 fractional addiction per wager and update persistent counters."""
        tracking = await self.repository.tracking(tx, character.char_id)
        fraction = float(tracking["gambling_addiction_fraction"]) + 0.2
        integer_increase = math.floor(fraction + 1e-10)
        fraction = round(fraction - integer_increase, 10)
        addiction = min(100, character.stats.addiction + integer_increase)
        updated = replace(character, stats=replace(character.stats, addiction=addiction))
        if addiction >= 100:
            fraction = 0.0
        await self.repository.save_tracking(
            tx,
            char_id=character.char_id,
            total_gambled=int(tracking["total_gambled"]) + bet_cents,
            total_gambling_net=(int(tracking["total_gambling_net"]) + net_cents) if net_cents is not None else int(tracking["total_gambling_net"]),
            addiction_fraction=fraction,
        )
        if addiction >= 60:
            severity = min(5, max(1, 1 + (addiction - 60) // 8))
            await self.repository.upsert_condition(
                tx, char_id=character.char_id, disease_id=GAMBLING_DISEASE_ID,
                severity=severity, age=character.age, now=now, active=True,
            )
        return updated

    async def _record_net(
        self, tx: aiosqlite.Connection, char_id: int, net_cents: int
    ) -> None:
        """Accumulate net profit/loss after an asynchronous blackjack hand settles."""
        tracking = await self.repository.tracking(tx, char_id)
        await self.repository.save_tracking(
            tx, char_id=char_id,
            total_gambling_net=int(tracking["total_gambling_net"]) + net_cents,
        )

    async def _save_character(
        self, tx: aiosqlite.Connection, character: Character, expected_version: int
    ) -> Character:
        """Increment and persist the character's optimistic version."""
        updated = replace(character, version=expected_version + 1)
        await self.repository.save_character(tx, updated, expected_version)
        return updated

    @staticmethod
    def slot_payout(symbols: Sequence[str], bet_cents: int) -> int:
        """Return slot gross winnings (including returned stake) for a three-reel result."""
        if len(symbols) != 3 or any(symbol not in SLOT_SYMBOLS for symbol in symbols):
            raise ValueError("Slots require exactly three catalog symbols.")
        validate_cents(bet_cents)
        if bet_cents < 0:
            raise ValueError("Bet cannot be negative.")
        if symbols[0] == symbols[1] == symbols[2]:
            numerator, denominator = SLOT_TRIPLE_MULTIPLIERS[symbols[0]]
            return bet_cents * numerator // denominator
        if len(set(symbols)) == 2:
            return bet_cents
        return 0

    def spin_slots(self, bet_cents: int) -> tuple[tuple[str, str, str], int]:
        """Spin three independently weighted reels and return symbols plus gross payout."""
        bet = self._validate_bet(bet_cents)
        reels = tuple(self.rng.weighted_choice(SLOT_SYMBOLS, SLOT_WEIGHTS) for _ in range(3))
        return reels, self.slot_payout(reels, bet)

    async def play_slots(self, user_id: int, bet_cents: int) -> CasinoReceipt:
        """Place and settle one three-reel weighted slot wager atomically."""
        bet = self._validate_bet(bet_cents)
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._active_character(tx, user_id)
                await self._reserve_bet(tx, character=character, user_id=user_id, bet_cents=bet, now=now)
                character, cash_debit, bank_debit = self._deduct(character, bet)
                reels, payout = self.spin_slots(bet)
                net = payout - bet
                character = self._credit_bank(character, payout)
                character = await self._record_wager_effect(tx, character, bet_cents=bet, net_cents=net, now=now)
                character = await self._save_character(tx, character, version)
                await self.repository.insert_play(
                    tx, char_id=character.char_id, user_id=user_id, age=character.age,
                    game="slots", bet_cents=bet, status="settled",
                    outcome={"reels": list(reels), "cash_debit": cash_debit, "bank_debit": bank_debit},
                    created_at=now, payout_cents=payout, net_cents=net,
                )
                await self.repository.insert_audit(
                    tx, now=now, user_id=user_id, char_id=character.char_id,
                    action="casino_slots", amount=bet,
                    details={"payout_cents": payout, "net_cents": net, "reels": list(reels), "version_before": version},
                )
                return CasinoReceipt(
                    game="slots", bet_cents=bet, payout_cents=payout, net_cents=net,
                    outcome={"reels": reels},
                    message=self._receipt_message("Slots", bet, payout, net, f"Reels: {' | '.join(reels)}"),
                )

    async def play_coinflip(self, user_id: int, side: str, bet_cents: int) -> CasinoReceipt:
        """Place a player-selected heads/tails wager paying 1.94x gross on a win."""
        bet = self._validate_bet(bet_cents)
        chosen = str(side).lower().strip()
        if chosen not in {"heads", "tails"}:
            raise ValidationError("Choose heads or tails.")
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._active_character(tx, user_id)
                await self._reserve_bet(tx, character=character, user_id=user_id, bet_cents=bet, now=now)
                character, cash_debit, bank_debit = self._deduct(character, bet)
                landed = self.rng.choice(("heads", "tails"))
                payout = bet * 194 // 100 if landed == chosen else 0
                net = payout - bet
                character = self._credit_bank(character, payout)
                character = await self._record_wager_effect(tx, character, bet_cents=bet, net_cents=net, now=now)
                character = await self._save_character(tx, character, version)
                outcome = {"chosen": chosen, "landed": landed, "cash_debit": cash_debit, "bank_debit": bank_debit}
                await self.repository.insert_play(
                    tx, char_id=character.char_id, user_id=user_id, age=character.age,
                    game="coinflip", bet_cents=bet, status="settled", outcome=outcome, created_at=now,
                    payout_cents=payout, net_cents=net,
                )
                await self.repository.insert_audit(
                    tx, now=now, user_id=user_id, char_id=character.char_id,
                    action="casino_coinflip", amount=bet,
                    details={"chosen": chosen, "landed": landed, "payout_cents": payout, "net_cents": net},
                )
                return CasinoReceipt(
                    game="coinflip", bet_cents=bet, payout_cents=payout, net_cents=net,
                    outcome=outcome,
                    message=self._receipt_message("Coinflip", bet, payout, net, f"You chose {chosen}; it landed {landed}."),
                )

    @staticmethod
    def roulette_payout(bet_cents: int, bet_type: str, number: Optional[int], landed: int) -> int:
        """Calculate European single-zero gross returns with the configured house adjustment."""
        validate_cents(bet_cents)
        kind = str(bet_type).lower().strip()
        if not 0 <= landed <= 36:
            raise ValueError("European roulette result must be between 0 and 36.")
        if kind in {"red", "black", "odd", "even"}:
            if number is not None:
                raise ValueError("Outside bets do not take a number.")
            wins = (
                (kind == "red" and landed in RED_NUMBERS)
                or (kind == "black" and landed != 0 and landed not in RED_NUMBERS)
                or (kind == "odd" and landed != 0 and landed % 2 == 1)
                or (kind == "even" and landed != 0 and landed % 2 == 0)
            )
            return payout_cents(
                2 * bet_cents, GameBalance.CASINO_ROULETTE_PAYOUT_SCALE
            ) if wins else 0
        if kind == "dozen":
            if isinstance(number, bool) or not isinstance(number, int) or number not in {1, 2, 3}:
                raise ValueError("A dozen bet must choose 1, 2, or 3.")
            low = (int(number) - 1) * 12 + 1
            return payout_cents(
                3 * bet_cents, GameBalance.CASINO_ROULETTE_PAYOUT_SCALE
            ) if low <= landed <= low + 11 else 0
        if kind == "straight":
            if isinstance(number, bool) or not isinstance(number, int) or not 0 <= number <= 36:
                raise ValueError("A straight bet must choose a number from 0 to 36.")
            return payout_cents(
                36 * bet_cents, GameBalance.CASINO_ROULETTE_PAYOUT_SCALE
            ) if number == landed else 0
        raise ValueError("Unsupported roulette bet type.")

    async def play_roulette(
        self, user_id: int, bet_type: str, bet_cents: int, number: Optional[int] = None
    ) -> CasinoReceipt:
        """Place a European roulette outside, dozen, or straight-up bet atomically."""
        bet = self._validate_bet(bet_cents)
        kind = str(bet_type).lower().strip()
        if kind not in {"red", "black", "odd", "even", "dozen", "straight"}:
            raise ValidationError("Choose red, black, odd, even, dozen, or straight.")
        if kind == "dozen" and (isinstance(number, bool) or not isinstance(number, int) or number not in {1, 2, 3}):
            raise ValidationError("For a dozen bet, number must be 1, 2, or 3.")
        if kind == "straight" and (isinstance(number, bool) or not isinstance(number, int) or not 0 <= number <= 36):
            raise ValidationError("For a straight bet, number must be 0–36.")
        if kind not in {"dozen", "straight"} and number is not None:
            raise ValidationError("This roulette bet type does not use a number.")
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._active_character(tx, user_id)
                await self._reserve_bet(tx, character=character, user_id=user_id, bet_cents=bet, now=now)
                character, cash_debit, bank_debit = self._deduct(character, bet)
                landed = self.rng.randint(0, 36)
                payout = self.roulette_payout(bet, kind, number, landed)
                net = payout - bet
                character = self._credit_bank(character, payout)
                character = await self._record_wager_effect(tx, character, bet_cents=bet, net_cents=net, now=now)
                character = await self._save_character(tx, character, version)
                outcome = {"bet_type": kind, "number": number, "landed": landed,
                           "color": "green" if landed == 0 else ("red" if landed in RED_NUMBERS else "black"),
                           "cash_debit": cash_debit, "bank_debit": bank_debit}
                await self.repository.insert_play(
                    tx, char_id=character.char_id, user_id=user_id, age=character.age,
                    game="roulette", bet_cents=bet, status="settled", outcome=outcome, created_at=now,
                    payout_cents=payout, net_cents=net,
                )
                await self.repository.insert_audit(
                    tx, now=now, user_id=user_id, char_id=character.char_id,
                    action="casino_roulette", amount=bet,
                    details={"bet_type": kind, "number": number, "landed": landed, "payout_cents": payout, "net_cents": net},
                )
                selection = f"{kind} {number}" if number is not None else kind
                return CasinoReceipt(
                    game="roulette", bet_cents=bet, payout_cents=payout, net_cents=net,
                    outcome=outcome,
                    message=self._receipt_message("Roulette", bet, payout, net, f"Bet: {selection}; wheel: {landed} ({outcome['color']})."),
                )

    async def use_lottery_ticket(self, user_id: int) -> CasinoReceipt:
        """Consume one shop ticket and run the staged, negative-EV prize draw."""
        item = self.items.get("lottery_ticket")
        if item is None:
            raise RuntimeError("Validated item catalog is missing lottery_ticket.")
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._active_character(tx, user_id)
                self._check_gambling_eligibility(character)
                bet = self._scaled_price(int(item["base_price_cents"]), character.price_index)
                if bet < 100 or bet > min(CASINO_MAX_BET_BASE_CENTS * character.price_index, MAX_CENTS):
                    raise ValidationError("This ticket's face value is outside the casino wager limits.")
                await self._reserve_bet(
                    tx, character=character, user_id=user_id, bet_cents=bet,
                    now=now, count_for_limit=True, enforce_cooldown=True,
                )
                if await self.repository.consume_inventory_item(tx, character.char_id, "lottery_ticket") is None:
                    raise ValidationError("You do not have an available lottery ticket in your inventory.")
                roll = self.rng.randrange(10_000_000)
                if roll == 0:
                    tier, base_prize = "jackpot", GameBalance.CASINO_LOTTERY_JACKPOT_CENTS
                elif 1 <= roll <= 100:
                    tier, base_prize = "$10,000 tier", 1_000_000
                elif 101 <= roll <= 10_100:
                    tier, base_prize = "$100 tier", 10_000
                elif 10_101 <= roll <= 110_100:
                    tier, base_prize = "$10 tier", 1_000
                elif 110_101 <= roll <= 1_110_100:
                    tier, base_prize = "$2.50 tier", 250
                else:
                    tier, base_prize = "no prize", 0
                payout = self._scaled_price(base_prize, character.price_index) if base_prize else 0
                net = payout - bet
                character = self._credit_bank(character, payout)
                character = await self._record_wager_effect(tx, character, bet_cents=bet, net_cents=net, now=now)
                character = await self._save_character(tx, character, version)
                outcome = {"tier": tier, "payout_cents": payout, "ticket_face_value_cents": bet}
                await self.repository.insert_play(
                    tx, char_id=character.char_id, user_id=user_id, age=character.age,
                    game="lottery", bet_cents=bet, status="settled", outcome=outcome, created_at=now,
                    payout_cents=payout, net_cents=net,
                )
                await self.repository.insert_audit(
                    tx, now=now, user_id=user_id, char_id=character.char_id,
                    action="lottery_ticket_used", amount=bet, details=outcome,
                )
                return CasinoReceipt(
                    game="lottery", bet_cents=bet, payout_cents=payout, net_cents=net,
                    outcome=outcome,
                    message=self._receipt_message("Lottery", bet, payout, net, f"Result: {tier}."),
                )

    @staticmethod
    def _scaled_price(base_cents: int, price_index: float) -> int:
        """Scale an integer price by the world index, rounding down for payouts."""
        validate_cents(base_cents)
        factor = Decimal(str(price_index))
        if not factor.is_finite() or factor <= 0:
            raise ValidationError("The current price index is invalid.")
        return validate_cents(int((Decimal(base_cents) * factor).to_integral_value(rounding=ROUND_FLOOR)))

    @staticmethod
    def _receipt_message(title: str, bet: int, payout: int, net: int, detail: str) -> str:
        """Format a game response with both gross return and net result."""
        return f"{title} — {detail} Bet {bet:,}¢; gross return {payout:,}¢; net {net:+,}¢."

    async def blackjack_start(self, user_id: int, bet_cents: int) -> CasinoReceipt:
        """Start a freshly shuffled six-deck hand and persist it before showing buttons."""
        bet = self._validate_bet(bet_cents)
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._active_character(tx, user_id)
                if await self.repository.active_session(tx, character.char_id) is not None:
                    raise ValidationError("You already have an unfinished blackjack hand.")
                await self._reserve_bet(tx, character=character, user_id=user_id, bet_cents=bet, now=now)
                original_balance = character.cash + character.bank
                character, cash_debit, bank_debit = self._deduct(character, bet)
                shoe = self._shuffled_shoe()
                player = [shoe.pop()]
                dealer = [shoe.pop()]
                player.append(shoe.pop())
                dealer.append(shoe.pop())
                state = {
                    "shoe": shoe,
                    "player": player,
                    "dealer": dealer,
                    "doubled": False,
                    "original_balance": original_balance,
                }
                player_natural = self._is_natural(player)
                dealer_natural = self._is_natural(dealer)
                if player_natural or dealer_natural:
                    if player_natural and dealer_natural:
                        payout, result = bet, "push: both have blackjack"
                    elif player_natural:
                        payout, result = bet + bet * 3 // 2, "natural blackjack"
                    else:
                        payout, result = 0, "dealer natural blackjack"
                    net = payout - bet
                    character = self._credit_bank(character, payout)
                    character = await self._record_wager_effect(tx, character, bet_cents=bet, net_cents=net, now=now)
                    character = await self._save_character(tx, character, version)
                    outcome = {"player": player, "dealer": dealer, "result": result, "payout_cents": payout}
                    await self.repository.insert_play(
                        tx, char_id=character.char_id, user_id=user_id, age=character.age,
                        game="blackjack", bet_cents=bet, status="settled", outcome=outcome, created_at=now,
                        payout_cents=payout, net_cents=net,
                    )
                    await self.repository.insert_audit(
                        tx, now=now, user_id=user_id, char_id=character.char_id,
                        action="casino_blackjack", amount=bet, details={**outcome, "net_cents": net},
                    )
                    return CasinoReceipt(
                        game="blackjack", bet_cents=bet, payout_cents=payout, net_cents=net,
                        outcome=outcome,
                        message=self._receipt_message("Blackjack", bet, payout, net, result),
                    )

                character = await self._record_wager_effect(tx, character, bet_cents=bet, net_cents=None, now=now)
                play_id = await self.repository.insert_play(
                    tx, char_id=character.char_id, user_id=user_id, age=character.age,
                    game="blackjack", bet_cents=bet, status="pending",
                    outcome={"player": player, "dealer_up": dealer[0]}, created_at=now,
                )
                nonce = secrets.token_urlsafe(16)
                expires_at = now + CASINO_SESSION_TIMEOUT_SECONDS
                session_id = await self.repository.insert_session(
                    tx, play_id=play_id, char_id=character.char_id, user_id=user_id,
                    nonce=nonce, bet_cents=bet, escrow_cash=cash_debit, escrow_bank=bank_debit,
                    state=state, now=now, expires_at=expires_at,
                )
                character = await self._save_character(tx, character, version)
                await self.repository.insert_audit(
                    tx, now=now, user_id=user_id, char_id=character.char_id,
                    action="casino_blackjack_started", amount=bet,
                    details={"session_id": session_id, "expires_at": expires_at},
                )
                outcome = {"player": player, "dealer_up": dealer[0], "dealer_hidden": True,
                           "player_total": self._hand_total(player)[0]}
                return CasinoReceipt(
                    game="blackjack", bet_cents=bet, payout_cents=None, net_cents=None,
                    outcome=outcome, message=f"Blackjack hand started. Your hand: {self._display_hand(player)} ({outcome['player_total']}). Dealer shows {dealer[0]}. Choose Hit, Stand, or Double.",
                    status="active", session_id=session_id, nonce=nonce, expires_at=expires_at,
                )

    async def blackjack_action(
        self,
        user_id: int,
        session_id: int,
        nonce: str,
        action: str,
        *,
        auto_stand: bool = False,
    ) -> CasinoReceipt:
        """Process a nonce-guarded Hit, Stand, Double, or timeout auto-stand action."""
        selected = "stand" if auto_stand else str(action).lower().strip()
        if selected not in {"hit", "stand", "double"}:
            raise ValidationError("Choose Hit, Stand, or Double.")
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                session = await self.repository.load_session(tx, session_id)
                if session is None or int(session["user_id"]) != user_id:
                    raise ValidationError("That blackjack hand does not belong to you.")
                if session["status"] != "active" or session["nonce"] != nonce:
                    raise ConcurrentUpdate("That blackjack control was already used or expired.")
                character, version = await self._active_character(tx, user_id)
                if character.char_id != int(session["char_id"]):
                    raise ValidationError("This blackjack hand belongs to a different life.")
                self._check_gambling_eligibility(character)
                if not auto_stand and now >= int(session["expires_at"]):
                    selected = "stand"
                    auto_stand = True
                state = json.loads(session["state_json"])
                player = list(state["player"])
                dealer = list(state["dealer"])
                shoe = list(state["shoe"])
                bet = int(session["bet_cents"])
                escrow_cash = int(session["escrow_cash"])
                escrow_bank = int(session["escrow_bank"])
                if selected == "double":
                    if len(player) != 2 or bool(state.get("doubled")):
                        raise ValidationError("Double is available only on your first two cards.")
                    total_wager = bet * 2
                    if total_wager > min(int(state["original_balance"]), self._scaled_price(CASINO_MAX_BET_BASE_CENTS, character.price_index)):
                        raise ValidationError("Doubling would exceed the maximum allowed wager.")
                    await self._check_additional_bet(tx, character, bet)
                    character, extra_cash, extra_bank = self._deduct(character, bet)
                    escrow_cash += extra_cash
                    escrow_bank += extra_bank
                    bet = total_wager
                    player.append(shoe.pop())
                    state["doubled"] = True
                    state["player"] = player
                    state["shoe"] = shoe
                    state["dealer"] = dealer
                    state["original_balance"] = int(state["original_balance"])
                    character = await self._record_wager_effect(tx, character, bet_cents=bet // 2, net_cents=None, now=now)
                    await self.repository.update_play_bet(
                        tx, int(session["play_id"]), bet,
                        {"player": player, "dealer_up": dealer[0], "doubled": True},
                    )
                    return await self._settle_blackjack(
                        tx, session=session, character=character, version=version, nonce=nonce,
                        state=state, bet=bet, escrow_cash=escrow_cash, escrow_bank=escrow_bank,
                        now=now, forced_stand=True,
                    )
                if selected == "hit":
                    player.append(shoe.pop())
                    state["player"] = player
                    state["shoe"] = shoe
                    state["dealer"] = dealer
                    if self._hand_total(player)[0] > 21:
                        state["result"] = "player bust"
                        return await self._settle_blackjack(
                            tx, session=session, character=character, version=version, nonce=nonce,
                            state=state, bet=bet, escrow_cash=escrow_cash, escrow_bank=escrow_bank,
                            now=now, forced_stand=True,
                        )
                    if self._hand_total(player)[0] == 21:
                        state["result"] = "player 21 stands"
                        return await self._settle_blackjack(
                            tx, session=session, character=character, version=version, nonce=nonce,
                            state=state, bet=bet, escrow_cash=escrow_cash, escrow_bank=escrow_bank,
                            now=now, forced_stand=True,
                        )
                    new_nonce = secrets.token_urlsafe(16)
                    expires_at = now + CASINO_SESSION_TIMEOUT_SECONDS
                    state["dealer"] = dealer
                    state["shoe"] = shoe
                    await self.repository.save_session_state(
                        tx, session_id=session_id, expected_nonce=nonce, nonce=new_nonce,
                        bet_cents=bet, escrow_cash=escrow_cash, escrow_bank=escrow_bank,
                        state=state, expires_at=expires_at,
                    )
                    updated = await self._save_character(tx, character, version)
                    outcome = {"player": player, "dealer_up": dealer[0], "dealer_hidden": True,
                               "player_total": self._hand_total(player)[0]}
                    return CasinoReceipt(
                        game="blackjack", bet_cents=bet, payout_cents=None, net_cents=None,
                        outcome=outcome,
                        message=f"Your hand: {self._display_hand(player)} ({outcome['player_total']}). Dealer shows {dealer[0]}.",
                        status="active", session_id=session_id, nonce=new_nonce, expires_at=expires_at,
                    )
                return await self._settle_blackjack(
                    tx, session=session, character=character, version=version, nonce=nonce,
                    state=state, bet=bet, escrow_cash=escrow_cash, escrow_bank=escrow_bank,
                    now=now, forced_stand=True,
                )

    async def _check_additional_bet(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        amount: int,
    ) -> None:
        """Reserve the annual limit for an added double-down wager, without another 3s delay."""
        if amount < 100 or character.cash + character.bank < amount:
            raise InsufficientFunds("You do not have enough available cash or bank balance to double.")
        count = await self.repository.reserve_yearly_bet(tx, character.char_id, character.age, CASINO_MAX_BETS_PER_YEAR)
        if count < 0:
            raise ValidationError(f"You have reached the limit of {CASINO_MAX_BETS_PER_YEAR} bets this in-game year.")

    async def _settle_blackjack(
        self,
        tx: aiosqlite.Connection,
        *,
        session: dict[str, Any],
        character: Character,
        version: int,
        nonce: str,
        state: dict[str, Any],
        bet: int,
        escrow_cash: int,
        escrow_bank: int,
        now: int,
        forced_stand: bool,
    ) -> CasinoReceipt:
        """Reveal the dealer, apply soft-17/natural rules, and settle the ledger once."""
        player = list(state["player"])
        dealer = list(state["dealer"])
        shoe = list(state["shoe"])
        player_total, _ = self._hand_total(player)
        player_natural = self._is_natural(player)
        if player_total <= 21:
            while self._dealer_hits(dealer):
                dealer.append(shoe.pop())
        dealer_total, _ = self._hand_total(dealer)
        dealer_natural = self._is_natural(dealer)
        if player_total > 21:
            payout, result = 0, "player bust"
        elif player_natural and not dealer_natural:
            payout, result = bet + bet * 3 // 2, "natural blackjack pays 3:2"
        elif dealer_natural and not player_natural:
            payout, result = 0, "dealer natural blackjack"
        elif dealer_total > 21 or player_total > dealer_total:
            payout, result = bet * 2, "player wins"
        elif player_total == dealer_total:
            payout, result = bet, "push"
        else:
            payout, result = 0, "dealer wins"
        net = payout - bet
        character = self._credit_bank(character, payout)
        character = await self._save_character(tx, character, version)
        await self._record_net(tx, character.char_id, net)
        outcome = {
            "player": player, "dealer": dealer, "player_total": player_total,
            "dealer_total": dealer_total, "result": result, "payout_cents": payout,
            "doubled": bool(state.get("doubled", False)), "auto_stand": forced_stand,
        }
        if not await self.repository.finish_session(tx, int(session["session_id"]), nonce, "settled", now):
            raise ConcurrentUpdate("That blackjack hand was already settled.")
        await self.repository.settle_play(
            tx, play_id=int(session["play_id"]), bet_cents=bet, payout_cents=payout,
            net_cents=net, status="settled", outcome=outcome, resolved_at=now,
        )
        await self.repository.insert_audit(
            tx, now=now, user_id=int(session["user_id"]), char_id=character.char_id,
            action="casino_blackjack_settled", amount=bet, details=outcome,
        )
        message = self._receipt_message(
            "Blackjack", bet, payout, net,
            f"{result}. Your hand {self._display_hand(player)} ({player_total}); dealer {self._display_hand(dealer)} ({dealer_total}).",
        )
        return CasinoReceipt(
            game="blackjack", bet_cents=bet, payout_cents=payout, net_cents=net,
            outcome=outcome, message=message, status="settled", session_id=int(session["session_id"]),
        )

    async def recover_sessions(self) -> int:
        """Refund every active blackjack escrow exactly once during startup recovery."""
        now = int(self.clock())
        recovered = 0
        async with self.db.transaction() as tx:
            sessions = await self.repository.active_sessions(tx)
            for session in sessions:
                record = await self.repository.character_record(tx, int(session["char_id"]))
                if record is None:
                    # The foreign key normally prevents this; fail loudly so the startup transaction rolls back.
                    raise RuntimeError(f"Blackjack session {session['session_id']} has no character to refund.")
                character = Character.from_dict(json.loads(record["data_json"]))
                cash_refund = int(session["escrow_cash"])
                bank_refund = int(session["escrow_bank"])
                character = replace(
                    character,
                    cash=validate_cents(character.cash + cash_refund),
                    bank=validate_cents(character.bank + bank_refund),
                    version=int(record["version"]) + 1,
                )
                await self.repository.save_character_any_life(tx, character, int(record["version"]))
                if not await self.repository.finish_session(tx, int(session["session_id"]), str(session["nonce"]), "refunded", now):
                    raise ConcurrentUpdate("A blackjack session changed during startup recovery.")
                await self.repository.settle_play(
                    tx, play_id=int(session["play_id"]), bet_cents=int(session["bet_cents"]),
                    payout_cents=int(session["bet_cents"]), net_cents=0, status="refunded",
                    outcome={"reason": "startup recovery", "cash_refund_cents": cash_refund,
                             "bank_refund_cents": bank_refund}, resolved_at=now,
                )
                await self.repository.insert_audit(
                    tx, now=now, user_id=int(session["user_id"]), char_id=character.char_id,
                    action="casino_blackjack_restart_refund", amount=int(session["bet_cents"]),
                    details={"session_id": int(session["session_id"]), "cash_refund_cents": cash_refund,
                             "bank_refund_cents": bank_refund},
                )
                recovered += 1
        return recovered

    async def use_rehab(self, user_id: int) -> tuple[int, int]:
        """Consume one recovery-program item and reduce integer addiction by 20 points."""
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, version = await self._active_character(tx, user_id)
                if character.age < 18:
                    raise ValidationError("Gambling recovery treatment is available from age 18.")
                item = self.items.get("gambling_rehab")
                if item is None:
                    raise RuntimeError("Validated item catalog is missing gambling_rehab.")
                if await self.repository.consume_inventory_item(tx, character.char_id, "gambling_rehab") is None:
                    raise ValidationError("You do not have a recovery-program item to use.")
                before = character.stats.addiction
                treatment_delta = int(item["effects_on_use"]["stats"].get("addiction", -20))
                if treatment_delta >= 0:
                    raise RuntimeError("Validated gambling recovery item must reduce addiction.")
                after = max(0, before + treatment_delta)
                if after == before:
                    raise ValidationError("Your gambling addiction is already at zero.")
                character = replace(character, stats=replace(character.stats, addiction=after))
                if after >= 60:
                    severity = min(5, max(1, 1 + (after - 60) // 8))
                    await self.repository.upsert_condition(
                        tx, char_id=character.char_id, disease_id=GAMBLING_DISEASE_ID,
                        severity=severity, age=character.age, now=now, active=True,
                    )
                elif await self.repository.condition_exists(tx, character.char_id, GAMBLING_DISEASE_ID):
                    await self.repository.upsert_condition(
                        tx, char_id=character.char_id, disease_id=GAMBLING_DISEASE_ID,
                        severity=1, age=character.age, now=now, active=False,
                    )
                    await self.repository.save_tracking(tx, char_id=character.char_id, addiction_fraction=0.0)
                character = await self._save_character(tx, character, version)
                await self.repository.insert_audit(
                    tx, now=now, user_id=user_id, char_id=character.char_id,
                    action="gambling_rehab_used", amount=0,
                    details={"addiction_before": before, "addiction_after": after},
                )
                return before, after

    async def advance_year(
        self,
        tx: aiosqlite.Connection,
        character: Character,
        *,
        previous_age: int,
        now: int,
    ) -> CasinoYearProgress:
        """Assess 24% gambling-winnings tax over $5,000 and maybe schedule a compulsion choice."""
        messages: list[str] = []
        existing = await self.repository.load_yearly_tax(tx, character.char_id, previous_age)
        if existing is None:
            gambling_net = await self.repository.plays_net_for_age(tx, character.char_id, previous_age)
            taxable = max(0, gambling_net - 500_000)
            tax = self._percent_ceiling(taxable, 24)
            character, paid, unpaid = self._collect_tax(character, tax)
            await self.repository.upsert_yearly_tax(
                tx, char_id=character.char_id, age=previous_age,
                gambling_net=gambling_net, gambling_tax=tax,
                capital_gain=0, capital_tax=0, now=now,
            )
            if tax:
                messages.append(
                    f"Gambling winnings tax: {tax:,}¢ assessed on {max(0, gambling_net - 500_000):,}¢ above the 500,000¢ annual allowance; paid {paid:,}¢"
                    + (f"; {unpaid:,}¢ added to tax debt." if unpaid else ".")
                )
        prompt = None
        if character.is_alive and character.stats.addiction >= 60 and not character.in_prison:
            pending = await self.repository.pending_compulsion(tx, character.char_id)
            if pending is None and self.rng.random() < 0.25:
                available = character.cash + character.bank
                maximum = self.max_bet_cents(character)
                forced_bet = min(1_000, available, maximum)
                if forced_bet >= 100:
                    nonce = secrets.token_urlsafe(18)
                    compulsion_id = await self.repository.insert_compulsion(
                        tx, character.char_id, character.age, nonce, forced_bet, now
                    )
                    prompt = {
                        "compulsion_id": compulsion_id,
                        "nonce": nonce,
                        "forced_bet_cents": forced_bet,
                        "expires_at": now + 300,
                    }
                    messages.append("Gambling addiction triggered a compulsion choice.")
        return CasinoYearProgress(character=character, messages=tuple(messages), compulsion=prompt)

    async def resolve_compulsion(
        self,
        user_id: int,
        compulsion_id: int,
        nonce: str,
        choice: str,
    ) -> CompulsionReceipt:
        """Resolve a nonce-protected resist/indulge choice as one atomic casino action."""
        selected = str(choice).lower().strip()
        if selected not in {"resist", "indulge"}:
            raise ValidationError("Choose resist or indulge.")
        now = int(self.clock())
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                prompt = await self.repository.load_compulsion(tx, compulsion_id)
                character, version = await self._active_character(tx, user_id)
                if prompt is None or int(prompt["char_id"]) != character.char_id or int(prompt["age"]) != character.age:
                    raise ValidationError("That compulsion choice does not belong to your current life year.")
                if prompt["nonce"] != nonce or prompt["status"] != "pending":
                    raise ConcurrentUpdate("That compulsion choice was already resolved or has expired.")
                if now > int(prompt["created_at"]) + 300:
                    message = "That compulsion choice expired; no wager was placed."
                    await self.repository.resolve_compulsion(
                        tx, compulsion_id, nonce, "expired", now, message
                    )
                    return CompulsionReceipt(status="expired", message=message)
                if selected == "resist":
                    character = replace(
                        character,
                        stats=replace(
                            character.stats,
                            stress=min(100, character.stats.stress + 5),
                            happiness=max(0, character.stats.happiness - 2),
                        ),
                    )
                    character = await self._save_character(tx, character, version)
                    message = "You resisted the gambling compulsion. Stress rose slightly, but no wager was placed."
                    await self.repository.resolve_compulsion(tx, compulsion_id, nonce, "resisted", now, message)
                    await self.repository.insert_audit(
                        tx, now=now, user_id=user_id, char_id=character.char_id,
                        action="gambling_compulsion_resisted", amount=0, details={"compulsion_id": compulsion_id},
                    )
                    return CompulsionReceipt(status="resisted", message=message)
                bet = int(prompt["forced_bet_cents"])
                self._check_gambling_eligibility(character)
                await self._reserve_bet(
                    tx, character=character, user_id=user_id, bet_cents=bet, now=now,
                    count_for_limit=True, enforce_cooldown=True,
                )
                character, cash_debit, bank_debit = self._deduct(character, bet)
                chosen = self.rng.choice(("heads", "tails"))
                landed = self.rng.choice(("heads", "tails"))
                payout = bet * 194 // 100 if chosen == landed else 0
                net = payout - bet
                character = self._credit_bank(character, payout)
                character = await self._record_wager_effect(tx, character, bet_cents=bet, net_cents=net, now=now)
                character = await self._save_character(tx, character, version)
                outcome = {"chosen": chosen, "landed": landed, "forced": True,
                           "cash_debit": cash_debit, "bank_debit": bank_debit}
                await self.repository.insert_play(
                    tx, char_id=character.char_id, user_id=user_id, age=character.age,
                    game="coinflip", bet_cents=bet, status="settled", outcome=outcome, created_at=now,
                    payout_cents=payout, net_cents=net,
                )
                message = self._receipt_message("Compulsion", bet, payout, net, f"Forced coinflip chose {chosen}; it landed {landed}.")
                if not await self.repository.resolve_compulsion(tx, compulsion_id, nonce, "indulged", now, message):
                    raise ConcurrentUpdate("That compulsion was already resolved.")
                await self.repository.insert_audit(
                    tx, now=now, user_id=user_id, char_id=character.char_id,
                    action="gambling_compulsion_indulged", amount=bet, details={**outcome, "payout_cents": payout},
                )
                receipt = CasinoReceipt("coinflip", bet, payout, net, outcome, message)
                return CompulsionReceipt(status="indulged", message=message, receipt=receipt)

    @staticmethod
    def _collect_tax(character: Character, tax_cents: int) -> tuple[Character, int, int]:
        """Pay assessed taxes without negative balances; unpaid amount becomes explicit debt."""
        validate_cents(tax_cents)
        if tax_cents <= 0:
            return character, 0, 0
        cash_paid = min(character.cash, tax_cents)
        remaining = tax_cents - cash_paid
        bank_paid = min(character.bank, remaining)
        unpaid = remaining - bank_paid
        updated = replace(
            character,
            cash=character.cash - cash_paid,
            bank=character.bank - bank_paid,
            debt_total=validate_cents(character.debt_total + unpaid),
        )
        return updated, cash_paid + bank_paid, unpaid

    @staticmethod
    def _percent_ceiling(amount_cents: int, percent: int) -> int:
        """Round a percentage charge upward, as required for fees/taxes."""
        validate_cents(amount_cents)
        if amount_cents <= 0:
            return 0
        return (amount_cents * percent + 99) // 100

    @staticmethod
    def _new_shoe() -> list[str]:
        """Create the ordered cards for exactly six standard 52-card decks."""
        ranks = ("A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K")
        suits = ("♠", "♥", "♦", "♣")
        shoe = [rank + suit for _ in range(6) for suit in suits for rank in ranks]
        return shoe

    def _shuffled_shoe(self) -> list[str]:
        """Return a six-deck card shoe shuffled by the service RNG."""
        shoe = self._new_shoe()
        self.rng.shuffle(shoe)
        return shoe

    @classmethod
    def _hand_total(cls, cards: Sequence[str]) -> tuple[int, bool]:
        """Compute blackjack total and whether an ace is currently counted as eleven."""
        total = 0
        aces = 0
        for card in cards:
            rank = str(card)[:-1]
            if rank == "A":
                total += 11
                aces += 1
            elif rank in {"K", "Q", "J", "10"}:
                total += 10
            else:
                total += int(rank)
        while total > 21 and aces > 0:
            total -= 10
            aces -= 1
        return total, aces > 0

    @classmethod
    def _is_natural(cls, cards: Sequence[str]) -> bool:
        """Return true for a two-card ace plus ten-valued natural blackjack."""
        return len(cards) == 2 and cls._hand_total(cards)[0] == 21

    @classmethod
    def _dealer_hits(cls, cards: Sequence[str]) -> bool:
        """Dealer stands on every soft or hard 17."""
        total, _ = cls._hand_total(cards)
        return total < 17

    @staticmethod
    def _display_hand(cards: Sequence[str]) -> str:
        """Render a short human-readable card list."""
        return " ".join(str(card) for card in cards)

    @staticmethod
    def _format_cards_masked(cards: Sequence[str]) -> str:
        """Render the dealer's up-card and conceal the hole card."""
        return f"{cards[0]} 🂠" if len(cards) > 1 else (cards[0] if cards else "—")

    async def require_no_active_hand(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Prevent annual aging while an escrowed blackjack hand is unresolved."""
        if await self.repository.has_active_session(tx, char_id):
            raise ValidationError("Finish your active blackjack hand before `/life age`.")

    async def require_no_pending_compulsion(self, tx: aiosqlite.Connection, char_id: int) -> None:
        """Require a choice or expire it after five minutes before another age tick."""
        prompt = await self.repository.pending_compulsion(tx, char_id)
        if prompt is None:
            return
        now = int(self.clock())
        if now > int(prompt["created_at"]) + 300:
            await self.repository.resolve_compulsion(
                tx, int(prompt["compulsion_id"]), str(prompt["nonce"]),
                "expired", now, "The compulsion choice expired; no wager was placed.",
            )
            return
        raise ValidationError("Resolve your pending gambling-compulsion choice before `/life age`.")

    async def get_pending_compulsion(self, user_id: int) -> dict[str, Any]:
        """Return the current life’s persisted choice so the owner can reopen its buttons."""
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, _ = await self._active_character(tx, user_id)
                prompt = await self.repository.pending_compulsion(tx, character.char_id)
                if prompt is None:
                    raise ValidationError("You have no pending gambling-compulsion choice.")
                return prompt
