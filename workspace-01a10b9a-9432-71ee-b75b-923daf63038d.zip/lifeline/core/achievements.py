"""Authoritative Stage 10 achievement evaluation and idempotent unlocks."""
from __future__ import annotations

import json
import time
from typing import Any, Callable, Optional

import aiosqlite

from .data_loader import DataLoader
from .locks import UserLockRegistry
from .models import Character, EducationLevel
from .repositories.legacy import LegacyRepository
from .validators import validate_achievement_catalog, validate_item_catalog

_EDUCATION_RANK = {
    EducationLevel.NONE.value: 0,
    EducationLevel.PRIMARY.value: 1,
    EducationLevel.HIGH_SCHOOL.value: 2,
    EducationLevel.BACHELOR.value: 3,
    EducationLevel.MASTER.value: 4,
    EducationLevel.DOCTORATE.value: 5,
}


class AchievementService:
    """Evaluate validated rules only from persisted game records and character state."""

    def __init__(
        self,
        db: Any,
        locks: Optional[UserLockRegistry] = None,
        *,
        clock: Callable[[], float] = time.time,
        data_loader: Optional[DataLoader] = None,
    ) -> None:
        self.db = db
        self.locks = locks or UserLockRegistry()
        self.clock = clock
        self.repository = LegacyRepository(db)
        loader = data_loader or DataLoader()
        self.definitions = tuple(loader.load_achievements()["achievements"])
        self.items = {str(row["id"]): dict(row) for row in loader.load_items()["items"]}
        self._pending_notifications: dict[int, list[dict[str, Any]]] = {}

    def replace_catalogs(self, achievements: dict[str, Any], items: dict[str, Any]) -> None:
        """Validate and atomically replace achievement and item references."""
        validate_achievement_catalog(achievements)
        validate_item_catalog(items)
        new_definitions = tuple(dict(row) for row in achievements["achievements"])
        new_items = {str(row["id"]): dict(row) for row in items["items"]}
        self.definitions = new_definitions
        self.items = new_items

    async def check_user(
        self, user_id: int, *, now: Optional[int] = None, guild_id: Optional[int] = None
    ) -> list[dict[str, Any]]:
        """Recompute all eligible unlocks from the user's authoritative database state."""
        timestamp = int(self.clock()) if now is None else int(now)
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                unlocked = await self.check_user_in_tx(
                    tx, user_id, now=timestamp, guild_id=guild_id
                )
        self.queue_notifications(user_id, unlocked)
        return unlocked

    async def check_user_in_tx(
        self,
        tx: aiosqlite.Connection,
        user_id: int,
        *,
        now: Optional[int] = None,
        guild_id: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """Unlock achievements inside an existing tick/action transaction, exactly once."""
        timestamp = int(self.clock()) if now is None else int(now)
        await self.repository.ensure_player(tx, user_id, timestamp)
        if guild_id is not None and guild_id > 0:
            await self.repository.record_guild_seen(tx, guild_id, user_id, timestamp)
        active = await self.repository.active_character(tx, user_id)
        if active is not None:
            character = Character.from_dict(json.loads(active["data_json"]))
            await self.repository.record_life_year(
                tx, character=character, age=character.age,
                served_prison_year=False, now=timestamp,
            )
        rows = await self.repository.user_character_rows(tx, user_id)
        rows.sort(key=lambda row: (not bool(row["is_alive"]), -int(row["char_id"])))
        unlocked: list[dict[str, Any]] = []
        for row in rows:
            character = Character.from_dict(json.loads(row["data_json"]))
            character.char_id = int(row["char_id"])
            character.user_id = int(row["user_id"])
            facts = await self._facts(tx, character)
            for definition in self.definitions:
                if not self._matches(definition, facts):
                    continue
                inserted = await self.repository.insert_achievement(
                    tx,
                    user_id=user_id,
                    achievement_id=str(definition["id"]),
                    char_id=character.char_id,
                    now=timestamp,
                )
                if inserted:
                    unlocked.append({**definition, "char_id": character.char_id})
        return unlocked

    def queue_notifications(self, user_id: int, achievements: list[dict[str, Any]] | tuple[dict[str, Any], ...]) -> None:
        """Queue committed unlocks for delivery by the next interaction response."""
        if achievements:
            self._pending_notifications.setdefault(int(user_id), []).extend(
                dict(row) for row in achievements
            )

    def consume_notifications(self, user_id: int) -> list[dict[str, Any]]:
        """Return and remove achievements waiting for the next interaction response."""
        return self._pending_notifications.pop(user_id, [])

    async def list_for_user(self, user_id: int, *, now: Optional[int] = None) -> list[dict[str, Any]]:
        """Return unlocked achievements with catalog descriptions and character names."""
        await self.check_user(user_id, now=now)
        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                rows = await self.repository.user_achievements(tx, user_id)
        definitions = {str(row["id"]): row for row in self.definitions}
        result: list[dict[str, Any]] = []
        for row in rows:
            definition = definitions.get(str(row["achievement_id"]))
            if definition is not None:
                result.append({**definition, **row})
        return result

    async def _facts(self, tx: aiosqlite.Connection, character: Character) -> dict[str, Any]:
        """Derive one life's eligibility facts from persisted records, never caller input."""
        char_id = character.char_id
        economy = await self.repository.economy_snapshot(tx, char_id)
        metrics = await self.repository.life_year_metrics(tx, char_id)
        peak = max(
            [economy["net_worth_cents"]]
            + [int(row["peak_net_worth_cents"]) for row in metrics]
        )
        average_happiness = (
            sum(int(row["happiness"]) for row in metrics) / len(metrics) if metrics else float(character.stats.happiness)
        )
        min_historical_worth = min(
            [economy["net_worth_cents"]] + [int(row["net_worth_cents"]) for row in metrics]
        )
        children = await self.repository.child_count(tx, char_id)
        marriage_count = await self.repository.marriage_count(tx, char_id)
        marriage_years = await self.repository.max_marriage_years(tx, char_id, character.age)
        divorces = await self.repository.divorce_count(tx, char_id)
        education = await self.repository.education_rows(tx, char_id)
        education_rank = _EDUCATION_RANK.get(character.education_level.value, 0)
        max_gpa = max(float(character.gpa or 0.0), float(education["max_gpa"]))
        careers = await self.repository.career_history(tx, char_id)
        job = await self.repository.active_job(tx, char_id)
        career_level = max(
            [int(row["max_level"]) for row in careers]
            + ([int(job["level"])] if job is not None else [0])
        )
        career_count = len(careers)
        career_years = 0
        for history in careers:
            if history["end_age"] is not None:
                career_years += max(0, int(history["end_age"]) - int(history["start_age"]))
            elif job is not None:
                career_years += max(0, int(job["years_in_career"]))
        if job is not None and not careers:
            career_years += max(0, int(job["years_in_career"]))
        level_two_careers = sum(1 for row in careers if int(row["max_level"]) >= 2)
        crime = await self.repository.crime_summary(tx, char_id)
        tracking = await self.repository.stats_tracking(tx, char_id)
        casino_rows = await self.repository.casino_rows(tx, char_id)
        settled_casino: list[dict[str, Any]] = []
        max_bet = 0
        jackpot = False
        lottery_win = False
        blackjack_wins = 0
        for row in casino_rows:
            if str(row["status"]) != "settled":
                continue
            settled_casino.append(row)
            max_bet = max(max_bet, int(row["bet_cents"]))
            try:
                outcome = json.loads(str(row["outcome_json"]))
            except (TypeError, json.JSONDecodeError):
                outcome = {}
            if str(row["game"]) == "lottery":
                if outcome.get("tier") == "jackpot":
                    jackpot = True
                if int(row["payout_cents"] or 0) > 0:
                    lottery_win = True
            if str(row["game"]) == "blackjack":
                result = str(outcome.get("result", "")).lower()
                if result in {"player wins", "natural blackjack pays 3:2"} or "natural blackjack" in result:
                    blackjack_wins += 1
        investment = await self.repository.investment_rows(tx, char_id)
        item_facts = await self.repository.item_facts(tx, char_id)
        item_ids = [str(row["item_id"]) for row in item_facts["item_rows"]]
        categories = {
            self.items[item_id]["category"]
            for item_id in item_ids if item_id in self.items
        }
        home_count = sum(
            1 for row in item_facts["item_rows"]
            if row["item_id"] in self.items and self.items[str(row["item_id"])]["category"] == "housing"
        )
        profiles = crime["profile"]
        past = await self.repository.past_life(tx, char_id)
        completed_naturally = (past is not None and not bool(past["abandoned"])) or (
            not character.is_alive and character.death_cause != "Life abandoned"
        )
        bankrupted = (
            economy["debts_cents"] > economy["gross_assets_cents"]
            or min_historical_worth < 0
            or await self.repository.bankruptcy_count(tx, char_id) > 0
        )
        clean_record = int(crime["convictions"]) == 0
        return {
            "age": character.age,
            "death_age": character.death_age,
            "is_alive": character.is_alive,
            "natural_death": (past is not None and not bool(past["abandoned"])) or (
                not character.is_alive and character.death_cause != "Life abandoned"
            ),
            "education_rank": education_rank,
            "education_level": character.education_level.value,
            "peak_net_worth_cents": peak,
            "net_worth_cents": economy["net_worth_cents"],
            "born_poor": character.wealth_class.lower() == "poor",
            "children": children,
            "marriage_count": marriage_count,
            "marriage_years": marriage_years,
            "prison_years": int(crime["years_in_prison"]),
            "crime_level": max(0, int(profiles.get("career_level", 0))),
            "escaped": crime["escaped"],
            "convictions": int(crime["convictions"]),
            "sealed_convictions": int(crime["sealed_convictions"]),
            "successes": int(crime["successes"]),
            "max_bet_cents": max_bet,
            "jackpot": jackpot,
            "bankrupt": bankrupted,
            "divorces": divorces,
            "max_gpa": max_gpa,
            "career_level": career_level,
            "executive_role": career_level >= 3,
            "career_count": career_count,
            "career_years": career_years,
            "level_two_careers": level_two_careers,
            "fame": character.stats.fame,
            "study_actions": int(education["study_actions"]),
            "hard_study_actions": int(education["hard_study_actions"]),
            "generation": character.generation,
            "clean_centenarian": character.age >= 100 and clean_record,
            "business_asset": "business" in categories,
            "homes": home_count,
            "owns_stock": int(investment["share_count"]) > 0 or any(
                str(row["item_id"]).startswith("stock_") for row in item_facts["item_rows"]
            ),
            "stock_trades": int(investment["trade_count"]),
            "matured_bond": int(investment["matured_bonds"]) > 0,
            "rental_income": int(investment["rental_income_cents"]) > 0,
            "debt_free": economy["debts_cents"] == 0,
            "completed_life": completed_naturally,
            "lottery_win": lottery_win,
            "blackjack_wins": blackjack_wins,
            "casino_plays": len(settled_casino),
            "average_happiness": average_happiness,
            "karma": character.stats.karma,
            "rehab_used": await self.repository.rehab_used(tx, char_id),
            "addiction_free_after_gambling": character.stats.addiction < 10 and tracking["total_gambled"] > 0,
            "salary_cents": int(job["salary"]) if job is not None else 0,
            "asset_lots": int(item_facts["asset_lots"]),
            "happiness": character.stats.happiness,
            "fitness": character.stats.fitness,
            "smarts": character.stats.smarts,
            "crime_recovery": int(crime["sealed_convictions"]) > 0 and clean_record,
            "total_gambled": int(tracking["total_gambled"]),
            "gambling_net": int(tracking["total_gambling_net"]),
            "financial_comeback": min_historical_worth < 0 and peak > 0,
            "no_convictions": clean_record,
        }

    @staticmethod
    def _matches(definition: dict[str, Any], facts: dict[str, Any]) -> bool:
        """Evaluate one validated rule against server-derived life facts."""
        rule = str(definition["rule"])
        target = definition["threshold"]
        if rule == "age_at_least":
            return facts["age"] >= target
        if rule == "education_at_least":
            return facts["education_rank"] >= _EDUCATION_RANK[str(target)]
        if rule == "peak_net_worth_at_least":
            return facts["peak_net_worth_cents"] >= target
        if rule == "rags_to_riches":
            return facts["born_poor"] and facts["peak_net_worth_cents"] >= target
        if rule == "marriage_years_at_least":
            return facts["marriage_years"] >= target
        if rule == "children_at_least":
            return facts["children"] >= target
        if rule == "prison_years_at_least":
            return facts["prison_years"] >= target
        if rule == "convictions_at_least":
            return facts["convictions"] >= target
        if rule == "crime_level_at_least":
            return facts["crime_level"] >= target
        if rule == "escaped":
            return bool(facts["escaped"])
        if rule == "max_bet_at_least":
            return facts["max_bet_cents"] >= target
        if rule == "jackpot":
            return bool(facts["jackpot"])
        if rule == "bankrupt":
            return bool(facts["bankrupt"])
        if rule == "divorces_at_least":
            return facts["divorces"] >= target
        if rule == "gpa_at_least":
            return facts["max_gpa"] >= float(target)
        if rule == "executive_role":
            return bool(facts["executive_role"])
        if rule == "fame_at_least":
            return facts["fame"] >= target
        if rule == "study_actions_at_least":
            return facts["study_actions"] >= target
        if rule == "generation_at_least":
            return facts["generation"] >= target
        if rule == "died_before_age":
            return bool(
                facts["natural_death"] and facts["death_age"] is not None
                and not facts["is_alive"] and int(facts["death_age"]) < target
            )
        if rule == "clean_centenarian":
            return bool(facts["clean_centenarian"])
        if rule == "hard_study_actions_at_least":
            return facts["hard_study_actions"] >= target
        if rule == "career_years_at_least":
            return facts["career_years"] >= target
        if rule == "career_level_at_least":
            return facts["career_level"] >= target
        if rule == "career_count_at_least":
            return facts["career_count"] >= target
        if rule == "business_asset":
            return bool(facts["business_asset"])
        if rule == "homes_at_least":
            return facts["homes"] >= target
        if rule == "owns_stock":
            return bool(facts["owns_stock"])
        if rule == "stock_trades_at_least":
            return facts["stock_trades"] >= target
        if rule == "matured_bond":
            return bool(facts["matured_bond"])
        if rule == "rental_income":
            return bool(facts["rental_income"])
        if rule == "debt_free":
            return bool(facts["debt_free"])
        if rule == "marriages_at_least":
            return facts["marriage_count"] >= target
        if rule == "completed_life":
            return bool(facts["completed_life"])
        if rule == "lottery_win":
            return bool(facts["lottery_win"])
        if rule == "blackjack_wins_at_least":
            return facts["blackjack_wins"] >= target
        if rule == "casino_plays_at_least":
            return facts["casino_plays"] >= target
        if rule == "average_happiness_at_least":
            return facts["average_happiness"] >= target
        if rule == "karma_at_least":
            return facts["karma"] >= target
        if rule == "rehab_used":
            return bool(facts["rehab_used"])
        if rule == "addiction_free_after_gambling":
            return bool(facts["addiction_free_after_gambling"])
        if rule == "salary_at_least":
            return facts["salary_cents"] >= target
        if rule == "asset_lots_at_least":
            return facts["asset_lots"] >= target
        if rule == "happiness_at_least":
            return facts["happiness"] >= target
        if rule == "fitness_at_least":
            return facts["fitness"] >= target
        if rule == "smarts_at_least":
            return facts["smarts"] >= target
        if rule == "crime_recovery":
            return bool(facts["crime_recovery"])
        if rule == "multiple_careers_level_two":
            return facts["level_two_careers"] >= 2
        if rule == "total_gambled_at_least":
            return facts["total_gambled"] >= target
        if rule == "gambling_net_positive":
            return facts["gambling_net"] > 0
        if rule == "financial_comeback":
            return bool(facts["financial_comeback"])
        if rule == "no_convictions":
            return bool(facts["no_convictions"])
        raise ValueError(f"Achievement rule was not implemented: {rule}")
