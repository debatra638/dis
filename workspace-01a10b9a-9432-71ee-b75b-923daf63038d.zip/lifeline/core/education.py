"""School progression, higher-education enrollment, and study actions."""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, replace
from typing import Any, Callable, Optional

import aiosqlite

from .errors import (
    CharacterDead,
    CharacterInPrison,
    CharacterNotFound,
    ConcurrentUpdate,
    EducationRequirementError,
    NotEnrolled,
    PendingEventExists,
    StudyAlreadyUsed,
    ValidationError,
)
from .locks import UserLockRegistry
from .models import Character, EducationLevel, Stats, StudyEffort

EDUCATION_RANK = {
    EducationLevel.NONE: 0,
    EducationLevel.PRIMARY: 1,
    EducationLevel.HIGH_SCHOOL: 2,
    EducationLevel.BACHELOR: 3,
    EducationLevel.MASTER: 4,
    EducationLevel.DOCTORATE: 5,
}

COLLEGE_PROGRAMS = {
    EducationLevel.BACHELOR: (EducationLevel.HIGH_SCHOOL, 4, 1.5),
    EducationLevel.MASTER: (EducationLevel.BACHELOR, 2, 2.0),
    EducationLevel.DOCTORATE: (EducationLevel.MASTER, 4, 2.5),
}

STUDY_EFFECTS = {
    StudyEffort.HARD: {"gpa": 0.30, "smarts": 2, "happiness": -1, "stress": 3},
    StudyEffort.NORMAL: {"gpa": 0.18, "smarts": 1, "happiness": 0, "stress": 1},
    StudyEffort.SLACK: {"gpa": -0.08, "smarts": 0, "happiness": 2, "stress": -1},
}


@dataclass(frozen=True, slots=True)
class EducationProgress:
    """Pure result of school progression during one age advancement."""

    character: Character
    messages: tuple[str, ...] = ()


def advance_school_year(character: Character) -> EducationProgress:
    """Advance mandatory schooling or an enrolled degree by one simulated year.

    The caller supplies a character whose age has already advanced. Starting a new
    school at age six or thirteen does not immediately consume a school year.
    """
    if not character.is_alive or character.in_prison:
        return EducationProgress(character)
    age = character.age
    program = character.school_program
    messages: list[str] = []

    if program is None:
        if age == 6 and EDUCATION_RANK[character.education_level] < EDUCATION_RANK[EducationLevel.PRIMARY]:
            updated = replace(
                character,
                current_school="Primary School",
                school_program=EducationLevel.PRIMARY,
                school_years_left=7,
                gpa=2.5,
                major=None,
            )
            return EducationProgress(updated, ("Started primary school.",))
        if age >= 13 and EDUCATION_RANK[character.education_level] < EDUCATION_RANK[EducationLevel.HIGH_SCHOOL]:
            updated = replace(
                character,
                education_level=EducationLevel.PRIMARY,
                current_school="High School",
                school_program=EducationLevel.HIGH_SCHOOL,
                school_years_left=5,
                gpa=2.5,
                major=None,
            )
            return EducationProgress(updated, ("Started high school.",))
        return EducationProgress(character)

    if program is EducationLevel.PRIMARY:
        if age <= 6:
            return EducationProgress(character)
        years_left = max(0, character.school_years_left - 1)
        if years_left > 0:
            return EducationProgress(replace(character, school_years_left=years_left))

        updated = replace(
            character,
            education_level=EducationLevel.PRIMARY,
            current_school=None,
            school_program=None,
            school_years_left=0,
        )
        messages.append("Completed primary school.")
        if age >= 13 and EDUCATION_RANK[updated.education_level] < EDUCATION_RANK[EducationLevel.HIGH_SCHOOL]:
            updated = replace(
                updated,
                current_school="High School",
                school_program=EducationLevel.HIGH_SCHOOL,
                school_years_left=5,
                gpa=2.5,
                major=None,
            )
            messages.append("Started high school.")
        return EducationProgress(updated, tuple(messages))

    if program is EducationLevel.HIGH_SCHOOL:
        if age <= 13:
            return EducationProgress(character)
        years_left = max(0, character.school_years_left - 1)
        if years_left > 0:
            return EducationProgress(replace(character, school_years_left=years_left))
        updated = replace(
            character,
            education_level=EducationLevel.HIGH_SCHOOL,
            current_school=None,
            school_program=None,
            school_years_left=0,
        )
        return EducationProgress(updated, ("Graduated from high school.",))

    # College, master's, and doctorate programs are started explicitly by the player.
    years_left = max(0, character.school_years_left - 1)
    if years_left > 0:
        return EducationProgress(replace(character, school_years_left=years_left))
    updated = replace(
        character,
        education_level=program,
        current_school=None,
        school_program=None,
        school_years_left=0,
    )
    degree_name = program.value.replace("_", " ").title()
    return EducationProgress(updated, (f"Graduated with a {degree_name} degree.",))


@dataclass(frozen=True, slots=True)
class StudyResult:
    character: Character
    effort: StudyEffort
    gpa_before: float
    gpa_after: float
    stat_changes: dict[str, int]


class EducationService:
    """Database-backed education actions; one study session is allowed per age."""

    def __init__(
        self,
        db: Any,
        locks: Optional[UserLockRegistry] = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.db = db
        self.locks = locks or UserLockRegistry()
        self.clock = clock

    async def status(self, user_id: int) -> Character:
        """Return the current active character, including education state."""
        row = await self.db.fetchone(
            "SELECT data_json FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        if row is None:
            latest = await self.db.fetchone(
                "SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,)
            )
            if latest is not None:
                raise CharacterDead()
            raise CharacterNotFound()
        return Character.from_dict(json.loads(row["data_json"]))

    async def enroll(
        self,
        user_id: int,
        program: EducationLevel | str,
        major: str,
    ) -> Character:
        """Enroll an eligible adult in a bachelor's, master's, or doctorate program."""
        if not isinstance(user_id, int) or user_id <= 0:
            raise ValidationError("A valid Discord user ID is required.")
        try:
            selected_program = program if isinstance(program, EducationLevel) else EducationLevel(str(program).lower())
        except ValueError as exc:
            raise ValidationError("Choose bachelor, master, or doctorate.") from exc
        if selected_program not in COLLEGE_PROGRAMS:
            raise ValidationError("Choose a college program: bachelor, master, or doctorate.")
        clean_major = self._validate_major(major)

        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._load_active(tx, user_id)
                await self._ensure_no_pending_event(tx, character.char_id)
                if character.in_prison:
                    raise CharacterInPrison()
                if character.age < 18:
                    raise EducationRequirementError("You must be at least 18 to enroll in college.")
                if character.school_program is not None or character.current_school is not None:
                    raise EducationRequirementError("Finish your current school program before enrolling again.")

                prerequisite, years, minimum_gpa = COLLEGE_PROGRAMS[selected_program]
                if EDUCATION_RANK[character.education_level] < EDUCATION_RANK[prerequisite]:
                    needed = prerequisite.value.replace("_", " ").title()
                    raise EducationRequirementError(f"You need to complete {needed} before enrolling in this program.")
                if EDUCATION_RANK[selected_program] <= EDUCATION_RANK[character.education_level]:
                    raise EducationRequirementError("You already hold this degree or a higher qualification.")
                current_gpa = 2.5 if character.gpa is None else character.gpa
                if current_gpa < minimum_gpa:
                    raise EducationRequirementError(
                        f"This program requires a GPA of at least {minimum_gpa:.1f}; your current GPA is {current_gpa:.2f}."
                    )

                updated = replace(
                    character,
                    current_school="University",
                    school_program=selected_program,
                    school_years_left=years,
                    major=clean_major,
                    gpa=2.5,
                    version=expected_version + 1,
                )
                await self._save_character(tx, updated, expected_version)
                await self._insert_log(
                    tx,
                    updated,
                    f"Enrolled in a {selected_program.value.replace('_', ' ')} program in {clean_major}.",
                    int(self.clock()),
                )
                return updated

    async def study(self, user_id: int, effort: StudyEffort | str = StudyEffort.NORMAL) -> StudyResult:
        """Study in the current school program, changing GPA and related stats."""
        try:
            selected_effort = effort if isinstance(effort, StudyEffort) else StudyEffort(str(effort).lower())
        except ValueError as exc:
            raise ValidationError("Choose hard, normal, or slack study effort.") from exc

        async with self.locks.hold(user_id):
            async with self.db.transaction() as tx:
                character, expected_version = await self._load_active(tx, user_id)
                await self._ensure_no_pending_event(tx, character.char_id)
                if character.in_prison:
                    raise CharacterInPrison()
                if character.school_program is None or character.current_school is None:
                    raise NotEnrolled()
                cursor = await tx.execute(
                    "SELECT 1 FROM education_actions WHERE char_id = ? AND age = ? LIMIT 1",
                    (character.char_id, character.age),
                )
                if await cursor.fetchone():
                    raise StudyAlreadyUsed()

                effects = STUDY_EFFECTS[selected_effort]
                gpa_before = 2.5 if character.gpa is None else float(character.gpa)
                gpa_after = max(0.0, min(4.0, round(gpa_before + effects["gpa"], 2)))
                original_stats = character.stats.to_dict()
                stats = Stats.from_dict(original_stats)
                stats.smarts += effects["smarts"]
                stats.happiness += effects["happiness"]
                stats.stress += effects["stress"]
                stats = stats.clamp_all()
                stat_changes = {
                    key: int(getattr(stats, key) - original_stats[key])
                    for key in ("smarts", "happiness", "stress")
                    if getattr(stats, key) != original_stats[key]
                }
                updated = replace(
                    character,
                    stats=stats,
                    gpa=gpa_after,
                    version=expected_version + 1,
                )
                await self._save_character(tx, updated, expected_version)
                created_at = int(self.clock())
                await tx.execute(
                    """INSERT INTO education_actions
                           (char_id, age, effort, gpa_before, gpa_after, effects_json, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (
                        character.char_id,
                        character.age,
                        selected_effort.value,
                        gpa_before,
                        gpa_after,
                        json.dumps({"stats": stat_changes}, separators=(",", ":")),
                        created_at,
                    ),
                )
                await self._insert_log(
                    tx,
                    updated,
                    f"Studied {selected_effort.value} at {character.current_school}; GPA is now {gpa_after:.2f}.",
                    created_at,
                )
                return StudyResult(updated, selected_effort, gpa_before, gpa_after, stat_changes)

    @staticmethod
    def _validate_major(major: str) -> str:
        if not isinstance(major, str):
            raise ValidationError("Enter a field of study.")
        clean = " ".join(major.split()).strip()
        if not 2 <= len(clean) <= 40 or any(ord(char) < 32 or ord(char) == 127 for char in clean):
            raise ValidationError("A major must be 2–40 characters and contain no control characters.")
        return clean

    async def _load_active(self, tx: aiosqlite.Connection, user_id: int) -> tuple[Character, int]:
        cursor = await tx.execute(
            "SELECT char_id, data_json, version FROM characters WHERE user_id = ? AND is_alive = 1 LIMIT 1",
            (user_id,),
        )
        row = await cursor.fetchone()
        if row is None:
            cursor = await tx.execute("SELECT 1 FROM characters WHERE user_id = ? LIMIT 1", (user_id,))
            if await cursor.fetchone():
                raise CharacterDead()
            raise CharacterNotFound()
        character = Character.from_dict(json.loads(row["data_json"]))
        character.char_id = int(row["char_id"])
        character.version = int(row["version"])
        return character, int(row["version"])

    @staticmethod
    async def _ensure_no_pending_event(tx: aiosqlite.Connection, char_id: int) -> None:
        cursor = await tx.execute("SELECT 1 FROM pending_events WHERE char_id = ? LIMIT 1", (char_id,))
        if await cursor.fetchone():
            raise PendingEventExists()

    @staticmethod
    async def _save_character(
        tx: aiosqlite.Connection,
        character: Character,
        expected_version: int,
    ) -> None:
        stats_json = json.dumps(character.stats.to_dict(), separators=(",", ":"), allow_nan=False)
        data_json = json.dumps(character.to_dict(), ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        cursor = await tx.execute(
            """UPDATE characters SET stats_json = ?, version = ?, data_json = ?
               WHERE char_id = ? AND version = ? AND is_alive = 1""",
            (stats_json, character.version, data_json, character.char_id, expected_version),
        )
        if cursor.rowcount != 1:
            raise ConcurrentUpdate()

    @staticmethod
    async def _insert_log(
        tx: aiosqlite.Connection,
        character: Character,
        text: str,
        created_at: int,
    ) -> None:
        await tx.execute(
            """INSERT INTO life_logs (char_id, age, category, text, importance, created_at)
               VALUES (?, ?, 'education', ?, 2, ?)""",
            (character.char_id, character.age, text, created_at),
        )
